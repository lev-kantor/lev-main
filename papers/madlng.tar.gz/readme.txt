Article submitted by:   L. N. Kantorovich

Journal submitted to:       J. of Phys: Cond. Matter

Article title: "Coulomb potential inside big finite crystal"

Authors:           L. N.  Kantorovich, I. I. Tupitsyn

Article Type:       Paper

Status of article:  Revised & accepted

Reference number:   CM/103908/PAP


Postal address:       Dept. of Physics and Astronomy
                      University College London
                      Gower Street 
                      London  WC1E 6BT

Telephone:            tel: (+44) (0)171-4193032

Fax:                  FAX: (+44) (0)171-3911360 (CMMP)

E-mail:  l.kantorovich@ucl.ac.uk
         ucaplek@ucl.ac.uk

Article file format:   LaTeX2e

Number of figures:    1

The number of separate figure files: 1 encapsulated postscript

