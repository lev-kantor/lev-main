      implicit real*8 (a-h,o-z)
      dimension R_Sph(3),r(3)
      include 'images.inc'
      include 'charges.inc'
      include 'precis.inc'
      dimension R_charge1(3)
      real*8 induc_poten
      logical Do_Forces_charges,Do_Forces_tip
      data unit/1.889725989D00/,tiny/0.001D00/

c
c..........................................................................
c Input:  V          - external potential in Volts
c ^^^^^   Rad        - sphere radius in A
c         R_Sph(xyz) - position of the sphere center in A
c      ( Note: z-component is the coordinate of the bottom of the sphere )
c         Z_plane    - Z-coordinate of the plane in A (parallel to xy-plane)
c      N_add_charges - number of points charges between the metals
c      scale - scaling factor to give coordinates of the charges in A
c      R_charge(xyz) - position of every such a charge (in A)
c      Charges       - amount of charge (a.u.) which is at R_charge
c..........................................................................
c
      open(2,file='input.img',form='formatted',status='old')
      read(2,*) V
      read(2,*) Rad
      Rad=Rad*unit
      read(2,*) R_Sph(1),R_Sph(2),Rz
      R_Sph(1)=R_Sph(1)*unit
      R_Sph(2)=R_Sph(2)*unit
      R_Sph(3)=Rz*unit + Rad
      read(2,*) Z_plane
      Z_plane=Z_plane*unit

c
c_________________ precision and flags:
c     precis = tolerance (if < 1)  or number of image charges (if integer)
c     iPrnt = integer - amount of output
c     iforce_charge = 1 if forces on charges are calculated 
c                   = 0 if not
c     iforce_tip = 1 if force on the tip is calculated
c                = 0 if not
c     iwrite = 1 - if write all image charges into <charges.out>
c            = 0 - if not
c     isetup = 0 - no plane/sphere, 1 - plane only, 2 - sphere only, 3 - plane/sphere
c     ibias = 1 is bias only calculation
c           = 0 - if bias and metal polarisation (due to charges)
c     iqmc = 1 if some atoms are marked as belonging to the Quantum
c              cluster and the energy and forces would correspond
c              to another definition of energy.
c          = 0 ususal definition of energy is used; all charges are
c              treated in the same way. 

      read(2,*) precis,iPrnt,
     &          iforce_charges,iforce_tip,iwrite,isetup,ibias,iqmc

c________ if precis < 1 then it is used as the precision to trancate the
c                       series of image charges;
c         if precis = positive integer number, then this will be the number
c                     of image charges on either side of the plane 
      if(precis.lt.1.0) then
         write(*,'(a,e12.6)')'... Setting precision to precis=',precis
         Toler=.true.
         NumImg=Number0/2
         write(*,'(a,i3)')
     &           '... Setting max. # of image charges to ',NumImg 
      else if(abs(nint(precis)).gt.2) then
         NumImg=abs(nint(precis))
         if(NumImg.gt.Number0/2) then
           write(*,'(a,i5,a,i5)')
     &        'FATAL! Number of image charges ',NumImg,' > ',Number0/2
           stop
         end if
         write(*,'(a,i3)')
     &           '... Setting max. # of image charges to ',NumImg 
         Toler=.false.
         precis=0.0
         write(*,'(a,e12.6)')'... Setting precision to precis=',precis
      else
         write(*,*)'FATAL! Wrong number of image charges!'
         stop
      end if

c________ if to calculate forces on charges
c      Do_Forces_charges = .true.  - forces on charges will be calculated    
c                          .false. - forces will NOT be calculated    
      if(iforce_charges.eq.1) then
        Do_Forces_charges=.true.
        write(*,'(a)')'... Forces on charges WILL be calculated'
      else
        Do_Forces_charges=.false.
        write(*,'(a)')'... Forces on charges will NOT be calculated'
      end if

c________ if to calculate the force on the tip
c      Do_Forces_tip = .true.  - the force on the tip will be calculated
c                      .false. - the force will NOT be calculated    
      zfrcT=0.0
      zfrcT_Sph=0.0
      if(iforce_tip.eq.1) then
        Do_Forces_tip=.true.
        write(*,'(a)')'... The force on the tip WILL be calculated'
      else
        Do_Forces_tip=.false.
        write(*,'(a)')'... The force on the tip will NOT be calculated'
      end if

c________ if to print out the charges
c     Write_Charges = .true. - charges will be written to charges.out
c                    .false. - will not be written  
      if(iwrite.eq.1) then
        Write_Charges=.true.
        write(*,'(a)')'... Image charges WILL be printed out'
        open(1,file='charges.out',form='formatted',status='unknown')
      else
        Write_Charges=.false.
        write(*,'(a)')'... Image charges will NOT be printed out'
      end if

c_________set logical variables according to isetup

      if(isetup.eq.2.or.isetup.eq.3) then
         do_sphere=.true.
         write(*,'(a)')'... Sphere is present'
      else
         write(*,'(a)')'... No sphere'
      end if
      
      if(isetup.eq.1.or.isetup.eq.3) then
         do_plane=.true.
         write(*,'(a)')'... Plane is present'
      else
         write(*,'(a)')'... No plane'
      end if
      
c_________ if polarisation is accounted for or not
      if(ibias.eq.1) then
         write(*,'(a)')'... ONLY bias: metal polarisation is OFF'
         do_only_bias=.true.
      else
         write(*,'(a)')'... Metal polarisation is ON'
         do_only_bias=.false.
      end if

c_________ if Quantum Cluster option is on
      if(iqmc.eq.1) then
         do_QMC=.true.
         write(*,'(a)')'... Quantum Cluster option is ON'
      else
         do_QMC=.false.
         write(*,'(a)')'... Quantum Cluster option is OFF'
      end if

c
c..... We move the system by Shift(xyz) so that the plane would 
c      be at z=0 and the sphere - at (0,0,H).
c      We also check if H > Rad.
c
      if(do_sphere) then
         H=R_Sph(3)-Z_plane
         if(H.lt.Rad) then
            write(*,'(a,2(f10.5,a))')'FATAL! H= ',H,' > Rad= ',Rad,' !'
            stop
         end if
         Shift(1)=R_Sph(1)
         Shift(2)=R_Sph(2)
      else
         H=0.0
         Rad=0.0
         Shift(1)=0.0
         Shift(2)=0.0
      end if

      Shift(3)=Z_plane
     
      if(iPrnt.ge.4) then
        open(9,file='image.out',form='formatted',status='unknown')
        write(9,*)'>>>>>>>>>>> Image charges input (a.u.) <<<<<<<<<<<<<'
        write(9,'(3(a,f10.5))') 'H = ',H,' Rad=',Rad,' V=',V
        write(9,'(a,3(f10.5,1x),a,f10.5)') 'R_Sph = [ ',R_Sph, 
     ,                                         ' ], Z_plane=',Z_plane
        write(9,'(a,3(f10.5,1x),a)') 'Shift = [ ',Shift, ' ]'
      end if
c
c............. generate all image charges (B-charges) for the bare electrodes:
c              
c
      open(13,file='potent.out',form='formatted',status='unknown')

      if(do_sphere) then
         call make_bare_images(Rad,V,H,iPrnt)
      end if

c     
c.......... additional point charges (coordinates in units of scale) 
c           simulating the charge density
c           between the electrodes: their coordinates are transformed to a.u.
c           [We first check if the charges are positioned between the electrodes.]
c
c           No_charges = 0 - no charges are present
c                      =/= 0 - number of charges (optional)
c
      read(2,*) N_add_charges, scale
      if(N_add_charges.eq.0) go to 200
c
c___________ iFlagF(L) = 0 the force imposed on the charge L is not calculated
c                      = 1 the force is calculated
c            iFlagQMC(L) = 1 if the charge belongs to the QMC
c                        = 0 if does not.          
      L=1
 10   read(2,*,err=15,end=15)
     &     (R_charge(L,j),j=1,3),Charges(L),iFlagF(L),iFlagQMC(L)
      do i=1,3
         R_charge(L,i)=R_charge(L,i)*scale*unit
      end do
      if(do_sphere) then
         a=(R_charge(L,1)-R_Sph(1))**2+(R_charge(L,2)-R_Sph(2))**2+
     +        (R_charge(L,3)-R_Sph(3))**2
         if(sqrt(a).le.Rad+tiny) then
            write(*,'(a,i5,a)') 'WARNING! The charge ',L,
     ,           ' is too close to or inside the sphere!'
            write(*,'(a)')       '         It will be excluded!'
            write(*,'(a,3(x,f10.5))') 
     &           'The charge is at (au): ',(R_charge(L,i),i=1,3)
            write(*,'(a,3(x,f10.5))') 
     &           'The sphere is at (au): ',(R_Sph(i),i=1,3)
            write(*,'(a,f10.5)') '      with a = ',a
            go to 10         
         end if
      end if
      if(do_plane) then
         if(R_charge(L,3).lt.Z_plane+tiny) then
            write(*,'(a,i5,a)') 'WARNING! The charge ',L,
     ,           ' is too close to or below the plane!'
            write(*,'(a)')       '         It will be excluded!'
            write(*,'(a,3(x,f10.5))') 
     &           'The charge is at (au): ',(R_charge(L,i),i=1,3)
            write(*,'(a,3(x,f10.5))') 
     &           'The plane is at (au) Z_plane = ',Z_plane
            go to 10         
         end if
      end if
      L=L+1
      if(L.gt.N_add_charges0) then
         write(*,*)'FATAL! N_add_charges0 (charges.inc) is not enough!'
         write(*,*) '... needed at least = ',L
         stop
      end if
      go to 10
 15   N_add_charges=L-1
      write(*,'(a,i5)')
     &     '___> Number of charges N_add_charges = ',N_add_charges
      close (2)
c
      if(Do_Forces_charges .or. Do_Forces_tip) 
     &   open(12,file='forces.out',form='formatted',status='unknown')
c
c............ calculate forces imposed on added charges due to bare electrods
c
      if(Do_Forces_charges.and.do_sphere) then
         call bare_forces(iPrnt)
      end if

c
c............ Potential on every added charge L due to bare electrodes. 
c             This is the initial setting for the Poten(charge). 
c             The potentials are needed for the energy.
c
      
      do L=1,N_add_charges     
         Poten0(L)=0.0
         Poten_ind(L)=0.0
         if(do_sphere) then
            do i=1,3
               r(i)=R_charge(L,i)
            end do
            Poten0(L)=bare_poten(r,iPrnt)
         end if
      end do
      
c
c............ calculate induced Q,P-charges generated by every added charge,
c             as well as their contribution to the energy, forces and the 
c             potential
c     zForce  - force acting on the spherical electrode        
c
      if(.not.do_only_bias) then
         do L=1,N_add_charges

c________________generate image charges due to charge L
c________________check whether we have sphere/plane
            IF(do_sphere) THEN
               call make_add_images(L,Rad,H,iPrnt)
            ELSE
               
c____<PLANE ONLY>
c____set coord. system

               R_charge1(1)=R_charge(L,1)-Shift(1)
               R_charge1(2)=R_charge(L,2)-Shift(2)
               R_charge1(3)=R_charge(L,3)-Shift(3)
               if(iPrnt.ge.4) then
                  write(9,'(a,3(f10.5,1x),a)') 'R_charge1 = [ ',R_charge1, ' ]'
               end if

c____for plane only, image is just reflection

               R_imP(0,1)=Shift(1)+R_charge1(1)
               R_imP(0,2)=Shift(2)+R_charge1(2)
               R_imP(0,3)=Shift(3)-R_charge1(3)
               P_image(0)=-Charges(L)
               if(Write_Charges) write(1,'(3(1x,f10.5),5x,e12.6)') 
     &              (R_imP(0,k),k=1,3),P_image(0)
            END IF

c________________contribution to the force on ALL charges from charge L
            if(Do_Forces_charges) call forces(L,R_Sph,Rad,H,V,iPrnt)

c_____________________________contribution to the force on the tip, 
c                             zForce, from charge L
            if(Do_Forces_tip.and.do_sphere) then
               call zForce_ind(L,R_Sph,Rad,V,H,iPrnt,zfrc,zfrc_Sph)
               zfrcT=zfrcT + zfrc
               zfrcT_Sph=zfrcT_Sph + zfrc_Sph
            end if
c_____________________________contribution to the induced potential 
c                             at ALL charges due to charge L
            do L1=1,N_add_charges
               do i=1,3
                  r(i)=R_charge(L1,i)
               end do
               Poten_ind(L1)=Poten_ind(L1)+induc_poten(r,iPrnt)
            end do
            
         end do
      end if
c
c............ final potential, tip force and output
c
      do L=1,N_add_charges
        Poten(L)= Poten_ind(L)+ Poten0(L)
      end do
      write(13,'(a)') '>>>>>>> Final potentials on charges <<<<<<<'
      if(Do_Forces_charges) 
     &    write(12,'(a)') '>>>>>>> Final forces on charges <<<<<<<<'
      do Nch=1,N_add_charges
        write(13,'(i5,5x,3(1x,e24.14))') 
     &                      Nch,Poten0(Nch),Poten_ind(Nch),Poten(Nch)
        if(Do_Forces_charges) then
           write(12,'(i5,5x,3(1x,e24.14))') Nch,(Force(Nch,i),i=1,3)
        end if
      end do
c
c............ contribution from bare electrodes to the Z-force acting
c             on the spherical electrode
c
      Bare=0.0
      Bare_Sphere=0.0

 200  if(Do_Forces_tip.and.do_sphere) then
         call Bare_zforce(Rad,V,H,iPrnt,Bare,Bare_Sphere)
      end if

c
c............ summing up all the contributions to the force on the tip
c
      if(Do_Forces_tip) then
         zForce= - 0.5*zfrcT + zfrcT_Sph
         zForce=zForce + Bare + Bare_Sphere 
      end if
      if((Do_Forces_charges .or. Do_Forces_tip) .and. iPrnt.ge.3) then
       write(12,'(a)') '........ >> The force on the sphere <<.........'
       write(12,'(a,e18.10)')'From Q*V/2 term (bare): Bare_Sphere= '
     ,                               ,Bare_Sphere
       write(12,'(a,e18.10)')'From bare pot. on charges:     Bare= '
     ,         ,Bare
       write(12,'(a,e18.10)')'From Q*V/2 term (ind.):   zfrcT_Sph= '
     ,         ,zfrcT_Sph
       write(12,'(a,e18.10)')'From induced pot. on charges: zfrcT= '
     ,         ,zfrcT
       write(12,'(a,e18.10)')'Total force on the sphere:   zForce= '
     ,         ,zForce
      end if
      if((Do_Forces_charges .or. Do_Forces_tip) .and. iPrnt.ge.3) 
     &   write(12,'(a,e24.15)') 
     &        'TOTAL force on the tip:      zForce= ',zForce
c
c............... Final calculation of the electrostatic energy(MIND: in a.u.)
c         Ecpctr - constant part of the capacitor energy
c
      en_unit=0.036749
      EnergyB=0.5*V*B_sum*en_unit
      Ecpctr=0.5*V*B_image(1)*en_unit
c
      EnergyFi0=0.0
      EnergyFi_ind=0.0
      if(N_add_charges.eq.0) go to 400
c     
      do L=1,N_add_charges
         if(do_QMC .and. iFlagQMC(L).eq.1) then
            EnergyFi_ind=EnergyFi_ind-Charges(L)*Poten_ind(L)
         else
            EnergyFi0=EnergyFi0+Charges(L)*Poten0(L)
            EnergyFi_ind=EnergyFi_ind+Charges(L)*Poten_ind(L)
         end if
      end do
      EnergyFi_ind=0.5*EnergyFi_ind
c
c________ this is an effective energy: is needed to calculate the force;
c         we also remove the constant part to facilitate the energy fit
c         (i.e. at large distances the energy would tend to 0.0)

 400  Energy_F=-(EnergyB-Ecpctr)+EnergyFi0+EnergyFi_ind

c________ this is efffective energy without taking into account the effect
c         of induced charges
      Energy_F_noind=-EnergyB+EnergyFi0

      if(iPrnt.ge.3) then
         write(13,'(a)') 
     &    '........ >>> Energy is split as follows (a.u.): <<<.........'
         write(13,'(a,e18.10)')
     &   'from bare electrodes -Q*V/2:       -EnergyB= ',-EnergyB
         write(13,'(a,e18.10)')
     &   'bare potential on charges:        EnerguFi0= ', EnergyFi0
         write(13,'(a,e18.10)')
     &   'induced potential on charges:  EnerguFi_ind= ', EnergyFi_ind
         write(13,'(a,e18.10)')
     &   'constant part of the capacitor:      Ecpctr= ', Ecpctr
         write(13,'(a,e18.10)')
     &   'TOTAL effective energy:            Energy_F= ', Energy_F
         write(13,'(a,e18.10/)')
     &   'no-iNd-effective energy:     Energy_F_noind= ', Energy_F_noind
      end if
c
c
c............ stupid energy: interaction between bare images on both sides of the plane
c      stupid= stupid_energy(iPrnt)
c      write(13,'(a,e16.10/)')'  stupid energy (a.u.): ',stupid

      write(13,'(a,e16.10)')'>>>>>>>>>>>>>> Final output <<<<<<<<<<<<<<'
      write(13,'(a,e24.15)')'>>>> Effective Energy (a.u.): ',Energy_F
      write(13,'(a,e24.15)')'>>>> zForce acting on the tip (a.u.): ',
     &                zForce
c
c............... closing all files, exiting
      if(iPrnt.ge.4) close (9)
      if(Write_Charges) close (1)
      if(Do_Forces_charges .or. Do_Forces_tip) close (12)
      close (13)
      stop
      end

      subroutine  make_bare_images(Rad,V,H,iPrnt)
c..........................................................................
c      All image charges are generated here due to bare electrodes 
c (i.e. sphere+plane system), so-called B-charges.
c                                       ^^^^^^^^^
c__________ input:
c  R_Sph - position of the sphere center  (a.u.)
c  Rad - sphere radius  (a.u.)
c  V - voltage (Volts)
c__________ output: via common block /image_charges/
c..........................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      dimension Z_image(Number0)
c
c[1]...... image charges and their z-positions (wrt the shifted system)
c          corresponding to the bare electrodes: B-images
c
      call get_charges(B_sum,B_image,Z_image,Number,Number0,
     ,                             Rad,V,H,iPrnt,do_plane)
c
c[2]...... return charges back to the initial coordinate system and add
c          their under-plane images as well which form pairs as (i,i+Number)
c

c______________ all B-images (i - for above, j - for below the plane)
      do i=1,Number
         R_im(i,1)=Shift(1)
         R_im(i,2)=Shift(2)
         R_im(i,3)=Shift(3)+Z_image(i)
         if(do_plane) then
            j=i+Number
            R_im(j,1)=Shift(1)
            R_im(j,2)=Shift(2)
            R_im(j,3)=Shift(3)-Z_image(i)
            B_image(j)=-B_image(i)
         end if
      end do
      if(iPrnt.gt.0.and.Write_Charges) then
c        write(1,*)'>>>>>>>>>>>>>> B-Image charges <<<<<<<<<<<<<<<<<<'
        ijk=1
        if(do_plane) ijk=2
        do i=1,ijk*Number
          write(1,'(3(1x,f10.5),5x,e12.6)') 
     &                      (R_im(i,k),k=1,3),B_image(i)
        end do
      end if
      return
      end

      subroutine get_charges(Q_sum,Q_image,Z_image,Number,Number0,Rad,
     ,                                   V,H,iPrnt,do_plane)
c..........................................................................
c    Charges, Q_image(i), and their z-positions, Z_image(i)
c are calculated (i=1,2,...,Number) from:
c   V - external potential (in Volts)
c   H - sphere height above the metallic surface (in a.u.)(i.e. center-surface)
c Rad - sphere radius (in a.u.)
c iPrnt - printing parameter
c..........................................................................
c Q_sum - sum of upper charges (is needed for the energy)
c..........................................................................
c  The last charge (with # Number) corresponds to the sum of all charges 
c to infinity and is positioned at the limit location.
c..........................................................................
c MIND: sphere is supposed to be at the point (0,0,H)
c       plane - at z=0
c MIND: only upper charges are calculated; their mirror images below the
c       plane are added at a latter stage.
c..........................................................................
      implicit real*8 (a-h,o-z)
      include 'precis.inc'
      dimension Q_image(Number0),Z_image(Number0)
      real*8 xlmb
      logical do_plane
      data unit/1.889725989D00/
c
c......... set up the first charge in a.u.; Rad, H - in a.u. as well
c
      Q=0.069446124*V*(Rad/unit)
      xlmb=H/Rad
      if(iPrnt.ge.10)  write(9,'(a,e12.6)') '>>>>>> lambda=',xlmb
c
c......... recursion process
c
      i=1
      D=2*xlmb
      zQ=xlmb
      Q_image(1)=Q
      Z_image(1)=zQ*Rad
      Q_sum=Q
      if(.not.do_plane) then
        Number=1
        go to 20
      end if
 10   i=i+1
      if(i.gt.Number0/2) then
        write(*,*)'FATAL in get_charges! Number0 is not sufficient!'
        stop
      end if
      if(i.eq.NumImg) go to 15
      zQ=xlmb-1.0/D
      Q=Q/D
      Q_image(i)=Q
      Z_image(i)=zQ*Rad
      if(Z_image(i-1)-Z_image(i).ge.precis) then
        D=2*xlmb-1.0/D
        Q_sum=Q_sum+Q
        go to 10
      end if
 15   Number=i
      D_inf=xlmb+sqrt(xlmb*xlmb-1.0)
      Q_image(i)=Q_image(i-1)/(D_inf-1.0)
      Z_image(i)=Rad*(D_inf-xlmb)
      Q_sum=Q_sum+Q_image(i)
c
c........ print
c
 20   if(iPrnt.ge.10) then
        do i=1,Number
          write(9,'(i3,1x,2(a,e12.6))') 
     &            i,' Q= ',Q_image(i),' zQ= ',Z_image(i)
        end do
        write(9,'(a,e12.6)')'>>>>>>> B_sum=',Q_sum
      end if
      return
      end

      subroutine make_add_images(L,Rad,H,iPrnt)
c..........................................................................
c      All image charges are generated here 
c due a L-th Charge(L) at R_charge(L,xyz) placed between the electrodes.
c__________ input:
c  R_Sph - position of the sphere center  (a.u.)
c  Rad - sphere radius  (a.u.)
c  V - voltage (Volts)
c__________ output: via common block /image_charges/
c..........................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      dimension R_charge1(3)
c
c[1]......... relative position of the Charge(L) at R_charge1 
c
      R_charge1(1)=R_charge(L,1)-Shift(1)
      R_charge1(2)=R_charge(L,2)-Shift(2)
      R_charge1(3)=R_charge(L,3)-Shift(3)
      if(iPrnt.ge.4) 
     &    write(9,'(a,3(f10.5,1x),a)') 'R_charge1 = [ ',R_charge1, ' ]'
c
c[2]...... image charges and their positions  (wrt the shifted system)
c          corresponding to the added unit charge: Q-charges
c
      call get_QP_charges(Q_sum,Q_image,R_imQ,NumberQP,Number0,Rad,H,
     ,                         R_charge1,iPrnt,'Q',do_plane)
      Q_sum=Q_sum*Charges(L)
      if(iPrnt.ge.4) write(10,'(a,e12.6)') '>>>>>> Q_sum= ',Q_sum
c
c.............. if only sphere is present, we have only one Q-charge
      if(.not.do_plane)  then
        R_imQ(1,1)=Shift(1)+R_imQ(1,1)
        R_imQ(1,2)=Shift(2)+R_imQ(1,2)
        R_imQ(1,3)=Shift(3)+R_imQ(1,3)
        Q_image(1)=Q_image(1)*Charges(L)
        go to 20
      end if
c
c[3]...... image charges and their positions  (wrt the shifted system)
c          corresponding to the added unit charge: P-charges
c
      call get_QP_charges(P_sum,P_image,R_imP,NumberQP,Number0,
     ,                  Rad,H,R_charge1,iPrnt,'P',do_plane)
      P_sum=P_sum*Charges(L)
      if(iPrnt.ge.4) write(10,'(a,e12.6)') '>>>>>> P_sum= ',P_sum
c
c[4]...... return charges back to the initial coordinate system and add
c          their under-plane images as well which form pairs as (i,i+Number)
c
      do i=1,NumberQP
        j=i+NumberQP
c__________________________ Q-images
        R_imQ(i,1)=Shift(1)+R_imQ(i,1)
        R_imQ(i,2)=Shift(2)+R_imQ(i,2)
        R_imQ(j,3)=Shift(3)-R_imQ(i,3)
        R_imQ(i,3)=Shift(3)+R_imQ(i,3)
        R_imQ(j,1)=R_imQ(i,1)
        R_imQ(j,2)=R_imQ(i,2)
        Q_image(i)=Q_image(i)*Charges(L)
        Q_image(j)=-Q_image(i)
c__________________________ P-images
        R_imP(i,1)=Shift(1)+R_imP(i,1)
        R_imP(i,2)=Shift(2)+R_imP(i,2)
        R_imP(j,3)=Shift(3)-R_imP(i,3)
        R_imP(i,3)=Shift(3)+R_imP(i,3)
        R_imP(j,1)=R_imP(i,1)
        R_imP(j,2)=R_imP(i,2)
        P_image(i)=P_image(i)*Charges(L)
        P_image(j)=-P_image(i)
      end do
c______________ an image to the added charge below the plane which gave rise to
c               the P-sequence of images
      R_imP(0,1)=Shift(1)+R_charge1(1)
      R_imP(0,2)=Shift(2)+R_charge1(2)
      R_imP(0,3)=Shift(3)-R_charge1(3)
      P_image(0)=-Charges(L)
c______________ just for "symmetry"  of notations: add the source charge as well
 20   R_imQ(0,1)=R_charge(L,1)
      R_imQ(0,2)=R_charge(L,2)
      R_imQ(0,3)=R_charge(L,3)
      Q_image(0)=Charges(L)
c
      if(iPrnt.gt.0.and.Write_Charges) then 
c        write(1,'(a,i3,a)')
c     &     '>>>>>>>> Q-Image charges due to L=',L,' <<<<<<<<'
        ijk=2
        if(.not.do_plane) ijk=1
        do i=1,ijk*NumberQP
          write(1,'(3(1x,f10.5),5x,e12.6)') 
     &                      (R_imQ(i,k),k=1,3),Q_image(i)
        end do
        if(.not.do_plane) return
c        write(1,'(a,i3,a)')
c     &     '>>>>>>>> P-Image charges due to L=',L,' <<<<<<<<'
        do i=0,2*NumberQP
          write(1,'(3(1x,f10.5),5x,e12.6)') 
     &                      (R_imP(i,k),k=1,3),P_image(i)
        end do
      end if
      return
      end

      subroutine get_QP_charges(Q_sum,Q_image,R_im,Number,Number0,Rad,H,
     ,                      R_point,iPrnt,who,do_plane)
c..........................................................................
c    Q- or P- image charges, Q_image(i), and their positions, R_im(i,3) 
c (only in the upper side of the plane) are calculated (i=1,2,...,Number) 
c for a sphere and a plane with a presense of a UNIT POINT CHARGE at R_point.
c                                               ^^^^^^^^^^^^^^^^^
c ____________ Input:
c   H - sphere center height above the metallic surface (in a.u.)
c Rad - sphere radius (in a.u.)
c R_point(xyz) - position of the UNIT CHARGE
c iPrnt - printing parameter
c who = 'Q' or 'P' for Q- or P-charges, respectively
c Q_sum - total image charge (either Q or P) which is inside the metal sphere 
c         (i.e. above the plane). This is needed for the energy.
c..........................................................................
c  The last charge corresponds to the sum of all charges till infinity and
c is positioned at the limit location on the z-axis.
c..........................................................................
c IMPORTANT: the plane is at z=0 and the sphere - at (0,0,H).
c..........................................................................
      implicit real*8 (a-h,o-z)
      include 'precis.inc'
      dimension Q_image(0:Number0),R_im(0:Number0,3),R_point(3)
      logical do_plane
      character who
c
c......... the only difference for Q- and P-charges: the position and
c          the sign of the initial charge given by iPQ in the end
      iPQ=1
      if(who.eq.'P') iPQ=-1
c
c......... recursion process for image charges
c
      if(who.eq.'Q') Number=Number0+1
      i=1
      call fun_Qh_image(Q_factor,R_im(i,1),R_im(i,2),R_im(i,3),
     ,                      R_point(1),R_point(2),iPQ*R_point(3),H,Rad)
      Q_image(1)=-Q_factor*iPQ
      Q_sum=Q_image(1)
      if(.not.do_plane) then
        Number=1
        go to 30
      end if
 10   i=i+1
      if(i.gt.Number0/2) then
        write(*,*)'FATAL in get_QP_charges! Number0 is not sufficient!'
        write(*,*) Number0,i
        stop
      end if
      if(i.eq.NumImg .and. who.eq.'Q') then
        Number=NumImg
        go to 20
      end if
      call fun_Qh_image(Q_factor,R_im(i,1),R_im(i,2),R_im(i,3),
     ,                      R_im(i-1,1),R_im(i-1,2),-R_im(i-1,3),H,Rad)
      if(who.eq.'Q') then
        a=(R_im(i,1)-R_im(i-1,1))**2+
     +     (R_im(i,2)-R_im(i-1,2))**2+(R_im(i,3)-R_im(i-1,3))**2
        a=sqrt(a)
        if(a.lt.precis) Number=i
      end if
 20   if(i.eq.Number) then
         d=sqrt(H*H-Rad*Rad)
         Q_image(i)=Q_image(i-1)*Rad/(H-Rad+d)
         R_im(i,1)=0.0
         R_im(i,2)=0.0
         R_im(i,3)=d
         Q_sum=Q_sum+Q_image(i)
      else
        Q_image(i)=Q_image(i-1)*Q_factor
        Q_sum=Q_sum+Q_image(i)
        go to 10
      end if
c........... print
 30   if(iPrnt.ge.6) then
         do i=1,Number
           write(9,'(i3,a,e12.6,a,3(1x,e12.6),a)')
     &          i,' Q= ',Q_image(i),' R= [',(R_im(i,j),j=1,3),' ]' 
         end do
         write(9,'(a,e12.6)') '>>>>>>>>> Q_sum= ',Q_sum
      end if
      return
      end

      subroutine fun_Qh_image(Q_fact,R_imX,R_imY,R_imZ,xq,yq,zq,H,Rad)
c..................................................................
c  Position of the image charge, (R_imX,R_imY,R_imZ), inside the 
c upper sphere (at (0,0,H)) is given for a unit charge at (xq,yq,zq)
c..................................................................
c  Q_fact to the image charge is also calculated
c..................................................................
c  The plane is suppposed to be at z=0
c..................................................................
      implicit real*8 (a-h,o-z)
      dimension x(3)
      x(1)=xq
      x(2)=yq
      x(3)=zq-H
      x2=x(1)*x(1)+x(2)*x(2)+x(3)*x(3)
      a=Rad*Rad/x2
      R_imX =   a*x(1)
      R_imY =   a*x(2)
      R_imZ = H+a*x(3)
      Q_fact = sqrt(a)
      return
      end

 
