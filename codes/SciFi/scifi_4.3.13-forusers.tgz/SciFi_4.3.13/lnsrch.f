      subroutine lnsrch(n,xold,fold,g,p,x,f,stmax,check,func)
