      subroutine do_conjug(p,energy_best,g,energy_gain,iPrnt,imf)
c..........................................................................
c conjugate gradient optimisation engine
c..........................................................................
c     n_dfree     - Number of degrees of freedom to optimise
c     i_lns_count - Number of line_search calls
c     i_eng_count - Number of Total energy calculations
c___________ INPUT:
c     p() - initial coordinates (in 1-dim representation)
c     g() - initial gadients
c     energy_best - initial energy
c___________ OUTPUT:
c     g() - final gradients
c     p() - final coordinates (in 1-dim representation)
c     x,y,z - final coordinates (in common /work/)
c     energy_best - final energy
c     imf - coordinate number in 1-dim vector with the max force
c........................................................................
c     xi(*)  -  direction of minimisation
c g_old, xi_old - gradients and direction on the previous (old)
c                conjugate gardient step
c........................................................................
      include 'shell.inc'
      dimension g(max_free),p(max_free),pnew(max_free)
      dimension xi(max_free),xi_old(max_free),g_old(max_free)
      logical check_eng,check_crd,check_frc,l_crd,l_frc,l_eng
      data tiny/0.0000001/            
c
c______ set the relaxation counter to 0:
c
      if(nid.eq.0) then
         write(*,'(a,i4)') ' conjug: Degrees of freedom =',n_dfree
         write(9,'(a,i4)') ' conjug: Degrees of freedom =',n_dfree
      end if
      N=0
c
c........ set counters for forces and energy to zero
      i_eng_count=0
      i_lns_count=0
      opt_problems=.false.
c
c...... initialise directions (xi) as well as 'old' (g_old) 
c       gradient and 'old' direction (xi_old): we start from the
c       steepest descent.
c
      if(nid.eq.0) 
     & write(9,'(a)') ' >>>>>>>  Start Conjugate Gradients  <<<<<<< '
 1    HF=0.0
      do i=1,n_dfree
        g_old(i)= g(i)
        xi_old(i)= -g_old(i)
        xi(i)= -g_old(i)
        HF=HF+xi(i)*xi(i)
      end do
c
C=====================================================================  
c================   Atomic relaxation starts here  ===================
C=====================================================================  
c
c__________ move the relaxation counter 1 step forward
c
 7000 N=N+1
c
c......... undertake one-dimensional search along xi.
c  It returns with a new point p(), the energy there energy_best
c  and the achieved energy fall energy_gain.
C
      M_Energy=3
      call linesearch(N_Energy,M_Energy,p,pnew,xi,
     ,      energy_best,energy_gain,iReturn,HF,iPrnt)
c
      i_eng_count=i_eng_count+N_Energy
      if(iReturn.eq.1) then
         opt_problems=.true.
         return
      end if

c______ Do restart file 
      if(Yes_Dump) call do_restart(pnew,iPrnt,.true.)
      if(nid.eq.0.and.iPrnt.ge.3) then
         write(9,'(a)')'))))))) New/Old Coordinates in CG ((((((((('
         call print_compare(p,pnew)
      end if
c
c............... Check energy, coordinates, forces to exit
c

      l_crd = check_crd(pnew,p,n_dfree,crd_tol)
      l_frc = check_frc(g,n_dfree,frc_tol,imf,nid)
      l_eng=check_eng(energy_gain,en_tol,nid)
      if(nid.eq.0) then
         if(l_crd) write(9,'(a)') ' Convergence in coordinates!'
         if(l_frc) write(9,'(a)') ' Convergence in forces!'
         if(l_eng) write(9,'(a)') ' Convergence in energy!'
      end if

c_________ decide whether to proceed or exit the routine
      if(l_frc.and.l_crd.and.l_eng) then
c_________ successful: exit
         if(nid.eq.0) then
            write(9,'(/a)')'==> Optimisation completed. Exiting ... <=='
            write(*,'(a)') '==> Optimisation completed. Exiting ... <=='
            write(9,'(a)') 
         end if
         finished=.true.
         return
c_________ energy and coordinates are fine, but force is still big:
c          switch to steepest descent
      else if(l_crd.and.l_eng) then
         energy_gain = es_tol
         if(nid.eq.0) then
            write(9,'(a)')'   >>>>>  Start CG from st.desc.  <<<<< '
            write(*,'(a)')'   >>>>>  Start CG from st.desc.  <<<<< '
         end if
         go to 1
      else
         if(nid.eq.0) then
            write(9,'(a/)') ' ==> next step'
            if(iPrnt.ge.3) write(*,'(a)') ' ==> next step'
         end if
      end if

c______ Update the current point
      call vector_copy(pnew,p,n_dfree)
c
c........ new gradients in g()
      call gradients(p,g,iPrnt)
      i_lns_count=i_lns_count+1
      if(i_lns_count.gt.max_opt .and. nid.eq.0) then
         write(9,'(a)') 
     &    '... WARNING! exiting CG: optimisation is NOT complete!'
         write(*,'(a)') 
     &    '... WARNING! exiting CG: optimisation is NOT complete!'
         return
      end if
c
c....... find the new direction xi
c_____ gamma=0 for steepest descent or is calculated otherwise
c
      if(method_cg.ne.'steep_des') then
         if(method_cg.eq.'fl_reeves') then
            if(nid.eq.0) write(9,*)'++ Conj. grad.: Fletcher-Reeves ++'
         else if(method_cg.eq.'polak_rib') then
            if(nid.eq.0) write(9,*)'++ Conj. grad.: Polak-Ribiere ++'
         end if
         Gcur=0.0
         Gold=0.0
         do i=1,n_dfree
            Gold=Gold+g_old(i)*g_old(i)
            if(method_cg.eq.'fl_reeves') then
               Gcur=Gcur+g(i)*g(i)
            else if(method_cg.eq.'polak_rib') then
               Gcur=Gcur+(g(i)-g_old(i))*g(i)
            end if
         end do
         if(sqrt(Gold).lt.frc_tol) then
            if(nid.eq.0) then
               write(*,'(2(a,e12.6))')
     &              'conjug:  Gold = ',Gold,' < frc_tol = ',frc_tol
               write(9,'(/a)')
     &              '==> Optimisation completed. Exiting ... <=='
               write(*,'(a)') 
     &              '==> Optimisation completed. Exiting ... <=='
               write(9,'(a)')
            end if 
            finished=.true.
            return
         end if
         gamma=Gcur/Gold
      else 
         if(nid.eq.0) write(9,*)'+++++++ steepest descent +++++++'
         gamma=0.0
      end if
      if(nid.eq.0) write(9,*) '_______> gamma=',gamma
c
c...... calculate new direction (xi) and reset 'old' (g_old) 
c       gradient and 'old' direction (xi_old)
c
      do i=1,n_dfree
        g_old(i)= g(i)
        xi_old(i)= -g_old(i) + gamma*xi_old(i)
        xi(i)= xi_old(i)
      end do
c
c......... calculate the scalar product (force*direction). If it is
c          negative (which can happen only during c.g. search), then
c          the c.g. direction xi is too bad. Switch to steep.desc.
c          Otherwise continue with cg.
c
      HF=0.0
      do i=1,n_dfree
        HF=HF-g(i)*xi(i)
      end do
      if(HF.le.0.0) then
         if(nid.eq.0) then
            write(*,'(a)')'... BAD direction! Switching to steepest ...'
            write(9,'(a)')'... BAD direction! Switching to steepest ...'
         end if
         go to 1
      end if
      go to 7000
      end

      subroutine linesearch(N_Energy,M_Energy,p,pnew,xi,
     ,      energy_best,energy_gain,iReturn,HF,iPrnt)
c......................................................................
c  M_Energy - maximal number of times of the energy calculation
c             (has to be not less than or equal to 1). It will keep
c             calculating energy unless the energy goes down even if
c             the number of times (N_Energy, see below) turns out to be
c             larger than M_Energy.
c......................................................................
c N_Energy - number of times the energy has been calculated
c iReturn = 1 - if the current direction is too bad and the steepest
c               descent line search is to be accomplished.
c......................................................................
      include 'shell.inc'
      dimension p(max_free),pnew(max_free),xi(max_free)
      data GOLD/1.618034/, GLIMIT/3./, tiny/0.0000001/
c
      iReturn=0
      N_Energy=0
c
c===================================================================
c    We are going to bracket the minimum by searching for a triple of
c points AX,BX and CX along the direction xi such that the energy
c FB in the point BX is lower than the energies FA,FC in AX,CX.
c===================================================================
c
c.......... set up the first point AX and arrived starting energy in FA0
c
      AX=0.0
      FA=energy_best
      FA0=energy_best
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(*,'(a,f18.8,a,f18.8)')'... A point=',AX,' energy=',FA
         write(9,'(a,f18.8,a,f18.8)')'... A point=',AX,' energy=',FA
      end if
c
c.......... estimate the 2nd point BX along the direction xi as 
c being the minimum of a porabola with the known energy fall, DELTA
c
      DELTA=energy_gain*0.4
      BX=2.0*DELTA/HF
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(*,*) 'DELTA,HF =',DELTA,HF
         write(9,*) 'DELTA,HF =',DELTA,HF
      end if
c
c_____________ calculate energy FB in the point BX
c
      do i = 1, n_dfree
         pnew(i) = p(i) + BX * xi(i)
      end do
      FB=energy(pnew,iPrnt)
      N_Energy=N_Energy+1
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(*,'(a,f18.8,a,f18.8)')'... B point=',BX,' energy=',FB
         write(9,'(a,f18.8,a,f18.8)')'... B point=',BX,' energy=',FB
      end if
      if(FB.lt.FA .and. N_Energy.ge.M_Energy) go to 210
c
c......... calculate the position CX of the 3rd point either as:
c
c  E(x)=E(0)-x*HF+0.5*B*x*x
c
c where x - the coordinate along the direction xi,
c HF = xi*(-g) (direction*force),
c B - parameter defined via the 2nd point BX 
c
c (a) [if the coefficient B is POSITIVE] an expected mimimum of the 
c     porabola:
c                B*(BX*xi)**2 = 2*(FB-FA+BX*HF),
c
c (b) [if B is NEGATIVE, i.e. FB is substantially lower than FA]
c      obtain CX by moving to the right.
c....................................................................
c
      Q=FB-FA+BX*HF
      if(Q.gt.0.0) then
        CX=HF*BX**2/(2*Q)
        if(nid.eq.0.and.iPrnt.ge.3) 
     &       write(9,*)'____> CX = a minimum of porabola'
      else 
        CX=BX+GOLD*(BX-AX)
        if(nid.eq.0.and.iPrnt.ge.3) 
     &       write(9,*)'____> CX = a shift to the right'
      end if
c
c_____________ calculate energy FC in the point CX
c
      do i = 1, n_dfree
         pnew(i) = p(i) + CX * xi(i)
      end do
      FC=energy(pnew,iPrnt)
      N_Energy=N_Energy+1
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(*,'(a,f18.8,a,f18.8)')'... C point=',CX,' energy=',FC
         write(9,'(a,f18.8,a,f18.8)')'... C point=',CX,' energy=',FC
      end if
c
c.......... we won't go further than this
c
      ULIM=BX+GLIMIT*(BX-AX)
c
c.......... set iCase5 to 0 (to be used to monitor the case 5)
c
      iCase5=0     
c
c.................................................................
c.......... beginning of the loop: search for a triple ...........
c.................................................................
c
 1    continue
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(9,'(a12 ,2(f12.7,a1),f12.7,a16)')
     &     'raw triple [',AX,',',BX,',',CX,'] with energies:'
         write(9,'(3(5x,f18.8))') FA,FB,FC
      end if
c
c--------------------------------------------------------------------
c----------------------- check the point CX -------------------------
c--------------------------------------------------------------------
c
c*******CHECK_1
c______ if we went too far downhill, the point CX is accepted
c       as the best one; the triple is not defined. Swap CX and BX in 
c       the case (2) (since FC is the best: FC < FB < FA).
c
      if(CX.gt.ULIM) then
         if(nid.eq.0) then
            write(*,'(a16,f18.8,a9)')'===== CX > ULIM=',ULIM,' <= QUIT!'
            write(9,'(a16,f18.8,a9)')'===== CX > ULIM=',ULIM,' <= QUIT!'
         end if
         if(FC.lt.FB) then
           BX=CX
           FB=FC
         end if
         go to 210
      end if
c
c*******CHECK_2
c.......... iCase5 counts energy calculations in the worst case (5),
c           when FB > FA (AX is always the initial point) and FC > FA.
c           If iCase5=M_Energy, the initial direction xi is thought
c           to be bad and, after restoring the coordinates, we start 
c           again in conjug with the direction along forces.
c           In case that the step was too long, we reduce energy_gain.
c
      if(iCase5.ge.M_Energy) then
         if(FC.lt.FA) then
           BX=CX
           FB=FC
           go to 210
         end if
         if(nid.eq.0) then
            write(*,*)'WARNING! Bad direction (case 5 - too often)!'
            write(9,*)'WARNING! Bad direction (case 5 - too often)!'
         end if
c         energy_gain=energy_gain*0.5
         iReturn=1
         return
      end if
c
c*******CHECK_3
c______ if we have calculated the energy too many times, choose the best
c       point (but necessary better than the initial point) and quit;
c       proceed only if the energy is still higher than that in the 
c       initial point.
c
      if(N_Energy.ge.M_Energy) then
         if(FB.lt.min(FA,FC)) then
           go to 210
         else if(FC.lt.min(FA,FB)) then
           BX=CX
           FB=FC
           go to 210
         end if
      end if
c
c--------------------------------------------------------------------
c----- Consider all possible cases and choose a new point CX if -----
c----- necessary. Note that (because of our choice of CX), CX   -----
c----- is going to be ALWAYS on the right from AX               -----
c--------------------------------------------------------------------
c
      IF(CX.gt.BX) THEN
c
c---------- the point CX is on the right from BX  (i.e. CX is NOT 
c           between AX and BX) and therefore FB is less than FA
c
        if(FC.gt.FB) then
c(1)
c__________ the right triple is [AX,BX,CX]
          if(nid.eq.0.and.iPrnt.ge.3) 
     &          write(9,*)'...(1)... BX Accepted! ....'
          go to 100
        else 
c(2)
c__________ make the "gold" step forward to some another point CX
c           instead and remove a redundant point AX; start again.
          AX=BX
          FA=FB 
          BX=CX 
          FB=FC 
          CX=BX+GOLD*(BX-AX) 
          if(nid.eq.0.and.iPrnt.ge.3) 
     &         write(9,*)'...(2)... Proceeding...'
        end if
c
c---------- the point CX is in between AX and BX
c
      ELSE IF(CX.le.BX) THEN
c(3)
c____________ if FC < min(FA,FB), we'v got the triple [AX,CX,BX]; 
c             swap BX and CX and quit
        if(FC.lt.min(FA,FB)) then
          DUM=BX
          BX=CX
          CX=DUM
          DUM=FB
          FB=FC
          FC=DUM
          if(nid.eq.0.and.iPrnt.ge.3) 
     &         write(9,*) '...(3)... CX Accepted! ....'
          go to  100
c(4)
c____________ FC > FB provided that FB < FA.
c             In this case: move to the RIGHT from BX, dismiss 
c             AX and put all points into the right order; start again.
c
        else if(FA.gt.FB) then 
          AX=CX 
          FA=FC 
          CX=BX+GOLD*(BX-AX) 
          if(nid.eq.0.and.iPrnt.ge.3)  
     &         write(9,*)'...(4)... Proceeding: move to the right ...' 
c(5)
c____________ FC > FA  provided that FB > FA. In this case:
c             move to the LEFT from BX toward AX (keeping still in 
c             between AX and BX) using a porabolic interpolation (the point 
c             AX is the same starting point in this case!), dismiss BX 
c             and put all points into the right order; start again.
c
        else if(FA.le.FB) then
          BX=CX
          FB=FC
          Q=FB-FA+BX*HF
          CX=HF*BX**2/(2*Q)
c         CX=(BX+GOLD*AX)/(1+GOLD)
          iCase5=iCase5+1
          if(nid.eq.0.and.iPrnt.ge.3) 
     &         write(9,*)'...(5)... Proceeding...'
        end if 
      END IF 
c
c________ recalculate the energy in the new point CX
c
      do i = 1, n_dfree 
         pnew(i) = p(i) + CX * xi(i) 
      end do 
      FC=energy(pnew,iPrnt) 
      N_Energy=N_Energy+1 
c
c_____ start again
c
      if(nid.eq.0.and.iPrnt.ge.1) then  
        write(*,'(a,f18.8,a,f18.8)')'... new C point=',CX,' energy=',FC
        write(9,'(a,f18.8,a,f18.8)')'... new C point=',CX,' energy=',FC
      end if 
      go to 1 
c
c===================================================================
c YES! We've got the right triple of points AX,BX,CX which bracket
c the minima somewhere close to BX which has the lowest energy FB.
c===================================================================
c
c_______ try porabolic interpolation and recalculate the energy in
c        the minimum
c
 100  if(N_Energy.ge.M_Energy) go to 210
      R=(BX-AX)*(FB-FC)
      Q=(BX-CX)*(FB-FA)
      if(abs(Q-R).lt.tiny) go to 210
      U=BX-((BX-CX)*Q-(BX-AX)*R)/(2*(Q-R))

      do i = 1, n_dfree
         pnew(i) = p(i) + U * xi(i)
      end do
      FU=energy(pnew,iPrnt)
      N_Energy=N_Energy+1
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(*,'(a29,f18.8,a9,f18.8)')
     &               'Porabolic interpolation is U=',U,' with FU=',FU
         write(9,'(a29,f18.8,a9,f18.8)')
     &               'Porabolic interpolation is U=',U,' with FU=',FU
      end if
c_________ adopt the interpolated value
      if(FU.lt.FB) then
        FB=FU
        BX=U
        if(nid.eq.0.and.iPrnt.ge.1) 
     &       write(9,*)'... The porabolic interpolation adopted! ...'
      else
        if(nid.eq.0.and.iPrnt.ge.1) 
     &        write(9,*)'... Interpolation NOT adopted! ...'
      end if 
c
c===================================================================
c END of the search
c===================================================================
c
 210  energy_best=FB 
      if(nid.eq.0.and.iPrnt.ge.1) then 
         write(*,'(a,e12.6,a,f18.8)') 
     &                    'The best point is BX=',BX,' with FB=',FB
         write(9,'(a,e12.6,a,f18.8)') 
     &                    'The best point is BX=',BX,' with FB=',FB
      end if 
c
c________ move to the final point BX in Optimisation coordinates
c
      do i=1,n_dfree
        pnew(i) = p(i) + BX*xi(i)
      end do
c
c....... recalculate the achieved energy fall to be used on the 
c        next search
c
      Q=FA0-FB
      if(Q.gt.0.0) then
         energy_gain=Q
         if(nid.eq.0) 
     &    write(9,'(a,f18.8)')'___> achieved energy fall = ',energy_gain
      else
         if(nid.eq.0) 
     &    write(9,*)'FATAL in linesearch.f => stop!'
      end if
c
c_________ total number of energy calculations
c
      if(nid.eq.0) then
         write(*,'(a,i5,a,e18.8)')
     &     '==> LineSearch(',N_Energy,') with energy = ',FB
         write(9,'(a,i5,a,e18.8)')
     &     '==> LineSearch(',N_Energy,') with energy = ',FB
      end if
      return
      end



