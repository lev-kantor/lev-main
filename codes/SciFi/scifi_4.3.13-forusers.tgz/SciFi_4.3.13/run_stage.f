      subroutine run_stage(t,is)
c..........................................................
c Run the elementary step  = is
c if_excite  - if .true., excitation signal is applied
c..........................................................
      include 'virtual.inc'
      include 'stages.inc'
      include 'noise.inc'
      integer t,t0
      character cha,cha2*2
      
c[1]........... set all the control variables for the given
c               stage
      Vx=VelocityX(is) 
      Vy=VelocityY(is) 
      NoiseF=if_NoiseF(is)
      NoiseA=if_NoiseA(is)
      ADC=if_ADC(is)
      if(ADC) DFC=DFC_(is)
      AGC=if_AGC(is)
      if(AGC) A0=A0_(is)
      excite=if_Excite(is)
      write(9,'(/a,i3,a/)')'>>>>>>>>>>>>>>>>>>>>>> elementary stage ',
     &     is,' <<<<<<<<<<<<<<<<<<<<<<'
      write(9,'(a,2(e12.6,a))') 
     &     'Entered at (X,Y) = (',XY(1),',',XY(2),')'
      write(9,'(a,l1,x,l1)') 'Noise (F,A) = ',NoiseF,NoiseA
      write(9,'(2(a,e12.6))') 'Velocities: Vx = ',Vx,' and Vy = ',Vy
      if(ADC) then
         write(9,'(a,f10.5,a)') 
     &        'ADC is ON: freq. shift DEF is kept near ',DFC,' Hz'
         write(9,'(a,f10.5,a)')'Currently DEF = ',DEF,' Hz'
      else
         write(9,'(a,f10.5,a)') 
     &        'ADC is OFF: height is kept at DISTA = ',DISTA*m_A,' A'
      end if
      if(AGC) then
         write(9,'(a,f10.5,a)') 'AGC is ON: oscillation amplitude '//
     &        'MODUL is kept near ',MODUL*m_A,' A'
         write(9,'(a,e12.6,a)')'Currently R = ',R,' N'
      else
         write(9,'(a,e12.6)') 
     &        'AGC is OFF: excitation amplitude is kept at R = ',R
      end if
      if(excite) write(9,'(a)') 'The EXCITATION signal IS added'
      if(if_tipf(is)) write(9,'(a)') 'The TIP force IS added'
      if(if_Prt(is)) then
         write(9,'(a,i5,a)') 
     &        'Debugging is ON, every ',HowOften(is),' iterations'
      else
         write(9,'(a)') 'Debugging is OFF'
      end if

c[2]........... run the complete simulation; 
c               printout every tRes iteration

c________________ heading for the debug printout
      if(is.eq.1 .and. if_prt(is)) then
         open(17,file='stage1.out',status='unknown',form='formatted')
         write(17,'(a)') '# a(t) - acceleration at timestep t (m/s^2)'
         write(17,'(a)') '# v(t) - velocity at timestep t (m/s)'
         write(17,'(a)') '# DEF    - frequency shift (Hz)'
         write(17,'(a)') '# '
         write(17,'(a)') '#      t        z(t)         a(t)       '//
     &        '   v(t)       DEF            sinPLL     A(t)'
      else if(is.eq.2 .and. if_prt(is)) then
         open(17,file='stage2.out',status='unknown',form='formatted')
         write(17,'(a)') '# excite - excitation signal at timestep t'
         write(17,'(a)') '# DEF    - frequency shift (Hz)'
         write(17,'(a)') '# '
         write(17,'(a)')'#      t        z(t)        excite        DEF'
      else if(if_prt(is)) then
         if(is.lt.10) then
            write(cha,'(i1)') is
            open(17,file='stage'//cha//'.out',status='unknown',
     &                                               form='formatted')
         else if(is.lt.100) then
            write(cha2,'(i2)') is
            open(17,file='stage'//cha2//'.out',status='unknown',
     &                                               form='formatted')
         end if
         write(17,'(a)') '# excite - excitation signal at timestep t'
         write(17,'(a)') '# DEF    - frequency shift (Hz)'
         write(17,'(a)') '# ds     - distance of closest approach (A)' 
         write(17,'(a)') '# dist   - actual distance at time t (A)' 
         write(17,'(a)') '# ftip   - force (eV/A)'
         write(17,'(a)') '# A      - oscillation amplitude '
         write(17,'(a)') '# '
         write(17,'(a)') '#    t          z(t)        excite    '//
     &        '     DEF         ds          ftip     dist     A'
      end if
 
c__________________ do the calculation

      t0=t
      write(*,'(/a,i3,a)')'......... entering stage ',is,' ..........'
      write(*,'(4(a,e12.6))')
     & ' with: R= ',R,', MODUL= ',MODUL,', DISTA= ',DISTA,', DEF= ',DEF 
      if(Finish_St(is).eq.' time') then
         write(9,'(a,f10.5,a)')
     &        'Control: via time => ',Stage_Time(is),' s'
         do while (t*dt .lt. Stage_Time(is))
            call integrate_all(t,if_tipf(is),if_Prt(is),HowOften(is),is)
         end do

      else if(Finish_St(is).eq.'freqs' .and. if_ADC(is)) then
         write(9,'(a,f10.5,a)') 
     &        'Control: via frequency shift target at ',DFC,' Hz'
         do while (abs(DEF-DFC) .gt. 0.5)
            call integrate_all(t,if_tipf(is),if_Prt(is),HowOften(is),is)
         end do

      else if(Finish_St(is).eq.'amplt' .and. if_AGC(is)) then
         write(9,'(a,f10.5,a)') 
     &     'Control: via oscillation amplitude target at ',A0*m_A,' A'
         do while (abs(MODUL-A0) .gt. 0.1/m_A)
            call integrate_all(t,if_tipf(is),if_Prt(is),HowOften(is),is)
         end do
      end if
      write(*,'(a,i3,a/)')'......... finished stage ',is,' ..........'
      if(if_prt(is)) close (17)
      return
      end

