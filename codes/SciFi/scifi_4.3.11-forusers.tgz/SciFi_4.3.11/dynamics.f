
      subroutine molecular_dynamics(iPrnt,sunit,tunit,funit_z,funit_x,
     &     funit_y)
c.................................................................
c     SCIFI subroutine to carry out a molecular dynamics          .
c     simulation on the system with the specified control        .
c     parameters.                                                .
c                                                                .
c     uses gradients3 and energy                                 .
c.................................................................
c Units: forces - a.u. (force)
c        length - a.u. (length)
c        energy - a.u. (energy)
c        time   - fs
c      velocity - a.u.(length) /fs
c.................................................................
      include 'shell.inc'
      double precision chi,tipforce_z,sh_temp
      double precision tipforce_x, tipforce_y
      double precision force_keep(isaved_rst,3)
      double precision iRx2(N0CH),iRy2(N0CH),iRz2(N0CH)
      double precision z_tip_stat(N0CH)
      integer n_dfree_temp,core_dfree_temp
      integer n_int,n_trj,n_rst
      integer sunit,tunit,funit_z,funit_x,funit_y
      real ttime,tarray(2),s_time
      logical t_shell_ref(N0KD)
      dimension p(N0FR),g(N0FR)
c#if defined(MPI)            
c      integer status(MPI_STATUS_SIZE)
c#endif
      Yes_Dump = .true.

      n_int = 1
      n_trj = 1
      n_rst = 1
      chi = 0.0
      nstep = 0
      idum = -5

c_____filling in number of frames for movie

      if(nid.eq.0) then

c         write(22,*) int(numstep0s/traj_print)

         write(*,*)'  - starting MD simulation -'

         ttime = dtime(tarray)
         
         call trajectory(tunit)
      end if

c_____saving original z coordinates for tip oscillation

      if(dynamic_tip) then
         do i=1,Natom
            z_tip_stat(i) = z(i)
            if(Shell_Ref(ISRT(i))) then
               j = iShell(i)
               z_tip_stat(j) = z(j)
            end if
         end do
      end if

      if(dshell_model.eq.1) then
c_____save flags in buffer
         do k=1,Natom
            iRx2(k) = iRx(k)
            iRy2(k) = iRy(k)
            iRz2(k) = iRz(k)
         end do
      end if
      n_dfree_temp = n_dfree
      core_dfree_temp = n_pos_cor

c*****starting MD*****

      j0=numsteps/10
      if(j0.eq.0) j0=1
      DO nstep=1,numsteps
         
         if(nstep/j0*j0.eq.nstep) 
     &        write(*,'(a,i3,a)')'Done ',nstep/j0*10,'%'

c-----relax shells (if wanted)

         if(dshell_model.eq.1) then 
c_____freeze all cores
            do k=1,Natom
               iRx(k) = 0
               iRy(k) = 0
               iRz(k) = 0
            end do
            n_dfree = n_dfree_temp - core_dfree_temp
            n_pos_cor = 0
c_____relax all shells
            call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     ,        n_pos_cor,iRx,iRy,iRz)
            en = energy(p,iPrnt)
            call gradients(p,g,iPrnt)
            call relax_all(p,g,en,energy_gain,iPrnt)
            write(*,*)' relaxed timestep : ',nstep
            call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,           n_pos_cor,iRx,iRy,iRz)
c_____restore relaxation flags
            do k=1,Natom
               iRx(k) = iRx2(k)
               iRy(k) = iRy2(k)
               iRz(k) = iRz2(k)
            end do
            n_dfree = n_dfree_temp
            n_pos_cor = core_dfree_temp
         end if

c-----calculate gradients (= -forces) on cores and shells

         call gradients3(0,.false.)

c_____remove all shells for the integration
         if(dshell_model.eq.1) then
            do k=Natom+1,Ncharge
               iRx(k) = 0
               iRy(k) = 0
               iRz(k) = 0
            end do
         end if

c-----integrate equations of motion

         sh_temp=0.0
         if(ialgorithm.eq.0) then
            call nve_vl(sh_temp)
         else if(ialgorithm.eq.1) then
            call nvt_gauss()
         else if(ialgorithm.eq.2) then
            call nvt_ber()
         else if(ialgorithm.eq.3) then
            call nvt_hover(chi)
         else if(ialgorithm.eq.4) then
            call nve_stoc()
         end if
         
c-----moving tip
         if(dynamic_tip) then
            call tipdynamic(z_tip_stat)
         end if
      
         if(nid.eq.0) then
c-----calculate total lateral force on the tip (due to relaxed atoms)
            tipforce_z = 0.0
            tipforce_x = 0.0
            tipforce_y = 0.0
            
            do k=1,Natom
               if(id2(k).le.3) then
c              if(id(k).eq.'ta'.or.id(k).eq.'tb'.or.id(k).eq.'ft') then
c_____forces on cores
                  tipforce_z = tipforce_z - fz(k)
                  if(do_lat) then
                     tipforce_x = tipforce_x - fx(k)
                     tipforce_y = tipforce_y - fy(k)
                  end if
c_____forces on shells
                  if(Shell_Ref(ISRT(k))) then
                     j = iShell(k)
                     if(iRz(j).ne.0) then
                        tipforce_z = tipforce_z - fz(j)
                        if(do_lat) then
                           tipforce_x = tipforce_x - fx(j)
                           tipforce_y = tipforce_y - fy(j)
                        end if
                     end if
                  end if
               end if
            end do
         end if
         
c_____replace all shells for relaxation and energy
         if(dshell_model.eq.1) then  
            do k=Natom+1,Ncharge
               iRx(k) = iRx2(k)
               iRy(k) = iRy2(k)
               iRz(k) = iRz2(k)
            end do      
         end if

         if(nid.eq.0) then

c-----print system information to file

            if(nstep.eq.(stat_print*n_int)) then
               n_int=n_int + 1
               call statistics(sunit,iPrnt,sh_temp)
            end if

c-----print trajectory information to file

            if(nstep.eq.(traj_print*n_trj)) then
               call trajectory(tunit)
               n_trj=n_trj + 1
            end if

c-----saving restart file every isaved_rst timesteps

            if(update_RST) then
               ind=nstep - (n_rst-1)*isaved_rst
               if(do_lat) then
                  force_keep(ind,1) = tipforce_x
                  force_keep(ind,2) = tipforce_y
               end if
               force_keep(ind,3) = tipforce_z
               if(nstep.eq.(isaved_rst*n_rst)) then
                  if(do_lat) then
                     write(funit_x,'(f20.10)') 
     &                    (force_keep(jj,1)*au_evA,jj=1,isaved_rst)
                     write(funit_y,'(f20.10)') 
     &                    (force_keep(jj,2)*au_evA,jj=1,isaved_rst)
                  end if
                  write(funit_z,'(f20.10)') 
     &                 (force_keep(jj,3)*au_evA,jj=1,isaved_rst)
                  call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     &                 n_pos_cor,iRx,iRy,iRz)
                  if(Yes_Dump) call do_restart(p,iPrnt,.true.)
                  n_rst=n_rst + 1
               end if
            else
               if(do_lat) then
                  write(funit_x,'(f20.10)')tipforce_x*au_evA
                  write(funit_y,'(f20.10)')tipforce_y*au_evA
               end if
               write(funit_z,'(f20.10)')tipforce_z*au_evA
            end if
         end if

      END DO

c*****  end MD simulation *****

c-----saving restart file
      if(nid.eq.0) then
         call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     ,        n_pos_cor,iRx,iRy,iRz)
         
         nstep = nstep - 1
         
         if(Yes_Dump) call do_restart(p,iPrnt,.true.)
         write(*,*)' - MD simulation completed'

c         s_time = dtime(tarray)

c         if(s_time.gt.60.0) then
c            if(s_time.gt.3600.0) then
c               if(s_time.gt.86400.0) then
c                  
c                  d_time = int(s_time/86400)
c                  h_time = int(s_time/86400 - d_time)*3600)
c                  m_time = int(
c 
c            m_time = int(s_time/60)
c            s_time = (s_time/60 - int(s_time/60))*60
c         end if

         write(*,*)' - cpu time elapsed : ',dtime(tarray)
      end if


      end


      subroutine fill_pmass(iPrnt)
c.................................................................
c     subroutine to get the mass of each individual particle     .
c     from the list of species mass                              .
c.................................................................
      include 'shell.inc'
      
c-----loop over all atoms
      do i=1,Natom
         j = iShell(i)
c-----then search the list of species mass
         do ii=1,KINDS
            if(ii.eq.ISRT(i)) then
               pmass(i) = smass(ii,1)
               if(Shell_Ref(ISRT(i))) pmass(j) = smass(ii,2)
            end if
         end do
      end do

      end



      subroutine initvel(iPrnt)
c..................................................................
c     subroutine to initialise the velocities of all non-frozen   .
c     atoms based on the desired system temperature, dtemp.       .
c                                                                 .
c     The subroutine gives atoms uniform energies in random       .
c     directions  - and  ensures that the total velocity and      .
c     angular momentum are zero.                                  .
c..................................................................

c!!!!! - This subroutine requires the f90 intrinsic RANDOM_NUMBER
c!!!!! - If compiled on f77 an alternative must be provided

      include 'shell.inc'
      double precision velmag,en,rand,theta,phi
      double precision x_tot,y_tot,z_tot,factor,tot_mass
      double precision mx_tot,my_tot,mz_tot,cmx,cmy,cmz
      double precision r2,rot_inertia(3,3),corx,cory,corz
      double precision inv_rot_inertia(3,3)
      double precision tmass(N0LT)
      real ran2
      integer idum3

      tot_mass = 0.0
      non_frozen = 0
      x_tot = 0.0
      y_tot = 0.0
      z_tot = 0.0
      cmx = 0.0
      cmy = 0.0
      cmz = 0.0
      idum3 = -6

c-----initialising velocities (cores and shells)

      do i=1,Ncharge

         vx(i) = 0.0
         vy(i) = 0.0
         vz(i) = 0.0

      end do

c-----initialising rotational inertia matrix

      do i=1,3

         rot_inertia(i,1) = 0.0
         rot_inertia(i,2) = 0.0
         rot_inertia(i,3) = 0.0

      end do

c-----creating an array for the total mass of the atoms
c     (core and shell)

c_____each atom will be considered as a single core when calculating
c     initial velocities, with separate shell and core velocities 
c     set equal at the end of the routine

      do i=1,Natom
         tmass(i) = pmass(i)
         if(Shell_Ref(ISRT(i))) then
            j = iShell(i)
            tmass(i) = tmass(i) + pmass(j)
         end if
      end do


c-----calculating the average energy per atom for a given temperature

      en = dtemp * PRM_KB * 3

c-----generating random unit vectors

      do i=1,Natom
            velmag = sqrt(en / tmass(i))*md_unit
c-----generating random theta and phi
            phi = ran2(idum3) * 3.141592654
            theta = ran2(idum3) * 1.570796327

         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = velmag * sin(theta) * cos(phi)
            vy(i) = velmag * sin(theta) * sin(phi)
            vz(i) = velmag * cos(theta)
            non_frozen = non_frozen + 1
         end if

      end do

c-----zeroing centre of mass motion

      do i=1,Natom
         x_tot = x_tot + vx(i)*tmass(i)
         y_tot = y_tot + vy(i)*tmass(i)
         z_tot = z_tot + vz(i)*tmass(i)
         tot_mass = tot_mass + tmass(i)         
      end do

c-----setting total velocity to zero

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = vx(i) - (x_tot/tot_mass)
            vy(i) = vy(i) - (y_tot/tot_mass)
            vz(i) = vz(i) - (z_tot/tot_mass)
         end if
      end do

c-----finding the centre of mass of the system

      sumx = 0.0
      sumy = 0.0
      sumz = 0.0

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and.iRz(i).eq.1) then
            sumx = sumx + x(i)*tmass(i)
            sumy = sumy + y(i)*tmass(i)   
            sumz = sumz + z(i)*tmass(i)
         end if
      end do

      cmx = sumx/tot_mass
      cmy = sumy/tot_mass
      cmz = sumz/tot_mass

c-----changing into centre of mass coordinates

      do i=1,Natom
         x(i) = x(i) - cmx
         y(i) = y(i) - cmy
         z(i) = z(i) - cmz
      end do

c-----calculating total angular momentum

      mx_tot = 0.0
      my_tot = 0.0
      mz_tot = 0.0

      do i=1,Natom

         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then 

            mx_tot = mx_tot + tmass(i)*(y(i)*vz(i) - z(i)*vy(i))
            my_tot = my_tot - tmass(i)*(x(i)*vx(i) - z(i)*vx(i))
            mz_tot = mz_tot + tmass(i)*(x(i)*vy(i) - y(i)*vx(i))

c-----calculating rotational inertia matrix

            r2 = x(i)*x(i) + y(i)*y(i) + z(i)*z(i)
            rot_inertia(1,1)=rot_inertia(1,1)+tmass(i)*(x(i)*x(i)-r2)
            rot_inertia(1,2)=rot_inertia(1,2)+tmass(i)*x(i)*y(i)
            rot_inertia(1,3)=rot_inertia(1,3)+tmass(i)*x(i)*z(i)
            rot_inertia(2,1)=rot_inertia(2,1)+tmass(i)*y(i)*x(i)
            rot_inertia(2,2)=rot_inertia(2,2)+tmass(i)*(y(i)*y(i)-r2)
            rot_inertia(2,3)=rot_inertia(2,3)+tmass(i)*y(i)*z(i)
            rot_inertia(3,1)=rot_inertia(3,1)+tmass(i)*z(i)*x(i)
            rot_inertia(3,2)=rot_inertia(3,2)+tmass(i)*z(i)*y(i)
            rot_inertia(3,3)=rot_inertia(3,3)+tmass(i)*(z(i)*z(i)-r2)

         end if

      end do

c-----inverting the rotaitional inertia matrix

      call invert(rot_inertia,inv_rot_inertia)
         
c-----calculating correction to the angular momentum

      corx = mx_tot*inv_rot_inertia(1,1)
     &     + my_tot*inv_rot_inertia(1,2)
     &     + mz_tot*inv_rot_inertia(1,3)
      cory = mx_tot*inv_rot_inertia(2,1)
     &     + my_tot*inv_rot_inertia(2,2)
     &     + mz_tot*inv_rot_inertia(2,3)
      corz = mx_tot*inv_rot_inertia(3,1)
     &     + my_tot*inv_rot_inertia(3,2)
     &     + mz_tot*inv_rot_inertia(3,3)

c-----correcting velocities and calculating the temperature

      temp = 0.0

      do i=1,Natom

         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = vx(i) + (cory*z(i) - corz*y(i))
            vy(i) = vy(i) - (corx*z(i) - corz*x(i))
            vz(i) = vz(i) + (corx*y(i) - cory*x(i))
            temp = temp + (tmass(i) *
     &           (vx(i)*vx(i) + vy(i)*vy(i) + vz(i)*vz(i))/
     &           (PRM_KB * 3 * non_frozen)) * md3_unit
         end if

      end do

c-----returning the coordinate system to the original origin

      do i=1,Natom
         x(i) = x(i) + cmx
         y(i) = y(i) + cmy
         z(i) = z(i) + cmz
      end do

c-----scalling velocities to exactly dtemp

      factor = sqrt(dtemp/temp)

      temp = 0.0
      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = vx(i) * factor
            vy(i) = vy(i) * factor
            vz(i) = vz(i) * factor

c-----if atoms have shells, match velocities

            if(Shell_Ref(ISRT(i))) then
               j = iShell(i)
               vx(j) = vx(i)
               vy(j) = vy(i)
               vz(j) = vz(i)
            end if
            
            temp = temp + (tmass(i) *
     &           (vx(i)*vx(i) + vy(i)*vy(i) + vz(i)*vz(i))/
     &           (PRM_KB * 3 * non_frozen)) * md3_unit
         end if

      end do

      end




      subroutine statistics(sunit,iPrnt,sh_temp)
c.........................................................................
c     subroutine to print system information to sunit when called -      .
c     prints timestep,time,total energy,K.E.,P.E. and temperature        .
c.........................................................................
      include 'shell.inc'
      double precision ken,p_energy,ten,sh_temp
      integer sunit
      dimension p(N0FR)

      call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     ,     n_pos_cor,iRx,iRy,iRz)
      p_energy = energy(p,iPrnt)      

c-----calculating kinetic energy of system

      ken = (temp+sh_temp) * (PRM_KB * 3 * non_frozen) / 2
      ten = ken + p_energy

c-----writing to sunit

      write(sunit,'(i8,3f20.5,3f10.2)')nstep,ten,p_energy,ken,temp,
     &     sh_temp,sh_temp+temp

      end


      subroutine trajectory(tunit)
c...........................................................................
c     subroutine to write trajectory data to file based on the trj_fmt key .
c                                                                          .
c     traj_fmt = 0   -> do not bother                                      .
c     traj_fmt = 2   -> xyz movie                                          .
c     traj_fmt = 1   -> ymol movie                                         .
c     traj_fmt = 3   -> HISTORY style with positions, velocities and forces.
c     traj_fmt = 4   -> HISTORY style with positions and velocities        .
c...........................................................................
      include 'shell.inc'
      integer tunit

      if(traj_fmt.eq.0) then
         return
      else if(traj_fmt.eq.1) then
         write(tunit,'(i4)') Natom

         do i=1,Natom
            write(tunit,'(i4,3f12.5)') NATM(ISRT(i)),x(i)*au_A,
     &           y(i)*au_A,z(i)*au_A
         end do

      else if(traj_fmt.eq.2) then
         write(tunit,'(i4/)') Natom
         do i=1,Natom
            write(tunit,'(a3,3f10.5)') Species(ISRT(i)),
     &           x(i)*au_A,y(i)*au_A,z(i)*au_A
         end do
      else if(traj_fmt.eq.3) then
         write(tunit,'(a8,i8)') 'timestep',nstep
         do i=1,Natom
            write(tunit,'(a4,i8)')  Species(ISRT(i)),i
            write(tunit,'(3f10.5)') x(i)*au_A,y(i)*au_A,z(i)*au_A
            write(tunit,'(3(e14.8,x))') 
     &           vx(i)*aufs_Aps,vy(i)*aufs_Aps,vz(i)*aufs_Aps
            write(tunit,'(3f10.5)')
     &           fx(i)*au_evA,fy(i)*au_evA,fz(i)*au_evA
         end do
         write(tunit,'(a8,i8)') 'timestep',nstep
      else if(traj_fmt.eq.4) then
         do i=1,Natom
            write(tunit,'(a4,i8)')  Species(ISRT(i)),i
            write(tunit,'(3f10.5)') x(i)*au_A,y(i)*au_A,z(i)*au_A
            write(tunit,'(3(e14.8,x))') 
     &           vx(i)*aufs_Aps,vy(i)*aufs_Aps,vz(i)*aufs_Aps
         end do         
      end if
      end


      subroutine invert(in,out)
c............................................................................
c     subroutine to invert a 3x3 matrix - supplied as in and returned       .
c     as out                                                                .
c............................................................................
      
      double precision det
      double precision in(3,3),out(3,3)


c-----calculate adjoint
      out(1,1)=in(2,2)*in(3,3)-in(2,3)*in(3,2)
      out(1,2)=in(1,3)*in(3,2)-in(1,2)*in(3,3)
      out(1,3)=in(1,2)*in(2,3)-in(1,3)*in(2,2)
      out(2,1)=in(2,3)*in(3,1)-in(2,1)*in(3,3)
      out(2,2)=in(1,1)*in(3,3)-in(1,3)*in(3,1)
      out(2,3)=in(1,3)*in(2,1)-in(1,1)*in(2,3)
      out(3,1)=in(2,1)*in(3,2)-in(2,2)*in(3,1)
      out(3,2)=in(1,2)*in(3,1)-in(1,1)*in(3,2)
      out(3,3)=in(1,1)*in(2,2)-in(1,2)*in(2,1)

c-----determinant

      det=in(1,1)*out(1,1)+in(2,1)*out(1,2)+in(3,1)*out(1,3)

c-----calculate inverse matrix

      out(1,1) = out(1,1) / det
      out(1,2) = out(1,2) / det
      out(1,3) = out(1,3) / det
      out(2,1) = out(2,1) / det
      out(2,2) = out(2,2) / det
      out(2,3) = out(2,3) / det
      out(3,1) = out(3,1) / det
      out(3,2) = out(3,2) / det
      out(3,3) = out(3,3) / det

      end

      subroutine tipdynamic(z_tip_stat)
c..........................................................
c     SCIFI subroutine to allow tip movement during a MD  .
c     simulation.  All of the frozen atoms in the tip are .
c     incrmentally moved according to the parameters      .
c     supplied in the input file.                         .
c..........................................................
      include 'shell.inc'
      double precision z_tip_stat(N0CH)

      do i=1,Natom
         if(id2(i).le.2) then
c        if(id(i).eq.'ft' .or. id(i).eq.'tb') then
            x(i) = x(i) + tstep*x_scan_speed
            y(i) = y(i) + tstep*y_scan_speed
            z(i) = z_tip_stat(i) + t_amplitude
     &           *sin((6.28318531*nstep*tstep)/t_period)

            if(Shell_Ref(ISRT(i))) then
               j = iShell(i)
               x(j) = x(j) + tstep*x_scan_speed
               y(j) = y(j) + tstep*y_scan_speed
               z(j) = z_tip_stat(j) + t_amplitude
     &              *sin((6.28318531*nstep*tstep)/t_period)                
            end if
         end if
      end do
      if(Do_Image) then
         R_Sph(1)=R_Sph(1)+tstep*x_scan_speed*au_A
         R_Sph(2)=R_Sph(2)+tstep*x_scan_speed*au_A
         Rz=Rz+t_amplitude
     &              *sin((6.28318531*nstep*tstep)/t_period)*au_A
      end if
      end
