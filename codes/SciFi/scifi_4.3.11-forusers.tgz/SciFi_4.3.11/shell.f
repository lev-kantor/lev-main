        program SHELL
c.....................................................................
      include 'tersoff.inc'
      include 'share.inc'


      logical restart,virtual_AFM
      integer sunit,tunit,funit_z,funit_x,funit_y
c p() - current vector of all active coordinates
c g() - current vector of all active gradients
      dimension p(N0FR),g(N0FR),tipf(3)
      character Line*120
      integer LinEnd(30),LinPos(30),NumLin

c.....initialising MPI






      nid = 0
      noprocs = 1


c..... performing input and system initialisation on single processor

      IF(nid.eq.0) THEN

         restart = .false.

c......... get job name + help

         i0=iargc()
         if(i0.eq.0) then
            write(*,'(a)') 
     &           '***    Usage: shellm <filename> [restart]  ****'
            write(*,'(a)') 
     &           '***   see manual file for further details  ****'
            go to 90
         else
            call getarg(1,FilNam)
            if(i0.gt.1) then
               call getarg(2,line)
               if(line.eq.'restart') restart = .true.
            end if
         end if
         i0=INDEX(FilNam ,'.')
         if(i0.ne.0) FilNam = FilNam(:i0-1)
         call right(FilNam,22,leng)

         if(noprocs.eq.1) then
            write(*,*) 'SCIFI+vAFM  - running on 1 processor'
         else
            write(*,'(a32,i,a11)')'SCIFI+vAFM  - running on '
     &           ,noprocs,' processors'
         end if

c
c .............. open files...........................................
C.......... Open file 9 for listing
         open (9,FILE=FilNam(leng:)//'.OUT',status='unknown')

c............................................................
c............. WELCOME message...............................
c............................................................
         call hat()
c
c.......... read data from the input: if restart file exists,
c treat it as the input and restart
c
         if(restart) then
            write(*,'(a)')'... opening as input '//FilNam(leng:)//'.RST'
            open(1,FILE=FilNam(leng:)//'.RST',status='old',err=102)
            write(*,'(a)')'... okay, restart file exists'
         else
            write(*,'(a)')'... opening as input '//FilNam(leng:)//'.INN'
            open(1,FILE=FilNam(leng:)//'.INN',status='old',err=102)
         end if

c_______________ reading in SCI-FI data
         call Inval(1,KodErr,restart,iPrnt)

c_______________ reading in the VIRTUAL AFM data
         call Inval_vAFM(1,virtual_AFM)
         close(1)

c_________________ deciding what to do

         if(KodErr.eq.1.and.(.not.virtual_AFM)) then
            write(*,*)'FATAL ERROR in the input file! Full STOP!'
            go to 90
         else if(KodErr.eq.1) then
            write(*,*)'ERROR in the SCI-FI input file! Only vAFM!'
            if(.not.scifi_and_vafm) call do_VirtualAFM()
            go to 90
         else if(.not.virtual_AFM) then
            write(*,*)'ERROR in the vAFM input file! Only SCI-FI!'
            scifi_and_vafm=.false.
         else
            write(*,*)'>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<'
            write(*,*)'>>>>>> Running SCI-FI and vAFM together! <<<<<<<'
            write(*,*)'>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<'
            dynamic_tip=.false.
            if(i_atom_sphere.gt.Natom.or.id(i_atom_sphere).ne.'ft') then
               write(*,'(a)')
     & 'ERROR in specifying atomic number w.r.t. vdW sphere'
               write(9,'(a)')
     & 'ERROR in specifying atomic number w.r.t. vdW sphere'
               go to 90
            end if
         end if

c-----setting integer ids

         do i=1,N0CH
            if(id(i).eq.'ft') then
               id2(i) = 1
            else if(id(i).eq.'tb') then
               id2(i) = 2
            else if(id(i).eq.'ta') then
               id2(i) = 3
            else if(id(i).eq.'ca') then
               id2(i) = 4
            else if(id(i).eq.'cb') then
               id2(i) = 5
            else
               id2(i) = 0
            end if
         end do

c-----calculating the loop interval for individual processors
         if(mod(Natom,noprocs).ne.0) then
            do i=0,noprocs-1
               if(i.ge.1) then
                  n_interval(i) = int(Natom/(noprocs))+1+n_interval(i-1)
               else
                  n_interval(i) = 0
               end if
            end do
            n_interval(noprocs) = Natom - (noprocs-1)*n_interval(1) +
     & n_interval(noprocs-1)
         else
            do i=0,noprocs
               if(i.ge.1) then
                  n_interval(i) = int(Natom/noprocs)+n_interval(i-1)
               else
                  n_interval(i) = 0
               end if
            end do
         end if

         if(do_test_input) go to 90

      END IF

      if(nid.ne.0) iPrnt=0

      write(9,*) 'for nid = ',nid,' we have atoms: ',
     , n_interval(nid)+1,n_interval(nid+1)

c.....broadcast all input data to all processors





c
c..........................................................................
c............ first calculation of energy and gradients ...................
c..........................................................................
c

      call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

      if(Yes_check_Central) then
         call do_restart(p,iPrnt,.true.)
         go to 90
      end if
      en = energy(p,iPrnt)
      call gradients(p,g,iPrnt)
c
c..........................................................................
c............... TESTS ....................................................
c..........................................................................
c
c............... test energy along a single direction

      if(do_test_dir) then
         if(dir_num.gt.n_pos_cor) then
            if(nid.eq.0)
     & write(*,*) 'ERROR! Wrong degree of freedom number!'
            go to 90
         end if
         call test_direction(p,g,iPrnt)
         go to 90
      end if
c
c............... test forces on atoms
      if(do_test) then
         call test_forces(p,g,iPrnt)
         go to 90
      end if
c
c............... test force on the tip along direction
      if(do_test_tip .and. Yes_Tip) then
         call test_tip_force(p,g,en,iPrnt)
         if(write_force.or.read_force) close (4)
         go to 90
      end if
      
c
c.........................................................................
c............ Open files .................................................
c.........................................................................
c
c...... files for tip forces
      if(nid.eq.0) then
         funit_z = 23
         funit_x = 24
         funit_y = 25
         open(23,FILE=FilNam(leng:)//'.TFZ',STATUS='unknown')
         tipf(1)=0.0
         tipf(2)=0.0
         if(do_lat) then
            open(24,FILE=FilNam(leng:)//'.TFX',STATUS='unknown')
            open(25,FILE=FilNam(leng:)//'.TFY',STATUS='unknown')
         end if

c....... files for energies and geometries
         sunit = 21
         tunit = 22
         open(21,FILE=FilNam(leng:)//'.STS',STATUS='unknown')
         open(22,FILE=FilNam(leng:)//'_TRJ.xyz',STATUS='unknown')
      end if
c
c...............................................................
c............ Molecular Dynamics run ...........................
c...............................................................
c

      if(do_md) then
c------output for molecular dynamics

c-----initialising velocities if vel_key = 0
         if(vel_key.eq.0) then
            call initvel(iPrnt)
         else if(vel_key.eq.1) then
            non_frozen = 0
            do jj=1,Natom
               if(iRx(jj).eq.1.and.iRy(jj).eq.1.and.iRz(jj).eq.1)then
                  non_frozen = non_frozen + 1
               end if
            end do
         end if

c-----starting MD simulation

         call molecular_dynamics(iPrnt,sunit,tunit,funit_z,funit_x,
     & funit_y)

         if(nid.eq.0) then
            close (21)
            close (22)
            close (23)
         end if

         go to 90
      end if
c
c...............................................................
c............ relaxation: BFGS or CG ...........................
c...............................................................
c

      if(.not.do_md) then

c
c........... open file=name.31 if write_en_frc=.true.
         if(nid.eq.0 .and. write_en_frc)
     & open (31,FILE=FilNam(leng:)//'.31',status='unknown')

         Yes_Dump=.true.
         if(.not.update_RST) Yes_Dump=.false.
         call relax_all(p,g,en,energy_gain,iPrnt)

c
c............. save restart file
         if(nid.eq.0) then

c            if(Yes_Dump .and. .not.(scan.and.finished)) then
c               call do_restart(p,iPrnt,.true.)
c            else if(scan.and.finished) then
c               call do_restart(p,iPrnt,.false.)
c            else if(finished .and. (.not.scan)) then
c               call do_restart(p,iPrnt,.true.)
c            end if
            call do_restart(p,iPrnt,.true.)

c............. do g98 file with all charges for Gaussian98
            if(write_g98) call do_for_g98(p,iPrnt)
c
c............. calculate QC-related energy
            if(exist_QC) en1 = energy_qmc(p,iPrnt)
c
c............. do xyz files for XMOL
c if(write_xyz) then
            if(iPrnt.ge.8) then
               write(*,*)
     & '... opening as output '//FilNam(leng:)//'_core.xyz'
               write(*,*)
     & '... opening as output '//FilNam(leng:)//'_shll.xyz'
            end if
            open(11,FILE=FilNam(leng:)//'_core.xyz',status='unknown')
            open(12,FILE=FilNam(leng:)//'_shll.xyz',status='unknown')
            if(.not.dynamic_tip) call do_xyz(p,iPrnt)
c end if
         end if

c............. force on the tip
         if(Yes_Tip) then
            call do_tip_force(p,g,tipf(1),tipf(2),tipf(3),iPrnt)
            if(nid.eq.0 .and. write_force.or.read_force) close (4)
         end if
c
c............. scan in a chosen direction
         if(dynamic_tip) then
            call scan_surf(p,g,en,tipf,iPrnt)
         else if(virtual_AFM) then
            call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)
            call do_VirtualAFM()
         end if

      end if
c
c........... stop
c
 90   continue




      stop 0
c
c...........................................................................
c......... ERRORS ..........................................................
c...........................................................................
c
 102  if(nid.eq.0) then
         if(restart) then
            write(*,*)
     & 'FATAL! File '//FilNam(leng:)//'.RST does not exist!'
         else
            write(*,*)
     & 'FATAL! File '//FilNam(leng:)//'.INN does not exist!'
         end if
      end if



      stop
      end

      subroutine relax_all(p,g,en,energy_gain,iPrnt)
c...............................................................
c............ relaxation: BFGS or CG ...........................
c...............................................................
c INPUT:
c p - initial geometry (1-dim)
c g - initial gradients at that geometry (1-dim)
c OUTPUT:
c p - final geometry (1-dim)
c g - final gradients at that geometry (1-dim)
c...............................................................
      include 'shell.inc'
      dimension p(N0FR),g(N0FR)
      ishake=0
      finished=.false.
 1    if(max_opt.gt.0) then
         if(bfgs .and. (.not.cg)) then
            call do_bfgs(p,en,g,e_last_gain,iPrnt,imf)
         else if(bfgs .and. cg) then
            max_opt1=max_opt
            energy_gain=es_tol
            max_opt=3
            call do_conjug(p,en,g,energy_gain,iPrnt,imf)
            max_opt=max_opt1
            call do_bfgs(p,en,g,e_last_gain,iPrnt,imf)
         else if(cg .and. (.not.bfgs)) then
            energy_gain=es_tol
            call do_conjug(p,en,g,energy_gain,iPrnt,imf)
         end if
      end if

c........ shake it if .not.finished:
c If we are indeed got stuck and shake=.true., we then move
c the coordinate p(imf) by shake_step in the direction of the force

      if((.not.finished) .and. opt_problems .and. shake) then
         isgn=1.0
         if(g(imf).lt.0.0) isgn=-1
         p(imf)=p(imf)+isgn*shake_step
         if(nid.eq.0) then
            write(*,'(/a,i5,a,e12.6/)')
     & 'RELAX_ALL: point p(',imf,') moved by ',isgn*shake_step
            write(9,'(/a,i5,a,e12.6/)')
     & 'RELAX_ALL: point p(',imf,') moved by ',isgn*shake_step
         end if
         ishake=ishake+1
         if(ishake.lt.3) then
            en = energy(p,iPrnt)
            call gradients(p,g,iPrnt)
            go to 1
         end if
      end if

c........ match x,y,z and p()
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

c........ end here
      if(nid.eq.0) then
         write(9,'(a,e16.10)') '... Final total energy (in a.u.) = ',en
         write(9,'(a,e16.10)')
     & '... Final total energy   (in eV) = ',en*au_eV
      end if
      if(cg) es_tol=energy_gain
      return
      end

      subroutine vector_copy(x1,x,n)
      include 'param.inc'
      dimension x1(n),x(n)
      do i=1,n
         x(i)=x1(i)
      end do
      return
      end

      BLOCK DATA Mendeleev
      INCLUDE 'shell.inc'
      DATA NAZV/' H','He','Li','Be',' B',' C',' N',' O',' F','Ne',
     ,'Na','Mg','Al','Si',' P',' S','Cl','Ar',' K','Ca','Sc','Ti',
     ,' V','Cr','Mn','Fe','Co','Ni','Cn','Zn','Ga','Ge','As','Se','Br',
     ,'Cr','Rb','Sr',' Y','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag',
     ,'Cd','In','Sn','Sb','Te',' I','Xe','Cs','Ba',15*'  ','Hf','Ta',
     ,' W','Re','Os','Ir','Pt','Au','Hg','Tl','Pb'/
       END

      subroutine old_relax_flags()
c......... restore relaxation flags from iRx1,...
      include 'shell.inc'
      do i=1,Natom
         iRx(i)=iRx1(i)
         iRy(i)=iRy1(i)
         iRz(i)=iRz1(i)
         if(Shell_Ref(ISRT(i))) then
            j=iShell(i)
            iRx(j)=iRx1(j)
            iRy(j)=iRy1(j)
            iRz(j)=iRz1(j)
         end if
      end do
      return
      end

      subroutine shift_tip(del)
c..............................................................
c shift all tip atoms by shift()
c..............................................................
      include 'shell.inc'
      dimension del(3)
      if(nid.eq.0) then
         write(*,'(/3(a,f10.5),a/)') '>>>>>>>>>>> Moving tip by (',
     & del(1),',',del(2),',',del(3),') au <<<<<<<<<<<<'
         write(9,'(/3(a,f10.5),a/)') '>>>>>>>>>>> Moving tip by (',
     & del(1),',',del(2),',',del(3),') au <<<<<<<<<<<<'
      end if
      do i=1,Natom
c if(id(i).eq.'ft'.or.id(i).eq.'tb'.or.id(i).eq.'ta') then
         if(id2(i).le.3) then
            x(i)=x(i)+del(1)
            y(i)=y(i)+del(2)
            z(i)=z(i)+del(3)
            if(Shell_Ref(ISRT(i))) then
               j=iShell(i)
               x(j)=x(j)+del(1)
               y(j)=y(j)+del(2)
               z(j)=z(j)+del(3)
            end if
         end if
      end do
      if(Do_Image) then
         R_Sph(1)=R_Sph(1)+del(1)*au_A
         R_Sph(2)=R_Sph(2)+del(2)*au_A
         Rz=Rz+del(3)*au_A
         if(nid.eq.0) then
c write(*,'(3(a,f10.5),a/)') '... the sphere moved by (',
c & del(1)*au_A,',',del(2)*au_A,',',del(3)*au_A,') A'
            write(9,'(3(a,f10.5),a/)') '... the sphere moved by (',
     & del(1)*au_A,',',del(2)*au_A,',',del(3)*au_A,') A'
         end if
      end if
      return
      end

      subroutine scan_surf(p,g,en,tipf,iPrnt)
c.......................................................................
c scan in a single direction minimising atomic positions at
c every point
c.......................................................................
      include 'shell.inc'
      dimension p(N0FR),g(N0FR),r(3),tipf(3)
      integer sign
      logical dotipf

c____________________ match p() and x,y,z
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

      if(nid.eq.0) then
         write(*,'(/a)')'))))))))))))))))))))(((((((((((((((((((((((('
         write(*,'(a)')')))))))))))))) Doing the SCAN (((((((((((((('
         write(*,'(a/)')'))))))))))))))))))))(((((((((((((((((((((((('
         write(*,'(a,3(x,f10.5)/)') 'using shift =',shift
         write(9,'(/a)')'))))))))))))))))))))(((((((((((((((((((((((('
         write(9,'(a)')')))))))))))))) Doing the SCAN (((((((((((((('
         write(9,'(a/)')'))))))))))))))))))))(((((((((((((((((((((((('
         write(9,'(a,3(x,f10.5)/)') 'using shift =',shift
      end if

      sign=1
      nsteps=relax_steps-1
      if(turnback) nsteps=2*nsteps
c write(11,*) nsteps+1
c write(12,*) nsteps+1

c______________save the starting configuration first

      if(nid.eq.0) then
         if(Yes_Tip) then
            write(23,'(e18.10,x,e18.10)') z(1)*au_A,tipf(3)*au_eV/au_A
            if(do_lat) then
               write(24,'(e18.10)') tipf(1)*au_eV/au_A
               write(25,'(e18.10)') tipf(2)*au_eV/au_A
            end if
         end if
         if(write_xyz) call do_xyz(p,iPrnt)
         write(21,'(e18.10)') en*au_eV
      end if

c............... now start the scan

      DO ist=1,nsteps

         if(turnback.and.ist.eq.nsteps/2+1) sign=-1

         if(nid.eq.0) then
            write(*,'(/a,i5,a/)')'...... doing the point ',ist,' ......'
            write(9,'(/a,i5,a/)')'...... doing the point ',ist,' ......'
         end if

c________________ shift all tip atoms and relax the system
         r(1)=sign*shift(1)
         r(2)=sign*shift(2)
         r(3)=sign*shift(3)
         dotipf=Yes_Tip
         call move_and_relax(en1,r,iPrnt,'return',dotipf,tipf)

c_____________________ tip force
         if(Yes_Tip) then
            if(nid.eq.0) then
               write(23,'(e18.10,x,e18.10)')
     & z(1)*au_A,tipf(3)*au_eV/au_A
               if(do_lat) then
                  write(24,'(e18.10)') tipf(1)*au_eV/au_A
                  write(25,'(e18.10)') tipf(2)*au_eV/au_A
               end if
            end if
         end if
         if(nid.eq.0) then
c_________ do xyz
           call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)
           if(write_xyz) call do_xyz(p,iPrnt)
c_________ write energy in eV
            write(21,'(e18.10)') en1*au_eV
         end if

      END DO

      return
      end

      subroutine move_and_relax(en,displ,iPrnt,whattodo,dotipf,tipf)
c.........................................................................
c Moves the tip by vector displ() and relaxes all the atoms allowed to.
c.........................................................................
c INPUT:
c^^^^^^^
c x(),y(),z() - current coordinates
c whattodo = ' stop ': will stop if the relaxation has not converged;
c whattodo = 'return': will return if the relaxation has not converged;
c dotipf - if .true., the tip force will be calculated
c
c OUTPUT:
c^^^^^^^^
c x(),y(),z() - new coordinates
c en - energy
c tipf() - tip force along x,y,z
c.........................................................................
c NOTE: we start from x,y,z, coordinates and finish with them!
c p() - are only used inside for relaxation
c.........................................................................
      include 'shell.inc'
      dimension displ(3),p(N0FR),g(N0FR),tipf(3)
      character whattodo*6
      logical dotipf

c________________ displace (x,y,z) of all tip atoms by vector displ()
      call shift_tip(displ)
      call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

c________________ get new energy and gradients
      en = energy(p,iPrnt)
      call gradients(p,g,iPrnt)

c_____________________ relaxation first
      finished=.false.
      call relax_all(p,g,en,energy_gain,iPrnt)

c_____________________ check if finished
      if(nid.eq.0 .and. .not.finished) then
         write(*,'(a)')'FATAL! Not finished in MOVE_AND_RELAX'
         if(whattodo.eq.' stop' ) then
            stop
         else if(whattodo.eq.'return') then
            return
         end if
      end if

c____________________ tip force
      if(dotipf) then
         call do_tip_force(p,g,tipf(1),tipf(2),tipf(3),iPrnt)
      end if

c____________________ return back to x,y,z
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

      return
      end

      subroutine pos_and_relax(displ,zpos,iPrnt,whattodo,dotipf,en,tipf)
c.........................................................................
c (1) the tip is moved by vector displ() within the XY-plane;
c (2) along Z the tip is positioned such that the z coordinate of the vdW
c sphere becomes zpos
c (3) all moveable atoms of the system are then relaxed.
c.........................................................................
c INPUT:
c^^^^^^^
c x(),y(),z() - current coordinates
c whattodo = ' stop ': will stop if the relaxation has not converged;
c whattodo = 'return': will return if the relaxation has not converged;
c dotipf - if .true., the tip force will be calculated
c
c OUTPUT:
c^^^^^^^^
c x(),y(),z() - new coordinates
c en - energy
c tipf() - tip force along x,y,z
c.........................................................................
c NOTE: we start from x,y,z, coordinates and finish with them!
c p() - are only used inside for relaxation
c.........................................................................
      include 'shell.inc'
      include 'share.inc'
      dimension displ(2),p(N0FR),g(N0FR),tipf(3),delta(3)
      character whattodo*6
      logical dotipf

c________________ displace (x,y,z) of all tip atoms by vector delta()
      delta(1)=displ(1)
      delta(2)=displ(2)
      zpos1=dist_to_sphere*A_au+z(i_atom_sphere)
      delta(3)=zpos-zpos1
      if(nid.eq.0) then
         write(*,'(/a,i5,a,f10.5,a)')
     & '========== Initial tip Z-position: z(',
     , i_atom_sphere,') = ', z(i_atom_sphere)*au_A,' (A) =========='
         write(*,'(a,20x,f10.5,a)')
     & '========== to be moved by ',delta(3)*au_A,' (A) =========='
         write(9,'(/a,i5,a,f10.5,a)')
     & '========== Initial tip Z-position: z(',
     , i_atom_sphere,') = ', z(i_atom_sphere)*au_A,' (A) =========='
         write(9,'(a,20x,f10.5,a)')
     & '========== to be moved by ',delta(3)*au_A,' (A) =========='
      end if
      call shift_tip(delta)
      call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)
      if(nid.eq.0) then
         write(*,'(a,i5,a,f10.5,a)')
     & '========== Current tip Z-position: z(',
     , i_atom_sphere,') = ', z(i_atom_sphere)*au_A,' (A) =========='
         write(9,'(a,i5,a,f10.5,a)')
     & '========== Current tip Z-position: z(',
     , i_atom_sphere,') = ', z(i_atom_sphere)*au_A,' (A) =========='
      end if

c________________ get new energy and gradients
      en = energy(p,iPrnt)
      call gradients(p,g,iPrnt)

c_____________________ relaxation first
      finished=.false.
      call relax_all(p,g,en,energy_gain,iPrnt)

c_____________________ check if finished
      if(nid.eq.0 .and. .not.finished) then
         write(*,'(a)')'FATAL! Not finished in MOVE_AND_RELAX'
         if(whattodo.eq.' stop' ) then
            stop
         else if(whattodo.eq.'return') then
            return
         end if
      end if

c____________________ tip force
      if(dotipf) then
         call do_tip_force(p,g,tipf(1),tipf(2),tipf(3),iPrnt)
      end if

c____________________ return back to x,y,z
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

      return
      end
