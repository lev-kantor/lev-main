      subroutine image_input(yes_forces,tip_forces,qmc_input)
c...............................................................
c  create complete input file for IMAGE
c  x,y,z - current coordinates (in au !)
c...............................................................
      include 'shell.inc'
      logical yes_forces,tip_forces,qmc_input
      integer ibias, isphere
      external decay

      ibias=0
      isphere=0

c.......... whether to do forces or not

      iforce_charges=0
      if(yes_forces) iforce_charges=1
      iforce_tip=0
      if(tip_forces) iforce_tip=1

c......... whether to switch on the QC option
      iqmc_input=0
      if(qmc_input) iqmc_input=1

c
c............ create the input file for IMAGE
c
c(1)_______________ bias, sphere, flags
      if(nid.eq.0) then
         open(2,file='input.img',form='formatted',status='unknown')
         write(2,*) Volt
         write(2,*) Rad
         write(2,*) R_Sph(1),R_Sph(2),Rz
         write(2,*) Z_plane
      end if
      
      if(do_plane .and. (.not.do_sphere)) then
         isetup=1
      else if((.not.do_plane) .and. do_sphere) then
         isetup=2
      else if(do_plane .and. do_sphere) then
         isetup=3
      end if

      if(do_only_bias)  ibias=1

      if(nid.eq.0) then
         if(precis.eq.0.0) then
            write(2,'(8(i5,x))') NumImg,iPrnt1,iforce_charges,
     ,                   iforce_tip,iwrite,isetup,ibias,iqmc_input
         else
            write(2,'(e12.6,7(x,i5))') precis,iPrnt1,iforce_charges,
     ,          iforce_tip,iwrite,isetup,ibias,iqmc_input
         end if    
         write(2,*) Ncharge-itft,scale
      end if  

c_______convert some quantities to atomic units
      if(do_decay) then
         rsx=r_sph(1)*a_au
         rsy=r_sph(2)*a_au
         rsz=(rz+rad)*a_au
         rads=rad*a_au
         zp=z_plane*a_au
      end if
c            
c..............  cores
c
      do i=1,Natom
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            is=ISRT(i)
            iflagf=0
            q=CoreQA(is)

c_______check how close charge is to plane/sphere and change charge as appropriate

            if(do_decay) then
               rsp2=(x(i)-rsx)**2 + (y(i)-rsy)**2 +(z(i)-rsz)**2
               rsp=sqrt(rsp2)-rads
               rpl=z(i)-zp

c_______calculate factors for reducing charge with function decay

               fsp=decay(rsp)
               fpl=decay(rpl)
               q=q*fpl*fsp
            end if
                       
c_______check if i is relaxed

            if(iRx(i).ne.0 .or. iRy(i).ne.0 .or. iRz(i).ne.0 
     &                                      .or. do_md) iflagf=1

c_______check if i belongs to the Quantum Cluster
            iflagQMC=0
            if(qmc_input .and. iQMC(i)) iflagQMC=1
            
c_______write atom
            if(nid.eq.0) write(2,'(4(e24.14,x),3i5)') 
     &           x(i)*au_A,y(i)*au_A,z(i)*au_A,q,iflagf,iflagQMC
         end if
      end do
c
c...................... shells
c
      do i=1,Natom
         if(id2(i).ne.1) then
            is=ISRT(i)
            if(Shell_Ref(is)) then
               j=iShell(i)
               iflagf=0
               q=ShellQA(is)
               
c_______check how close charge is to plane/sphere and change charge as appropriate

               if(do_decay) then
                  rsp2=(x(j)-rsx)**2 + (y(j)-rsy)**2 +(z(j)-rsz)**2
                  rsp=sqrt(rsp2)-rads
                  rpl=z(j)-zp

c______same setup as with cores

                  fsp=decay(rsp)
                  fpl=decay(rpl)
                  q=q*fpl*fsp
               end if
               
c_______check if j is relaxed

               if(iRx(j).ne.0 .or. iRy(j).ne.0 .or. iRz(j).ne.0
     &                                      .or. do_md) iflagf=1

c_______check if j belongs to the Quantum Cluster

               iflagQMC=0
               if(qmc_input .and. iQMC(j)) iflagQMC=1
               
c_______write shell
               if(nid.eq.0) write(2,'(4(e24.14,x),3i5)') 
     &              x(j)*au_A,y(j)*au_A,z(j)*au_A,q,iflagf,iflagQMC
            end if      
         end if
      end do
      if(nid.eq.0) close (2)
      return
      end

      double precision function image_get_energy(iPrnt)
c........................................................
c read potent.out and get the image energy in au
c........................................................
      include 'param.inc'
      character line*120
      integer LinPos(30),LinEnd(30)

c__________ open output file with the energy
      open(2,file='potent.out',form='formatted',status='old',err=100)

c__________ find the line with energy
10    read (2,'(a)',END=100,ERR=100) Line
      i0=INDEX(Line,'>>>> Effective Energy (a.u.):')
      if(i0.eq.0) go to 10
      if(iPrnt.ge.10)  write(9,'(a)')'Okay! Found ==> '//line

c__________ read the energy
      call CutStr(Line,NumLin,LinPos,LinEnd,0,iErr)
      if(iErr.eq.1 .or. NumLin.ne.5) go to 100
      Read(Line(LinPos(5):),*,end=100,err=100) en
      if(iPrnt.ge.10)  then
         write(9,'(a,e16.10)')'Image energy found = ',en
         write(*,'(a,e16.10)')'Image energy found = ',en
      end if
      image_get_energy=en
      close (2)
      return
c
c.......... error
 100  write(*,'(a)')'FATAL! Error while opening or reading potent.out'
      stop 'image_get_energy: smth wrong with IMAGE'
      end

      logical function catch_fatal(file,l)
c........................................................
c read potent.out and get the image energy in au
c........................................................
      include 'param.inc'
      character line*120,file*20
      integer LinPos(30),LinEnd(30)

      catch_fatal=.false.

c__________ open output file 
      open(2,file=file(1:l),form='formatted',status='old',err=100)

c__________ catching a fatal error message
10    read (2,'(a)',END=20,ERR=100) Line
      i0=INDEX(Line,'FATAL')
      if(i0.eq.0) go to 10
      write(9,'(/a)')'ERROR found in <'//file(1:l)//'>: '//line
      catch_fatal=.true.
 20   close (2)
      return
c
c.......... error
 100  write(*,'(a)')'FATAL! Error while opening or reading '//file(1:l)
      stop 'catch_fatal: smth wrong with IMAGE'
      end
      
      subroutine image_get_grad(iPrnt,fx,fy,fz,ISRT,Natom,id2,
     ,                                      Shell_Ref,iShell)
c........................................................
c read forces.out and get the image forces f_im in au
c........................................................
      include 'param.inc'
      dimension fx(N0CH),fy(N0CH),fz(N0CH),ISRT(N0LT),iShell(N0LT)
      logical Yes_Tip,Shell_Ref(N0KD)
c      character id(N0CH)*2
      integer id2(N0CH)

c__________ open output file with the forces
      open(2,file='forces.out',form='formatted',status='old',err=100)
      read(2,'(a)') 

c__________ read forces on all charges: cores and then shells
      if(iPrnt.ge.10) write(9,'(/a/)') '........ IMAGE: forces .....'

c________________ image forces on cores of normal atoms
      do i=1,Natom
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            read(2,*,err=100,end=100) ii,fx(i),fy(i),fz(i)
            if(iPrnt.ge.10) 
     &           write(9,'(i5,3(x,e12.6))') i,fx(i),fy(i),fz(i)
         else
            fx(i)=0.0d0
            fy(i)=0.0d0
            fz(i)=0.0d0
            if(iPrnt.ge.10) 
     &           write(9,'(i5,3(x,e12.6))') i,fx(i),fy(i),fz(i)
         end if
      end do

c________________ image forces on shells of all atoms;
c                 set to 0.0 for shells of 'ft' atoms
      do i=1,Natom
         is=ISRT(i)
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            if(Shell_Ref(is)) then
               j=iShell(i)
               read(2,*,err=100,end=100) ii,fx(j),fy(j),fz(j)
               if(iPrnt.ge.10) write(9,'(i5,3(x,e12.6))') 
     &                                     j,fx(j),fy(j),fz(j)
            end if      
         else if(Shell_Ref(is)) then
            j=iShell(i)
            fx(j)=0.0d0
            fy(j)=0.0d0
            fz(j)=0.0d0
            if(iPrnt.ge.10) write(9,'(i5,3(x,e12.6))') 
     &                                    j,fx(j),fy(j),fz(j)
         end if
      end do
c
      if(iPrnt.ge.10) write(9,'(/)') 
      close (2)
      return

c_________add contribution due to decay
c
c.......... error
 100  write(*,'(a)')'FATAL! Error while opening or reading forces.out'
      stop 'image_get_grad: smth wrong with IMAGE'
      end

      double precision  function get_tip_force_image(iPrnt)
c........................................................
c read potent.out and get the force on the tip
c........................................................
      include 'param.inc'
      character line*120
      integer LinPos(30),LinEnd(30)

c__________ open output file with the force
      open(2,file='potent.out',form='formatted',status='old',err=100)

c__________ find the line with force
10    read (2,'(a)',END=100,ERR=100) Line
      i0=INDEX(Line,'>>>> zForce acting on the tip (a.u.):')
      if(i0.eq.0) go to 10
      if(iPrnt.ge.10)  write(9,'(a)')'Okay! Found ==> '//line

c__________ read the energy
      call CutStr(Line,NumLin,LinPos,LinEnd,0,iErr)
      if(iErr.eq.1 .or. NumLin.ne.8) go to 100
      Read(Line(LinPos(8):),*,end=100,err=100) force
      if(iPrnt.ge.10)  then
         write(9,'(a,e16.10)')'Image force on the tip found = ',force
         write(*,'(a,e16.10)')'Image force on the tip found = ',force
      end if
      get_tip_force_image =force
      close (2)
      return
c
c.......... error
 100  write(*,'(a)')'FATAL! Error while opening or reading potent.out'
      stop 'image_get_tip_force: smth wrong with IMAGE'
      end

      subroutine do_tip_force(p,g,tipforce_x,tipforce_y,tipforce_z,
     ,     iPrnt)
c........................................................
c read forces.out and get the image forces f_im in au
c........................................................
      include 'shell.inc'
      dimension p(max_free),g(max_free),force_on_tip(3)
      double precision  image_get_tip_force, zfrc_decay
      logical Keep_Image
      logical fatal,catch_fatal
      character id1*2,cha6*6

      tip_decay=0.0

c[1]......... calculate the contribution from atoms
c
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,                  n_pos_cor,iRx,iRy,iRz)
c___________ set relaxation flags iRz=1 for all frozen atoms in
c            the physical tip (types: 'ft','tb','ta').
c            All others should be set to 0 (both in the physical tip
c            and in the cluster).
      do i=1,Natom
         if(id2(i).le.3) then
            if(iRz1(i).gt.0) iRz(i)=0
            if(iRz1(i).eq.0) iRz(i)=1
            if(do_lat) then
               if(iRx1(i).gt.0) iRx(i)=0
               if(iRx1(i).eq.0) iRx(i)=1
               if(iRy1(i).gt.0) iRy(i)=0
               if(iRy1(i).eq.0) iRy(i)=1
            else
               iRx(i)=0
               iRy(i)=0
            end if
            if(Shell_Ref(ISRT(i))) then
               j=iShell(i)
               iRz(j)=1-iRz1(j)
               if(do_lat) then
                  iRx(j)=1-iRx1(j)
                  iRy(j)=1-iRy1(j)
               end if
            end if
         else
            iRx(i)=0
            iRy(i)=0
            iRz(i)=0
            if(Shell_Ref(ISRT(i))) then
               j=iShell(i)
               iRx(j)=0
               iRy(j)=0
               iRz(j)=0
            end if
         end if
      end do
c___________ call gradients: our gradients will be in fx,fy,fz
c                            and coordinates in x,y,z
c      write(9,*)' got here !!! ', nid
c      write(9,*) 'x => ',(irx(i),i=1,Natom)
c      write(9,*) 'y => ',(iry(i),i=1,Natom)
c      write(9,*) 'z => ',(irz(i),i=1,Natom)
      call gradients3(iPrnt,.true.)
c      write(9,*)' got past gradients !! ',nid
c
c.............. Sum forces of tip atoms. If read_force=.true., then
c               we read z-forces fzt imposed on every frozen tip atoms
c               from a free-tip calculation made previously, and 
c               subtract it from the current force fz(i) to reduce
c               numerical noise.
c                  If write_force=.true., we write fz(i) to the file
c               implying this is the free-tip calculation.
      do j=1,3
         force_on_tip(j)=0.0d0
      end do

      do i=1,Natom

         if(id2(i).le.3) then

c__________________ read/write the force on tip atoms cores
            fzt=0.0d0
            if(nid.eq.0) then
               if(write_force) then
                  write(4,'(a2,a6,x,e24.14)') id(i),' core ',fz(i)
               else if(read_force) then
                  read(4,'(a2,a6,x,e24.14)',err=100) id1,cha6,fzt
                  if(id1.ne.id(i) .or. cha6.ne.' core ') go to 100
               end if
            end if
            if(iRx(i).eq.1) then
               force_on_tip(1)=force_on_tip(1)-fx(i)
               if(iPrnt.ge.5.and.nid.eq.0) 
     &              write(9,'(i5,x,a2,a7,2(e24.14,x))') 
     &                                   i,id(i),'  core ',fx(i)
            end if
            if(iRy(i).eq.1) then
               force_on_tip(2)=force_on_tip(2)-fy(i)
               if(iPrnt.ge.5.and.nid.eq.0) 
     &              write(9,'(i5,x,a2,a7,2(e24.14,x))') 
     &                                   i,id(i),'  core ',fy(i)
            end if
            if(iRz(i).eq.1) then
               force_on_tip(3)=force_on_tip(3)-(fz(i)-fzt)
               if(iPrnt.ge.5.and.nid.eq.0) 
     &              write(9,'(i5,x,a2,a7,2(e24.14,x))') 
     &                                   i,id(i),'  core ',fz(i),fzt
            end if
            
c__________________ read/write the force on tip atoms shells
            if(Shell_Ref(ISRT(i))) then
               j=iShell(i)
               fzt=0.0d0
               if(nid.eq.0) then
                  if(write_force) then
                     write(4,'(a2,a6,x,e24.14)') id(j),' shll ',fz(j)
                  else if(read_force) then
                     read(4,'(a2,a6,x,e24.14)',err=100) id1,cha6,fzt
                     if(id1.ne.id(j) .or. cha6.ne.' shll ') go to 100
                  end if
               end if
               if(iRx(j).eq.1.and.do_lat) then
                  force_on_tip(1)=force_on_tip(1)-fx(j)
                  if(iPrnt.ge.5.and.nid.eq.0) 
     &                 write(9,'(i5,x,a2,a7,2(e24.14,x))') 
     &                 j,id(j),'  shell ',fx(j)
               end if
               if(iRy(j).eq.1.and.do_lat) then
                  force_on_tip(2)=force_on_tip(2)-fy(j)
                  if(iPrnt.ge.5.and.nid.eq.0) 
     &                 write(9,'(i5,x,a2,a7,2(e24.14,x))') 
     &                 j,id(j),'  shell ',fy(j)
               end if
               if(iRz(j).eq.1) then
                  force_on_tip(3)=force_on_tip(3)-(fz(j)-fzt)
                  if(iPrnt.ge.5.and.nid.eq.0) 
     &                 write(9,'(i5,x,a2,a7,2(e24.14,x))') 
     &                 j,id(j),' shell ',fz(j),fzt
               end if
            end if
         end if
      end do

c
c[2].....................contribution from IMAGE.
c                 The contributions from IMAGE and DECAY to the force
c                 coming from the only-tip system is written/read
c                 from/to the file and accounted for if applied.
c

      if(Do_Image) then
c         call image_input(.false.,.true.)
c         call system('image > outf')
c         fatal=catch_fatal('outf',4)
c         if(fatal) then
c            write(*,*)'FATAL! Error in IMAGE. Stop in DO_TIP_FORCE'
c            stop
c         end if
         tip_image= get_tip_force_image(iPrnt)
         tip_image0= 0.0d0
         if(write_force .and. nid.eq.0) then
            write(4,'(a13,e24.14)') 'from image = ',tip_image
         else if(read_force .and. nid.eq.0) then
            read(4,'(13x,e24.14)',err=100) tip_image0
         end if
         tip_image = tip_image - tip_image0
c_________get DECAY contribution

         if (do_decay) then
            call decay_force(tip_decay)
            tip_decay0= 0.0d0
            if(write_force .and. nid.eq.0) then
               write(4,'(a13,e24.14)') 'from decay = ',tip_decay
            else if(read_force .and. nid.eq.0) then
               read(4,'(13x,e24.14)',err=100) tip_decay0
            end if
            tip_decay = tip_decay - tip_decay0
         end if
      else
         tip_image=0.0d0
      end if
c
c[3]............. add together
c
      if(nid.eq.0) then

         write(9,'(/a,3(x,e16.10))')
     &     '... sum of x,y,z-forces on tip atoms (au) = ', force_on_tip 
         write(9,'(a,e16.10)')
     &     '... z-force on the tip from IMAGE  (au) = ', tip_image
         write(9,'(a,e16.10)')
     &     '... z-force on the tip from DECAY  (au) = ', tip_decay

      end if

      tipforce_z = force_on_tip(3) + tip_image + tip_decay
      if(do_lat) then
         tipforce_x = force_on_tip(1)
         tipforce_y = force_on_tip(2)
      end if

      un1=au_eV/au_A
      if(nid.eq.0) then

         write(9,'(/a,3(x,e16.10))')
     &        '... total x,y,z-force on the tip       (eV/A) = ', 
     &        tipforce_x*un1,tipforce_y*un1,tipforce_z*un1
      end if

c........ restore relaxation flags

      call old_relax_flags()
      return
c
c......... error
 100  write(*,'(a)')
     &               'FATAL! error in DO_TIP_FORCE while reading forces'
      if(nid.eq.0) write(9,'(a)')
     &               'FATAL! error in DO_TIP_FORCE while reading forces'
      stop
      end

