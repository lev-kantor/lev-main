      subroutine gradients(R,F,iPrnt)
c....................................................................
c calculates the gradient (=-force) vector F() at the point R().
c Definition: gradient = dE/dR (force=-dE/dR)
c....................................................................
c r() - 1-dim vectror of all coordinates
c x(),y(),z() - working arrays for coordinates (ALL included)
c F() - 1-dim vector of gradients (made in the same way as r())
c fx(),fy(),fz() - working arrays for gradients (ALL included)
c fimx(),fimy(),fimz() - working arrays for image forces
c....................................................................
      include 'shell.inc'
      dimension R(N0FR),F(N0FR)
c
c........... convert to x,y,z
c
      if(iPrnt.ge.8) then
         write(9,*)'========> ... entering GRADIENTS ...'
         if(iPrnt.ge.10) write(9,*)'... converting 1 to 3 ...'
      end if
      call conv_1_3(R,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

      if(nid.eq.0) then
        if(iPrnt.ge.8) then
         write(9,'(/a)')'.......GRADIENTS:  current coordinates .......'
          call print_6(x,y,z,Natom,Shell_Ref,iShell,ISRT,iRx,iRy,iRz)
        end if
      end if
c
c...............................................................
c........... calculate gradients on chosen cores and shells
c coordinates are now in x,y,z
c gradients will be in fx,fy,fz
c...............................................................
c
c write(*,*) 'nid=',nid,' before gradients3 call'

      call gradients3(iPrnt,.false.)
c
c........... convert gradients from fx,fy,fz to F
c
      if(iPrnt.ge.8) write(9,*)'... converting gradients 3 to 1 ...'
      call force_conv_3_1(fx,fy,fz,F,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,     n_pos_cor,iRx,iRy,iRz)
      return
      end

      subroutine gradients3(iPrnt,tip_flag)
c....................................................................
c calculates the gradient (=-force) in fx,fy,fy at the point x,y,z.
c Definition: gradient = dE/dR (force=-dE/dR)
c....................................................................
c x(),y(),z() - working arrays for coordinates (ALL included)
c fx(),fy(),fz() - working arrays for gradients (ALL included)
c fimx(),fimy(),fimz() - working arrays for image forces
c....................................................................
      include 'shell.inc'



      double precision fidx(ncharge), fidy(ncharge), fidz(ncharge)
      dimension fimx(N0CH),fimy(N0CH),fimz(N0CH)
      dimension e_cc(3),e_cs(3),e_ss(3),e_sc(3),grad(3)
      logical fatal,catch_fatal,tip_flag,in_tip
      character cha(3)
      data cha/'F','R','C'/
c
c...............................................................
c........... calculate gradient on chosen cores and shells
c...............................................................
c
      do i=1,Natom
         fx(i)=0.0d0
         fy(i)=0.0d0
         fz(i)=0.0d0
      end do
      if(do_tersoff) call tersoff_force()

c______________ add contribution from springs (only if present)

      do i=1,Natom
         is=ISRT(i)
         if(Shell_Ref(is)) then
            j=iShell(i)
            fx(j)=0.0d0
            fy(j)=0.0d0
            fz(j)=0.0d0
            if(iRx(j).gt.0) fx(j)=-Spring(is)*( x(i)-x(j) )
            if(iRy(j).gt.0) fy(j)=-Spring(is)*( y(i)-y(j) )
            if(iRz(j).gt.0) fz(j)=-Spring(is)*( z(i)-z(j) )
            if(iRx(i).gt.0) fx(i)= fx(i) + Spring(is)*( x(i)-x(j) )
            if(iRy(i).gt.0) fy(i)= fy(i) + Spring(is)*( y(i)-y(j) )
            if(iRz(i).gt.0) fz(i)= fz(i) + Spring(is)*( z(i)-z(j) )
            if(iPrnt.ge.10) then
               write(9,'(2(a,i3))')' spring of i=',i,' with j=',j
               write(9,'(3(x,f10.5))') fx(i),fy(i),fz(i)
            end if
         end if
 10   end do
c
c................ gradient on the core i, shell j and core ii, shell jj
c by making double loop over all pairs of cores (i,ii)

      do i=n_interval(nid)+1,n_interval(nid+1)
         is=ISRT(i)
         do ii=1,i
            iis=ISRT(ii)
            if(i.eq.ii) go to 100

c-----------check if the pair is excluded by a multibody interaction
c           or between two Tersoff or two many-body atoms

            if(excl_atom(i,ii)) go to 100
c
            if(iPrnt.ge.10)  write(9,'(a,2i5)') 
     &                      ')))))))  pair i,ii= ',i,ii,' ((((((('

c_______________ if both i,ii have shells, we have contributions to gradients on
c both cores i,ii and both shells j,jj

            IF(Shell_Ref(is) .and. Shell_Ref(iis) ) THEN
               j=iShell(i)
               jj=iShell(ii)
               call unitv(x(i),y(i),z(i),x(ii),y(ii),z(ii),
     ,              d_cc,d_cc2,e_cc)
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc2
               call unitv(x(i),y(i),z(i),x(jj),y(jj),z(jj),
     ,              d_cs,d_cs2,e_cs)
               coul_cs=CoreQA(is)*ShellQA(iis)/d_cs2
               call unitv(x(j),y(j),z(j),x(ii),y(ii),z(ii),
     ,              d_sc,d_sc2,e_sc)
               coul_sc=ShellQA(is)*CoreQA(iis)/d_sc2
               call unitv(x(j),y(j),z(j),x(jj),y(jj),z(jj),
     ,              d_ss,d_ss2,e_ss)
               coul_ss=ShellQA(is)*ShellQA(iis)/d_ss2
               short=der_Pot(is,iis,d_ss)
               if(iRx(i).gt.0 .or.(do_md))
     &              fx(i)=fx(i)-coul_cc*e_cc(1)-coul_cs*e_cs(1)
               if(iRy(i).gt.0 .or.(do_md))
     &              fy(i)=fy(i)-coul_cc*e_cc(2)-coul_cs*e_cs(2)
               if(iRz(i).gt.0 .or.(do_md))
     &              fz(i)=fz(i)-coul_cc*e_cc(3)-coul_cs*e_cs(3)
               if(iRx(ii).gt.0 .or.(do_md))
     &              fx(ii)=fx(ii)+coul_cc*e_cc(1)+coul_sc*e_sc(1)
               if(iRy(ii).gt.0 .or.(do_md))
     &              fy(ii)=fy(ii)+coul_cc*e_cc(2)+coul_sc*e_sc(2)
               if(iRz(ii).gt.0 .or.(do_md))
     &              fz(ii)=fz(ii)+coul_cc*e_cc(3)+coul_sc*e_sc(3)
               if(iRx(j).gt.0 .or.(do_md))
     &              fx(j)=fx(j)-coul_sc*e_sc(1)-(coul_ss-short)*e_ss(1)
               if(iRy(j).gt.0 .or.(do_md))
     &              fy(j)=fy(j)-coul_sc*e_sc(2)-(coul_ss-short)*e_ss(2)
               if(iRz(j).gt.0 .or.(do_md))
     &              fz(j)=fz(j)-coul_sc*e_sc(3)-(coul_ss-short)*e_ss(3)
               if(iRx(jj).gt.0 .or.(do_md))
     &             fx(jj)=fx(jj)+coul_cs*e_cs(1)+(coul_ss-short)*e_ss(1)
               if(iRy(jj).gt.0 .or.(do_md))
     &             fy(jj)=fy(jj)+coul_cs*e_cs(2)+(coul_ss-short)*e_ss(2)
               if(iRz(jj).gt.0 .or.(do_md))
     &             fz(jj)=fz(jj)+coul_cs*e_cs(3)+(coul_ss-short)*e_ss(3)
               if(iPrnt.ge.10) then
                  write(9,'(5x,a,2i5)') 'both shells j,jj= ',j,jj
                  write(9,'(a,4(x,f10.5))')'dist: ',d_cc,d_cs,d_sc,d_ss
                  write(9,'(a,3(x,f10.5))') 'current gradient on i => ',
     &                 fx(i),fy(i),fz(i)
                  write(9,'(a,3(x,f10.5))')'current gradient on ii => ',
     &                 fx(ii),fy(ii),fz(ii)
                  write(9,'(a,3(x,f10.5))') 'current gradient on j => ',
     &                 fx(j),fy(j),fz(j)
                  write(9,'(a,3(x,f10.5))')'current gradient on jj => ',
     &                 fx(jj),fy(jj),fz(jj)
               end if

c_______________ if only i has a shell, we have contributions to the gradients on
c both cores i,ii and the shell j
            ELSE IF(Shell_Ref(is)) THEN
               j=iShell(i)
               call unitv(x(i),y(i),z(i),x(ii),y(ii),z(ii),
     ,              d_cc,d_cc2,e_cc)
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc2
               call unitv(x(j),y(j),z(j),x(ii),y(ii),z(ii),
     ,              d_sc,d_sc2,e_sc)
               coul_sc=ShellQA(is)*CoreQA(iis)/d_sc2
               short=der_Pot(is,iis,d_sc)
               if(iRx(i).gt.0 .or.(do_md))
     &              fx(i)=fx(i)-coul_cc*e_cc(1)
               if(iRy(i).gt.0 .or.(do_md))
     &              fy(i)=fy(i)-coul_cc*e_cc(2)
               if(iRz(i).gt.0 .or.(do_md))
     &              fz(i)=fz(i)-coul_cc*e_cc(3)
               if(iRx(ii).gt.0 .or.(do_md))
     &             fx(ii)=fx(ii)+coul_cc*e_cc(1)+(coul_sc-short)*e_sc(1)
               if(iRy(ii).gt.0 .or.(do_md))
     &             fy(ii)=fy(ii)+coul_cc*e_cc(2)+(coul_sc-short)*e_sc(2)
               if(iRz(ii).gt.0 .or.(do_md))
     &             fz(ii)=fz(ii)+coul_cc*e_cc(3)+(coul_sc-short)*e_sc(3)
               if(iRx(j).gt.0 .or.(do_md))
     &              fx(j)=fx(j)-(coul_sc-short)*e_sc(1)
               if(iRy(j).gt.0 .or.(do_md))
     &              fy(j)=fy(j)-(coul_sc-short)*e_sc(2)
               if(iRz(j).gt.0 .or.(do_md))
     &              fz(j)=fz(j)-(coul_sc-short)*e_sc(3)
               if(iPrnt.ge.10) then
                  write(9,'(5x,a,2i5)') 'only shell j= ',j
                  write(9,'(a,4(x,f10.5))')'dist: ',d_cc,d_sc
                  write(9,'(a,3(x,f10.5))') 'current gradient on i => ',
     &                 fx(i),fy(i),fz(i)
                  write(9,'(a,3(x,f10.5))')'current gradient on ii => ',
     &                 fx(ii),fy(ii),fz(ii)
                  write(9,'(a,3(x,f10.5))') 'current gradient on j => ',
     &                 fx(j),fy(j),fz(j)
               end if

c_______________ if only ii has a shell, we have contributions to the gradients on
c both cores i,ii and the shell jj
            ELSE IF(Shell_Ref(iis)) THEN
               jj=iShell(ii)
               call unitv(x(i),y(i),z(i),x(ii),y(ii),z(ii),
     ,              d_cc,d_cc2,e_cc)
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc2
               call unitv(x(i),y(i),z(i),x(jj),y(jj),z(jj),
     ,              d_cs,d_cs2,e_cs)
               coul_cs=CoreQA(is)*ShellQA(iis)/d_cs2
               short=der_Pot(is,iis,d_cs)
               if(iRx(i).gt.0 .or.(do_md))
     &              fx(i)=fx(i)-coul_cc*e_cc(1)-(coul_cs-short)*e_cs(1)
               if(iRy(i).gt.0 .or.(do_md))
     &              fy(i)=fy(i)-coul_cc*e_cc(2)-(coul_cs-short)*e_cs(2)
               if(iRz(i).gt.0 .or.(do_md))
     &              fz(i)=fz(i)-coul_cc*e_cc(3)-(coul_cs-short)*e_cs(3)
               if(iRx(ii).gt.0 .or.(do_md))
     &              fx(ii)=fx(ii)+coul_cc*e_cc(1)
               if(iRy(ii).gt.0 .or.(do_md))
     &              fy(ii)=fy(ii)+coul_cc*e_cc(2)
               if(iRz(ii).gt.0 .or.(do_md))
     &              fz(ii)=fz(ii)+coul_cc*e_cc(3)
               if(iRx(jj).gt.0 .or.(do_md))
     &              fx(jj)=fx(jj)+(coul_cs-short)*e_cs(1)
               if(iRy(jj).gt.0 .or.(do_md))
     &              fy(jj)=fy(jj)+(coul_cs-short)*e_cs(2)
               if(iRz(jj).gt.0 .or.(do_md))
     &              fz(jj)=fz(jj)+(coul_cs-short)*e_cs(3)
               if(iPrnt.ge.10) then
                  write(9,'(5x,a,2i5)') 'only shell jj= ',jj
                  write(9,'(a,4(x,f10.5))')'dist: ',d_cc,d_cs
                  write(9,'(a,3(x,f10.5))')'current gradient on i => ',
     &                 fx(i),fy(i),fz(i)
                  write(9,'(a,3(x,f10.5))')'current gradient on ii => ',
     &                 fx(ii),fy(ii),fz(ii)
                  write(9,'(a,3(x,f10.5))')'current gradient on jj => ',
     &                 fx(jj),fy(jj),fz(jj)
               end if

c_______________ if both do not have shells, we have contributions to the gradients
c only on cores i,ii
            ELSE
               call unitv(x(i),y(i),z(i),x(ii),y(ii),z(ii),
     ,              d_cc,d_cc2,e_cc)
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc2
               short=der_Pot(is,iis,d_cc)
               if(iRx(i).gt.0 .or.(do_md))
     &              fx(i)=fx(i)-(coul_cc-short)*e_cc(1)
               if(iRy(i).gt.0 .or.(do_md))
     &              fy(i)=fy(i)-(coul_cc-short)*e_cc(2)
               if(iRz(i).gt.0 .or.(do_md))
     &              fz(i)=fz(i)-(coul_cc-short)*e_cc(3)
               if(iRx(ii).gt.0 .or.(do_md))
     &              fx(ii)=fx(ii)+(coul_cc-short)*e_cc(1)
               if(iRy(ii).gt.0 .or.(do_md))
     &              fy(ii)=fy(ii)+(coul_cc-short)*e_cc(2)
               if(iRz(ii).gt.0 .or.(do_md))
     &              fz(ii)=fz(ii)+(coul_cc-short)*e_cc(3)
               if(iPrnt.ge.10) then
                  write(9,'(5x,a,2i5)') 'only cores i,ii= ',i,ii
                  write(9,'(a,4(x,f10.5))')'dist: ',d_cc
                  write(9,'(a,3(x,f10.5))') 'current gradient on i => ',
     &                 fx(i),fy(i),fz(i)
                  write(9,'(a,3(x,f10.5))')'current gradient on ii => ',
     &                 fx(ii),fy(ii),fz(ii)
               end if

            END IF
            
 100     end do
      end do

c_____add contribution on the force on atoms due to many-body interactions

      if(nid.eq.0 .and. do_mbody) call diag_force(iPrnt)
c
c................ contribution from IMAGE: note we need gradients
c                 although in IMAGE we have forces!

      if(Do_Image) then
         call image_input(.true.,tip_flag,.false.)
         call system('image > outf')
         fatal=catch_fatal('outf',4)
         if(fatal .and. nid.eq.0) then
            write(*,*)'FATAL! fatal error in IMAGE. Stop in gradients.'
            stop 'called from GRADIENTS'
         end if
         call image_get_grad(iPrnt,fimx,fimy,fimz,ISRT,Natom,id2,
     ,        Shell_Ref,iShell)
         
c_______ calculate gradients due to decay of charges in image

         do i=1,ncharge
            fidx(i)=0.0
            fidy(i)=0.0
            fidz(i)=0.0
         end do
         if(do_decay) call decay_atoms(fidx, fidy, fidz)

         if(iPrnt.ge.5) then
            write(9,'(/a)')
     & '........ GRADIENTS before IMAGE forces: .......'
            call print_6(fx,fy,fz,
     ,           Natom,Shell_Ref,iShell,ISRT,iRx,iRy,iRz)
            write(9,'(/a)')'........ Current IMAGE forces: .......'
            call print_6(fimx,fimy,fimz,
     ,           Natom,Shell_Ref,iShell,ISRT,iRx,iRy,iRz)
            write(9,'(/a)')'........ Current DECAY forces: .......'
            call print_6(fidx,fidy,fidz,
     ,           Natom,Shell_Ref,iShell,ISRT,iRx,iRy,iRz)
         end if
      end if

c
c............... calculate final gradients if IMAGE
      if(Do_Image) then
         do i=1,Natom
            if(iRx(i).gt.0.or.do_md) fx(i)=fx(i)-fimx(i)-fidx(i)
            if(iRy(i).gt.0.or.do_md) fy(i)=fy(i)-fimy(i)-fidy(i)
            if(iRz(i).gt.0.or.do_md) fz(i)=fz(i)-fimz(i)-fidz(i)
         end do
         do i=1,Natom
            if(Shell_Ref(ISRT(i))) then
               j=iShell(i)
               if(iRx(j).gt.0.or.do_md) fx(j)=fx(j)-fimx(j)-fidx(j)
               if(iRy(j).gt.0.or.do_md) fy(j)=fy(j)-fimy(j)-fidy(j)
               if(iRz(j).gt.0.or.do_md) fz(j)=fz(j)-fimz(j)-fidz(j)
            end if
         end do
      end if
c
c........... print out positions/forces if write_en_frc=.true.
c
      if(write_en_frc .and. nid.eq.0) then
         write(31,'(a)') 'Current positions / forces (all in a.u.):'
         do i=1,Natom
            write(31,'(i5,2(3(x,e24.18),5x))')
     &           i,x(i),y(i),z(i),-fx(i),-fy(i),-fz(i)
         end do
      end if
c
c.......... print final gradients on cores/shells
c grad - total gradient (should be near 0.0 without IMAGE)
c
      if(iPrnt.ge.1) then
         write(9,'(/a)')
     & '........ COORDINATES/GRADIENTS (final) on cores (a.u.) ...'
         grad(1)=0.0d0
         grad(2)=0.0d0
         grad(3)=0.0d0
         do i=1,Natom
            write(9,'(a3,i5,2(3(x,e12.6),5x))')
     &           cha(iRx(i)+1)//cha(iRy(i)+1)//cha(iRz(i)+1),
     &           i,x(i),y(i),z(i),fx(i),fy(i),fz(i)
            grad(1)=grad(1)+fx(i)
            grad(2)=grad(2)+fy(i)
            grad(3)=grad(3)+fz(i)
         end do
         write(9,'(/a)')
     &     '........ COORDINATES/GRADIENTS (final) on shells (a.u.) ...'
         do i=1,Natom
            is=ISRT(i)
            if(Shell_Ref(is)) then
               j=iShell(i)
               write(9,'(a3,i5,2(3(x,e12.6),5x))')
     &              cha(iRx(j)+1)//cha(iRy(j)+1)//cha(iRz(j)+1),
     &              j,x(j),y(j),z(j),fx(j),fy(j),fz(j)
               grad(1)=grad(1)+fx(j)
               grad(2)=grad(2)+fy(j)
               grad(3)=grad(3)+fz(j)
            end if
         end do
         write(9,'(/a,3(x,e16.10)/)')'...> total gradient = ',grad
      end if

      return
      end

      subroutine unitv(x,y,z,x1,y1,z1,dist1,dist2,e)
c..........................................................
c (i) distance dist1 between two points: (x,y,z) and (x1,y1,z1)
c (ii) its square dist2
c (iii) unit vector e() in the direction from (x,y,z) to
c (x1,y1,z1)
c..........................................................
      include 'param.inc'
      dimension e(3)
      data tiny/0.001/
      d1=x-x1
      d2=y-y1
      d3=z-z1
      dist2=d1*d1+d2*d2+d3*d3
      dist1=sqrt(dist2)
      if(dist1.lt.tiny) then
         write(*,*)'FATAL! Close points:'
         write(*,'(5x,a,3(x,f10.5))') ' (x,y,z)= ',x,y,z
         write(*,'(5x,a,3(x,f10.5))') ' (x1,y1,z1)= ',x1,y1,z1
         stop 'stop in unitv'
      end if
      d=1.0d0/dist1
      e(1)=d1*d
      e(2)=d2*d
      e(3)=d3*d
      return
      end
