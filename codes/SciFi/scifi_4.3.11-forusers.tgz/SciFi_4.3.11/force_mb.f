      subroutine diag_force(iPrnt)
c.............................................................
c     function that calculates the gradient at each atom     .
c     in the molecule for the diagonal energy terms          .
c.............................................................
      include 'shell.inc'

c_____temporary variables to increase clarity
      double precision length,bgradx,bgrady,bgradz
      double precision angle,agrad1,agrad2,agrad3
      double precision torsion,tgrad1,tgrad2,tgrad3,tgrad4
      double precision ograd1,ograd2,ograd3,ograd4
      double precision angle_12,angle_23
      double precision e_by_dtheta
      double precision e_by_dphi
      double precision e_by_dchi
c_____temporary vectors to increase clarity
      double precision xa,ya,za,xb,yb,zb,xc,yc,zc
      double precision mod_a,mod_b,mod_c,mod_ab,mod_cb

c.....bond forces
      do i=1,n_b
         j1=nbond(i,1)
         j2=nbond(i,2)
         length=bond_l(x(j1),y(j1),z(j1),x(j2),y(j2),z(j2))
         
c.....gradient in the x direction

c_____calculating the ith bond contribution to the gradient
c_____of the two atoms involved in the bond

         bgradx=2*pbond(i,2)*(length-pbond(i,1))*(x(j1) - 
     &        x(j2))/length

         if(iRx(j1).ne.0) fx(j1)=fx(j1) + bgradx
         if(iRx(j2).ne.0) fx(j2)=fx(j2) - bgradx

c.....gradient in the y direction

c_____calculating the ith bond contribution to the gradient
c_____of the two atoms involved in the bond

         bgrady=2*pbond(i,2)*(length-pbond(i,1))*(y(j1) - 
     &        y(j2))/length

         if(iRy(j1).ne.0) fy(j1)=fy(j1) + bgrady
         if(iRy(j1).ne.0) fy(j2)=fy(j2) - bgrady         

c.....gradient in the z direction

c_____calculating the ith bond contribution to the gradient
c_____of the two atoms involved in the bond

         bgradz=2*pbond(i,2)*(length-pbond(i,1))*(z(j1) - 
     &        z(j2))/length

         if(iRz(j1).ne.0) fz(j1)=fz(j1) + bgradz
         if(iRz(j1).ne.0) fz(j2)=fz(j2) - bgradz

      end do

c.....angle forces

      do i=1,n_a

         j1=nangle(i,1)
         j2=nangle(i,2)
         j3=nangle(i,3)

c_____calculating angle

         angle=angle_theta(x(j1),y(j1),z(j1),
     &        x(j2),y(j2),z(j2),  x(j3),y(j3),z(j3))

c_____calculating vectors and magnitudes from the central 
c_____atom to angle forming atoms

         xa=x(j1)-x(j2)
         ya=y(j1)-y(j2)
         za=z(j1)-z(j2)

         xb=x(j3)-x(j2)
         yb=y(j3)-y(j2)
         zb=z(j3)-z(j2)

         mod_a=sqrt(xa*xa + ya*ya + za*za)
         mod_b=sqrt(xb*xb + yb*yb + zb*zb)

         e_by_dtheta=-2*pangle(i,2)*(angle-radians(pangle(i,1)))
     &        /sin(angle)

c.....gradient in the x direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         agrad1=e_by_dtheta*((xb/(mod_a*mod_b))-(cos(angle)*xa/
     &        (mod_a*mod_a)))

         agrad3=e_by_dtheta*((xa/(mod_a*mod_b))-(cos(angle)*xb/
     &        (mod_b*mod_b)))

         if(iRx(j1).ne.0) fx(j1)=fx(j1) + agrad1
         if(iRx(j2).ne.0) fx(j2)=fx(j2) - agrad1 - agrad3   
         if(iRx(j3).ne.0) fx(j3)=fx(j3) + agrad3  

c.....gradient in the y direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         agrad1=e_by_dtheta*((yb/(mod_a*mod_b))-(cos(angle)*ya/
     &        (mod_a*mod_a)))

         agrad3=e_by_dtheta*((ya/(mod_a*mod_b))-(cos(angle)*yb/
     &        (mod_b*mod_b)))

         if(iRy(j1).ne.0) fy(j1)=fy(j1) + agrad1
         if(iRy(j2).ne.0) fy(j2)=fy(j2) - agrad1 - agrad3  
         if(iRy(j3).ne.0) fy(j3)=fy(j3) + agrad3  

c.....gradient in the z direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         agrad1=e_by_dtheta*((zb/(mod_a*mod_b))-(cos(angle)*za/
     &        (mod_a*mod_a)))

         agrad3=e_by_dtheta*((za/(mod_a*mod_b))-(cos(angle)*zb/
     &        (mod_b*mod_b)))

         if(iRz(j1).ne.0) fz(j1)=fz(j1) + agrad1
         if(iRz(j2).ne.0) fz(j2)=fz(j2) - agrad1 - agrad3  
         if(iRz(j3).ne.0) fz(j3)=fz(j3) + agrad3  

      end do

c.....torsion forces

      do i=1,n_t

         j1=ntorsion(i,1)
         j2=ntorsion(i,2)
         j3=ntorsion(i,3)
         j4=ntorsion(i,4)

         torsion=torsion_phi(x(j1),y(j1),z(j1),
     &        x(j2),y(j2),z(j2),
     &        x(j3),y(j3),z(j3),
     &        x(j4),y(j4),z(j4))
         
c.....calculating vectors and magnitudes of vectors that make up
c.....the torsion
      
         xa=x(j1)-x(j2)
         ya=y(j1)-y(j2)
         za=z(j1)-z(j2)

         xb=x(j3)-x(j2)
         yb=y(j3)-y(j2)
         zb=z(j3)-z(j2)

         xc=x(j3)-x(j4)
         yc=y(j3)-y(j4)
         zc=z(j3)-z(j4)

         mod_a=sqrt(xa*xa + ya*ya + za*za)
         mod_b=sqrt(xb*xb + yb*yb + zb*zb)
         mod_c=sqrt(xc*xc + yc*yc + zc*zc)

c_____and the cross product modului

         mod_ab=sqrt((ya*zb-za*yb)**2+(za*xb-xa*zb)**2+(xa*yb-ya*xb)**2)
         mod_cb=sqrt((yc*zb-zc*yb)**2+(zc*xb-xc*zb)**2+(xc*yb-yc*xb)**2)

c_____and the two three body angles

         angle_12=angle_theta(x(j1),y(j1),
     &        z(j1),
     &        x(j2),y(j2),z(j2),
     &        x(j3),y(j3),z(j3))
         angle_23=angle_theta(x(j2),y(j2),
     &        z(j2),
     &        x(j3),y(j3),z(j3),
     &        x(j4),y(j4),z(j4))

c.....calculating the derivative of energy with respect to torsion angle

         e_by_dphi=(ptorsion(i,2)*ptorsion(i,1)*sin((ptorsion(i,2)*
     &        torsion) - radians(ptorsion(i,3))))

c.....gradient in the x direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         if(iRx(j1).ne.0) fx(j1)=fx(j1) + 
     +      e_by_dphi*((ya*zb-za*yb)/(mod_a*mod_ab*sin(angle_12)))
         
         if(iRx(j2).ne.0) fx(j2)=fx(j2) + e_by_dphi*(-1)*
     &        ((((ya*zb-za*yb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12)))) + (cos(angle_23)*
     &        ((yc*zb-zc*yb)/(mod_cb*mod_b*sin(angle_23)))))

         if(iRx(j3).ne.0) fx(j3)=fx(j3) + e_by_dphi*(-1)*
     &        (((yc*zb-zc*yb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((ya*zb-za*yb)/(mod_ab*mod_b*sin(angle_12))))

         if(iRx(j4).ne.0) fx(j4)=fx(j4) + 
     +        e_by_dphi*((yc*zb-zc*yb)/(mod_c*mod_cb*sin(angle_23)))

c.....gradient in the y direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         if(iRy(j1).ne.0) fy(j1)=fy(j1) + 
     +        e_by_dphi*((za*xb-xa*zb)/(mod_a*mod_ab*sin(angle_12)))

         if(iRy(j2).ne.0) fy(j2)=fy(j2) + e_by_dphi*(-1)*
     &        (((za*xb-xa*zb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((zc*xb-xc*zb)/(mod_cb*mod_b*sin(angle_23))))

         if(iRy(j3).ne.0) fy(j3)=fy(j3) + e_by_dphi*(-1)*
     &        (((zc*xb-xc*zb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((za*xb-xa*zb)/(mod_ab*mod_b*sin(angle_12))))

         if(iRy(j4).ne.0) fy(j4)=fy(j4) + 
     +        e_by_dphi*((zc*xb-xc*zb)/(mod_c*mod_cb*sin(angle_23)))

c.....gradient in the z direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         if(iRz(j1).ne.0) fz(j1)=fz(j1) + 
     +        e_by_dphi*((xa*yb-ya*xb)/(mod_a*mod_ab*sin(angle_12)))

         if(iRz(j2).ne.0) fz(j2)=fz(j2) + e_by_dphi*(-1)*
     &        (((xa*yb-ya*xb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((xc*yb-yc*xb)/(mod_cb*mod_b*sin(angle_23))))

         if(iRz(j3).ne.0) fz(j3)=fz(j3) + e_by_dphi*(-1)*
     &        (((xc*yb-yc*xb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((xa*yb-ya*xb)/(mod_ab*mod_b*sin(angle_12))))

         if(iRz(j4).ne.0) fz(j4)=fz(j4) + 
     +        e_by_dphi*((xc*yb-yc*xb)/(mod_c*mod_cb*sin(angle_23)))

      end do

c.....out-of-plane forces

      do i=1,n_o

         j1=noop(i,1)
         j2=noop(i,2)
         j3=noop(i,3)
         j4=noop(i,4)

c.....calculating vectors for out of plane angle

         oop=oop_chi(x(j1),y(j1),z(j1),
     &        x(j2),y(j2),z(j2),
     &        x(j3),y(j3),z(j3),
     &        x(j4),y(j4),z(j4))

c.....calculating vectors and magnitudes of vectors that make up
c.....the torsion
      
         xa=x(j1)-x(j3)
         ya=y(j1)-y(j3)
         za=z(j1)-z(j3)

         xb=x(j4)-x(j3)
         yb=y(j4)-y(j3)
         zb=z(j4)-z(j3)

         xc=x(j4)-x(j2)
         yc=y(j4)-y(j2)
         zc=z(j4)-z(j2)


         mod_a=sqrt(xa*xa + ya*ya + za*za)
         mod_b=sqrt(xb*xb + yb*yb + zb*zb)
         mod_c=sqrt(xc*xc + yc*yc + zc*zc)

c_____and the cross product modului

         mod_ab=sqrt((ya*zb-za*yb)**2+(za*xb-xa*zb)**2+(xa*yb-ya*xb)**2)
         mod_cb=sqrt((yc*zb-zc*yb)**2+(zc*xb-xc*zb)**2+(xc*yb-yc*xb)**2)

c_____and the two three body angles

         angle_12=angle_theta(x(j1),y(j1),
     &        z(j1),
     &        x(j3),y(j3),z(j3),
     &        x(j4),y(j4),z(j4))
         angle_23=angle_theta(x(j3),y(j3),
     &        z(j3),
     &        x(j4),y(j4),z(j4),
     &        x(j2),y(j2),z(j2))

c.....calculating the derivative of energy with respect to oop angle

         e_by_dchi=(poop(i,2)*poop(i,1)*sin((poop(i,2)*
     &        oop) - radians(poop(i,3))))

c.....gradient in the x direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         if(iRx(j1).ne.0) fx(j1)=fx(j1) +
     +        e_by_dchi*((ya*zb-za*yb)/(mod_a*mod_ab*sin(angle_12)))

         if(iRx(j3).ne.0) fx(j3)=fx(j3) + e_by_dchi*(-1)*
     &        ((((ya*zb-za*yb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12)))) + (cos(angle_23)*
     &        ((yc*zb-zc*yb)/(mod_cb*mod_b*sin(angle_23)))))

         if(iRx(j4).ne.0) fx(j4)=fx(j4) + e_by_dchi*(-1)*
     &        (((yc*zb-zc*yb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((ya*zb-za*yb)/(mod_ab*mod_b*sin(angle_12))))

         if(iRx(j2).ne.0) fx(j2)=fx(j2) +
     +        e_by_dchi*((yc*zb-zc*yb)/(mod_c*mod_cb*sin(angle_23)))

c.....gradient in the y direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         if(iRy(j1).ne.0) fy(j1)=fy(j1) +
     +        e_by_dchi*((za*xb-xa*zb)/(mod_a*mod_ab*sin(angle_12)))

         if(iRy(j3).ne.0) fy(j3)=fy(j3) + e_by_dchi*(-1)*
     &        (((za*xb-xa*zb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((zc*xb-xc*zb)/(mod_cb*mod_b*sin(angle_23))))

         if(iRy(j4).ne.0) fy(j4)=fy(j4) + e_by_dchi*(-1)*
     &        (((zc*xb-xc*zb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((za*xb-xa*zb)/(mod_ab*mod_b*sin(angle_12))))

         if(iRy(j2).ne.0) fy(j2)=fy(j2) +
     +        e_by_dchi*((zc*xb-xc*zb)/(mod_c*mod_cb*sin(angle_23)))

c.....gradient in the z direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         if(iRz(j1).ne.0) fz(j1)=fz(j1) +
     +        e_by_dchi*((xa*yb-ya*xb)/(mod_a*mod_ab*sin(angle_12)))

         if(iRz(j3).ne.0) fz(j3)=fz(j3) + e_by_dchi*(-1)*
     &        (((xa*yb-ya*xb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((xc*yb-yc*xb)/(mod_cb*mod_b*sin(angle_23))))

         if(iRz(j4).ne.0) fz(j4)=fz(j4) + e_by_dchi*(-1)*
     &        (((xc*yb-yc*xb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((xa*yb-ya*xb)/(mod_ab*mod_b*sin(angle_12))))

         if(iRz(j2).ne.0) fz(j2)=fz(j2) +
     +        e_by_dchi*((xc*yb-yc*xb)/(mod_c*mod_cb*sin(angle_23)))

      end do

      end
