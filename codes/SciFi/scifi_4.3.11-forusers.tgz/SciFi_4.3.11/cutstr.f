       subroutine CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
c.................................................................
c....It reads the line from the file UNIT=NFIL as a string   .....
c.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
c.... substrings. Their number is NumLin, while starting and .....
c.... ending positions are LinPos and LinEnd.                .....
c.................................................................
c Up to 30 substrings is implied to be in the initial string Line.
c.................................................................
c  If NFIL=0 it is supposed that the string Line*80 exists and
c  must not be read from the external source, but must be taken
c  as an input from the parent program
c.................................................................
c  iErr=1 in the case of error input
c  iErr=2 in the case of end of file
c  iErr=0 otherwise
c.................................................................
c
      character Line*120,cha
      integer LinEnd(30),LinPos(30)
      iErr=0
c
c............ get the line skipping comments
      if(NFIL.ne.0) then
         call SkipL(NFIL,Line,iErr)
         if(iErr.ne.0) return
      end if
      NumLin=0
      icase=0
c............ Loop over all characters in the Line(1:80)............
       do 5 i=1,120
       cha=Line(i:i)
c________ if the 1st not blank character is found
       if(cha.ne.' '.and.icase.eq.0) then
          NumLin=NumLin+1
          if(NumLin.gt.30) go to 10
          LinPos(NumLin)=i
          icase=1
       end if
c_________ if the 1st blank character is found after the substring
       if(cha.eq.' '.and.icase.eq.1) then
          LinEnd(NumLin)=i-1
          icase=0
       end if
 5     end do
       if(icase.eq.1) LinEnd(NumLin)=120
       return
10     iErr=1
       return
       end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine AtLabel(Line,iLi,na2,nzvn3,j,iErr)
c.......................................................................
c       The program correctly gives the atomic label analyzing the     .
c       string Line*iLi. It puts the atomic name to na2, while         .
c       the atomic 3rd index - to nzvn3. Besides, the Mendeleev's      .
c       atomic number j is found.                                      .
c.......................................................................
c       iErr=1 in the case of an incorrect input; otherwise iErr=0     .
c.......................................................................
c ****  This is an OLD version, not presntly used. ****
c.......................................................................
      INCLUDE 'shell.inc'
      character Line(iLi)*1,na2*2,nzvn3*1
 
      if(iLi.eq.1) then
          na2=' '//Line(1)
          nzvn3=' '
      else if(iLi.eq.2) then
          na2=Line(1)//Line(2)
          nzvn3=' '
      else if(iLi.eq.3) then
          na2=Line(1)//Line(2)
          nzvn3=Line(3)
      else
          go to 100
      end if
c...... recognizes the atom among all available in the Mendeleev's table
      do J1=1,82
      if(na2.eq.nazv(J1)) then
         j=J1
         go to 2
      end if
      end do
c......... if not, tries one special case for the atomic label
      if(iLi.eq.2) then
         na2=' '//Line(1)
         nzvn3=Line(2)
         do J1=1,82
            if(na2.eq.nazv(J1)) then
               j=J1
               go to 2
            end if
         end do
      end if
      if(iLi.eq.1.and.na2.eq.' *') then
         j=100
         go to 2
      end if
      goto 100
2     iErr=0
      return
c_ _ _ _ _ the atomic label was not recognized  !
100   iErr=1
      return
      end

      subroutine AtLabel_m(Line1,l1,l2,na2,nzvn3,j,iErr)
c.......................................................................
c       The program correctly gives the atomic label analyzing the     .
c       string Line1*iLi. It puts the atomic name to na2, while         .
c       the atomic 3rd index - to nzvn3. Besides, the Mendeleev's      .
c       atomic number j is found.                                      .
c.......................................................................
c       iErr=1 in the case of an incorrect input; otherwise iErr=0     .
c.......................................................................
c modified 17.11.2004 to match strings at the call (Intel complained)
c This is the replacement for Atlabel().
c.......................................................................
      INCLUDE 'shell.inc'
      character Line(120),na2*2,nzvn3,Line1*120

      j=0
      do i=l1,l2
         j=j+1
         Line(j)=Line1(i:i)
      end do
      iLi=l2-l1+1

      if(iLi.eq.1) then
          na2=' '//Line(1)
          nzvn3=' '
      else if(iLi.eq.2) then
          na2=Line(1)//Line(2)
          nzvn3=' '
      else if(iLi.eq.3) then
          na2=Line(1)//Line(2)
          nzvn3=Line(3)
      else
          go to 100
      end if
c...... recognizes the atom among all available in the Mendeleev's table
      do J1=1,82
         if(na2.eq.nazv(J1)) then
            j=J1
            go to 2
         end if
      end do
c......... if not, tries one special case for the atomic label
      if(iLi.eq.2) then
         na2=' '//Line(1)
         nzvn3=Line(2)
         do J1=1,82
            if(na2.eq.nazv(J1)) then
               j=J1
               go to 2
            end if
         end do
      end if
      if(iLi.eq.1.and.na2.eq.' *') then
         j=100
         go to 2
      end if
      goto 100
2     iErr=0
      return
c_ _ _ _ _ the atomic label was not recognized  !
100   iErr=1
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine atom_type(Line,LinPos,LinEnd,i,iErr)
      include 'shell.inc'
      character Line*120,na3*3,na2*2,cha
      iErr=0
      call AtLabel_m(Line,LinPos,LinEnd,na2,cha,j,iErr)
      if(iErr.eq.1) go to 1
      na3=na2//cha     !na3 is the name of element
      do k1=1,KINDS
         if(na3.eq.Species(k1)) then   
            i=k1
            return
         end if
      end do
 1    WRITE(9,'(a/)')'FATAL! Species '//na3// ' not identified!!'
      WRITE(*,*)     'FATAL! Species '//na3// ' not identified!!'
      iErr=1
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine SkipL(NFIL,Line,iErr)
c.......................................................................
c...... Program skips all "empty" string containing comments, etc.......
c...... All lines, containing **,--,==,*- and -* symbols are     .......
c...... recognized as the comments lines and are skipped. The    .......
c...... driver is set up at the beginning of the first "nonempty".......
c...... record                                                   .......
c.......................................................................
c  iErr=1 in the case of error input
c  iErr=2 in the case of end of file
c  iErr=0 otherwise
c.................................................................
c
      parameter (nComm=6)
      character Line*120,Comm(nComm)*2
      data Comm/'*-','-*','--','==','**','##'/
c.......... read the current line from the driver NFIL
1     read (NFIL,'(a)',err=10,end=20) Line
c_________ analyze Line if it is empty
      if(Line(1:1).eq.CHAR(0)) go to 1
c_________ analyze Line if it is filled by simple blanks
        do i=1,120
        if(Line(i:i).ne.CHAR(0).and.Line(i:i).ne.' ') go to 2
        end do
      go to 1
c_________ analyze Line for the comment symbols; in the case if any
c          one from the list Comm() was found it reads the next line
2       do i=1,nComm
        i0=INDEX(Line,Comm(i))
        if(i0.ne.0) go to 1
        end do
      iErr=0
      return
c......... in the case of an error
10    iErr=1
      return
 20   iErr=2
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine find_string(string,l,NFIL,iErr)
      character*(*) string
      character line*120
      logical memo
c
      iErr=0
 10   read (NFIL,'(a)',END=40,ERR=40) Line
      i0=index(Line,string(1:l))
      if(i0.eq.0) go to 10
      write(9,'(/a)')
     & '.........O.K.! String '//string(1:l)//' is found !!! .........'
      return
 40   iErr=1
      write(9,'(/a)')
     & '.........BAD! String '//string(1:l)//' NOT found !!! .........'
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine right(char,len,len00)
      character*(*)  char
      do i=len,1,-1
         j=i
         if(char(i:i).ne.' ') go to 1
      end do
 1    jj=len-j
      do i=j,1,-1
         char(jj+i:jj+i) = char(i:i)
      end do
      do i=1,jj
         char(i:i)=' '
      end do
      len00=jj+1
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc


      subroutine print_6(x,y,z,Natom,Shell_Ref,iShell,ISRT,iRx,iRy,iRz)
c...................................................................
c prints out x,y,z in 6 columns (either cooordinates or gradients)
c...................................................................
      include 'param.inc'
      dimension x(N0CH),y(N0CH),z(N0CH),iRx(N0CH),iRy(N0CH),iRz(N0CH)
      dimension ISRT(N0LT),iShell(N0LT)
      logical Shell_Ref(N0KD)
      character cha(3)
      data cha/'F','R','C'/

      do i=1,Natom
         is=ISRT(i)
         if(Shell_Ref(is)) then 
            j=iShell(i)
            write(9,'(2(a3,i5,3(x,e12.6),3x))') 
     &           cha(iRx(i)+1)//cha(iRy(i)+1)//cha(iRz(i)+1),
     &           i,x(i),y(i),z(i),
     &           cha(iRx(j)+1)//cha(iRy(j)+1)//cha(iRz(j)+1),
     &           j,x(j),y(j),z(j)
         else
            write(9,'(a3,i5,3(x,e12.6))') 
     &           cha(iRx(i)+1)//cha(iRy(i)+1)//cha(iRz(i)+1),
     &           i,x(i),y(i),z(i)
         end if
      end do
      return
      end


