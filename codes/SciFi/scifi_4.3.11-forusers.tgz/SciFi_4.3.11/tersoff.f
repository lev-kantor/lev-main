      double precision function tersoff_energy()
c---------11.03.05 --------------------------------------------------
c....................................................................
c   Calculation of energies and forces using Tersoff semiclassical 
c potential
c....................................................................
c xr(),yr(),zr() - working arrays for coordinates
c....................................................................
      include 'tersoff.inc'
      integer is,js,ks
      
c........... create atomic positions in an extended latice
      call create_surrounding(Natoms_sur)

c........... recalculate the neighbours
      iErr=0
      if(nstep/nn_list_howoften*nn_list_howoften.eq.nstep) then
         call neighbour(Natoms_sur,'tf',iErr)
         if(iErr.eq.1) stop 'Tersoff_energy: too many neighbours'
      end if
c........... get the energy
      tersoff_energy = tersoff_en()
      write(9,'(a, f12.5,a)')'ENERGY: ',tersoff_energy, ' au'
      write(9,'(a, f12.5,a)')'ENERGY: ',tersoff_energy*au_eV, ' eV'
      end

      double precision function tersoff_en()
      include 'tersoff.inc'
      E=0.0d0
      DO i=1,Natom    
         if(.not.central_atom(i) .or. nnn(i).eq.0) go to 100
         is=ISRT(i)
         if(SpecType(is).ne.'tf') go to 100

         do j1=1,nnn(i)
            j=bond(i,j1)
            js=ISRT_sur(j)
            
            R_ij = dist(xr(i),yr(i),zr(i),xr(j),yr(j),zr(j)) 
            if(R_ij.gt.Pair_dist_max) go to 50
            call b_tersf(i,is,j,js,R_ij,dzeta,b_ij)
            FC_ij=fc_func(R_ij,is,js)
            
            FR_ij=AA(is,js)*exp(-lam1(is,js)*R_ij)
c            write(9,'(2i2,2(x,e14.8))') is,js,AA(is,js),lam1(is,js)
            FA_ij=BB(is,js)*exp(-lam2(is,js)*R_ij)
c            write(9,'(2i2,2(x,e14.8))') is,js,BB(is,js),lam2(is,js)
            
            Vij=FC_ij * (FR_ij - b_ij*FA_ij)
c            write(9,'(2i4,6(x,e14.8))') 
c     &           i,j1,R_ij,FC_ij,FR_ij,FA_ij,dzeta,b_ij
            E=E+Vij
 50      end do                 !j-loop
 100  END DO                    !i-loop
      tersoff_en=E*0.5   
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine tersoff_force()
c............................................................................
c   Calculation of forces using Tersoff semiclassical potential
c............................................................................
c   Uses coordinates xr(),yr(),zr() and Tersoff parameters defined in or read 
c   using the Tersoff subroutine of inval.f
c............................................................................
c   Calculates the derivative of Tersoff's energy (and all functions included
c   in this energy expression)
c   NB all functions that have "1" after the name of the function mean a first 
c   derivative of this function. E.g. "zeta1" means the first derivative of zeta. 
c   More exactly, zeta1i(dir) (dir=1,2 or 3) means the first derivative of zeta 
c   by the x, y, or z displacement of atom i.
c............................................................................
c   Output: fx(i),fy(i),fz(i) -- forces acting on atom i in x, y, z directions
c............................................................................
      include 'tersoff.inc'
      dimension grad(N0LT,3)
      data step1/0.0001/

c........... create atomic positions in an extended latice
      call create_surrounding(Natoms_sur)

c........... recalculate the neighbours
      iErr=0
      if(nstep/nn_list_howoften*nn_list_howoften.eq.nstep) then
         call neighbour(Natoms_sur,'tf',iErr)
         if(iErr.eq.1) stop 'Tersoff_energy: too many neighbours'
      end if

c........... force on atom i
      
      do i=1,Natom
         is=ISRT(i)
         if(SpecType(is).ne.'tf') go to 100
         if(central_atom(i) .and. nnn(i).ne.0) then
c_______________ along X
            if(iRx(i).eq.1) then
               c0=xr(i)
               call shift_coord(i,1,c0,step1,Natoms_sur)
               e1=tersoff_en()
               call shift_coord(i,1,c0,-step1,Natoms_sur)
               e2=tersoff_en()
               call shift_coord(i,1,c0,0.0d0,Natoms_sur)
               fx(i)=(e1-e2)/(2*step1)
            end if
c_______________ along Y
            if(iRy(i).eq.1) then
               c0=yr(i)
               call shift_coord(i,2,c0,step1,Natoms_sur)
               e1=tersoff_en()
               call shift_coord(i,2,c0,-step1,Natoms_sur)
               e2=tersoff_en()
               call shift_coord(i,2,c0,0.0d0,Natoms_sur)
               fy(i)=(e1-e2)/(2*step1)
            end if
c_______________ along Z
            if(iRz(i).eq.1) then
               c0=zr(i)
               call shift_coord(i,3,c0,step1,Natoms_sur)
               e1=tersoff_en()
               call shift_coord(i,3,c0,-step1,Natoms_sur)
               e2=tersoff_en()
               call shift_coord(i,3,c0,0.0d0,Natoms_sur)
               fz(i)=(e1-e2)/(2*step1)
            end if
         end if
 100  end do
      end

c...............................................................................
c.................... SUBROUTINES & FUNCTIONS...................................
c...............................................................................

      double precision function fc_func(r,is,js)  
c....... Fc(r) in Tersoff formula
      include 'tersoff.inc'
      Rpar=RR(is,js)
      Dpar=DD(is,js)
      if(r.gt.(Rpar+Dpar))then
         fc_func=0.0
      else if (r.lt.(Rpar-Dpar))then
         fc_func=1.0
      else
         fc_func=0.5*(1-sin(pi/2*(r-Rpar)/Dpar))
      endif
      end

      subroutine vect(i,j,rij,vec)
c...............................................................
c  unit vector e_ij and the distance rij between i and j
c  from the extended list
c...............................................................
      include 'shell.inc'
      dimension vec(3)
      vec(1)=xr(i)-xr(j)
      vec(2)=yr(i)-yr(j)
      vec(3)=zr(i)-zr(j)
      rij=sqrt( vec(1)*vec(1)+vec(2)*vec(2)+vec(3)*vec(3) )
      vec(1)=vec(1)/rij         
      vec(2)=vec(2)/rij         
      vec(3)=vec(3)/rij         
      end
     
      subroutine b_tersf(i,is,j,js,R_ij,dzeta,b)
c...............................................................
c  b_ij is calculated
c...............................................................
      include 'tersoff.inc'

c.......... dzeta_ij is calculated first
      dzeta=0.0
      do k1=1,nnn(i)            
         k=bond(i,k1)
         if(k.eq.j)  goto 20
         ks=ISRT_sur(k)

         R_ik = dist(xr(i),yr(i),zr(i),xr(k),yr(k),zr(k)) 
         if(R_ik.gt.Pair_dist_max) go to 20
         R_jk = dist(xr(j),yr(j),zr(j),xr(k),yr(k),zr(k)) 
         
         FC_ik=fc_func(R_ik,is,ks)
         
         costh = (R_ij*R_ij+R_ik*R_ik-R_jk*R_jk)/(2*R_ij*R_ik)

         g_ijk = 1+(c_ters(is)/d_ters(is))**2 - c_ters(is)*c_ters(is)/
     /    (d_ters(is)*d_ters(is)+(h_ters(is)-costh)*(h_ters(is)-costh))

         a=lam3(is,js,ks)*(R_ij-R_ik)
         dzeta=dzeta + FC_ik*g_ijk*exp(a*a*a)
 20   end do

c.......... now b_ij
      b=xi(is,js)*(1.+(beta_ters(is)*dzeta)**nb(is))**(-0.5/nb(is))   
      end    

      subroutine shift_coord(i,j,c0,step,Natoms_sur)
c.................................................................
c  coordinate j=1,2,3 of atom i, currently at c0, is shifted by 
c  [step] together with all its images in the extended system
c.................................................................
      include 'tersoff.inc'
      if(j.eq.1) then
         xr(i)=c0+step
      else if(j.eq.2) then
         yr(i)=c0+step
      else 
         zr(i)=c0+step
      end if
      if(system_type.eq.'cluster') then
         return
      else if(system_type.eq.'   bulk') then
         ii=Ref_sur(i)-1
         do i1=-1,1
            do i2=-1,1
               do i3=-1,1
                  if(i1.ne.0 .or. i2.ne.0 .or. i3.ne.0) then
                     ii=ii+1
                     if(j.eq.1) then
                        xr(ii)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+xr(i)
                     else if(j.eq.2) then
                        yr(ii)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+yr(i)
                     else 
                        zr(ii)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+zr(i)
                     end if
                  end if
               end do
            end do
         end do
      else if(system_type.eq.'surface') then
         ii=Ref_sur(i)-1
         do i1=-1,1
            do i2=-1,1
               if(i1.ne.0 .or. i2.ne.0) then
                  ii=ii+1
                  if(j.eq.1) then
                     xr(ii)=i1*AJ(1,1)+i2*AJ(2,1)+xr(i)
                  else if(j.eq.2) then
                     yr(ii)=i1*AJ(1,2)+i2*AJ(2,2)+yr(i)
                  else 
                     zr(ii)=i1*AJ(1,3)+i2*AJ(2,3)+zr(i)
                  end if
               end if
            end do
         end do
      end if
      end

