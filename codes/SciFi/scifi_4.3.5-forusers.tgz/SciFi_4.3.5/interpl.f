      double precision function interpl(x,y,nx,xx)
c.........................................................................
c        Here we do interpolation of the force at xx using the data points
c [zf(i),Frc(i)].
c.........................................................................
      include 'real8.inc'
      dimension x1(4),y1(4),x(nx),y(nx)
      data tiny/0.001/
c
c............. prepare data for the interpolation/extrapolation
c
      ym=0.0
      n=3
      if(xx.lt.x(2)) then
c___________ xx < x(2) : extrapolation here using 3 points
        do i=1,n
          x1(i)=x(i)
          y1(i)=y(i)
          y2=abs(y1(i))
          if(y2.gt.ym) ym=y2
        end do
c___________ xx >= x(2) and xx <= x(nx-1) : we use 4 points around
      else if(xx.ge.x(2) .and. xx.le.x(nx-1)) then
        do i=2,nx-2
          if(xx.ge.x(i) .and. xx.le.x(i+1)) go to 10
        end do
 10     n=4
        do j=1,n
          x1(j)=x(i-2+j)
          y1(j)=y(i-2+j)
          y2=abs(y1(j))
          if(y2.gt.ym) ym=y2
        end do
c___________  x(nx-1) < xx <= x(nx) : extrapolation here using 3 pints
      else if(xx.gt.x(nx-1) .and. xx.le.x(nx)) then
        do j=1,n
          x1(j)=x(nx-3+j)
          y1(j)=y(nx-3+j)
          y2=abs(y1(j))
          if(y2.gt.ym) ym=y2
        end do
      end if
c
c__________ do the interpolation
      pres=0.1*ym
      call polint(x1,y1,n,xx,yy,dy)
      interpl=yy
      if(abs(dy).gt.pres) go to 200
      return
c...........error
 200  write(*,'(a,e12.6,a,e12.6)')
     &      'FATAL! Failure in extrapolation: |dy|=',abs(dy),'> y2=',y2
      write(*,*)'data points are:'
      do i=1,n
         write(*,'(i5,x,3(e12.6,x))') i,x1(i),y1(i)
      end do
      write(*,*)'attempting to extrapolate at x = ',xx
      write(*,*)'with the result y = ',yy
      stop
      end  

      subroutine polint(xa,ya,n,x,y,dy)
c.....................................................................
c      It does a polynomial interpolation at x (the result is y) being
c given a set of n points [xa(i),ya(i)]. The interpolation error is dy.
c.....................................................................
      include 'real8.inc'
      parameter (NMAX=10)
      dimension xa(n),ya(n),c(NMAX),d(NMAX)
c      write(*,*)'x= ',x
c      do i=1,n
c         write(*,*) i,xa(i),ya(i)
c      end do
      if(n.gt.NMAX) then
        write(*,'(a,i3)')'FATAL! In polint.f: cannot handle n>',NMAX
        stop
      end if
      ns=1
      dif=abs(x-xa(1))
      do 11 i=1,n
        dift=abs(x-xa(i))
        if (dift.lt.dif) then
          ns=i
          dif=dift
        endif
        c(i)=ya(i)
        d(i)=ya(i)
11    continue
      y=ya(ns)
      ns=ns-1
      do 13 m=1,n-1
        do 12 i=1,n-m
          ho=xa(i)-x
          hp=xa(i+m)-x
          w=c(i+1)-d(i)
          den=ho-hp
          if(den.eq.0.) then
            write(*,'(a,i3)')'FATAL! Failure in polint'
            stop
          end if
          den=w/den
          d(i)=hp*den
          c(i)=ho*den
12      continue
        if (2*ns.lt.n-m)then
          dy=c(ns+1)
        else
          dy=d(ns)
          ns=ns-1
        endif
        y=y+dy
13    continue
c      write(*,*)'answer: y= ',y
      return
      END
