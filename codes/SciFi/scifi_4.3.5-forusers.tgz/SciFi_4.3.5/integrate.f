      subroutine integrate_all(t,if_forces,Prt,when_prt,istage)
      include 'virtual.inc'
      include 'noise.inc'
c........................................................................
c  istage - current elementary stage
c........................................................................
c  One iteration timestep t for electronics (including ADC) and tip.
c     AGC    - if .true., then the amplitude control is ON
c     ADC    - if .true., then the distance control is ON
c     excite - if .true., excitation signal is added to the
c              equation of motion of the tip
c  if_forces - if .true., tip force is ON
c........................................................................
c     Prt    - if .true., then most of the stuff is printed out
c               (useful for test/debugging).
c   when_prt - how often to print 
c........................................................................
c  tip_surface_force(dist) - external routine to calculate the force
c                            at distance dist between tip and surface.
c........................................................................
      logical Prt,if_forces
      integer t,when_prt

      t=t+1
      Top=.false.
c......... prepare noise vectors
      if(NoiseF.or.NoiseA) then
         Unoise=Unoise+1
         if (Unoise .ge. long) then
            if(NoiseF) call gauss(bruitF,long)
            iF(NoiseA) call gauss(bruitA,long)
            Unoise=1
         end if
      end if
c.........and get the noise
      if(NoiseF) Fnoise=dble(bruitF(Unoise))*SDF
      if(NoiseA) Znoise=dble(bruitA(Unoise))*SDA

c......... Automatic Distance Control (ADC) 
c          DISTA - new distance 
      if(ADC) then
         Nadc= Nadc + Iadc*(DFC-DEF)*dt
         DISTA = D1 + Padc*(DFC-DEF) + Nadc
      end if

c......... the VERLET procedure (in fact, this is the "Velocity Verlet"
c          version by Swope, Andersen, Berens, Wilson 1982)

      Znew = Zold + dt*Vold + 0.5d0*ACC*dt*dt
      Vnew=Vold + 0.5d0*ACC*dt

c......... iterate all the electronics involved
      call iterate_electronics(t,Znoise)

c......... move the tip laterally
      XY(1)=XY(1)+Vx*dt
      XY(2)=XY(2)+Vy*dt

c......... calculate the tip-surface force  at height DIST
c          and lateral position r(xy)
      if(if_forces) then
         DIST=DISTA+Znew
         ftip=tip_surface_force(DIST)
      else
         ftip=0.0d0
      end if
          
c.......... calculate the excitation signal
      if(excite) then
         excite1=(R/mass)*sinPLL
      else
         excite1=0.0d0
      end if

c.......... update acceleration and velocity
      ACC = excite1 - gamma*Vnew - Znew*w02 +(ftip+Fnoise)/mass
      Vnew=Vnew + 0.5d0*ACC*dt

c.......... check if at the upper point of the oscillation cycle
c           and do a nice printout
      if((Zold .gt. Zprv) .and. (Zold .gt. Znew) .and. istage.ge.3) then
         Top=.true.
         n_of_oscil=n_of_oscil+1
         if(n_of_oscil/tRes*tRes.eq.n_of_oscil) call dump(istage)
      end if

c.......... collect the "backward" setting
      Vold=Vnew
      Zprv=Zold
      Zold=Znew
      DISTAold=DISTA

c.......... print: debugging only
c           ds - distance of closest approach 
      if( Prt .and. (t/when_prt*when_prt.eq.t) ) then
         zt=Znew*m_A
         ds=(DISTA-MODUL)*m_A
         fs=ftip*N_eVpA
         if(istage.eq.1) then
            write(17,'(i10,8(x,e12.6))') 
     &           t,zt,ACC,Vnew,DEF,sinPLL,at_new
         else if(istage.eq.2) then
            write(17,'(i10,8(x,e12.6))') t,zt,excite1,DEF
         else 
            write(17,'(i10,8(x,e12.6))') 
     &           t,zt,excite1,DEF,ds,fs,DISTA*m_A,MODUL*m_A
         end if
      end if
      return
      end

      subroutine iterate_electronics(t,Znoise)
      include 'virtual.inc'
c........................................................................
c  One iteration timestep t for electronics excluding ADC.
c........................................................................
      integer t

c[1]......... Lock-in of the PLL [always ON]

c______________  Multiplier
      pt_new=(Znew+Znoise)/A0 * Zrefcos
         
c______________ Low-Pass Filter 1
      p1t_new = exp1*p1t_old + 0.5*dt/tau1*(exp1*pt_old+pt_new)
c______________ Low-Pass Filter 2
      ut_new = exp2*ut_old + 0.5*dt/tau2*(exp2*p1t_old+p1t_new)
         
c_________________ frequency shift from the low-pass filter
      DEF=ut_new * gainPB*K1
         
c_________________ into the VCO
      fref=f0+DEF
      Iphy=dmod(Iphy+fref*dt,1.d0)
      Zrefcos=dcos(twopi*Iphy)
      Zrefsin=dsin(twopi*Iphy)
c_________________ into the phase shifter : sinPLL=sin(Wref*t+Phase)
      sinPLL=Zrefsin*cosphy+Zrefcos*sinphy
         
c[2].......... Peak detection 
      Dnew=dabs(Znew+Znoise)
c_________________ Low-Pass Filter
      at_new = expD*at_old + 0.5*dt/tauD*(expD*Dold +Dnew)

c[3].......... AGC: calculate the damping (once in a period)

      if(t.gt.2 .and. AGC) then
         if ((Zold .gt. Zprv) .and. (Zold .gt. Znew)) then
            MODUL=at_new*pi/2.d0
            N = N + I_AGC*(MODUL-A0)/fref
            R = P_AGC*(MODUL-A0) + N
         end if
      end if

c[4].......... collect all the "backward" settings
      pt_old=pt_new
      p1t_old=p1t_new
      ut_old=ut_new
      Dold=Dnew
      at_old=at_new

      return
      end

      subroutine dump(istage)
c...................................................................
c dumps important output into a file
c...................................................................
      include 'virtual.inc'
      include 'stages.inc'
      
c________ dissipatin energy per one cycle (in eV)
      Pdiss=-Rinf*MODUL*pi*fref*(R/Rinf - fref/fref0)*J_eV
      Ediss=Pdiss/fref
c________distance of closest approach (topology image, in A)
      ds=(DISTA-MODUL)*m_A

c________ write in the case of a 2D scan
      if(scan_no(istage).ne.0) then
         write(19,'(6(x,e12.6))') 
     &     XY(1)*m_A,XY(2)*m_A,MODUL*m_A,DEF,Ediss,ds
      end if

c________ write in all cases into a single file
      write(15,'(i10,6(x,e12.6))') 
     &     n_of_oscil,XY(1)*m_A,XY(2)*m_A,MODUL*m_A,DEF,Ediss,ds
      return
      end
