      double precision function energy_qmc(R,iPrnt)
c....................................................................
c    calculates that part of the energy at the point R which does not
c    enter the g98 energy. This is therefore only self-energy of the
c    environment and QC-environment short-range energy.
c....................................................................
c r() - 1-dim vectror of all coordinates
c x(),y(),z() - working arrays for coordinates
c....................................................................
      include 'shell.inc'
      dimension R(N0FR)
      double precision image_get_energy
      logical fatal,catch_fatal
c
c........... convert to x,y,z
c
      if(nid.eq.0.and.iPrnt.ge.10) write(9,*)'... converting 1 to 3 ...'
      call conv_1_3(R,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,                  n_pos_cor,iRx,iRy,iRz)
c
c...............................................................
c........... calculate energy: double loop over all atomic pairs
c...............................................................
c
      short12=0.0d0
      short2=0.0d0
      sprn2=0.0d0
      coul2=0.0d0
      do i=1,Natom
         is=ISRT(i)

c.............. add springs

         if(Shell_Ref(is).and.(.not.iQMC(i))) then
            j=iShell(i)
            d_cs=dist(x(i),y(i),z(i),x(j),y(j),z(j))
            spr=0.5*Spring(is)*d_cs*d_cs
            sprn2=sprn2+spr
            if(nid.eq.0.and.iPrnt.ge.10) then
               write(9,'(2(a,i3))')' spring of i=',i,' with j=',j
               write(9,'(3(x,f10.5))') d_cs,spr,sprn2
            end if
         end if

c.............. add Coulomb and short-range with others

         do 100 ii=1,i
            iis=ISRT(ii)
            if(i.eq.ii) go to 100
            if(iQMC(i).and.iQMC(ii)) go to 100

            if(nid.eq.0.and.iPrnt.ge.10) 
     &           write(9,'(a,2i5)') ' pair i,ii= ',i,ii

c_______________ if both i,ii have shells
            if(Shell_Ref(is) .and. Shell_Ref(iis) ) then
               j=iShell(i)
               jj=iShell(ii)
               d_ss=dist(x(j),y(j),z(j),x(jj),y(jj),z(jj))
               if((.not.iQMC(i)).and.(.not.iQMC(ii))) then
                  d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
                  d_cs=dist(x(i),y(i),z(i),x(jj),y(jj),z(jj))
                  d_sc=dist(x(j),y(j),z(j),x(ii),y(ii),z(ii))
                  coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
                  coul_cs=CoreQA(is)*ShellQA(iis)/d_cs
                  coul_sc=ShellQA(is)*CoreQA(iis)/d_sc
                  coul_ss=ShellQA(is)*ShellQA(iis)/d_ss
                  coul2=coul2+coul_cc+coul_cs+coul_sc+coul_ss
                  short2=short2 + Pot(is,iis,d_ss)
               else
                  short12=short12 + Pot(is,iis,d_ss)
               end if
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a,2i5,a,2(l,x))') 'both shells j,jj= ',
     &                 j,jj,' QMC => ',iQMC(i),iQMC(ii)
                  write(9,'(6(x,f10.5))') d_ss,short2,coul2,short12
               end if

c_______________ if only i has a shell
            else if(Shell_Ref(is)) then 
               j=iShell(i)
               d_sc=dist(x(j),y(j),z(j),x(ii),y(ii),z(ii))
               if((.not.iQMC(i)).and.(.not.iQMC(ii))) then
                  d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
                  coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
                  coul_sc=ShellQA(is)*CoreQA(iis)/d_sc
                  short2= short2 + Pot(is,iis,d_sc)
                  coul2=coul2+coul_cc+coul_sc
               else
                  short12= short12 + Pot(is,iis,d_sc)
               endif
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a,i5,a,2(l,x))') 
     &                 'i has shell j= ',j,' QMC => ',iQMC(i),iQMC(ii)
                  write(9,'(6(x,f10.5))') d_sc,short2,coul2,short12
               end if

c_______________ if only ii has a shell
            else if(Shell_Ref(iis)) then 
               jj=iShell(ii)
               d_cs=dist(x(i),y(i),z(i),x(jj),y(jj),z(jj))
               if((.not.iQMC(i)).and.(.not.iQMC(ii))) then
                  d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
                  coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
                  coul_cs=CoreQA(is)*ShellQA(iis)/d_cs
                  short2=short2 + Pot(is,iis,d_cs)
                  coul2=coul2+coul_cc+coul_cs
               else
                  short12=short12 + Pot(is,iis,d_cs)
               endif
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a,i5,a,2(l,x))') 
     &               'ii has shell jj= ',jj,' QMC => ',iQMC(i),iQMC(ii)
                  write(9,'(6(x,f10.5))') d_cs,short2,coul2,short12
               end if

c_______________ if both do not have shells
            else
               d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
               if((.not.iQMC(i)).and.(.not.iQMC(ii))) then
                  coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
                  short2=short2 + Pot(is,iis,d_cc)
                  coul2=coul2+coul_cc
               else
                  short12=short12 + Pot(is,iis,d_cc)
               end if
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(2a,2(l,x))') 'both i,ii do not have shells',
     &               ' QMC => ',iQMC(i),iQMC(ii)
                  write(9,'(6(x,f10.5))') d_cc,short2,coul2,short12
               end if
            end if

 100     continue
      end do


c_________________ contribution from IMAGE.
c             MIND: since here the Quantum Cluster is on (exist_QC=.true.),
c                   the image energy from <image_get_energy> will contain
c                   only part of the total image energy which is consistent 
c                   with the shell-model part
      if(Do_Image) then
         call image_input(.false.,.false.,.true.)
         
         call system('image > out')
         fatal=catch_fatal('out',3)
         if(fatal) then
            write(*,*)'FATAL! fatal error in IMAGE. Stop in energy.'
            stop
         end if
         en_image= image_get_energy(iPrnt)
      else
         en_image=0.0d0
      end if

c_________________ total energy
      energy_qmc=(coul2+short2+sprn2)+en_image+short12

      if(nid.eq.0.and.iPrnt.ge.5) then
         write(9,'(/a,e16.10)')'ENV.: Coulomb energy (au)     = ',coul2
         write(9,'(a,e16.10)') 'ENV.: Short-range energy (au) = ',short2
         write(9,'(a,e16.10)') 'ENV.: Spring energy (au)      = ',sprn2
         write(9,'(a,e16.10)') 'QMC-ENV.: Short-range energy (au) = ',
     ,                                                           short12
         if(Do_Image) write(9,'(a,e16.10)') 
     &                   'QMC-ENV.: Image energy (au)       = ',en_image
      end if
      if(nid.eq.0) then
         write(9,'(/a,e16.10)') 'QMC: Total energy (au) = ',energy_qmc
         write(9,'(a,e16.10/)') 
     &                      'QMC: Total energy (eV) = ',energy_qmc*au_eV
         write(6,'(a,e16.10/)') 
     &                      'QMC: Total energy (eV) = ',energy_qmc*au_eV
      end if
      return
      end
