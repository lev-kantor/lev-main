      subroutine in_par(NFIL,iPrnt,iErr)
c...............................................................
c     subroutine to read in parameters from a cvff force       .
c     field file and assign them to the parameter arrays       .
c                                                              .
c     returns iErr=1 if input error                            .
c...............................................................
      include 'shell.inc'

      iErr=0
      if(n_b.gt.0) call in_par_bond(NFIL,iErr)
      if(n_a.gt.0) call in_par_angle(NFIL,iErr)
      if(n_t.gt.0) call in_par_torsion(NFIL,iErr)
      if(n_o.gt.0) call in_par_oop(NFIL,iErr)
      if(iErr.eq.1) then
         do_mbody=.false.
         write(9,*) 
     &     'ERROR in reading parameters for the MANY-BODY interaction!'
      end if
      write(9,'(a/)')
     &'################################################################'
      end

      subroutine in_par_bond(NFIL,iErr)
c...............................................................
c     subroutine to read in morse bond parameters from         .
c     the force field file attached to unit NFIL and to match  .
c     them with the terms contained in the nbond array, they   .
c     are then passed to the pbond array with the same index   .
c                                                              .
c     returns iErr=1 if parameters not read correctly          .
c...............................................................
      include 'shell.inc'
      integer foundb
      integer NumLin
      integer at1,at2,st1,st2
      character line*120,na2*2
      character dmmy(200)
      integer LinPos(30),LinEnd(30)

      numpar_b=0

c.....read in parameters from file

      rewind (NFIL)
      call find_string('.<quadratic_bond>',17,NFIL,iErr)
      if(iErr.eq.1) return
      
      jj=0
 30   call CutStr(line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(line(1:6).eq.'.<End>') go to 10
      jj=jj+1

c_______________ read the two species
      read(Line(LinPos(1):LinEnd(1)),*,err=5) bond_at(jj,1)
      call atom_type(Line,LinPos(1),LinEnd(1),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      read(Line(LinPos(2):LinEnd(2)),*,err=5) bond_at(jj,2)
      call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5

      call AtLabel_m(Line,LinPos(1),LinEnd(1),na2,dmmy(jj),
     &     bondpar(jj,1),iErr)
      call AtLabel_m(Line,LinPos(2),LinEnd(2),na2,dmmy(jj),
     &     bondpar(jj,2),iErr)
      read(line(LinPos(3):LinEnd(3)),*,err=5) r0(jj)
      read(line(LinPos(4):LinEnd(4)),*,err=5) k0(jj)
      numpar_b=numpar_b+1
      go to 30

 5    write(9,'(a,i5)') 'ERROR when reading line ',jj
      iErr=1
 10   write(9,'(a)') '...End of quadratic bond box found...'

c.....match parameters to terms in nbond array
c_____loop over all terms in the nbond array

      foundb=0
      do ii=1,n_b
         at1=NATM(ISRT(nbond(ii,1)))
         at2=NATM(ISRT(nbond(ii,2)))
c_____loop over all bond stretching parameters
         do j=1,numpar_b
            st1=bondpar(j,1)
            st2=bondpar(j,2)
c_____match terms to parameters
            if((at1.eq.st1 .and. at2.eq.st2) .or.
     &           (at2.eq.st1 .and. at1.eq.st2)) then

c_____fill pbond array with bond parameters
               pbond(ii,1)=r0(j)*A_au
               pbond(ii,2)=k0(j)*ev_au
               foundb=foundb+1
               write(9,*)'...bond ',at1,'- ',at2,' : r0 = ',r0(j),
     &              ' k0 = ',k0(j)
               go to 20
            end if
         end do
         write(9,*)' - !Error: parameters for ',at1,' ',at2,
     &        ' not found! -'
         pbond(ii,2)=0
 20   end do
      if(foundb.eq.n_b) then
         write(9,'(a)') 'All quadratic bond parameters found'
      else
         iErr=1
      end if
      if(iErr.eq.1) write(*,'(a)')'ERROR reading <quadratic_bond> box'
      end

      subroutine in_par_angle(NFIL,iErr)
c................................................................
c     subroutine to read in angle bending parameters from the   .
c     force field file attached to unit NFIL and to match the   .
c     parameters to the terms in the nangle array, which are    .
c     then passed to the pangle array with the same index       .
c                                                               .
c     returns iErr=1 if parameters not input correctly          .
c................................................................
      include 'shell.inc'
      integer founda
      integer NumLin
      integer at1,at2,at3,st1,st2,st3
      character line*120,na2*2
      character dmmy(200)
      integer LinPos(30),LinEnd(30)

      iErr=0
      numpar_a=0
c.....read in parameters from file
      rewind (NFIL)
      call find_string('.<quadratic_angle>',18,NFIL,iErr)
      if(iErr.eq.1) return

      jj=0
 30   call CutStr(line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(line(1:6).eq.'.<End>') go to 10
      jj=jj+1

c_______________ read the four species
      read(Line(LinPos(1):LinEnd(1)),*,err=5) ang_at(jj,1)
      call atom_type(Line,LinPos(1),LinEnd(1),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      read(Line(LinPos(2):LinEnd(2)),*,err=5) ang_at(jj,2)
      call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      read(Line(LinPos(3):LinEnd(3)),*,err=5) ang_at(jj,3)
      call atom_type(Line,LinPos(3),LinEnd(3),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5

      call AtLabel_m(Line,LinPos(1),LinEnd(1),na2,dmmy(jj),
     &     angpar(jj,1),iErr)
      call AtLabel_m(Line,LinPos(2),LinEnd(2),na2,dmmy(jj),
     &     angpar(jj,2),iErr)
      call AtLabel_m(Line,LinPos(3),LinEnd(3),na2,dmmy(jj),
     &     angpar(jj,3),iErr)
      read(line(LinPos(4):LinEnd(4)),*,err=5) theta0(jj)
      read(line(LinPos(5):LinEnd(5)),*,err=5) k02(jj)
      numpar_a=numpar_a+1
      go to 30

 5    write(9,'(a,i5)') 'ERROR when reading line ',jj
      iErr=1
 10   write(9,'(a)') '...End of angle box found...'

c.....match parameters to terms in nangle array
c_____loop over all terms in nangle array

      founda=0
      do ii=1,n_a
         at1=NATM(ISRT(nangle(ii,1)))
         at2=NATM(ISRT(nangle(ii,2)))
         at3=NATM(ISRT(nangle(ii,3)))
c_____loop over all parameters
         do j=1,numpar_a
            st1=angpar(j,1)
            st2=angpar(j,2)
            st3=angpar(j,3)
c_____match terms with parameters
            if((at1.eq.st1 .and. at2.eq.st2 .and. at3.eq.st3) .or.
     &           (at3.eq.st1 .and. at2.eq.st2 .and. at1.eq.st3)) then
c_____fill the pangle array with relevent parameters
               pangle(ii,1)=theta0(j)
               pangle(ii,2)=k02(j)*ev_au
               founda=founda+1
               write(9,*)'...angle ',at1,'- ',at2,'- ',at3,
     &              ' : k02 = ',k02(j),' theta0 = ',theta0(j)
               go to 20
            end if
         end do
         write(9,*) ' - !Error: parameters for ',at1,'- ',at2,
     &        '- ',at3,' not found! -'
         pangle(ii,2)=0
 20   end do

      if(founda.eq.n_a) then
         write(9,'(a)') 'All angle parameters found'
      else
         iErr=1
      end if
      if(iErr.eq.1) write(*,'(a)')'ERROR reading <quadratic_angle> box'
      end

      subroutine in_par_torsion(NFIL,iErr)
c................................................................
c     subroutine to read in torsion bending parameters from the .
c     force field file attached to unit NFIL and to match the   .
c     parameters to the terms in the ntorsion array, which are  .
c     then passed to the ptorsion array with the same index     .
c                                                               .
c     returns iErr=1 if parameters are not inputed correctly    .
c................................................................
      include 'shell.inc'
      integer foundt,count
      integer NumLin
      integer at1,at2,at3,at4,st1,st2,st3,st4
      character line*120,na2*2
      character dmmy(200)
      integer LinPos(30),LinEnd(30)
      integer wc
      logical wild(3*N0KD)

c.....initialising wild array which records which parameters come 
c.....from wild card entries

      do i=1,3*N0KD
         wild(i)=.false.
      end do
      iErr=0
      numpar_t=0

c.....read in parameters from file

      rewind (NFIL)
      call find_string('.<torsion_1>',12,NFIL,iErr)
      if(iErr.eq.1) return
      
      jj=0
 30   call CutStr(line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(line(1:6).eq.'.<End>') go to 10
      jj=jj+1

c_______________ read the four species
      read(Line(LinPos(1):LinEnd(1)),*,err=5) tor_at(jj,1)
      if(tor_at(jj,1).ne.'*') then
         call atom_type(Line,LinPos(1),LinEnd(1),i,iErr)
         if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      end if
      read(Line(LinPos(2):LinEnd(2)),*,err=5) tor_at(jj,2)
      if(tor_at(jj,2).ne.'*') then
         call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
         if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      end if
      read(Line(LinPos(3):LinEnd(3)),*,err=5) tor_at(jj,3)
      if(tor_at(jj,3).ne.'*') then
         call atom_type(Line,LinPos(3),LinEnd(3),i,iErr)
         if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      end if
      read(Line(LinPos(4):LinEnd(4)),*,err=5) tor_at(jj,4)
      if(tor_at(jj,4).ne.'*') then
         call atom_type(Line,LinPos(4),LinEnd(4),i,iErr)
         if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      end if

      call AtLabel_m(Line,LinPos(1),LinEnd(1),na2,dmmy(jj),
     &     torpar(jj,1),iErr)
      call AtLabel_m(Line,LinPos(2),LinEnd(2),na2,dmmy(jj),
     &     torpar(jj,2),iErr)
      call AtLabel_m(Line,LinPos(3),LinEnd(3),na2,dmmy(jj),
     &     torpar(jj,3),iErr)
      call AtLabel_m(Line,LinPos(4),LinEnd(4),na2,dmmy(jj),
     &     torpar(jj,4),iErr)
      read(line(LinPos(5):LinEnd(5)),*,err=5) Kphi(jj)
      read(line(LinPos(6):LinEnd(6)),*,err=5) n1(jj)
      read(line(LinPos(7):LinEnd(7)),*,err=5) Phi0(jj)
      numpar_t=numpar_t+1
      go to 30

 5    write(9,'(a,i5)') 'ERROR when reading line ',jj
      iErr=1
 10   write(9,'(a)') '...End of torsion box found...'

c.....match parameters to terms in ntorsion array
      foundt=0
c_____loop over all terms in ntorsion array
      do ii=1,n_t
         at1=NATM(ISRT(ntorsion(ii,1)))
         at2=NATM(ISRT(ntorsion(ii,2)))
         at3=NATM(ISRT(ntorsion(ii,3)))
         at4=NATM(ISRT(ntorsion(ii,4)))
c_____loop over all parameters
         do j=1,numpar_t
            st1=torpar(j,1)
            st2=torpar(j,2)
            st3=torpar(j,3)
            st4=torpar(j,4)
c_____match terms with parameters
            if((at1.eq.st1 .and. at2.eq.st2 .and. at3.eq.st3 .and.
     &           at4.eq.st4) .or. (at4.eq.st1 .and. at3.eq.st2
     &           .and. at2.eq.st3 .and. at1.eq.st4)) then
c_____fill the ptorsion array with relevent parameters
               ptorsion(ii,1)=Kphi(j)*ev_au
               ptorsion(ii,2)=n1(j)
               ptorsion(ii,3)=Phi0(j)
               foundt=foundt+1
               write(9,*)'...torsion ',at1,'- ',at2,'- ',at3,'- ',at4,
     &            ' : Kphi = ',Kphi(j),' n = ',n1(j),' Phi0 = ',Phi0(j)
               go to 20
            end if
         end do

c.....where no parameters are found, then look for wild
c.....card entries in the parameter list

c_____wild card atomic number is '100'
         wc=100
         do j=1,numpar_t
            st1=torpar(j,1)
            st2=torpar(j,2)
            st3=torpar(j,3)
            st4=torpar(j,4)
            if((st1.eq.wc .and. at2.eq.st2 .and. at3.eq.st3 .and.
     &           st4.eq.wc) .or. (st1.eq.wc .and. at3.eq.st2
     &           .and. at2.eq.st3 .and. st4.eq.wc)) then
c_____fill the ptorsion array with relevent parameters
               ptorsion(ii,1)=Kphi(j)*ev_au
               ptorsion(ii,2)=n1(j)
               ptorsion(ii,3)=Phi0(j)
               wild(ii)=.true.
               foundt=foundt+1
               write(9,*)'...torsion * - ',at2,'- ',at3,
     &              '- * : Kphi = ',Kphi(j),' n = ',n1(j),
     &              ' Phi0 = ',Phi0(j)                 
               go to 20
            end if
         end do                  
         write(9,*)' - !Error: parameters for ',at1,'- ',at2,
     &        '- ',at3,'- ',at4,' not found! - '
 20   end do

      if(foundt.eq.n_t) then
         write(9,'(a)') 'All torsion parameters found'
      else
         iErr=1
      end if
      if(iErr.eq.1) write(*,'(a)')'ERROR reading <torsion_1> box'

c.....dividing wild card parameters for torsions arround a single bond

      count=1
      do i=1,n_t
         if(wild(i)) then
            do ii=1,n_t
               if(wild(ii).and. i.ne.ii .and. ((ntorsion(i,2).eq.
     &              ntorsion(ii,2).and.ntorsion(i,3).eq.ntorsion(ii,3))
     &              .or. (ntorsion(i,2).eq.ntorsion(ii,3).and.
     &              ntorsion(i,3).eq.ntorsion(ii,2)))) then
                  count=count+1
               end if
            end do
            ptorsion(i,1)=ptorsion(i,1)/count
         end if
      end do
      end

      subroutine in_par_oop(NFIL,iErr)
c................................................................
c     subroutine to read in angle bending parameters from the   .
c     force field file attached to unit NFIL and to match the   .
c     parameters to the terms in the nangle array, which are    .
c     then passed to the pangle array with the same index       .
c                                                               .
c     returns iErr=1 if parameters not input correctly          .
c................................................................
      include 'shell.inc'
      integer foundo
      integer NumLin
      integer at1,at2,at3,at4,st1,st2,st3,st4
      character line*120,na2*2
      character dmmy(200)
      integer LinPos(30),LinEnd(30)

      iErr=0
      numpar_o=0

c.....read in parameters from file to temporary array

      rewind (NFIL)
      call find_string('.<out_of_plane>',13,NFIL,iErr)
      if(iErr.eq.1) return

      jj=0
 30   call CutStr(line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(line(1:6).eq.'.<End>') go to 10
      jj=jj+1

c_______________ read the four species
      read(Line(LinPos(1):LinEnd(1)),*,err=5) oop_at(jj,1)
      call atom_type(Line,LinPos(1),LinEnd(1),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      read(Line(LinPos(2):LinEnd(2)),*,err=5) oop_at(jj,2)
      call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      read(Line(LinPos(3):LinEnd(3)),*,err=5) oop_at(jj,3)
      call atom_type(Line,LinPos(3),LinEnd(3),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5
      read(Line(LinPos(4):LinEnd(4)),*,err=5) oop_at(jj,4)
      call atom_type(Line,LinPos(4),LinEnd(4),i,iErr)
      if(iErr.eq.1 .or. SpecType(i).ne.'mb') go to 5

      call AtLabel_m(Line,LinPos(1),LinEnd(1),na2,dmmy(jj),
     &     ooppar(jj,1),iErr)
      call AtLabel_m(Line,LinPos(2),LinEnd(2),na2,dmmy(jj),
     &     ooppar(jj,2),iErr)
      call AtLabel_m(Line,LinPos(3),LinEnd(3),na2,dmmy(jj),
     &     ooppar(jj,3),iErr)
      call AtLabel_m(Line,LinPos(4),LinEnd(4),na2,dmmy(jj),
     &     ooppar(jj,4),iErr)
      read(line(LinPos(5):LinEnd(5)),*,err=5) Kchi(jj)
      read(line(LinPos(6):LinEnd(6)),*,err=5) n2(jj)
      read(line(LinPos(7):LinEnd(7)),*,err=5) Chi0(jj)
      numpar_o=numpar_o+1
      go to 30

 5    write(9,'(a,i5)') 'ERROR when reading line ',jj
      iErr=1
 10   write(9,'(a)') '...End of out-of-plane box found...'

c.....match parameters to terms in noop array
      foundo=0

c_____loop over all terms in noop array
      do ii=1,n_o
         at1=NATM(ISRT(noop(ii,1)))
         at2=NATM(ISRT(noop(ii,2)))
         at3=NATM(ISRT(noop(ii,3)))
         at4=NATM(ISRT(noop(ii,4)))
c_____loop over all parameters
         do j=1,numpar_o
            st1=ooppar(j,1)
            st2=ooppar(j,2)
            st3=ooppar(j,3)
            st4=ooppar(j,4)
c_____match terms with parameters
            if(at2.eq.st2 .and. (
     &           (at1.eq.st1 .and. at3.eq.st3 .and. at4.eq.st4)
     &      .or. (at1.eq.st4 .and. at3.eq.st1 .and. at4.eq.st3)
     &      .or. (at1.eq.st3 .and. at3.eq.st4 .and. at4.eq.st1)
     &      .or. (at1.eq.st4 .and. at3.eq.st3 .and. at4.eq.st1)
     &      .or. (at1.eq.st3 .and. at3.eq.st1 .and. at4.eq.st4)
     &      .or. (at1.eq.st1 .and. at3.eq.st4 .and. at4.eq.st3)))
     &           then
c_____fill the poop array with relevent parameters
               poop(ii,1)=Kchi(j)*ev_au
               poop(ii,2)=n2(j)
               poop(ii,3)=Chi0(j)
               foundo=foundo+1
               write(9,*)'...oop ',at1,'- ',at2,'- ',at3,'- ',at4,
     &            ' : Kphi = ',Kchi(j),' n = ',n2(j),' Phi0 = ',Chi0(j)
               go to 20
            end if
         end do
         write(9,*)' - !Error: parameters for ',at1,'- ',at2,
     &        '- ',at3,'- ',at4,' not found! - '
 20   end do
      if(foundo.eq.n_o) then
         write(9,'(a)') 'All out-of-plane parameters found'
      else
         iErr=1
      end if
      if(iErr.eq.1) write(*,'(a)')'ERROR reading <out_of_plane> box'
      end












