c...............................................................
c  This compares two xyz-files and prints out the displacements
c...............................................................
c SYNOPSIS:
c
c     compare file1[.RST] file2[.RST]
c 
c........................................................................
c     The resulting displacements will be dumped separately for core
c and shells into files:
c            comp_core.dsp 
c            comp_shll.dspl
c........................................................................

      implicit double precision (a-h,o-z)
      character filnam1*100,filnam2*100, answer, line*120
      integer LinEnd(30),LinPos(30)
      character spc1*3,spc2*3,cha
      logical move
      dimension shift(3)

      i0=iargc()
      if(i0.lt.2) call help()
c......... get job name 1
      call getarg(1,FilNam1)
      i0=INDEX(FilNam1 ,'_')
      if(i0.ne.0) FilNam1 = FilNam1(:i0-1)
      call right(FilNam1,100,leng1)
c......... get job name 2
      call getarg(2,FilNam2)
      i0=INDEX(FilNam2 ,'_')
      if(i0.ne.0) FilNam2 = FilNam2(:i0-1)
      call right(FilNam2,100,leng2)

c......... ask whether cores or shells
      write(*,*)'Compare cores or shells files (c,C/other char)?'
      read(*,'(a)') answer
      if(answer.eq.'c' .or. answer.eq.'C') then
         write(*,*)'... opening '//FilNam1(leng1:)//'_core.xyz'
         open(1,FILE=FilNam1(leng1:)//'_core.xyz',status='old')
         write(*,*)'... opening '//FilNam2(leng2:)//'_core.xyz'
         open(2,FILE=FilNam2(leng2:)//'_core.xyz',status='old')
         write(*,*)'... opening output comp_core.dspl'
         open(3,FILE='comp_core.dspl',status='unknown')
      else
         write(*,*)'... opening '//FilNam1(leng1:)//'_shll.xyz'
         open(1,FILE=FilNam1(leng1:)//'_shll.xyz',status='old')
         write(*,*)'... opening '//FilNam2(leng2:)//'_shll.xyz'
         open(2,FILE=FilNam2(leng2:)//'_shll.xyz',status='old')
         write(*,*)'... opening output comp_shll.dspl'
         open(3,FILE='comp_shll.dspl',status='unknown')
      end if

c......... specify threshold
 1    write(*,*)'Give the threshold dispacement: atoms will be marked!'
      read(*,*,err=1) thr

c.......... start reading
      read(1,*,err=101,end=101) Natom
      read(2,*,err=102,end=102) Natom1

c__________ take H out
      Natom=Natom-3
      Natom1=Natom1-3
      write(*,*) Natom, Natom1
      if(Natom.ne.Natom1) go to 103
      do i=1,4
         read(1,'(a)') line
         read(2,'(a)') line
      end do

c........ ask if tip atoms are to be readjusted in the two files
      move=.false.
      Ntip=0
      write(*,*)
     &     'Do you want to shift tip atoms in the 2nd file (y,Y/other)?'
      read(*,'(a)') answer
      if(answer.eq.'y' .or. answer.eq.'Y') then
         move=.true.
 3       write(*,*)
     &        'Give the number of tip atoms in both files (go 1st):'
         read(*,*,err=3)  Ntip
         if(Ntip.lt.0 .or. Ntip.gt.Natom) go to 3
 4       write(*,*)'Shift vector in A:'
         read(*,*,err=4)  (Shift(i),i=1,3)
      end if

c.......... read, check and compare
      drm=0.0
      do i=1,Natom
         call CutStr(Line,NumLin,LinPos,LinEnd,1,iErr)
         if(iErr.ne.0) go to 101
         spc1=line(LinPos(1):LinEnd(1))
         read(line(LinPos(2):),*,err=101) x1,y1,z1
         call CutStr(Line,NumLin,LinPos,LinEnd,2,iErr)
         if(iErr.ne.0) go to 102
         spc2=line(LinPos(1):LinEnd(1))
         read(line(LinPos(2):),*,err=102) x2,y2,z2
         if(spc1.ne.spc2) then 
            write(*,'(a,i5,a)')'FATAL! Atom ',i,' is incompatible!'
            go to 103
         end if

c_________ shift if necessary
         if(move .and. i.le.Ntip) then
            x2=x2+shift(1)
            y2=y2+shift(2)
            z2=z2+shift(3)
         end if

c_________ compare
         dx=x2-x1
         dy=y2-y1
         dz=z2-z1
         dr=sqrt(dx*dx+dy*dy+dz*dz)
         if(dr.gt.drm) drm=dr
         cha=' '
         if(dr.ge.thr) cha='*'
         write(3,'(a3,3(x,f10.5),2x,3(x,f10.5),x,a,x,f10.5)') 
     &        spc1,x1,y1,z1,dx,dy,dz,cha,dr

      end do

      write(*,'(a,e12.6)')'... MAX displacement found = ',drm
      close (1)
      close (2)
      close (3)
      if(answer.eq.'c' .or. answer.eq.'C') then
         write(*,'(a)')'... Done comp_core.dspl file'
      else
         write(*,'(a)')'... Done comp_shll.dspl file'
      end if
      stop
c
c............. errors
 101  write(*,'(a)')
     &     'FATAL! Bad '//FilNam1(leng1:)//'_[core/shll].xyz file'
      stop
 102  write(*,'(a)')
     &     'FATAL! Bad '//FilNam2(leng2:)//'_[core/shll].xyz file'
      stop
 103  write(*,'(a)')'FATAL! Core/shll files '//FilNam1(leng1:)//
     &        ' and '//FilNam2(leng2:)//' are incompatible!'
      end

      subroutine help()
      write(6,*) '  Compares two xyz files from SHELLM/SCI-FI and gives'
      write(6,*) 
     &     'displacements either for cores or shells. Interactive.'
      write(6,*) 
     &     'Displacements larger than a specified threshold are marked.'
      write(6,*) 
      write(6,*) 'SYNOPSIS:'
      write(6,*) '    compare file1[.RST] files2[.RST]'
      write(6,*) 
      write(6,*) 'where output files for cores and shells are:'
      write(6,*) '    comp_core.dsp  '
      write(6,*) '    comp_shll.dspl '
      stop
      end

      subroutine right(char,len,leng)
      character  char(len)*1
      do i=len,1,-1
         j=i
         if(char(i).ne.' ') go to 1
      end do
 1    jj=len-j
      do i=j,1,-1
         char(jj+i) = char(i)
      end do
      do i=1,jj
         char(i)=' '
      end do
      leng=jj+1
      return
      end

      subroutine CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
c.................................................................
c....It reads the line from the file UNIT=NFIL as a string   .....
c.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
c.... substrings. Their number is NumLin, while starting and .....
c.... ending positions are LinPos and LinEnd.                .....
c.................................................................
c Up to 30 substrings is implied to be in the initial string Line.
c.................................................................
c  If NFIL=0 it is supposed that the string Line*80 exists and
c  must not be read from the external source, but must be taken
c  as an input from the parent program
c.................................................................
c  iErr=1 in the case of error input
c  iErr=2 in the case of end of file
c  iErr=0 otherwise
c.................................................................
c
      character Line*120,cha
      integer LinEnd(30),LinPos(30)
      iErr=0
c
c............ get the line skipping comments
      if(NFIL.ne.0) then
         call SkipL(NFIL,Line,iErr)
         if(iErr.ne.0) return
      end if
      NumLin=0
      icase=0
c............ Loop over all characters in the Line(1:80)............
       do 5 i=1,120
       cha=Line(i:i)
c________ if the 1st not blank character is found
       if(cha.ne.' '.and.icase.eq.0) then
          NumLin=NumLin+1
          if(NumLin.gt.30) go to 10
          LinPos(NumLin)=i
          icase=1
       end if
c_________ if the 1st blank character is found after the substring
       if(cha.eq.' '.and.icase.eq.1) then
          LinEnd(NumLin)=i-1
          icase=0
       end if
 5     end do
       if(icase.eq.1) LinEnd(NumLin)=120
       return
10     iErr=1
       return
       end

      subroutine SkipL(NFIL,Line,iErr)
c.......................................................................
c...... Program skips all "empty" string containing comments, etc.......
c...... All lines, containing **,--,==,*- and -* symbols are     .......
c...... recognized as the comments lines and are skipped. The    .......
c...... driver is set up at the beginning of the first "nonempty".......
c...... record                                                   .......
c.......................................................................
c  iErr=1 in the case of error input
c  iErr=2 in the case of end of file
c  iErr=0 otherwise
c.................................................................
c
      parameter (nComm=6)
      character*2 Line*120,Comm(nComm)
      data Comm/'*-','-*','--','==','**','##'/
c.......... read the current line from the driver NFIL
1     read (NFIL,'(a)',err=10,end=20) Line
c_________ analyze Line if it is empty
      if(Line(1:1).eq.CHAR(0)) go to 1
c_________ analyze Line if it is filled by simple blanks
        do i=1,120
        if(Line(i:i).ne.CHAR(0).and.Line(i:i).ne.' ') go to 2
        end do
      go to 1
c_________ analyze Line for the comment symbols; in the case if any
c          one from the list Comm() was found it reads the next line
2       do i=1,nComm
        i0=INDEX(Line,Comm(i))
        if(i0.ne.0) go to 1
        end do
      iErr=0
      return
c......... in the case of an error
10    iErr=1
      return
 20   iErr=2
      return
      end

