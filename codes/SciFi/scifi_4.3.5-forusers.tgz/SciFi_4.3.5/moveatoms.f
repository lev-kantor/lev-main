c
c move all atoms by a specified vector and/or rotate all
c
      parameter (NAT0=1000)
      implicit double precision (a-h,o-z)
      character Spec(NAT0)*2,line*120,item
      dimension r(3),x(3),iflag(NAT0,3),Rat(NAT0,3)
      data pi/3.141592654/
c
c[1]............... read atomic positions
c___________ read the atom i
      write(*,'(a)')'... reading input file {at.in} with coordinates'
      open(1,file='at.in',form='formatted',status='old')
      i=0
 10   i=i+1
      if(i.gt.NAT0) stop 'Too many atoms!'
      read(1,'(a)',err=20,end=20) line
      write(*,'(a)') line
      spec(i)=Line(1:2)
      read(Line(3:),*,err=20,end=20) (Rat(i,j),j=1,3),(iflag(i,j),j=1,3)
      go to 10
c
c_________ finish reading atoms
 20   Nat=i-1
      write(*,'(a,i5,a)')'... found ',Nat,' atoms'
      write(*,'(a)') '... Done!'
      close (1)
c
c[2]................ main menu: change atomic positions
c
 30   write(*,*)'.......Change atomic positions.........'
      write(*,*)
      write(*,*)' m - move by a vector'
      write(*,*)' x - rotate about X-axes'
      write(*,*)' y - rotate about Y-axes'
      write(*,*)' z - rotate about Z-axes'
      write(*,*)' w - write atoms in XMOL format as {at.xyz}'
      write(*,*)' q - write atoms in SHM format as {at.out} and quit'
      write(*,*)
      write(*,*)'_______> choose and press Enter:'
      read(*,'(a)',err=30) item

c______________ move atoms by X
      if(item.eq.'m') then
 1       write(*,*)'Specify the vector to move by:'
         read(*,*,err=1) x
         do n=1,Nat
            do j=1,3
               Rat(n,j)=Rat(n,j)+x(j)
            end do
         end do

c______________ rotate atoms about X
      else if(item.eq.'x') then
 2       write(*,*)'Specify angle in degrees (left rotation):'
         read(*,*,err=2) fi
         fi=fi/180.0*pi
         cosfi=cos(fi)
         sinfi=sin(fi)
         do n=1,Nat
            x1=Rat(n,1)
            x2=          Rat(n,2)*cosfi + Rat(n,3)*sinfi 
            x3=         -Rat(n,2)*sinfi + Rat(n,3)*cosfi 
            Rat(n,1)=x1
            Rat(n,2)=x2
            Rat(n,3)=x3
         end do

c______________ rotate atoms about Y
      else if(item.eq.'y') then
 3       write(*,*)'Specify angle in degrees (left rotation):'
         read(*,*,err=3) fi
         fi=fi/180.0*pi
         cosfi=cos(fi)
         sinfi=sin(fi)
         do n=1,Nat
            x1=Rat(n,1)*cosfi           - Rat(n,3)*sinfi 
            x2=                 Rat(n,2)
            x3=Rat(n,1)*sinfi           + Rat(n,3)*cosfi 
            Rat(n,1)=x1
            Rat(n,2)=x2
            Rat(n,3)=x3
         end do

c______________ rotate atoms about Z
      else if(item.eq.'z') then
 4       write(*,*)'Specify angle in degrees (left rotation):'
         read(*,*,err=4) fi
         fi=fi/180.0*pi
         cosfi=cos(fi)
         sinfi=sin(fi)
         do n=1,Nat
            x1= Rat(n,1)*cosfi + Rat(n,2)*sinfi 
            x2=-Rat(n,1)*sinfi + Rat(n,2)*cosfi 
            x3=                                  Rat(n,3)
            Rat(n,1)=x1
            Rat(n,2)=x2
            Rat(n,3)=x3
         end do

c______________ write xmol file to see the system; H atoms are used to
c               show axes
      else if(item.eq.'w') then
         open(1,file='at.xyz',form='formatted',status='unknown')
         write(1,*) Nat+3
         write(1,*) 
         write(1,'(a)') 'H     0.0 0.0 0.0    10.0  0.0  0.0 '
         write(1,'(a)') 'H     0.0 0.0 0.0     0.0 10.0  0.0 '
         write(1,'(a)') 'H     0.0 0.0 0.0     0.0  0.0 10.0 '
         do n=1,Nat
            write(1,'(a2,x,3(f10.5,x),a)') 
     &        spec(n),(Rat(n,j),j=1,3),' 0.0 0.0 0.0'
         end do
         close (1)
c         call system('xmol at.xyz')

c_____________ write geometry in the format of <shm>-code and quit
      else if(item.eq.'q') then
         open(1,file='at.out',form='formatted',status='unknown')
         write(1,*) Nat
         do n=1,Nat
            write(1,'(a2,x,3(f10.5,x),3i5)') 
     &        spec(n),(Rat(n,j),j=1,3),(iflag(n,j),j=1,3)
         end do
         close (1)
         stop
      else
         write(*,*)'Try again!'
         go to 30
      end if
      go to 30
      end

