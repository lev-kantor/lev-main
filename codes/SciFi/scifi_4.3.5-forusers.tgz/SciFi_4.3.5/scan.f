      subroutine do_VirtualAFM()
      include 'virtual.inc'
      include 'forces.inc'
      include 'stages.inc'
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c       S.I. Units are mostly used                                 c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

c..................................................................c
c  LK (Lev Kantorovich) 21.11.2003                                 c
c  LK (Lev Kantorovich) 28.06.2004                                 c
c  King's College London                                           c
c  lev.kantorovitch@kcl.ac.uk                                      c
c..................................................................c
c  This version was written nearly from scratch by L.K. using the  c
c  original version by:                                            c
c..................................................................c
C                                                                  C
C        Virtual Dynamic Atomic Force Microscope including         C
C         the electronic regulation on Amplitude (AGC: Automatic   C
C         Gain Control) and the regulation on Distance via         C
C         a PLL FM demodulation.                                   C
C                                                                  C
C           by Jerome POLESEL-MARIS   Copyrights october 2003      C
C           CEMES-CNRS de TOULOUSE (FRANCE)                        C
C           Groupe Nanoscience                                     C
C           29. rue Jeanne Marvig                                  C
C           F-31055 TOULOUSE Cedex 04                              C
C           E-mail: polesel@cemes.fr                               C
C                   poleselmaris@hotmail.com                       C
c..................................................................c
      integer t
      character cha,cha2*2

c............ test forces
      if(do_force_test) then
         call test_force()
         stop
      end if

c............  Initialisation of time dependent variables

      call initialise()
c
c...................................................................
c [1] The first step: stabilisation of the free cantilever
c...................................................................
c
      istage=1
      t=1
      call run_stage(t,istage)

c...................................................................
c [2] The second step: stabilisation of the regulation signals of
c     the loops. Here the excitation signal is added to the 
c     cantilever oscillation. In the end we should have a forced
c     oscillation with the same frequency w0 (DEF close to 0).
c...................................................................
c
      istage=2
      call run_stage(t,istage)

      write(*,'(a,f10.5)') 'DEF = ',DEF
      write(*,'(a,i10)') 'time step = ',t
      write(*,'(a)') '...... The AFM has stabilized !!! ......'
      write(*,'(a,f10.5)')
     &     'Looking for the frequency shift setpoint = ',DFC
      write(*,'(3(a,e12.6/))')'Rinf= ',R,' fref= ',fref,' Modul= ',MODUL

c____________  excitation amplitude Rinf at infinite separation is needed
c              for the calculation of the dissipation power per cycle Pinf

      Rinf=R
      Pinf=0.5*Rinf*MODUL*2*pi*fref*J_eV
      fref0=fref
      write(*,'(a,e12.6)')'Excitation amplitude at infinity = ',Rinf
      write(*,'(a,e12.6,a)')'Power fed in at infinity = ',Pinf,' eV/sec'
      
c......................................................................
c [3] The third step: the tip is moved down towards the surface
c     so that the frequency shift DEF is found within 0.5 Hz of
c     the setpoint DFC. The tip-surface force is now also switched on.
c     Does as many timesteps as necessary.
c......................................................................
c
      istage=3
      Iadc=Iadc0
      write(*,*) 'Performing vertical approach'
      write(9,'(/a/)') '=======> Performing vertical approach <======='
      open(15,file='signals.dat',status='unknown',form='formatted')
      write(15,'(a)')'# oscil  - oscillation number'
      write(15,'(a)')'# X,Y    - lateral position (in A)'
      write(15,'(a)')'# A      - oscillation amplitude (in A)'
      write(15,'(a)')'# DEF    - frequency shift (Hz)'
      write(15,'(a)')'# Ediss  - dissipation energy per cycle (eV)'
      write(15,'(a)')'# appr   - distance of closest approach (A)'
      write(15,'(a)')'# '
      write(15,'(a)')'#    oscil      X             Y           A '//
     &     '           DEF         Ediss       appr'

      n_of_oscil=0
      call run_stage(t,istage)

      print *,'time step = ',t
      write (*,'(3(a,e12.6))') 
     &     'DFC= ',DFC,', DEF= ',DEF,', tolerance= ',DEF-DFC
      print *,'Distance DISTA = ',DISTA

c______________ dissipation energy at this position x,y
c               dissipation power: 2 expressions, the 1st is simplier
      Pdiss1=Pinf*(R/Rinf - 1.0)
      Pdiss=0.5*Rinf*MODUL*2*pi*fref*(R/Rinf - fref/fref0)*J_eV
c______________ dissipation energy per cycle
      Ediss1=Pdiss1/fref
      Ediss=Pdiss/fref
      write(*,'(a,e12.6)')'Excitation amplitude = ',R
      write(*,'(a,e12.6,a)')'Dissipation power = ',Pdiss1,' eV/sec'
      write(*,'(a,e12.6,a)')'Dissipation power = ',Pdiss,
     &     ' eV/sec (more precise)'
      write(*,'(a,e12.6,a)')
     &     'Dissipation energy per cycle = ',Ediss1,' eV'
      write(*,'(a,e12.6,a)')
     &     'Dissipation energy per cycle = ',Ediss,' eV (more precise)'
      if(N_of_Stages.eq.3) stop

c......................................................................
c [4 onwards] Other elementary stages follow here
c......................................................................
c If scans are to be performed, a file 2Dimage_{scan#}.dat is openned
c with all the data for each X,Y.
c......................................................................
c
      Iadc=Iadc1
      do istage = 4,N_of_Stages
         t=0
         if(scan_mark(istage).eq.'start') then
            if(scan_no(istage).lt.10) then
               write(cha,'(i1)') scan_no(istage)
               open(19,file='2Dimage_'//cha//'.dat',form='formatted',
     ,                                             status='unknown')
            else if(scan_no(istage).lt.100) then
               write(cha2,'(i2)') scan_no(istage)
               open(19,file='2Dimage_'//cha2//'.dat',form='formatted',
     ,                                             status='unknown')
            else
               write(*,*)'ERROR! # of scans cannot be > 99!'
               stop
            end if
         end if
         call run_stage(t,istage)
         if(scan_mark(istage).eq.' end ') close (19)
      end do

      close (9)
      close (15)
      stop
c
c............. errors
c
      write(*,*)'FATAL! Input file has not been found!'
      stop
      end

      subroutine initialise()
c.....................................................................
c     Initialise everything needed for the time integration of the
c  equations.
c.....................................................................
      include 'virtual.inc'
      t=1
      Zprv=A0
      Zold=A0
      Dold = A0
      at_old = 0.0d0
      Vold   = 0.0d0
      ACC = -A0*w0*w0
      pt_old = 1.0d0
      p1t_old = 0.0d0
      ut_old  = 0.0d0
      Nadc    = 0.0d0
      N       = -3.d-12
      cosphy=dcos(phase)
      sinphy=dsin(phase)
      Zrefcos = 1.0d0
      exp1 = exp(-dt/tau1)
      exp2 = exp(-dt/tau2)
      expD = exp(-dt/tauD)
      Iphy=0.d0
      return
      end

