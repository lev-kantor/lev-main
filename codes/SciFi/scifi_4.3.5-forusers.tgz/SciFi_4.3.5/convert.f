      subroutine conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,n_pos_cor,
     ,                                               iRx,iRy,iRz)
c....................................................................
c  converts 3 vectors x,y,z into one ( r ) with the lenght of n_dfree
c....................................................................
      include 'param.inc'
      dimension X(N0CH),Y(N0CH),Z(N0CH),p(N0FR)
      dimension iShell(N0LT),iRx(N0CH),iRy(N0CH),iRz(N0CH),ISRT(N0LT)
      logical Shell_Ref(N0KD)

      n=0
      ns=n_pos_cor
      do i=1,Natom
         if(iRx(i).eq.1) then
            n=n+1
            p(n)=x(i)
         end if
         if(iRy(i).eq.1) then
            n=n+1
            p(n)=y(i)
         end if
         if(iRz(i).eq.1) then
            n=n+1
            p(n)=z(i)
         end if
         if(Shell_Ref(ISRT(i))) then
            j=iShell(i)
            if(iRx(j).eq.1) then
               ns=ns+1
               p(ns)=x(j)
            end if
            if(iRy(j).eq.1) then
               ns=ns+1
               p(ns)=y(j)
            end if
            if(iRz(j).eq.1) then
               ns=ns+1
               p(ns)=z(j)
            end if
         end if
      end do

      return
      end

      subroutine force_conv_3_1(fx,fy,fz,g,x,y,z,iShell,Shell_Ref,ISRT,
     ,                                      Natom,n_pos_cor,iRx,iRy,iRz)
c....................................................................
c  converts 3 vectors fx,fy,fz of cartesian forces into one vector g
c  of gradients (-forces) of lenght n_dfree 
c....................................................................
      include 'param.inc'
      include 'constr.inc'
      dimension x(N0CH),y(N0CH),z(N0CH)
      dimension fx(N0CH),fy(N0CH),fz(N0CH),g(N0FR)
      dimension iShell(N0LT),iRx(N0CH),iRy(N0CH),iRz(N0CH),ISRT(N0LT)
      logical Shell_Ref(N0KD)

c........ correcting if there are constraints

      if(Yes_Constr) then
         do ic=1,N_of_Constr
c____________ Type A_1x
            if(Type_Constr(ic).eq.'A_1x') then
               nat1=Inv_atoms(ic,1)
               nat2=Inv_atoms(ic,2)
               angle=Par_constr(ic,1)
               dd=sqrt( (z(nat2)-z(nat1))**2 + (y(nat2)-y(nat1))**2 )
               dd=1.0/(dd*tan(angle))*Par_constr(ic,2)
               fy(nat1)=fy(nat1)+fx(nat1)*dd*(y(nat2)-y(nat1))
               fz(nat1)=fz(nat1)+fx(nat1)*dd*(z(nat2)-z(nat1))
               fx(nat2)=fx(nat2)+fx(nat1)
               fy(nat2)=fy(nat2)-fx(nat1)*dd*(y(nat2)-y(nat1))
               fz(nat2)=fz(nat2)-fx(nat1)*dd*(z(nat2)-z(nat1))
c____________ Type B1xz
            else if(Type_Constr(ic).eq.'B1xz') then
               nat1=Inv_atoms(ic,1)
               nat2=Inv_atoms(ic,2)
               angle=Par_constr(ic,1)
               dd=-1.0/tan(angle)*Par_constr(ic,2)
               fz(nat1)=fz(nat1)+fx(nat1)*dd
               fx(nat2)=fx(nat2)+fx(nat1)
               fz(nat2)=fz(nat2)-fx(nat1)*dd
c____________ Type C_1x (not yet ready!)
c            else if(Type_Constr(ic).eq.'C_1x') then
c               nat1=Inv_atoms(ic,1)
c               nat2=Inv_atoms(ic,2)
c               nat3=Inv_atoms(ic,3)
c               angle=Par_constr(ic,1)

c____________ Type D_1x 
            else if(Type_Constr(ic).eq.'D_1x') then
               nat1=Inv_atoms(ic,1)
               nat2=Inv_atoms(ic,2)
               dist1=Par_constr(ic,1)
               d12=(z(nat2)-z(nat1))**2 + (y(nat2)-y(nat1))**2
               dd=1.0/sqrt(dist1*dist1-d12)*Par_constr(ic,2)
               fy(nat1)=fy(nat1)-fx(nat1)*dd*(y(nat1)-y(nat2))
               fz(nat1)=fz(nat1)-fx(nat1)*dd*(z(nat1)-z(nat2))
               fx(nat2)=fx(nat2)+fx(nat1)
               fy(nat2)=fy(nat2)+fx(nat1)*dd*(y(nat1)-y(nat2))
               fz(nat2)=fz(nat2)+fx(nat1)*dd*(z(nat1)-z(nat2))

c____________Type LINR
            else if(Type_Constr(ic).eq.'LINR') then
               if(Redund_dir(ic).eq.'x') then
                  fdir=fx(Inv_atoms(ic,1))
               else if(Redund_dir(ic).eq.'y') then
                  fdir=fy(Inv_atoms(ic,1))
               else if(Redund_dir(ic).eq.'z') then
                  fdir=fz(Inv_atoms(ic,1))
               end if
               do j=2,N_inv_atoms(ic)
                  natj=Inv_atoms(ic,j)
                  if(Inv_crd(ic,j,1)) then
                     fx(natj)=fx(natj)-fdir*Par_constr(ic,j)
                  else if(Inv_crd(ic,j,2)) then
                     fy(natj)=fy(natj)-fdir*Par_constr(ic,j)
                  else if(Inv_crd(ic,j,3)) then
                     fz(natj)=fz(natj)-fdir*Par_constr(ic,j)
                  end if
               end do

c____________ Type X
            else if(Type_Constr(ic).eq.'X   ') then

            end if
         end do
      end if

c......... setting up g-vector of gradients = -forces

      n=0
      ns=n_pos_cor
      do i=1,Natom
         if(iRx(i).eq.1) then
            n=n+1
            g(n)=fx(i)
         end if
         if(iRy(i).eq.1) then
            n=n+1
            g(n)=fy(i)
         end if
         if(iRz(i).eq.1) then
            n=n+1
            g(n)=fz(i)
         end if
         if(Shell_Ref(ISRT(i))) then
            j=iShell(i)
            if(iRx(j).eq.1) then
               ns=ns+1
               g(ns)=fx(j)
            end if
            if(iRy(j).eq.1) then
               ns=ns+1
               g(ns)=fy(j)
            end if
            if(iRz(j).eq.1) then
               ns=ns+1
               g(ns)=fz(j)
            end if
         end if
      end do
      return
      end

      subroutine coord_constr(ic,x,y,z,crd,xyz,nat)
c....................................................................
c  calculates the redundant coordinate from the constraint ic:
c  crd - value
c  xyz - either x,y or z (character*1)
c  nat - atomic number
c....................................................................
      include 'param.inc'
      include 'constr.inc'
      dimension X(N0CH),Y(N0CH),Z(N0CH)
      character xyz
      nat=Inv_atoms(ic,1)
      xyz=Redund_dir(ic)
c____________ Type A_1x
      if(Type_Constr(ic).eq.'A_1x') then
         nat1=Inv_atoms(ic,1)
         nat2=Inv_atoms(ic,2)
         angle=Par_constr(ic,1)
         dd=sqrt( (z(nat2)-z(nat1))**2 + (y(nat2)-y(nat1))**2 )
         crd=x(nat2)-dd/tan(angle)*Par_constr(ic,2)

c____________Type B1xz
      else if(Type_Constr(ic).eq.'B1xz') then
         nat1=Inv_atoms(ic,1)
         nat2=Inv_atoms(ic,2)
         angle=Par_constr(ic,1)
         crd=x(nat2)+(z(nat2)-z(nat1))/tan(angle)*Par_constr(ic,2)

c____________Type C_1x (not yet ready!)
c     else if(Type_Constr(ic).eq.'C_1x') then
c     nat1=Inv_atoms(ic,1)
c     nat2=Inv_atoms(ic,2)
c     nat3=Inv_atoms(ic,3)
c     angle=Par_constr(ic,1)
         
c____________Type D_1x 
      else if(Type_Constr(ic).eq.'D_1x') then
         nat1=Inv_atoms(ic,1)
         nat2=Inv_atoms(ic,2)
         dist1=Par_constr(ic,1)
         d12 = (z(nat2)-z(nat1))**2 + (y(nat2)-y(nat1))**2
         crd=x(nat2)+sqrt(dist1*dist1-d12)*Par_constr(ic,2)

c____________Type LINR
      else if(Type_Constr(ic).eq.'LINR') then
         crd=0.0
         do j=2,N_inv_atoms(ic)
            if(Inv_crd(ic,j,1)) then
               atcoord=x(Inv_atoms(ic,j))
            else if(Inv_crd(ic,j,2)) then
               atcoord=y(Inv_atoms(ic,j))
            else if(Inv_crd(ic,j,3)) then
               atcoord=z(Inv_atoms(ic,j))
            end if
            crd=crd-Par_Constr(ic,j)*atcoord
         end do

c____________Type X
      else if(Type_Constr(ic).eq.'X   ') then
         
      end if
      return
      end

      subroutine conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,n_pos_cor,
     ,                                               iRx,iRy,iRz)
c....................................................................
c  converts vector p() into 3 vectors x,y,z 
c....................................................................
      include 'param.inc'
      include 'constr.inc'     
      parameter (au_A = 0.529177249d0,A_au=1.0d0/au_A)
      dimension X(N0CH),Y(N0CH),Z(N0CH),p(N0FR)
      dimension iShell(N0LT),iRx(N0CH),iRy(N0CH),iRz(N0CH),ISRT(N0LT)
      logical Shell_Ref(N0KD)
      character xyz

      n=0
      ns=n_pos_cor
      do i=1,Natom
         if(iRx(i).eq.1) then
            n=n+1
            x(i)=p(n)
         end if
         if(iRy(i).eq.1) then
            n=n+1
            y(i)=p(n)
         end if
         if(iRz(i).eq.1) then
            n=n+1
            z(i)=p(n)
         end if
         if(Shell_Ref(ISRT(i))) then
            j=iShell(i)
            if(iRx(j).eq.1) then
               ns=ns+1
               x(j)=p(ns)
            end if
            if(iRy(j).eq.1) then
               ns=ns+1
               y(j)=p(ns)
            end if
            if(iRz(j).eq.1) then
               ns=ns+1
               z(j)=p(ns)
            end if
         end if
      end do

c
c........ correcting if there are constraints
c
      if(Yes_Constr) then
         do ic=1,N_of_Constr
            call coord_constr(ic,x,y,z,crd,xyz,nat)
            if(xyz.eq.'x') then
               x(nat)=crd
            else if(xyz.eq.'y') then
               y(nat)=crd
            else 
               z(nat)=crd
            end if
         end do
      end if

cccccccccccccccccccc
c      write(9,*) 'conv_1_3 => initial 1-coordinates (cores only):'
c      write(9,'(2(a,i5),a)')'>>>>>>> n = ',n,' , ns = ',ns,' <<<<<<<<'
c      write(9,'(6(e14.8,x))') (p(i),i=1,n)
c      write(9,*) 'conv_1_3 => final 3-coordinates (A/au):'
c      do i=1,Natom
c         if(Shell_Ref(ISRT(i))) then
c            j=iShell(i)
c            write(9,'(i3,6(x,e14.8))') i,x(i),y(i),z(i),x(j),y(j),z(j)
c         else
c            write(9,'(i3,3(x,e14.8))') i,x(i),y(i),z(i)
c         end if
c      end do
      return
      end

