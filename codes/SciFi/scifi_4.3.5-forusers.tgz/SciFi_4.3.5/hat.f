      subroutine hat()
      character line*30
      
      write(9,'(a)') 
     &     '***********************************************'
      write(9,'(a)') 
     &     '***********     WELCOME to Sci-Fi   ***********'
      write(9,'(a)') 
     &     '***********************************************'
      write(9,'(a/a/a)')
     &     '*********    By:  Lev Kantorovich   ***********',
     &     '*********         Tom Trevethan     ***********',
     &     '*********     Jerome Polesel-Maris  ***********'
      write(9,'(a)') 
     &     '***********************************************'
      write(*,'(a)') 
     &     '***********************************************'
      write(*,'(a)') 
     &     '***********     WELCOME to Sci-Fi   ***********'
      write(*,'(a)') 
     &     '***********************************************'
      write(*,'(a/a/a)')
     &     '*********    By:  Lev Kantorovich   ***********',
     &     '*********         Tom Trevethan     ***********',
     &     '*********     Jerome Polesel-Maris  ***********'
      write(*,'(a)') 
     &     '***********************************************'
      include 'build.hat'
      call system('date > tmp.date')
      open(111,file='tmp.date')
      read(111,'(a)') line
      close (111,status='delete')
      write(9,'(a)')'>>>  Today      : '//line
      write(*,'(a)')'>>>  Today      : '//line
      write(9,'(a)') 
     &     '***********************************************'
      write(9,'(a)') 
     &     '********  inquiries to L. Kantorovich  ********'
      write(9,'(a/)') 
     &     '***********************************************'
      write(*,'(a)') 
     &     '***********************************************'
      write(*,'(a)') 
     &     '********  inquiries to L. Kantorovich  ********'
      write(*,'(a/)') 
     &     '***********************************************'
      return
      end



