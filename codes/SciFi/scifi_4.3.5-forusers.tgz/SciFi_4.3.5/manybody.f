      subroutine diag_terms(iPrnt)
c................................................................
c     subroutine to find all interactions in a molecule with    .
c     a given connection table, bond.  returns arrays           .
c     containing lists of atom numbers for each interaction.    .
c     it also returns the number of each type of interaction    .
c................................................................
      include 'shell.inc'

      n_b=0
      n_a=0
      n_t=0
      n_o=0

c.....filling the nbonds array with all directional bonds

      do i=1,Natom
         is=ISRT(i)
         if(SpecType(is).eq.'mb') then
            do ib=1,N0BD
               if(bond(i,ib).gt.i) then
                  n_b=n_b+1
                  nbond(n_b,1)=i
                  nbond(n_b,2)=bond(i,ib)
               end if
            end do
         end if
      end do

c.....filling the nangle array with all three sequentially bonded atoms

      do i=1,n_b
         do ii=i,n_b
            if(nbond(i,1).eq.nbond(ii,1) .and. i.ne.ii) then
               n_a=n_a+1
               nangle(n_a,1)=nbond(i,2)
               nangle(n_a,2)=nbond(i,1)
               nangle(n_a,3)=nbond(ii,2)
            else if(nbond(i,2).eq.nbond(ii,1) .and. i.ne.ii) then
               n_a=n_a+1
               nangle(n_a,1)=nbond(i,1)
               nangle(n_a,2)=nbond(i,2)
               nangle(n_a,3)=nbond(ii,2)
            else if(nbond(i,2).eq.nbond(ii,2) .and. i.ne.ii) then
               n_a=n_a+1
               nangle(n_a,1)=nbond(i,1)
               nangle(n_a,2)=nbond(i,2)
               nangle(n_a,3)=nbond(ii,1)
            else if(nbond(i,1).eq.nbond(ii,2) .and. i.ne.ii) then
               n_a=n_a+1
               nangle(n_a,1)=nbond(i,2)
               nangle(n_a,2)=nbond(i,1)
               nangle(n_a,3)=nbond(ii,1)
            end if
         end do
      end do

c.....filling the ntorsion array with all four sequentially bonded atoms

      do i=1,n_a
         do ii=i,n_a
            if(nangle(i,2).eq.nangle(ii,1) .and. 
     &           nangle(i,3).eq.nangle(ii,2) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(i,1)
               ntorsion(n_t,2)=nangle(i,2)
               ntorsion(n_t,3)=nangle(i,3)
               ntorsion(n_t,4)=nangle(ii,3)
            else if(nangle(i,1).eq.nangle(ii,2) .and. 
     &              nangle(i,2).eq.nangle(ii,3) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(ii,1)
               ntorsion(n_t,2)=nangle(i,1)
               ntorsion(n_t,3)=nangle(i,2)
               ntorsion(n_t,4)=nangle(i,3)
            else if(nangle(i,2).eq.nangle(ii,3) .and. 
     &              nangle(i,3).eq.nangle(ii,2) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(i,1)
               ntorsion(n_t,2)=nangle(i,2)
               ntorsion(n_t,3)=nangle(i,3)
               ntorsion(n_t,4)=nangle(ii,1)
            else if(nangle(i,1).eq.nangle(ii,2) .and. 
     &              nangle(i,2).eq.nangle(ii,1) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(ii,3)
               ntorsion(n_t,2)=nangle(ii,2)
               ntorsion(n_t,3)=nangle(ii,1)
               ntorsion(n_t,4)=nangle(i,3)   

            else if(nangle(i,2).eq.nangle(ii,1) .and. 
     &           nangle(i,1).eq.nangle(ii,2) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(ii,3)
               ntorsion(n_t,2)=nangle(i,1)
               ntorsion(n_t,3)=nangle(i,2)
               ntorsion(n_t,4)=nangle(i,3)
            else if(nangle(i,3).eq.nangle(ii,2) .and. 
     &              nangle(i,2).eq.nangle(ii,3) .and. i.ne.ii) then
               nt=nt+1
               ntorsion(n_t,1)=nangle(ii,1)
               ntorsion(n_t,2)=nangle(i,3)
               ntorsion(n_t,3)=nangle(i,2)
               ntorsion(n_t,4)=nangle(i,1)

            else if(nangle(i,2).eq.nangle(ii,3) .and. 
     &           nangle(i,1).eq.nangle(ii,2) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(ii,1)
               ntorsion(n_t,2)=nangle(i,3)
               ntorsion(n_t,3)=nangle(i,2)
               ntorsion(n_t,4)=nangle(i,1)
            else if(nangle(i,3).eq.nangle(ii,2) .and. 
     &              nangle(i,2).eq.nangle(ii,1) .and. i.ne.ii) then
               n_t=n_t+1
               ntorsion(n_t,1)=nangle(i,3)
               ntorsion(n_t,2)=nangle(i,2)
               ntorsion(n_t,3)=nangle(i,1)
               ntorsion(n_t,4)=nangle(ii,3)
            end if
         end do
      end do

c.....filling the noop array with all valence three atoms
c.....with central atom in the second column
 
      do i=1,Natom
         is=ISRT(i)
         if(SpecType(is).eq.'mb') then
            if(bond(i,1).ne.0 .and. bond(i,2).ne.0 .and. 
     &           bond(i,3).ne.0 .and. bond(i,4).eq.0) then
               n_o=n_o+1
               noop(n_o,1)=bond(i,1)
               noop(n_o,2)=i
               noop(n_o,3)=bond(i,2)
               noop(n_o,4)=bond(i,3)
            end if
         end if
      end do
 
c.....writing details to record file (unit 5)

      write(9,'(a,i5)')        'No. bonds        = ',n_b

c      do m=1,nb
c         write(4,*) nbond(m,1),' ',nbond(m,2)
c      end do

      write(9,'(a,i5)')        'No. angles       = ',n_a

c      do m=1,na
c         write(4,*) nangle(m,1),' ',nangle(m,2),' ',
c     &        nangle(m,3)
c      end do

      write(9,'(a,i5)')        'No. torsions     = ',n_t

c      do m=1,nt
c         write(4,*) ntorsion(m,1),' ',ntorsion(m,2),' ',
c     &        ntorsion(m,3),' ',ntorsion(m,4)
c      end do

      write(9,'(a,i5)')        'No. out of plane = ',n_o
c      do m=1,no
c         write(4,*) noop(m,1),' ',noop(m,2),' ',
c     &        noop(m,3),' ',noop(m,4)
c      end do

c
c......... Create excluded interaction list for covalent bonds and angles
c
c    excl_atom(i,ii) - pair-wise interaction between i,ii to be removed
c                      (is only used in energy() and gradients3())
c
      do jj=1,n_b
         i =nbond(jj,1)
         ii=nbond(jj,2)
         excl_atom(i,ii) = .true.
         excl_atom(ii,i) = .true.
      end do
      do j=1,n_a
         i =nangle(j,1)
         ii=nangle(j,3)
         excl_atom(i,ii) = .true.
         excl_atom(ii,i) = .true.
      end do
      return
      end

      double precision function diag_energy(iPrnt)
c.............................................................
c     function that calculates the diagonal energy of the    .
c     of the molecule                                        .
c.............................................................
      include 'shell.inc'

      double precision length,angle,torsion,oop
      double precision energy

      energy=0.0d0

c.....calculating energy of all bonds (quadratic)
c_____looping over all bonds

      do i=1,n_b
         length=bond_l(x(nbond(i,1)),y(nbond(i,1)),z(nbond(i,1)),
     &        x(nbond(i,2)),y(nbond(i,2)),z(nbond(i,2)))
         energy=energy + (pbond(i,2)*(length-pbond(i,1))**2)
      end do

c.....calculating energy of all angles
c_____looping over all angles

      do i=1,n_a
c_____calculating angle
         angle=angle_theta(x(nangle(i,1)),y(nangle(i,1)),z(nangle(i,1)),
     &        x(nangle(i,2)),y(nangle(i,2)),z(nangle(i,2)),
     &        x(nangle(i,3)),y(nangle(i,3)),z(nangle(i,3)))
c_____calculating energy (also converting parameter in degrees to rads)
         energy=energy + (pangle(i,2)*((angle-radians(pangle(i,1)))**2))
      end do
      
c.....calculating energy of all torsions
c_____looping over all torsions

      do i=1,n_t
c_____calculating angle
         torsion=torsion_phi(x(ntorsion(i,1)),y(ntorsion(i,1)),
     &        z(ntorsion(i,1)),
     &        x(ntorsion(i,2)),y(ntorsion(i,2)),z(ntorsion(i,2)),
     &        x(ntorsion(i,3)),y(ntorsion(i,3)),z(ntorsion(i,3)),
     &        x(ntorsion(i,4)),y(ntorsion(i,4)),z(ntorsion(i,4)))
c_____calculating energy (converting parameter in degrees to radians)
         energy=energy + (ptorsion(i,1)*(1+cos((ptorsion(i,2)*torsion)-
     &        radians(ptorsion(i,3)))))
      end do


c.....calculating energy of all out-of plane interactions
c_____looping over all out-of-plane

      do i=1,n_o
c_____calculating angle
         oop=oop_chi(x(noop(i,1)),y(noop(i,1)),z(noop(i,1)),
     &        x(noop(i,2)),y(noop(i,2)),z(noop(i,2)),
     &        x(noop(i,3)),y(noop(i,3)),z(noop(i,3)),
     &        x(noop(i,4)),y(noop(i,4)),z(noop(i,4)))
c_____calculating energy (converting parameter in degrees to radians)
         energy=energy + (poop(i,1)*(1+cos((poop(i,2)*oop)-
     &        radians(poop(i,3)))))
      end do

      diag_energy=energy
      end

      double precision function bond_l(x1,y1,z1,x2,y2,z2)
c...........................................................
c     function to return bond lengths given cartesian      .
c     coordinates and molecule atom index numbers of the   .
c     two atoms forming the bond                           .
c...........................................................
      double precision x1,y1,z1,x2,y2,z2,xt,yt,zt
c.....calculate bond length
      xt=x1-x2
      yt=y1-y2
      zt=z1-z2
      bond_l=sqrt((xt*xt)+(yt*yt)+(zt*zt))
      end

      double precision function angle_theta(x1,y1,z1,x2,y2,z2,x3,y3,z3)
c............................................................
c     function to return angle of three body interactions   .
c     given cartesian coordinates and molecule atom index   .
c     numbers of the three atoms                            .
c............................................................
      double precision x1,y1,z1,x2,y2,z2,x3,y3,z3,xt1,yt1,zt1,xt2
      double precision dotprod1,mag1,mag2,yt2,zt2
c.....calculate angle between two bonds (angle a-b-c)
      xt1=x1-x2
      yt1=y1-y2
      zt1=z1-z2
      xt2=x3-x2
      yt2=y3-y2
      zt2=z3-z2
      dotprod1=xt1*xt2 + yt1*yt2 + zt1*zt2
      mag1=sqrt(xt1*xt1+yt1*yt1+zt1*zt1)
      mag2=sqrt(xt2*xt2+yt2*yt2+zt2*zt2)
      angle_theta=acos(dotprod1/(mag1*mag2))
      end

      double precision function torsion_phi(x1,y1,z1,x2,y2,z2,x3,y3,
     ,     z3,x4,y4,z4)
c.............................................................
c     function to return the torsional four body angle given .
c     the cartesian coordinates and molecule atom indexes    .
c     of the four atoms involved in the torsion angle        .
c.............................................................
      double precision x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4
      double precision xt1,yt1,zt1,xt2,yt2,zt2,xt3,yt3,zt3
      double precision xcross1,ycross1,zcross1,ratio2
      double precision xcross2,ycross2,zcross2,dotprod1
      double precision theta1,theta2,ratio1,mag1,mag2,magt2

c.....calculate torsional angle (angle i-j-k-l)
c_____calculate three vectors for adjacent bonds (1 for i-j, 
c_____2 for j-k, 3 for k-l)
      xt1=x2-x1
      yt1=y2-y1
      zt1=z2-z1         
      xt2=x3-x2
      yt2=y3-y2      
      zt2=z3-z2         
      xt3=x4-x3
      yt3=y4-y3
      zt3=z4-z3
c_____calculate cross products
c_____cross1 for vectors j-k and i-j
      xcross1= -yt2*zt1 + zt2*yt1
      ycross1=xt2*zt1 - zt2*xt1
      zcross1=yt2*xt1 - xt2*yt1
c_____cross2 for vectors k-l and i-j
      xcross2= -yt3*zt2 + zt3*yt2
      ycross2=xt3*zt2 - zt3*xt2
      zcross2=yt3*xt2 - xt3*yt2
c_____dot product of the two cross products
      dotprod1=xcross1*xcross2 + ycross1*ycross2 + zcross1*zcross2
c_____the magnitudes of the two cross products
      mag1=sqrt(xcross1*xcross1 + ycross1*ycross1 + zcross1*zcross1)
      mag2=sqrt(xcross2*xcross2 + ycross2*ycross2 + zcross2*zcross2)
      magt2=sqrt(xt2*xt2 + yt2*yt2 + zt2*zt2)
      ratio1=dotprod1/(mag1*mag2)
      ratio2=(xt2*(ycross2*zcross1-zcross2*ycross1)+
     &     yt2*(xcross1*zcross2-zcross1*xcross2)+
     &     zt2*(xcross2*ycross1-ycross2*xcross1))/(mag1*mag2*magt2)
      torsion_phi=atan2(ratio2,ratio1)
      end

      double precision function oop_chi(x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,
     ,     y4,z4)
c.........................................................
c     function that takes the cartesian coordinates and  .
c     molecule atom indexes involved in an out-of-plane  .
c     interaction and returns the out-of-plane angle     .
c                                                        .
c     j is the central atom                              .
c.........................................................
      double precision x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4
      double precision xt1,yt1,zt1,xt2,yt2,zt2,xt3,yt3,zt3
      double precision xcross1,ycross1,zcross1
      double precision xcross2,ycross2,zcross2
      double precision mag1,mag2,magt2
c.....calculate the improper torsional angle (angle i-k-l-j)

c_____calculate three vectors for adjacent bonds (1 for i-k, 
c_____2 for j-k, 3 for l-j)
      xt1=x3-x1
      yt1=y3-y1
      zt1=z3-z1         
      xt2=x4-x3
      yt2=y4-y3      
      zt2=z4-z3         
      xt3=x2-x4
      yt3=y2-y4
      zt3=z2-z4
c_____calculate cross products
c_____cross1 for vectors j-k and i-j
      xcross1= -yt2*z1 + zt2*yt1
      ycross1=xt2*zt1 - zt2*xt1
      zcross1=yt2*xt1 - xt2*yt1
c_____cross2 for vectors k-l and i-j
      xcross2= -yt3*zt2 + zt3*yt2
      ycross2=xt3*zt2 - zt3*xt2
      zcross2=yt3*xt2 - xt3*yt2
c_____dot product of the two cross products
      dotprod1=xcross1*xcross2 + ycross1*ycross2 + zcross1*zcross2
c_____the magnitudes of the two cross products
      mag1=sqrt(xcross1*xcross1 + ycross1*ycross1 + zcross1*zcross1)
      mag2=sqrt(xcross2*xcross2 + ycross2*ycross2 + zcross2*zcross2)
c_____and finally......the oop angle
      magt2=sqrt(xt2*xt2 + yt2*yt2 + zt2*zt2)
      ratio1=dotprod1/(mag1*mag2)
      ratio2=(xt2*(ycross2*zcross1-zcross2*ycross1)+
     &     yt2*(xcross1*zcross2-zcross1*xcross2)+
     &     zt2*(xcross2*ycross1-ycross2*xcross1))/(mag1*mag2*magt2)
      oop_chi=atan2(ratio2,ratio1)

c      oop_chi=acos(dotprod1/(mag1*mag2))
c      if(oop_chi.gt.acos(0.0)) then
c         oop_chi = 2*acos(0.0) - oop_chi
c      end if
c      write(*,*)'chi ',oop_chi
c      return
      end

      double precision function radians(degrees)
c...................................................................
c     function to return radians given an angle in degrees         .
c...................................................................
      double precision degrees
      double precision zero
      zero=0
      radians=degrees * (acos(zero)/90)
      end

      double precision function degrees(radians)
c...................................................................
c     function to return radians given an angle in degrees         .
c...................................................................
      double precision radians
      double precision zero
      zero=0
      degrees=radians * (90/acos(zero))
      end
