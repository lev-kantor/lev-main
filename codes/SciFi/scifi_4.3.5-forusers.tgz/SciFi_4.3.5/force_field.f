      double precision function tip_surface_force(dps)
c...............................................................
c     The vertical force between tip and surface at vertical
c distance dps and the lateral position XY(xy) is calculated:
c
c   force = microscopic + vdW
c
c The short-range force is interpolated between given points.
c...............................................................
      include 'virtual.inc'
      include 'forces.inc'
      include 'share.inc'
      dimension fr(2)
      double precision kk1,kk2,kk3,interpl,tipf(3),displ(2)
c
c............... check if the distance is reasonable
c
      if(dps.lt.threshold) then
         write(*,'(2(a,e12.6))')
     &             'FATAL! Distance dps = ',dps, ' < ',threshold 
         write(9,'(2(a,e12.6))')
     &             'FATAL! Distance dps = ',dps, ' < ',threshold 
         stop 'ERROR in the distance'
      else if(dps.gt.threshold+D1+A0) then
         write(*,'(2(a,e12.6))')
     &             'FATAL! Distance dps = ',dps, ' > ',threshold+D1+A0 
         write(9,'(2(a,e12.6))')
     &             'FATAL! Distance dps = ',dps, ' < ',threshold+D1+A0 
         stop 'ERROR in the distance'
      end if
      ftip=0.0d0
c
c{A}............... vdW is always needed
c
      vdW=-HAMAK*RADIUS/(6.d0*dps*dps)
c
c{B}.............. if the LONG-RANGE force is needed
c
      IF (dps .gt. bound) THEN
         dd=dps+z0
         ftip=g0+(g1+(g2+(g3+(g4+(g5+g6/dd)/dd)/dd)/dd)/dd)/dd
      ELSE
c
c{C}.............. if the SHORT-RANGE force is needed
c
         if(scifi_and_vafm) then

c{C.1}_______________ call SCI-FI force here: 
c                     do the interpolation if required
            displ(1)=Vx*dt*m_au
            displ(2)=Vy*dt*m_au
            if(interpolate) then
               call force_predict(displ,dps,ftip)
            else
               call pos_and_relax(displ,dps*m_au,0,' stop ',.true.,
     ,                                                toten,tipf)
               ftip=tipf(3)*au_N
            end if

c{C.2}_______________ call the force field here
         else 

c[1]_________ obtain fractional coordinates fr(xy) for the point
c             XY(xy) within the 0-th cell
            call reducn_2D(XY,fr,BI)

c[2]_________ find 4 fractional points with the known force field
c             which surround the given point; these are:
c             (i1,j1),(i1,j2),(i2,j1) and (i2,j2).
            c1=fr(1)*j1_ftip
            i1=int(c1)
            i2=i1+1
            if(i2.gt.j1_ftip) i2=j1_ftip
            c2=fr(2)*j2_ftip
            j1=int(c2)
            j2=j1+1
            if(j2.gt.j2_ftip) j2=j2_ftip

c[3]__________ interpolate the force for each lateral point
c              for the given z = dps

            f11=interpl(cz,all_force(1,i1,j1),nz,dps)
            f12=interpl(cz,all_force(1,i1,j2),nz,dps)
            f21=interpl(cz,all_force(1,i2,j1),nz,dps)
            f22=interpl(cz,all_force(1,i2,j2),nz,dps)

c[4]__________ interpolate linearly the force between the four points
c              using:    y(x)=kk*(x-x1)+y1 
c
            kk1=f12-f11
            f11_12=kk1*(c2-j1)+f11
            kk2=f22-f21
            f21_22=kk2*(c2-j1)+f21
            kk3=f21_22-f11_12
            ftip=kk3*(c1-i1)+f11_12
         end if
      END IF
c
c{C}.............. final force
c
      tip_surface_force=ftip+vdW
      return
      end

      subroutine reducn_2D(x,r,BJ)
c..................................................................
c INPUT:
c^^^^^^^^
c   x()     - Cartesian coordinate of the 2D point
c BJ(#,xyz) - reciprocal lattice vectors  
c
c OUTPUT:
c^^^^^^^^
c  r() - the point x() in fractional coordinates within the 
c        0-th unit cell 
c..................................................................
      include 'real8.inc'
      dimension x(2),BJ(2,2),r(2)
      data tiny/0.000001/
c
c________ get fractional coordinates of x()
c
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)
c
c________ extract the integer part from the coefficients and do them
c         closer to the nearest integer if the difference is small
c
      do i=1,2
        r(i)=r(i)-int(r(i))
        if(r(i).lt.0.0) r(i)=r(i)+1.0
      end do
      return 
      end

      subroutine INVER2(AI,BI,iErr)
c...............................................................
c....... build reciprocal basic vectors BI(number,component) (in
c units of 2*PI) from the direct ones, AI(number,component) for
c the 2-dimensional case (3-component is suppressed)
c...............................................................
      include 'real8.inc'
      double precision one,zero
      logical iErr
      data one/1.0/,zero/0.0/
      dimension AI(2,2), BI(2,2)
      iErr=.false.
      a1_2=AI(1,1)**2+AI(1,2)**2
      a2_2=AI(2,1)**2+AI(2,2)**2
      a1_a2=AI(1,1)*AI(2,1)+AI(1,2)*AI(2,2)
      DET= a1_2 * a2_2  -  a1_a2
      if(abs(DET).lt.tiny) then
         write(*,*)'FATAL! Bad 2D lattice vectors'
         iErr=.true.
         return
      end if
      DET=one/DET
      BI(1,1)=( a2_2*AI(1,1) - a1_a2*AI(2,1) )*DET
      BI(1,2)=( a2_2*AI(1,2) - a1_a2*AI(2,2) )*DET
      BI(2,1)=( a1_2*AI(2,1) - a1_a2*AI(1,1) )*DET
      BI(2,2)=( a1_2*AI(2,2) - a1_a2*AI(1,2) )*DET
      RETURN
      END

      subroutine test_force()
c...............................................................
c     The vertical force between tip and surface at a set of
c vertical distances is calculated.
c...............................................................
      include 'virtual.inc'
      include 'forces.inc'

      open(14,file='ftip.dat',form='formatted')
      write(14,'(2(a,f10.5),a)') 
     &     '# force field for given X,Y=(',XY(1),',',XY(2),')' 
      write(14,'(a)') '#  z (in A)    vdW (in eV/A)  chemical'//
     &     ' (in e/V)   total (in eV/A)     energy (in eV)'   

ccccccccccccccccccc this is test ccccccccccccccccccccccccccccccccccccc
c      i=0
c      dps=0.1299828000E+02*A_m
c 10   ftip_tot=tip_surface_force(dps)
c      i=i+1
c      write(14,'(f10.5,4(5x,e20.10))') 
c     &   dps*m_A,vdW*N_eVpA,ftip*N_eVpA,ftip_tot*N_eVpA,toten*au_eV
c      write(*,'(f10.5,4(5x,e20.10))') 
c     &   dps*m_A,vdW*N_eVpA,ftip*N_eVpA,ftip_tot*N_eVpA,toten*au_eV
c      dps=dps-0.1*A_m
c      if(i.lt.20) go to 10
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      dps=D1+A0+test_step
 10   dps = dps - test_step
      ftip_tot=tip_surface_force(dps)
      write(14,'(f10.5,3(5x,e12.6))') 
     &   dps*m_A,vdW*N_eVpA,ftip*N_eVpA,ftip_tot*N_eVpA,toten*au_eV
      if(dps.gt.threshold) go to 10
      close (14)

      return
      end
         
      subroutine force_predict(displ,dps,tipf)
c............................................................................
c          The tip force is predicted from available force values: here at 
c least interpolation (and possibly extrapolation) are supposed to be .true.
c............................................................................
      include 'virtual.inc'
      include 'forces.inc'
      include 'share.inc'
      double precision tipf(3),displ(2)

c.............. make sure that the first values of the force field are available
      if(jf_stored.eq.0) then
         call pos_and_relax(displ,bound*m_au,0,' stop ',.true.,
     ,        toten,tipf)
         jf_stored=1
         Z_stored(jf_stored)=bound
         f_stored(jf_stored)=tipf(3)*au_N
         write(29,'(i5,x,f10.5,x,e20.12)') jf_stored,
     ,        z_stored(jf_stored)*m_A,f_stored(jf_stored)*N_eVpA
         call pos_and_relax(displ,dps*m_au,0,' stop ',.true.,toten,tipf)
         ftip=tipf(3)*au_N
         jf_stored=2
         Z_stored(jf_stored)=dps
         f_stored(jf_stored)=ftip
         write(29,'(i5,x,f10.5,x,e20.12)') jf_stored,
     ,        z_stored(jf_stored)*m_A,f_stored(jf_stored)*N_eVpA
         
c............... calculate the force and then store it
      else if(dps.lt.Z_stored(jf_stored)) then
         call pos_and_relax(displ,dps*m_au,0,' stop ',.true.,toten,tipf)
         ftip=tipf(3)*au_N
         jf_stored=jf_stored+1
         if(jf_stored.gt.Nf_stored) then
            write(9,'(a)')'ERROR! Max working array reached!'
            write(*,'(a)')'ERROR! Max working array reached!'
            stop
         end if
         Z_stored(jf_stored)=dps
         f_stored(jf_stored)=ftip
c________________________________ smooth out the force field
         if(smooth .and. jf_stored.gt.num_smooth) then
            ff=0.0
            do jf=jf_stored-num_smooth+1,jf_stored
               ff=ff+f_stored(jf)
            end do
            jf1=jf_stored-(num_smooth-1)/2
            f_stored(jf1)=ff/num_smooth
            write(30,'(i5,x,f10.5,x,e20.12)') jf1,
     ,           z_stored(jf1)*m_A,f_stored(jf1)*N_eVpA
         end if
         write(29,'(i5,x,f10.5,x,e20.12)') jf_stored,
     ,        z_stored(jf_stored)*m_A,f_stored(jf_stored)*N_eVpA
         
c............... interpolate the force
      else
         do j=1,jf_stored-1
            if(dps.lt.Z_stored(j).and.dps.gt.Z_stored(j+1))then
               tg=(f_stored(j+1)-f_stored(j))/
     /              (Z_stored(j+1)-Z_stored(j))
               ftip=f_stored(j)+(dps-Z_stored(j))*tg
               write(29,'(a,f10.5,2(a,i5),a,e20.12)')
     ,              '# interpl z=',dps*m_A,' between ',j,
     &              ' and ',j+1,' => ftip= ',ftip*N_eVpA
               return
            end if
         end do
         write(*,'(a,e12.6)')'ERROR in interpl for z = ',dps*m_A 
         write(9,'(a,e12.6)')'ERROR in interpl for z = ',dps*m_A 
         stop
      end if
      return
      end

