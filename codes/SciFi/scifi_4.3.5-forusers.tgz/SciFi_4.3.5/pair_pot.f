      double precision function cut_off_fun(r,cut)
c_______decay function for the short-range potential
      include 'shell.inc'
      double precision r
      cut_off_fun=1.0
      if(r.gt.cut)          cut_off_fun=0.0d0
      return
c      roo=0.4d0
c      d1=exp(-(r-cut)/roo)
c      cut_off_fun=d1/(d1+1.0d0)
c      return
      end

      double precision function dcut_off_fun(r,cut)
c_______derivative of the decay function 
      include 'shell.inc'
      double precision r
      dcut_off_fun=1.0
      if(r.gt.cut)          dcut_off_fun=0.0d0
      return
c      roo=0.4d0
c      d1=exp(-(r-cut)/roo)
c      dcut_off_fun= -d1/(roo*(1.0d0+d1)**2)
c      return
      end

      double precision function Pot(IS,IS1,R)
c.....................................................................
c  For every pair of species IS,IS1 of atoms, separated by the distance
c  R, the potential Pot=V(R) is calculated.
c.....................................................................
c  One type of the analytical form of the V(R) is acceptable, namely:
c  the sum of the exponetial terms distinguished by n,
c         ParD(k,n,1,1)*exp(-ParD(k,n,2,1)*R),    n=1,...,iPotV(k,1),
c  and terms with powers,
c         ParD(k,n,1,2)/R**ParD(k,n,2,2),         n=1,...,iPotV(k,2).
c where
c            / (IS1-1)*KINDS+IS , if IS.le.IS1
c        k= |                                   is a join pair index.
c            \ (IS-1)*KINDS+IS1 , if IS1.le.IS
c.....................................................................
      include 'shell.inc'
c........ find k:
      if(IS1.le.IS) then
          k=IS1+(IS-1)*IS/2
      else
          k=IS+(IS1-1)*IS1/2
      end if
      cut=CutOff(k)

      Pot=0.0d0
c      if(R.gt.CutOff(k)) return
      if(iPotD(k,1).eq.0) go to 100
c
c---------------------------------------------------------------------
c  the potential:  the sum of exponentials A(n)*exp(-a(n)*R)
c---------------------------------------------------------------------
      do n=1,iPotD(k,1)
         a=R/ParD(k,n,2,1)
         Pot=Pot+ParD(k,n,1,1)*exp(-a)
      end do
 100  if(iPotD(k,2).eq.0) go to 200
c
c---------------------------------------------------------------------
c  the potential:  the sum of powers B(n)/R**b(n)
c---------------------------------------------------------------------
      do n=1,iPotD(k,2)
         pn=ParD(k,n,2,2)
         Pot=Pot+ParD(k,n,1,2)/R**pn
      end do
 200  if(Pot.ne.0.0d0) then
         if(do_cutoff) Pot=Pot*cut_off_fun(R,cut)
      end if            
      return
      end

      double precision function Der_Pot(IS,IS1,R)
c.....................................................................
c  For every pair of species IS,IS1 of atoms, separated by the distance
c  R, the derivative of the potential Der() wrt distance is calculated.
c                                           ^^^^^^^^^^^^  
c.....................................................................
c  One type of the analytical form of the V(R) is acceptable, namely:
c  the sum of the exponetial terms distinguished by n,
c         ParD(k,n,1,1)*exp(-ParD(k,n,2,1)*R),    n=1,...,iPotV(k,1),
c  and terms with powers,
c         ParD(k,n,1,2)/R**ParD(k,n,2,2),         n=1,...,iPotV(k,2).
c where
c            / (IS1-1)*KINDS+IS , if IS.le.IS1
c        k= |                                   is a join pair index.
c            \ (IS-1)*KINDS+IS1 , if IS1.le.IS
c.....................................................................
      include 'shell.inc'
c........ find k:
      if(IS1.le.IS) then
          k=IS1+(IS-1)*IS/2
      else
          k=IS+(IS1-1)*IS1/2
      end if
      cut=CutOff(k)

      Pot=0.0d0
      Der_Pot=0.0d0
c      if(R.gt.CutOff(k)) return
      if(iPotD(k,1).eq.0) go to 100
c
c---------------------------------------------------------------------
c  the potential:  the sum of exponentials A(n)*exp(-a(n)*R)
c---------------------------------------------------------------------
      do n=1,iPotD(k,1)
         a=R/ParD(k,n,2,1)
         ae=exp(-a)
         Der_Pot=Der_Pot-ParD(k,n,1,1)*ae/ParD(k,n,2,1)
         Pot=Pot+ParD(k,n,1,1)*ae
      end do
 100  if(iPotD(k,2).eq.0) go to 200
c
c---------------------------------------------------------------------
c  the potential:  the sum of powers B(n)/R**b(n)
c---------------------------------------------------------------------
      do n=1,iPotD(k,2)
         pn=ParD(k,n,2,2)
         ae=ParD(k,n,1,2)/R**pn
         Der_Pot=Der_Pot-pn*ae/R
c         Der_Pot=Der_Pot-pn*ParD(k,n,1,2)/R**(pn+1)
         Pot=Pot+ae
      end do
 200  if(Pot.ne.0.0d0) then
         if (do_cutoff) Der_Pot=Der_Pot*cut_off_fun(R,cut) + 
     +        Pot*dcut_off_fun(R,cut)
      end if
      return
      end

