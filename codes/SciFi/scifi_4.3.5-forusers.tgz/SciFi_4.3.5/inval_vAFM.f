      subroutine Inval_vAFM(NFIL,virtual_AFM)
      include 'real8.inc'
      include 'forces.inc'
c.....................................................................
c      Read all the parameters for the virtual AFM from the file 
c  UNIT=NFIL.
c......................................................................
      logical virtual_AFM
      iErr=0
      virtual_AFM=.false.
c
c_____________ reading in general paramaters and defaults
      write(9,'(/a/)')'))))))))))))))))))))))))) virtual AFM box ((('
     &     //'(((((((((((((((((((((((('
      call read_machine(NFIL,iErr)
      if(iErr.eq.2) then
         write(9,'(a)')'WARNING! Virtual AFM box was NOT found!'
         write(9,'(a)')'         NO Virtual AFM then!'
         write(*,'(a)')'WARNING! Virtual AFM box was NOT found!'
         write(*,'(a)')'         NO Virtual AFM then!'
         return
      end if
c
c_____________ reading in the force field
      write(9,'(/a/)')'))))))))))))))))))))))))) Force_Field box ((('
     &     //'(((((((((((((((((((((((('
      call read_force_field(NFIL,iErr)
c
c_____________ reading in elementary stages
      if(.not.do_force_test) then
         write(9,'(/a/)')'))))))))))))))))))))))))) Elementary_Stages'
     &     //' box ((((((((((((((((((((((((((('
         call read_elementary_stages(NFIL,iErr)
      end if
c
c_____________ finish reading in data
      if(iErr.eq.1) then
         write(9,'(a)') 
     &        'FATAL errors in the virtual AFM input file. STOP'
         stop
      end if
      write(9,'(/a/)')'######################### END OF INPUT '
     &     //' ###########################'
      virtual_AFM=.true.
      return
      end

      subroutine read_machine(NFIL,iErr)
c.....................................................................
c      Read all the parameters for the virtual AFM from the file 
c  UNIT=NFIL.
c......................................................................
      include 'virtual.inc'
      include 'noise.inc'
      character Line*120,na2*2,cha(4)*1
      integer LPos(30),LEnd(30),Z_pixels
c
c......................................................................
c............. set default values first ...............................
c......................................................................
c
c................  Parameters of the probe:
      K0    =  6.0
      f0    =  60406.0
      Q     =  10000.0

c............... AGC (Automatic Gain Control): keeping the amplitude 
c                constant 
      P_AGC  = 0.1
      I_AGC  = 2.0
      tauD   = 0.002

c............... PLL (FM demodulator)
      tau1   = 5.0d-5
      tau2   = 1.6d-4
      gainPB = 6.0
      K1     = 220.0
      phase  = -pi/2.0

c............... PLL (Automatic Distance Control)
      Padc  = 7.0d-11
      Iadc1  = 5.d-9
      Iadc0 = 50.d-9

c............... Times/# of cycles
      n_stabil1  = 4
      Stab_Time2 = 15.0d-3
      tRes       = 100

c............... the number of timesteps per single oscillation
c                period
      Z_pixels = 400

c............... General set point values (defaults)
      D1    =   34.25d-09
      DEBUG = .false.
      when_debug=10
      A0    =   31.25d-9
      DFC   = -100.0
      NoiseF = .false.
      NoiseA = .false.
      Temp = 300.0d0
      XY(1)=0.0d0
      XY(2)=0.0d0
c
c...... Seeks for the box marker: [.<VirtualAFM>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<VirtualAFM>',13,NFIL,iEr)
      if(iEr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      iw=0
      l=0
c_______________ read every line here one by one in a loop

 20   call CutStr(Line,NumLin,LPos,LEnd,NFIL,iEr)
      l=l+1
      if(iEr.ne.0) go to 50

c_______________ finish reading the box here by finding the end marker

      if(index(line,'.<End>').ne.0) go to 30

c_______________ interpret the read line and set parameters

      if(index(line(LPos(1):LEnd(1)),'Elastic_Constant').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) K0
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &              '...> found (',iw,') new value for K0 = ',K0

      else 
     &   if(index(line(LPos(1):LEnd(1)),'Natural_Frequency').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) f0
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &               '...> found (',iw,') new value for f0 = ',f0

      else 
     &   if(index(line(LPos(1):LEnd(1)),'Start{X,Y}').ne.0) then
         if(NumLin.lt.3) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) XY(1),XY(2)
         iw=iw+1
         write(9,'(a,i2,a,2(e12.6,a))')
     &               '...> found (',iw,') new value for start = (',
     &                XY(1),',',XY(2),')'

      else 
     &   if(index(line(LPos(1):LEnd(1)),'Debug').ne.0) then
         if(NumLin.lt.3) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'T') DEBUG=.true.
         read(Line(LPos(3):),*,END=50,ERR=50) when_debug
         iw=iw+1
         write(9,'(a,i2,a,l,a,i5)')
     &          '...> found (',iw,') new value for debug = ',DEBUG,
     &          ' and when_debug = ',when_debug

      else if(index(line(LPos(1):LEnd(1)),'Q-factor').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) Q
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &             '...> found (',iw,') new value for Q = ',Q

      else if(index(line(LPos(1):LEnd(1)),'SetPnt_Amplitude').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) A0
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &             '...> found (',iw,') new value for A0 = ',A0

      else if(index(line(LPos(1):LEnd(1)),'SetPnt_FreqShift').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) DFC
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &             '...> found (',iw,') new value for DFC = ',DFC

      else if(index(line(LPos(1):LEnd(1)),'Initial_Z').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) D1
         iw=iw+1
         write(9,'(a,i2,a,e12.6)') 
     &               '...> found (',iw,') new value for D1 = ',D1

      else if(index(line(LPos(1):LEnd(1)),'noise{F,A,Temp}').ne.0) then
         if(NumLin.lt.4) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'T') NoiseF=.true.
         if(Line(LPos(3):LEnd(3)).eq.'T') NoiseA=.true.
         read(Line(LPos(4):),*,END=50,ERR=50) Temp
         iw=iw+1
         write(9,'(a,i2,a,2(/a,l),/a,f10.5,a)') 
     &     '...> found (',iw,') new values for:',
     &     'NoiseF = ',NoiseF,' NoiseA = ',NoiseA,' Temp = ',Temp,' K'

      else if(index(line(LPos(1):LEnd(1)),'AGC{P,I,tau}').ne.0) then
         if(NumLin.lt.4) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) P_AGC,I_AGC,tauD
         iw=iw+1
         write(9,'(a,i2,a,3(/a,e12.6))') 
     &        '...> found (',iw,') new values for:',
     &        'P_AGC = ',P_AGC, 'I_AGC = ',I_AGC,'tauD = ',tauD 

      else if(index(line(LPos(1):LEnd(1)),
     &                        'PLL_FMdem{t1,t2,gainPB,K1}').ne.0) then
         if(NumLin.lt.5) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) tau1,tau2,gainPB,K1
         iw=iw+1
         write(9,'(a,i2,a,4(/a,e12.6))') 
     &        '...> found (',iw,') new values for:','tau1 = ',tau1, 
     &        'tau2 = ',tau2,'gainPB = ',gainPB,'K1 = ',K1

      else if(index(line(LPos(1):LEnd(1)),'PLL_ADC{P,I0,I}').ne.0) then
         if(NumLin.lt.4) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) Padc,Iadc0,Iadc1
         iw=iw+1
         write(9,'(a,i2,a,3(/a,e12.6))') 
     &        '...> found (',iw,') new values for:',
     &        'Padc = ',Padc, 'Iadc0 = ',Iadc0,' Iadc1 = ',Iadc1

      else 
     &  if(index(line(LPos(1):LEnd(1)),'t-steps_in_period').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) Z_pixels
         iw=iw+1
         write(9,'(a,i2,a,i10)') 
     &    '...> found (',iw,') new values for: Z_pixels = ',Z_pixels

      else if(index(line(LPos(1):LEnd(1)),'Stabil_Time1').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) n_stabil1
         iw=iw+1
         write(9,'(a,i2,a,i5)') 
     &    '...> found (',iw,') new values for: n_stabil1 = ',n_stabil1

      else if(index(line(LPos(1):LEnd(1)),'Stabil_Time2').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) Stab_Time2 
         iw=iw+1
         write(9,'(a,i2,a,e12.6)') 
     &   '...> found (',iw,') new values for: Stab_Time2 = ',Stab_Time2 

      else if(index(line(LPos(1):LEnd(1)),'Print_Cycles').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) tRes
         iw=iw+1
         write(9,'(a,i2,a,e12.6)') 
     &   '...> found (',iw,') new values for: tRes = ',tRes

      end if
      go to 20

c................  Print all

 30   write(9,'(a)')
     &     '...........<VirtualAFM> box is read correctly ..........'

c_____________ Times
      write(9,'(/a/)')'>>>>>>>>>>>>>>> Times used <<<<<<<<<<<<<<<<<<<'
      dt = 1.d0/ (f0*Z_pixels)
      write(9,'(a,e12.6,a)')'Timestep dt                = ',dt,' sec'
      Stab_Time1 = n_stabil1/f0
      write(9,'(a,i5)')'Number of timesteps per oscillation period = ',
     ,            Z_pixels
      write(9,'(a,e12.6,a)')
     &     'Stabilisation time stage 1 = ',Stab_Time1,' sec'
      write(9,'(a,e12.6,a)')
     &     'Stabilisation time stage 2 = ',Stab_Time2,' sec'
      write(9,'(a,i6,a)')
     &     'Nice printout to signals.dat every ',tRes,' cycles'
      write(9,'(a,l)') 'Debugging = ',DEBUG

c_____________ Probe
      write(9,'(/a/)')'>>>>>>>>>>>>>>>>> Probe <<<<<<<<<<<<<<<<<<<<<<'
      w0=2*pi*f0
      w02=w0*w0
      mass = K0/w02
      write(9,'(a,e12.6,a)')'Elastic constant   (K0)   = ',K0,' N/m' 
      write(9,'(a,e12.6,a)')'Natural frequency  (f0)   = ',f0,' Hz' 
      write(9,'(a,e12.6,a)')'Natural frequency  (w0)   = ',w0,' Hz' 
      write(9,'(a,e12.6,a)')'Mass                      = ',mass,' Kg' 
      gamma = w0/Q
      write(9,'(a,e12.6,a)')
     &               'Friction (=w0/Q)          = ',gamma,' sec^(-1)'

c_____________ Setpoints
      write(9,'(/a/)')'>>>>>>>>>>>>>>>> Setpoints <<<<<<<<<<<<<<<<<<<'
      write(9,'(a,e12.6,a)')'Amplitude                 = ',A0,' m' 
      write(9,'(a,e12.6,a)')
     &     '                          = ',A0*1.0d10,' A' 
      write(9,'(a,e12.6,a)')'Frequency shift           = ',DFC,' Hz' 
      write(9,'(a,2(f10.5,a))')'Starting point at X= ',XY(1)*m_A,
     &       ' A and Y= ',XY(2)*m_A,' A'

c______________ AGC
      write(9,'(/a/)')'>>>>>>>>>> Automatic Gain Control <<<<<<<<<<<<'
      write(9,'(a,e12.6,a)')'P                         = ',P_AGC,' N/m'
      write(9,'(a,e12.6,a)')
     &     'I                         = ',I_AGC,' N/m*sec'
      write(9,'(a,e12.6,a)')'Time constant             = ',tauD,' sec' 

c______________ PLL (FM demodulator)
      write(9,'(/a/)')'>>>>>>>>>> PLL (FM demodulator) <<<<<<<<<<<<<<'
      write(9,'(a,e12.6,a)')'Time constant 1           = ',tau1,' sec' 
      write(9,'(a,e12.6,a)')'Time constant 2           = ',tau2,' sec' 
      write(9,'(a,e12.6)')  'gainPB parameter          = ',gainPB
      write(9,'(a,e12.6,a)')'Frequency prefactor       = ',K1
      
c______________ PLL (Automatic Distance Control)
      write(9,'(/a/)')'>>>>>> PLL (Automatic Distance Control) <<<<<<'
      write(9,'(a,e12.6,a)')'P                         = ',Padc,' m*s'
      write(9,'(2(a,e12.6,a/))')
     &     'I (initial)               = ',Iadc0,' m',
     &     'I (working)               = ',Iadc1,' m'
      
c_______________ Noise
      write(9,'(/a/)')'>>>>>>>>>>>> Noise <<<<<<<<<<<<<<<'
      if(NoiseF) then
         write(9,'(a)')' ===> noise in the force is ON'
      else
         write(9,'(a)')' ===> noise in the force is OFF'
      end if
      if(NoiseA) then
         write(9,'(a)')' ===> noise in the amplitude is ON'
      else
         write(9,'(a)')' ===> noise in the amplitude is OFF'
      end if
      write(9,'(a,f10.5,a)')'temperature = ',Temp,' K'
c____________________ setting up everytihng for the noise
      if(NoiseF.or.NoiseA) then
         Unoise=0
         Fnoise=0.0d0
         Znoise=0.0d0
         call NoiseVariance (Q,K0,W0,dt)
c__________________________ IJ,KL - seeds needed to initialise 
c                                   random numbers
         IJ = 1802
         KL = 9373
         call rmarin(IJ,KL)
c__________________________ get noise vectors
         if(NoiseF) call gauss(bruitF,long)
         if(NoiseA) call gauss(bruitA,long)
      end if

      return
c
c.......... error messages
c
 40   write(9,'(a)') 'WARNING! Box <VirtualAFM> not found! Ignored'
      write(*,'(a)') 'WARNING! Box <VirtualAFM> not found! Ignored'
      iErr=2
      return
 50   write(*,'(a,i3,a)') 
     &     '`ERROR around line = ',l,' in Box <VirtualAFM>!'
      write(9,'(a,i3,a)') 
     &     '`ERROR around line = ',l,' in Box <VirtualAFM>!'
      iErr=1
      return
      end

      subroutine read_force_field(NFIL,iErr)
c.....................................................................
c      Read all the force field from the file UNIT=NFIL
c......................................................................
c IMPORTANT: all units in this box are in eV,A !!!!
c......................................................................
      include 'virtual.inc'
      include 'forces.inc'
      include 'share.inc'
      character Line*120
      integer LPos(30),LEnd(30)
      logical iiErr,lattice,field_file
c
c......................................................................
c............. set default values first ...............................
c......................................................................
c
c.............. force field file (short-range part)
      j1_ftip = 1
      j2_ftip = 1
      nz = 44
      FileName='           '
      leng=0
      field_file=.false.
c
c.............. vdW part (in eV,A units)
      HAMAK=1.6d-19*J_eV
      RADIUS=30.d-09*m_A
c
c.............. long-range part of the force (in eV,A units)
      bound=16.d-10
      z0=-5.0928d-10*m_A
      g0=0.0d0
      g1=0.0d0
      g2=0.0d0
      g3=-6.5555d-40*m_A**2
      g4=0.0d0
      g5=0.0d0
      g6=0.0d0
c
c.............. lattice vectors AI(1) and AI(2)
      lattice=.false.
c
c................ test for the force field (in eV,A units)
      do_force_test=.false.
      test_step=0.01
c
c................ how to communicate with Sci-Fi
      interpolate = .true.
      interpl_num_points = 4
      extrapolate = .true.
      extrpl_polyn_order = 2
      extrpl_num_points  = 3
      smooth      = .true.
      num_smooth  =   3

c................ connection with the atomic tip
      i_atom_sphere = 1
      dist_to_sphere = 0.0d0
c
c...... Seeks for the box marker: [.<Force_Field>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Force_Field>',14,NFIL,iEr)
      if(iEr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      iw=0
      l=0
c_______________ read every line here one by one in a loop

 20   call CutStr(Line,NumLin,LPos,LEnd,NFIL,iEr)
      l=l+1
      if(iEr.ne.0) go to 50

c_______________ finish reading the box here by finding the end marker

      if(index(line,'.<End>').ne.0) go to 30

c_______________ interpret the read line and set parameters

      if(index(line(LPos(1):LEnd(1)),'Force_field_file').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LPos(2):LEnd(2)),'(a)',END=50,ERR=50) FileName
         call right(FileName,50,leng)
         iw=iw+1
         write(9,'(a,i2,2a)') '...> found (',iw,
     &               ') new values for: FileName = ',FileName(leng:)
         field_file=.true.

      else 
     & if(index(line(LPos(1):LEnd(1)),'Atom_Sphere{#,dist}').ne.0) then
         if(NumLin.lt.3) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) i_atom_sphere,
     ,                                                   dist_to_sphere
         iw=iw+1
         write(9,'(a,i2,a,i5,a,e12.6,a)')
     &          '...> found (',iw,') new value for i_atom_sphere = ',
     ,      i_atom_sphere,' and dist_to_sphere = ',dist_to_sphere,' A'

      else if(index(line(LPos(1):LEnd(1)),'Force_Test').ne.0) then
         if(NumLin.lt.3) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'T') do_force_test=.true.
         read(Line(LPos(3):),*,END=50,ERR=50) test_step
         iw=iw+1
         write(9,'(a,i2,a,l,a,e12.6,a)')
     &          '...> found (',iw,') new value for do_force_test = ',
     ,          do_force_test,
     &          ' and test_step = ',test_step,'A'

      else if(index(line(LPos(1):LEnd(1)),
     &                            'interpolate{F/T,points}').ne.0) then
         if(NumLin.lt.2) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'F') interpolate=.false.
         if(interpolate) then
            if(NumLin.lt.3) go to 50
            read(Line(LPos(3):),*,err=50,end=50) interpl_num_points
         end if
         iw=iw+1
         write(9,'(a,i2,a,l,a,i2)')
     &          '...> found (',iw,') new value for interpolate = ',
     ,   interpolate,' with interpl_num_points =',interpl_num_points

      else if(index(line(LPos(1):LEnd(1)),
     &                      'extrapolate{F/T,polyn,points}').ne.0) then
         if(NumLin.lt.2) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'F') extrapolate=.false.
         if(extrapolate) then
            if(NumLin.lt.4) go to 50
            read(Line(LPos(3):),*,err=50,end=50) 
     &                              extrpl_polyn_order,extrpl_num_points
         end if
         iw=iw+1
         write(9,'(a,i2,a,l,a/a,i2/a,i2)')
     &          '...> found (',iw,') new value for extrapolate = ',
     ,  extrapolate,' with ','extrpl_polyn_order = ',extrpl_polyn_order,
     &      'extrpl_num_points = ',extrpl_num_points

      else if(index(line(LPos(1):LEnd(1)),'smooth').ne.0) then
         if(NumLin.lt.3) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'F') smooth=.false.
         if(smooth) 
     &        read(Line(LPos(3):LEnd(3)),*,err=50,end=50) num_smooth
         if(num_smooth/2*2.eq.num_smooth) num_smooth=num_smooth+1
         iw=iw+1
         write(9,'(a,i2,a,l,a,i5)')
     &          '...> found (',iw,') new value for smooth = ',smooth,
     &          ' with num_smooth = ',num_smooth

      else if(index(line(LPos(1):LEnd(1)),'Pixels{1,2,z}').ne.0) then
         if(NumLin.lt.4) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) j1_ftip,j2_ftip,nz
         iiErr=.false.
         if(nz.gt.nz_max) then
            write(*,*)'ERROR! Too many pixels for the Z-force!'
            iiErr=.true.
         end if
         if(j1_ftip.gt.j1_ftip_max) then
            write(*,*)'ERROR! Too many pixels for the AI(1)-force!'
            iiErr=.true.
         end if
         if(j2_ftip.gt.j2_ftip_max) then
            write(*,*)'ERROR! Too many pixels for the AI(2)-force!'
            iiErr=.true.
         end if
         if(iiErr) go to 50
         iw=iw+1
         write(9,'(a,i2,a/3(a,i5))') 
     &        '...> found (',iw,') new values for the force field:',
     &        ' j1_ftip= ',j1_ftip,', j2_ftip= ',j2_ftip,', nz = ',nz

      else if(index(line(LPos(1):LEnd(1)),'vdW{H,R}').ne.0) then
         if(NumLin.lt.3) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) HAMAK,RADIUS
         iw=iw+1
         write(9,'(a,i2,a/2(a,e12.6),a)') 
     &        '...> found (',iw,') new values for the vdW force:',
     &   ' H = ',HAMAK,' eV and  R = ',RADIUS,' A' 

      else if(index(line(LPos(1):LEnd(1)),
     &                    'Long-Range{bound,z0,g0,...,g6}').ne.0) then
         if(NumLin.lt.9) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) 
     &                              bound,z0,g0,g1,g2,g3,g4,g5,g6
         if(bound.lt.0.0) go to 50
         iw=iw+1
         write(9,'(a,i2,a/2(a,e12.6,x)/7(a,e12.6,x))') 
     &   '...> found (',iw,
     &     ') new values for the long-range force field (in eV,A):',
     &     'bound= ',bound,' z0= ',z0,' g0= ',g0,'g1= ',g1,
     &        'g2= ',g2, 'g3= ',g3,'g4= ',g4,'g5= ',g5,'g6= ',g6

      else if(index(line(LPos(1):LEnd(1)),
     &                    'Lattice{/A1(xy),/A2(xy)}').ne.0) then
         read(NFIL,*,END=50,ERR=50) (AI(1,j),j=1,2)
         read(NFIL,*,END=50,ERR=50) (AI(2,j),j=1,2)
         iw=iw+1
         write(9,'(a,i2,a/2(a,e12.6,x),a/2(a,e12.6,x),a)') 
     &   '...> found (',iw,') new values for lattice vectors (in A):',
     &     'AI(1) = {',AI(1,1),',',AI(1,2),'}',
     &     'AI(2) = {',AI(2,1),',',AI(2,2),'}'
         lattice=.true.
      end if
      go to 20

c................  Print all

c................ change units to the SI system
 30   test_step=test_step*A_m
      HAMAK=HAMAK*eV_J
      RADIUS=RADIUS*A_m
      bound=bound*A_m
      z0=z0*A_m
      g0=g0*eVpA_N
      g1=g1*eV_J
      g2=g2*eV_J*A_m
      g3=g3*eV_J*A_m**2
      g4=g4*eV_J*A_m**3
      g5=g5*eV_J*A_m**4
      g6=g6*eV_J*A_m**5

c_____________ force test
      if(do_force_test) then
         write(9,'(a,f10.5,a)') 
     &        'TEST for the force IS performed with step = ',
     &        test_step*m_A,' A'
      else
         write(9,'(a,f10.5,a)') 'TEST for the force is NOT performed'
      end if

c_____________ summary for the long-range part of the force field
      write(9,'(/a/)')'>>>>>>>>>>>>>>>> Force field <<<<<<<<<<<<<<<<<<<'
      write(9,'(a,2(5x,a,e12.6))') 'van der Waals part is: ',
     &     ' Hamaker= ',HAMAK,',  Radius= ',RADIUS
      write(9,'(a,(5x,a,e12.6))')
     &     'Long-range part is:',
     &     'bound= ',bound,' z0= ',z0,'g0= ',g0,'g1= ',g1,'g2= ',g2,
     &     'g3= ',g3,'g4= ',g4,'g5= ',g5,'g6= ',g6

c.................. read the force field file (short-range)

      IF(field_file) THEN
         open(7,file=FileName(leng:),status='old',form='formatted',
     ,                                                     err=70)
         read(7,*)
         do iz=1,nz
            read (7,*,err=70,end=70) ccc
            cz(iz)=ccc/m_A
         end do
         read(7,*)
         do j1=0,j1_ftip
            do j2=0,j2_ftip
               read(7,*)
               do iz=1,nz
                  read (7,*,err=70,end=70) fuerza
                  all_force(iz,j1,j2)=fuerza/N_evpA
               end do
            end do
         end do
         close (7)

c____________ check if the force field is the same across a lattice vector
         do j1=0,j1_ftip
            s=0.0d0
            do iz=1,nz
               s=s+abs(all_force(iz,j1,0)-all_force(iz,j1,j2_ftip))
            end do
            if(s.gt.0.0d0) then
               write(9,*)'FATAL! Force field wrong at j1= ',j1
               go to 70
            end if
         end do
         do j2=0,j2_ftip
            s=0.0d0
            do iz=1,nz
               s=s+abs(all_force(iz,0,j2)-all_force(iz,j1_ftip,j2))
            end do
            if(s.gt.0.0d0) then
               write(9,*)'FATAL! Force field wrong at j2= ',j2
               go to 70
            end if
         end do

c______________ check the lattice
         if(lattice) then
            do i=1,2
               do j=1,2
                  AI(i,j)=AI(i,j)*A_m
               end do
            end do
            call INVER2(AI,BI,iiErr)
            if(iiErr) then
               write(9,'(a)')
     &              'FATAL! Bad lattice vectors in Box <Force_Field>'
               iErr=1
               return
            end if
         else
            write(9,'(a)')'ERROR: lattice is not specified!'
            iErr=1
            return
         end if

c_____________ summary for the force field

         write(9,'(a)')'... Using EXISTING force field:'
         write(9,'(2a)') 'Force field file          = ',FileName(leng:)
         write(9,'(a,3(i5,x))') 
     &        'pixels of the force (1,2,z) = ',j1_ftip,j2_ftip,nz
         write(9,'(a/2(a,e12.6,x),a/2(a,e12.6,x),a)') 
     &        'Lattice vectors (in A):',
     &        'AI(1) = {',AI(1,1)*m_A,',',AI(1,2)*m_A,'}',
     &        'AI(2) = {',AI(2,1)*m_A,',',AI(2,2)*m_A,'}'
         write(9,'(a/2(a,e12.6,x),a/2(a,e12.6,x),a)') 
     &        'Reciprocal lattice vectors (in 1/A):',
     &        'BI(1) = {',BI(1,1)/m_A,',',BI(1,2)/m_A,'}',
     &        'BI(2) = {',BI(2,1)/m_A,',',BI(2,2)/m_A,'}'
         scifi_and_vafm=.false.
      ELSE
         write(9,'(a)')
     &        '... Calculating force field on the fly from SCI-FI:'
         write(9,'(a,f10.5,a)')
     &        'Distance to the vdW sphere = ',dist_to_sphere,' A'
         write(9,'(a,i5,a)')'[ as measured from a frozen tip atom ',
     &        i_atom_sphere,' ]'
         scifi_and_vafm=.true.
         if(interpolate) then
            write(9,'(a)') 
     &           'Interpolation is ON: will be attempted if possible'
            write(9,'(a,i2,a)') 'using ',interpl_num_points,' points'
            j_force_stored=0
            if(extrapolate) then
               write(9,'(a)') '... Extrapolation is ON using:'
               write(9,'(5x,i2,a/5x,i2,a)')  extrpl_polyn_order,
     &                 ' order polynomial and using',
     &                                extrpl_num_points, ' points'
            else
               write(9,'(a)') '... Extrapolation is OFF'
            end if
            if(smooth) then
               write(9,'(a,i2,a)') 
     &   '... Smoothing of the force is ON using ',num_smooth,' points'
            else
               write(9,'(a)') '... Smoothing of the force is OFF'
            end if
         else
            write(9,'(a)') 
     &         'Interpolation is OFF: direct calculation at each point:'
            write(9,'(a)')'be WARNED: this is going to be VERY SLOW!'
            extrapolate=.false.
            smooth=.false.
         end if
      END IF
      write(9,'(a)')
     &       '...........<Force_Field> box is read correctly ..........'
      return
c
c.......... error messages
c
 70   write(9,*) 'FATAL! Error in the force field file'
      write(*,*) 'FATAL! Error in the force field file'
      iErr=1
 40   write(9,*) 'FATAL! Box <Force_Field> not found! '
      write(*,*) 'FATAL! Box <Force_Field> not found! Ignored'
      iErr=1
      return
 50   write(*,*) '`ERROR around line = ',l,' in Box <Force_Field>'
      write(9,*) '`ERROR around line = ',l,' in Box <Force_Field>!'
      iErr=1
      return
      end

      subroutine read_elementary_stages(NFIL,iErr)
c.....................................................................
c      Read all the stages/steps from the file UNIT=NFIL
c.....................................................................
      include 'virtual.inc'
      include 'forces.inc'
      include 'noise.inc'
      include 'stages.inc'
      character Line*120,cha5*5,cha10*10,chb10*10,chc10*10
      integer LPos(30),LEnd(30)
      logical iiErr
c
c......................................................................
c............. set default values first ...............................
c......................................................................
c
c............... Setpoints      

c____ for the 1st stabilisation stage: all the parameters are fixed here!
c
      if_NoiseF(1) = .false.
      if_NoiseA(1) = .false.
      if_ADC(1)    = .false.
      if_AGC(1)    = .true.
      A0_(1)       =  A0
      if_tipf(1)   = .false.
      Finish_St(1) = ' time'
      Stage_Time(1)= Stab_Time1 
      VelocityX(1) = 0.0d0
      VelocityY(1) = 0.0d0
      if_Excite(1) = .false.
      if_Prt(1)    = DEBUG
      HowOften(1)  = when_debug
      scan_no(1)   = 0 
      scan_mark(1) = '     '
c
c____ for the 2nd stabilisation stage: all the parameters are fixed here! 
c
      if_NoiseF(2) = .false.
      if_NoiseA(2) = .false.
      if_ADC(2)    = .false.
      if_AGC(2)    = .true.
      A0_(2)       =  A0
      if_tipf(2)   = .false.
      Finish_St(2) = ' time'
      Stage_Time(2)= Stab_Time2 
      VelocityX(2) = 0.0d0
      VelocityY(2) = 0.0d0
      if_Excite(2) = .true.
      if_Prt(2)    = DEBUG
      HowOften(2)  = when_debug
      scan_no(2)   = 0
      scan_mark(2) = '     '
c
c____ for the 3rd stage: approach to the setpoint DFC 
c
c      if_NoiseF(3) = .false.
c      if_NoiseA(3) = .false.
c      if_ADC(3)    = .true.
c      DFC_(3)      = DFC
c      if_AGC(3)    = .true.
c      A0_(3)       = A0
c      if_tipf(3)   = .true.
c      Finish_St(3) = 'freqs'
c      VelocityX(3) = 0.0d0
c      VelocityY(3) = 0.0d0
c      if_Excite(3) = .true.
c      if_Prt(3)    = DEBUG
c      HowOften(3)  = when_debug

c____ for the 2D scans
      scan           = .false.
      N_of_passages  = 4
      N_of_sequences = 10
      iscan=0
 
c...... Seeks for the box marker: [.<Elementary_Stages>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Elementary_Stages>',20,NFIL,iEr)
      if(iEr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      l=0
      istage=2
c_______________ read every line here one by one in a loop

 20   call CutStr(Line,NumLin,LPos,LEnd,NFIL,iEr)
      l=l+1
      if(iEr.ne.0) go to 50

c_______________ finish reading the box here by finding the end marker

      if(index(line,'.<End>').ne.0) go to 30

c_______________ interpret the line read in and set the parameters

      if(index(line(LPos(1):LEnd(1)),'==={begin_scan}===').ne.0) then
         iscan=iscan+1
         if(iscan.gt.N_of_scans_max) then
            write(9,'(a,i5)')'ERROR! # of scans is > ',N_of_scans_max
            go to 50
         end if
         scan=.true.
         iscan1=istage+1
         write(9,'(a,i5)')
     &        'SCAN keyword found; starts from stage ',iscan1

      else if(index(line(LPos(1):LEnd(1)),'No_of_sequences').ne.0) then
         if(.not.scan .or. NumLin.lt.2) go to 50
         read(line(LPos(2):),*,err=50,end=50) N_of_sequences 
         if(scan .and. istage.ge.iscan1) then
            write(9,'(a)')
     &       'ERROR: # of sequences must be at the beg. of the scan box'
            go to 50
         end if
         write(9,'(a,i2,a)')
     &        'There are ',N_of_sequences,' sequences in the SCAN' 

      else if(index(line(LPos(1):LEnd(1)),'==={end_scan}===').ne.0) then
         if(.not.scan) go to 50
         iscan2=istage
         N_of_passages=iscan2-iscan1+1
         iTot=iscan1-1 + N_of_sequences*N_of_passages
         if(iTot.gt.N_of_stages_max) then
            write(9,'(a,i5)')'FATAL! # of stages in the SCAN is > ',
     ,           N_of_stages_max
            go to 50
         end if
         write(9,'(2(a,i5),a)')'SCAN consists of ',
     &   N_of_sequences,' sequences, ',N_of_passages,' passages in each'
         write(9,'(2(a,i5))')
     &     'SCAN: elementary stages in the passage from ',iscan1,
     ,                                                     ' to ',iscan2
         write(9,'(2(a,i5))')
     &    'SCAN: all elementary stages from ',iscan1,' to ',iTot
         if(N_of_sequences.gt.1) call set_scan(istage,iscan1,iscan2)
         do is=iscan1,iTot
            scan_no(is)=iscan
            scan_mark(is) = 'ordin'
         end do
         scan_mark(iscan1) = 'start'
         scan_mark(iTot)   = ' end '
         scan=.false.

      else if(index(line(LPos(1):LEnd(1)),'_{begin_stage}_').ne.0) then
         istage=istage+1
         if(istage.gt.N_of_stages_max) then
            write(9,'(a,i5)')'FATAL! Too many stages > ',N_of_stages_max
            go to 50
         end if
         if(.not.scan) then
            scan_no(istage)=0
            scan_mark(istage)='     '
         end if
         write(9,'(a,i5,a)')
     &        '...............> stage = ',istage,' <.................'
         if_NoiseF(istage) = NoiseF
         if_NoiseA(istage) = NoiseA
         if_ADC(istage)    = .true.
         DFC_(istage)      =  DFC
         if_AGC(istage)    = .true.
         A0_(istage)       =  A0
         if_tipf(istage)   = .true.
         Finish_St(istage) = ' time'
         Stage_Time(istage)= 0.0d0
         VelocityX(istage) = 0.0d0
         VelocityY(istage) = 0.0d0
         if_Excite(istage) = .true.
         if_Prt(istage)    = DEBUG
         HowOften(istage)  = when_debug

      else if(index(line(LPos(1):LEnd(1)),'Finish{how,time}').ne.0) then
         if(NumLin.lt.2) go to 50
         if(index(line(LPos(2):LEnd(2)),'time').ne.0) then
            Finish_St(istage) = ' time'
            if(NumLin.lt.3) go to 50
            read(Line(LPos(3):),*,END=50,ERR=50) Stage_Time(istage)
         else if(index(line(LPos(2):LEnd(2)),'freq').ne.0) then
            Finish_St(istage) = 'freqs'
         else if(index(line(LPos(2):LEnd(2)),'ampl').ne.0) then
            Finish_St(istage) = 'amplt'
         else
            go to 50
         end if

      else if(index(line(LPos(1):LEnd(1)),'Excite{T/F}').ne.0) then
         if(NumLin.lt.2) go to 50
         if_Excite(istage)=.false.
         if(Line(LPos(2):LEnd(2)).eq.'T') if_Excite(istage)=.true.

      else if(index(line(LPos(1):LEnd(1)),'AGC{T/F,A0}').ne.0) then
         if(NumLin.lt.2) go to 50
         if_AGC(istage)=.false.
         if(Line(LPos(2):LEnd(2)).eq.'T') then
            if_AGC(istage)=.true.
            if(NumLin.lt.3) go to 50
            read(Line(LPos(3):),*,END=50,ERR=50) A0_(istage)
         end if

      else if(index(line(LPos(1):LEnd(1)),'ADC{T/F,freq}').ne.0) then
         if(NumLin.lt.2) go to 50
         if_ADC(istage)=.false.
         if(Line(LPos(2):LEnd(2)).eq.'T') then
            if_ADC(istage)=.true.
            if(NumLin.lt.3) go to 50
            read(Line(LPos(3):),*,END=50,ERR=50) DFC_(istage)
         end if

      else if(index(line(LPos(1):LEnd(1)),'Noise{F,A}').ne.0) then
         if(NumLin.lt.3) go to 50
         if(Line(LPos(2):LEnd(2)).eq.'T') if_NoiseF(istage)=.true.
         if(Line(LPos(3):LEnd(3)).eq.'T') if_NoiseA(istage)=.true.

      else 
     & if(index(line(LPos(1):LEnd(1)),'Prt{T/F,how_often}').ne.0) then
         if(NumLin.lt.2) go to 50
         if_Prt(istage)=.false.
         if(Line(LPos(2):LEnd(2)).eq.'T') then
            if_Prt(istage)=.true.
            if(NumLin.lt.3) go to 50
            read(Line(LPos(3):),*,END=50,ERR=50) HowOften(istage)
         end if

      else if(index(line(LPos(1):LEnd(1)),'Velocity{Vx,Vy}').ne.0) then
         if(NumLin.lt.3) go to 50
         read(Line(LPos(2):),*,END=50,ERR=50) 
     ,                         VelocityX(istage),VelocityY(istage)

      else if(index(line(LPos(1):LEnd(1)),'Tip_Force{T/F}').ne.0) then
         if(NumLin.lt.2) go to 50
         if_tipf(istage)=.false.
         if(Line(LPos(2):LEnd(2)).eq.'T') if_tipf(istage)=.true.

      end if
      go to 20

c................  Print all

 30   write(9,'(a)')
     & '...........<Elementary_Stages> box is read correctly ..........'
      N_of_Stages=istage
c
c.................... summary for the Elementary_Stages
c
      write(9,'(/a/)')
     &     '>>>>>>>>>>>>>>>> Elementary_Stages <<<<<<<<<<<<<<<<<<<'
      write(9,'(a)')'  #  ADC  DFC(Hz)  AGC  A0(A)   noise(F,A) tipf'
     &//'   Exc        Vx         Vy    Finish     time  Prt  every'
     &//'  scan   type  ' 
      do is=1,N_of_Stages

         if(if_ADC(is)) then
            write(cha10,'(f10.5)') DFC_(is)
         else
            cha10='   N/A   '
         end if
         if(if_AGC(is)) then
            write(chb10,'(f10.5)') A0_(is)*m_A
         else
            chb10='   N/A   '
         end if
         if(Finish_St(is).eq.' time') then
            write(chc10,'(f10.5)') Stage_Time(is)
         else
            chc10='     N/A '
         end if
         if(if_AGC(is)) then
            write(cha5,'(i5)') HowOften(is)
         else
            cha5='  N/A'
         end if
         if(if_Prt(is) .and. is .gt.99) then
            write(*,*)
     &        'WARNING: debugging of stage > 99 is not yet supported!'
            write(9,*)
     &        'WARNING: debugging of stage > 99 is not yet supported!'
            if_Prt(is)=.false.
         end if
         write(9,'(i3,2x,2(l,x,a),x,4(l,4x),2(e10.4,x),2(a,x),l,x,a,
     ,        5x,i2,4x,a)') 
     &        is,if_ADC(is),cha10,if_AGC(is),chb10,
     &        if_NoiseF(is), if_NoiseA(is),if_tipf(is),if_Excite(is),
     &        VelocityX(is),VelocityY(is),
     &        Finish_St(is),chc10,if_Prt(is),cha5,
     &        scan_no(is),scan_mark(is) 
      end do
      return
c
c.......... error messages
c
 40   write(9,*) 'FATAL! Box <Elementary_Stages> not found! '
      write(*,*) 'FATAL! Box <Elementary_Stages> not found! Ignored'
      iErr=1
      return
 50   write(*,*) 'ERROR around line = ',l,' in Box <Elementary_Stages>'
      write(9,*) 'ERROR around line = ',l,' in Box <Elementary_Stages>'
      write(9,'(a)') line
      iErr=1
      return
      end

      subroutine set_scan(istage,iscan1,iscan2)
c..................................................................
c     The whole scan sequence is constructed from one passage by
c repeating it N_of_sequence times.
c The passage consists of stages from iscan1 to iscan2.
c..................................................................
      include 'real8.inc'
      include 'virtual_param.inc'
      include 'stages.inc'
      integer ref_stage

      istage=iscan2
      do i=2,N_of_sequences
         do j=1,N_of_passages
            istage=istage+1

c___________ find the corresponding stage in the 1st passage
            ref_stage=iscan1+j-1

c___________ set the parameters for the current stage
            if_NoiseF(istage) = if_NoiseF(ref_stage)  
            if_NoiseA(istage) = if_NoiseA(ref_stage) 
            if_ADC(istage)    = if_ADC(ref_stage)    
            DFC_(istage)      = DFC_(ref_stage)      
            if_AGC(istage)    = if_AGC(ref_stage)    
            A0_(istage)       = A0_(ref_stage)       
            if_tipf(istage)   = if_tipf(ref_stage)   
            Finish_St(istage) = Finish_St(ref_stage) 
            Stage_Time(istage)= Stage_Time(ref_stage)
            VelocityX(istage) = VelocityX(ref_stage) 
            VelocityY(istage) = VelocityY(ref_stage) 
            if_Excite(istage) = if_Excite(ref_stage) 
            if_Prt(istage)    = if_Prt(ref_stage)    
            HowOften(istage)  = HowOften(ref_stage)  

         end do
      end do
      return
      end

         
