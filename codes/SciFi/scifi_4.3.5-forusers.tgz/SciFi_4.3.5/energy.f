      double precision function energy(R,iPrnt)
c....................................................................
c    calculates energy at the point r
c....................................................................
c r() - 1-dim vectror of all coordinates
c x(),y(),z() - working arrays for coordinates
c....................................................................
      include 'shell.inc'
      dimension R(N0FR)
      double precision  image_get_energy
      double precision  mbenergy
      logical fatal,catch_fatal
c
c........... convert to x,y,z
c
      if(nid.eq.0.and.iPrnt.ge.8) 
     &     write(9,*)'========> ... entering ENERGY ...'
      call conv_1_3(R,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,                  n_pos_cor,iRx,iRy,iRz)
c
c........... do TERSOFF energy if necessary (do_tersoff=.true.)
c
      if(do_tersoff) then
         energyT=tersoff_energy()
      else
         energyT=0.0d0
      end if
c
c........................................................................
c........... calculate PAIRWISE energy: double loop over all atomic pairs
c........................................................................
c
      short=0.0d0
      sprn=0.0d0
      coul=0.0d0
      do i=1,Natom
         is=ISRT(i)

c.............. add springs

         if(Shell_Ref(is)) then
            j=iShell(i)
            d_cs=dist(x(i),y(i),z(i),x(j),y(j),z(j))
            spr=0.5*Spring(is)*d_cs*d_cs
            sprn=sprn+spr
            if(nid.eq.0.and.iPrnt.ge.10) then
               write(9,'(2(a,i3))')' spring of i=',i,' with j=',j
               write(9,'(3(x,f10.5))') d_cs,spr,sprn
            end if
         end if

c.............. add Coulomb and short-range with others

         do 100 ii=1,i

c-----------check if the pair is excluded by a multibody interaction
            if(excl_atom(i,ii)) go to 100

            iis=ISRT(ii)
            if(i.eq.ii) go to 100

            if(nid.eq.0.and.iPrnt.ge.10) 
     &           write(9,'(a,2i5)')' pair i,ii= ',i,ii

c_______________ if both i,ii have shells
            if(Shell_Ref(is) .and. Shell_Ref(iis) ) then
               j=iShell(i)
               jj=iShell(ii)
               d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
               d_cs=dist(x(i),y(i),z(i),x(jj),y(jj),z(jj))
               d_sc=dist(x(j),y(j),z(j),x(ii),y(ii),z(ii))
               d_ss=dist(x(j),y(j),z(j),x(jj),y(jj),z(jj))
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
               coul_cs=CoreQA(is)*ShellQA(iis)/d_cs
               coul_sc=ShellQA(is)*CoreQA(iis)/d_sc
               coul_ss=ShellQA(is)*ShellQA(iis)/d_ss
               coul=coul+coul_cc+coul_cs+coul_sc+coul_ss
               short=short + Pot(is,iis,d_ss)
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a,2i5)') 'both shells j,jj= ',j,jj
                  write(9,'(4(x,f10.5))') d_cc,d_cs,d_sc,d_ss
                  write(9,'(6(x,f10.5))') 
     &                 coul_cc,coul_cs,coul_sc,coul_ss,short,coul
               end if

c_______________ if only i has a shell
            else if(Shell_Ref(is)) then 
               j=iShell(i)
               d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
               d_sc=dist(x(j),y(j),z(j),x(ii),y(ii),z(ii))
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
               coul_sc=ShellQA(is)*CoreQA(iis)/d_sc
               short= short + Pot(is,iis,d_sc)
               coul=coul+coul_cc+coul_sc
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a,i5)') 'i has shell j= ',j
                  write(9,'(4(x,f10.5))') d_cc,d_sc
                  write(9,'(4(x,f10.5))') coul_cc,coul_sc,short,coul
               end if

c_______________ if only ii has a shell
            else if(Shell_Ref(iis)) then  
               jj=iShell(ii)
               d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
               d_cs=dist(x(i),y(i),z(i),x(jj),y(jj),z(jj))
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
               coul_cs=CoreQA(is)*ShellQA(iis)/d_cs
               short=short + Pot(is,iis,d_cs)
               coul=coul+coul_cc+coul_cs
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a,i5)') 'ii has shell jj= ',jj
                  write(9,'(4(x,f10.5))') d_cc,d_cs
                  write(9,'(4(x,f10.5))') coul_cc,coul_cs,short,coul
               end if

c_______________ if both do not have shells
            else
               d_cc=dist(x(i),y(i),z(i),x(ii),y(ii),z(ii))
               coul_cc=CoreQA(is)*CoreQA(iis)/d_cc
               short=short + Pot(is,iis,d_cc)
               coul=coul+coul_cc
               if(nid.eq.0.and.iPrnt.ge.10) then
                  write(9,'(5x,a)') 'both i,ii do not have shells'
                  write(9,'(2i3,4(x,f10.5))') i,ii,d_cc
c                  write(9,'(4(x,f10.5))') d_cc
                  write(9,'(4(x,f10.5))') coul_cc,short,coul
               end if
            end if

 100     continue
      end do

c................. Many-body energy

      if(do_mbody) then
         mbenergy = diag_energy(iPrnt)
      else
         mbenergy = 0.0d0
      end if
c................. Contribution from IMAGE

      if(Do_Image) then
         call image_input(.false.,.false.,.false.)
         call system('image > out')
         fatal=catch_fatal('out',3)
         if(fatal .and. nid.eq.0) then
            write(*,*)'FATAL! fatal error in IMAGE. Stop in energy.'
            stop
         end if
         en_image = image_get_energy(iPrnt)
      else
         en_image=0.0d0
      end if

c_________________ total energy
      energy=energyT+coul+short+sprn+en_image+mbenergy

      if(nid.eq.0.and.iPrnt.ge.5) then
         write(9,'(/a,e16.10)')'Tersoff energy (au)     = ',energyT
         write(9,'(/a,e16.10)')'Coulomb energy (au)     = ',coul
         write(9,'(a,e16.10)') 'Short-range energy (au) = ',short
         write(9,'(a,e16.10)') 'Spring energy (au)      = ',sprn
         write(9,'(a,e16.10)') 'Many-Body energy (au)      = ',mbenergy     
         if(Do_Image) 
     &     write(9,'(a,e16.10)') 'Image energy (au)       = ',en_image
      end if
      if(nid.eq.0) then
         write(9,'(a,e16.10/)') 'Total energy (au)       = ',energy
         if(write_en_frc) 
     &        write(31,'(a,e24.18)')'Tot energy (au)= ',energy
         if(iPrnt.ge.3) write(*,'(a,e16.10)') 'Total energy = ',energy
      end if

      return
      end

      double precision function dist(x,y,z,x1,y1,z1)
c..........................................................
c distance between two points: (x,y,z) and (x1,y1,z1)
c..........................................................
      include 'param.inc'
      dx=x-x1
      dy=y-y1
      dz=z-z1
      dist=dx*dx+dy*dy+dz*dz
      dist=sqrt(dist)
      return
      end
