      subroutine dizzy(x, y, z, rot)
c_______routine which carries out rotations 
c_______x, y, z - atom coord.
c_______rot - array with x, y, z rotation
      implicit none
      integer i
      double precision x, y, z
      double precision x1, x2, x3, pi
      double precision rot(3), sn(3), cs(3), rrot(3)
      data pi/3.141592654/

      do i=1,3
         sn(i)=0.0
         cs(i)=0.0
      end do
      
      do i=1,3
         rrot(i)=rot(i)*pi/180.0
         sn(i)=sin(rrot(i))
         cs(i)=cos(rrot(i))
      end do
            
c______rotate about x
      
      if(rot(1).ne.0.0) then
         x2=y*cs(1) + z*sn(1) 
         x3=-y*sn(1) + z*cs(1) 
         y=x2
         z=x3
      end if
      
c______rotate about y
      
      if (rot(2).ne.0.0) then
         x1=x*cs(2)-z*sn(2) 
         x3=x*sn(2)+z*cs(2) 
         x=x1
         z=x3
      end if
      
c______rotate about z
      
      if (rot(3).ne.0.0) then
         x1=x*cs(3) + y*sn(3) 
         x2=-x*sn(3) + y*cs(3) 
         x=x1
         y=x2
      end if
      end
