      subroutine decay_atoms(fidx, fidy, fidz)

c.............Calculates contribution to force on atoms due to the
c.............reduction of their charges as a function of distance in IMAGE.

      include 'shell.inc'
      double precision rsx, rsy, rsz
      double precision fsp, fpl, dfsp, dfpl
      double precision fidx(ncharge), fidy(ncharge), fidz(ncharge)
      double precision q, thi0, thind, thi
      integer i, ii, j
      external decay, ddecay

      rsx=r_sph(1)*a_au
      rsy=r_sph(2)*a_au
      rsz=(rz+rad)*a_au
      rads=rad*a_au
      zp=z_plane*a_au
      
c______decay charge on cores

c__________ open output file with the potentials on atoms from image
      open(2,file='potent.out',form='formatted',status='old',err=100)
      read(2,'(a)')

      do i=1,Natom
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            is=ISRT(i)

c_______calculate distance to sphere and plane

            rsp2=(x(i)-rsx)**2 + (y(i)-rsy)**2 +(z(i)-rsz)**2
            rsp0=sqrt(rsp2)
            rsp=rsp0-rads
            rpl=z(i)-zp
            q=CoreQA(is)

c_______get decay function values and derivatives

            fsp=decay(rsp)
            fpl=decay(rpl)
            dfsp=ddecay(rsp)
            dfpl=ddecay(rpl)

c_______read potentials on atoms from IMAGE

            read(2,*) ii, thi0, thind, thi

c_______calculate force contributions due to decay
            
            fidx(i)=-thi*q*fpl*dfsp*(x(i)-rsx)/rsp0
            fidy(i)=-thi*q*fpl*dfsp*(y(i)-rsy)/rsp0
            fidz(i)=-thi*q*(fpl*dfsp*(z(i)-rsz)/rsp0 + fsp*dfpl) 
         end if
      end do

c_______repeat for shells
                        
      do i=1,Natom
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            is=ISRT(i)
            if(Shell_Ref(is)) then
               j=iShell(i)
               rsp2=(x(j)-rsx)**2 + (y(j)-rsy)**2 +(z(j)-rsz)**2
               rsp0=sqrt(rsp2)
               rsp=rsp0-rads
               rpl=z(j)-zp
               q=ShellQA(is)
               fsp=decay(rsp)
               fpl=decay(rpl)
               dfsp=ddecay(rsp)
               dfpl=ddecay(rpl)
               read(2,*) ii, thi0, thind, thi
            
c_______calculate force contributions due to decay
            
               fidx(j)=-thi*q*fpl*dfsp*(x(j)-rsx)/rsp0
               fidy(j)=-thi*q*fpl*dfsp*(y(j)-rsy)/rsp0
               fidz(j)=-thi*q*(fpl*dfsp*(z(j)-rsz)/rsp0
     +              + fsp*dfpl) 
            end if
         end if
      end do
      return

 100  write(*,*) 'FATAL ERROR reading potent.out in decay.'
      stop
      end
      
      subroutine decay_force(zfrc_decay)

c................Calculates contribution to tip force due the fact that the atomic
c................charges in IMAGE depend on distance from sphere.

      include 'shell.inc'
      double precision zfrc_decay
      double precision rsx, rsy, rsz
      double precision fpl, dfsp
      double precision q, thi
      integer i, ii, j
      external decay, ddecay

      rsx=r_sph(1)*a_au
      rsy=r_sph(2)*a_au
      rsz=(rz+rad)*a_au
      rads=rad*a_au
      zp=z_plane*a_au
      zfrc_decay=0.0
      
c______decay charge on cores

c__________ open output file with the potentials on atoms from image
      open(2,file='potent.out',form='formatted',status='old',err=100)
      read(2,'(a)')

      do i=1,Natom
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            is=ISRT(i)
            rsp2=(x(i)-rsx)**2 + (y(i)-rsy)**2 +(z(i)-rsz)**2
            rsp0=sqrt(rsp2)
            rsp=rsp0-rads
            rpl=z(i)-zp
            q=CoreQA(is)
            fpl=decay(rpl)
            dfsp=ddecay(rsp)
            read(2,*) ii, thi0, thind, thi

c_______calculate force contributions due to decay
            
            zfrc_decay=zfrc_decay+thi*q*fpl*dfsp*(z(i)-rsz)/rsp0
         end if
      end do

c_______repeat for shells
                        
      do i=1,Natom
         if(id2(i).ne.1) then
c        if(id(i).ne.'ft') then
            is=ISRT(i)
            if(Shell_Ref(is)) then
               j=iShell(i)
               rsp2=(x(j)-rsx)**2 + (y(j)-rsy)**2 +(z(j)-rsz)**2
               rsp0=sqrt(rsp2)
               rsp=rsp0-rads
               rpl=z(j)-zp
               q=ShellQA(is)
               fpl=decay(rpl)
               dfsp=ddecay(rsp)
               read(2,*) ii, thi0, thind, thi
            
c_______calculate force contributions due to decay
            
               zfrc_decay=zfrc_decay+thi*q*fpl*dfsp*(z(j)-rsz)/rsp0
            end if
         end if
      end do
      return

 100  write(*,*) 'FATAL ERROR reading potent.out in decay_force.'
      stop
      end

c_______decay function and its derivative
      
      double precision function decay(r)
      include 'shell.inc'
      double precision r

c      if(r.ge.50.0) then
c         decay=1.0
c      else
         d1=exp(-(r-beta)/ro)
         decay=1.0 - d1/(d1+1.0)
c      end if
      
      return
      end

      double precision function ddecay(r)
      include 'shell.inc'
      double precision r
      
c      if(r.ge.50.0) then
c         ddecay=0.0
c      else
         d1=exp(-(r-beta)/ro)
         ddecay= d1/(ro*(1.0+d1)**2)
c      end if
      return
      end
