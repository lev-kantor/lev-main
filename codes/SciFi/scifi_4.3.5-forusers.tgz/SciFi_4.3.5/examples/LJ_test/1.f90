program atoms
implicit none
real a
integer i,j,k
write(*,*) 'give a'
read(*,*) a
do i=-1,1
   do j=-1,1
      do k=-1,1
         write(*,'(a,3(f10.5,x),a)') 'He ',i*a,j*a,k*a,' 1 1 1'
      end do
   end do
end do

end program atoms
