      SUBROUTINE PBC_lattice(NFIL,KodErr)
c......................................................................
c.....Read in the file UNIT=NFIL the box <Lattice>
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2
      integer LinPos(30),LinEnd(30)

      periodic_lattice=.false.
c
c...... Seeks for the box marker: [.<Lattice>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Lattice>',10,NFIL,iErr)
      if(iErr.eq.1) go to 100
c
c......... Read the box contents .......................................
c
      do i=1,3
         read(NFIL,*,err=10) (AJ(i,j),j=1,3)
         do j=1,3
            AJ(i,j)=AJ(i,j)*A_au
         end do
      end do
      periodic_lattice=.true.
      write(9,*)'>>>> Periodic boundary conditions are ON <<<<'
      write(6,*)'>>>> Periodic boundary conditions are ON <<<<'
      write(9,'(a)')
     &  '.........<Lattice> box is read correctly ........'
      write(9,'(a/)')
     &'################################################################'
      return
c.......... ERROR messages ..........................................
 10   WRITE(9,'(a/)')'FATAL! Error in lattice vectors'
 100  WRITE(6,*)'FATAL! Box <Lattice> is not found !!! '
      WRITE(9,*)'FATAL! Box <Lattice> is not found !!! '
      write(9,*)'>>>> Periodic boundary conditions are OFF <<<<'
      write(6,*)'>>>> Periodic boundary conditions are OFF <<<<'
      KodErr=1
      return
      end

      SUBROUTINE TersoffInput(NFIL,KodErr)
c....................................Input for Tersoff calculations
cc      INCLUDE 'shell.inc'
cc-------NB 'shell.inc' is now included in tersoff.inc'
      include 'tersoff.inc'
      logical modified_beta_ters(N0KD), modified_nb_ters(N0KD),
     .        modified_c_ters(N0KD),modified_d_ters(N0KD),
     .        modified_h_ters(N0KD),modified_AA(N0KD,N0KD),
     .        modified_BB(N0KD,N0KD),modified_RR(N0KD,N0KD),
     .        modified_DD(N0KD,N0KD),modified_Rmin(N0KD,N0KD),
     .        modified_Rmax(N0KD,N0KD),modified_xi(N0KD,N0KD),
     .        modified_lam1(N0KD,N0KD),modified_lam2(N0KD,N0KD),
     .        modified_lam3(N0KD,N0KD,N0KD),use_R_D(N0KD,N0KD),
     .        use_Rmin_Rmax(N0KD,N0KD),error_ters
      character Line*120,na3*3,na2*2,cha*1,na4*3,na5*3,messg2*3,messg1*8
      integer LinPos(30),LinEnd(30)      
      double precision value

C---------DEFAULT PARAMETERS

c_____ how often to unpdate the list of neighbours
      nn_list_howoften=1000
c_____ system type: non-periodic ('cluster') or periodic ('   bulk' or 'surface')   
      system_type='cluster'

c_____ Tersoff parameters

      do i=1, KINDS
         if(SpecType(i).ne.'tf') go to 100
         
         if((Species(i).eq.'Si ').or.(Species(i).eq.'Si#')) then
C...........This is Silicon from J. Tersoff, Phys. Rev. B 37, 6991 (1988).
c            AA(i,i)=3264.7
c            BB(i,i)=95.373
c            lam1(i,i)=3.2394
c            lam2(i,i)=1.3258
c            lam3(i,i,i)=1.3258
c            beta_ters(i)=0.33675
c            c_ters(i)=4.8381
c            d_ters(i)=2.0417
c            h_ters(i)=0.00
c            nb(i)=22.956
c            RR(i,i)=3.0
c            DD(i,i)=0.2
c            Rmin(i,i)=2.8
c            Rmax(i,i)=3.2
c            xi(i,i)=1.0
c            nnn_default(i)=4
C...........This is Silicon from J. Tersoff, Phys. Rev. B 38, 9902 (1988).
            AA(i,i)=1830.8
            BB(i,i)=471.18
            lam1(i,i)=2.4799
            lam2(i,i)=1.7322
            lam3(i,i,i)=1.7322
            beta_ters(i)=1.0999e-6
            c_ters(i)=1.0039e5
            d_ters(i)=16.218
            h_ters(i)=-0.59826
            nb(i)=0.78734
            RR(i,i)=2.85
            DD(i,i)=0.15
            Rmin(i,i)=2.7
            Rmax(i,i)=3.0
            xi(i,i)=1.0
      
C..........Two-element parameters according to J.Tersoff, PRB 39, 5566 (1989).
            do j=1,KINDS
               if(SpecType(j).eq.'tf') then
                  if((Species(j).eq.' C ') .or. 
     &                 (Species(j).eq.' C#')) then
                     xi(i,j)=0.9776
                     xi(j,i)=0.9776
                  else if((Species(j).eq.'Ge ')
     &                    .or.(Species(j).eq.'Ge#')) then
                     xi(i,j)=1.00061
                     xi(j,i)=1.00061
                  end if
               end if
            end do

         else if((Species(i).eq.' C ').or. (Species(i).eq.' C#')) then
C...........This is Carbon from J. Tersoff, Phys. Rev. Lett. 61, 2879 (1988).
            AA(i,i)=1393.6
            BB(i,i)=346.74
            lam1(i,i)=3.4879
            lam2(i,i)=2.2119
            lam3(i,i,i)=0.0
            beta_ters(i)=1.5724e-7
            c_ters(i)=3.8049e4
            d_ters(i)=4.3484
            h_ters(i)=-0.57058
            nb(i)=0.72751
            RR(i,i)=1.95
            DD(i,i)=0.15
            Rmin(i,i)=1.8
            Rmax(i,i)=2.1
            xi(i,i)=1.0
            nnn_default(i)=4
      
         else if((Species(i).eq.'Ge ').or.(Species(i).eq.'Ge#')) then
C...........This is Germanium from J. Tersoff, Phys. Rev. B 39, 5566 (1989).
            AA(i,i)=1769
            BB(i,i)=419.23
            lam1(i,i)=2.4451
            lam2(i,i)=1.7047
            lam3(i,i,i)=0.0
            beta_ters(i)=9.066e-7
            c_ters(i)=1.0643e5
            d_ters(i)=15.652
            h_ters(i)=-0.43884
            nb(i)=0.75627
            RR(i,i)=2.95
            DD(i,i)=0.15
            Rmin(i,i)=2.8
            Rmax(i,i)=3.1
            xi(i,i)=1.0
            nnn_default(i)=4
            
            do j=1,KINDS
               if(SpecType(j).eq.'tf') then
                  if((Species(j).eq.' C ') .or. 
     &                 (Species(j).eq.' C#')) then
                     xi(i,j)=1.0
                     xi(j,i)=1.0
                  end if
               end if
            end do
      
         else 
            WRITE(9,'(a/)')'ERROR: No Tersoff data for element ',
     .                     Species(i)
            WRITE(*,*)     'ERROR: No Tersoff data for element ',
     ,                     Species(i)
            goto 129
         endif                  !KINDS
         
C-------------Three-element parameter lambda3 equals zero in most cases
         do j=1,KINDS
            if(SpecType(j).eq.'tf') then
               if(j.ne.i) then
                  AA(i,j)=(AA(i,i)*AA(j,j))**0.5
                  AA(j,i)=AA(i,j)
                  BB(i,j)=(BB(i,i)*BB(j,j))**0.5
                  BB(j,i)=BB(i,j)
                  RR(i,j)=(RR(i,i)*RR(j,j))**0.5
                  RR(j,i)=RR(i,j)
                  DD(i,j)=(DD(i,i)*DD(j,j))**0.5
                  DD(j,i)=DD(i,j)
                  Rmax(i,j)=(Rmax(i,i)*Rmax(j,j))**0.5
                  Rmax(j,i)=Rmax(i,j)
                  Rmin(i,j)=(Rmin(i,i)*Rmin(j,j))**0.5
                  Rmin(j,i)=Rmin(i,j)
                  lam1(i,j)=(lam1(i,i)+lam1(j,j))*0.5
                  lam1(j,i)=lam1(i,j)
                  lam2(i,j)=(lam2(i,i)+lam2(j,j))*0.5
                  lam2(j,i)=lam2(i,j)
               end if
               do k=1,KINDS
                  if(SpecType(k).eq.'tf') then
                     if(.not.((i.eq.j).and.(i.eq.k))) lam3(i,j,k)=0.0
                  end if
               end do
            end if
         end do
         
 100  end do                    !KINDS
           
C-----------end of default parameters    
      
C........logical variables which define if a parameter value was 
c        set manually or the default value was used
      do i=1,KINDS
         if(SpecType(i).eq.'tf') then
            modified_beta_ters(i)=.false.
            modified_nb_ters(i)=.false.
            modified_c_ters(i)=.false.
            modified_d_ters(i)=.false.
            modified_h_ters(i)=.false.

            do j=1, KINDS
               if(SpecType(j).eq.'tf') then
                  modified_AA(i,j)=.false.
                  modified_BB(i,j)=.false.
                  modified_RR(i,j)=.false.
                  modified_DD(i,j)=.false.
                  modified_Rmin(i,j)=.false.
                  modified_Rmax(i,j)=.false.
                  modified_lam1(i,j)=.false.
                  modified_lam2(i,j)=.false.
                  modified_xi(i,j)=.false.
                  use_R_D(i,j) = .true.
c     use_Rmin_Rmax(i,j)=.false.
                  do k=1,KINDS
                     if(SpecType(k).eq.'tf') 
     &                      modified_lam3(i,j,k)=.false.
                  end do
               end if
            end do

         end if
      end do
      
C--------------------------------------------
      
      error_ters=.false.
c
c......If we want to input any of the Tersoff interaction parameters manually:
c
      rewind(NFIL)
      call find_string('.<Tersoff>',10,NFIL,iErr)
      if(iErr.eq.1) then
         write(9,'(a/)')'WARNING! <Tersoff> box is NOT found !!! '
         write(9,'(a/)')'FATAL! NO Tersoff> ! '
         do_tersoff=.false.
         KodErr=1
         write(9,'(a/)')
     &'################################################################'
         return              
      else
         write(9,'(a/)')'WARNING! <Tersoff> box IS found! OK! '
      end if
 
 1200 call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(line(LinPos(1):LinEnd(1)).eq.'.<End>') go to 130
      write(9,'(a,i2,a,e12.6)')
     &       'Manual input of the following Tersoff parameters: '

c.............. some special parameters
      if(NumLin.eq.2) then

         if(index(line(LinPos(1):LinEnd(1)),
     ,        'how_often_nn_update').Ne.0) then
            read(Line(LinPos(2):),*,ERR=129) nn_list_howoften
            Write(9,'(a,i10)')
     ,           '...> found new value for nn_list_howoften=',
     ,           nn_list_howoften
         else if(index(line(LinPos(1):LinEnd(1)),'system').Ne.0) then
            if(index(Line(LinPos(2):LinEnd(2)),'bulk').ne.0) then
               system_type='   bulk'
            else if(index(Line(LinPos(2):LinEnd(2)),'surf').ne.0) then
               system_type='surface'
            else
               system_type='cluster'
            end if
            write(9,'(a,a)')
     ,           '...> found new value for system_type = ',system_type
         end if

c..............for all parameters depending on one atom:
      else if(NumLin.eq.3) then
      
         read(Line(LinPos(3):LinEnd(3)),*,err=129) value
c     _ _ _ _ _ _ _ _ _ _ _ the species I of the pair
         call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
         if( iErr.eq.1 .or. (SpecType(i).ne.'tf') ) go to 129
            
         if(index(line(LinPos(1):LinEnd(1)),'beta_ters').ne.0) then
            call tersoff_read1(beta_ters, KINDS,
     ,           modified_beta_ters,i,value,error_ters,'beta_ters   ')
            
         else if (index(line(LinPos(1):LinEnd(1)),'c_ters').ne.0) then
            call tersoff_read1(c_ters, KINDS,
     ,           modified_c_ters,i,value,error_ters,'c_ters      ')
            
         else if (index(line(LinPos(1):LinEnd(1)),'d_ters').ne.0) then
            call tersoff_read1(d_ters, KINDS,
     ,           modified_d_ters,i,value,error_ters,'d_ters      ')
            
         else if (index(line(LinPos(1):LinEnd(1)),'h_ters').ne.0) then
            call tersoff_read1(h_ters, KINDS,
     ,           modified_h_ters,i,value,error_ters,'h_ters      ')
            
         else if (index(line(LinPos(1):LinEnd(1)),'n_ters').ne.0) then
            call tersoff_read1(nb, KINDS,
     ,           modified_nb_ters,i,value,error_ters,'n_ters      ')

         else if (index(line(LinPos(1):LinEnd(1)),'nnn_def').ne.0) then
            nnn_default(i)=value
            
         else 
            write(*,*)
     .      'Error in the Tersoff block in manual input of parameter ',
     ,      line(LinPos(1):LinEnd(1)), Species(i)
            write(9,'(a,a,a)')
     .      'Error in the Tersoff block in manual input of parameter ',
     ,      line(LinPos(1):LinEnd(1)), Species(i)
            error_ters=.true.
         endif
         
c..............parameters depending on one atom -- done
      
c..............for all parameters depending on two atoms:
      else if(NumLin.eq.4)then
         
         read(Line(LinPos(4):LinEnd(4)),*,err=129) value
         call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
         if( iErr.eq.1 .or. (SpecType(i).ne.'tf') ) go to 129
         call atom_type(Line,LinPos(3),LinEnd(3),j,iErr)
         if( iErr.eq.1 .or. (SpecType(j).ne.'tf') ) go to 129
         
         if (index(line(LinPos(1):LinEnd(1)),'A_ters').ne.0)then
            call tersoff_read2(AA, modified_AA,KINDS,i,j,
     ,           value,error_ters,'A_ters      ')
            
         else if(index(line(LinPos(1):LinEnd(1)),'B_ters').ne.0)then
            call tersoff_read2(BB, modified_BB,KINDS,i,j,
     ,           value,error_ters,'B_ters      ')
            
         else if(index(line(LinPos(1):LinEnd(1)),'R_ters').ne.0)then
            use_R_D(i,j)=.true.
            call tersoff_read2(RR, modified_RR,KINDS,i,j,
     ,           value,error_ters,'R_ters      ')
            
         else if(index(line(LinPos(1):LinEnd(1)),'D_ters').ne.0)then
            use_R_D(i,j)=.true.
            call tersoff_read2(DD, modified_DD,KINDS,i,j,
     ,           value,error_ters,'D_ters      ')
            
         else if(index(line(LinPos(1):LinEnd(1)),'Rmin_ters').ne.0)then
            use_R_D(i,j)=.false.
            call tersoff_read2(Rmin, modified_Rmin,KINDS,i,j,
     ,           value,error_ters,'Rmin_ters   ')

         else if(index(line(LinPos(1):LinEnd(1)),'Rmax_ters').ne.0)then
            use_R_D(i,j)=.false.
            call tersoff_read2(Rmax, modified_Rmax,KINDS,i,j,
     ,           value,error_ters,'Rmax_ters   ')
 
         else if((index(line(LinPos(1):LinEnd(1)),'lambda1_ters').ne.0).
     .   or.(index(line(LinPos(1):LinEnd(1)),'lambda_ters').ne.0))then
            call tersoff_read2(lam1, modified_lam1,KINDS,i,j,
     ,           value,error_ters,'lam1_ters   ')
            
         else if((index(line(LinPos(1):LinEnd(1)),'lambda2_ters').ne.0).
     .         or.(index(line(LinPos(1):LinEnd(1)),'mu_ters').ne.0))then
            call tersoff_read2(lam2, modified_lam2,KINDS,i,j,
     ,           value,error_ters,'lam2_ters   ')
            
         else if((index(line(LinPos(1):LinEnd(1)),'xi_ters').ne.0).
     .         or.(index(line(LinPos(1):LinEnd(1)),'xi_ters').ne.0))then
            call tersoff_read2(xi, modified_xi,KINDS,i,j,
     ,           value,error_ters,'xi_ters     ')
            
         else
            write(*,*)
     .      'Error in the Tersoff block in manual input of parameter ',
     ,      line(LinPos(1):LinEnd(1)), Species(i), Species(j)
            write(9,'(a,a,a)')
     .      'Error in the Tersoff block in manual input of parameter ',
     ,      line(LinPos(1):LinEnd(1)), Species(i), Species(j)
            error_ters=.true.
         endif
c..............parameters depending on two atoms -- done
      
c..............for all parameters depending on three atoms:
      else if(NumLin.eq.5)then
         
         read(Line(LinPos(5):LinEnd(5)),*,err=129) value
         call atom_type(Line,LinPos(2),LinEnd(2),i,iErr)
         if( iErr.eq.1 .or. (SpecType(i).ne.'tf') ) go to 129
         call atom_type(Line,LinPos(3),LinEnd(3),j,iErr)
         if( iErr.eq.1 .or. (SpecType(j).ne.'tf') ) go to 129
         call atom_type(Line,LinPos(4),LinEnd(4),k,iErr)
         if( iErr.eq.1 .or. (SpecType(k).ne.'tf') ) go to 129
         if(index(line(LinPos(1):LinEnd(1)),'lambda3_ters').ne.0) then
            lam3(i,j,k)=value
            lam3(i,k,j)=value
            modified_lam3(i,j,k)=.true.
            modified_lam3(i,k,j)=.true.
         else
            write(*,*)
     .      'Error in the Tersoff block in manual input of parameter ',
     ,      line(LinPos(1):LinEnd(1)), Species(i), Species(j),Species(k)
            write(9,'(a,a,a)')
     .      'Error in the Tersoff block in manual input of parameter ',
     ,      line(LinPos(1):LinEnd(1)), Species(i), Species(j),Species(k)
            error_ters=.true.
         endif
      endif
c..............parameters depending on three atoms -- done
      
      goto 1200 !Read and process the next line
      
 130  write(9,'(a,i10,a/)') 'WARNING: NN list will be updated every ',
     ,     nn_list_howoften, ' MD steps'
      write(9,'(a,a)')  '...> system_type = ',system_type
      if(error_ters) goto 129

c..........remove all shells if exist (for Tersoff atoms only)

      write(9,'(a)') '... SHELLS on Tersoff atoms are REMOVED ...'
      do i=1,KINDS
         if(SpecType(i).eq.'tf') Shell_Ref(i)=.false.
      end do
         
C..........Calculate Two-element parameters according to J.Tersoff, PRB 39, 5566 (1989).

      do i=1,KINDS
         if(SpecType(i).eq.'tf') then
            do j=1,KINDS
               if(SpecType(j).eq.'tf') then
                  if(.not.use_R_D(i,j))then
                     RR(i,j)=(Rmax(i,j)+Rmin(i,j))*0.5
                     RR(j,i)=(Rmax(j,i)+Rmin(j,i))*0.5
                     DD(i,j)=(Rmax(i,j)-Rmin(i,j))*0.5
                     DD(j,i)=(Rmax(j,i)-Rmin(j,i))*0.5
                     modified_RR(i,j)=.true.
                     modified_RR(j,i)=.true.
                     modified_DD(i,j)=.true.
                     modified_DD(j,i)=.true.
                  end if
                  if(i.gt.j) then
                     call tersoff_sum(lam1, modified_lam1,KINDS,i,j)
                     call tersoff_sum(lam2, modified_lam2,KINDS,i,j)
                     call tersoff_product(AA, modified_AA,KINDS,i,j)
                     call tersoff_product(BB, modified_BB,KINDS,i,j)
                     call tersoff_product(RR, modified_RR,KINDS,i,j)
                     call tersoff_product(DD, modified_DD,KINDS,i,j)
                  end if
               end if
            end do
         end if
      end do
C..........End of two-element parameters
      
C----------Convert Ang, eV to au and
C----------Print all parameters
      
      write(9, '(a)')'-------------------------------------'
      write(9, '(a)')'Parameters used in Tersoff calculations:'

      do i=1,KINDS
         if(SpecType(i).ne.'tf') go to 113
         write(9,'(a)')'--- '//Species(i)//' ---'

         write(9,'(a,i1)') 
     &           'nnn_default('//Species(i)//') = ',nnn_default(i) 

         if(modified_beta_ters(i)) then
            write(9, '(a,e12.6,a)')'beta_ters('//Species(i)//') = ', 
     .                        beta_ters(i), '(manual input)'
         else
            write(9, '(a,e12.6,a)')'beta_ters('//Species(i)//') = ', 
     .                        beta_ters(i), '(DEFAULT)'
         endif
         
         if(modified_nb_ters(i)) then
            write(9, '(a,e12.6,a)')'n_ters('//Species(i)//')    = ', 
     .                        nb(i), '(manual input)'
         else
            write(9, '(a,e12.6,a)')'n_ters('//Species(i)//')    = ', 
     .                        nb(i), '(DEFAULT)'
         endif
         
         if(modified_c_ters(i)) then
            write(9, '(a,e12.6,a)')'c_ters('//Species(i)//')    = ', 
     .                        c_ters(i), '(manual input)'
         else
            write(9, '(a,e12.6,a)')'c_ters('//Species(i)//')    = ', 
     .                        c_ters(i), '(DEFAULT)'
         endif
         
         if(modified_d_ters(i)) then
            write(9, '(a,e12.6,a)')'d_ters('//Species(i)//')    = ', 
     .                        d_ters(i), '(manual input)'
         else
            write(9, '(a,e12.6,a)')'d_ters('//Species(i)//')    = ', 
     .                        d_ters(i), '(DEFAULT)'
         endif
         
         if(modified_h_ters(i)) then
            write(9, '(a,e12.6,a)')'h_ters('//Species(i)//')    = ', 
     .                        h_ters(i), '(manual input)'
         else
            write(9, '(a,e12.6,a)')'h_ters('//Species(i)//')    = ', 
     .                        h_ters(i), '(DEFAULT)'
         endif
         
         do j=1,KINDS
            if(SpecType(j).ne.'tf') go to 112
            if(modified_AA(i,j)) then
               write(9, '(a,e12.6,a)')'A_ters('//Species(i)//
     ,              Species(j)//')       = ', AA(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'A_ters('//Species(i)//
     ,              Species(j)//')       = ', AA(i,j), '(DEFAULT)'
            endif
            AA(i,j)=AA(i,j)*eV_au
            
            if(modified_BB(i,j)) then
               write(9, '(a,e12.6,a)')'B_ters('//Species(i)//
     ,              Species(j)//')       = ', BB(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'B_ters('//Species(i)//
     ,              Species(j)//')       = ', BB(i,j), '(DEFAULT)'
            endif
            BB(i,j)=BB(i,j)*eV_au
            
            if(modified_RR(i,j)) then
               write(9, '(a,e12.6,a)')'R_ters('//Species(i)//
     ,              Species(j)//')       = ', RR(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'R_ters('//Species(i)//
     ,              Species(j)//')       = ', RR(i,j), '(DEFAULT)'
            endif
            RR(i,j)=RR(i,j)*A_au
            
            if(modified_DD(i,j)) then
               write(9, '(a,e12.6,a)')'D_ters('//Species(i)//
     ,              Species(j)//')       = ', DD(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'D_ters('//Species(i)//
     ,              Species(j)//')       = ', DD(i,j), '(DEFAULT)'
            endif
            DD(i,j)=DD(i,j)*A_au
            
            if(modified_lam1(i,j)) then
               write(9, '(a,e12.6,a)')'lambda1_ters('//Species(i)//
     ,              Species(j)//') = ', lam1(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'lambda1_ters('//Species(i)//
     ,              Species(j)//') = ', lam1(i,j), '(DEFAULT)'
            endif
            lam1(i,j)=lam1(i,j)/A_au
            
            if(modified_lam2(i,j)) then
               write(9, '(a,e12.6,a)')'lambda2_ters('//Species(i)//
     ,              Species(j)//') = ', lam2(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'lambda2_ters('//Species(i)//
     ,              Species(j)//') = ', lam2(i,j), '(DEFAULT)'
            endif
            lam2(i,j)=lam2(i,j)/A_au
            
            if(modified_xi(i,j)) then
               write(9, '(a,e12.6,a)')'xi_ters('//Species(i)//
     ,              Species(j)//')       = ', xi(i,j), '(manual input)'
            else
               write(9, '(a,e12.6,a)')'xi_ters('//Species(i)//
     ,              Species(j)//')       = ', xi(i,j), '(DEFAULT)'
            endif
            
ccc   endif   !condition if(i.ge.j)
            
            do k=1,KINDS
               if(SpecType(k).ne.'tf') go to 111
               if(modified_lam3(i,j,k)) then
                  write(9, '(a,e12.6,a)')'lambda3_ters('//Species(i)//
     ,                 Species(j)// Species(k)//') = ', lam3(i,j,k), 
     ,                 '(manual input)'
               else
                  write(9, '(a,e12.6,a)')'lambda3_ters('//Species(i)//
     ,                 Species(j)// Species(k)//') = ', lam3(i,j,k), 
     ,                 '(DEFAULT)'
               endif
               lam3(i,j,k)=lam3(i,j,k)/A_au
 111        end do
            
 112     end do
 113  end do
      
      write(9,'(a/)')
     &'################################################################'
      return
c
c............... if error was found
c     
 129  WRITE(9,'(a/)')'FATAL! <Tersoff> box is WRONG or absent !!! '
      WRITE(*,*)     'FATAL! <Tersoff> box is WRONG or absent !!! '
      KodErr=1
      do_tersoff=.false.
      write(9,'(a/)')
     &'################################################################'
      END              

      subroutine tersoff_read1(param, KINDS,modified_parameter,i,
     ,           value,error_ters,char)
            
      logical modified_parameter(KINDS),error_ters
      integer i,KINDS
      character char*12
      double precision param(KINDS),value
            
      if(modified_parameter(i))then
         error_ters=.true.
               write(*,*)
     .            'WARNING: parameter //char// has already been defined'
               write(9,'(a/)')
     .            'WARNING: parameter //char// has already been defined'
      else
         param(i)=value
         modified_parameter(i)=.true.
      endif
      write(9,*) char,'(',i,')','=',value
      
      return
      end

      subroutine tersoff_read2(param, modified_parameter,KINDS,i,j,
     ,           value,error_ters,char)
            
      logical modified_parameter(KINDS,KINDS),error_ters
      integer i,j,KINDS
      character char*12
      double precision param(KINDS,KINDS),value
            
      if(modified_parameter(i,j)) then
         error_ters=.true.
         write(*,*)
     .          'WARNING: parameter //char// has already been defined'
         write(9,'(a/)')
     .          'WARNING: parameter '//char//' has already been defined'
         return
      else
         param(i,j)=value
         param(j,i)=value
         modified_parameter(i,j)=.true.
         modified_parameter(j,i)=.true.
      endif
      write(9,*)char,'(',i,',',j,')','=',value
      
      return
      end
      
      subroutine tersoff_sum(param, modified_parameter,KINDS,i,j)
            
      logical modified_parameter(KINDS,KINDS)
      integer i,j,KINDS
      double precision param(KINDS,KINDS)
            
      if(.not.modified_parameter(i,j))then
         param(i,j)=(param(i,i)+param(j,j))*0.5
         param(j,i)=param(i,j)
      endif
      
      return
      end

      subroutine tersoff_product(param,modified_parameter,KINDS,i,j)
            
      logical modified_parameter(KINDS,KINDS)
      integer i,j,KINDS
      double precision param(KINDS,KINDS)
            
      if(.not.modified_parameter(i,j)) then
         param(i,j)=sqrt( param(i,i)*param(j,j) )
         param(j,i)=param(i,j)
      endif
      
      return
      end
