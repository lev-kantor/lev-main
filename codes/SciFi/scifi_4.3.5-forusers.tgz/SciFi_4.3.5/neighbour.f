      subroutine neighbour(Natoms_sur,Type,KodErr)
c......................................................................
c find all nn of every atom in bond(atom,nn) for the current geometry;
c if atoms are at the boundary (like Si#), then there are no neighbours.
c......................................................................
c Type = either 'tf' or 'mb', i.e. only bond connections are done 
c        between atoms of the same type (Tersoff or Many-body)
c......................................................................
c   nnn(i) = # of nn of atom i
c bond(i,j)= atom number of the nn to atom i; this is nn number j
c            (there could be several nn atoms for atom i)
c......................................................................
      include 'tersoff.inc'
      integer which_nn_pair
      character Type*2

c      write(9,*) '...NEIGHBOUR for '//Type//' .............'

      DO i=1,Natom
         is=ISRT(i)
         if(SpecType(is).ne.Type) go to 50

         do nbb=1,N0BD
            bond(i,nbb)=0
         end do
         if(Species(is)(3:3).eq.'#') then
            nnn(i)=0
            go to 50
         end if

c         write(9,*) '.........> neighbours of atom i= ',i

c_____loop over all other atoms in the molecule; iii - counts neighbours of i
         iii=0
         do ii=1,Natoms_sur
            iis=ISRT_sur(ii)
            if(SpecType(iis).ne.Type) go to 51
c_____loop over all specified pair parameters
            dist1=dist(xr(i),yr(i),zr(i),xr(ii),yr(ii),zr(ii))
            if(dist1.gt.Pair_dist_max .or. dist1.lt.0.001) go to 51
            j=which_nn_pair(is,iis)
            if(j.eq.0) go to 51
c            write(9,'(i3,2(x,a),i3,f10.5)') 
c     &                ii,Species(is),Species(iis),j,dist1

            if(dist1.lt.max_bond(j)) then
c_________  If an atom has too many neighbours then give an error message and exit.
               if(iii+1.gt.N0BD) then
                  write(9,*) ' - !Error: atom ',i,' has more ',
     &                 'bonds than N0BD=', N0BD,'!- NM'
                  write(*,'(a,i3,3(x,f10.5))')
     &                                'atom ',i,xr(i),yr(i),zr(i)
                  write(*,'(a,f10.5)') 'max_bond = ',max_bond(j)
                  do k=1,iii
                     k1=bond(i,k)
                     d=sqrt((xr(i)-xr(k1))**2+(yr(i)-yr(k1))**2+
     +                    (zr(i)-zr(k1))**2)
                    write(*,'(2i4,4(x,f10.5))') 
     ,                    k, k1,xr(k1),yr(k1),zr(k1),d
                  end do
                  go to 55
               end if
c_________  add to the neighbours list
               iii=iii+1
               bond(i,iii)=ii
c                        write(9,*) 'added'

            end if
 51      end do
         nnn(i)=iii

 50   END DO

      open(2,file='nn.out')
      do i=1,Natom
         is=ISRT_sur(i)
         if(SpecType(is).ne.Type) go to 52
         write(2,'(a,i5,x,l1,x,a,i2,3(x,f10.5),a,x,a)') 
     &        'atom ',i,central_atom(i),' #-of-nn= ', nnn(i),
     &        xr(i),yr(i),zr(i),Species(is),SpecType(is)
         do j1=1,nnn(i)
            j=bond(i,j1)
            js=ISRT_sur(j)
            d=(xr(i)-xr(j))**2+(yr(i)-yr(j))**2+(zr(i)-zr(j))**2
            d=sqrt(d)
            write(2,'(a,i5,a,i5,x,l1,x,4(x,f10.5))') 'its nn ',j1, 
     ,           ' actual # = ',j,central_atom(j),xr(j),yr(j),zr(j),d
         end do
 52   end do
      close (2)
      return

c................. errors      
 55   WRITE(9,'(a/)')'FATAL! Too many neighbours!!! '
      WRITE(6,*)'FATAL! Too many neighbours!!! '
      KodErr=1
      end

      integer function which_nn_pair(is,iis)
      include 'tersoff.inc'
      integer is,iis
      do j=1,n_pair
         if( (is.eq.pair(j,1) .and. iis.eq.pair(j,2)) .or. 
     &        (is.eq.pair(j,2) .and. iis.eq.pair(j,1))) then
            which_nn_pair=j
            return
         end if
      end do
c............. cannot find the pair: then ignore the pair in bonding
c      write(*,*)'Which_nn_pair: problem in identifying a pair'
      which_nn_pair=0
      return
      end

      subroutine create_surrounding(Natoms_sur)
c......................................................................
c if system_type='   bulk' or 'surface', it creates atomic positions
c for all atoms 3x3x3 (bulk) or 3x3 (surface) cells; only Tersoff
c related atoms are actually bred.
c......................................................................
c note that atoms of the central cell always set at the beginning of
c the extended list in the same order as in the cell: 1,...,Natom
c......................................................................
      include 'tersoff.inc'


      do i=1,Natom
         xr(i)=x(i)
         yr(i)=y(i)
         zr(i)=z(i)
         ISRT_sur(i)=ISRT(i)
      end do
      if(system_type.eq.'cluster') then
         Natoms_sur=Natom
         return
      else if(system_type.eq.'   bulk') then
         ii=Natom
         do j=1,Natom
            js=ISRT(j)
            if(SpecType(js).ne.'tf') go to 10
            Ref_sur(j)=ii+1
            do i1=-1,1
               do i2=-1,1
                  do i3=-1,1
                     if(i1.ne.0 .or. i2.ne.0 .or. i3.ne.0) then
                        ii=ii+1
                        xr(ii)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+x(j)
                        yr(ii)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+y(j)
                        zr(ii)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+z(j)
                        ISRT_sur(ii)=ISRT(j)
                     end if
                  end do
               end do
            end do
 10      end do
         Natoms_sur=ii
      else if(system_type.eq.'surface') then
         ii=Natom
         do j=1,Natom
            js=ISRT(j)
            if(SpecType(js).ne.'tf') go to 20
            Ref_sur(j)=ii+1
            do i1=-1,1
               do i2=-1,1
                  if(i1.ne.0 .or. i2.ne.0) then
                     ii=ii+1
                     xr(ii)=i1*AJ(1,1)+i2*AJ(2,1)+x(j)
                     yr(ii)=i1*AJ(1,2)+i2*AJ(2,2)+y(j)
                     zr(ii)=i1*AJ(1,3)+i2*AJ(2,3)+z(j)
                     ISRT_sur(ii)=ISRT(j)
                  end if
               end do
            end do
 20      end do
         Natoms_sur=ii
      end if
c................................. test printing
c         open(112,file='test.xyz')
c      n_xyz_sur=n_xyz_sur+1
c         write(112,'(2i10/)') Natoms_sur,n_xyz_sur
c         write(*,'(2i10)') Natoms_sur,n_xyz_sur
c         do i=1,Natoms_sur
c            if(i.le.natom) then
c               write(112,'(a,3(x,f10.5),3i5)') 
c     &           'Si ',xr(i)*au_A,yr(i)*au_A,zr(i)*au_A,i,ISRT_sur(i)
c            else
c               write(112,'(a,3(x,f10.5),3i5)') 
c     &           'Ge ',xr(i)*au_A,yr(i)*au_A,zr(i)*au_A,i,ISRT_sur(i)
c            end if
c         end do
c         close (112)
c         open(222,file='test.image')
c         do i=1,Natom
c            if(system_type.eq.'surface') then
c               write(222,'(a,i3,8(x,i3))') 'i=',i,Ref_sur(i)
c            else if(system_type.eq.'   bulk') then
c               write(222,'(a,i3,8(x,i3))') 'i=',i,Ref_sur(i)
c            end if
c         end do
c         close (222)
      end
