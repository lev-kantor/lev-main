      subroutine test_direction(p,g,iPrnt)
      include 'shell.inc'
      dimension p(N0FR),g(N0FR)
      if(nid.eq.0) then
         write(*,'(a)')'....))) Okay, going along the direction (((....'
         write(19,'(/a/)')'#..))) Okay, going along the direction (((..'
         write(19,'(a)') '#   i     coord                   energy'
      end if

      i=dir_num
c............... going along direction i

      c0=p(i)
      do ic=1,n_dir_steps
         p(i)=dir_start+dir_step*(ic-1)
         if(nid.eq.0) write(*,'(a,i3,a,e20.12)')
     &                  '... doing point ic= ',ic,' coordinate = ',p(i)
         en = energy(p,iPrnt)
         if(nid.eq.0) write(19,'(i5,2(e20.12,x))') ic,p(i),en
      end do
      p(i)=c0
      return
      end

      subroutine test_forces1(p,g,iPrnt)
c......................................................................
c this is another version based on moving atoms along axes one by one
c......................................................................
      include 'shell.inc'
      dimension p(N0FR),g(N0FR),en(5),crd(5)
      character coor(3)
      data coor/'x','y','z'/
      
      call conv_1_3(g,fx,fy,fz,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

      if(nid.eq.0) then
         write(*,'(a)')'....))) Okay, checking the gradients (((....'
         write(*,'(/a/)')'..))) Okay, checking the gradients (((....'
      end if

      do i=1,Natom
         if(nid.eq.0) write(*,'(a,i5,a,3(x,f10.5))')
     &           'atom ',i,' position => ',x(i)*au_A,y(i)*au_A,z(i)*au_A

c............. shifting along X 
         if(iRx(i).eq.1) then
            c0=x(i)
            do ic=1,5
               crd(ic)=step0*(ic-3)
               x(i)=c0+crd(ic)
               call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     ,              n_pos_cor,iRx,iRy,iRz)
               en(ic) = energy(p,iPrnt)
            end do
            call quadr(en,crd,5,a,b,c,err,iPrnt)
            x(i)=c0
         else
           b=0.0
         end if
         if(nid.eq.0) write(*,'(5x,3(a,e20.12),5x,i1)') 
     ,        'X: num= ',b,' anl= ',fx(i),' err= ',abs(b-fx(i)),iRx(i)

c............. shifting along Y
         if(iRy(i).eq.1) then
            c0=y(i)
            do ic=1,5
               crd(ic)=step0*(ic-3)
               y(i)=c0+crd(ic)
               call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     ,              n_pos_cor,iRx,iRy,iRz)
               en(ic) = energy(p,iPrnt)
            end do
            call quadr(en,crd,5,a,b,c,err,iPrnt)
            y(i)=c0
         else
            b=0.0
         end if
         if(nid.eq.0) write(*,'(5x,3(a,e20.12),5x,i1)') 
     ,        'Y: num= ',b,' anl= ',fy(i),' err= ',abs(b-fy(i)),iRy(i)

c............. shifting along Z
         if(iRz(i).eq.1) then
            c0=z(i)
            do ic=1,5
               crd(ic)=step0*(ic-3)
               z(i)=c0+crd(ic)
               call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
     ,              n_pos_cor,iRx,iRy,iRz)
               en(ic) = energy(p,iPrnt)
            end do
            call quadr(en,crd,5,a,b,c,err,iPrnt)
            z(i)=c0
         else
            b=0.0
         end if
         if(nid.eq.0) write(*,'(5x,3(a,e20.12),5x,i1)') 
     ,        'Z: num= ',b,' anl= ',fz(i),' err= ',abs(b-fz(i)),iRz(i)
      end do
      end

      subroutine test_forces(p,g,iPrnt)
c...........................................................................
c this is the standrd version based on moving degrees of freedom one by one
c...........................................................................
      include 'shell.inc'
      dimension p(N0FR),g(N0FR),en(5),crd(5)

      if(nid.eq.0) then
         write(*,'(a)')'....))) Okay, checking the gradients (((....'
         write(*,'(/a/)')'..))) Okay, checking the gradients (((....'
         write(*,'(a)')
     &        '   i     coord                   analytical   '//
     &   '        numerical              error'
      end if

      do i=1,n_dfree
c............... checking the component i of the force
c                (interpolation by 5 points around the given coordinate)
         c0=p(i)
         do ic=1,5
            crd(ic)=step0*(ic-3)
            p(i)=c0+crd(ic)
            en(ic) = energy(p,iPrnt)
            if(nid.eq.0.and.iPrnt.ge.10) 
     &           write(19,'(i5,2(e20.12,x))') ic,p(i),en(ic)
         end do
         call quadr(en,crd,5,a,b,c,err,iPrnt)
         p(i)=c0
         if(nid.eq.0) 
     &        write(*,'(i4,4(x,e20.12))') i,p(i),g(i),b,abs(b-g(i))
      end do

      return
      end

      subroutine test_tip_force(p,g,en1,iPrnt)
c.......................................................................
c The calculated force on the tip is checked here numerically.
c    Note that the current configuration is not dumped to RST during
c relaxation steps not to overwrite the existing current configuration.
c.......................................................................
      include 'shell.inc'
      dimension p(N0FR),g(N0FR),en(3),crd(3),r(3),tipf(3)

      Yes_Dump=.false.
      do_lat=.true.
      step0=sqrt(shft(1)**2+shft(2)**2+shft(3)**2)

      if(nid.eq.0) then
         write(*,'(/a/)')'..))) Okay, checking the TIP gradient (((....'
         write(19,'(a)') '..))) Okay, checking the TIP gradient (((....'
c
c[1]............. calculation at the given geometry
         write(*,'(/a/)')'...... doing the 1st point ........'
         write(9,'(/a/)')'...... doing the 1st point ........'
      end if
      r(1)=0.0
      r(2)=0.0
      r(3)=0.0
c      call conv_3_1(x,y,z,p,iShell,Shell_Ref,ISRT,Natom,
c     ,                  n_pos_cor,iRx,iRy,iRz)
      call move_and_relax(en1,r,iPrnt,'return',.true.,tipf)
      tipf1=(tipf(1)*shft(1)+tipf(2)*shft(2)+tipf(3)*shft(3))/step0
      en(2)=en1
      crd(2)=0.0

c
c[2]............. calculation for the shifted down geometry
      if(nid.eq.0) then
         write(*,'(/a/)')'...... doing the 2nd point ........'
         write(9,'(/a/)')'...... doing the 2nd point ........'
      end if
      r(1)=-shft(1)
      r(2)=-shft(2)
      r(3)=-shft(3)
      call move_and_relax(en1,r,iPrnt,'return',.false.,tipf)
      en(1)=en1
      crd(1)=-step0

c
c[3]............. calculation for the shifted up geometry
      if(nid.eq.0) then
         write(*,'(/a/)')'...... doing the 3rd point ........'
         write(9,'(/a/)')'...... doing the 3rd point ........'
      end if
      r(1)=2*shft(1)
      r(2)=2*shft(2)
      r(3)=2*shft(3)
      call move_and_relax(en1,r,iPrnt,'return',.false.,tipf)
      en(3)=en1
      crd(3)=step0

c
c............... interpolation by 3 points around the given tip position
      do i=1,3
         write(9,'(i2,2(x,e20.12))') i, crd(i), en(i)
      end do
      call quadr(en,crd,3,a,b,c,err,iPrnt)
      write(9,'(3(e20.12,x))') a,b,c
      if(nid.eq.0) then
         write(6,'(/a)')
     & '       analytical           numerical              error'
         write(6,'(4(x,e20.12))') tipf1,-b,abs(-b-tipf1)
         write(19,'(a)')
     & '       analytical           numerical              error'
         write(19,'(4(x,e20.12))') tipf1,-b,abs(-b-tipf1)
      end if
      return
      end

      subroutine quadr(Y,X,N,a,b,c,err,iPrnt)
c.............................................................
c Perform quadratical interpolation Y=a+b*X+c*X*X for the grid 
c of points Y(i), X(i), i=1,...,N
c.....Output:
c            a,b,c - coefficients
c            err - relative error of the interpolation
c.............................................................
       include 'real8.inc'
       dimension Y(N),X(N)
c
c......... Compute the moments of the data points:
       x1=0.0
       x2=0.0
       x3=0.0
       x4=0.0
       y1=0.0
       yx1=0.0
       yx2=0.0
       do i=1,N
          x1=x1+X(i)
          x2=x2+X(i)*X(i)
          x3=x3+X(i)*X(i)*X(i)
          x4=x4+X(i)*X(i)*X(i)*X(i)
          y1=y1+Y(i)
          yx1=yx1+Y(i)*X(i)
          yx2=yx2+Y(i)*X(i)*X(i)
       end do
       x1=x1/N
       x2=x2/N
       x3=x3/N
       x4=x4/N
       y1=y1/N
       yx1=yx1/N
       yx2=yx2/N
c     
c.......... compute the linear coefficients a,b,c
       det=(x2*x1-x3)**2-(x1*x1-x2)*(x2*x2-x4)
       detc=(y1*x1-yx1)*(x2*x1-x3)-(y1*x2-yx2)*(x1*x1-x2)
       c=detc/det
       b=( (y1*x1-yx1)-c*(x2*x1-x3) )/(x1*x1-x2)
       a=y1-b*x1-c*x2
c
c.......... compute the error of the interpolation
       err=0.0
       do i=1,N
c          if(iPrnt.ge.8) 
c     &       write(19,'(i3,3(1x,d21.14))') 
            write(9,'(i3,3(1x,d21.14))') 
     &         i,X(i),Y(i),a+b*X(i)+c*X(i)*X(i)
          err=err+(Y(i)-(a+b*X(i)+c*X(i)*X(i)))**2
       end do
       err=err/N
       return
       end
