      subroutine Bare_zforce(Rad,V,H,iPrnt,Bare,Bare_Sphere)
c..............................................................................
c   The force on the sphere (z-component) due to bare electrodes potential
c acting on all charges is calculated.
c..............................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      parameter (Number02=Number0/2+1)
      dimension r(3),eup(3),edw(3)
      dimension Drv_rBk(Number02),Drv_Bch(Number02)
c
      if(iPrnt.ge.4) write(10,'(/a/)')
     &  '...... calculating z-force from B-charges (bare electrodes)'
c
c....... calculate the derivatives for all charges B_image(k)
c        above the plane:
c           Drv_Bch(k) - charges over sphere z-position
c           Drv_rBk(k) - charges z-positions over sphere z-position
c           Sum_Drv_Bch - sum of all derivatives of charges
c
      xlmb=H/Rad
      Dk=2.0
      D=2*xlmb
      Drv_Bch(1)=0.0
      Drv_rBk(1)=Rad
      Sum_Drv_Bch=Drv_Bch(1)
      k=1
      if(iPrnt.ge.8) then
         write(10,'(a)') '  k      Dk          D          Drv_Bch(k)'//
     &          '   Drv_rBk(k) Sum_Drv_Bch'
         write(10,'(i3,5(1x,e12.6))') 
     &               k,Dk,D,Drv_Bch(k),Drv_rBk(k),Sum_Drv_Bch
      end if
      if(.not.do_plane) go to 50

      do k=2,Number-1
        Drv_Bch(k)=( Drv_Bch(k-1) - B_image(k-1)*Dk/D )/D
        Dk=2.0+Dk/(D*D)
        Drv_rBk(k)=Rad*(Dk-1.0)
        Sum_Drv_Bch=Sum_Drv_Bch+Drv_Bch(k)
        D=2*xlmb-1.0/D
        if(iPrnt.ge.8) write(10,'(i3,5(1x,e12.6))') 
     &               k,Dk,D,Drv_Bch(k),Drv_rBk(k),Sum_Drv_Bch
      end do
      D_inf=xlmb+sqrt(xlmb*xlmb-1.0)
      Drv_rBk(Number)=Rad*xlmb/(D_inf-xlmb)
      a=D_inf/( (D_inf-1.0)*(D_inf-xlmb) )
      Drv_Bch(Number)=( Drv_Bch(Number-1) - 
     -                       B_image(Number-1)*a )/(D_inf-1.0)
      Sum_Drv_Bch=Sum_Drv_Bch+Drv_Bch(Number)
      Sum_Drv_Bch=Sum_Drv_Bch/Rad
      k=Number
      if(iPrnt.ge.8) write(10,'(i3,5(1x,e12.6))') 
     &               k,Dk,D,Drv_Bch(k),Drv_rBk(k),Sum_Drv_Bch
c
c.......... in a loop over all charges: calculate the contribution
c           to the total force acting on the sphere from the bare
c           electrodes' potential
c
 50   Bare=0.0
      if(N_add_charges.eq.0) go to 200
      do L=1,N_add_charges
        if(iPrnt.ge.4) write(10,'(a,i3,a)') 
     &        '... deriv. of potent. on L=',L,' ........'    
c______________ if only sphere is present        
        if(.not.do_plane) then
           r(1)=R_im(1,1)-R_charge(L,1)
           r(2)=R_im(1,2)-R_charge(L,2)
           r(3)=R_im(1,3)-R_charge(L,3)
           call e_vector(r,eup,up)
           s=-B_image(1)*eup(3)*Rad
           go to 60
        end if
c_______________ sphere + plane: contribution from the given charge L
        s=0.0
        do k=1,Number
          r(1)=R_im(k,1)-R_charge(L,1)
          r(2)=R_im(k,2)-R_charge(L,2)
          r(3)=R_im(k,3)-R_charge(L,3)
          call e_vector(r,eup,up)
          j=k+Number
          r(1)=R_im(j,1)-R_charge(L,1)
          r(2)=R_im(j,2)-R_charge(L,2)
          r(3)=R_im(j,3)-R_charge(L,3)
          call e_vector(r,edw,dw)
          s=s+ Drv_Bch(k)*(1.0/up-1.0/dw) - 
     -                  B_image(k)*(eup(3)+edw(3))*Drv_rBk(k)
          if(iPrnt.ge.10) write(10,'(i3,3(1x,e12.6))') k,up,dw,s
        end do
 60     if(iPrnt.ge.10) write(10,'(a,e12.6)') 's= ',s
c________________ summing up all the contributions
        Bare=Bare-0.5*Charges(L)*s/Rad
        if(iPrnt.ge.8) 
     &         write(10,'(a,i3,2(1x,e12.6))') 'L=',L,Charges(L),Bare
      end do
c
c.......... add the contribution from the spherical electrode
c
 200  en_unit=0.036749
      Bare_Sphere=0.5*V*Sum_Drv_Bch*en_unit
      if(iPrnt.ge.4) write(10,'(2(a,1x,e12.6))') 
     &          'Bare=',Bare,' Bare_Sphere=',Bare_Sphere
      return
      end

      subroutine zForce_ind(L,R_Sph,Rad,V,H,iPrnt,zfrc,zfrc_Sph)
c..............................................................................
c   The force on the sphere (z-component) due to induced charges associated
c with the given charge L (the induced charges are currently in 
c the common /image_charges/, see <images.inc>) is calculated.
c..............................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      dimension R_ch(3),R_Sph(3)
c
c............ calculating the contributions to the z-force from the current
c             Q-charges generated from the given L-charge
c
      if(iPrnt.ge.4) write(10,'(/a,i5/)')
     &  '...... calculating z-force from Q-charges due to charge L=',L
      do i=1,3
        R_ch(i)=R_imQ(0,i)
      end do
      call do_zforce(R_ch,R_Sph,Rad,V,H,iPrnt,zfrcQ,zfrcQ_Sph,'Q')
      if(iPrnt.ge.4) 
     &   write(10,'(a,2(1x,e12.6))')'Q-charges: ',zfrcQ,zfrcQ_Sph
      zfrcP=0.0
      zfrcP_Sph=0.0
      if(.not.do_plane) go to 10
c
c............ calculating the contributions to the z-force from the current
c             P-charges generated from the given L-charge
c
      if(iPrnt.ge.4) write(10,'(/a,i5/)')
     &  '...... calculating z-force from P-charges due to charge L=',L
      do i=1,3
        R_ch(i)=R_imP(0,i)
      end do
      call do_zforce(R_ch,R_Sph,Rad,V,H,iPrnt,zfrcP,zfrcP_Sph,'P')
      if(iPrnt.ge.4) 
     &   write(10,'(a,2(1x,e12.6))')'P-charges: ',zfrcP,zfrcP_Sph
c
c......... total contribution
c
 10   zfrc=zfrcQ+zfrcP
      zfrc_Sph=zfrcQ_Sph+zfrcP_Sph
      if(iPrnt.ge.4) 
     &   write(10,'(a,2(1x,e12.6))')'Q,P-charges: ',zfrc,zfrc_Sph
      return
      end

      subroutine do_zforce(R_ch,R_Sph,Rad,V,H,iPrnt,zfrc,zfrc_Sph,who)
c..............................................................................
c   The force on the sphere (z-component) due to induced charges associated
c with the given source charge at R_ch (the induced charges are currently in 
c the common /image_charges/, see <images.inc>) is calculated.
c..............................................................................
c    Depending on the actual position R_ch of the source charge, the result 
c here will correspond to the contribution either from Q- or P-charges.
c..............................................................................
c  who='Q' or 'P'
c..............................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      parameter (Number02=Number0/2+1)
      dimension r(3),eup(3),edw(3),R_Sph(3),e(3),R_ch(3)
      dimension delta(3),teta(3),Ztlda(3)
      dimension Drv_rk(Number02,3),Drv_ch(Number02)
      character who
      data delta/0.0d00,0.0d00,1.0d00/,teta/1.0d00,1.0d00,-1.0d00/
c
c........... calculate derivatives of Q- and P-induced charges as well as
c            derivatives of their vector-positions:
c  Drv_rk(k,xyz) - derivative of every component of the position of
c                     the Q(P)-charge k
c  Drv_ch(k) - derivative of the value of the Q(P)-charge k
c
c_____________ initial setting for the recursion process

      r(1)=R_ch(1)-R_Sph(1)
      r(2)=R_ch(2)-R_Sph(2)
      r(3)=R_ch(3)-R_Sph(3)
      call e_vector(r,e,r1)
      r2=r1*r1
      a=Rad*Rad/r2
      do i=1,3
         b=delta(i)-2*r(3)*r(i)/r2
         Drv_rk(1,i)=delta(i)-a*b
      end do
      if(who.eq.'Q') then
         Drv_ch(1)=-Rad*e(3)*Q_image(0)
      else
         Drv_ch(1)=-Rad*e(3)*P_image(0)
      end if
      k=1
      if(iPrnt.ge.10) write(10,'(i3,4(1x,e12.6))')
     &     k,Drv_ch(k),(Drv_rk(k,i),i=1,3)
c_____________only sphere present
      if(.not.do_plane) go to 50
  
c     
c_________________ start recursion process
c
      do k=2,NumberQP-1
        j=k+NumberQP
        if(who.eq.'Q') then
          r(1)=R_imQ(j-1,1)-R_Sph(1)
          r(2)=R_imQ(j-1,2)-R_Sph(2)
          r(3)=R_imQ(j-1,3)-R_Sph(3)
          Qim=Q_image(k-1)
        else
          r(1)=R_imP(j-1,1)-R_Sph(1)
          r(2)=R_imP(j-1,2)-R_Sph(2)
          r(3)=R_imP(j-1,3)-R_Sph(3)
          Qim=P_image(k-1)
        end if
        r2=r(1)*r(1)+r(2)*r(2)+r(3)*r(3)
        r1=sqrt(r2)
        a=Rad*Rad/r2
        scal=0.0
        do i=1,3
          Ztlda(i)=teta(i)*Drv_rk(k-1,i)-delta(i)
          scal=scal+Ztlda(i)*r(i)
        end do
        do i=1,3
          Drv_rk(k,i)=delta(i)+a*( Ztlda(i)-2*scal*r(i)/r2 )
        end do
        Drv_ch(k)=Rad/r1*(Drv_ch(k-1)-scal*Qim/r2)
        if(iPrnt.ge.10) write(10,'(i3,4(1x,e12.6))')
     &                      k,Drv_ch(k),(Drv_rk(k,i),i=1,3)
      end do
c
c____________ "last" term
      rt=sqrt(H*H-Rad*Rad)
      a=Rad/(H-Rad+rt)
      b=(H+rt)/(rt*(H-Rad+rt))
      do i=1,3
        Drv_rk(NumberQP,i)=delta(i)*H/rt
      end do
      if(who.eq.'Q') then
        Qim=Q_image(NumberQP-1)
      else
        Qim=P_image(NumberQP-1)
      end if
      Drv_ch(NumberQP)=a*(Drv_ch(NumberQP-1)-Qim*b)
      k=NumberQP
      if(iPrnt.ge.10) write(10,'(i3,4(1x,e12.6))')
     &                       k,Drv_ch(k),(Drv_rk(k,i),i=1,3)
c
c.........summing up the contributions coming out from this induced
c         charge L due to potential produced on ALL charges L1
c
 50   contr=0.0
      do L1=1,N_add_charges
c_______________ contribution to the given charge L1
        if(iPrnt.ge.4) write(10,'(a,i3,a)') 
     &        '... deriv. of potent. on L1=',L1,' ........'            
c
c__________________ if only sphere is present
        if(.not.do_plane) then
           r(1)=R_charge(L1,1)-R_imQ(1,1)
           r(2)=R_charge(L1,2)-R_imQ(1,2)
           r(3)=R_charge(L1,3)-R_imQ(1,3)
           call e_vector(r,eup,up)
           sc=eup(1)*Drv_rk(1,1)+eup(2)*Drv_rk(1,2)+eup(3)*Drv_rk(1,3)
           s=Drv_ch(1)/up + Q_image(1)*sc
           go to 100
        end if
c__________________ sphere + plane
        s=0.0
        do k=1,NumberQP
c___________________ images above the plane
          if(who.eq.'Q') then
            r(1)=R_charge(L1,1)-R_imQ(k,1)
            r(2)=R_charge(L1,2)-R_imQ(k,2)
            r(3)=R_charge(L1,3)-R_imQ(k,3)
            Qim=Q_image(k)
          else
            r(1)=R_charge(L1,1)-R_imP(k,1)
            r(2)=R_charge(L1,2)-R_imP(k,2)
            r(3)=R_charge(L1,3)-R_imP(k,3)
            Qim=P_image(k)
          end if
          call e_vector(r,eup,up)
          scalup=0.0
          do i=1,3
            scalup=scalup+eup(i)*Drv_rk(k,i)
          end do
c___________________ images below the plane
          j=k+NumberQP
          if(who.eq.'Q') then
            r(1)=R_charge(L1,1)-R_imQ(j,1)
            r(2)=R_charge(L1,2)-R_imQ(j,2)
            r(3)=R_charge(L1,3)-R_imQ(j,3)
          else
            r(1)=R_charge(L1,1)-R_imP(j,1)
            r(2)=R_charge(L1,2)-R_imP(j,2)
            r(3)=R_charge(L1,3)-R_imP(j,3)
          end if
          call e_vector(r,edw,dw)
          scaldw=0.0
          do i=1,3
            scaldw=scaldw+edw(i)*Drv_rk(k,i)*teta(i)
          end do
          s=s+Drv_ch(k)*(1.0/up-1.0/dw)+Qim*(scalup-scaldw)

        end do

 100    contr=contr+s*Charges(L1)
        if(iPrnt.ge.10) write(10,'(2(a,e12.6))')'s= ',s,' contr= ',contr

      end do
      zfrc=contr
c
c............ contribution to the force due to the total induced charge
c             on the sphere and the applied bias
c
 200  Sum_Drv_ch=0.0
      do k=1,NumberQP
        Sum_Drv_ch=Sum_Drv_ch+Drv_ch(k)
      end do
      en_unit=0.036749
      zfrc_Sph=0.5*V*Sum_Drv_ch*en_unit
      if(iPrnt.ge.10) write(10,'(a,e12.6)')'Sum_Drv_ch= ',Sum_Drv_ch
      return
      end

