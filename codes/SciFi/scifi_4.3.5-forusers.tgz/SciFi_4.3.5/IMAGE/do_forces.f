      subroutine bare_forces(iPrnt)
c........................................................................
c         Contributions to forces on ALL added charges (due to 
c   bare electrodes) are calculated. 
c........................................................................
c Mind: the B-charges should have been calculated just before this call.
c........................................................................
c  All forces are set here for the first time.
c........................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      dimension Rr(3),Fo(3),r(3),r1(3),e(3),e1(3)

      if(iPrnt.ge.4) write(10,'(/a/)')
     &                    '>>>>>>>>>> doing bare forces <<<<<<<<<<'
c
c................ loop over all charges
c
      DO Nch=1,N_add_charges
        if((iFlagF(Nch).eq.0) .or. (do_QMC.and.iFlagQMC(Nch).eq.1)) then
          Force(Nch,1)= 0.0
          Force(Nch,2)= 0.0
          Force(Nch,3)= 0.0
          go to 100
        end if
        do i=1,3
          Rr(i)=R_charge(Nch,i)
          Fo(i)=0.0
        end do
c
c_____________________ contribution from the B-charges
c
        do k=1,Number
          j=k+Number
          do i=1,3
            r(i)=Rr(i)-R_im(k,i)
            if(do_plane) r1(i)=Rr(i)-R_im(j,i)
            e1(i)=0.0
          end do
          call e_vector(r,e,d)
          if(do_plane) call e_vector(r1,e1,d1)
          do i=1,3
            Fo(i)=Fo(i)+B_image(k)*(e(i)-e1(i))
          end do
        end do
c
c_____________________ putting this into the force
c
        do i=1,3
          Force(Nch,i)= Charges(Nch)*Fo(i)
        end do
 100    if(iPrnt.ge.4) 
     &        write(10,'(i5,5x,3(1x,e12.6))') Nch,(Force(Nch,i),i=1,3)
      END DO
      return
      end

      subroutine forces(L,R_Sph,Rad,H,V,iPrnt)
c........................................................................
c         Contributions to forces on ALL added charges due to the
c   current added charge L are calculated. 
c   ^^^^^^^^^^^^^^^^^^^^   
c........................................................................
c Mind: the Q,P charges should have been calculated just before this call.
c........................................................................
c  Forces should have been set initially somewhere above this routine.
c........................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      include 'charges.inc'
      include 'xy.inc'
      dimension R_ch(3),R_Sph(3),f2(3),f1(3),Fi1(3),Fi2(3)
      dimension X_sumQ(3),X_sumP(3),f3(3)

      if(iPrnt.ge.4) write(10,'(a,i5,a,5x,3(1x,f10.5))')
     &           '>>>>>>>>>> doing ind. forces from L=',L,'-charge at ',
     ,               (R_charge(L,i),i=1,3)
c
c[1].............. direct contibution to all forces from the given Q,P-charges
c                  associated with the charge L (the current one)
c
      if(iPrnt.ge.4) write(10,'(/a/)')
     &  '............ direct contribution to all charges .............'
      do 10 Nch=1,N_add_charges
         if(iFlagF(Nch).eq.0) go to 10
         do i=1,3
            R_ch(i)=R_charge(Nch,i)
         end do

c__________ if Quantum Cluster is on (do_QMC=.true.), check if L belongs
c           to the QMC and therefore if Nch also does or not. 
         isign=1
         if(do_QMC) then
            if(iFlagQMC(Nch).ne.iFlagQMC(L)) go to 10
            if(iFlagQMC(Nch).eq.1) isign=-1
         end if
         
c__________  calculate the contribution to the force on Nch due to 
c            current charge L

         call deriv_fi1(R_ch,Fi1,iPrnt)
         do i=1,3
            f1(i)=isign*Charges(Nch)*Fi1(i)
            Force(Nch,i)=Force(Nch,i)+f1(i)
         end do
         if(iPrnt.ge.4) write(10,'(a,i5,5x,3(1x,e12.6))') 
     &                              'f1 from Nch=',Nch,(f1(i),i=1,3) 
 10   continue
c
 50   if(iPrnt.ge.4) then
         write(10,'(/a,i5/)') '>>>>> final forces after this atom L=',L
         do Nch=1,N_add_charges
            write(10,'(i5,5x,3(1x,e12.6))') Nch,(Force(Nch,i),i=1,3)
         end do
      end if
      return
      end

      subroutine deriv_fi1(R_ch,Fi1,iPrnt)
c............................................................................
c Fi1(xyz) - derivative at the point R_ch(xyz) of the induced potential 
c            arising due to the current polarising charge
c............................................................................
c Mind: since we are using the final image charges, then the force Fi1 
c       is already multiplied on the value of the polarising charge
c............................................................................
c Mind: this force is due to the current added charge for which all the data 
c       is currently available in 
c              common/image_charges/   
c       (see images.inc).
c............................................................................
      implicit real*8 (a-h,o-z)
      include 'images.inc'
      dimension R_ch(3),Fi1(3),Fi1Q(3),Fi1P(3)
      dimension r(3),e(3),r1(3),e1(3)

      if(iPrnt.ge.4) write(10,'(a,3(1x,f10.5))') 
     &             '>>>>> deriv_fi1: R_charge= ',(R_ch(i),i=1,3)
c
c........... if only sphere is present
c
      if(.not.do_plane) then
         do i=1,3
            r(i)=R_ch(i)-R_imQ(1,i)
         end do
         call e_vector(r,e,d)
         do i=1,3
            Fi1(i)=Q_image(1)*e(i)
         end do
         go to 10
      end if

c........... if only plane is present, there is only one contribution 
c            from the P0-charge
      
      if(.not.do_sphere) then
         do i=1,3
            r(i)=R_ch(i)-R_imP(0,i)
         end do
         call e_vector(r,e,d)
         do i=1,3
            Fi1(i)=P_image(0)*e(i)
         end do
         goto 10
      end if
c     
c________ contribution from the direct image in the plane of the current 
c         added charge
      do i=1,3
        r(i)=R_ch(i)-R_imP(0,i)
      end do
      call e_vector(r,e,d)
      do i=1,3
        Fi1(i)=e(i)*P_image(0)
        Fi1Q(i)=0.0d00
        Fi1P(i)=0.0d00
      end do
c
c...................... contribution from the Q,P-charges
c
      do k=1,NumberQP
        j=k+NumberQP

c_____________________ contribution from the Q-charges
        do i=1,3
         r(i)=R_ch(i)-R_imQ(k,i)
         r1(i)=R_ch(i)-R_imQ(j,i)
        end do
        call e_vector(r,e,d)
        call e_vector(r1,e1,d1)
        do i=1,3
          Fi1Q(i)=Fi1Q(i)+Q_image(k)*(e(i)-e1(i))
        end do

c_____________________ contribution from the P-charges
        do i=1,3
         r(i)=R_ch(i)-R_imP(k,i)
         r1(i)=R_ch(i)-R_imP(j,i)
        end do
        call e_vector(r,e,d)
        call e_vector(r1,e1,d1)
        do i=1,3
          Fi1P(i)=Fi1P(i)+P_image(k)*(e(i)-e1(i))
        end do

      end do
c
c............ gathering all contributions together
c
      do i=1,3
        Fi1(i)=Fi1(i)+Fi1Q(i)+Fi1P(i)
      end do
 10   if(iPrnt.ge.4) write(10,'(a,3(1x,e12.6))') 
     &                          ' Fi1= ',(Fi1(j),j=1,3)
      return
      end

      subroutine e_vector(r,e,d)
      implicit real*8 (a-h,o-z)
c      implicit double precision (a-h,o-z)
      dimension r(3),e(3)
      data tiny/0.001d00/
      r2=r(1)*r(1)+r(2)*r(2)+r(3)*r(3)
      d=sqrt(r2)
      if(d.lt.tiny) then
        write(*,*)'FATAL in e_vector: d=',d
        stop
      end if
      r3=r2*d
        e(1)=r(1)/r3
        e(2)=r(2)/r3
        e(3)=r(3)/r3
      return
      end

