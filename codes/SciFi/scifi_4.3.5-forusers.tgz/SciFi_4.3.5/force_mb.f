      subroutine diag_force(iPrnt)
c.............................................................
c     function that calculates the gradient at each atom     .
c     in the molecule for the diagonal energy terms          .
c.............................................................
      include 'shell.inc'

c_____temporary variables to increase clarity
      double precision length,bgradx,bgrady,bgradz
      double precision angle,agrad1,agrad2,agrad3
      double precision torsion,tgrad1,tgrad2,tgrad3,tgrad4
      double precision ograd1,ograd2,ograd3,ograd4
      double precision angle_12,angle_23
      double precision e_by_dtheta
      double precision e_by_dphi
      double precision e_by_dchi
c_____temporary vectors to increase clarity
      double precision xa,ya,za,xb,yb,zb,xc,yc,zc
      double precision mod_a,mod_b,mod_c,mod_ab,mod_cb

c.....bond forces
      do i=1,n_b

         length=bond_l(x(nbond(i,1)),y(nbond(i,1)),z(nbond(i,1)),
     &        x(nbond(i,2)),y(nbond(i,2)),z(nbond(i,2)))
         
c.....gradient in the x direction

c_____calculating the ith bond contribution to the gradient
c_____of the two atoms involved in the bond

         bgradx=2*pbond(i,2)*(length-pbond(i,1))*(x(nbond(i,1)) - 
     &        x(nbond(i,2)))/length

         fx(nbond(i,1))=fx(nbond(i,1)) + bgradx
         fx(nbond(i,2))=fx(nbond(i,2)) - bgradx

c.....gradient in the y direction

c_____calculating the ith bond contribution to the gradient
c_____of the two atoms involved in the bond

         bgrady=2*pbond(i,2)*(length-pbond(i,1))*(y(nbond(i,1)) - 
     &        y(nbond(i,2)))/length

         fy(nbond(i,1))=fy(nbond(i,1)) + bgrady
         fy(nbond(i,2))=fy(nbond(i,2)) - bgrady         

c.....gradient in the z direction

c_____calculating the ith bond contribution to the gradient
c_____of the two atoms involved in the bond

         bgradz=2*pbond(i,2)*(length-pbond(i,1))*(z(nbond(i,1)) - 
     &        z(nbond(i,2)))/length

         fz(nbond(i,1))=fz(nbond(i,1)) + bgradz
         fz(nbond(i,2))=fz(nbond(i,2)) - bgradz

      end do

c.....angle forces

      do i=1,n_a

c_____calculating angle

         angle=angle_theta(x(nangle(i,1)),y(nangle(i,1)),z(nangle(i,1)),
     &        x(nangle(i,2)),y(nangle(i,2)),z(nangle(i,2)),
     &        x(nangle(i,3)),y(nangle(i,3)),z(nangle(i,3)))

c_____calculating vectors and magnitudes from the central 
c_____atom to angle forming atoms

         xa=x(nangle(i,1))-x(nangle(i,2))
         ya=y(nangle(i,1))-y(nangle(i,2))
         za=z(nangle(i,1))-z(nangle(i,2))

         xb=x(nangle(i,3))-x(nangle(i,2))
         yb=y(nangle(i,3))-y(nangle(i,2))
         zb=z(nangle(i,3))-z(nangle(i,2))

         mod_a=sqrt(xa*xa + ya*ya + za*za)
         mod_b=sqrt(xb*xb + yb*yb + zb*zb)

         e_by_dtheta=-2*pangle(i,2)*(angle-radians(pangle(i,1)))
     &        /sin(angle)

c.....gradient in the x direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         agrad1=e_by_dtheta*((xb/(mod_a*mod_b))-(cos(angle)*xa/
     &        (mod_a*mod_a)))

         agrad3=e_by_dtheta*((xa/(mod_a*mod_b))-(cos(angle)*xb/
     &        (mod_b*mod_b)))

         fx(nangle(i,1))=fx(nangle(i,1)) + agrad1
         fx(nangle(i,2))=fx(nangle(i,2)) - agrad1 - agrad3   
         fx(nangle(i,3))=fx(nangle(i,3)) + agrad3  

c.....gradient in the y direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         agrad1=e_by_dtheta*((yb/(mod_a*mod_b))-(cos(angle)*ya/
     &        (mod_a*mod_a)))

         agrad3=e_by_dtheta*((ya/(mod_a*mod_b))-(cos(angle)*yb/
     &        (mod_b*mod_b)))

         fy(nangle(i,1))=fy(nangle(i,1)) + agrad1
         fy(nangle(i,2))=fy(nangle(i,2)) - agrad1 - agrad3  
         fy(nangle(i,3))=fy(nangle(i,3)) + agrad3  

c.....gradient in the z direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         agrad1=e_by_dtheta*((zb/(mod_a*mod_b))-(cos(angle)*za/
     &        (mod_a*mod_a)))

         agrad3=e_by_dtheta*((za/(mod_a*mod_b))-(cos(angle)*zb/
     &        (mod_b*mod_b)))

         fz(nangle(i,1))=fz(nangle(i,1)) + agrad1
         fz(nangle(i,2))=fz(nangle(i,2)) - agrad1 - agrad3  
         fz(nangle(i,3))=fz(nangle(i,3)) + agrad3  

      end do

c.....torsion forces

      do i=1,n_t

         torsion=torsion_phi(x(ntorsion(i,1)),y(ntorsion(i,1)),
     &        z(ntorsion(i,1)),
     &        x(ntorsion(i,2)),y(ntorsion(i,2)),z(ntorsion(i,2)),
     &        x(ntorsion(i,3)),y(ntorsion(i,3)),z(ntorsion(i,3)),
     &        x(ntorsion(i,4)),y(ntorsion(i,4)),z(ntorsion(i,4)))
         
c.....calculating vectors and magnitudes of vectors that make up
c.....the torsion
      
         xa=x(ntorsion(i,1))-x(ntorsion(i,2))
         ya=y(ntorsion(i,1))-y(ntorsion(i,2))
         za=z(ntorsion(i,1))-z(ntorsion(i,2))

         xb=x(ntorsion(i,3))-x(ntorsion(i,2))
         yb=y(ntorsion(i,3))-y(ntorsion(i,2))
         zb=z(ntorsion(i,3))-z(ntorsion(i,2))

         xc=x(ntorsion(i,3))-x(ntorsion(i,4))
         yc=y(ntorsion(i,3))-y(ntorsion(i,4))
         zc=z(ntorsion(i,3))-z(ntorsion(i,4))

         mod_a=sqrt(xa*xa + ya*ya + za*za)
         mod_b=sqrt(xb*xb + yb*yb + zb*zb)
         mod_c=sqrt(xc*xc + yc*yc + zc*zc)

c_____and the cross product modului

         mod_ab=sqrt((ya*zb-za*yb)**2+(za*xb-xa*zb)**2+(xa*yb-ya*xb)**2)
         mod_cb=sqrt((yc*zb-zc*yb)**2+(zc*xb-xc*zb)**2+(xc*yb-yc*xb)**2)

c_____and the two three body angles

         angle_12=angle_theta(x(ntorsion(i,1)),y(ntorsion(i,1)),
     &        z(ntorsion(i,1)),
     &        x(ntorsion(i,2)),y(ntorsion(i,2)),z(ntorsion(i,2)),
     &        x(ntorsion(i,3)),y(ntorsion(i,3)),z(ntorsion(i,3)))
         angle_23=angle_theta(x(ntorsion(i,2)),y(ntorsion(i,2)),
     &        z(ntorsion(i,2)),
     &        x(ntorsion(i,3)),y(ntorsion(i,3)),z(ntorsion(i,3)),
     &        x(ntorsion(i,4)),y(ntorsion(i,4)),z(ntorsion(i,4)))

c.....calculating the derivative of energy with respect to torsion angle

         e_by_dphi=(ptorsion(i,2)*ptorsion(i,1)*sin((ptorsion(i,2)*
     &        torsion) - radians(ptorsion(i,3))))

c.....gradient in the x direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         tgrad1=e_by_dphi*((ya*zb-za*yb)/(mod_a*mod_ab*sin(angle_12)))

         tgrad2=e_by_dphi*(-1)*
     &        ((((ya*zb-za*yb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12)))) + (cos(angle_23)*
     &        ((yc*zb-zc*yb)/(mod_cb*mod_b*sin(angle_23)))))

         tgrad3=e_by_dphi*(-1)*
     &        (((yc*zb-zc*yb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((ya*zb-za*yb)/(mod_ab*mod_b*sin(angle_12))))

         tgrad4=e_by_dphi*((yc*zb-zc*yb)/(mod_c*mod_cb*sin(angle_23)))

         fx(ntorsion(i,1))=fx(ntorsion(i,1)) + tgrad1
         fx(ntorsion(i,2))=fx(ntorsion(i,2)) + tgrad2
         fx(ntorsion(i,3))=fx(ntorsion(i,3)) + tgrad3
         fx(ntorsion(i,4))=fx(ntorsion(i,4)) + tgrad4

c.....gradient in the y direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         tgrad1=e_by_dphi*((za*xb-xa*zb)/(mod_a*mod_ab*sin(angle_12)))

         tgrad2=e_by_dphi*(-1)*
     &        (((za*xb-xa*zb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((zc*xb-xc*zb)/(mod_cb*mod_b*sin(angle_23))))

         tgrad3=e_by_dphi*(-1)*
     &        (((zc*xb-xc*zb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((za*xb-xa*zb)/(mod_ab*mod_b*sin(angle_12))))

         tgrad4=e_by_dphi*((zc*xb-xc*zb)/(mod_c*mod_cb*sin(angle_23)))

         fy(ntorsion(i,1))=fy(ntorsion(i,1)) + tgrad1
         fy(ntorsion(i,2))=fy(ntorsion(i,2)) + tgrad2  
         fy(ntorsion(i,3))=fy(ntorsion(i,3)) + tgrad3
         fy(ntorsion(i,4))=fy(ntorsion(i,4)) + tgrad4

c.....gradient in the z direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         tgrad1=e_by_dphi*((xa*yb-ya*xb)/(mod_a*mod_ab*sin(angle_12)))

         tgrad2=e_by_dphi*(-1)*
     &        (((xa*yb-ya*xb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((xc*yb-yc*xb)/(mod_cb*mod_b*sin(angle_23))))

         tgrad3=e_by_dphi*(-1)*
     &        (((xc*yb-yc*xb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((xa*yb-ya*xb)/(mod_ab*mod_b*sin(angle_12))))

         tgrad4=e_by_dphi*((xc*yb-yc*xb)/(mod_c*mod_cb*sin(angle_23)))

         fz(ntorsion(i,1))=fz(ntorsion(i,1)) + tgrad1
         fz(ntorsion(i,2))=fz(ntorsion(i,2)) + tgrad2  
         fz(ntorsion(i,3))=fz(ntorsion(i,3)) + tgrad3
         fz(ntorsion(i,4))=fz(ntorsion(i,4)) + tgrad4

      end do

c.....out-of-plane forces

      do i=1,n_o

c.....calculating vectors for out of plane angle

         oop=oop_chi(x(noop(i,1)),y(noop(i,1)),z(noop(i,1)),
     &        x(noop(i,2)),y(noop(i,2)),z(noop(i,2)),
     &        x(noop(i,3)),y(noop(i,3)),z(noop(i,3)),
     &        x(noop(i,4)),y(noop(i,4)),z(noop(i,4)))

c.....calculating vectors and magnitudes of vectors that make up
c.....the torsion
      
         xa=x(noop(i,1))-x(noop(i,3))
         ya=y(noop(i,1))-y(noop(i,3))
         za=z(noop(i,1))-z(noop(i,3))

         xb=x(noop(i,4))-x(noop(i,3))
         yb=y(noop(i,4))-y(noop(i,3))
         zb=z(noop(i,4))-z(noop(i,3))

         xc=x(noop(i,4))-x(noop(i,2))
         yc=y(noop(i,4))-y(noop(i,2))
         zc=z(noop(i,4))-z(noop(i,2))


         mod_a=sqrt(xa*xa + ya*ya + za*za)
         mod_b=sqrt(xb*xb + yb*yb + zb*zb)
         mod_c=sqrt(xc*xc + yc*yc + zc*zc)

c_____and the cross product modului

         mod_ab=sqrt((ya*zb-za*yb)**2+(za*xb-xa*zb)**2+(xa*yb-ya*xb)**2)
         mod_cb=sqrt((yc*zb-zc*yb)**2+(zc*xb-xc*zb)**2+(xc*yb-yc*xb)**2)

c_____and the two three body angles

         angle_12=angle_theta(x(noop(i,1)),y(noop(i,1)),
     &        z(noop(i,1)),
     &        x(noop(i,3)),y(noop(i,3)),z(noop(i,3)),
     &        x(noop(i,4)),y(noop(i,4)),z(noop(i,4)))
         angle_23=angle_theta(x(noop(i,3)),y(noop(i,3)),
     &        z(noop(i,3)),
     &        x(noop(i,4)),y(noop(i,4)),z(noop(i,4)),
     &        x(noop(i,2)),y(noop(i,2)),z(noop(i,2)))

c.....calculating the derivative of energy with respect to oop angle

         e_by_dchi=(poop(i,2)*poop(i,1)*sin((poop(i,2)*
     &        oop) - radians(poop(i,3))))

c.....gradient in the x direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         ograd1=e_by_dchi*((ya*zb-za*yb)/(mod_a*mod_ab*sin(angle_12)))

         ograd2=e_by_dchi*(-1)*
     &        ((((ya*zb-za*yb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12)))) + (cos(angle_23)*
     &        ((yc*zb-zc*yb)/(mod_cb*mod_b*sin(angle_23)))))

         ograd3=e_by_dchi*(-1)*
     &        (((yc*zb-zc*yb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((ya*zb-za*yb)/(mod_ab*mod_b*sin(angle_12))))

         ograd4=e_by_dchi*((yc*zb-zc*yb)/(mod_c*mod_cb*sin(angle_23)))

         fx(noop(i,1))=fx(noop(i,1)) + ograd1
         fx(noop(i,3))=fx(noop(i,3)) + ograd2
         fx(noop(i,4))=fx(noop(i,4)) + ograd3
         fx(noop(i,2))=fx(noop(i,2)) + ograd4

c.....gradient in the y direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         ograd1=e_by_dchi*((za*xb-xa*zb)/(mod_a*mod_ab*sin(angle_12)))

         ograd2=e_by_dchi*(-1)*
     &        (((za*xb-xa*zb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((zc*xb-xc*zb)/(mod_cb*mod_b*sin(angle_23))))

         ograd3=e_by_dchi*(-1)*
     &        (((zc*xb-xc*zb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((za*xb-xa*zb)/(mod_ab*mod_b*sin(angle_12))))

         ograd4=e_by_dchi*((zc*xb-xc*zb)/(mod_c*mod_cb*sin(angle_23)))

         fy(noop(i,1))=fy(noop(i,1)) + ograd1
         fy(noop(i,3))=fy(noop(i,3)) + ograd2  
         fy(noop(i,4))=fy(noop(i,4)) + ograd3
         fy(noop(i,2))=fy(noop(i,2)) + ograd4

c.....gradient in the z direction

c_____calculating the ith angle contribution to the gradient
c_____of the three angles involved in the bond

         ograd1=e_by_dchi*((xa*yb-ya*xb)/(mod_a*mod_ab*sin(angle_12)))

         ograd2=e_by_dchi*(-1)*
     &        (((xa*yb-ya*xb)/mod_ab)*((mod_b-mod_a*cos(angle_12))/
     &        (mod_a*mod_b*sin(angle_12))) + cos(angle_23)*
     &        ((xc*yb-yc*xb)/(mod_cb*mod_b*sin(angle_23))))

         ograd3=e_by_dchi*(-1)*
     &        (((xc*yb-yc*xb)/mod_cb)*((mod_b-mod_c*cos(angle_23))/
     &        (mod_c*mod_b*sin(angle_23))) + cos(angle_12)*
     &        ((xa*yb-ya*xb)/(mod_ab*mod_b*sin(angle_12))))

         ograd4=e_by_dchi*((xc*yb-yc*xb)/(mod_c*mod_cb*sin(angle_23)))

         fz(noop(i,1))=fz(noop(i,1)) + ograd1
         fz(noop(i,3))=fz(noop(i,3)) + ograd2  
         fz(noop(i,4))=fz(noop(i,4)) + ograd3
         fz(noop(i,2))=fz(noop(i,2)) + ograd4
      end do

      end
