      subroutine nve_vl(sh_temp)
c......................................................................
c     verlet leapfrog integration algorithm that samples the nve or   .
c     microcanonical ensemble - the velocity is supplied at timestep  .
c     n-1/2 and the atomic coordinates and forces at timestep n.      .
c     The velocity is then returned at timestep n+1/2 and the         .
c     atomic coordinates at timestep n+1                              .
c                                                                     .
c     If velocities at timestep n are required for analysis  the v?1  .
c     and ??1 vectors will return the velocities and positions at     .
c     timestep n                                                      .
c                                                                     .
c     NOTE: this subroutine uses grandients (=-force)                 .
c......................................................................
      include 'shell.inc'

      double precision vx1(N0CH),vy1(N0CH),vz1(N0CH)
      double precision v_cm_x,v_cm_y,v_cm_z,sh_temp
      temp = 0.0
      sh_temp = 0.0

      do i=1,Ncharge
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx1(i) = vx(i)
            vy1(i) = vy(i)
            vz1(i) = vz(i)
         end if
      end do

c-----calculating new positions and velocities

c_________ md2_unit converts (F*t/m) from (a.u.force * fs/a.u.m) 
c          into (a.u.length/fs)

      tstep1=tstep * md2_unit

      do i=1,Ncharge
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = vx(i) - fx(i)*tstep1/pmass(i)
            vy(i) = vy(i) - fy(i)*tstep1/pmass(i)
            vz(i) = vz(i) - fz(i)*tstep1/pmass(i)
            x(i) = x(i) + vx(i)*tstep
            y(i) = y(i) + vy(i)*tstep
            z(i) = z(i) + vz(i)*tstep
         end if
      end do

c-----scaling core-shell kinetic energies to 1K

c      do i=1,Natom
c         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
c            if(Shell_Ref(ISRT(i))) then 
c               j = iShell(i)
c               rmu = pmass(i)*pmass(j)/(pmass(i)+pmass(j))
c               dvx = vx(j) - vx(i)
c               dvy = vy(j) - vy(i)
c               dvz = vz(j) - vz(i)
c               scl = sqrt((PRM_KB*dtemp*0.0001)/
c     &              (rmu*(dvx**2+dvy**2+dvz**2)))
c               tmx = pmass(i)*vx(i) + pmass(j)*vx(j)
c               tmy = pmass(i)*vy(i) + pmass(j)*vy(j)               
c               tmz = pmass(i)*vz(i) + pmass(j)*vz(j)
c               vx(i) = tmx/(pmass(i)+pmass(j)) - scl*rmu*dvx/pmass(i)
c               vx(j) = tmx/(pmass(i)+pmass(j)) + scl*rmu*dvx/pmass(j)
c               vy(i) = tmy/(pmass(i)+pmass(j)) - scl*rmu*dvy/pmass(i)
c               vy(j) = tmy/(pmass(i)+pmass(j)) + scl*rmu*dvy/pmass(j)
c               vz(i) = tmz/(pmass(i)+pmass(j)) - scl*rmu*dvz/pmass(i)
c               vz(j) = tmz/(pmass(i)+pmass(j)) + scl*rmu*dvz/pmass(j)
c            end if
c         end if
c      end do

c-----interpelating velocities for timestep n
c     and calculating temperature for timestep n

c     if there are shells, then calculate the temperature
c     of the centre of mass of the shell-core pairs

      do i=1,Ncharge
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx1(i) = 0.5 * (vx(i) + vx1(i))
            vy1(i) = 0.5 * (vy(i) + vy1(i))
            vz1(i) = 0.5 * (vz(i) + vz1(i))
         end if
      end do

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            if(Shell_Ref(ISRT(i)).and. dshell_model.eq.0) then 
               j = iShell(i)
               v_cm_x = (vx1(i)*pmass(i) + vx1(j)*pmass(j))
     &              /(pmass(i)+pmass(j))
               v_cm_y = (vy1(i)*pmass(i) + vy1(j)*pmass(j))
     &              /(pmass(i)+pmass(j))
               v_cm_z = (vz1(i)*pmass(i) + vz1(j)*pmass(j))
     &              /(pmass(i)+pmass(j))

               temp = temp + (pmass(i) + pmass(j))*
     &           (v_cm_x*v_cm_x + v_cm_y*v_cm_y + v_cm_z*v_cm_z)/
     &           (PRM_KB * 3 * non_frozen) * md3_unit
c-----calculating the temperature of the cores and shells relative 
c     to their respective centres of mass
               sh_temp = sh_temp + (pmass(i)*
     &     ((v_cm_x-vx1(i))**2+(v_cm_y-vy1(i))**2+(v_cm_z-vz1(i))**2)
     &              + pmass(j)*
     &     ((v_cm_x-vx1(j))**2+(v_cm_y-vy1(j))**2+(v_cm_z-vz1(j))**2))
     &              /(PRM_KB * 3 * non_frozen) * md3_unit
c               temp = temp + (pmass(i)*
c     &           (vx1(i)*vx1(i) + vy1(i)*vy1(i) + vz1(i)*vz1(i))/
c     &           (PRM_KB * 3 * non_frozen))
c               temp = temp + (pmass(j)*
c     &           (vx1(j)*vx1(j) + vy1(j)*vy1(j) + vz1(j)*vz1(j))/
c     &           (PRM_KB * 3 * non_frozen))
            else               
               temp = temp + (pmass(i)*
     &           (vx1(i)*vx1(i) + vy1(i)*vy1(i) + vz1(i)*vz1(i))/
     &           (PRM_KB * 3 * non_frozen)) * md3_unit
            end if
         end if
      end do

      end

      subroutine nvt_gauss()
c.....................................................................
c     differential temperature control integertion alogorithm        .
c     (evans thermostat)                                             .
c                                                                    .
c     subroutine that integrates the equations of motion with        .
c     gaussian constraints - sampling the canonical ensemble to      .
c     within O(1/N^0.5)                                              .
c                                                                    .
c   Evans D.J, Morriss G.P, 1984, Computer Physics Reports, v.1,297  .
c   Brown D, Clarke J.H.R, 1984, Molecular Physics, v.51,1243        .
c.....................................................................
      include 'shell.inc'
      double precision factor,vxt,vyt,vzt
      double precision vx1(N0LT),vy1(N0LT),vz1(N0LT)

      temp = 0.0

      do i=1,Natom
         vx1(i) = vx(i)
         vy1(i) = vy(i)
         vz1(i) = vz(i)
      end do

c-----estimating the teperature using verlet half leap

c_________ md2_unit converts (F*t/m) from (a.u.force * fs/a.u.m) 
c          into (a.u.length/fs)

      tstep1=tstep * md2_unit
      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vxt = vx(i) - tstep1*fx(i)/pmass(i) * 0.5
            vyt = vy(i) - tstep1*fy(i)/pmass(i) * 0.5
            vzt = vz(i) - tstep1*fz(i)/pmass(i) * 0.5
            temp = temp + pmass(i)*(vxt**2+vyt**2+vzt**2)/
     &           (PRM_KB * 3 * non_frozen) * md3_unit
         end if
      end do
      factor = sqrt(dtemp / temp)

c-----calculating new positions and velocities

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = (2*factor-1)*vx(i) - factor*fx(i)*tstep1/pmass(i)
            vy(i) = (2*factor-1)*vy(i) - factor*fy(i)*tstep1/pmass(i)
            vz(i) = (2*factor-1)*vz(i) - factor*fz(i)*tstep1/pmass(i)
            x(i) = x(i) + vx(i)*tstep
            y(i) = y(i) + vy(i)*tstep
            z(i) = z(i) + vz(i)*tstep
         end if
      end do

c-----interpelating velocities for timestep n
c     and calculating temperature for timestep n

      temp = 0.0
      do i=1,Natom
         vx1(i) = 0.5 * (vx(i) + vx1(i))
         vy1(i) = 0.5 * (vy(i) + vy1(i))
         vz1(i) = 0.5 * (vz(i) + vz1(i))
         temp = temp + (pmass(i) *
     &        (vx1(i)*vx1(i) + vy1(i)*vy1(i) + vz1(i)*vz1(i)) /
     &        (PRM_KB * 3 * non_frozen)) * md3_unit
      end do
      end

      subroutine nvt_ber()
c......................................................................
c     proportaional temperature control integeration algorithm        .
c     (berensden thermostat)                                          .
c......................................................................
      include 'shell.inc'
      double precision vxt,vyt,vzt
      double precision vx1(N0LT),vy1(N0LT),vz1(N0LT)
      double precision chi

      temp = 0.0

c-----puting old phase coordinates into old arrays

      do i=1,Natom
         vx1(i) = vx(i)
         vy1(i) = vy(i)
         vz1(i) = vz(i)
      end do

c-----estimating current temperture using verlet half leap

c_________ md2_unit converts (F*t/m) from (a.u.force * fs/a.u.m) 
c          into (a.u.length/fs)

      tstep1=tstep * md2_unit
      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vxt = vx(i) - tstep1*fx(i)/pmass(i) * 0.5
            vyt = vy(i) - tstep1*fy(i)/pmass(i) * 0.5
            vzt = vz(i) - tstep1*fz(i)/pmass(i) * 0.5
            temp = temp + pmass(i)*(vxt**2+vyt**2+vzt**2)/
     &           (PRM_KB * 3 * non_frozen) * md3_unit
         end if
      end do

      chi = sqrt(1 + (tstep/tau)*(dtemp/temp - 1))

c-----calculating new positions and velocities

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = chi*(vx(i) - fx(i)*tstep1/pmass(i))
            vy(i) = chi*(vy(i) - fy(i)*tstep1/pmass(i))
            vz(i) = chi*(vz(i) - fz(i)*tstep1/pmass(i))
            x(i) = x(i) + vx(i)*tstep
            y(i) = y(i) + vy(i)*tstep
            z(i) = z(i) + vz(i)*tstep
         end if
      end do

c-----interpelating velocities for timestep n
c     and calculating actual temperature for timestep n

      temp = 0.0
      do i=1,Natom
         vx1(i) = 0.5 * (vx(i) + vx1(i))
         vy1(i) = 0.5 * (vy(i) + vy1(i))
         vz1(i) = 0.5 * (vz(i) + vz1(i))
         temp = temp + (pmass(i) *
     &        (vx1(i)*vx1(i) + vy1(i)*vy1(i) + vz1(i)*vz1(i)) /
     &       (PRM_KB * 3 * non_frozen)) * md3_unit
      end do
      end

      subroutine nvt_hover(chi)
c......................................................................
c     integral temperature control integeration algorithm             .
c     (noose-hoover thermostat)                                       .
c......................................................................
      include 'shell.inc'
      double precision vx1(N0LT),vy1(N0LT),vz1(N0LT)
      double precision ux(N0LT),uy(N0LT),uz(N0LT)
      double precision vxt,vyt,vzt
      double precision chi
      double precision chi1,chit
      integer sc_iter

      sc_iter = 2
      temp = 0.0

c-----putting the old value of chi into the old-chi variable

      chi1 = chi

c-----putting old phase coordinates into old arrays

      do i=1,Natom
         vx1(i) = vx(i)
         vy1(i) = vy(i)
         vz1(i) = vz(i)
      end do

c-----estimating current temperature using verlet half leap;
c     velocities at timestep n are stored in the u (i) arrays

c_________ md2_unit converts (F*t/m) from (a.u.force * fs/a.u.m) 
c          into (a.u.length/fs)

      tstep1=tstep * md2_unit
      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            ux(i) = vx(i) - tstep1*fx(i)/pmass(i) * 0.5
            uy(i) = vy(i) - tstep1*fy(i)/pmass(i) * 0.5
            uz(i) = vz(i) - tstep1*fz(i)/pmass(i) * 0.5
            temp = temp + pmass(i)*(ux(i)**2+uy(i)**2+uz(i)**2)/
     &           (PRM_KB * 3 * non_frozen) * md3_unit
         end if
      end do

c-----iterate to obtain self-consistency
c..............................................................

      do iii=1,sc_iter
c-----calculating chi at n+1/2 timesteps
         chi = chi1 + (tstep/tau**2)*(temp/dtemp - 1)
c-----calculating chi at n timesteps
         chit = 0.5*(chi + chi1)
         temp = 0.0
c-----calculating new estimates of velocities at n
         do i=1,Natom
            if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
               ux(i)= vx(i) + tstep*( -fx(i)/pmass(i)*md2_unit -
     -                                               chit*ux(i) )*0.5
               uy(i)= vy(i) + tstep*( -fy(i)/pmass(i)*md2_unit -
     -                                               chit*uy(i) )*0.5
               uz(i)= vz(i) + tstep*( -fz(i)/pmass(i)*md2_unit -
     -                                               chit*uz(i) )*0.5
               temp = temp + (pmass(i) *
     &              (ux(i)*ux(i) + uy(i)*uy(i) + uz(i)*uz(i))/
     &              (PRM_KB * 3 * non_frozen)) * md3_unit
            end if
         end do
      end do
c...................................................................

c-----calculating chi at n+1/2 timesteps
      chi = chi1 + (tstep/tau**2)*(temp/dtemp - 1)
c-----calculating chi at n timesteps
      chit = 0.5*(chi + chi1)
c-----calculating new final velocities and positions
      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx(i) = vx(i) + tstep*(-fx(i)/pmass(i)*md2_unit-chit*ux(i))
            vy(i) = vy(i) + tstep*(-fy(i)/pmass(i)*md2_unit-chit*uy(i))
            vz(i) = vz(i) + tstep*(-fz(i)/pmass(i)*md2_unit-chit*uz(i))         
            x(i) = x(i) + vx(i)*tstep
            y(i) = y(i) + vy(i)*tstep
            z(i) = z(i) + vz(i)*tstep   
         end if     
      end do
c-----interpelating actual velocities for timestep n
c     and calculating actual temperature for timestep n
      temp = 0.0
      do i=1,Natom
         vx1(i) = 0.5 * (vx(i) + vx1(i))
         vy1(i) = 0.5 * (vy(i) + vy1(i))
         vz1(i) = 0.5 * (vz(i) + vz1(i))
         temp = temp + (pmass(i) *
     &        (vx1(i)*vx1(i) + vy1(i)*vy1(i) + vz1(i)*vz1(i)) /
     &        (PRM_KB * 3 * non_frozen)) * md3_unit
      end do
      return
      end

      subroutine nve_stoc()
c......................................................................
c     verlet leapfrog algothim that integrate the equations of motion .
c     according to the nve ensemble for a subset of the atoms and     .
c     according to an nvt stochastic thermostat for the remainder.    .
c                                                                     .
c     the stoc(i) array lists which atoms are subjected to a random   .
c     force and friction coefficient.                                 .
c                                                                     .
c     the temperature calculated by this algorithm is that of the     .
c     nve region only.                                                .
c......................................................................
      include 'shell.inc'

      double precision vx1(N0CH),vy1(N0CH),vz1(N0CH)
      double precision rsq_x,rsq_y,rsq_z,f_s_x,f_s_y,f_s_z
      integer n_temp
      n_temp = 0
      n_stoc = 0
      temp = 0.0

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
            vx1(i) = vx(i)
            vy1(i) = vy(i)
            vz1(i) = vz(i)
         end if
      end do

c-----calculating new positions and velocities for nve


c_________ md2_unit converts (F*t/m) from (a.u.force * fs/a.u.m) 
c          into (a.u.length/fs)

      tstep1=tstep * md2_unit
      do i=1,Natom
         if(stoc(i).eq.0 .and. iRx(i).eq.1 .and. iRy(i).eq.1 .and.
     &        iRz(i).eq.1) then
            vx(i) = vx(i) - fx(i)*tstep1/pmass(i)
            vy(i) = vy(i) - fy(i)*tstep1/pmass(i)
            vz(i) = vz(i) - fz(i)*tstep1/pmass(i)
            x(i) = x(i) + vx(i)*tstep
            y(i) = y(i) + vy(i)*tstep
            z(i) = z(i) + vz(i)*tstep
            n_temp = n_temp + 1
         else if(stoc(i).eq.1 .and. iRx(i).eq.1 .and. iRy(i).eq.1 .and.
     &              iRz(i).eq.1) then
c.....create random forces and friction forces based on
c     the velocity at minus half a timestep
            rsq_x = 2*pmass(i)*PRM_KB*dtemp*fricx(i)/tstep1
            rsq_y = 2*pmass(i)*PRM_KB*dtemp*fricy(i)/tstep1
            rsq_z = 2*pmass(i)*PRM_KB*dtemp*fricz(i)/tstep1
            f_s_x = -fricx(i)*pmass(i)*vx(i)/md2_unit + 
     +           gasdev(idum)*sqrt(rsq_x)
            f_s_y = -fricy(i)*pmass(i)*vy(i)/md2_unit + 
     +           gasdev(idum)*sqrt(rsq_y)
            f_s_z = -fricz(i)*pmass(i)*vz(i)/md2_unit + 
     +           gasdev(idum)*sqrt(rsq_z)
c.....integerate equations of motion with stochastic force
            vx(i) = vx(i) + ( -fx(i) + f_s_x )/pmass(i)*tstep1
            vy(i) = vy(i) + ( -fy(i) + f_s_y )/pmass(i)*tstep1
            vz(i) = vz(i) + ( -fz(i) + f_s_z )/pmass(i)*tstep1
            x(i) = x(i) + vx(i)*tstep
            y(i) = y(i) + vy(i)*tstep
            z(i) = z(i) + vz(i)*tstep
            n_temp = n_temp + 1
         end if
      end do

c-----interpelating velocities for timestep n
c     and calculating temperature for timestep n

      do i=1,Natom
         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
c         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1 .and. 
c     &        stoc(i).eq.0) then
            vx1(i) = 0.5 * (vx(i) + vx1(i))
            vy1(i) = 0.5 * (vy(i) + vy1(i))
            vz1(i) = 0.5 * (vz(i) + vz1(i))
            temp = temp + (pmass(i)*
     &           (vx1(i)*vx1(i) + vy1(i)*vy1(i) + vz1(i)*vz1(i))/
     &           (PRM_KB * 3 * n_temp)) * md3_unit
        end if
      end do
      end

c     The random number used in the 2.0 and newer releases of pghpf 
c     generates a 46 bit lagged fibonacci pseudo-random sequence with 
c     a short lag of 5 and a long lag of 17. For a given seed, including 
c     the default seed, the sequence generated is independent of the 
c     platform and number of processors. Due to limitations of some 
c     platforms' default integer type, the seed vector is of size 34. 
c     Only the least significant 23 bits of each element of the seed 
c     array are used, thus a seed array returned or used is portable 
c     between platforms. For non-degenerate seed arrays, the period of 
c     this generator is (2^17 - 1) * 2^45. If all the odd elements of the 
c     seed array are even, the period will be shorter.


      double precision function gasdev(idum)
c.......................................................................
c     returns a normally distributed deviate with zero mean and unit   .
c     variance                                                         .
c.......................................................................
       double precision value
       integer iset
       double precision fac,gset,rsq,v1,v2
       save iset,gset
       real ran2
       data iset/0/
       if(idum.lt.0) iset=0
       if(iset.eq.0) then
 1        v1 = 2.*ran2(idum) - 1.
          v2 = 2.*ran2(idum) - 1.
          rsq = v1**2 + v2**2
          if(rsq.ge.1..or.rsq.eq.0.) goto 1
          fac = sqrt(-2.*log(rsq)/rsq)
          gset = v1*fac
          gasdev = v2*fac
          iset = 1
       else
          gasdev = gset
          iset = 0
       end if
       return
       end


      function ran1(idum)
c.....................................................................
c     minimal random number geerator with Bays-Durham shuffle and    .
c     added safeguards. Returns a uniform deviate between 0.0 and    .
c     1.0 (exclusive of the endpoint values). Call with idum a       .
c     negative integer to initialise; thereafter, do not alter idum  .
c     between successive deviates in a sequence. RNMX should         .
c     approximate the largest floating value that is less than 1.    .
c.....................................................................
      integer idum,ia,im,iq,ir,ntab,ndiv
      real ran1,am,eps,rnmx
      parameter (ia=16807,im=2147483647,am=1./im,iq=127773,ir=2836,
     &     ntab=32,ndiv=1+(im-1)/ntab,eps=1.2e-7,rnmx=1.-eps)
      integer j,k,iv(ntab),iy
      save iv,iy
      data iv /ntab*0/, iy /0/
      if(idum.le.0.or.iy.eq.0) then
         idum = max(-idum,1)
         do j=ntab + 8,1,-1
            k = idum/iq
            idum = ia*(idum-k*iq)-ir*k
            if(idum.lt.0) idum = idum + im
            if(j.le.ntab) iv(j) = idum
         end do
         iy = iv(1)
      end if
      k = idum/iq
      idum = ia*(idum - k*iq)-ir*k
      if(idum.lt.0) idum = idum + im
      j = 1 + iy/ndiv
      iy = iv(j)
      iv(j) = idum
      ran1 = min(am*iy,rnmx)
      return
      end


      function ran2(idum)
      integer idum,im1,im2,imm1,ia1,ia2,iq1,iq2,ir1,ir2,ntab,ndiv
      real ran2,am,eps,rnmx
      parameter (im1=2147483563,im2=2147483399,am=1./im1,imm1=im1-1,
     &     ia1=40014,ia2=40692,iq1=53668,iq2=52774,ir1=12211,
     &     ir2=3791,ntab=32,ndiv=1+imm1/ntab,eps=1.2e-7,rnmx=1.-eps)
c.............................................................................
c     Long period (>2x10^18) random number generator of L'Ecyer with Bays-   .
c     Durham shuffle and add safeguards. Returns a uniform deviate between   .
c     0.0 and 1.0 (exculsive of the endpoint values). Call with idum a       .
c     negative integer to initialise; thereafter, do no alter idum between   .
c     successive deviates in a sequence. RNMX should approximate the largest .
c     floating value that is less than 1                                     .
c.............................................................................
      integer idum2,j,k,iv(ntab),iy
      save iv,iy,idum2
      data idum2/123456789/, iv/NTAB*0/, iy/0/
      if(idum.le.0) then
         idum=max(-idum,1)
         idum2=idum
         do 11 j=ntab+8,1,-1
            k=idum/iq1
            idum=ia1*(idum-k*iq1)-k*ir1
            if(idum.lt.0) idum=idum+im1
            if(j.le.ntab) iv(j)=idum
 11      end do
         iy=iv(1)
      end if
      k=idum/iq1
      idum=ia1*(idum-k*iq1)-k*ir1
      if(idum.lt.0) idum=idum+im1
      k=idum2/iq2
      idum2=ia2*(idum2-k*iq2)-k*ir2
      if(idum2.lt.0) idum2=idum2+im2
      j=1+iy/ndiv
      iy=iv(j)-idum2
      iv(j)=idum
      if(iy.lt.1) iy=iy+imm1
      ran2=min(am*iy,rnmx)
      return
      end
