      subroutine do_bfgs(p,energy_best,g,e_last_gain,iPrnt,imf)
c........................................................................
c BFGS: Variable Metric minimization ( numerical recepies )
c........................................................................
c n_dfree - Number of degrees of freedom to optimise
c i_lns_count - Number of line_search calls
c i_eng_count - Number of Total energy calculations
c___________ INPUT:
c p() - initial coordinates (in 1-dim representation)
c g() - initial gadients
c energy_best - initial energy
c___________ OUTPUT:
c g() - final gadients
c p() - final coordinates (in 1-dim representation)
c x,y,z - final coordinates (in common /work/)
c energy_best - final energy
c imf - coordinate number in 1-dim vector with the max force
c........................................................................
c xi(*) - direction of minimisation
c........................................................................
c stpmax - maximum step allowed (0.8 default; taken from input)
c........................................................................
      include 'shell.inc'

      include 'mpif.h'

      parameter ( eps = 3.d-8 )
      dimension g(max_free),dg(max_free),p(max_free),pnew(max_free)
      dimension xi(max_free),hdg(max_free)
      double precision, dimension(:,:), allocatable :: hessin
      logical check_eng,check_crd,check_frc,l_crd,l_frc,l_eng

c.......... allocate memory

      allocate(hessin(n_dfree,n_dfree),stat=iErr)
      if(iErr.ne.0) then
         if(nid.eq.0)
     & write(*,*)'FATAL! NOt enough memory available! Stop!'

                  call MPI_Abort(MPI_COMM_WORLD,-1,error)



      end if


c ----------------------------------------------------------------------
c ---- Initialise ----
c ----------------------------------------------------------------------

      i_lns_count = 0
      i_eng_count = 0
      energy_new = 0.d0
      opt_problems=.false.

c ___ number of degrees of freedom
      if(nid.eq.0) then
         write(*,'(a,i4)') ' bfgs: Degrees of freedom =',n_dfree
         write(9,'(a,i4)') ' bfgs: Degrees of freedom =',n_dfree
      end if

c ___ Print initial coordinates and gradients

      if(nid.eq.0.and.iPrnt.ge.10) then
         write(9,'(/a)') ' Initial P(oint) and G(radients) in bfgs'
         do i = 1, n_dfree
            write(9,'(i4,2f12.6)') i,p(i),g(i)
         end do
         write(9,'(a/)')'-------------------------------------------'
      end if

c ----------------------------------------------------------------------
c ---- Start BFGS! ----
c ----------------------------------------------------------------------

      i_lns_count=0
      if(nid.eq.0) write(9,'(a)') '>>>>>>> Start(!) BFGS  <<<<<<< '
      i_std_runs=0
 1    continue

c ___ Initialise the inverse Hessian to the unit matrix
c ___ Initial line direction

      do i = 1, n_dfree
         xi(i) = -g(i)
         do j = 1, n_dfree
            hessin(i,j) = 0.d0
         end do
         hessin(i,i) = 1.d0
      end do

c.......................................................................
c................. Main loop: iter - iteration number ..................
c.......................................................................

 100  i_lns_count=i_lns_count+1
      if(i_lns_count.eq.max_opt) go to 200

c______________ do line search along xi():
c p(), energy_best - entrance point
c pnew(), energy_new - exit point

c write(*,*) 'I am nid=',nid,' before linear search',i_lns_count
      call lnsrch(p,g,xi,energy_best,pnew,energy_new,
     + i_eng_count,iPrnt)
c write(*,*) 'I am nid=',nid,' after linear search',i_lns_count
      if(opt_problems) go to 300

      e_last_gain = energy_best - energy_new
      energy_best = energy_new

      if(nid.eq.0) then
         write(*,'(a,i3,a,i4,a,e24.14,a,e24.14)') '===== BFGS line(',
     & i_lns_count,') energy(',i_eng_count,') = ',energy_best,
     & ' a.u. -> gain= ',e_last_gain
         write(9,'(a,i3,a,i4,a,e24.14,a,e24.14)') '===== BFGS line(',
     & i_lns_count,') energy(',i_eng_count,') = ',energy_best,
     & ' a.u. -> gain= ',e_last_gain
      end if

c______ Do restart file

      if(Yes_Dump) call do_restart(pnew,iPrnt,.true.)

c ______ Calculate new gradients (coordinates will be in x,y,z),
c save the old one in dg:
      call vector_copy(g,dg,n_dfree)

c write(*,'(a,i5)') 'entering gradienst in bfgs, I am nid=',nid
      call gradients(pnew,g,iPrnt)
c write(*,'(a,i5)') 'exiting gradienst in bfgs, I am nid=',nid

c______ Update the line direction
      do i = 1, n_dfree
         xi(i) = pnew(i) - p(i)
      end do

c______ Print out
      if(nid.eq.0.and.iPrnt.ge.10) then
         write(9,'(a)') '   N  Gradients   Coord  Delta Crd.  in BFGS'
         do i = 1, n_dfree
            write(9,'(i4,3f12.6)') i,g(i),pnew(i),xi(i)
         end do
         write(9,'(a)')'-------------------------------------'
      end if
      if(nid.eq.0.and.iPrnt.ge.3) then
         write(9,'(a)')'))))))) New/Old Coordinates in BFGS ((((((((('
         call print_compare(p,pnew)
      end if

c -----------------------------------------------------------------------
c ------------- Check energy, coordinates, forces to exit ---------------
c -----------------------------------------------------------------------

      l_crd = check_crd(pnew,p,n_dfree,crd_tol)
      l_frc = check_frc(g,n_dfree,frc_tol,imf,nid)
      l_eng=check_eng(e_last_gain,en_tol,nid)
      if(nid.eq.0) then
         if(l_crd) write(9,'(a)') ' Convergence in coordinates!'
         if(l_frc) write(9,'(a)') ' Convergence in forces!'
         if(l_eng) write(9,'(a)') ' Convergence in energy!'
      end if

c______ Update the current point
      call vector_copy(pnew,p,n_dfree)

c_________ decide whether to proceed or exit the routine

c write(*,*) 'I am nid=',nid,' checks = ',l_crd,l_frc,l_eng,finished

      if(l_frc.and.l_crd.and.l_eng) then
c_________ successful: exit
         if(nid.eq.0) then
            write(9,'(/a)')'==> Optimisation completed. Exiting ... <=='
            write(*,'(a)') '==> Optimisation completed. Exiting ... <=='
            write(9,'(a)')
         end if
         finished=.true.
c write(*,'(a,i5)') 'exiting bfgs, I am nid=',nid
         go to 300
c_________ energy and coordinates are fine, but force is still big:
c switch to steepest descent.
c The variable i_std_run looks after this: it won't be possible 
c to get stuck!
c
      else if(l_crd.and.l_eng) then
         i_std_runs=i_std_runs+1
         if(i_std_runs.gt.iBFGS_st_desc_max .and.
     & e_last_gain.lt.en_tol) then
            if(nid.eq.0) then
               write(9,'(a,i3,a)')'>>>>> BFGS: the max count = ',
     & iBFGS_st_desc_max,' reached. Exiting!'
               write(*,'(a,i3,a)')'>>>>> BFGS: the max count = ',
     & iBFGS_st_desc_max,' reached. Exiting!'
            end if
            opt_problems=.true.
            go to 300
         else
            if(nid.eq.0) then
               write(9,'(a,i3,a)')'>>>>> Start BFGS from st.desc. ==> ',
     & i_std_runs,' <<<<< '
               write(*,'(a,i3,a)')'>>>>> Start BFGS from st.desc. ==> ',
     & i_std_runs,' <<<<< '
            end if
            go to 1
         end if
      else
         i_std_runs=0
         if(nid.eq.0) then
            write(9,'(a/)') ' ==> next step'
            if(iPrnt.ge.3) write(*,'(a)') ' ==> next step'
         end if
      end if

c ----------------------------------------------------------------------
c ------------- Update the Hessian matrix ---------------
c ----------------------------------------------------------------------

c______ Difference of gradients
      do i = 1, n_dfree
         dg(i) = g(i) - dg(i)
      end do

c______ and difference times current matrix
      do i = 1, n_dfree
         hdg(i) = 0.d0
         do j = 1, n_dfree
            hdg(i) = hdg(i) + hessin(i,j)*dg(j)
         end do
      end do

c______ Calculate products for denominator:
      fac = 0.d0
      fae = 0.d0
      sumdg = 0.d0
      sumxi = 0.d0
      do i = 1, n_dfree
         fac = fac + dg(i)*xi(i)
         fae = fae + dg(i)*hdg(i)
         sumdg = sumdg + dg(i)*dg(i)
         sumxi = sumxi + xi(i)*xi(i)
      end do

c______ Skip the update if fac is not sufficiently positive

      if(fac*fac.gt.EPS*sumdg*sumxi) then

         if(nid.eq.0.and.iPrnt.ge.10)
     & write(9,'(a)') '... Do update of the Hessian in BFGS'
         fac = 1.d0 / fac
         fad = 1.d0 / fae

c _________ The vector that makes BFGS different from DFP
         do i = 1, n_dfree
            dg(i) = fac*xi(i) - fad*hdg(i)
         end do

         if(nid.eq.0.and.iPrnt.ge.10) then
            write(9,'(a)') ' Vectors: i,xi,g,dg  and Hessian Matrix'
            do i = 1, n_dfree
               write(9,'(i4,3f12.6,5x,8f18.6)') i,xi(i),g(i),
     + dg(i),(hessin(i,j),j = 1,n_dfree)
            end do
            write(9,'(a)')
         end if

c _________ Do update
         do i = 1, n_dfree
            do j = 1, n_dfree
               hessin(i,j) = hessin(i,j) + fac*xi(i)*xi(j) -
     + fad*hdg(i)*hdg(j) + fae*dg(i)*dg(j)
            end do
         end do
      end if

c ----------------------------------------------------------------------
c ------------- Calculate new direction of optimisation ---------------
c ----------------------------------------------------------------------

      do i = 1, n_dfree
         xi(i) = 0.d0
         do j = 1, n_dfree
            xi(i) = xi(i) - hessin(i,j)*g(j)
         end do
      end do

c ______ Print out
      if(nid.eq.0.and.iPrnt.ge.10) then
         write(9,'(a)')
     + '   New Direction Grad. in BFGS and Hessian Matrix'
         do i = 1, n_dfree
            write(9,'(i4,2f12.6,5x,8f18.6)') i,xi(i),g(i),
     + (hessin(i,j),j = 1,n_dfree)
         end do
         write(9,'(a)')
      end if

c_____________ continue optimisation
c
      go to 100
 200  if(nid.eq.0) write(9,'(a)')
     & '... WARNING! exiting BFGS: optimisation is NOT complete!'

c.............. return her
 300  deallocate(hessin)
      if(nid.eq.0) write(*,*)'Memory deallocated successfully!'
      return
      end

      subroutine lnsrch(p,g,xi,energy_best,pnew,energy_new,
     + i_eng_count,iPrnt)
c........................................................................
c line search:
c p(*) - entrance point (vector of coordinates)
c g(*) - entrance gradient
c xi(*) - direction of the line search
c energy_best - entrance energy ( at p(*) )
c pnew(*) - new point
c energy_new - new energy ( at pnew(*) )
c stpmax - maximum step allowed
c n_dfree - number of degrees of freedom
c i_lns_count - number of the "lnsrch" calls
c i_eng_count - number of the "energy" calls
c........................................................................
      include 'shell.inc'

      include 'mpif.h'

      parameter ( alf = 1.d-4, tolx = 1.d-7 )
      double precision p(*),g(*),xi(*),pnew(*)

c___ Start here
      sum = 0.d0
      do i = 1, n_dfree
         sum = sum + xi(i)*xi(i)
      end do
      sum = dsqrt(sum)

      if(sum.gt.stpmax) then
         do i = 1, n_dfree
            xi(i) = xi(i) * stpmax / sum
         end do
      end if
      slope = 0.d0
      do i = 1, n_dfree
         slope = slope + g(i) * xi(i)
      end do
      test = 0.d0
      do i = 1, n_dfree
         temp = dabs(xi(i)) / max(dabs(p(i)),1.d0)
         if(temp.gt.test) test = temp
      end do
      alamin = TOLX / test
      alam = 1.d0

c________________ move along xi() by alam and calculate the energy

 1    continue
      do i = 1, n_dfree
         pnew(i) = p(i) + alam * xi(i)
      end do

      i_eng_count = i_eng_count + 1
      energy_new = energy(pnew,iPrnt)
      if(nid.eq.0.and.iPrnt.ge.1) then
         write(9,'(a,5x,i3,2(x,e24.14))')
     & 'linesearch: ',i_eng_count, energy_new,slope
         write(*,'(a,5x,i3,2(x,e24.14))')
     & 'linesearch: ',i_eng_count, energy_new,slope
      end if

      check = ALF*alam*slope
c________________ what to do next?

      if(alam.lt.alamin) then
         do i = 1, n_dfree
            pnew(i) = p(i)
         end do
         e_gain = energy_new - energy_best
         if(nid.eq.0) then
            write(9,1005) i_lns_count,alam,energy_new,e_gain
            if(iPrnt.ge.5)
     & write(*,1005) i_lns_count,alam,energy_new,e_gain
            if(e_gain.gt.0.0d0)
     & write(*,'(a,e12.6,a)') 'WARNING in LNSRCH: e_gain = ',
     & e_gain,' >0  -> still proceeding ...'
         end if
         return
      else if(energy_new.le.(energy_best + check)) then
         e_gain = energy_new - energy_best
         if(nid.eq.0) then
            write(9,1005) i_lns_count,alam,energy_new,e_gain
            if(iPrnt.ge.5)
     & write(*,1005) i_lns_count,alam,energy_new,e_gain
         end if
         return
      else
         if(alam.eq.1.d0) then
            tmplam = -slope/(2.d0 * (energy_new - energy_best - slope))
         else
            rhs1 = energy_new - energy_best - alam*slope
            rhs2 = f2 - energy_best2 - alam2*slope
            a = ( rhs1/alam**2 - rhs2/alam2**2 ) / ( alam-alam2)
            b = (-alam2*rhs1/alam**2 + alam*rhs2/alam2**2) /
     + (alam - alam2)
            if(a.eq.0.d0) then
               tmplam = -slope / ( 2.d0 * b )
            else
               disc = b*b - 3.d0 * a * slope
               if(nid.eq.0.and.disc.lt.0.d0) then
                  write(*,*) 'FATAL! roundoff prblem in lnsrch'

                  call MPI_Abort(MPI_COMM_WORLD,-1,error)



               end if
               tmplam = ( -b + dsqrt(disc)) / ( 3.d0 * a)
            end if
            if(tmplam.gt.0.5d0*alam) tmplam = 0.5d0 * alam
         end if
      end if
      alam2 = alam
      f2 = energy_new
      energy_best2 = energy_best
      alam = max(tmplam, 0.1d0*alam)
      goto 1

c___ Formats
 1005 format(' >>> lnsrch >>>',i4,' lambda = ',f16.10,
     + '  energy = ',e24.14,' a.u.','  delta = ',e24.14)

      end

      logical function check_eng(e_last_gain,en_tol,nid)
c........ checks convergence in the energy
      include 'param.inc'
      check_eng = .false.
      if(e_last_gain.ge.0.0) then
         if(nid.eq.0) write(9,'(a,e16.8,a,e16.8)')
     & ' Energy gain = ',e_last_gain,'   Tolerance = ',en_tol
         if(e_last_gain.lt.en_tol) check_eng = .true.
      else
         if(nid.eq.0) write(9,'(a,e16.8,a,e16.8)')
     & ' Energy gain = ',e_last_gain,
     , ' =< NEGATIVE! >= Tolerance = ',en_tol
      end if
      return
      end

      logical function check_crd(pnew,p,n_dfree,crd_tol)
c........ checks convergence in coordinates
      include 'param.inc'
      dimension pnew(n_dfree),p(n_dfree)
      do i=1,n_dfree
         if(abs(pnew(i)-p(i)).gt.crd_tol) then
            check_crd=.false.
            return
         end if
      end do
      check_crd=.true.
      return
      end

      logical function check_frc(g,n_dfree,frc_tol,imf,nid)
c........ checks convergence in forces
c im - 1-dim coordinate with the maximum force found
      include 'param.inc'
      dimension g(n_dfree)
      force_max=0.0
      do i=1,n_dfree
         if(abs(g(i)).gt.force_max) then
            force_max=abs(g(i))
            imf=i
         end if
      end do
      if(force_max.gt.frc_tol) then
         if(nid.eq.0) then
            write(9,'(/2(a,e12.6),a,i5/)')' ...>>> MAX force = ',
     & force_max,' > frc_tol=',frc_tol,' for imf= ',imf
            write(*,'(/2(a,e12.6),a,i5/)')' ...>>> MAX force = ',
     & force_max,' > frc_tol=',frc_tol,' for imf= ',imf
         end if
         check_frc=.false.
      else
         if(nid.eq.0) then
            write(9,'(/2(a,e12.6)/)')' ...>>> MAX force = ',
     & force_max,' < frc_tol=',frc_tol
            write(*,'(/2(a,e12.6)/)')' ...>>> MAX force = ',
     & force_max,' < frc_tol=',frc_tol
         end if
         check_frc=.true.
      end if
      return
      end

      subroutine print_compare(p,pnew)
c........ all coordinates associated with p,pnew are printed together
      include 'shell.inc'
      dimension p(max_free),pnew(max_free)
      character cha(3)
      data cha/'F','R','C'/

c_______ old: p => fx,fy,fz
      call vector_copy(x,fx,Ncharge)
      call vector_copy(y,fy,Ncharge)
      call vector_copy(z,fz,Ncharge)
      call conv_1_3(p,fx,fy,fz,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)
c_______ new: pnew => x,y,z
      call conv_1_3(pnew,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     , n_pos_cor,iRx,iRy,iRz)

c_______ print now
      if(nid.ne.0) then

         write(9,'(/a)')'........... Old/New cores (au) ...............'
         do i=1,Natom
            write(9,'(a3,i5,5x,2(a3,3(x,f10.5)),a2)')
     & cha(iRx(i)+1)//cha(iRy(i)+1)//cha(iRz(i)+1),
     & i,' | ',fx(i),fy(i),fz(i),' | ',x(i),y(i),z(i),' |'

         end do
         write(9,'(/a)')'........... Old/New shells (au) ..............'
         do i=1,Natom
            is=ISRT(i)
            if(Shell_Ref(is)) then
               j=iShell(i)
               write(9,'(a3,2i5,2(a3,3(x,f10.5)),a2)')
     & cha(iRx(j)+1)//cha(iRy(j)+1)//cha(iRz(j)+1),
     & j,i,' | ',fx(j),fy(j),fz(j),' | ',x(j),y(j),z(j),' |'
c
            end if
         end do
      end if
      return
      end
