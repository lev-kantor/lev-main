      double precision function gasdev(idum)
c.......................................................................
c     returns a normally distributed deviate with zero mean and unit   .
c     variance                                                         .
c.......................................................................
       double precision value
       integer iset
       double precision fac,gset,rsq,v1,v2
       save iset,gset
       real ran2
       data iset/0/
       if(idum.lt.0) iset=0
       if(iset.eq.0) then
 1        v1 = 2.*ran2(idum) - 1.
          v2 = 2.*ran2(idum) - 1.
          rsq = v1**2 + v2**2
          if(rsq.ge.1..or.rsq.eq.0.) goto 1
          fac = sqrt(-2.*log(rsq)/rsq)
          gset = v1*fac
          gasdev = v2*fac
          iset = 1
       else
          gasdev = gset
          iset = 0
       end if
       return
       end


      function ran1(idum)
c.....................................................................
c     minimal random number geerator with Bays-Durham shuffle and    .
c     added safeguards. Returns a uniform deviate between 0.0 and    .
c     1.0 (exclusive of the endpoint values). Call with idum a       .
c     negative integer to initialise; thereafter, do not alter idum  .
c     between successive deviates in a sequence. RNMX should         .
c     approximate the largest floating value that is less than 1.    .
c.....................................................................
      integer idum,ia,im,iq,ir,ntab,ndiv
      real ran1,am,eps,rnmx
      parameter (ia=16807,im=2147483647,am=1./im,iq=127773,ir=2836,
     &     ntab=32,ndiv=1+(im-1)/ntab,eps=1.2e-7,rnmx=1.-eps)
      integer j,k,iv(ntab),iy
      save iv,iy
      data iv /ntab*0/, iy /0/
      if(idum.le.0.or.iy.eq.0) then
         idum = max(-idum,1)
         do j=ntab + 8,1,-1
            k = idum/iq
            idum = ia*(idum-k*iq)-ir*k
            if(idum.lt.0) idum = idum + im
            if(j.le.ntab) iv(j) = idum
         end do
         iy = iv(1)
      end if
      k = idum/iq
      idum = ia*(idum - k*iq)-ir*k
      if(idum.lt.0) idum = idum + im
      j = 1 + iy/ndiv
      iy = iv(j)
      iv(j) = idum
      ran1 = min(am*iy,rnmx)
      return
      end


      function ran2(idum)
      integer idum,im1,im2,imm1,ia1,ia2,iq1,iq2,ir1,ir2,ntab,ndiv
      real ran2,am,eps,rnmx
      parameter (im1=2147483563,im2=2147483399,am=1./im1,imm1=im1-1,
     &     ia1=40014,ia2=40692,iq1=53668,iq2=52774,ir1=12211,
     &     ir2=3791,ntab=32,ndiv=1+imm1/ntab,eps=1.2e-7,rnmx=1.-eps)
c.............................................................................
c     Long period (>2x10^18) random number generator of L'Ecyer with Bays-   .
c     Durham shuffle and add safeguards. Returns a uniform deviate between   .
c     0.0 and 1.0 (exculsive of the endpoint values). Call with idum a       .
c     negative integer to initialise; thereafter, do no alter idum between   .
c     successive deviates in a sequence. RNMX should approximate the largest .
c     floating value that is less than 1                                     .
c.............................................................................
      integer idum2,j,k,iv(ntab),iy
      save iv,iy,idum2
      data idum2/123456789/, iv/NTAB*0/, iy/0/
      if(idum.le.0) then
         idum=max(-idum,1)
         idum2=idum
         do 11 j=ntab+8,1,-1
            k=idum/iq1
            idum=ia1*(idum-k*iq1)-k*ir1
            if(idum.lt.0) idum=idum+im1
            if(j.le.ntab) iv(j)=idum
 11      end do
         iy=iv(1)
      end if
      k=idum/iq1
      idum=ia1*(idum-k*iq1)-k*ir1
      if(idum.lt.0) idum=idum+im1
      k=idum2/iq2
      idum2=ia2*(idum2-k*iq2)-k*ir2
      if(idum2.lt.0) idum2=idum2+im2
      j=1+iy/ndiv
      iy=iv(j)-idum2
      iv(j)=idum
      if(iy.lt.1) iy=iy+imm1
      ran2=min(am*iy,rnmx)
      return
      end
