      subroutine do_restart(p,iPrnt,mainf)
c.....................................................................
c  restart file is dumped here.
c  p - 1-dim vector of coordinates
c  mainf - if .true., then main final <name>.RST file is dumped.
c          if .false., then an additional file <name>_add.RST is dumped 
c                     in which the keywords "move" and "scan" are
c                     absent (when scan=.true.).
c.....................................................................

c      include 'shell.inc'  NB 'tersoff.inc' now includes 'shell.inc'

      include 'tersoff.inc'
      include 'constr.inc'
      dimension p(N0FR),r(3)
      logical mainf
      character which*2,cha*1,cha4*4,sign,xyz(NinvAt0),frmat*22,line*120

      if(nid.ne.0) return
c
c............ make p => x,y,z
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,        n_pos_cor,iRx,iRy,iRz)
c
c............ open restart file
      if(mainf) then
         if(iPrnt.ge.8) 
     &        write(*,*)'... opening as output '//FilNam(leng:)//'.RST'
         open(1,FILE=FilNam(leng:)//'.RST',status='unknown')
      else
         if(iPrnt.ge.8) 
     &     write(*,*)'... opening as output '//FilNam(leng:)//'_add.RST'
         open(1,FILE=FilNam(leng:)//'_add.RST',status='unknown')
      end if

c
c.............. tolerances
      write(1,'(/a)') '.<Toleranc>'

      if(do_lat) write(1,'(a)') 'do_lateral'
      if(iPrnt.eq.0) then
         write(1,'(a)') 'printing no'
      else if(iPrnt.eq.1) then
         write(1,'(a)') 'printing tiny'
      else if(iPrnt.eq.3) then
         write(1,'(a)') 'printing small'
      else if(iPrnt.eq.5) then
         write(1,'(a)') 'printing medium'
      else if(iPrnt.eq.8) then
         write(1,'(a)') 'printing large'
      else if(iPrnt.eq.10) then
         write(1,'(a)') 'printing huge'
      end if
      if(move_shells.eq.0) then
         write(1,'(a)') 'shells frozenall'
      else if(move_shells.eq.1) then
         write(1,'(a)') 'shells follow'
      else if(move_shells.eq.2) then
         write(1,'(a)') 'shells moveall'
      end if
      if(write_xyz) write(1,'(a)') 'xyz'
      if(do_movie)  write(1,'(a)') 'movie'
      if(write_en_frc) write(1,'(a)')'write_energy_forces'
      if(write_g98) write(1,'(a)') 'g98'
      write(1,'(a,i5)') 'max_opt ',max_opt
      if(bfgs) write(1,'(a,f10.5)') 'optim bfgs ',stpmax
      if(cg) then
         if(method_cg.eq.'steep_des') then
            write(1,'(a)') 'optim steep'
         else
            write(1,'(a)') 'optim conjug '//method_cg
         end if
      end if
      if(shake) write(1,'(a,e12.6)') 'shake ',shake_step*au_A
      write(1,'(2(a,e12.6),a)') 'en_tol ',en_tol*au_eV
      if(finished) then
         write(1,'(a,e12.6)') 'es_tol ',es0_tol*au_eV
      else
         write(1,'(a,2(x,e12.6))') 'es_tol ',es_tol*au_eV,es0_tol*au_eV
      end if
      unit=eV_au/A_au
      write(1,'(2(a,e12.6),a)') 'frc_tol ',frc_tol/unit
      write(1,'(2(a,e12.6),a)') 'crd_tol ',crd_tol*au_A
      if(read_force) write(1,'(a)')'read_force '//force_file(lengf:)
      if(update_RST) write(1,'(a)') 'update_RST'
      write(1,'(a)') '.<End>'
c
c.............. molecular dynamics

      if(do_md) then

         write(1,'(/a)') '.<MDcontrol>'

         if(nstep.ne.numsteps) then
            write(1,*) '...simulation stopped after ',nstep,' steps...'
         end if
         write(1,*) 'numsteps   ',numsteps
         write(1,*) 'tstep   ',tstep * fs_ps
         write(1,*) 'dtemp   ',dtemp

         if(ialgorithm.eq.0) then
            write(1,'(a)') 'algorithm nve'
         else if(ialgorithm.eq.1) then
            write(1,'(a)') 'algorithm evn_nvt'
         else if(ialgorithm.eq.2) then
            write(1,'(a)') 'algorithm ber_nvt'
         else if(ialgorithm.eq.3) then
            write(1,'(a)') 'algorithm hov_nvt' 
         else if(ialgorithm.eq.4) then
            write(1,'(a)') 'algorithm stochastic' 
         end if

         if(dshell_model.eq.0) then
            write(1,'(a)') 'shells  dynamic'
         else if(dshell_model.eq.1) then
            write(1,'(a)') 'shells  relax'
         end if

         write(1,*) 'tau   ',tau * fs_ps
         write(1,*) 'statistics   ',stat_print
         write(1,*) 'trajectory   ',traj_print
         write(1,*) 'traj_fmt   ',traj_fmt
         write(1,*) 'vel_key   1'

         write(1,'(a)') '.<End>'

      end if
c
c............... tip dynamics
      if(dynamic_tip) then
         write(1,'(/a)') '.<TipDynamics>'
         if(do_md) then
            write(1,'(a,4(x,f10.5))') 'howto',
     &           t_amplitude*au_S,t_period*fs_ps,
     &           x_scan_speed*aufs_Aps,y_scan_speed*aufs_Aps
         else
            r(1)=shift(1)*au_A
            r(2)=shift(2)*au_A
            r(3)=shift(3)*au_A
            write(1,'(a,3(x,f10.5),x,i5)') 
     &                      'howto',r,relax_steps
            if(turnback) write(1,'(a)') 'turnback'
         end if
         write(1,'(a)') '.<End>'
      end if
c
c............... shell parameters

      write(1,'(/a)') '.<ShellPar>'
      units=eV_au/A_au**2
      do i=1,KINDS
         write(1,'(a3,5(x,e12.6))') 
     &        Species(i),smass(i,1),CoreQA(i),smass(i,2),
     &        ShellQA(i),Spring(i)/units
      end do
      write(1,'(a)') '.<End>'

c............. species types

      write(1,'(/a)') '.<SpeciesTypes>'
      itf=0
      imb=0
      do i=1,KINDS
         if(SpecType(i).eq.'tf') then
            itf=itf+1
            line((itf-1)*4+1:itf*4)=Species(i)//' '
         end if
      end do
      if(itf.ne.0) write(1,'(a)') 'Tersoff_Species '//line(1:itf*4)
      do i=1,KINDS
         if(SpecType(i).eq.'mb') then
            imb=imb+1
            line((imb-1)*4+1:imb*4)=Species(i)//' '
         end if
      end do
      if(imb.ne.0) write(1,'(a)') 'ManyBody_Species '//line(1:imb*4)
      write(1,'(a)') '.<End>'
c
c.............. coordinates

      write(1,'(/a)') '.<Coord>'
      if(scan .and. mainf) then
         write(1,'(a,3(x,e12.6))') 'scan ',(shift_sc(l),l=1,3)
         if(finished)
     &        write(1,'(a,3(x,e12.6))') 'move ',(shift_sc(l),l=1,3)
      end if
      which='  '
      do i=1,Natom
         cha=' '
         if(iQMC(i)) cha='@'
         if(.not.central_atom(i)) cha='#'
         if(Species(ISRT(i))(3:3).eq.' ') then
            cha4=Species(ISRT(i))(1:2)//cha//' '
         else
            cha4=Species(ISRT(i))(1:3)//cha
         end if
         if(id(i).ne.which) then
            which=id(i)
            if(which.eq.'ft') write(1,'(a)') 'frozen-tip'
            if(which.eq.'tb') write(1,'(a)') 'tip-buffer'
            if(which.eq.'ta') write(1,'(a)') 'tip-atoms'
            if(which.eq.'ca') write(1,'(a)') 'cluster-atoms'
            if(which.eq.'cb') write(1,'(a)') 'cluster-buffer'
         end if
         j=i
         if(Shell_Ref(ISRT(i))) j=iShell(i)
         write(1,'(a4,3(x,e16.10),3(x,i1),3(x,e16.10),i2)') 
     &                      cha4,X(i)*au_A,Y(i)*au_A,Z(i)*au_A,
     ,                    iRx1(i),iRy1(i),iRz1(i),
     ,                    X(j)*au_A,Y(j)*au_A,Z(j)*au_A
      end do
      write(1,'(a)') '.<End>'

c
c.............. crystal lattice
      if(periodic_lattice) then
         write(1,'(/a)') '.<Lattice>'
         do i=1,3
            write(1,*) (AJ(i,j),j=1,3)
         end do
         write(1,'(a)') '.<End>'
      end if
c     
c..............bond tolerances
      write(1,'(/a)') '.<BondToleranc>'
      do i=1,n_pair
         write(1,*) 
     &        mdv_pair(i,1),'   ',mdv_pair(i,2),'    ',min_bond(i)*au_A,
     &        '     ',max_bond(i)*au_A
      end do
      write(1,'(a)') '.<End>'

c
c..............bond potentials
      write(1,'(/a)') '.<quadratic_bond>'
      do i=1,numpar_b
         write(1,*) 
     &        bond_at(i,1),'   ',bond_at(i,2),'    ',
     &        r0(i),'   ',k0(i)
      end do
      write(1,'(a)') '.<End>'

c
c..............angle potentials
      write(1,'(/a)') '.<quadratic_angle>'
      do i=1,numpar_a
         write(1,*) 
     &        ang_at(i,1),'   ',ang_at(i,2),'    ',
     &        ang_at(i,3),'   ',theta0(i),'   ',k02(i)
      end do
      write(1,'(a)') '.<End>'

c
c..............torsion potentials
      write(1,'(/a)') '.<torsion_1>'
      do i=1,numpar_t
         write(1,*) 
     &        tor_at(i,1),'   ',tor_at(i,2),'    ',
     &        tor_at(i,3),'   ',tor_at(i,4),'    ',
     &        Kphi(i),'   ',n1(i),'   ',Phi0(i)
      end do
      write(1,'(a)') '.<End>'

c
c..............oop potentials
      write(1,'(/a)') '.<out_of_plane>'
      do i=1,numpar_o
         write(1,*) 
     &        oop_at(i,1),'   ',oop_at(i,2),'    ',
     &        oop_at(i,3),'   ',oop_at(i,4),'    ',
     &        Kchi(i),'   ',n2(i),'   ',Chi0(i)
      end do
      write(1,'(a)') '.<End>'

c
c.............. pair potentials

      write(1,'(/a)') '.<PairPotenc>'
      if(do_cutoff) then
         write(1,*) 'cutoff'
      end if
      do i=1,KINDS
        do j=1,i
           k=j+i*(i-1)/2
           if(do_cutoff) then
              write(1,'(2(a3,x),e12.6,5x,2(x,i3))') 
     &             Species(i),Species(j),CutOff(k)*au_A
           else
              write(1,'(2(a3,x),e12.6,5x,2(x,i3))') 
     &             Species(i),Species(j)
           end if
           write(1,'(5x,a,i2)') 'exp ',iPotD(k,1)
           if(iPotD(k,1).ne.0) then
              do n=1,iPotD(k,1)
                 write(1,*) ParD(k,n,1,1)*au_eV,ParD(k,n,2,1)*au_A
              end do
           end if
           write(1,'(5x,a,i2)') 'pow ',iPotD(k,2)
           if(iPotD(k,2).ne.0) then
              do n=1,iPotD(k,2)
                 units=eV_au*A_au**ParD(k,n,2,2)
                 write(1,*) ParD(k,n,1,2)/units,ParD(k,n,2,2)
              end do
           end if
        end do
      end do
      write(1,'(a)') '.<End>'

c
c.............. image

      if(Do_Image) then
         write(1,'(/a)') '.<Image>'
         if(iPrnt1.eq.0) then
            write(1,'(a)') 'printing no'
         else if(iPrnt1.eq.1) then
            write(1,'(a)') 'printing tiny'
         else if(iPrnt1.eq.3) then
            write(1,'(a)') 'printing small'
         else if(iPrnt1.eq.5) then
            write(1,'(a)') 'printing medium'
         else if(iPrnt1.eq.8) then
            write(1,'(a)') 'printing large'
         else if(iPrnt1.eq.10) then
            write(1,'(a)') 'printing huge'
         end if
         if(do_only_bias) then
            write(1,'(a)') 'capacitor only'
         else
            write(1,'(a)') 'capacitor and polarisation'
         end if
         if(do_decay) then
            write(1,'(a)') 'decay'
         end if
         if(precis.eq.0.0) then
            write(1,'(a,i5)')'precis  ',NumImg
         else
            write(1,'(a,e12.6)')'precis  ',precis
         end if      
         write(1,'(a,e12.6)') 'Z_plane  ',Z_plane
         if(do_plane) then
            write(1,'(a)') 'plane'
         end if
         if(do_sphere) then
            write(1,'(a)') 'sphere'
         end if
         if(iwrite.eq.1) then
            write(1,'(a)') 'qwrite'
         end if
         write(1,'(a,3(e12.6,x))') 'bottom_sph ',R_Sph(1),R_Sph(2),Rz
         write(1,'(a,e12.6)') 'buffer ',2*beta*au_A
         write(1,'(a,e12.6)') 'smooth ',ro*au_A
         write(1,'(a,e12.6)') 'bias  ',Volt
         write(1,'(a,e12.6)') 'radius  ',Rad
         write(1,'(a)') '.<End>'
      end if

c............. constraints

      if(Yes_Constr) then
         write(1,'(/a)') '.<Constraints>'
         do ic=1,N_of_Constr
            if(Type_Constr(ic).eq.'A_1x') then 
               if(Par_Constr(ic,2).eq.1.0) then
                  sign='+'
               else 
                  sign='-'
               end if
               write(1,'(a,2(i3,x),5x,f10.5,x,a)') Type_Constr(ic),
     &            (Inv_atoms(ic,j),j=1,2),Par_Constr(ic,1)*180./pi,sign

            else if(Type_Constr(ic).eq.'B1xz') then
               if(Par_Constr(ic,2).eq.1.0) then
                  sign='+'
               else 
                  sign='-'
               end if
               write(1,'(a,2(i3,x),5x,f10.5,x,a)') Type_Constr(ic),
     &            (Inv_atoms(ic,j),j=1,2),Par_Constr(ic,1)*180./pi,sign

            else if(Type_Constr(ic).eq.'C_1x') then
               if(Par_Constr(ic,2).eq.1.0) then
                  sign='+'
               else 
                  sign='-'
               end if
               write(1,'(a,2(i3,x),5x,f10.5,x,a)') Type_Constr(ic),
     &            (Inv_atoms(ic,j),j=1,3),Par_Constr(ic,1)*180./pi,sign
               
            else if(Type_Constr(ic).eq.'D_1x') then
               if(Par_Constr(ic,2).eq.1.0) then
                  sign='+'
               else 
                  sign='-'
               end if
               write(1,'(a,2(i3,x),5x,f10.5,x,a)') Type_Constr(ic),
     &            (Inv_atoms(ic,j),j=1,2),Par_Constr(ic,1)*au_A,sign
               
            else if(Type_Constr(ic).eq.'LINR') then
               do j=1,N_inv_atoms(ic)
                  if(Inv_crd(ic,j,1)) then
                     xyz(j)='x'
                  else if(Inv_crd(ic,j,2)) then
                     xyz(j)='y'
                  else if(Inv_crd(ic,j,3)) then
                     xyz(j)='z'
                  end if
               end do
               write(frmat,'(a,i3,a)') 
     &              '(a,',N_inv_atoms(ic),'(i3,a1,x,f10.5))'
               write(1,frmat) 'LINR ',(Inv_atoms(ic,j),
     &                   xyz(j),Par_Constr(ic,j),j=1,N_inv_atoms(ic))

            else if(Type_Constr(ic).eq.'X   ') then
            end if
         end do
         write(1,'(a)') '.<End>'
      end if

c......writing velocities to file
      
      if(do_md) then
         write(1,'(/a)') '.<Velocity>'
         do i=1,Natom
            if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
               if(Shell_Ref(ISRT(i)).and.dshell_model.eq.0) then
                  j=iShell(i)
                  write(1,'(6f16.10)') 
     &                 vx(i)*aufs_Aps,vy(i)*aufs_Aps,vz(i)*aufs_Aps,
     &                 vx(j)*aufs_Aps,vy(j)*aufs_Aps,vz(j)*aufs_Aps
               else
                  write(1,'(3f16.10)') 
     &                 vx(i)*aufs_Aps,vy(i)*aufs_Aps,vz(i)*aufs_Aps
               end if
            end if
         end do

         write(1,'(a)')'.<End>'
      end if

c......writing frictions to file

      if(do_md .and. ialgorithm.eq.4) then
         write(1,'(/a)')'.<Friction>'
         do i=1,Natom
            write(1,'(i4,3f10.5)') stoc(i),fricx(i)*ps_fs,
     &           fricy(i)*ps_fs,fricz(i)*ps_fs
         end do
      
         write(1,'(a)')'.<End>'
      end if

c........ Tersoff
      
      if(do_tersoff) then
         write(1,'(/a)') '.<Tersoff>'
         write(1,'(a,i10)') 'how_often_nn_update ',nn_list_howoften
         write(1,'(2a)') 'system ',system_type
         write(1,'(a)') '.<End>'
      end if

      close (1)
      if(iPrnt.ge.8) write(*,'(a)')'... Done restart file successfully'
      return
      end

      subroutine do_xyz(p,iPrnt)
c.....................................................................
c xmol input files are prepared:
c
c       <name>_core.xyz file with core coordinates 
c       <name>_shll.xyz file with shell coordinates 
c.....................................................................
c Ghost H atoms are added with vectors to plot the axes with XMOL.
c.....................................................................
      include 'shell.inc'
      dimension p(N0FR)
c
c............ make p => x,y,z
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,        n_pos_cor,iRx,iRy,iRz)
c
c............ open xyz files

      write(11,*) Natom+3
      write(11,*) '... created by shm: core coordinates '
      write(12,*) Natom+3
      write(12,*) '... created by shm: shell coordinates '
      write(11,'(a)') 'H 0.0 0.0 0.0 atom_vector  10.0  0.0  0.0 '
      write(11,'(a)') 'H 0.0 0.0 0.0 atom_vector    0.0 10.0  0.0 '
      write(11,'(a)') 'H 0.0 0.0 0.0 atom_vector    0.0  0.0 10.0 '
      write(12,'(a)') 'H 0.0 0.0 0.0 atom_vector   10.0  0.0  0.0 '
      write(12,'(a)') 'H 0.0 0.0 0.0 atom_vector    0.0 10.0  0.0 '
      write(12,'(a)') 'H 0.0 0.0 0.0 atom_vector    0.0  0.0 10.0 '

      do i=1,Natom
         write(11,'(a3,3(x,e16.10),a)') 
     &       Species(ISRT(i)),X(i)*au_A,Y(i)*au_A,Z(i)*au_A,
     &       ' 0.0 0.0 0.0'
         j=i
         if(Shell_Ref(ISRT(i))) j=iShell(i)
         write(12,'(a3,3(x,e16.10),a)') 
     &         Species(ISRT(i)),X(j)*au_A,Y(j)*au_A,Z(j)*au_A,
     &       ' 0.0 0.0 0.0'
      end do

      if(iPrnt.ge.8) then
         write(*,'(a)')'... Done '//FilNam(leng:)//'_core.xyz file'
         write(*,'(a)')'... Done '//FilNam(leng:)//'_shll.xyz file'
      end if
      return
      end

      subroutine do_for_g98(p,iPrnt)
c.....................................................................
c a set of charges for the input to Gaussian98 is prepared:
c
c       <name>_g98.chg
c.....................................................................
      include 'shell.inc'
      dimension p(N0FR)
c
c............ make p => x,y,z (in au)
      call conv_1_3(p,x,y,z,iShell,Shell_Ref,ISRT,Natom,
     ,        n_pos_cor,iRx,iRy,iRz)
c
c............ open g98 file
      if(iPrnt.ge.8) then
         write(*,*)'... opening as output '//FilNam(leng:)//'_g98.chg'
      end if
      open(1,FILE=FilNam(leng:)//'_g98.chg',status='unknown')

      do i=1,Natom
         write(1,'(4(x,e16.10))') X(i),Y(i),Z(i),CoreQA(ISRT(i))
         if(Shell_Ref(ISRT(i))) then
            j=iShell(i)
            write(1,'(4(x,e16.10))') X(j),Y(j),Z(j),ShellQA(ISRT(i))
         end if
      end do
      close (1)
      if(iPrnt.ge.8) then
         write(*,'(a)')'... Done '//FilNam(leng:)//'_g98.chg file'
      end if
      return
      end




