      subroutine Inval(NFIL,KodErr,restart,iPrnt)
c.....................................................................
c.............Read the file UNIT=NFIL, one box after another...........
c       Checks if all blocks are present (=boxes) for the task under
c       consideration
c......................................................................
c  KodErr = 1 in the FATAL cases only; otherwise, including WARNING
c  cases, KodErr = 0
c......................................................................
c Units: 
c ^^^^^^ - inside the code: a.u.(length, energy) , fs (time), a.u.m.(mass)
c        - outside (i/o)  : A (length), eV (energy), ps (time), a.u.m.(mass)
c......................................................................
      INCLUDE 'tersoff.inc'
      include 'constr.inc'
      logical restart
      integer ita,ica
      KodErr=0

c..............The box: <Toleranc>
      call Tolerc(NFIL,iPrnt)

c......... The box <Image>
      Do_Image=.false.
      call Image(NFIL,iPrnt)
      if(Do_Image.and.do_lat) then
         write(*,*)'FATAL! x,y image forces not yet implemented!'
         stop 'image with do_lat'
      end if
c
      do_md=.false.
      dynamic_tip=.false.
      if(.not. (do_test .or. do_test_tip .or. do_test_dir)) then
c..............The box: <MDcontrol>
         call MDcontrol(NFIL,iPrnt)
c..............The box: <TipDynamics>
         call Tip_Dynamics(NFIL,iPrnt)
      end if

c..............The box: <ShellPar>
      call ShellPar(NFIL,KodErr)

c..............The box: <SpeciesTypes>
      call SpeciesTypes(NFIL,KodErr)

c.............. read the force field: either Tersoff or pair-pot
      system_type='cluster'
      if(do_tersoff) call TersoffInput(NFIL,KodErr)

c.........The boxes: <Coord> 
      call Coord(NFIL,KodErr,restart,ita,ica)

c.........The box: <Lattice>'
      if(do_tersoff .and. 
     &     system_type.eq.'   bulk' .or. system_type.eq.'surface') then
         call PBC_lattice(NFIL,KodErr)
         if(.not.periodic_lattice) write(9,*)
     &        'FATAL: lattice vectors have not been found in <Lattice>!'
      end if

c............  initialise excluded interaction list: disallow direct pair-wise
c              interaction between atoms of the same molecules, as well as
c              between Tersoff related atoms
c
c    excl_atom(i,ii) - pair-wise interaction between i,ii to be removed
c                      (is only used in energy() and gradients3())
c
      do i=1,Natom
         do ii=1,Natom
            excl_atom(i,ii) = .false.
         end do
      end do

c.........The boxes: <BondToleranc>
      if(do_mbody .or. do_tersoff) then
         call BondToleranc(NFIL,iPrnt,KodErr1,KodErr)
         if(KodErr1.eq.1) then
            do i=1,Natom
               nnn(i)=0
               do nbb=1,N0BD
                  bond(i,nbb)=0
               end do
            end do
         end if
c_______________ exclude direct pairwise interaction between Tersoff atoms
         do i=1,Natom
            is=ISRT(i)
            do j=1,Natom
               js=ISRT(j)
               if(SpecType(is).eq.'tf' .and. SpecType(js).eq.'tf')
     &                                         excl_atom(i,ii) = .true.
            end do
         end do
      end if
      
c.........The box: <Pair Potenc>
      write(9,'(a,l1)') 'Tersoff  = ',do_tersoff
      write(9,'(a,l1)') 'ManyBody = ',do_mbody
      write(9,'(a,l1)') 'Pairwise = ',do_pair
      if(do_pair) call DynPotc(NFIL,KodErr)

c......... Many-body interaction, the box: 
      if(do_mbody) then
c_____fill interaction term arrays
         call diag_terms(iPrnt)
c_____get force field parameters for multi-body interactions
         call in_par(NFIL,iPrnt,iErr)
         if(iErr.eq.1) KodErr=1
      end if

c.........The box: <Constraints>
      Yes_Constr=.false.
      if(.not.do_test_tip) call Constraints(NFIL)
c.........The velocities
      if(vel_key.eq.1 .and. do_md) then
         call Velin(NFIL,ita,ica)
      end if
c.........The friction coefficients (if required)
      if(ialgorithm.eq.4 .and. do_md) then
         call FricIn(NFIL,KodErr)
      end if
c
c........... checking the size of the optimisation space
c
      if(n_dfree.gt.max_free) then
         write(*,'(a)')'FATAL! Exceeded optimisation space!'
         write(*,'(a,i5)')
     &          'FATAL! Increase N0FR in param.inc to ',n_dfree
         write(9,'(a)')'FATAL! Exceeded optimisation space!'
         write(9,'(a,i5)')
     &          'FATAL! Increase N0FR in param.inc to ',n_dfree
         stop
      end if
c
c-----filling the particle mass array
      call fill_pmass(iPrnt)
      return
      end

      SUBROUTINE MDcontrol(NFIL,iPrnt)
c......................................................................
c.....Read in the file UNIT=NFIL the box <MDcontrol>
c......................................................................
c MD times  - in fs
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2
      integer LinPos(30),LinEnd(30)
      data tiny/0.01/
c
c............. set default values first 
c
c____________ number of timesteps
      numsteps = 1000
c____________ timestep in femtoseconds (fs)
      tstep = 1.0 
c____________ desired system temperature in Kelvin
      dtemp = 300
c____________ integration algorithm to be used
      ialgorithm = 0
c____________time constant for thermostats in picoseconds
      tau = 0.0
c____________ statistics and trajectory printing intervals (in timesteps)
      traj_print = 500
      stat_print = 500
c_____________and format
      traj_fmt = 2
c____________ shells
      dshell_model = 0

c...... Seeks for the box marker: [.<MDcontrol>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<MDcontrol>',12,NFIL,iErr)
      if(iErr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      do_md=.true.
      iw=0
 20   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0) go to 50
      if(index(line,'.<End>').ne.0) go to 100

      if(index(line(LinPos(1):LinEnd(1)),'numsteps').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) numsteps
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'tstep').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) tstep
         iw=iw+1
         tstep = tstep * ps_fs

      else if(index(line(LinPos(1):LinEnd(1)),'dtemp').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) dtemp
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'algorithm').ne.0) then
         if(NumLin.lt.2) go to 50
         if(index(line(LinPos(2):LinEnd(2)),'nve').ne.0) then
            ialgorithm = 0
         else if(index(line(LinPos(2):LinEnd(2)),'evn_nvt').ne.0) then
            ialgorithm = 1
         else if(index(line(LinPos(2):LinEnd(2)),'ber_nvt').ne.0) then
            ialgorithm = 2
         else if(index(line(LinPos(2):LinEnd(2)),'hov_nvt').ne.0) then
            ialgorithm = 3
         else if(index(line(LinPos(2):LinEnd(2)),'stochastic').ne.0)then
            ialgorithm = 4
         end if
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'tau').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) tau
         iw=iw+1
         tau = tau * ps_fs

      else if(index(line(LinPos(1):LinEnd(1)),'statistics').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) stat_print
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'trajectory').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) traj_print
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'vel_key').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) vel_key
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'traj_fmt').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) traj_fmt
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'shells').ne.0) then
         if(NumLin.lt.2) go to 50
         if(index(line(LinPos(2):LinEnd(2)),'dynamic').ne.0) then
            dshell_model = 0
         else if(index(line(LinPos(2):LinEnd(2)),'relax').ne.0) then
            dshell_model = 1
         end if
         iw=iw+1

      end if

      go to 20

c_________ warning messages
 50   write(9,*) 'WARNING! Error while reading Box <MDcontrol>!'
      write(9,*) 'Using default values for the rest of the parameters'
      go to 101

c_________ print out the final set of parameters
 100  write(9,*)
     &     '...........<MDcontrol> box is read correctly ..........'

 101  write(9,*) 'number of timesteps   = ',numsteps
      write(9,*) 'time step = ',tstep,' fs'
      write(9,*) 'temperature = ',dtemp
      
      if(ialgorithm.eq.0) write(9,*) 'algorithm: nve'
      if(ialgorithm.eq.1) write(9,*) 'algorithm: nvt evans'
      if(ialgorithm.eq.2) write(9,*)'algorithm: nve berensden',
     &     ' - time constant = ',tau, ' fs'
      if(ialgorithm.eq.3) write(9,*)'algorithm: nve hoover',
     &     ' - time constant = ',tau, ' fs'
      if(ialgorithm.eq.4) write(9,*) 'algorithm: stochastic'

      write(9,*) 'statistics interval = ',stat_print
      write(9,*) 'trajectory interval  = ',traj_print

      write(9,'(a/)')
     &'################################################################'
      return
 40   write(9,*)'WARNING! Box <MDcontrol> not found! No MD then!'
      write(9,'(a/)')
     &'################################################################'
      return
      end

      SUBROUTINE Tolerc(NFIL,iPrnt)
c......................................................................
c.....Read in the file UNIT=NFIL the box <Toleranc>
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2
      integer LinPos(30),LinEnd(30)
c
c............. set default values first 

c____________ do lateral forces on the tip
      do_lat = .false.
c
c____________ amount of output
      iPrnt=1
c____________ max number of line searches
      max_opt=100
c____________ tolerances for relaxation: energy (eV), coordinates (A) and 
c                                       forces (eV/A)
      en_tol =0.1d-05
      crd_tol=0.01
      frc_tol=0.1
c____________ max energy change during 1-dim search (eV)
      es_tol=0.05
      es0_tol=es_tol
c____________ set shells to be relaxed even for free cores
      move_shells=1
c____________ do not test forces or input
      do_test=.false.
      do_test_tip=.false.
      do_test_input=.false.
      step0=0.0001
      shft(1)=0.0
      shft(2)=0.0
      shft(3)=0.0001
c____________ direction test: energy versus a single displacement coordinate
      do_test_dir=.false.
      dir_step=0.01
      dir_start=-0.5
      dir_end=0.5
      n_dir_steps=(dir_end-dir_start)/dir_step+1
      dir_num=1
c___________ write energy+forces during the course of minimisation to name.31
      write_en_frc=.false.
c____________ write/read forces acting on the frozen tip atoms
      write_force=.false.
      read_force=.false.
      force_file='                      '
      lengf=22
c____________ update RST file during relaxation or not
      update_RST=.false.
c____________ do g98-file with coordinates in a.u. and charges
      write_g98=.false.
c____________ do xyz-files at the end of relaxation
      write_xyz=.false.
c____________movie style continuous xyz file
      do_movie=.false.
c____________ which optimisation method
      bfgs=.false.
      stpmax=0.8d0
      cg=.false.
      method_cg='fl_reeves'
c____________ shaking of the atomic coordinate corresponding to the
c             maximum atomic force: it is done if BFGS/CG gets stuck.
      shake=.false.
      shake_step=0.01
c
c...... Seeks for the box marker: [.<Toleranc>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Toleranc>',11,NFIL,iErr)
      if(iErr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      iw=0
 20   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0) go to 50
      if(index(line,'.<End>').ne.0) go to 100

      if(index(line(LinPos(1):LinEnd(1)),'en_tol').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) en_tol
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &              '...> found (',iw,') new value for en_tol= ',en_tol

      else if(index(line(LinPos(1):LinEnd(1)),'es_tol').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) es_tol
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &               '...> found (',iw,') new value for es_tol= ',es_tol
         if(NumLin.eq.3) then
            read(Line(LinPos(3):),*,END=50,ERR=50) es0_tol
            iw=iw+1
            write(9,'(a,i2,a,e12.6)')
     &            '...> found (',iw,') new value for es0_tol= ',es0_tol
         else
            es0_tol=es_tol
         end if

      else if(index(line(LinPos(1):LinEnd(1)),'crd_tol').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) crd_tol
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &             '...> found (',iw,') new value for crd_tol= ',crd_tol

      else if(index(line(LinPos(1):LinEnd(1)),'do_lateral').ne.0) then
         do_lat=.true.
         iw=iw+1

      else if(index(line(LinPos(1):LinEnd(1)),'frc_tol').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) frc_tol
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &             '...> found (',iw,') new value for frc_tol= ',frc_tol

      else if(index(line(LinPos(1):LinEnd(1)),'max_opt').ne.0) then
         if(NumLin.lt.2) go to 50
         read(Line(LinPos(2):),*,END=50,ERR=50) max_opt
         iw=iw+1
         write(9,'(a,i2,a,i5)')
     &             '...> found (',iw,') new value for max_opt= ',max_opt

      else if(index(line(LinPos(1):LinEnd(1)),'update_RST').ne.0) then
         update_RST=.true.
         iw=iw+1
         write(9,'(a,i2,a,l1)')
     &    '...> found (',iw,') new value for update_RST = ',update_RST


      else if(index(line(LinPos(1):LinEnd(1)),'test').ne.0) then
         if(NumLin.eq.1) go to 50
         iw=iw+1
         if(index(line(LinPos(2):LinEnd(2)),'atom').ne.0) then
            do_test=.true.
            if(NumLin.gt.2) read(Line(LinPos(3):),*,END=50,ERR=50) step0
            write(9,'(a,i2,a,l1,a,f10.5)') '...> found (',iw,
     &              ') new value for do_test= ',do_test,
     &              ' with step0 = ',step0
         else if(index(line(LinPos(2):LinEnd(2)),'tip').ne.0) then
            do_test_tip=.true.
            if(NumLin.gt.2) read(Line(LinPos(3):),*,END=50,ERR=50) shft
            write(9,'(a,i2,a,l1,a,3(x,f10.5))') '...> found (',iw,
     &              ') new value for do_test_tip= ',do_test_tip,
     &              ' with shift = ',shft
         else if(index(line(LinPos(2):LinEnd(2)),'input').ne.0) then
            do_test_input=.true.
            write(9,'(a,i2,a,l1,a,f10.5)') '...> found (',iw,
     &              ') new value for do_test_input= ',do_test_input
         else if(index(line(LinPos(2):LinEnd(2)),'direct').ne.0) then
            do_test_dir=.true.
            write(9,'(a,i2,a,l1,a,f10.5)') '...> found (',iw,
     &              ') new value for do_test_dir= ',do_test_dir
            if(NumLin.eq.6) read(Line(LinPos(3):),*,END=50,ERR=50) 
     &                                dir_num,dir_start,dir_end,dir_step
            n_dir_steps=(dir_end-dir_start)/dir_step+1
            do_test_dir=.true.
            if(dir_end.le.dir_start.or.dir_num.lt.1) do_test_dir=.false.
         else
            write(9,'(a)')
     &           'WARNING! Test option ignored! Wrong 2nd keyword!'
            write(*,'(a)')
     &           'WARNING! Test option ignored! Wrong 2nd keyword!'
         end if

      else if(index(line(LinPos(1):LinEnd(1)),'write_energy_forces')
     &                                                       .ne.0) then
         write_en_frc=.true.
         iw=iw+1
         write(9,'(a,i2,a,l1)') '...> found (',iw,
     &        ') new value for write_en_frc= ',write_en_frc

      else if(index(line(LinPos(1):LinEnd(1)),'write_force').ne.0) then
         if(read_force) then
            write(*,*)
     &       'WARNING! Found [write_force] after read_force=T. Ignored!'
            write(9,*)
     &       'WARNING! Found [write_force] after read_force=T. Ignored!'
         else
            if(NumLin.lt.2) go to 50
            ll=LinEnd(2)-LinPos(2)+1
            if(ll.gt.22) go to 50
            lengf=22-ll+1
            force_file(lengf:)=Line(LinPos(2):LinEnd(2))
            iw=iw+1
            write(*,'(a)')'... opening as output '//force_file(lengf:)
            open(4,FILE=force_file(lengf:),status='unknown')
            write_force=.true.
            write(9,'(a,i2,a,l1,a)') '...> found (',iw,
     &              ') new value for write_force= ',write_force,
     &              ' with filename = '//force_file(lengf:)
         end if

      else if(index(line(LinPos(1):LinEnd(1)),'read_force').ne.0) then
         if(write_force) then
            write(*,*)
     &       'WARNING! Found [read_force] after write_force=T. Ignored!'
            write(9,*)
     &       'WARNING! Found [read_force] after write_force=T. Ignored!'
         else
            if(NumLin.lt.2) go to 50
            ll=LinEnd(2)-LinPos(2)+1
            if(ll.gt.22) go to 50
            lengf=22-ll+1
            force_file(lengf:)=Line(LinPos(2):LinEnd(2))
            iw=iw+1
            write(*,'(a)')'... opening as input '//force_file(lengf:)
            open(4,FILE=force_file(lengf:),status='old',err=30)
            go to 35
 30         write(6,'(a)')
     &           'FATAL! File '//force_file(lengf:)//' does not exist!'
            go to 50
 35         read_force=.true.
            write(9,'(a,i2,a,l1,a)') '...> found (',iw,
     &              ') new value for read_force= ',read_force,
     &              ' with filename = '//force_file(lengf:)
         end if

      else if(index(line(LinPos(1):LinEnd(1)),'shake').ne.0) then
         shake=.true.
         if(NumLin.gt.1) read(Line(LinPos(2):),*,END=50,ERR=50) 
     &                                                      shake_step
         iw=iw+1
         write(9,'(a,i2,a,l1,a,f10.5)')
     &      '...> found (',iw,') new value for shake= ',shake,
     &      ' with shake_step = ',shake_step

      else if(index(line(LinPos(1):LinEnd(1)),'xyz').ne.0) then
         write_xyz=.true.
         iw=iw+1
         write(9,'(a,i2,a,l1)')
     &    '...> found (',iw,') new value for write_xyz = ',write_xyz

      else if(index(line(LinPos(1):LinEnd(1)),'movie').ne.0) then
         do_movie=.true.
            iw=iw+1
            write(9,'(a,i2,a)')
     &           '...> found (',iw,') movie file will be produced.' 
             
      else if(index(line(LinPos(1):LinEnd(1)),'g98').ne.0) then
         write_g98=.true.
         iw=iw+1
         write(9,'(a,i2,a,l1)')
     &    '...> found (',iw,') new value for write_g98 = ',write_g98

      else if(index(line(LinPos(1):LinEnd(1)),'shell').ne.0) then
         if(NumLin.lt.2) go to 50
         if(index(line(LinPos(2):LinEnd(2)),'moveall').ne.0) then
            move_shells=2
         else if(index(line(LinPos(2):LinEnd(2)),'frozenall').ne.0) then
            move_shells=0
         else if(index(line(LinPos(2):LinEnd(2)),'follow').ne.0) then
            move_shells=1
         end if
         iw=iw+1
         write(9,'(a,i2,a,i1)')
     &    '...> found (',iw,') new value for move_shells = ',move_shells

      else if(index(line(LinPos(1):LinEnd(1)),'optim').ne.0) then
         do_test=.false.
         if(NumLin.lt.2) go to 50
         if(index(line(LinPos(2):LinEnd(2)),'bfgs').ne.0) then
            bfgs=.true.
            if(NumLin.ge.3) 
     &          read(line(LinPos(3):LinEnd(3)),*,err=50,end=50) stpmax
            iw=iw+1
            write(9,'(a,i2,a,l1)') 
     &           '...> found (',iw,') new value for bfgs = ',bfgs
         else if(index(line(LinPos(2):LinEnd(2)),'conj').ne.0) then
            cg=.true.
            if(NumLin.ge.3) then
               if(index(line(LinPos(3):LinEnd(3)),'polak').ne.0)
     &              method_cg='polak_rib'
            end if
            iw=iw+1
            write(9,'(a,i2,a,l1,a,a)') 
     &           '...> found (',iw,') new value for cg = ',cg,
     &                 ' method= ',method_cg
         else if(index(line(LinPos(2):LinEnd(2)),'steep').ne.0) then
            cg=.true.
            method_cg='steep_des'
            iw=iw+1
            write(9,'(a,i2,a,l1,a,a)') 
     &           '...> found (',iw,') new value for cg = ',cg,
     &                 ' method= ',method_cg
         end if

      else if(index(line(LinPos(1):LinEnd(1)),'printing').ne.0) then
         if(NumLin.lt.2) go to 50
         if(index(line(LinPos(2):LinEnd(2)),'huge').ne.0) then
            iPrnt=10
         else if(index(line(LinPos(2):LinEnd(2)),'large').ne.0) then
            iPrnt=8
         else if(index(line(LinPos(2):LinEnd(2)),'medium').ne.0) then
            iPrnt=5
         else if(index(line(LinPos(2):LinEnd(2)),'small').ne.0) then
            iPrnt=3
         else if(index(line(LinPos(2):LinEnd(2)),'tiny').ne.0) then
            iPrnt=1
         else if(index(line(LinPos(2):LinEnd(2)),'no').ne.0) then
            iPrnt=0
         end if
         iw=iw+1
         write(9,'(a,i2,a,i5)')
     &                '...> found (',iw,') new value for iPrnt= ',iPrnt

      end if
      go to 20

c_________ warning messages
 40   write(9,*) 
     &         'WARNING! Box <Toleranc> not found! Using default values'
      go to 100
 50   write(9,*) 'WARNING! Error while reading Box <Toleranc>!'
      write(9,*) 'Using default values for the rest of the parameters'

c____________ setting up default optimisation method
 100  if((.not.do_test).and.(.not.bfgs).and.(.not.cg)) bfgs=.true.

c_________ print out the final set of parameters
      write(9,'(a)')
     &     '...........<Toleranc> box is read correctly ..........'
c________if movie is on then activate xyz-writing
      if(do_movie) write_xyz=.true.

      write(9,'(a,i2)') 'iPrnt   = ',iPrnt
      write(9,'(a,i5)') 'max_opt = ',max_opt
      write(9,'(a,i1)') 'move_shells = ',move_shells
      write(9,'(a,l1)') 'write_xyz = ',write_xyz
      write(9,'(a,l1)') 'do_movie  = ',do_movie
      write(9,'(a,l1)') 'write_g98 = ',write_g98
      write(9,'(a,l1)') 'update_RST = ',update_RST
      write(9,'(a,l1)') 'write_en_frc = ',write_en_frc
      write(9,'(a,l1,a)') 'write_force = ',write_force,
     &     ' with filename= '//force_file(lengf:)
      write(9,'(a,l1,a)') 'read_force = ',read_force,
     &     ' with filename= '//force_file(lengf:)
      shake_step=shake_step*A_au
      write(9,'(a,l1,a,f10.5,a)')'shake = ',shake,
     ,     ' with shake_step= ',shake_step*au_A,' A'
      write(9,'(a,l1,a,f10.5)') 'bfgs = ',bfgs,' with stpmax = ',stpmax
      write(9,'(a,l1,a,a)') 'cg = ',cg, ' with method= ',method_cg
      en_tol=en_tol*eV_au
      write(9,'(2(a,e12.6),a)') 
     &       'en_tol  = ',en_tol*au_eV,' (eV)   or = ',en_tol,' (au)'
      es_tol=es_tol*eV_au
      write(9,'(2(a,e12.6),a)') 
     &       'es_tol  = ',es_tol*au_eV,' (eV)   or = ',es_tol,' (au)'
      es0_tol=es0_tol*eV_au
      write(9,'(2(a,e12.6),a)') 
     &       'es0_tol  = ',es0_tol*au_eV,' (eV)   or = ',es0_tol,' (au)'
      unit=eV_au/A_au
      frc_tol=frc_tol*unit
      write(9,'(2(a,e12.6),a)') 
     &       'frc_tol = ',frc_tol/unit,' (eV/A) or = ',frc_tol,' (au)'
      crd_tol=crd_tol*A_au
      write(9,'(2(a,e12.6),a)') 
     &       'crd_tol = ',crd_tol*au_A,' (A)    or = ',crd_tol,' (au)'
c
c.......... test options
c
      write(9,'(a)')'... test options:'
      step0=step0*A_au
      shft(1)=shft(1)*A_au
      shft(2)=shft(2)*A_au
      shft(3)=shft(3)*A_au
      write(9,'(a,l1)')'do_test_input = ',do_test_input
      write(9,'(a,l1,2(a,f10.5),a)')'do_test = ',do_test,
     ,     ' with step0= ',step0*au_A,' (A) or = ',step0,' (au)'
      write(9,'(a,l1,a,3(x,f10.5),a)')'do_test_tip = ',do_test_tip,
     ,     ' with shift= [',shft,'] (au)'
      if(do_test_dir) then
         dir_start=dir_start*A_au
         dir_end=dir_end*A_au
         dir_step=dir_step*A_au
         write(9,'(a,l1,2(a,f10.5),a,i3,a,i3)') 'do_test_dir = ',
     &        do_test_dir,' in (au) [',dir_start,',',dir_end,
     &      '] using ',n_dir_steps,' points for direction ',dir_num
      else
         write(9,'(a,l1)') 'do_test_dir = ',do_test_dir
      end if
      write(9,'(a/)')
     &'################################################################'
      return
      end

      SUBROUTINE ShellPar(NFIL,KodErr)
c......................................................................
c.....Read in the file UNIT=NFIL the box <ShellPar>
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2,cha
      integer LinPos(30),LinEnd(30)
      data tiny/0.01/
c
c...... Seeks for the box marker: [.<ShellPar>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<ShellPar>',11,NFIL,iErr)
      if(iErr.eq.1) go to 100
c
c......... Read the box contents .......................................
c
      I=0
 20   I=I+1
      if(I.gt.N0KD) then
         write(*,*) 'FATAL! Too many species!'
         write(9,*) 'FATAL! Too many species!'
         go to 100
      end if

c___________ General information: get the atom label and the number
c            NATM(i) in the Mendeleev's table,as well as the 3rd letter
 25   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0.or.line(LinPos(1):LinEnd(1)).eq.'.<End>') go to 50

c_______ check if species recognised
      call AtLabel_m(Line,LinPos(1),LinEnd(1),na2,nzv3(i),NATM(i),iErr)
      if(iErr.eq.1) go to 99

c_ _ _ _ _ the atomic label was recognized correctly !
      Species(I)=na2//nzv3(i)
      WRITE(9,'(a20,a2,a31)')'...The atom ',Species(i),
     &                       '  was recognized correctly ....'
c____________ read: 
c            smass   - mass (a.m.u.) 
c            CoreQA  - core charge
c            ShellQA - shell charge
c            Spring  - the spring constant
c  Shell_Ref(species) = .false. if the shell is not present on the species.
c
      Read(Line(LinPos(2):),*,END=100,ERR=100) 
     &            smass(I,1),CoreQA(I),smass(I,2),ShellQA(I),Spring(I)
      if(abs(ShellQA(I)).lt.tiny .or. Spring(I).lt.tiny) then
         Shell_Ref(I)=.false.
         ShellQA(I)=0.0
         Spring(I)=0.0
      else
         Shell_Ref(I)=.true.
         if(ialgorithm.ne.0) go to 101
      end if
      write(9,'(i2,x,a3,x,l1,x,3(1x,e12.6))') 
     &      I,Species(I),Shell_Ref(I),CoreQA(I),ShellQA(I),Spring(I)
      Spring(I)=Spring(I)*eV_au/A_au**2
      go to 20

 50   KINDS=I-1
      write(9,'(a,i2)')'... species found = ',KINDS
      write(9,'(a)')
     &  '.........<ShellPar> box is read correctly ........'
      write(9,'(a/)')
     &'################################################################'
      return
c.......... ERROR messages ..........................................
 99   WRITE(9,'(a/)')'FATAL! Atomic species not recognized'
 101  if(ialgorithm.ne.0) then
         WRITE(9,'(a/)')'FATAL! Shells with NVE only !!! '
      end if
100   WRITE(9,'(a/)')'FATAL! Box <ShellPar> is WRONG or absent !!! '
      KodErr=1
      write(9,'(a/)')
     &'################################################################'
      return
      end

      SUBROUTINE SpeciesTypes(NFIL,KodErr)
c......................................................................
c.....Read in the file UNIT=NFIL the box <SpeciesTypes>.This gives
c     information concerning species and interactions, i.e. which
c     species are associated with tersoff interactions or many-body
c     ones. By default, all interactions are pairwise. 
c......................................................................
c Tersoff species:   only interact between themselves via Tersoff force 
c                    field
c Many-body species: only interact between themselves via bond, angle, 
c                    torsion and out-of-plane interactions
c Pair-wise:         between any atoms is possible.
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2
      integer LinPos(30),LinEnd(30)

c...... default
      do_pair=.true.
      do_mbody=.false.
      do_tersoff=.false.
      do i=1,KINDS
         SpecType(i)='pp'
      end do

c...... Seeks for the box marker: [.<SpeciesTypes>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<SpeciesTypes>',15,NFIL,iErr)
      if(iErr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      iw=0
 20   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0) go to 50
      if(index(line,'.<End>').ne.0) go to 100

      iw=iw+1
      if(index(line(LinPos(1):LinEnd(1)),'Tersoff_Species').ne.0) then
         if(NumLin.gt.1) then
            do i=2,NumLin
               call atom_type(Line,LinPos(i),LinEnd(i),is,iErr)
               if(iErr.eq.1) then
                  write(9,'(a)') 'ERROR in reading species: '//
     &                 Line(LinPos(i):LinEnd(i))
                  KodErr=1
               else
                  SpecType(is)='tf'
                  write(9,'(a,i3,3a)') 'Species(',is,')= ',
     &                 Species(is),' is Tersoff related: '//SpecType(is)
                  do_tersoff=.true.
               end if
            end do
         end if
      else if(index(line(LinPos(1):LinEnd(1)),
     &                                    'ManyBody_Species').ne.0) then
         if(NumLin.gt.1) then
            do i=2,NumLin
               call atom_type(Line,LinPos(i),LinEnd(i),is,iErr)
               if(iErr.eq.1) then
                  write(9,'(a)') 'ERROR in reading species: '//
     &                 Line(LinPos(i):LinEnd(i))
                  KodErr=1
               else
                  SpecType(is)='mb'
                  write(9,'(a,i3,3a)') 'Species(',is,')= ',
     &              Species(is),' is Many-Body related: '//SpecType(is)
                  do_mbody=.true.
               end if
            end do
         end if
      end if
      go to 20

c_________ warning messages
 50   write(9,*) 'WARNING! Error while reading Box <SpeciesTypes>!'
      KodErr=1
      go to 101

c_________ print out the final set of parameters
 100  write(9,*)
     &     '...........<SpeciesTypes> box is read correctly ..........'

 101  write(9,'(/a)') '===> Distribution of species over Types <===='
      write(9,'(a)') '---------------------------------------------'
      ii=0
      jj=0
      do i=1,KINDS
         write(9,'(i3,x,a)') i,Species(i)//' Type = '//SpecType(i)
         if(SpecType(i).eq.'tf') ii=ii+1
         if(SpecType(i).eq.'mb') jj=jj+1
      end do
      if(ii.eq.KINDS .or. jj.eq.KINDS) do_pair=.false.

      write(9,'(a/)') '---------------------------------------------'

      if(do_tersoff) then
         write(9,'(a)') 'WARNING: Tersoff IS expected!'
      else
         write(9,'(a)') 'WARNING: Tersoff is NOT expected!'
      end if

      if(do_mbody) then
         write(9,'(a)') 'WARNING: many-body IS expected!'
      else
         write(9,'(a)') 'WARNING: many-body is NOT expected!'
      end if

      if(do_pair) then
         write(9,'(a)') 'WARNING: pair-wise IS expected!'
      else
         write(9,'(a)') 'WARNING: pair-wise is NOT expected!'
      end if
      write(9,'(a/)')
     &'################################################################'
      return

c.................. no box found
 40   write(9,*)
     &    'WARNING! Box <SpeciesTypes> not found! Only Pair-wise then'
      write(9,'(a/)')
     &'################################################################'
      end

      SUBROUTINE BondToleranc(NFIL,iPrnt,KodErr1,KodErr)
c......................................................................
c.....Read in the file UNIT=NFIL the box <BondToleranc> and 
c     generate the bond table
c......................................................................
cc      include 'shell.inc'
cc------NB 'tersoff.inc' includes 'shell.inc'
      include 'tersoff.inc'
      character Line*120,na2*2
      character dmmy(N0KD*N0KD)
      integer LinPos(30),LinEnd(30)
      double precision e(3),dist1,dist2
      logical in_window,define_z_min,define_z_max
      KodErr1=0

c....... default

      Yes_check_Central=.false.
      z_win_min= 1000.0
      z_win_max=-1000.0
      Pair_dist_max=0.0
c
c...... Seeks for the box marker: [.<BondToleranc>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<BondToleranc>',15,NFIL,iErr)
      if(iErr.eq.1) then
         KodErr1=1
         write(9,'(a/)')'WARNING! Box <BondToleranc> is absent!'
         write(6,*)'WARNING! Box <BondToleranc> is absent!'
         return
      end if
c
c......... Read the box contents .......................................
c
      i=0
 20   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0.or.line(LinPos(1):LinEnd(1)).eq.'.<End>') go to 30
      if(NumLin.eq.1) then
         if(line(LinPos(1):LinEnd(1)).eq.'do_check_central') then
            Yes_check_Central=.true.
         else
            write(9,*)'ERROR: Problem with do_check_central'
            go to 100
         end if
         goto 20
      else if(NumLin.eq.2) then
         if(line(LinPos(1):LinEnd(1)).eq.'z_window_min') then
            read(line(LinPos(2):LinEnd(2)),*) z_win_min
            write(9,*)'z-window-min',z_win_min
            z_win_min=z_win_min*A_au
            define_z_min=.true.
         else if(line(LinPos(1):LinEnd(1)).eq.'z_window_max') then
            read(line(LinPos(2):LinEnd(2)),*) z_win_max
            write(9,*)'z-window-max',z_win_max
            z_win_max=z_win_max*A_au
            define_z_max=.true.
         else
            write(9,*)'ERROR: Problem with z-window'
            go to 100
         end if
         goto 20
      end if

      i=i+1
      if(i.gt.(N0KD*N0KD)) then
         write(9,*) 'FATAL! Too many pairs of species!'
         go to 100
      end if

c_________ read the pair of species and the window for them

      call atom_type(Line,LinPos(1),LinEnd(1),is1,iErr)
      if(iErr.eq.1) go to 100
      if(.not.(SpecType(is1).eq.'tf' .or. SpecType(is1).eq.'mb')) then
         write(9,'(a)') 'ERROR! Wrong 1st species type '//
     ,                               SpecType(is1)//', see below:' 
         write(9,'(a)') Line
         go to 100
      end if
      mdv_pair(i,1)=Species(is1)
      pair(i,1)=is1
      call atom_type(Line,LinPos(2),LinEnd(2),is2,iErr)
      if(iErr.eq.1) go to 100
      if(.not.(SpecType(is2).eq.'tf' .or. SpecType(is2).eq.'mb')) then
         write(9,'(a)') 'ERROR! Wrong 2nd species type '//
     ,                               SpecType(is2)//', see below:' 
         write(9,'(a)') Line
         go to 100
      end if
      mdv_pair(i,2)=Species(is2)
      pair(i,2)=is2
      
      if(NumLin.eq.3) then
         min_bond(i)=0.0
         read(line(LinPos(3):LinEnd(3)),*) max_bond(i)
      elseif (NumLin.eq.4) then
         read(line(LinPos(3):LinEnd(3)),*) min_bond(i)
         read(line(LinPos(4):LinEnd(4)),*) max_bond(i)
      end if

      max_bond(i) = max_bond(i)*A_au
      min_bond(i) = min_bond(i)*A_au
      if(max_bond(i).gt.Pair_dist_max) Pair_dist_max=max_bond(i)
      write(9,'(a,i2,a,3(a,f10.5))') 'BondToleranc: ',i,
     &     ' {'//mdv_pair(i,1)//','//mdv_pair(i,2)//'}',
     &     ' D_min=',min_bond(i),', D_max=',max_bond(i),
     ,      ' MAX_dist=',Pair_dist_max   
      go to 20

c..... check if the z-window was correctly specified

 30   if(Yes_check_Central) then
         if(define_z_min.and.define_z_max) then
            if (z_win_min.gt.z_win_max) then
               write(9,*)'ERROR: z-window incorrectly specified'
               go to 100
            end if
         endif
      end if

c.....loop over all atoms in the molecule; 
c               total number of pairs found = n_pair
      n_pair=i
      
c.....find pairs of bonded atoms
      
c______________ multiply the system if 'bulk' or 'surface' (i.e. when PBC)
      call create_surrounding(Natoms_sur)

c_______________ create nn table (in: bond(j,jj) and nnn(j) ) for each atom j

c______________________ do it for Tersoff-related species if any
      if(do_tersoff) call neighbour(Natoms_sur,'tf',KodErr)

c_______________________ do it for Many-bondy-related species if any
      if(do_mbody) call neighbour(Natoms_sur,'mb',KodErr)

c......... change the atom type (central/noncentral) by checking the nnn(i)
c          against the default value nnn_default(i) and whether the atom
c          is inside the z window (e.g. to automatically sort out atoms at
c          the bottom of the slab and at the top of the tip - be careful with the
c          latter one as the tip may move along z)

      if(.not.Yes_check_Central) go to 70

      do i=1,Natom
         is=ISRT(i)
         if(SpecType(is).ne.'tf') go to 60
         if(Species(is)(3:3).ne.'#') then

            in_window=.false.
            if(z(i).le.z_win_max .and. z(i).ge.z_win_min) 
     &                                              in_window=.true.

            if(nnn(i).lt.nnn_default(is) .and. (.not.in_window)) then
               central_atom(i)=.false.

               do js=1,KINDS
                  if(SpecType(js).eq.'tf') then
                     if(Species(js)(1:2).eq.Species(is)(1:2) .and.
     &                    Species(js)(3:3).eq.'#') then
                        ISRT(i)=js
                        go to 55
                     end if
                  end if
               end do
               write(9,*)'ERROR! Species '//Species(1:2)//'# not found'
               go to 100
 55            write(9,'(a,i5,a)')
     &              'WARNING: atom ',i,' changed into '//Species(js)

            end if
         end if
 60   end do

 70   write(9,'(a/)')
     &'################################################################'
      return
c.......... ERROR messages ..........................................
100   WRITE(9,'(a/)')'FATAL! Box <BondToleranc> is WRONG !!! '
      WRITE(6,*)'FATAL! Box <BondToleranc> is WRONG !!! '
      KodErr=1
      write(9,'(a/)')
     &'################################################################'
      return
      end

      SUBROUTINE Coord(NFIL,KodErr,restart,ita,ica)
c......................................................................
c... Read in the file UNIT=NFIL the boxes <Coord>
c......................................................................
cc      include 'shell.inc'
cc------NB 'tersoff.inc' includes 'shell.inc'
      include 'tersoff.inc'
      character Line*120,na3*3,na2*2,cha*1,cha6*6, which*2,cha4*4
      integer LinPos(30),LinEnd(30)
      logical restart,yes_ft,yes_tb,yes_ta,yes_ca,yes_cb,error
      logical move, rotate
      double precision vec(3), rot(3), cen(3),inx, iny, inz

c...... Seeks for the box marker: [.<Coord>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Coord>',8,NFIL,iErr)
      if(iErr.eq.1) go to 100
      error=.false.
c
c_________ convert positions of the sphere and the plane into a.u.
      if(Do_Image) then
         if(do_sphere) then
            rsx=r_sph(1)*a_au
            rsy=r_sph(2)*a_au
            rsz=(rz+rad)*a_au
            rads=rad*a_au
            write(9,'(/a,3(f10.5,x),a)')
     &           'Sphere is at (a.u.) ==> [',rsx,rsy,rsz,']'
            write(9,'(a,f10.5)')'Sphere radius is (a.u.) ==> ',rads
         end if
         zp=z_plane*a_au
         write(9,'(a,f10.5)')'Plane is at (a.u.) ==> ',zp
      end if
c
c..................... read box: species, coordinates, relaxation flags:
c   Five types of atoms are allowed:
c
c Atoms in the tip:
c^^^^^^^^^^^^^^^^^^^
c (a) [ft]=<frozen-tip>  - frozen atoms in the tip, IMAGE does not 
c                       see them at all (are not ported to)
c                       bare numbers: [nft1,nft2]
c (b) [tb]=<tip-buffer> - frozen atoms in the tip
c                       bare numbers: [ntb1,ntb22]
c (c) [ta]=<tip-atoms> - atoms in the tip which are allowed 
c                        to relax and are polarising charges for IMAGE
c                        bare numbers: [nta1,nta2]
c Atoms in the cluster:
c^^^^^^^^^^^^^^^^^^^^^^
c (d) [ca]=<cluster-atoms> - atoms in the cluster which are allowed 
c                        to relax and are polarising charges for IMAGE
c                        bare numbers: [nca1,nca2]
c (e) [cb]=<cluster-buffer> - frozen atoms in the cluster
c                        bare numbers: [ncb1,ncb2]
c
      Yes_Tip=.false.
      yes_ft=.false.
      yes_tb=.false.
      yes_ta=.false.
      yes_ca=.false.
      yes_cb=.false.
      move=.false.
      rotate=.false.
      scan=.false.
      which='  '
      ica=0
      ift=0
      icb=0
      ita=0
      itb=0
      ifr=0
      inx=0.0
      iny=0.0
      inz=0.0

c_______ general flag for existence of atoms belonging to the Quantum Cluster
      exist_QC=.false.
      iQMC_at=0

c     itft=total charges (cores + shells) in frozen tip

      itft=0
      Nshell=0
      
      do i=1,3
         vec(i)=0.0
         rot(i)=0.0
         cen(i)=0.0
      end do
  
c........................................................................
c.......... STARTING READING IN COORDINATES
c........................................................................
      i=0
 20   i=i+1
      if(i.gt.N0LT) then
         write(*,*)'FATAL! Too many cores found!'
         go to 100
      end if
      
 21   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(index(Line,'<End>').ne.0)  go to 50
      if(iErr.ne.0) go to 50

c________check if tip translation or rotation is active
c__________translation of tip, vec - array with translation in x, y, z

      if(index(Line(LinPos(1):LinEnd(1)),'move').ne.0) then
         move=.true.
         read(Line(LinPos(2):),*,END=50,ERR=50) vec(1), vec(2), vec(3)
         do ii=1,3
            vec(ii)=vec(ii)*A_au
         end do
c........move the sphere if IMAGE is on
         if(Do_Image .and. do_sphere) then
            R_Sph(1)=R_Sph(1)+vec(1)*au_A
            R_Sph(2)=R_Sph(2)+vec(2)*au_A
            Rz=Rz+vec(3)*au_A
            rsx=r_sph(1)*A_au
            rsy=r_sph(2)*A_au
            rsz=(rz+rad)*A_au
            write(*,'(a,3(x,f10.5),a)')
     &           '... the sphere moved by ',(vec(j)*au_A,j=1,3),' A'
            write(9,'(a,3(x,f10.5),a)')
     &           '... the sphere moved by ',(vec(j)*au_A,j=1,3),' A'
         end if
         goto 21
      end if

c__________rotation of tip, rot - array with x,y,z rotations

      if(index(Line(LinPos(1):LinEnd(1)),'rotate').ne.0) then
         rotate=.true.
         read(Line(LinPos(2):),*,END=50,ERR=50) rot(1), rot(2), rot(3)
         if(restart.and.rotate) then
            rotate=.false.
            write(*,'(a)')'WARNING! You cannot rotate while restarting!'
         end if
         goto 21
      end if

c__________centre of rotation of tip, cen(i)

      if(index(Line(LinPos(1):LinEnd(1)),'centre').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) cen(1), cen(2), cen(3)
         do ii=1,3
            cen(ii)=cen(ii)*A_au
         end do
         goto 21
      end if

c_________check if scanning mode is activated

      if(index(Line(LinPos(1):LinEnd(1)),'scan').ne.0) then
         if(dynamic_tip.and.(.not.do_md)) then
            write(*,*)
     &       'WARNING! scan=.true. constradicts with dynamic_tip=.true.'
            write(*,*)'scan is set to .false. then!'
            scan=.false.
         else
            read(Line(LinPos(2):),*,END=50,ERR=50) (shift_sc(l),l=1,3)
            scan=.true.
         end if
         goto 21
      end if
c
c............... identify type of the atoms which follow: tip, atoms, buffer
c

      if(index(Line(LinPos(1):LinEnd(1)),'cluster-buffer').ne.0) then
         ncb1=i
         yes_cb=.true.
         if(which.eq.'ft') then
            nft2=i-1
            write(9,'(a,i5)')'... frozen tip atoms ended at i= ',nft2
         else if(which.eq.'tb') then
            ntb2=i-1
            write(9,'(a,i5)')'... buffer tip atoms ended at i= ',ntb2
         else if(which.eq.'ta') then
            nta2=i-1
            write(9,'(a,i5)')'... tip atoms ended at i= ',nta2
         else if(which.eq.'ca') then
            nca2=i-1
            write(9,'(a,i5)')'... cluster atoms ended at i= ',nca2
         end if
         write(9,'(a,i5)')'... cluster buffer atoms started at i= ',ncb1
         which='cb'
         go to 21
      else if(index(Line(LinPos(1):LinEnd(1)),'frozen-tip').ne.0) then
         nft1=i
         yes_ft=.true.
         Yes_Tip=.true.
         if(which.eq.'tb') then
            ntb2=i-1
            write(9,'(a,i5)')'... buffer tip atoms ended at i= ',ntb2
         else if(which.eq.'ta') then
            nta2=i-1
            write(9,'(a,i5)')'... tip atoms ended at i= ',nta2
         else if(which.eq.'ca') then
            nca2=i-1
            write(9,'(a,i5)')'... cluster atoms ended at i= ',nca2
         else if(which.eq.'cb') then
            ncb2=i-1
            write(9,'(a,i5)')
     &           '... cluster buffer atoms ended at i= ',ncb2
         end if
         write(9,'(a,i5)')'... frozen tip atoms started at i= ',nft1
         which='ft'
         go to 21
      else if(index(Line(LinPos(1):LinEnd(1)),'tip-buffer').ne.0) then
         ntb1=i
         yes_tb=.true.
         Yes_Tip=.true.
         if(which.eq.'ft') then
            nft2=i-1
            write(9,'(a,i5)')'... frozen tip atoms ended at i= ',nft2
         else if(which.eq.'ta') then
            nta2=i-1
            write(9,'(a,i5)')'... tip atoms ended at i= ',nta2
         else if(which.eq.'ca') then
            nca2=i-1
            write(9,'(a,i5)')'... cluster atoms ended at i= ',nca2
         else if(which.eq.'cb') then
            ncb2=i-1
            write(9,'(a,i5)')
     &           '... cluster buffer atoms ended at i= ',ncb2
         end if
         write(9,'(a,i5)')'... tip buffer atoms started at i= ',ntb1
         which='tb'
         go to 21
      else if(index(Line(LinPos(1):LinEnd(1)),'tip-atoms').ne.0) then
         nta1=i
         yes_ta=.true.
         Yes_Tip=.true.
         if(which.eq.'ft') then
            nft2=i-1
            write(9,'(a,i5)')'... frozen tip atoms ended at i= ',nft2
         else if(which.eq.'tb') then
            ntb2=i-1
            write(9,'(a,i5)')'... buffer tip atoms ended at i= ',ntb2
         else if(which.eq.'ca') then
            nca2=i-1
            write(9,'(a,i5)')'... cluster atoms ended at i= ',nca2
         else if(which.eq.'cb') then
            ncb2=i-1
            write(9,'(a,i5)')
     &           '... cluster buffer atoms ended at i= ',ncb2
         end if
         write(9,'(a,i5)')'... tip atoms started at i= ',nta1
         which='ta'
         go to 21
      else if(index(Line(LinPos(1):LinEnd(1)),'cluster-atoms').ne.0) 
     &        then
         nca1=i
         yes_ca=.true.
         if(which.eq.'ft') then
            nft2=i-1
            write(9,'(a,i5)')'... frozen tip atoms ended at i= ',nft2
         else if(which.eq.'tb') then
            ntb2=i-1
            write(9,'(a,i5)')'... buffer tip atoms ended at i= ',ntb2
         else if(which.eq.'ta') then
            nta2=i-1
            write(9,'(a,i5)')'... tip atoms ended at i= ',nta2
         else if(which.eq.'cb') then
            ncb2=i-1
            write(9,'(a,i5)')
     &           '... cluster buffer atoms ended at i= ',ncb2
         end if
         write(9,'(a,i5)')'... cluster atoms started at i= ',nca1
         which='ca'
         go to 21
      end if
c
c............. read atom of the type <which>. Note that @ at the end of
c  the atomic symbol means that this atom (the core together with its 
c  shell) belongs to the Quantum Cluster. The symbol @ is ignored in
c  identifying the particular species and is only used to generate
c  the logical flag array iQMC(i)=.true./.false. for atoms which do or 
c  do not belong to the QC.
c
c                i   - its number in the list of cores
c           ISRT(i)  - its types in the list of types (parameters)
c             id(i)  - type of the atom (atomic ID)
c             id2(i) - the same but integer from 1 to 5 (to facilitate MPI)
c
      id(i)=which
c_ _ _ _ _ _ _ _ _ _ _ the name of the atom:
      iQMC(i)=.false.
      if(index(Line(LinEnd(1):LinEnd(1)),'@').ne.0) then
         iQMC(i)=.true.
         LinEnd(1)=LinEnd(1)-1
         exist_QC=.true.
         iQMC_at=iQMC_at+1
      end if

c
c............. check if the atom is at the border of the cluster (important only
c              if do_tersoff=.true.), i.e. its 3rd charcater is #, in which case 
c              central_atom(atom)=.false.
c
      central_atom(i)=.true.
      if(index(Line(LinEnd(1):LinEnd(1)),'#').ne.0) then
         central_atom(i)=.false.
         LinEnd(1)=LinEnd(1)-1
      end if
c
c............. species recognition

      call atom_type(Line,LinPos(1),LinEnd(1),k,iErr)
      if(iErr.eq.1) go to 50
      ISRT(i)=k
      na3=Species(k)

c_____________ check if it contains a shell
      if(Shell_Ref(ISRT(I))) Nshell=Nshell+1

c_____________ read: 
c   x,y,z - coordinates of the core
c   fx,fy,fz - coordinates of the shell (stored temporarily here)
c   iRx,iRy,iRz - relaxation flags
c
 
c________________ reading from a restart file *.RST
      if(restart) then
         Read(Line(LinPos(2):),*,end=50,err=100) 
     &           x(i),y(i),z(i),iRx(i),iRy(i),iRz(i),
     &           fx(i),fy(i),fz(i)
         fx(i)=fx(i)*A_au
         fy(i)=fy(i)*A_au
         fz(i)=fz(i)*A_au
      else
c________________ reading from input file *.iNN
         iRx(i)=1
         iRy(i)=1
         iRz(i)=1
         if(NumLin.eq.4) then
            Read(Line(LinPos(2):),*,end=50,err=50) x(i),y(i),z(i)
         else if(NumLin.eq.7) then
            Read(Line(LinPos(2):),*,end=50,err=50) 
     &           x(i),y(i),z(i),iRx(i),iRy(i),iRz(i)
         else if(NumLin.ge.10) then
            Read(Line(LinPos(2):),*,end=50,err=100) 
     &           x(i),y(i),z(i),iRx(i),iRy(i),iRz(i),
     &           fx(i),fy(i),fz(i)
            fx(i)=fx(i)*A_au
            fy(i)=fy(i)*A_au
            fz(i)=fz(i)*A_au
         else
            go to 100
         end if
         if(which.eq.'ft'.or.which.eq.'tb'.or.which.eq.'cb') then
            iRx(i)=0
            iRy(i)=0
            iRz(i)=0
         end if
         if(NumLin.ne.10) then
            fx(i)=x(i)*A_au
            fy(i)=y(i)*A_au
            fz(i)=z(i)*A_au
         end if
      end if
      x(i)=x(i)*A_au
      y(i)=y(i)*A_au
      z(i)=z(i)*A_au
      if(iRx(i).ne.0) iRx(i)=1
      if(iRy(i).ne.0) iRy(i)=1
      if(iRz(i).ne.0) iRz(i)=1

c-----if doing MD then all relaxation flags must be the same
      if(do_md.and.(.not.((iRx(i).eq.0.and.iRy(i).eq.0.and.iRz(i).eq.0)
     &     .or.(iRx(i).eq.1.and.iRy(i).eq.1.and.iRz(i).eq.1)))) then
         write(*,*)'FATAL! Atom ',i,' not completely relaxed or frozen',
     &        ' while doing molecular dynamics'
         stop
      end if

c_______ copy relaxation flags to iRx1, ..       
      iRx1(i)=iRx(i)
      iRy1(i)=iRy(i)
      iRz1(i)=iRz(i)

c_______If move or rotate are active then modify coordinates
c_______appropriately.

      if(move) then
         if(which.eq.'ft'.or.which.eq.'tb'.or.which.eq.'ta') then
            x(i)=x(i)+vec(1)
            y(i)=y(i)+vec(2)
            z(i)=z(i)+vec(3)
            fx(i)=fx(i)+vec(1)
            fy(i)=fy(i)+vec(2)
            fz(i)=fz(i)+vec(3)
         end if
      end if

c______call subroutine for rotations: rotate both cores and shells 
c      independently

      if(rotate) then
         if(which.eq.'ft'.or.which.eq.'tb'.or.which.eq.'ta') then
            inx=x(i)-cen(1)
            iny=y(i)-cen(2)
            inz=z(i)-cen(3)
            call dizzy(inx,iny,inz,rot)
            x(i)=inx+cen(1)
            y(i)=iny+cen(2)
            z(i)=inz+cen(3)
            inx=fx(i)-cen(1)
            iny=fy(i)-cen(2)
            inz=fz(i)-cen(3)
            call dizzy(inx,iny,inz,rot)
            fx(i)=inx+cen(1)
            fy(i)=iny+cen(2)
            fz(i)=inz+cen(3)
         end if
      end if

c_______ If IMAGE is on: check if atoms are correctly assigned to the regions.
c        We calculate distances: to the sphere (rsp) and to the plane (rpl).
c        Give an error message if anything wrong and quit afterwards.
c
      if(Do_Image) then
         rsp2=(x(i)-rsx)**2 + (y(i)-rsy)**2 + (z(i)-rsz)**2
         rsp=sqrt(rsp2)-rads
         rpl=z(i)-zp
         if(id(i).ne.'ft') then
            is=ISRT(i)
            if(do_decay) then
               qc=CoreQA(is)*decay(rsp)*decay(rpl)
            else
               qc=CoreQA(is)
            end if
         else
            qc=0.0
         end if
         write(9,'(i5,x,a3,x,2a,3(x,f10.5),x,3(a,f10.5))') 
     &        i,na3,which,' R=',x(i),y(i),z(i),
     &        '=> d(sph)= ',rsp,' d(pln)= ',rpl,' Qc= ',qc
         if(rsp.le.0.0 .and. which.ne.'ft'.and.do_sphere) then
            write(*,'(a,i5,a)') 'ERROR! Atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is inside the sphere!'
            write(9,'(a,i5,a)') 'ERROR! Atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is inside the sphere!'
            error=.true.
         end if
         if(rpl.le.0.0.and.do_plane) then
            write(9,'(a,i5,a)') 'ERROR! Atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is under the plane!'
            write(*,'(a,i5,a)') 'ERROR! Atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is under the plane!'
            error=.true.
         end if
         rsp2=(fx(i)-rsx)**2 + (fy(i)-rsy)**2 +(fz(i)-rsz)**2
         rsp=sqrt(rsp2)-rads
         rpl=fz(i)-zp
         if(rsp.le.0.0 .and. which.ne.'ft'.and.do_sphere) then
            write(9,'(a,i5,a)') 'ERROR! Shell of atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is inside the sphere!'
            write(*,'(a,i5,a)') 'ERROR! Shell of atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is inside the sphere!'
            error=.true.
         end if
         if(rpl.le.0.0.and.do_plane) then
            write(9,'(a,i5,a)') 'ERROR! Shell of atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is under the plane!'
            write(*,'(a,i5,a)') 'ERROR! Shell of atom '//na3//' i=',i,
     ,                   ' (region: '//which//') is under the plane!'
            error=.true.
         end if
      end if
c_______ if no. of iterations is zero then freeze everything
      if(max_opt.eq.0) then
         iRx(i)=0
         iRy(i)=0
         iRz(i)=0
      end if
c
c_______ increment counters
      if((iRx(i).eq.1).or.(iRy(i).eq.1).or.(iRz(i).eq.1)) then
         ifr=ifr+1
      end if
      if(which.eq.'ft') ift=ift+1
      if(which.eq.'tb') itb=itb+1
      if(which.eq.'ta') ita=ita+1
      if(which.eq.'ca') ica=ica+1
      if(which.eq.'cb') icb=icb+1
      go to 20
c
c........................................................................
c.......... FINISHED READING IN COORDINATES
c........................................................................
c
 50   Natom=i-1
      write(*,'(a,i10)')'... cores found = ',Natom
      if(Natom.eq.0) go to 100
      write(*,'(a,i10)')'... shells found = ',Nshell
      Ncharge=Natom+Nshell
      write(*,'(a,i10)')'... charges found = ',Ncharge
      write(*,'(a,i10)')'... frozen tip atoms found =',ift
      write(*,'(a,i10)')'... buffer tip atoms found =',itb
      write(*,'(a,i10)')'... tip atoms found =',ita
      write(*,'(a,i10)')'... cluster atoms found =',ica
      write(*,'(a,i10)')'... cluster buffer atoms found =',icb
      write(*,'(a,i10)')'... Quantum Cluster atoms found =',iQMC_at
      if(move) then
         write(*,'(a,3(x,f10.5))')
     &        '... tip atoms were moved by (au) vec= ',vec
         write(9,'(a,3(x,f10.5))')
     &        '... tip atoms were moved by (au) vec= ',vec
      end if
      if(rotate) then
         write(*,'(a,3(x,f10.5))')
     &        '... tip atoms were rotated about X,Y,Z by ',rot
         write(*,'(a,3(x,f10.5))')
     &        '..............the centre of rotation was (au)',cen
         write(9,'(a,3(x,f10.5))')
     &        '... tip atoms were rotated about X,Y,Z by ',rot
         write(9,'(a,3(x,f10.5))')
     &        '..............the centre of rotation was (au)',cen
      end if
c_______if there are no relaxed atoms set iterations to zero

      if(ifr.eq.0) then
         write(*,*) '... All atoms are frozen, so no relaxation.'
         max_opt=0
      end if
      
      itft=ift

      if(Natom.ne.ift+itb+ita+ica+icb) then
         write(*,'(a)')'ERROR: Natoms =/= ita+itb+ ...'
         go to 100
      end if

c_______ set the last number of each type
c_______i is reduced by one to account for extra loop on last line of file
      i=i-1

      if(which.eq.'ft') then
         nft2=i
         write(9,'(a,i5)')'... frozen tip atoms ended at i= ',nft2
      else if(which.eq.'tb') then
         ntb2=i
         write(9,'(a,i5)')'... buffer tip atoms ended at i= ',ntb2
      else if(which.eq.'ta') then
         nta2=i
         write(9,'(a,i5)')'... tip atoms ended at i= ',nta2
      else if(which.eq.'ca') then
         nca2=i
         write(9,'(a,i5)')'... cluster atoms ended at i= ',nca2
      else if(which.eq.'cb') then
         ncb2=i
         write(9,'(a,i5)') '... cluster buffer atoms ended at i= ',ncb2
      end if
c
c........ print all regions 
      if(yes_ft) then
         write(*,'(a,i5,a,i5)')'... Frozen tip atoms:     ',
     ,        nft1,' - ',nft2
         if(ift.eq.0) then
            write(*,*) 'FATAL! Empty ft region. Stop!'
            go to 100
         end if
      end if
      if(yes_tb) then
         write(*,'(a,i5,a,i5)')'... Tip buffer atoms:     ',
     ,        ntb1,' - ',ntb2
         if(itb.eq.0) then
            write(*,*) 'FATAL! Empty tb region. Stop!'
            go to 100
         end if
      end if
      if(yes_ta) then
         write(*,'(a,i5,a,i5)')'... Tip atoms:            ',
     ,        nta1,' - ',nta2
         if(ita.eq.0) then
            write(*,*) 'FATAL! Empty ta region. Stop!'
            go to 100
         end if
      end if
      if(yes_ca) then
         write(*,'(a,i5,a,i5)')'... Cluster atoms:        ',
     ,        nca1,' - ',nca2
         if(ica.eq.0) then
            write(*,*) 'FATAL! Empty ca region. Stop!'
            go to 100
         end if
      end if
      if(yes_cb) then
         write(*,'(a,i5,a,i5)')'... Cluster buffer atoms: ',
     ,        ncb1,' - ',ncb2
         if(icb.eq.0) then
            write(*,*) 'FATAL! Empty cb region. Stop!'
            go to 100
         end if
      end if
c
c........... Setting up shells:
c            now shell is positioned in x,y,z after all cores;
c            working out the lookup array iShell: it shows
c            the position in x,y,z of the shell associated
c            with every atom (=core)
c__________________ Also save relaxation flags for shells
      write(9,'(/a)')'............ Setting up SHELLS ...........'
      j=Natom
      do i=1,Natom
         cha=' '
         if(iQMC(i)) cha='@'
         if(Species(ISRT(i))(3:3).eq.' ') then
            cha4=Species(ISRT(i))(1:2)//cha//' '
         else
            cha4=Species(ISRT(i))(1:3)//cha
         end if
         if(Shell_Ref(ISRT(i))) then
            if(id(i).eq.'ft') itft=itft+1
            j=j+1
            id(j)=id(i)
            iShell(i)=j
            iQMC(j)=iQMC(i)
            x(j)=fx(i)
            y(j)=fy(i)
            z(j)=fz(i)
            if((id(i).eq.'ca'.or.id(i).eq.'ta')
     &                                       .and.move_shells.eq.2) then
               iRx(j)=1
               iRy(j)=1
               iRz(j)=1
            else if((id(i).eq.'ca'.or.id(i).eq.'ta')
     &                                       .and.move_shells.eq.0) then
               iRx(j)=0
               iRy(j)=0
               iRz(j)=0
            else
               iRx(j)=iRx(i)
               iRy(j)=iRy(i)
               iRz(j)=iRz(i)
            end if
            iRx1(j)=iRx(j)
            iRy1(j)=iRy(j)
            iRz1(j)=iRz(j)
            write(9,'(i5,x,2a,3(x,f10.5),x,i5,3(x,f10.5))') 
     &          i,cha4,id(i),
     ,            x(i)*au_A,y(i)*au_A,z(i)*au_A,
     ,            iShell(i),x(j)*au_A,y(j)*au_A,z(j)*au_A
         else
            iShell(i)=0
            write(9,'(i5,x,2a,3(x,f10.5),x,i5,3(x,f10.5))') 
     &          i,cha4,id(i),
     ,           x(i)*au_A,y(i)*au_A,z(i)*au_A,iShell(i)
         end if
      end do
      
c
c........... n_dfree - the number of degrees of freedom is worked out
c            n_pos_cor - lenght of only cores in the 1-dim relaxation vector r()
c
      n_dfree=0
      n_pos_cor=0
      do i=1,Natom
         ndf=iRx(i)+iRy(i)+iRz(i)
         n_pos_cor=n_pos_cor+ndf
         if(Shell_Ref(ISRT(i))) then
            j=iShell(i)
            ndf=ndf+iRx(j)+iRy(j)+iRz(j)
         end if
         n_dfree=n_dfree+ndf
      end do
      write(*,'(a,i10)')'... number of degrees of freedom = ',n_dfree
      write(*,'(a,i10)')'... among which cores occupy     = ',n_pos_cor
c
      if(exist_QC) then 
         write(9,'(a)')
     &        '... QC specific energy/forces WILL be calculated'
         write(6,'(a)')
     &        '... QC specific energy/forces WILL be calculated'
      else
         write(9,'(a)')
     &        '... QC specific energy/forces will NOT be calculated'
         write(6,'(a)')
     &        '... QC specific energy/forces will NOT be calculated'
      end if
c
      if(Yes_Tip) then
         write(9,'(a)')'... the force on the tip WILL be calculated'
         write(6,'(a)')'... the force on the tip WILL be calculated'
      else
         write(9,'(a)')'... the force on the tip will NOT be calculated'
         write(6,'(a)')'... the force on the tip will NOT be calculated'
      end if
      write(9,'(a)')
     &     '.............<Coord> box is read correctly ..............'
      write(9,'(a/)')
     &'################################################################'
      if(error) go to 100
      return
c.......... ERROR messages ..........................................
100   WRITE(9,'(a/)')'FATAL! <Coord> box is WRONG or absent !!! '
      WRITE(6,*)'FATAL! <Coord> box is WRONG or absent !!! '
      KodErr=1
      write(9,'(a/)')
     &'################################################################'
      RETURN
      END

      SUBROUTINE DynPotc(NFIL,KodErr)
c......................................................................
c.....Read in the file UNIT=NFIL the box <Pair Potenc> ................
c......................................................................
c Pair-wise interaction can act between any two following species: 
c   (1) pp <---> pp
c   (2) pp <---> mb
c   (3) pp <---> tf
c   (4) mb <---> tf
c i.e. it cannot only work between Tersoff atoms:  tf <--X--> tf
c                    and between many-body atoms:  mb <--X--> mb
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na3*3,na2*2,cha*1,na4*3,messg2*3,messg1*8
      character line1*120
      integer LinPos(30),LinEnd(30),iPair(N0KD1)
      logical log
      data iPair/N0KD1*0/
c
c...... Seeks for the box marker: [.<PairPotenc>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<PairPotenc>',13,NFIL,iErr)
      if(iErr.eq.1) go to 100
c
c.......................................................................
c SHELL-SHELL parameters (k - pair index): 
c  (1) exponential terms A(n)*exp(-R/a(n))
c       - the number of exponenets iPotD(k,1)
c       - parameters (A,a) follow one exponential term per line: 
c               { A(n) -> ParD(k,n,1,1), a(n) -> ParD(k,n,2,1) }
c  (2) power terms B(n)/R**b(n)
c       - the number of power-terms iPotD(k,2)
c       - parmeters (B,b) follow one power term per line: 
c               { B(n) -> ParD(k,n,1,2), b(n) -> ParD(k,n,2,2) }
c.......................................................................
c all pairs are checked using iPair
c.......................................................................

      do_cutoff=.false.

c___________ loop over all pairs of species

      DO 80 I1=1,KINDS
        DO 50 J1=1,I1

c_______________ identify the pair {i, j}
 10        call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
           if(index(line,'.<End>').ne.0) go to 90
           if(NumLin.eq.1) then
              if(index(line(LinPos(1):LinEnd(1)),'cutoff').ne.0) then
                 do_cutoff=.true.
                 write(9,'(a,i2,a,e12.6)')
     &       '...> cutoff activated for short-range interaction '
                 go to 10
              else
                 go to 100
              end if
           else if(NumLin.eq.2 .and. do_cutoff) then
              go to 100
           end if
           if(iErr.ne.0) go to 100

c_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ the species I of the pair

           call atom_type(Line,LinPos(1),LinEnd(1),i,iErr)
           if(iErr.eq.1) go to 100
           na3=Species(i)

c_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ the species J of the pair
c 2         iLi=LinEnd(2)-LinPos(2)+1

           call atom_type(Line,LinPos(2),LinEnd(2),j,iErr)
           if(iErr.eq.1) go to 100
           na4=Species(j)

c__________ check if these two are Tersoff-related; if YES, then an error
           if(SpecType(i).eq.'tf' .and. SpecType(j).eq.'tf') then
              write(9,'(a)') 'ERROR: Tersoff species '//na3//' and '
     &             //na4//' cannot interact via pair-wise interaction!'
              go to 100
              
c__________ check if these two are both many-body; if YES, then an error
           else if(SpecType(i).eq.'mb' .and. SpecType(j).eq.'mb') then
              write(9,'(a)') 'ERROR: Many-body species '//na3//' and '
     &             //na4//' cannot interact via pair-wise interaction!'
              go to 100
           else
              write(9,'(/a)') '==> Species '//na3//' and '//na4//
     &                  ' are OK for pair-wise interaction! <=='
           end if
 
c__________ the pair index k=(i,j)
           if(j.le.i) then
              k=j+i*(i-1)/2
           else
              k=i+j*(j-1)/2
           end if

c_________ read the cut-off for this interaction
           
           if(do_cutoff) then
              read(Line(LinPos(3):LinEnd(3)),*,err=100) CutOff(k)
           end if

c__________ check in the pair 

           if(iPair(k).eq.0) then
              iPair(k)=1
              write(9,'(x,a,i2,a1,i2,a42)')
     &             '.... The pair (',i,',',j,') = '//na3//'-'//na4//
     &             ' has the following interaction:'
              write(9,'(6x,a,i3)')'pair index k= ',k
              if(do_cutoff) then
                 write(9,'(6x,a,f10.5)')'cut-off distance = ',CutOff(k)
                 CutOff(k)=CutOff(k)*A_au
              end if
           else
              write(9,*)'WARNING! An extra pair '//na3//'-'//na4//
     &             ' was met. Exiting...'
              go to 50
           end if
c     
c________________ read the parameters for that pair: ________________
c

c_________ read exp and power terms in the potential
           iPotD(k,1)=0
           iPotD(k,2)=0
 13        call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
           go to (15,100,50) iErr+1

c-.-.-.-.-.- the exponential terms 
 15        if(index(Line(LinPos(1):LinEnd(1)),'exp').ne.0) then
              read(Line(LinPos(2):),*,err=100)  iPotD(k,1)
              if(iPotD(k,1).gt.N0PAR) go to 110
              if(iPotD(k,1).eq.0) write(9,'(6x,a)')' D(exp)=0.0'
              if(iPotD(k,1).ne.0) then
                 do n=1,iPotD(k,1)
                    Read(NFIL,*,END=100,ERR=100) 
     &                          ParD(k,n,1,1),ParD(k,n,2,1)
                    messg1='        '
                    if(n.eq.1) messg1=' D(exp)='
                    messg2=') +'
                    if(n.eq.iPotD(k,1)) messg2=')  '
                    write(9,'(6x,a8,f12.5,a8,f10.5,a3)')
     &              messg1,ParD(k,n,1,1),'*exp(-R/',ParD(k,n,2,1),messg2
                    ParD(k,n,1,1)=ParD(k,n,1,1)*eV_au
                    ParD(k,n,2,1)=ParD(k,n,2,1)*A_au
                 end do
              end if
c-.-.-.-.-.- the power terms 
           else if(index(Line(LinPos(1):LinEnd(1)),'pow').ne.0) then
              read(Line(LinPos(2):),*,err=100)  iPotD(k,2)
              if(iPotD(k,2).gt.N0PAR) go to 110
              if(iPotD(k,2).eq.0) write(9,'(6x,a)')' D(pow)=0.0'
              if(iPotD(k,2).ne.0) then
                 do n=1,iPotD(k,2)
                    Read(NFIL,*,END=100,ERR=100) 
     &                         ParD(k,n,1,2),ParD(k,n,2,2)
                    messg1='        '
                    if(n.eq.1) messg1=' D(pow)='
                    messg2=') +'
                    if(n.eq.iPotD(k,2)) messg2=')  '
                    write(9,'(6x,a8,f12.5,a5,f10.5,a3)')
     &                messg1,ParD(k,n,1,2),'/R**(',ParD(k,n,2,2),messg2
                   ParD(k,n,1,2)=ParD(k,n,1,2)*eV_au*A_au**ParD(k,n,2,2)
                 end do
              end if
           else
              backspace NFIL
              go to 50
           end if
           go to 13

 50     END DO
 80   END DO
c
c________ check if all pairs have been met
c
 90   ik=0
      do i=1,KINDS
         do j=1,i
            k=j+i*(i-1)/2
            if(iPair(k).eq.0) then
               na3 = Species(i)
               na4 = Species(j)
               log=(SpecType(i).eq.'tf'.and. SpecType(j).eq.'tf') .or.
     &                (SpecType(i).eq.'mb'.and. SpecType(j).eq.'mb') 
               if(.not.log) then
                  write(9,*)
     &                'FATAL! The pair '//na3//'-'//na4//' is absent!'
                  ik=ik+1
               end if
            end if
         end do
      end do
c
c__________ print nice table of pp interactions
c
      write(9,'(/a)')
     &     '=====> Nice table of pairwise interactions <====='
      line1(1:8)='--------'
      do i=1,KINDS
         line((i-1)*4+1 :8+i*4)=Species(i)//' '
         line1(8+(i-1)*4+1 : 8+i*4)='-----'
      end do
      write(9,'(a)') '/'//line1(2:KINDS*4+8)//'-'//char(92)
      write(9,'(a)') '|     | '//line(1:KINDS*4)//' |'
      write(9,'(a)') '|'//line1(1:KINDS*4+8)//'|'
      do i=1,KINDS
         line(1:8)='| '//Species(i)//' | '
         do j=1,KINDS
            k=i+j*(j-1)/2
            if(j.le.i) k=j+i*(i-1)/2
            log=(SpecType(i).eq.'tf'.and. SpecType(j).eq.'tf') .or.
     &                (SpecType(i).eq.'mb'.and. SpecType(j).eq.'mb') 
            if(iPair(k).eq.1) then
               if(log) then
                  line(8+(j-1)*4 : 8+j*4)=' NN '
               else
                  line(8+(j-1)*4 : 8+j*4)=' T  '
               end if
            else
               if(log) then
                  line(8+(j-1)*4 : 8+j*4)=' NA '
               else
                  line(8+(j-1)*4 : 8+j*4)=' F  '
               end if
            end if
         end do
         write(9,'(a)') line(1:KINDS*4+8)//' |'
      end do
      write(9,'(a)') char(92)//line1(1:KINDS*4+8)//'/'
      write(9,'(a)') 'Index: T - true; F - false; '
      write(9,'(a/)') '       NN - not needed; NA -not applicable'
c
c.............. quit if in error
      if(ik.ne.0) go to 100

      write(9,'(a)')
     &     '...........<Pair Potenc> box is read correctly ...........'
      write(9,'(a/)')
     &'################################################################'
      return
c.......... ERROR messages ..........................................
 110  write(9,'(a)')'FATAL! You must increase your N0PAR in shell.inc'
100   WRITE(9,'(a/)')'FATAL! <Pair Potenc> box is WRONG or absent !!! '
      do_pair=.false.
      KodErr=1
      write(9,'(a/)')
     &'################################################################'
      RETURN
      END

      SUBROUTINE Image(NFIL,iPrnt)
c......................................................................
c.....Read in the file UNIT=NFIL the box <Image>
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2
      integer LinPos(30),LinEnd(30)
      data tiny/0.01/
c
c............. set default values first 
c
c____________ amount of output
      iPrnt1=iPrnt
c____________ precision
      precis=0.1d-5
c____________ position of the image plane
      Z_plane=0.0
c____________bias
      Volt=0.0
c____________sphere radius
      rad=100.0
c____________position of the sphere
      R_Sph(1)=0.0
      R_Sph(2)=0.0
      Rz=0.0
c
c____________ buffer between conductor and charges, used to reduce charges
c             which are too close to the metal electrodes. 
c             Good pairs (buffer,smooth):
c             [1.5,0.2], [1.8,0.3], [2.2,0.4], etc. 
c             Probably, it is safer to take even smaller values for smooth.
c____________ near the conductors (in A)
      buffer=1.8
c____________smoothness of decay in A (the bigger the smoother)
      smooth=0.3
c____________ whether to write charges (default no)
      iwrite=0
c____________do we have sphere (default = no)
      do_sphere=.false.
c____________do we have plane (default = no)
      do_plane=.false.
c____________do we have decay (default = no)
      do_decay=.false.
c____________ scaling factor for coordinates (unchangable)
      scale=1.0
c____________ include metal polarization or only bias
      do_only_bias=.false.
c
c...... Seeks for the box marker: [.<Toleranc>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Image>',8,NFIL,iErr)
      if(iErr.eq.1) go to 40
c
c........... read the input file: 
c               iw - number of words found (optional)
c               im - number of words found (mandatory)
c
      iw=0

 20   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0.or.NumLin.lt.1) go to 50
      if(index(line,'.<End>').ne.0) go to 50

      if(index(line(LinPos(1):LinEnd(1)),'precis').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) precis
         iw=iw+1
         if(precis.lt.1.0) then
            write(9,'(a,i2,a,e12.6)')
     &       '...> found (',iw,') new value for precis= ',precis
            NumImg=0
         else if(abs(nint(precis)).gt.2) then
            NumImg=abs(nint(precis))
            precis=0.0
            write(9,'(a,i2,a,i5)')
     &       '...> found (',iw,') new value for precis= ',NumImg
         else
            write(9,*)'FATAL! Wrong precis or # of image charges!'
            go to 50
         end if

      else if(index(line(LinPos(1):LinEnd(1)),'Z_plane').ne.0 .or.
     &           index(line(LinPos(1):LinEnd(1)),'z_plane').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) Z_plane
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &           '...> found (',iw,') new value for Z_plane= ',Z_plane

      else if(index(line(LinPos(1):LinEnd(1)),'qwrite').ne.0) then
         iwrite=1
         iw=iw+1
         write(9,'(a,i2,a)')
     &        '...> found (',iw,'): image charges will be printed out.'
         
      else if(index(line(LinPos(1):LinEnd(1)),'buffer').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) buffer
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &        '...> found (',iw,') new value for buffer= ',buffer
         
      else if(index(line(LinPos(1):LinEnd(1)),'smooth').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) smooth
         iw=iw+1
         write(9,'(a,i2,a,e12.6)')
     &        '...> found (',iw,') new value for smooth= ',smooth
         
      else if(index(line(LinPos(1):LinEnd(1)),'plane').ne.0) then
         do_plane=.true.
         iw=iw+1
         write(9,'(a,i2,a)') '...> found (',iw,') plane exists.'

      else if( (index(line(LinPos(1):LinEnd(1)),'sphere').ne.0).and. 
     &        (index(line(LinPos(1):LinEnd(1)),'bottom').eq.0) ) then
         do_sphere=.true.
         iw=iw+1
         write(9,'(a,i2,a)') '...> found (',iw,') sphere exists.'
         
      else if(index(line(LinPos(1):LinEnd(1)),'decay').ne.0) then
         do_decay=.true.
         iw=iw+1
         write(9,'(a,i2,a)') '...> found (',iw,') decay is activated.'
         
      else if(index(line(LinPos(1):LinEnd(2)),'capacitor').ne.0 .and. 
     &        index(line(LinPos(1):LinEnd(2)),'only').ne.0) then
         iw=iw+1
         do_only_bias=.true.
            write(9,'(a,i2,a,l1)')
     &        '...> found (',iw,') bias only calculation. '

      else if(index(line(LinPos(1):LinEnd(1)),'printing').ne.0) then
         if(index(line(LinPos(2):LinEnd(2)),'huge').ne.0) then
            iPrnt1=10
         else if(index(line(LinPos(2):LinEnd(2)),'large').ne.0) then
            iPrnt1=8
         else if(index(line(LinPos(2):LinEnd(2)),'medium').ne.0) then
            iPrnt1=5
         else if(index(line(LinPos(2):LinEnd(2)),'small').ne.0) then
            iPrnt1=3
         else if(index(line(LinPos(2):LinEnd(2)),'tiny').ne.0) then
            iPrnt1=1
         else if(index(line(LinPos(2):LinEnd(2)),'no').ne.0) then
            iPrnt1=0
         end if
         iw=iw+1
         write(9,'(a,i2,a,i5)')
     &            '...> found (',iw,') new value for iPrnt1= ',iPrnt1

      else if(index(line(LinPos(1):LinEnd(1)),'bottom').ne.0.and.
     &        index(line(LinPos(1):LinEnd(1)),'sph').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) R_Sph(1),R_Sph(2),Rz
         iw=iw+1
         write(9,'(a,i2,a,3(x,f10.5))')
     &      '...> found (',iw,') bottom of the sphere: ', 
     &            R_Sph(1),R_Sph(2),Rz

      else if(index(line(LinPos(1):LinEnd(1)),'bias').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) Volt
         iw=iw+1
         write(9,'(a,i2,a,f10.5,a)')
     &      '...> found (',iw,') bias = ', Volt,' volt'

      else if(index(line(LinPos(1):LinEnd(1)),'radius').ne.0) then
         read(Line(LinPos(2):),*,END=50,ERR=50) Rad
         iw=iw+1
         write(9,'(a,i2,a,f10.5)')
     &      '...> found (',iw,') radius = ', Rad

      end if

      go to 20

c____ check if any image components are included
         
 50   if( (.not.do_plane) .and. (.not.do_sphere) ) then
         do_image=.false.
         write(9,'(a/)') 'No plane/sphere found!'
         write(*,'(a/)') 'No plane/sphere found!'
         goto 70
      end if
c
c____if no plane then reduce Z_plane (we can still have a bias,
c            i.e. a point charge in the sphere centre!)

      if(.not.do_plane) Z_plane=Z_plane-1000.0

c____ if we have a plane only calculation then bias=0
         
      if(.not.do_sphere) then
         Volt=0.0
         Rz=Rz+1000.0
         write(9,'(a)')'No sphere, so no potential - bias = 0 V'
         write(*,'(a)')'No sphere, so no potential - bias = 0 V'
         do_only_bias=.false.
      end if

c_____ redefine variables and check buffer/smooth
         
      Do_Image=.true.
      ro=smooth*a_au
      beta=0.5*buffer*a_au
      
c_____ check if decay is on
     
      if(do_decay) then
         if(ro.ge.beta) then
            write(*,'(a)')'ERROR! Buffer is inconsistent with Smooth!'
            go to 60
         end if
         write(9,'(/a)')
     &        '.... decay function (21 points) in [0:10] a.u. ...'
         do i=1,21
            d=(i-1)*0.5
            dec=decay(d)
            write(9,'(2(x,f10.5))') d,dec
         end do
         write(*,'(a)')'... Buffer is consistent with Smooth!'
      end if
c     
c.......... finish
      write(9,'(a)')'..........{ IMAGE is ACTIVE }............'
      write(9,'(a)')'..........<Image> box is read correctly ........'
      write(*,'(a)')'..........{ IMAGE is ACTIVE }............'
      write(9,'(a/)')
     &'################################################################'
      return
c............. error  messages
 40   write(9,'(a/)') 'ERROR! Box <Image> not found! No image then!'
      go to 70
 60   write(9,'(a)') 'ERROR! Error while reading Box <Image>!'
 70   write(9,'(a/)') '................. No image then! ..............'
      write(9,'(a/)')
     &'################################################################'
      return
      end

      subroutine Constraints(NFIL)
c......................................................................
c.....Read in the file UNIT=NFIL the box <Constraints>
c......................................................................
      include 'shell.inc'
      include 'constr.inc'
      character Line*120,sign,xyz,cxyz(3),chat(9),char(9),cha
      integer LinPos(30),LinEnd(30),iat(9),invatoms(NinvAt0)
      data pi/3.141592654/,cxyz/'x','y','z'/,tiny/0.01/

c......... counters: ic  - general counter of liear and nonlinear constraints
      ic=0
c
c...... Seeks for the box marker: [.<Constraints>]  in the file
c_________ Start every time from the beginning of the file
c
      rewind (NFIL)
      call find_string('.<Constraints>',14,NFIL,iErr)
      if(iErr.eq.1) go to 100
      write(9,'(/a/)')'reading in constraints ...'
c
c........... read the input file: N_of_Constr - number of constraints found
c
 10   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.eq.1) go to 10
      if(iErr.eq.2.or.index(line,'.<').ne.0) go to 100


      ic1=ic+1
      if(ic1.gt.N0CNSTR) then
         write(*,*)'ERROR! Too many constrains - see param.inc'
         write(9,*)'ERROR! Too many constrains - see param.inc'
         go to 100
      end if
      Type_Constr(ic1)=line(LinPos(1):LinEnd(1))
      write(9,'(a,i2,a)')'>>> ', ic1,
     &     ' <<< ... attempting to read constraint: '//Type_Constr(ic1)
c
c....................  read in the details and make
c
c======= Type=A_1x: fixed angle (input: in degrees) formed by a pair of atoms 
c                   with the X axis; the angle will substitute the x-coordinate
c                   of the FIRST atom of the pair; care is to be taken for the
c                   cases of the angle near 0 and 180 degrees! 
      IF(Type_Constr(ic1).eq.'A_1x') THEN
         if(NumLin.lt.5) go to 11
         read(line(LinPos(2):LinEnd(4)),*,err=11) 
     &        (Inv_atoms(ic1,j),j=1,2),Par_Constr(ic1,1)
         read(line(LinPos(5):LinEnd(5)),'(a1)') sign
         N_inv_atoms(ic1)=2
         Par_Constr(ic1,1)=Par_Constr(ic1,1)*pi/180.
         do j=1,2
            Inv_crd(ic1,j,1)=.true.
            Inv_crd(ic1,j,2)=.true.
            Inv_crd(ic1,j,3)=.true.
         end do
         Redund_dir(ic1)= 'x'
c
c======= Type=B1xz: the same as A_1x, but the atoms involved are constrained
c                   in a plane parallel to the XZ plane (i.e. they have 
c                   identical y-coordinates)
      ELSE IF(Type_Constr(ic1).eq.'B1xz' ) THEN
         if(NumLin.lt.5) go to 11
         read(line(LinPos(2):LinEnd(4)),*,err=11) 
     &        (Inv_atoms(ic1,j),j=1,2),Par_Constr(ic1,1)
         read(line(LinPos(5):LinEnd(5)),'(a1)') sign
         N_inv_atoms(ic1)=2
         Par_Constr(ic1,1)=Par_Constr(ic1,1)*pi/180.
         do j=1,2
            Inv_crd(ic1,j,1)=.true.
            Inv_crd(ic1,j,2)=.false.
            Inv_crd(ic1,j,3)=.true.
         end do
         Redund_dir(ic1)= 'x'
c
c======= Type=C_1x: fixed angle between three atoms; the x-coordinate of the
c                   FIRST atom will be made redundant in the optimisation.
      ELSE IF(Type_Constr(ic1).eq.'C_1x') THEN
         if(NumLin.lt.6) go to 11
         read(line(LinPos(2):LinEnd(5)),*,err=11) 
     &        (Inv_atoms(ic1,j),j=1,3),Par_Constr(ic1,1)
         read(line(LinPos(6):LinEnd(6)),'(a1)') sign
         N_inv_atoms(ic1)=3
         Par_Constr(ic1,1)=Par_Constr(ic1,1)*pi/180.
         do j=1,3
            Inv_crd(ic1,j,1)=.true.
            Inv_crd(ic1,j,2)=.true.
            Inv_crd(ic1,j,3)=.true.
         end do
         Redund_dir(ic1)= 'x'
c
c======= Type=D_1x: distance (in A) between two atoms kept constant; the 
c                   x-coordinate of the FIRST atom will be made redundant in 
c                   the optimisation.
      ELSE IF(Type_Constr(ic1).eq.'D_1x') THEN
         if(NumLin.lt.5) go to 11
         read(line(LinPos(2):LinEnd(4)),*,err=11) 
     &        (Inv_atoms(ic1,j),j=1,2),Par_Constr(ic1,1)
         Par_Constr(ic1,1)=Par_Constr(ic1,1)*A_au
         N_inv_atoms(ic1)=2
         read(line(LinPos(5):LinEnd(5)),'(a1)') sign
         do j=1,2
            Inv_crd(ic1,j,1)=.true.
            Inv_crd(ic1,j,2)=.true.
            Inv_crd(ic1,j,3)=.true.
         end do
         Redund_dir(ic1)= 'x'
c
c======= Type=LINR: linear constraint given as a1*r1+a2*r2+a3*r3+...=0,
c                   where a1,a2,a3,... - nonzero coefficients and
c                   r1,r2,r3,.. - atomic coordinates specified by the atomic 
c                   number with attached x,y or z. The coordinate r1 which is
c                   given the first on the input line, will be the redundant one.
c                   MIND: this constraint is stored by the coordinates involved,
c                         not atoms! Seems to be okay.
c                      
      ELSE IF(Type_Constr(ic1).eq.'LINR') THEN
         N_inv_atoms(ic1)=(NumLin-1)/2
         if(N_inv_atoms(ic1).lt.2
     &                    .or. N_inv_atoms(ic1).gt.NinvAt0) then
            write(9,'(a)')'   ERROR: wrong number of coordinates'
            go to 12
         end if
         do k1=2,NumLin,2
            do l1=2,k1,2
               if(k1.ne.l1.and.line(LinPos(k1):LinEnd(k1))
     &                     .eq.line(LinPos(l1):LinEnd(l1))) then
                  write(9,'(a)')'   ERROR: found repeated coordinates'
                  go to 12
               end if
            end do
         end do
         do j=1,N_inv_atoms(ic1)
            k1=2*j
            k2=2*j+1
            if(LinEnd(k1)-LinPos(k1)+1.lt.2) then
               write(9,'(a,i2)')
     &                       '   ERROR: wrong syntax of coordinate ',j
               go to 12
            end if
            read(line(LinPos(k1):LinEnd(k1)-1),*,err=12) 
     &                                                  Inv_atoms(ic1,j)
            read(line(LinPos(k2):LinEnd(k2)),*,err=12) Par_Constr(ic1,j)
            cha=line(LinEnd(k1):LinEnd(k1))
            Inv_crd(ic1,j,1)=.false.
            Inv_crd(ic1,j,2)=.false.
            Inv_crd(ic1,j,3)=.false.
            if(cha.eq.'x') then
               Inv_crd(ic1,j,1)=.true.
            else if(cha.eq.'y') then
               Inv_crd(ic1,j,2)=.true.
            else if(cha.eq.'z') then
               Inv_crd(ic1,j,3)=.true.
            else
               write(9,'(3x,a,i2)')
     &           'ERROR: did not recognize direction for coordinate ',j
               go to 12
            end if
            if(j.eq.1) Redund_dir(ic1)= cha
         end do
         if(abs(Par_Constr(ic1,1)).gt.tiny) then
            do j=2,N_inv_atoms(ic1)
               Par_Constr(ic1,j)=Par_Constr(ic1,j)/Par_Constr(ic1,1)
            end do
            Par_Constr(ic1,1)=1.0
         else
            write(9,'(3x,a,i2)') 'ERROR: small leading coefficient'
            go to 12
         end if

c======= Type=X
      ELSE IF(Type_Constr(ic1).eq.'X   ') THEN
         write(9,'(a)') '... not yet implemented; ignored!'
      ELSE
         write(9,'(a)')'... ERROR - unexpected type found. Ignored!'
         go to 10
      END IF
      write(9,'(a,10(x,i3))') '... atoms involved: ',
     &        (Inv_atoms(ic1,j),j=1,N_inv_atoms(ic1))
      go to 15
c
c.......... if error
 11   write(9,'(a,i3,a)')
     &  '... ERROR in reading constraint ',ic+1,' ==> will be ignored'
      go to 10
 12   write(9,'(a,i3)') '...ERROR in the linear constraint ',ic+1
      go to 10
c
c................... the sign parameter
c
 15   if(Type_Constr(ic1).eq.'A_1x' .or. Type_Constr(ic1).eq.'B1xz' 
     &     .or. Type_Constr(ic1).eq.'C_1x') then
         if(sign.eq.'+') then
            Par_Constr(ic1,2)=1.0
         else if(sign.eq.'-') then
            Par_Constr(ic1,2)=-1.0
         else if(sign.eq.'a') then
            write(9,'(a)')'... attempting to choose the sign:'
            Par_Constr(ic1,2)=1.0
            call coord_constr(ic1,x,y,z,crd1,xyz,nat)
            Par_Constr(ic1,2)=-1.0
            call coord_constr(ic1,x,y,z,crd2,xyz,nat)
            if(xyz.eq.'x') then
               delta1=abs(x(nat)-crd1)
               delta2=abs(x(nat)-crd2)
            else if(xyz.eq.'y') then
               delta1=abs(y(nat)-crd1)
               delta2=abs(y(nat)-crd2)
            else 
               delta1=abs(z(nat)-crd1)
               delta2=abs(z(nat)-crd2)
            end if
            if(delta1.gt.delta2) then
               Par_Constr(ic1,2)=-1.0
               write(9,'(2(a,f10.5),a)')
     &           '... delta(+/-)= ',delta1,' / ',delta2,' => choosing -'
            else
               Par_Constr(ic1,2)=1.0
               write(9,'(2(a,f10.5),a)')
     &           '... delta(+/-)= ',delta1,' / ',delta2,' => choosing +'
            end if
         else
            write(9,'(a)')'... ERROR in the sign ==> will be ignored'
            go to 10
         end if
      end if

c________________ setting relaxation flags: iRx,iRy,iRz=2 means that 
c                 the coordinate is redundant (does not exist in the 
c                 optimisation space); however, the corresponding gradient
c                 in gradients() is to be calculated

      if(Redund_dir(ic1).eq.'x') then
         iR_keep=iRx(Inv_atoms(ic1,1))
         iRx(Inv_atoms(ic1,1))=2
         iRx1(Inv_atoms(ic1,1))=0
      else if(Redund_dir(ic1).eq.'y') then
         iR_keep=iRy(Inv_atoms(ic1,1))
         iRy(Inv_atoms(ic1,1))=2
         iRy1(Inv_atoms(ic1,1))=0
      else if(Redund_dir(ic1).eq.'z') then
         iR_keep=iRz(Inv_atoms(ic1,1))
         iRz(Inv_atoms(ic1,1))=2
         iRz1(Inv_atoms(ic1,1))=0
      end if

c................ checking; restore flags if ignored 

      call check_constr(ic,ic1,iErr)
      if(iErr.eq.1) then
         if(Redund_dir(ic1).eq.'x') then
            iRx(Inv_atoms(ic1,1))=iR_keep
            iRx1(Inv_atoms(ic1,1))=iR_keep
         else if(Redund_dir(ic1).eq.'y') then
            iRy(Inv_atoms(ic1,1))=iR_keep
            iRy1(Inv_atoms(ic1,1))=iR_keep
         else if(Redund_dir(ic1).eq.'z') then
            iRz(Inv_atoms(ic1,1))=iR_keep
            iRz1(Inv_atoms(ic1,1))=iR_keep
         end if
         go to 10
      end if

c................ OKAY, putting in: we increment ic and change the optimisation
c                 dimenstion

      ic=ic1
      if(iR_keep.eq.1) then
         n_dfree=n_dfree-1
         n_pos_cor=n_pos_cor-1
      end if
            
      if(Type_Constr(ic).eq.'A_1x' .or. Type_Constr(ic).eq.'B1xz' 
     &                .or. Type_Constr(ic).eq.'C_1x') then
         write(9,'(3x,a,i2,a,2(f10.5,a),f4.1)')
     &        '<'//Type_Constr(ic)//'>-constraint = ',ic,
     &        ', angle to fix = ', Par_Constr(ic,1),
     &        ' / ',Par_Constr(ic,1)*180./pi,' (rad/D), sol = ',
     &        Par_Constr(ic,2)
      else if(Type_Constr(ic).eq.'D_1x') then 
         write(9,'(3x,a,i2,a,2(f10.5,a),f4.1)')
     &        '<'//Type_Constr(ic)//'>-constraint = ',ic,
     &        ', distance to fix = ', Par_Constr(ic,1),
     &        ' / ',Par_Constr(ic,1)*au_A,' (au/A) sol = ',
     &        Par_Constr(ic,2)
      else if(Type_Constr(ic).eq.'LINR') then 
         write(9,'(3x,a,i2,a,2(f10.5,a),f4.1)')
     &        '<'//Type_Constr(ic)//'>-constraint = ',ic
         write(9,'(3x,a,6(f10.5,x))') 'coeff: ',
     &                          (Par_Constr(ic,j),j=1,N_inv_atoms(ic))
      end if
      write(9,'(3x,a,i3,a1)') 
     &        'redundant coordinate = ',Inv_atoms(ic,1),Redund_dir(ic)
c________ printing all involved coordinates
      k=0
      do j=1,N_inv_atoms(ic)
         do i=1,3
            if(Inv_crd(ic,j,i)) then
               k=k+1
               iat(k)=Inv_atoms(ic,j)
               chat(k)=cxyz(i)
               char(k)=' '
               if(j.eq.1.and.chat(k).eq.Redund_dir(ic)) char(k)='*'
            end if
         end do
      end do
      write(9,'(3x,a,9(i3,a2,x)/)') 
     &    'coordinates involved: ',(iat(i),chat(i)//char(i),i=1,k)
      go to 10
c
c......... finish off
c
 100  N_of_Constr=ic
      if( N_of_Constr.eq.0) then
         write(*,*)'WARNING! No constrains => full optimisation!'
         write(9,'(/a)')'WARNING! No constrains => full optimisation!'
         Yes_Constr=.false.
      else
         write(*,*)'>>>>>> Found ',N_of_Constr,' constraints <<<<<<<'
         write(9,'(/a,i2,a)')
     &          '>>>>>> Found ',N_of_Constr,' constraints <<<<<<<'
         Yes_Constr=.true.
      end if
      write(*,'(a,i10)')
     &      ' ...> CORRECTED number of degrees of freedom = ',n_dfree
      write(*,'(a,i10)')
     &      ' ...> CORRECTED : amongst which cores occupy = ',n_pos_cor
      write(9,'(a/)')
     &'################################################################'
      return
      end

      subroutine check_constr(ic,ic1,iErr)
c............................................................................
c commmon sense checking of the current constraint ic1
c............................................................................
      include 'shell.inc'
      include 'constr.inc'
      character sign
      iErr=0
c[1]............. checking atom numbers
c                 irr - counts coordinates associated with the constraint
c                       which are allowed to relax
      irr=0
      do j=1,N_inv_atoms(ic1)
         if(Inv_atoms(ic1,j).lt.0.or.Inv_atoms(ic1,j).gt.Natom) then
            write(9,'(a,i3,a)') 
     &           '... ERROR in atom number j = ',j, ' ==> ignored'
            go to 10
         end if

         if(Inv_crd(ic1,j,1)) irr=irr+iRx1(Inv_atoms(ic1,j))
         if(Inv_crd(ic1,j,2)) irr=irr+iRy1(Inv_atoms(ic1,j))
         if(Inv_crd(ic1,j,3)) irr=irr+iRz1(Inv_atoms(ic1,j))

         if(Type_Constr(ic1).ne.'LINR') then 
            do k=j,N_inv_atoms(ic1)
               if(j.ne.k.and.Inv_atoms(ic1,j).eq.Inv_atoms(ic1,k)) then
                  write(9,'(a)') '... ERROR in atom numbers ==> ignored'
                  go to 10
               end if
            end do
         end if
      end do

c[2]............ checking if there are any free coordinates left in the 
c                constraint

      if(irr.eq.0) then
         write(9,'(a)')'... ERROR: all atoms found fixed ==> ignored'
         go to 10
      end if

c[3]............ checking if the current constraint ic1 does not contain 
c                other redundant variables; in other words, we check:
c                
      if(ic.ge.1) then
         do jc=1,ic
c_______________ if the ic1-redundant variable is contained in any of
c                the previously constructed constraints
            do k=1,N_inv_atoms(jc)
               if(Inv_atoms(ic1,1).eq.Inv_atoms(jc,k)) then
                  if((Redund_dir(ic1).eq.'x'.and.Inv_crd(jc,k,1)).or.
     &               (Redund_dir(ic1).eq.'y'.and.Inv_crd(jc,k,2)).or.
     &                (Redund_dir(ic1).eq.'z'.and.Inv_crd(jc,k,3))) then
                     go to 5
                  end if
               end if
            end do
c_______________if ic-redundant variable (from any of the previously 
c                constructed constraints) is contained in ic1
            do k=1,N_inv_atoms(ic1)
               if(Inv_atoms(jc,1).eq.Inv_atoms(ic1,k)) then
                  if((Redund_dir(jc).eq.'x'.and.Inv_crd(ic1,k,1)).or.
     &                 (Redund_dir(jc).eq.'y'.and.Inv_crd(ic1,k,2)).or.
     &                (Redund_dir(jc).eq.'z'.and.Inv_crd(ic1,k,3))) then
                     go to 5
                  end if
               end if
            end do
         end do
      end if
      return
c
c.......... error
 5    write(9,'(2(a,i2),a,i2,a)')
     &     '... ERROR: constraints ',ic1,' and ',jc,
     &     ' found dependent ==> ',ic1,' ignored'
 10   iErr=1
      return
      end

      SUBROUTINE Velin(NFIL,ita,ica)
c......................................................................
c... Read in the file UNIT=NFIL the atomic velocities if inkey = 1
c......................................................................
c  In the file velocity is in A/ps units, conversion is required.
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120
      integer LinPos(30),LinEnd(30)
      integer num_rel,ita,ica
      logical error

      num_rel = 0.0
      error=.false.

c...... Seeks for the box marker: [.<Velocity>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Velocity>',11,NFIL,iErr)
      if(iErr.ne.0) go to 30

      do i=1,Natom

         if(iRx(i).eq.1 .and. iRy(i).eq.1 .and. iRz(i).eq.1) then
      
            call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
            if(line(LinPos(1):LinEnd(1)).eq.'.<End>') go to 20
            read(line(LinPos(1):LinEnd(3)),*) vx(i), vy(i), vz(i)
            vx(i)=vx(i)*Aps_aufs
            vy(i)=vy(i)*Aps_aufs
            vz(i)=vz(i)*Aps_aufs
            if(Shell_Ref(ISRT(i)).and.dshell_model.eq.0) then
               j=iShell(i)
               read(line(LinPos(4):LinEnd(6)),*) vx(j), vy(j), vz(j)
               vx(j)=vx(j)*Aps_aufs
               vy(j)=vy(j)*Aps_aufs
               vz(j)=vz(j)*Aps_aufs
            end if
            num_rel = num_rel + 1

         end if
      end do

 20   write(9,'(a)')
     &   '.............<Velocity> box is read correctly ..............'
      write(9,'(a/)')
     &'################################################################'
      return
c
 30   vel_key = 0
      write(*,'(a)')
     &'WARNING: ...........Velocities WRONG, initialising .............'
      write(9,'(a)')
     &'WARNING: ...........Velocities WRONG, initialising .............'
      write(9,'(a/)')
     &'################################################################'
      return
      end

      SUBROUTINE FricIn(NFIL,KodErr)
c......................................................................
c... Read in the file UNIT=NFIL the friction coeficients for 
c the stochastic thermostat.
c......................................................................
c    Friction coefficient should be in inverse ps, conversion is 
c required!
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120
      integer LinPos(30),LinEnd(30)
      integer num_rel
      logical error

      nat = 0
      error=.false.

c...... Seeks for the box marker: [.<Friction>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<Friction>',11,NFIL,iErr)
      if(iErr.ne.0) go to 30

      do i=1,Natom
         call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
         if(line(LinPos(1):LinEnd(1)).eq.'.<End>') go to 20
         read(line(LinPos(1):LinEnd(1)),*) stoc(i)
         read(line(LinPos(2):LinEnd(4)),*) fricx(i),fricy(i),fricz(i)
         fricx(i)=fricx(i)/ps_fs
         fricy(i)=fricy(i)/ps_fs
         fricz(i)=fricz(i)/ps_fs
         nat = nat + 1
      end do

 20   if(nat.eq.Natom) then
         write(9,'(a)')
     &   '.............<Friction> box is read correctly ..............'
         write(9,'(a/)')
     &'################################################################'
         return
      end if

 30   write(*,'(a)')
     &'FATAL: ...........Friction Box WRONG .............'
      write(9,'(a)')
     &'FATAL: ...........Friction Box WRONG .............'
         write(9,'(a/)')
     &'################################################################'
      KodErr=1
      return
      end

      SUBROUTINE Tip_Dynamics(NFIL,iPrnt)
c......................................................................
c.....Read in the file UNIT=NFIL the box <TipDynamics>
c......................................................................
c Times - in fs; velocities - in A/fs
c......................................................................
      INCLUDE 'shell.inc'
      character Line*120,na2*2
      integer LinPos(30),LinEnd(30)
      data tiny/0.01/
c
c............. set default values first 
c
      turnback = .false.
      t_period = 1.0
      x_scan_speed = 0.0
      y_scan_speed = 0.0
      t_amplitude = 0.0
      shift(1)=0.0
      shift(2)=0.0
      shift(3)=0.0
      relax_steps=1

c...... Seeks for the box marker: [.<TipDynamics>]  in the file
c_________ Start every time from the beginning of the file
      rewind (NFIL)
      call find_string('.<TipDynamics>',14,NFIL,iErr)
      if(iErr.eq.1) go to 40
c
c........... read the input file: iw - number of words found
c
      dynamic_tip = .true.
      iw=0
 20   call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iErr)
      if(iErr.ne.0) go to 50
      if(index(line,'.<End>').ne.0) go to 100

      if(do_md) then
         if(index(line(LinPos(1):LinEnd(1)),'howto').ne.0) then
            if(NumLin.lt.5) go to 50
            read(Line(LinPos(2):LinEnd(2)),*,END=50,ERR=50) t_amplitude
            read(Line(LinPos(3):LinEnd(3)),*,END=50,ERR=50) t_period
            read(Line(LinPos(4):LinEnd(4)),*,END=50,ERR=50) x_scan_speed
            read(Line(LinPos(5):LinEnd(5)),*,END=50,ERR=50) y_scan_speed
            t_amplitude = t_amplitude*A_au
            t_period = t_period*ps_fs
            x_scan_speed = x_scan_speed*Aps_aufs
            y_scan_speed = y_scan_speed*Aps_aufs
            if(t_period.eq.0.0) t_period = 1.0
            iw=iw+1
            write(9,'(a,i2,a,e12.6)') '...> found (',iw,
     &          ') new value for t_amplitude = ', t_amplitude
            write(9,'(a,i2,a,e12.6)') '...> found (',iw,
     &           ') new value for t_period = ',t_period
            write(9,'(a,i2,a,e12.6)') '...> found (',iw,
     &       ') new value for x_scan_speed = ', x_scan_speed
            write(9,'(a,i2,a,e12.6)') '...> found (',iw,
     &       ') new value for y_scan_speed = ', y_scan_speed
         end if
      else
         if(index(line(LinPos(1):LinEnd(1)),'howto').ne.0) then
            if(NumLin.lt.5) go to 50
            read(Line(LinPos(2):),*,END=50,ERR=50) shift,relax_steps
            shift(1)=shift(1)*A_au
            shift(2)=shift(2)*A_au
            shift(3)=shift(3)*A_au
            iw=iw+1
            write(9,'(a,i2,a,3(x,e12.6),a)') '...> found (',iw,
     &           ') new value for shift = (', shift,')'
            write(9,'(a,i2,a,i5)') '...> found (',iw,
     &           ') new value for relax_steps = ', relax_steps
         
         else if(index(line(LinPos(1):LinEnd(1)),'turnback').ne.0) then
            turnback=.true.
            iw=iw+1
            write(9,'(a,i2,a,l1)') '...> found (',iw,
     &           ') new value for turnback = ', turnback
         end if
      end if

      go to 20

c_________ warning messages
 40   write(9,*)'WARNING! Box <TipDynamics> not found! Using defaults'
      go to 60
 50   write(9,*) 'WARNING! Error while reading Box <TipDynamics>!'
      write(9,*) 'Using default values for the rest of the parameters'
 60   write(9,'(a/)')
     &'################################################################'
      return
c_________ print out the final set of parameters
 100  write(9,*)
     &     '...........<TipDynamics> box is read correctly ..........'

      write(9,'(a,l1)') 'Dynamic tip = ',dynamic_tip

      if(do_md) then
         write(9,*)'>___> during MD simulations with:'
         write(9,*) 'speed in the X direction (A/ps): ',
     &        x_scan_speed*aufs_Aps
         write(9,*) 'speed in the Y direction (A/ps): ',
     &        y_scan_speed*aufs_Aps
         write(9,*) 'tip oscillation amplitude (A) = ',t_amplitude*au_A
         write(9,*) 'tip oscillation period = ',t_period*fs_ps,'  ps'
      else
         write(9,*)'>___> during relaxation calculation with:'
         write(9,*)'turn back: ',turnback
         write(9,*)'elementary displacement (A): ',(shift(j)*au_A,j=1,3)
         write(9,*)'relaxation steps = ',relax_steps
      end if 
      write(9,'(a/)')
     &'################################################################'
      return
      end



