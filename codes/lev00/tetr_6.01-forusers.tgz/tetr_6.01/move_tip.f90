      subroutine move_tip(Which_Code,nkp,kpoint)
!.....................................................................
!    A script is created which runs siesta/vasp on a 3D grid (e.g. for
! simulation of AFM images)
!.....................................................................
      use real8
      use tetrag1
      use afm
      use mlists
      implicit none

      character :: line*200,answer*20
      integer :: LinEnd(100),LinPos(100),NumLin
      character :: cha2*2, Labels(N0LT)*2
      logical :: Frozen_tipat,Frozen_surfat,list_tip(N0LT)
      logical :: list_srf(N0LT)
      logical :: listat(N0LT),Err,star,Yes_Do
      logical :: Moved_Atoms,Vert_Displ
      character :: Which_Code*6,code*6
      real(8) :: Displ(Ndispl0)
      real(8) :: kpoint(Nkpoint,3)
      real(8),dimension(2,2) :: vec
      logical :: Add_Hs=.false.
      integer :: Np1=1,Np2=1,Ndispl=0
      character*4 ::  YES_xyz='Xmol'
      integer :: M11=0,N11=0,M22=0,N22=0,M33=0,N33=0
!
      integer :: nkp,iAt,ii,i,length,L_ext1,l0
      integer :: jd,iLi,j,id,k,i1,iErr,lensur,lentip
      real(8) :: Z_value,s1,s2,s12,s,zlow,zhi,ddd

      vec=reshape((/0.1,0.0,0.0,0.1/),shape(vec))
!
!___________ initialise tags
      Moved_Atoms=.false.
      do i=1,N0LT
         listat(i)=.false.
         list_tip(i)=.false.
         list_srf(i)=.false.
      end do
      code=Which_Code
      iAt=0
      do i=1,Nsp
         do ii=1,NspN(i)
            iAt=iAt+1
            Labels(iAt)=Species(i)
         end do
      end do

!========================================================================
!===================== MENU starts here =================================
!========================================================================

      Z_value=0.0
      Moved_Atoms=.false.
      Vert_Displ=.false.
      Yes_Do=.false.
      Frozen_tipat=.false.
      Frozen_surfat=.false.
 21   write(*,*)
      write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,*)'... CURRENT lattice vectors for the supercell ARE...'
      write(*,'(a,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
      write(*,'(a,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
      write(*,'(a,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      write(*,'(a)') &
           '>>>>>>>>>>>>>>>> Current species are: <<<<<<<<<<<<<<'
      write(*,'(5x,20(a2,x))') (Species(i),i=1,Nsp)
      write(*,*)
      write(*,*)'========= CHOOSE AN OPTION:'
      write(*,*)
      write(*,*) '/============================================\\'
      write(*,*)'||  MIND: current geometry is used as INITIAL  ||'
      write(*,*)'\\=============================================/'
      write(*,*)

      if(.not.Moved_Atoms) then
         length=0
         write(*,*) &
              '  T. Atoms to be moved (e.g. of the tip) <- Not given!'
      else
         write(*,*)'  T. Atoms to be moved (e.g. of the tip):'
         write(*,*) '     >> Current set of tip atoms: '
         call print_long_char(lists,length,long_lists)
         write(*,*)'     >> Choose again to untag'
      end if

      if(Vert_Displ) then
         write(*,*)' Vd. Vertical displacements: ',Ndispl
      else
         write(*,*)' Vd. Vertical displacements: <- Not given!'
      end if

      write(*,*)' Lt. Elementary displacements along the lateral grid:'
      write(*,'(a,2(f10.5,a))')'     [1] (',vec(1,1),',',vec(2,1),')'
      write(*,'(a,2(f10.5,a))')'     [2] (',vec(1,2),',',vec(2,2),')'

      write(*,*)' P1. Points along 1st lateral directions: ',Np1
      write(*,*)' P2. Points along 2nd lateral directions: ',Np2
      write(*,*)' Cd. Code to be used for the calculation: '//code
      write(*,*)'  Z. Tip height for this geometry: ',Z_value
      if(Vert_Displ .and. Moved_Atoms) then
         if(Yes_Do) then
            write(*,*)'  G. Generate the script <-- Done!'
            write(*,*)'     >> script: run_AFM'
         else
            write(*,*)'  G. Generate the script'
         end if
      end if

!_____ getting the input file

      if(Moved_Atoms) then
         write(*,*) &
        '------------ Optional:  t h e  I N P U T  f i l e ------------'
         if(Frozen_tipat) then
            write(*,*)' FT. Frozen atoms in the tip:'
            write(*,*)'     >> Current set of frozen tip atoms: '
            call print_long_char(listip,lentip,long_listip)
         else
            write(*,*)' FT. Frozen atoms in the tip:     <-- not set'
         end if
         if(Frozen_surfat) then
            write(*,*)' FS. Frozen atoms in the surface:'
            write(*,*)'     >> Current set of frozen surface atoms: '
            call print_long_char(lisurf,lensur,long_lisurf)
         else
            write(*,*)' FS. Frozen atoms in the surface: <-- not set'
         end if
         if(Frozen_surfat .and. Frozen_tipat) &
              write(*,*)'  S. Save the input file with constraints'
      end if

!_____ show settings

      write(*,*) &
      '---------- v i s u a l i a s i o n   s e t t i n g s ---------'
!___________ set YES_xyz to the visualisation code:
!            make geom.xyz file automatically after every change
      write(*,'(8x,a)') &
           '>>>>> Current setting for the breeding box: <<<<<'
      write(*,'(13x,a,3(i2,a,i2,a))') '[',M11,'...',N11,'] x [', M22, &
                                 '...',N22,'] x [', M33,'...',N33,']'
      L_ext1=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)
      write(*,'(8x,2(a,i5))') &
           '>>>>> extension = ',L_ext1,', # of atoms= ',ITI*L_ext1

      write(*,*) &
              ' Bb. Set the size of the breeding box for visualisation'
      write(*,*) &
              ' B0. Nullify the breeding box (make the UNIT extension)'

!      if(YES_xyz.ne.'None') then
!         write(*,*)
!     &   ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
!      else
!         write(*,*)
!     &   ' XY. Do NOT produce <geom.xyz> file after every change'
!      end if
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: YES'
         else
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      write(*,*) &
         '  W. Write <geom.xyz> file for preview using current breeding'

      write(*,*) &
      '-------------- g e n e r a l  s e t t i n g s ----------------'
      if(Vert_Displ) write(*,*)' VD. Show vertical displacements'

      write(*,*) &
           ' Co. Show current atomic positions in fractional/Cartesian'

      write(*,*)'  Q. Proceed/Quit'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![T].... tag atoms belonging to the tip using a multiple lists method

      IF(cha2(l0:).eq.'T') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         if(Moved_Atoms) then
            Moved_Atoms=.false.
            write(*,*)'WARNING! The tagging is disabled!'
            go to 21
         end if

!__________ specify wanted atoms
         call TTag(Moved_Atoms,ITI,TI,Labels,listat,lists,length, &
                                                 N_lists,long_lists)

!__________ check if atoms are already frozen from the initial input file
         if((.not.Frozen_tipat) .and. (.not.Frozen_surfat)) then
            do i=1,ITI
               if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' &
                    .or. relax_flag(3,i).eq.'F' ) then
                  if(listat(i)) then
                     list_tip(i)=.true.
                     Frozen_tipat=.true.
                  else
                     list_srf(i)=.true.
                     Frozen_surfat=.true.
                  end if
               end if
            end do
            call do_nice_list(list_tip,ITI,listip,lentip, &
                                                N_lists,long_listip)
            call do_nice_list(list_srf,ITI,lisurf,lensur, &
                                                N_lists,long_lisurf)
         end if

![XY]...... ask whether to produce geom.xyz file automatically

!      ELSE IF(cha2(l0:).eq.'XY') THEN

!         if(YES_xyz.eq.'None') then
!            YES_xyz='Ymol'
!         else if(YES_xyz.eq.'Ymol') then
!            YES_xyz='Xmol'
!         else if(YES_xyz.eq.'Xmol') then
!            YES_xyz='None'
!         end if

![Hs]...... add Hydrongens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else
            Add_Hs=.true.
         end if

![Lt].... choose elementary displacements along the lateral grid

      ELSE IF(cha2(l0:).eq.'Lt') THEN

         write(*,*)'==================================================='
         write(*,*)'MIND: both displacements are given within the XY'
         write(*,*)'      plane, i.e. only 2 coordinates are needed'
         write(*,*)'==================================================='
 1       write(*,*)'Specify the 1st displacement vector (in A):'
         read(*,*,err=1) vec(1,1),vec(2,1)
         write(8,*) vec(1,1),vec(2,1)
 2       write(*,*)'Specify the 2nd displacement vector (in A):'
         read(*,*,err=2) vec(1,2),vec(2,2)
         write(8,*) vec(1,2),vec(2,2)
         s1 = vec(1,1)*vec(1,1)+vec(2,1)*vec(2,1)
         s2 = vec(1,2)*vec(1,2)+vec(2,2)*vec(2,2)
         s12= vec(1,1)*vec(1,2)+vec(2,1)*vec(2,2)
         s=s12/sqrt(s1*s2)
         if(abs(abs(s)-1).lt.tiny_equiv) then
            write(*,*)'ERROR: your vectors are collinear!'
            go to 1
         end if

![P1].... number of grid points along the 1st lateral direction

      ELSE IF(cha2(l0:).eq.'P1') THEN

 3       write(*,*) &
           'Specify # of grid points along the 1st lateral direction:'
         read(*,*,err=3) Np1 ; write(8,*) Np1
         if(Np1.lt.0) go to 3

![P2].... number of grid points along the 2nd lateral direction

      ELSE IF(cha2(l0:).eq.'P2') THEN

 4       write(*,*) &
           'Specify # of grid points along the 2nd lateral direction:'
         read(*,*,err=4) Np2 ; write(8,*) Np2
         if(Np2.lt.0) go to 4

![Cd].... code to be used

      ELSE IF(cha2(l0:).eq.'Cd') THEN

         if(code.eq.'SIESTA') then
            code='  VASP'
         else if(code.eq.'  VASP') then
            code='VASP52'
         else if(code.eq.'VASP52') then
            code='SIESTA'
         end if

![Z].... tip height corresponding to the given geometry

      ELSE IF(cha2(l0:).eq.'Z') THEN

!______________ find the lowest tip atom and the highest surface atom,
!               and then suggest the tip height as the difference

         if(Moved_Atoms) then
             zlow=1.0e10
             zhi=-1.0e10
             do i=1,ITI
                if(listat(i).and.TI(3,i).lt.zlow) zlow=TI(3,i)
                if(.not.listat(i).and.TI(3,i).gt.zhi) zhi=TI(3,i)
             end do
             Z_value=zlow-zhi
             write(*,'(a,f10.5,a)') &
                'The lowest tip atom is at      Z = ',zlow,' A'
             write(*,'(a,f10.5,a)') &
                'The highest surface atom is at Z = ',zhi,' A'
             write(*,'(a,f10.5,a)') &
                'The suggested tip height         = ',Z_value,' A'
7            write(*,*)'Press ENTER to accept or enter another value:'
             read(*,'(a)') answer ; write(8,'(a)') answer
             if(answer.eq.'') go to 21
             read(answer,*,err=7) Z_value
             go to 21
          end if
8         write(*,*)'Specify the tip height:'
          read(*,*,err=8) Z_value ; write(8,*) Z_value

![Vd].... give vertical displacements

      ELSE IF(cha2(l0:).eq.'Vd') THEN

 5       write(*,*)'==================================================='
         write(*,*)'Specify vertical displacements using space or comma'
         write(*,*)'between lists and * sign for repetitions inside'
         write(*,*)'each list, e.g.:  -1.0*5 -0.5*10, -0.25, -0.1*10'
         write(*,*)'==================================================='
         read(*,'(a)') line ; write(8,'(a)') trim(line)
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 5
         if(NumLin.eq.0) then
            Vert_Displ=.false.
            write(*,*)'WARNING! Vertical displacements NOT given!'
            go to 21
         end if

!______________ analise each word (list) and construct displacements
         jd=0
         do i=1,NumLin
            iLi=LinEnd(i)-LinPos(i)+1
            star=.false.
            do j=LinPos(i),LinEnd(i)
               if(line(j:j).eq.'*') then
                  star=.true.
                  read(line(LinPos(i):j-1),*,err=10) ddd
                  if(ddd.eq.0.0) go to 10
                  read(line(j+1:LinEnd(i)),*,err=10) id
                  if(jd+id.gt.Ndispl0) go to 11
                  do k=1,id
                     Displ(jd+k)=ddd
                  end do
                  jd=jd+id
               end if
            end do
            if(.not.star) then
               read(line(LinPos(i):LinEnd(i)),*,err=10) ddd
               if(i.gt.1 .and. ddd.eq.0.0) go to 10
               jd=jd+1
               if(jd+1.gt.Ndispl0) go to 11
               Displ(jd+1)=ddd
            end if
         end do
         Vert_Displ=.true.
         Ndispl=jd
         go to 21
 10      write(*,*)'ERROR! Try again!'
         go to 5
 11      write(*,*)'ERROR! Too many displacements:'
         write(*,*)'       Ndispl0 in [afm.inc] is too small !'
         Vert_Displ=.false.
         Ndispl = 0
         go to 21

![VD].... show vertical displacements

      ELSE IF(cha2(l0:).eq.'VD') THEN

         do i=1,Ndispl,10
            i1=i+9
            if(i1.gt.Ndispl) i1=Ndispl
            write(*,'(10(f6.2,x))') (Displ(j),j=i,i1)
         end do
         write(*,*)'Press ENTER when ready ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN

         call show_atoms(listat)

![Bb].... ask extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'Bb') THEN

!___________ ask extensions along the existing lattice vectors for the
!            breeding box
         call ask_breeding_box(M11,N11,M22,N22,M33,N33)
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![B0].... nullify the extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'B0') THEN

         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W') THEN

!___________ constract all lattice sites  and write geom.xyz
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![G].... generate script

      ELSE IF(cha2(l0:).eq.'G' .and. Vert_Displ .and. Moved_Atoms) THEN

         call do_AFM_script(Np1,Np2,vec,lists,length,Displ, &
              Ndispl,code,Z_value,long_lists)
         Yes_Do=.true.

![FT].... choose frozen tip atoms from the tip atoms

      ELSE IF(cha2(l0:).eq.'FT' .and. Moved_Atoms) THEN

         if(Frozen_tipat) then
            do i=1,ITI
               if(list_tip(i)) then
                  relax_flag(1,i)='T'
                  relax_flag(2,i)='T'
                  relax_flag(3,i)='T'
                  list_tip(i)=.false.
               end if
            end do
            Frozen_tipat=.false.
            write(*,*)'WARNING! The frozen tip atoms unselected!'
            go to 21
         end if

!__________ specify wanted atoms
 44      write(*,*)'================================================='
         write(*,*)'Tip atoms are: '
         call print_long_char(lists,length,long_lists)
         write(*,*)'================================================='
         call TTag(Frozen_tipat,ITI,TI,Labels,list_tip,listip,lentip, &
                                                N_lists,long_listip)

!__________ check that the chosen atoms belong to the tip
         Err=.false.
         do i=1,ITI
            if(list_tip(i)) then
               if(.not. listat(i)) then
                  write(*,*) &
                       'ERROR: atom ',i,' does not belong to the tip!'
                  Err=.true.
               end if
            end if
         end do
         if(Err) go to 44

!__________ set relaxation flags
         do i=1,ITI
            if(list_tip(i)) then
               relax_flag(1,i)='F'
               relax_flag(2,i)='F'
               relax_flag(3,i)='F'
            end if
         end do
         Frozen_tipat=.true.

![FS].... choose frozen tip atoms from the surface (NOT belonging to the tip)

      ELSE IF(cha2(l0:).eq.'FS' .and. Moved_Atoms) THEN

         if(Frozen_surfat) then
            do i=1,ITI
               if(list_srf(i)) then
                  relax_flag(1,i)='T'
                  relax_flag(2,i)='T'
                  relax_flag(3,i)='T'
                  list_srf(i)=.false.
               end if
            end do
            Frozen_surfat=.false.
            write(*,*)'WARNING! The frozen surface atoms unselected!'
            go to 21
         end if

!__________ specify wanted atoms
 45      write(*,*)'================================================='
         write(*,*)'Tip atoms are: '
         call print_long_char(lists,length,long_lists)
         write(*,*)'================================================='
         call TTag(Frozen_surfat,ITI,TI,Labels,list_srf,lisurf,lensur, &
                                   N_lists,long_lisurf)

!__________ check that the chosen atoms do NOT belong to the tip
         Err=.false.
         do i=1,ITI
            if(list_srf(i)) then
               if(listat(i)) then
                  write(*,*) &
                       'ERROR: atom ',i,' belongs to the tip!'
                  Err=.true.
               end if
            end if
         end do
         if(Err) go to 45

!__________ set relaxation flags
         do i=1,ITI
            if(list_srf(i)) then
               relax_flag(1,i)='F'
               relax_flag(2,i)='F'
               relax_flag(3,i)='F'
            end if
         end do
         Frozen_surfat=.true.

![S].... save the input file

      ELSE IF(cha2(l0:).eq.'S' .and. Moved_Atoms .and. &
                           Frozen_tipat .and. Frozen_surfat) THEN
         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,code,YES_xyz,.false.)

![Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine move_tip

      subroutine do_AFM_script(Np1,Np2,vec,lists,length,Displ,Ndispl, &
                                            code,Z_value,long_lists)
!........................................................................
! writes the AFM script
!........................................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: vec(2,2),Displ(Ndispl)
      logical :: long_lists
      character :: code*6,lists*200,ch*3
!
      integer :: Np1,Np2,length,Ndispl,j,is,i
      real(8) :: Z_value

      if(long_lists) then
         write(*,*)'WARNING! Your list of tip atoms will be incomplete!'
         write(*,*)'         Edit manually run_AFM script!'
         write(*,*)'Hit ENTER when ready ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'
      end if
!.......... open run_AFM file for the script
      open(37,file='run_AFM',form='formatted',status='unknown')

!......... write the heading
      write(37,'(a)')'#! /bin/csh -f'
      write(37,'(a)') &
      '###############################################################'
      write(37,'(a)') &
      '# calculation of 3D force field  - for AFM imaging calculations'
      write(37,'(a)') &
      '###############################################################'
      write(37,'(a)')'# syntax:'
      write(37,'(a)')'#          run_AFM '
      write(37,'(a)') &
      '###############################################################'
      if(code.eq.'SIESTA') then
         write(37,'(a)')'# IMPORTNAT!  Before running the script:'
         write(37,'(a)')'#    (1) run SIESTA for the initial geometry'
         write(37,'(a)') &
            '#    (2) prepare INPUT_FILE.fdf with the relaxed geometry'
         write(37,'(a)')'#        using e.g. option Ss in tetr'
         write(37,'(a)') &
            '#    (3) Set SystemLabel in INPUT_FILE.fdf to INPUT_FILE'
         write(37,'(a)') &
            '#    (4) Remove UseSaveData and DM.UseSaveDM from the file'
         write(37,'(a)') &
         '#    (5) change entry_count to the count number at which to '
         write(37,'(a)') &
         '#        restart the calculation if stopped with an ERROR '
         write(37,'(a)')'#        during the run of the script'
      else
         write(37,'(a)')'# IMPORTNAT!  Before running the script:'
         write(37,'(a)')'#    (1) run VASP for the initial geometry'
         write(37,'(a)')'#    (2) save the relaxed geometry in POSCAR'
         write(37,'(a)')'#    (3) set ISTART=1 in INCAR file'
         write(37,'(a)') &
         '#    (4) change entry_count to the count number at which to'
         write(37,'(a)') &
         '#        restart the calculation if stopped with an ERROR'
         write(37,'(a)')'#        during the run of the script'
      end if
      write(37,'(a)') &
      '###############################################################'
      write(37,'(a/)')'set entry_count=0'
      write(37,'(a)')'echo > null'

!........... write tip atoms
      write(37,'(a)')'#... tip atoms (to be moved at each step)'
      write(37,'(a)')'set tip=( '//lists(1:length)//' )'
      write(37,'(a,f10.5,a)')'set zt0=(',Z_value,')'

!............ write displacement vectors
      write(37,'(a)') &
      '#... elementary displacement vectors within the surface '
      write(37,'(2(a,f6.2),a)')'set a1= ( ',vec(1,1),' ',vec(2,1),' )'
      write(37,'(2(a,f6.2),a)')'set a2= ( ',vec(1,2),' ',vec(2,2),' )'

!............ code dependent part and templates for tetr
      write(37,'(a)')'#... templates for tetr'
      if(code.eq.'SIESTA') then
         write(37,'(a)')'set cd=(4 INPUT_FILE)'
         write(37,'(a)')'set Sp='
         write(37,'(a)')'echo > ttmp1'
         write(37,'(a)')'foreach word ( $cd Ss $cd[2] Q )'
         write(37,'(a)')'   echo $word >> ttmp1'
         write(37,'(a)')'end'
         write(37,'(a)') 'if ($entry_count == 0 ) '// &
                            '/bin/cp INPUT_FILE.fdf INPUT_FILE_ini.fdf'
      else if(code.eq.'  VASP') then
         write(37,'(a)')'set cd=(3 POSCAR)'
         write(ch,'(i3)') Nsp
         write(37,'(a,'//ch//'(a,x),a)') &
              'set Sp=( ',(Species(is),is=1,Nsp),' )'
         write(37,'(a)')'/bin/cp POSCAR POSCAR_ini'
      else if(code.eq.'VASP52') then
         write(37,'(a)')'set cd=(8 POSCAR)'
         write(37,'(a)')'/bin/cp POSCAR POSCAR_ini'
      end if
      write(37,'(a)')'echo > ttmp'
      write(37,'(a)') &
           'foreach word ( $cd $Sp M T $tip Mv 4 Displ S $cd  Q Q )'
      write(37,'(a)')'   echo $word >> ttmp'
      write(37,'(a/)')'end'

!............. start loops: lateral
      write(37,'(a)') &
      '#[1]... make loops over displcements along 3 directions'
      write(37,'(a/)')'set count=0'
      write(ch,'(i3)') Np1
      write(37,'(a,'//ch//'(i3,x),a)')'foreach n1 ( ',(j,j=0,Np1-1),' )'
      write(ch,'(i3)') Np2
      write(37,'(/a,'//ch//'(i3,x),a/)') &
                     '   foreach n2 ( ',(j,j=0,Np2-1),' )'
      write(37,'(a)')'#________ restore the initial geometry'
      if(code.eq.'SIESTA') then
         write(37,'(5x,a/)')'/bin/cp INPUT_FILE_ini.fdf INPUT_FILE.fdf'
      else
         write(37,'(a/)')'     /bin/cp POSCAR_ini POSCAR'
      end if
      write(37,'(a)') &
      "     echo '<============= n1= '$n1' and n2= '$n2' =========>'"
      write(37,'(a)')'     if( ! -e $n1.$n2 ) mkdir $n1.$n2'
      write(37,'(a)')'#________ calculate the actual displ. vector'
      write(37,'(a)')'     if( $n1 != 0 || $n2 != 0) then'
      write(37,'(a)') &
      "        awk 'BEGIN {d1='$n1'*'$a1[1]'+'$n2'*'$a2[1]'; "//char(92)
      write(37,'(a)') &
      "                    d2='$n1'*'$a1[2]'+'$n2'*'$a2[2]'; "//char(92)
      write(37,'(a)')"                      print d1,d2 } ' null > tmp"
      write(37,'(a)')"        set displ=`cat tmp` "
      write(37,'(a)')"        echo '========== Displacement = ' $displ"
      write(37,'(a)') &
       '#_____________ create the input file with the displaced tip'
      write(37,'(7x,a)') &
        " sed -e 's/Displ/'$displ[1]' '$displ[2]' 0.0/g' ttmp > tinp "
      write(37,'(a)')'        /bin/cp tinp $n1.$n2/.'
      write(37,'(a)')'        tetr < tinp >& tout'
      write(37,'(a)')'#_____________ check for possible errors'
      write(37,'(a)') &
           '        if ( `cat tout| grep -i err| wc -l` != 0) then'
      write(37,'(a)')'           mv tout $n1.$n2/.'
      write(37,'(11x,a)') &
         "echo 'STOP: ERROR in TETR when Mv; check file ' $n1.$n2/tout"
      write(37,'(a)')"           echo 'stopped at count = '$count"
      write(37,'(a)')'           exit'
      write(37,'(a)')'        endif'
      write(37,'(a)')'     endif'
      if(code.eq.'SIESTA') then
         write(37,'(a)')"     echo 'DM.UseSaveDM F' >> INPUT_FILE.fdf"
         write(37,'(a)')'     /bin/cp INPUT_FILE.fdf $n1.$n2/.'
      else
         write(37,'(a)')'     /bin/cp POSCAR $n1.$n2/.'
      end if

!............. start loop: vertical

      write(37,'(/a)') &
         '#[2]........ loop over vert. down displs (may be noneven)'
      write(37,'(a)')'     set z=0'
      write(37,'(a)')'     set zt=$zt0'
      write(37,'(a)')'     if( ! -e $n1.$n2/tip_forces_z ) then'
      write(37,'(a)')'        echo > $n1.$n2/tip_forces_z'
      write(37,'(a)')'     endif'
      write(ch,'(i3)') Ndispl
      write(37,'(a,'//ch//'(f6.2,x),a/)') &
           '     foreach zd ( 0.0 ',(Displ(i),i=1,Ndispl),'  )'
      write(37,'(a)') '#____________ if restart: update input file to'// &
           ' the nearest from the previous run'
      write(37,'(a)')'         @ count = $count + 1'
      write(37,'(a)')'         if ( $entry_count != 0 && $entry_count'// &
           ' == $count) then'
      if(code.eq.'SIESTA') then
         write(37,'(12x,a)') 'if ( $z > 0 ) '// &
              '/bin/cp $n1.$n2/$z/INPUT_FILE-relaxed.fdf INPUT_FILE.fdf'
      else
         write(37,'(12x,a)') &
              'if ( $z > 0 ) /bin/cp $n1.$n2/$z/CONTCAR POSCAR'
      end if
      write(37,'(a)')'         endif'
      write(37,'(a)')'#____________ calculate down displacement and'// &
           ' vertical coordinate'
      write(37,'(a)')'         @ z = $z + 1'
      write(37,'(7x,a)') "  echo '<== '$count' "// &
           "............$z= '$z' --> zd= '$zd' .........==>'"
      write(37,'(7x,a)') &
         "  awk 'BEGIN { e=('$zt')+('$zd'); print e }' null > tmp"
      write(37,'(a)')'         set zt=`cat tmp`'
      write(37,'(a)')'         if( ! -e $n1.$n2/$z ) mkdir $n1.$n2/$z'
      write(37,'(a)')'#_____________ move the tip by the displcement'
      write(37,'(a)')'         if( $z != 1 ) then '
      write(37,'(12x,a)')"sed -e 's/Displ/0.0 0.0 '$zd'/g' ttmp > tinp"
      write(37,'(a)')'            /bin/cp tinp $n1.$n2/$z/.'
      write(37,'(a)')'            tetr < tinp >& tout'
      write(37,'(a)')'#_____________ check for possible errors'
      write(37,'(12x,a)') &
           "if ( `cat tout| grep -i err| wc -l` != 0) then"
      write(37,'(a)')'               mv tout $n1.$n2/$z/.'
      write(37,'(15x,a)')"echo 'STOP: ERROR in TETR when Mv; "// &
           "check file ' $n1.$n2/$z/tout"
      write(37,'(a)')"               echo 'stopped at count = '$count"
      write(37,'(a)')'               exit'
      write(37,'(a)')'            endif'
      if(code.eq.'SIESTA') write(37,'(a)') &
           "            echo 'DM.UseSaveDM T' >> INPUT_FILE.fdf"
      write(37,'(a)')'         endif'
      write(37,'(9x,a)')"echo '============ Displacement = 0.0 0.0 "// &
           "' $zd ' and height = ' $zt"
      if(code.eq.'SIESTA') then
         write(37,'(a)')'         /bin/cp INPUT_FILE.fdf  $n1.$n2/$z/.'
      else
         write(37,'(a)')'         /bin/cp POSCAR $n1.$n2/$z/.'
      end if
      write(37,'(a)')'#______________ run the code'
      write(37,'(a)')'         if( $entry_count < = $count) then'

      if(code.eq.'SIESTA') then
         write(37,'(a)')'            siesta >& OUTCAR'
         write(37,'(a)')'#______________ create the final fdf file'
         write(37,'(a)')'            if( -e INPUT_FILE.XV ) then'
         write(37,'(3x,a)')'            tetr < ttmp1 >& tout'
         write(37,'(3x,a)') &
         "            if ( `cat tout| grep -i err| wc -l` != 0) then"
         write(37,'(3x,a)')'               mv tout $n1.$n2/$z/.'
         write(37,'(3x,a)')"               echo 'STOP: ERROR in TETR"// &
              " when Ss; check file ' $n1.$n2/$z/tout"
         write(37,'(18x,a)') "echo 'stopped at count = '$count"
         write(37,'(3x,a)')'               exit'
         write(37,'(3x,a)')'            endif'
         write(37,'(3x,a)') &
              '            /bin/mv INPUT_FILE.XV $n1.$n2/$z/.'

         write(37,'(6x,a)') &
                '         /bin/cp INPUT_FILE-relaxed.fdf $n1.$n2/$z/.'
         write(37,'(6x,a)') &
             '         /bin/mv INPUT_FILE-relaxed.fdf INPUT_FILE.fdf'
         write(37,'(a)')'            else'
         write(37,'(15x,a)') &
              '/bin/cp INPUT_FILE.fdf $n1.$n2/$z/INPUT_FILE-relaxed.fdf'
         write(37,'(a)')'            endif'

      else
         write(37,'(3x,a)')'         vasp >& output'
         write(37,'(3x,a)')'         /bin/mv output $n1.$n2/$z/.'
         write(37,'(3x,a)')'         /bin/cp CONTCAR $n1.$n2/$z/.'
         write(37,'(3x,a)')'         /bin/mv CONTCAR POSCAR'
      end if

!_____________ get forces in the directory

      write(37,'(3a)')'#_______________ get forces, tip force and'// &
           ' check if DFT finshed relaxation'
      write(37,'(3x,3a)')'         $HOME_TETR/get_forces F OUTCAR ', &
                               lists(1:length),' > $n1.$n2/$z/tip_force'
      write(37,'(3x,a)')'         /bin/mv OUTCAR $n1.$n2/$z/.'
      write(37,'(12x,a)') &
      'if ( `cat $n1.$n2/$z/tip_force| grep -i error| wc -l` != 0) then'
      write(37,'(15x,a)')"echo 'STOP: ERROR in get_forces; check file"// &
           " ' $n1.$n2/$z/tip_force"
      write(37,'(15x,a)')"echo 'STOP: ERROR in get_forces; check file"// &
           " ' $n1.$n2/$z/OUTCAR"
      write(37,'(15x,a)')"echo 'stopped at count = '$count"
      write(37,'(a)')'               exit'
      write(37,'(a)')'            endif'
      write(37,'(3x,a)')'         set tf=`cat $n1.$n2/$z/tip_force`'
      write(37,'(12x,a)') &
         'echo $z $zt $tf[1] $tf[2] $tf[3] >> $n1.$n2/tip_forces_z'
      write(37,'(3x,a)')'         /bin/mv tmp.f $n1.$n2/$z/forces'
      write(37,'(a/)')'         endif'
      write(37,'(a/)')'     end'
      write(37,'(a/)')'   end'
      write(37,'(a)')'end'
      close (37)
      return
      end subroutine do_AFM_script

