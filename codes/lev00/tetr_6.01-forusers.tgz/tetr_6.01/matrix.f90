module matrix
use sym_par  
implicit none
!............ matrices for options V2, V3
!      common /matrices/ G_mat,F_mat
!........... memory for eigenproblem
!      common /eigen/ EigV,Work,EigR
!       real(8) :: G_mat(K0DM0,K0DM0),F_mat(K0DM0,K0DM0)
       real(8),dimension(:,:),allocatable :: G_mat,F_mat
!       real(8) :: EigV(K0DM0,K0DM0),Work(K0DM0),EigR(K0DM0)
       real(8),dimension(:,:),allocatable :: EigV
       real(8),dimension(:),allocatable :: Work,EigR
end module matrix
