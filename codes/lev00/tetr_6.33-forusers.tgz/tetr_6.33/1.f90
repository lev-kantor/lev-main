program test
  implicit none
  real*8 :: a,tiny=0.0001

  
1  read(*,*) a
  write(*,*) a, int(a),nint(a)


         if(abs(a-nint(a)).lt.tiny) a=nint(a)
         a=a-int(a)+1
         a=a-int(a)
 
write(*,'(f10.5)') a
  
  go to 1

end program test
