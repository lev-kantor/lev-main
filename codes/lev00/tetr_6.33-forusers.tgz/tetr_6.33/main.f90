
program tetr
!.........................................................................
!..........[This is kept for historical reasons]..........................
!.........................................................................
!
!..................This program was written to simplify ................
!..................an input to CASTEP. At the moment it ................
!..................produces "fort.15" file contained:   ................
!..................................
!..................- direct lattice vectors;            ................
!..................- atomic coordinates in the cell;    ................
!..................- k-points and their weights.        ................
!..................................
!.........................................................................
!.................    L.N.Kantorovich        25.07.94     ................
!.........................................................................
!
      use real8
      use tetrag1
      use siesta
      use pgroup
      use systema
      implicit none
      character(len=FLEN) :: seed0
      character :: Which_Code*6,cha2*2,word*14
      logical :: read_c,okay,Err,run_from_inside,ts_list(N0LT)
      real(8) :: kpoint(Nkpoint,3),Add_Vects(5,3)
      integer,parameter :: M1=0,N1=0,M2=0,N2=0,M3=0,N3=0
      character*4, parameter ::  YES_xyz='Xmol'
!
      integer :: i0,iargc,Nkp,l0seed0,M11,M22,N11,N22,M33,N33,l0

!______check if TETR is run under Chimera:
      i0=iargc()
      if(i0.eq.0) then
         CHIMERA=.false.
         write(*,*)'>>>> CHIMERA is OFF'
         run_from_inside=.false.
         write(*,*)'>>> primary run of TETR '
      else
         call getarg(1,word)
         i0=index(word,'CHIMERA=true') + index(word,'CHIMERA=T') &
              + index(word,'CHIMERA=.TRUE.')
         if(i0.ne.0) then
            CHIMERA=.true.
            write(*,*)'>>>> CHIMERA is ON'
         end if
         i0=index(word,'-inside')
         if(i0.ne.0) then
            run_from_inside=.true.
            write(*,*)'>>> secondary run of TETR from inside'
         end if
      end if
!
!___________log file recording all the commands in the order they were
!           given
      if(.not.run_from_inside) then
         open(8,file='tetr.log',STATUS='replace',form='formatted')
      else
         open(8,file='tetr_ins.log',STATUS='replace',form='formatted')
      end if
!
!___ elements of all groups
!
      call C_matrix()
      call elem_numb()
!
!___ read_c=.true. if ALL coordinates have been already read in by
!                   read_coord(); otherwise, it is .false.
      call initialise(nkp,read_c)
!
!___ setting initial precision for checking atomic positions for
!    equivalence
!
      tiny_equiv=0.0001d0
!
!....... the hat
      call hat()
!
!....... ask about the code: which format?
 111  call which_PW_code(Which_Code)
      seed0=seed
      l0seed0=l0seed
!
!....... read geometry information from the file
      if(Which_Code.ne.'   NEW') then
         call initiate(Which_Code,seed0,l0seed0,Err)
         if(Err) then
            read_c=.false.
            go to 111
         else
            read_c=.true.
         end if
      end if
!
!........ initial setting:
!             origin - if to move closer to the centre of the coord. system
!             donot_kp - if to leave the k-points unchanged
!
      origin=.false.
      donot_kp=.false.

!....... this is needed to avoid calling ask_which_format()
      if_call_which_format=.true.
!
!......ask what to do in the MAIN MENU
!
!_________ calculate reciprocal lattice vectors in 2*PI units
 1    if(read_c) call INVER(AJ,BJ)

      if(CHIMERA .and. read_c) then
         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         ts_list=.false.
         call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz, &
              .false.,0,Add_Vects,ts_list)
      end if

      write(*,*)'/---------------------------------------------------\\'
      write(*,*)'|.................... MAIN MENU:.....................|'
      write(*,*)'\\---------------------------------------------------/'

      write(*,*)
      write(*,*) &
               '>>>>>>>>>>>>>  Create unit cell from scratch <<<<<<<<'
      write(*,*)  '               [current geometry will be lost] '
      write(*,*) &
      '  B. Generate cell from scratch || Pc. Generate from space group'
      write(*,*)
      write(*,*) &
              '>>>>>>>>>>>>>>>>>  Cluster construction  <<<<<<<<<<<<<'
      write(*,*)'  Cl. Build up a cluster from the lattice'

      if(Which_Code.ne.'   NEW') then
         write(*,*)
         write(*,*) &
              '>>>>>>>>>>>>> Geometry file already exists <<<<<<<<<<<'
         write(*,*) &
      '  M. Complex cell modifications ||  KP. k-points generation '
!         write(*,*)'  La. Build up a layered cell (e.g. for SBC)'
         write(*,*)
         write(*,*) &
              '>>>>>>>>>>>>>>>  PHONONS: preparation <<<<<<<<<<<<<<<<'
         write(*,*) &
       ' Vm. Vibrations of molecules    || Vc. Crystals (point group)'
         write(*,*) &
       ' Vs. Crystals (space group)     || Vk. Crystals (k-points)'
         write(*,*)
         write(*,*) &
              '>>>>>>>>>>>>>>>  PHONONS: calculation <<<<<<<<<<<<<<<<'
         write(*,*) &
       ' V2. Vibrations [normal modes]  || V3. Vibrations application'
         if(Which_Code.eq.'QUICKS') then
            write(*,*)
            write(*,*)'>>>>>>>>>> CURRENT: preparation of systems <<<<<<<<<<<'
            write(*,*) ' SC. Create a mesh of tip apex positions [S+C or S+C+T system] (EA model)'
            write(*,*) ' CT. Keep tip, replace the apex molecule from file [C+T system] (EA model)'
         end if
         write(*,*)
         write(*,*) &
              '>>>>>>>>>>>>>>>>>  Miscellaneous  <<<<<<<<<<<<<<<<<<<<'
         write(*,*) &
       ' Cm. Compare geometries         ||  D. Interatomic distances'
         write(*,*) &
              ' PE. Move atoms via symmetry    || Ch. Check a specified point'
         write(*,*) ' NB. Interpolate between 2 geometries (for NEB)' 
         if(Which_Code.eq.'SIESTA' .or. Which_Code.eq.'  VASP' &
                .or. Which_Code.eq.'VASP52') then
            write(*,*) &
         ' AF. Script for AFM modelling   || Ew. Coulomb potential'
         else
            write(*,*)' Ew. Coulomb potential inside the unit cell'
         end if
         if(Which_Code.eq.'QUICKS') then
            write(*,*) ' 2K. Create CP2K file with relaxed geometry from output'
            write(*,*) ' A2. Create XYZ file along the CP2K relaxation run'
         end if
         if(Which_Code.eq.'CASTEP') &
         write(*,*)' An. Animation XYZ file of the relaxation process'
         write(*,*) &
           ' Sb. Save XYZ file in a box running across adjacent cells'
      end if
 3    write(*,*)
      write(*,*)'---------- g e n e r a l  s e t t i n g s -----------'
!      write(*,*)' XY. Format of <geom.xyz> is set to '//YES_xyz
      if(Which_Code.eq.'SIESTA') then
        if(where_siesta.eq.'SIESTA') then
           write(*,*)' Ss. Save SIESTA settings with geometry'// &
                                                ' from another XV file'
        else if(where_siesta.eq.'SIE-XV') then
           write(*,*)' Ss. Save geometry with SIESTA settings'// &
                                               ' from another fdf file'
        end if
      else
         if(Which_Code.eq.'QUICKS') write(*,*) &
             ' Ss. Update geometry from the QUICKSTEP output XYZ file'
      end if
      write(*,*) '  R. Read geometry from file    ||  S. Save'
      write(*,*) '  Q. Quit.'
      write(*,*)
      write(*,*)'Specify the character and press ENTER ------->'
      read(*,'(a)',err=1) cha2  ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![B].......... generate primitive geometry from scratch

      IF(cha2(l0:).eq.'B') THEN
         Which_Code='   NEW'
         call initialise(nkp,read_c)
         write(*,*) 'The geometry  will be prepared!'
         call build_lat(okay)
         if(okay) then
            read_c=.true.
            Which_Code='  None'
         end if

![Pc].......... primitive cell from space group

      ELSE IF(cha2(l0:).eq.'Pc') THEN
         Which_Code='   NEW'
         call initialise(nkp,read_c)
         write(*,*) 'The geometry  will be prepared!'
         call lattice_space(okay,nkp,kpoint,Which_Code)
         if(okay) then
            read_c=.true.
            Which_Code='  None'
         end if

![R].......... read geometry from file

      ELSE IF(cha2(l0:).eq.'R') THEN
         Which_Code='   NEW'
         call initialise(nkp,read_c)
         write(*,*)'Read geometry from file!'
 11      call which_PW_code(Which_Code)
         seed0=seed
         l0seed0=l0seed
         if(Which_Code.ne.'   NEW') then
            call initiate(Which_Code,seed0,l0seed0,Err)
            read_c=.true.
            if(Err) go to 11
         end if

![M].......... sophisticated modification of geometry file

      ELSE IF(cha2(l0:).eq.'M' .and. Which_Code.ne.'   NEW') THEN

         call change(nkp,kpoint,Which_Code)

![KP].......... generating k-points

      ELSE IF(cha2(l0:).eq.'KP' .and. Which_Code.ne.'   NEW') THEN

         call problem(Which_Code,kpoint,nkp,YES_xyz)

![Cl].......... Cluster

      ELSE IF(cha2(l0:).eq.'Cl') THEN

         if(Which_Code.ne.'   NEW') then
            okay=.true.
         else
            okay=.false.
         end if
         call cluster(okay,Which_Code)
         if(Which_Code.eq.'   NEW' .and. okay) then
            read_c=.true.
            Which_Code='  None'
         end if

![La].......... build a layered system, e.g. for Stochastic Boundary Conditions
!               calculations

      ELSE IF(cha2(l0:).eq.'La') THEN

!         call onion_build(Which_Code)

![Ew].......... Coulomb potential

      ELSE IF(cha2(l0:).eq.'Ew' .and. Which_Code.ne.'   NEW') THEN

         call Coulomb()

![Vm]......... study vibrations of molecules: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vm' .and. Which_Code.ne.'   NEW') THEN

         system='MOLECULE'
         call mol_vibr(Which_Code,kpoint,nkp)

![Vc]......... study vibrations of crystals: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vc' .and. Which_Code.ne.'   NEW') THEN

         system=' LATTICE'
         call mol_vibr(Which_Code,kpoint,nkp)

![Vs]......... study vibrations of crystals: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vs' .and. Which_Code.ne.'   NEW') THEN

         system='LATT-TRA'
         call crystal_vibr(Which_Code,kpoint,nkp)

![Vk]......... study vibrations of crystals: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vk' .and. Which_Code.ne.'   NEW') THEN

         system=' K-POINT'
         call kpoint_vibr(Which_Code,kpoint,nkp)

![V2]......... calculations of vibrational frequencies

      ELSE IF(cha2(l0:).eq.'V2' .and. Which_Code.ne.'   NEW') THEN

         call eig_vibr(Which_Code)

![V3]......... application

      ELSE IF(cha2(l0:).eq.'V3' .and. Which_Code.ne.'   NEW') THEN

         call make_fcm(Which_Code)

![AF]......... AFM imaging script

      ELSE IF(cha2(l0:).eq.'AF' .and. &
          (Which_Code.eq.'SIESTA' .or. Which_Code.eq.'  VASP' &
                                .or. Which_Code.eq.'VASP52')) then

         call move_tip(Which_Code,nkp,kpoint)

![Cm].......... compare geometry with the one in another file

      ELSE IF(cha2(l0:).eq.'Cm' .and. Which_Code.ne.'   NEW') THEN

         call compare()

![NB].......... interpolate between 2 geometries (for NEB)

      ELSE IF(cha2(l0:).eq.'NB' .and. Which_Code.ne.'   NEW') THEN

         call neb_interpolate()

![SC].......... mesh (grid) of positions for the tip atoms for the STM_EA model
!               This is used in the STM_EA models 1-5
         
      ELSE IF(cha2(l0:).eq.'SC' .and. Which_Code.eq.'QUICKS') THEN

         call EA_model_mesh(Which_Code)
         
![CT].......... read for_lev00.dat file of the previously created mesh and apply
!               the grid to the tip and saving it in a T_atoms.inc file.
!               This is used in the STM_EA models 3-5

      ELSE IF(cha2(l0:).eq.'CT' .and. Which_Code.eq.'QUICKS') THEN

         call EA_model_mesh_tip(Which_Code)

![2K].......... replace current [coordinates.inc] with the ones from the CP2K output 
!               xyz file (the last iteration after relaxation) 

      ELSE IF(cha2(l0:).eq.'2K' .and. Which_Code.eq.'QUICKS') THEN

         call read_CP2K_xyz_last()

![A2].......... save XYZ file from the CP2K XYZ file output
!               (any iteration along the relaxatioon run)

      ELSE IF(cha2(l0:).eq.'A2' .and. Which_Code.eq.'QUICKS') THEN

         call read_CP2K_xyz_any()

![Ge].......... dump Cartesian coordinates into XYZ file

      ELSE IF(cha2(l0:).eq.'Ge' .and. Which_Code.ne.'   NEW') THEN

![D].......... study distances between atoms

      ELSE IF(cha2(l0:).eq.'D' .and. Which_Code.ne.'   NEW') THEN

         call distances()

![Ch].......... check point in the cell

      ELSE IF(cha2(l0:).eq.'Ch' .and. Which_Code.ne.'   NEW') THEN

         call add_rem()

![An]........... animation XYZ file after relaxation run

!      ELSE IF(cha2(l0:).eq.'An' .and. Which_Code.ne.'   NEW') THEN
      ELSE IF(cha2(l0:).eq.'An' .and. Which_Code.eq.'CASTEP') THEN

         call write_animate_xyz(Which_Code)

![PE]........... moving atoms (for petential energy surfaces) keeping the
!                symmetry

      ELSE IF(cha2(l0:).eq.'PE' .and. Which_Code.ne.'   NEW') THEN

         call move_atoms(nkp,kpoint,Which_Code)

![S]........... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S' .and. Which_Code.ne.'   NEW') THEN

         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

![Ss]........... save final fdf file after relaxation (i.e. combine the latest
!                XV file with the initial fdf one)

      ELSE IF(cha2(l0:).eq.'Ss') THEN
         if(Which_Code.eq.'SIESTA') then
            call write_final_siesta()
         else if(Which_Code.eq.'QUICKS') then
            call write_final_cp2k(YES_xyz)
         end if

![Sb]........... create an XYZ file of a box running across adjacent cells

      ELSE IF(cha2(l0:).eq.'Sb' .and. Which_Code.ne.'   NEW') THEN

         call write_in_box(Which_Code,YES_xyz)

![XY]...... ask which visualisation package

!      ELSE IF(cha2(l0:).eq.'XY') THEN

!         if(YES_xyz.eq.'Ymol') then
!            YES_xyz='Xmol'
!         else if(YES_xyz.eq.'Xmol') then
!            YES_xyz='Ymol'
!         end if

![Q]........... exit

      ELSE IF(cha2(l0:).eq.'Q') THEN
         close(8)
         stop "I owe you nothing!"
      ELSE
         write(*,*) 'Wrong! Try again!'
      END IF
      go to 1
      end program tetr

!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine initiate(Where_From,seed0,l0seed0,Err)
      use real8
      use tetrag1
      implicit none
      character :: Where_From*6
      character(len=FLEN) :: seed0
      logical :: Err
!
      integer :: l0seed0

      Err=.false.
!
!_____________ read exisiting geometry file if entering for the first time
      relax_flag='T'
      Species='  '
      if(Where_From.eq.'CASTEP'.or.Where_From.eq.' CETEP' &
           .or. Where_From.eq.'  VASP' .or. Where_From.eq.'VASP52') then
         call get_N_of_Atoms(Where_From,seed0,l0seed0,Err)
         if(Err) go to 19
         call get_geometry(Where_From,seed0,l0seed0,Err)
         if(Err) go to 19
!_____________ask species
         if(Where_From.ne.'VASP52') then
            call ask_species(Nsp,Species,0,Err)
            if(Err) go to 19
         end if
      else if(Where_From.eq.'SIESTA') then
         call get_all_from_SIESTA(seed0,l0seed0,Err)
         if(Err) go to 19
         where_siesta='SIESTA'
      else if(Where_From.eq.'SIE-XV') then
         call get_all_from_SIESTAXV(seed0,l0seed0,Err)
         if(Err) go to 19
         Where_From='SIESTA'
         where_siesta='SIE-XV'
      else if(Where_From.eq.'   XYZ') then
         call read_xyz(seed0,l0seed0,Err)
         if(Err) go to 19
         Where_From='  None'
      else if(Where_From.eq.'QUICKS') then
         call get_all_from_QUICKSTEP(Seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'    QE') then
         call get_all_from_QE(seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'CRYSTL') then
         call get_all_from_CRYSTAL(seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'LAMMPS') then
         call get_all_from_LAMMPS(seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'    LM') then
!         call get_all_from_LM(seed0,l0seed0,Err)
         if(Err) go to 19

      end if

!_________ get atomic masses (in a.u.m.) for all species
      call get_masses()

!_________ calculate reciprocal lattice vectors in 2*PI units
      call INVER(AJ,BJ)
!
!_________ error
 19   if(Err) then
         write(*,*) '/---------------------------------------\\'
         write(*,*) '|  No file or Wrong format! Try again!  |'
         write(*,*)'\\---------------------------------------/'
      end if
      return
      end subroutine initiate

!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine compare()
!..................................................................
!   Compare the current geometry with that in another file
!..................................................................
      use real8
      use tetrag1
      use buffer
      implicit none
      character(len=FLEN) :: seed1
      character :: Which_Format*6,cha*2
      character :: fl*4,fl1*4
      real(8) :: r(3),fr(3)
      logical :: Err
!
      integer :: i,j,ii,isp,nat,l0seed1
      real(8) :: frac,rr,thresh

      thresh=0.1
!
!............. read geometry from another file and keep in /buffer/

!___________ temporarily keep the current geometry in /buffer/
      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)

!___________ choose the read format and then read in the geometry
 11   call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
      if(Which_Format.eq.'  None') return
      call initiate(Which_Format,seed1,l0seed1,Err)
      if(Err) go to 11
!
!___________ check consistency first
      if(ITI.ne.ITI1 .or. Nsp.ne.Nsp1) go to 100
      do isp=1,Nsp
         if(NspN(isp).ne.NspN1(isp)) go to 100
         if(Species(isp).ne.Species1(isp)) go to 100
      end do
      ii=0
      do i=1,3
         do j=1,3
            if(abs(AX(i,j)-AJ(i,j)).gt.tiny_equiv) ii=ii+1
         end do
      end do
      if(ii.ne.0) then
         write(*,*)'MIND: Direct lattice vectors are different!'
      end if
!
!............. open the output file
!  current geometry     - in /buffer/ as ITI1, TI1, etc.
!  newly read geometry  - as ITI,TI, etc.

      write(*,*) &
           'File compare_to.dat is being created ...'
!     &     'File comp_to_'//seed1(l0seed1:)//'.dat is being created ...'
!      open(14,file='comp_to_'//seed1(l0seed1:)//'.dat',status='unknown')
      open(14,file='compare_to.dat',status='unknown')
      write(14,'(a,i5)')'# Number os species Nsp = ',Nsp
      write(14,'(a)')'# Number of atoms in every species:'
      write(14,'(10(i3,a,a,a))') (NspN(i),'[',Species(i),'] ',i=1,Nsp)

      write(14,'(a)')' #  '
      write(14,'(a)')' #  Lattice vectors'
      write(14,'(a)')' #  ^^^^^^^^^^^^^^^'
      write(14,'(a/)') &
       ' #                Current(=1st)                       Second'
      write(*,'(a)')' #  '
      write(*,'(a)')' #  Lattice vectors'
      write(*,'(a)')' #  ^^^^^^^^^^^^^^^'
      write(*,'(a/)') &
       ' #                Current(=1st)                       Second'

!___________ while comparing, take away the complete translations and
!            mark with * displacements larger than thresh

      do i=1,3
         write(14,'(a,i1,a,3(f10.5,x),5x,3(f10.5,x))') &
              '[',i,'] ',(AX(i,j),j=1,3),(AJ(i,j),j=1,3)
         write(*,'(a,i1,a,3(f10.5,x),5x,3(f10.5,x))') &
              '[',i,'] ',(AX(i,j),j=1,3),(AJ(i,j),j=1,3)
      end do

      write(14,'(/a)')' #  '
      write(14,'(a)')' #  In Cartesian coordinates'
      write(14,'(a)')' #  ^^^^^^^^^^^^^^^^^^^^^^^^'
      write(14,'(a)') &
           ' #              Current (1st) position                  '// &
           ' Additional (2nd) position              Displ (2nd - 1st)'
      write(*,'(/a)')' #  '
      write(*,'(a)')' #  In Cartesian coordinates'
      write(*,'(a)')' #  ^^^^^^^^^^^^^^^^^^^^^^^^'
      write(*,'(a)') &
           ' #              Current (1st) position                  '// &
           ' Additional (2nd) position              Displ (2nd - 1st)'

      nat=0
      do isp=1,Nsp
         write(14,*)
         write(14,'(a12,i2,a20)') &
              '........ ',isp,' species '//Species(isp)//' ........'
         write(14,*)
         write(*,*)
         write(*,'(a12,i2,a20)') &
              '........ ',isp,' species '//Species(isp)//' ........'
         write(*,*)

!_______________ take out the direct lattice part when comparing;
!                note that TI,TI1 are given in Cartesian coordinates!

         do i=1,NspN(isp)
            nat=nat+1
            r(1:3)=TI1(1:3,nat)-TI(1:3,nat)
            do j=1,3
               frac=r(1)*BJ(j,1)+r(2)*BJ(j,2)+r(3)*BJ(j,3)
               frac=frac-int(frac)
               if(frac.gt.0.5) frac=frac-1.0
               if(frac.lt.-0.5) frac=frac+1.0
               fr(j)=frac
            end do
            r(1:3)=fr(1)*AJ(1,1:3)+fr(2)*AJ(2,1:3)+fr(3)*AJ(3,1:3)
            rr=sqrt(r(1)**2+r(2)**2+r(3)**2)
            if(rr.gt.thresh) then
               cha=' *'
            else
               cha='  '
            end if
            fl =' '//relax_flag(1,nat)//relax_flag(2,nat)// &
                                                     relax_flag(3,nat)
            fl1=' '//relax_flag1(1,nat)//relax_flag1(2,nat)// &
                                                    relax_flag1(3,nat)
            if(fl.ne.fl1) write(*,*) &
                 ' <... WARNING: relaxation flags are different ...>'
            write(14,'(i4,3(1x,f12.6),a,3(1x,f12.6),a,3(1x,f12.6),a)') &
              nat,(TI1(j,nat),j=1,3),fl1,(TI(j,nat),j=1,3),fl, &
                                                       (-r(j),j=1,3),cha
            write(*,'(i4,3(1x,f12.6),a,3(1x,f12.6),a,3(1x,f12.6),a)') &
              nat,(TI1(j,nat),j=1,3),fl1,(TI(j,nat),j=1,3),fl, &
                                                       (-r(j),j=1,3),cha
         end do
      end do
      close (14)
      go to 200

!....... errors in comparability
 100  write(*,*)'The files are NOT compatible. ABORTING ...'

!___________ restore the original geometry from /buffer/
 200  call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
           Genrt)
      write(*,*)'Press ENTER when done ...'
      read(*,*) ; write(8,'(a)') 'PressEnter'
      return
      end subroutine compare

!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine neb_interpolate()
!..................................................................
!   Intepolate betwen 2 geometries for a NEB calculation
!..................................................................
      use real8
      use tetrag1
      use buffer
      implicit none
      character(len=FLEN) :: seed1
      character :: Which_Format*6
      character :: ch2*2,cha1,cha2*2
      real(8) :: r(3),rii(3),tiny=0.0001,ss
      logical :: Err
!
      integer :: i,j,ii,isp,nat,l0seed1,images
!
!............. read geometry from another file and keep in /buffer/
!  current geometry     - as ITI1, TI1, etc.
!  newly read geometry  - as ITI,TI, etc.

      write(*,*)
      write(*,*)'******************************************************'
      write(*,*)'** CURRENT geometry is the INITIAL point of the BAND **'
      write(*,*)'******************************************************'
      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)

!___________ choose the read format and then read in the geometry into AJ, ITI, etc.
      
      write(*,*)
      write(*,*)'****************************************************'
      write(*,*)'**  READ geometry of the FINAL point of the BAND  **'
      write(*,*)'****************************************************'
11    call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
      if(Which_Format.eq.'  None') return
      call initiate(Which_Format,seed1,l0seed1,Err)
      if(Err) go to 11
!
!.............. check consistency first

      if(ITI.ne.ITI1 .or. Nsp.ne.Nsp1) then
         write(*,*) 'ITI=',ITI,', while ITI1=',ITI1
         write(*,*) 'Nsp=',Nsp,', while Nsp1=',Nsp1
         go to 100
      end if
      do isp=1,Nsp
         if(NspN(isp) .ne. NspN1(isp)) go to 100
         if(Species(isp) .ne. Species1(isp)) go to 100
      end do
      ii=0
      do i=1,3
         do j=1,3
            if(abs(AX(i,j)-AJ(i,j)).gt.tiny_equiv) ii=ii+1
         end do
      end do
      if(ii.ne.0) then
         write(*,*)'ERROR: ',ii, 'direct lattice vectors is/are different!'
         go to 100
      end if
      write(*,*)'GOOD! The two geometries ARE compatible! Proceeding ....'
      write(*,*)
!
!............. run the loop over all images. Ask for the number of images 
!  (excluding the initial and final images - the total number of images is then +2)
!
!  Note: the geometry of the images will be written into files geom_XX 
!        (where XX=00,01,02,...) in the format of VASP v. 5.

      write(*,*)'************************************************************'
1     write(*,*) '**  The total number of images allowed to relax (1 - 99) **'
      write(*,*) '**   (i.e. excluding the two end points):                **' 
      write(*,*)'************************************************************'
      read(*,*,err=1) images
      if(images.lt.1 .or. images.gt.98) go to 1

      
!___________ while creating images, take away the complete translations
 
      if(Nsp.lt.10) then
         write(cha1,'(i1)') Nsp
         cha2=' '//cha1
      else
         write(cha2,'(i2)') Nsp
      end if

      DO ii=0,images+1

         if(ii.lt.10) then
            write(ch2(2:2),'(i1)') ii ; ch2(1:1)='0'
         else if(ii.lt.100) then
            write(ch2(1:2),'(i2)') ii 
         end if
         open(17,file='POSCAR_'//ch2,status='unknown')
         write(17,*) '==================> Image number [ ',ii,' ] <=================='
         write(17,'(a)') '1.0'
         write(17,*) AJ(1,1), AJ(1,2), AJ(1,3)
         write(17,*) AJ(2,1), AJ(2,2), AJ(2,3)
         write(17,*) AJ(3,1), AJ(3,2), AJ(3,3)
         write(17,'('//cha2//'(a,x))') (Species(i),i=1,Nsp)
         write(17,*) (NspN(i),i=1,Nsp)
         write(17,'(a)')'Selective dynamics'
         write(17,'(a)')'Cartesian'

         nat=0
         do isp=1,Nsp
            write(*,'(a12,i2,a20)') '........ ',isp,' species '//Species(isp)//' ........'

!_______________ take out the direct lattice part when comparing;
!                note that TI,TI1 are given in Cartesian coordinates!

            do i=1,NspN(isp)
               nat=nat+1
               r(1:3)=TI(1:3,nat)-TI1(1:3,nat)
!               do j=1,3
!                  frac=r(1)*BJ(j,1)+r(2)*BJ(j,2)+r(3)*BJ(j,3)
!                  frac=frac-int(frac)
!                  if(frac.gt.0.5) frac=frac-1.0
!                  if(frac.lt.-0.5) frac=frac+1.0
!                  fr(j)=frac
!               end do
!               r(1:3)=fr(1)*AJ(1,1:3)+fr(2)*AJ(2,1:3)+fr(3)*AJ(3,1:3)

!_______________ position of atom nat for image ii
               
               rii(1:3)=TI1(1:3,nat)+r(1:3)*ii/(images+1)
               ss=(rii(1)-TI1(1,nat))**2+(rii(2)-TI1(2,nat))**2+(rii(3)-TI1(3,nat))**2
               if(sqrt(ss).gt.tiny) write(*,*) nat,Species(isp),i,rii
               
!_______________ save the atom in the geometry file
               write(17,'(3(f16.12,x),2x,3(a,x))') (rii(j),j=1,3),(relax_flag(j,nat),j=1,3)
               
            end do
            write(17,*)
         end do
         close (17)
         write(*,*)'==> Written geometry to POSCAR_'//ch2//' ...' 
         
      END DO
      go to 200

!....... errors in comparability
 100  write(*,*)'NEB_interpolate: The files are NOT compatible. ABORTING ...'

!___________ restore the original geometry from /buffer/
 200  call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
           Genrt)
      write(*,*)'Press ENTER when done ...'
      read(*,*) ; write(8,'(a)') 'PressEnter'
      return
    end subroutine neb_interpolate

!===============================================================================
      
      subroutine choose_dstn(K1,K2,i_Max,Method,iQuit)
!......................................................................
!      Choose two points K1 and K2 of interest and the maximal distance
! for images.
!.........................................................................
! Method='all_shortest ' - examination of ALL interatomic distances between
!                          ALL species (including images); only the shortest
!                          distance is chosen for each species; then, these
!                          distances are ordered in increasing order;
! Method='pair_limiting' - for the given pair all the images in the right
!                          order will be given (up to desired number i_Max)
!.........................................................................
! iQuit = 0 - not quit, proceed with the procedure;
!         1 - quit, i.e. skip the procedure in the parent program.
!......................................................................
      use real8
      use tetrag1
      implicit none
      logical :: numbers=.false.
      character :: Method*13
!
      integer :: K1,K2,iQuit,i_max,item

      Method='pair_limiting'
1     iQuit=0
      write(*,*)' '
      write(*,*)'..............MENU for exploring distances ...........'
      write(*,*)'......... Change these parameters if necessary: ......'
      write(*,*)
      write(*,*)'  0. Method for exploring distances: '//Method
      if(Method.ne.'all_shortest ') then
        if(.not.numbers) then
          iQuit=1
          write(*,'(a)') &
         '   1. Pair of atoms to be studied: ....... undefined .......'
        else
          write(*,'(a34,i3,a5,i3)') &
         '   1. Pair of atoms to be studied: ',K1,' and ',K2
        end if
      end if
      if(Method.eq.'pair_limiting') write(*,'(a39,i3)') &
                 '   2. Number of spheres of images to be shown: ',i_Max
      write(*,'(a)') &
               '   3. Calculate distances'
      write(*,'(a)')'   4. Quit: skip the step and do NOT proceed. '
      write(*,*)' '
      write(*,*)'------> Choose the item and press ENTER:'
      read(*,*,err=100) item ; write(8,*) item
!
!__________ choose the method
!
      if(item.eq.0) then
         if(Method.eq.'pair_limiting') then
            Method='all_shortest '
         else
            Method='pair_limiting'
         end if
!
!__________ choose two atoms
!
      else if(Method.eq.'pair_limiting' .and. item.eq.1) then
 10      write(*,*)'Specify atomic numbers K1 and K2:'
         read(*,*,err=10) K1,K2 ; write(8,*) K1,K2
         if(K1.lt.1.or.K2.lt.1) go to 10
         if(K1.gt.ITI.or.K2.gt.ITI) go to 10
         numbers=.true.
!
!__________  number of "spheres" of images
!
      else if(Method.eq.'pair_limiting' .and. item.eq.2) then
 11      write(*,*)'Give the number of spheres:'
         read(*,*,err=11) i_Max ; write(8,*) i_Max
         if(i_Max.le.0) go to 11
!
!__________ Quit or skip
!
      else if(item.eq.3) then
         if(iQuit.eq.0) return
         write(*,*)'ERROR! You still have undefined parameters!'
      else if(item.eq.4) then
         iQuit=1
         return
      else
         write(*,*)'ERROR! Try again!'
      end if
      go to 1
!
!............. error
 100  write(*,*)'Incorrect item number! Try again!'
      go to 1
      end subroutine choose_dstn

      subroutine distances()
!..................................................................
!    Calculates interatomic distances for all pairs of specified
! atoms including images from nearest 26 cells
!..................................................................
      use real8
      use tetrag1
      implicit none
      integer,parameter :: N0LT0=1000
!      integer,parameter :: N0LT0=N0LT*(1+N0LT)/2
      real(8) :: x(3),dist_short(N0LT0),distan(27)
      integer :: isort(N0LT0),i1_all(N0LT0),i2_all(N0LT0)
      character :: Method*13,line(27)*76
      integer,parameter :: i_Max=1
      real(8),parameter :: tiny=0.00001
!
      integer :: K1,K2,iT,is,i_all,iM,ii,jj,jjj,j,j1,i1,i2,i3,i,iQuit
      real(8) :: ar,d,short
!
!_______ open coord.dat
!
      OPEN(UNIT=77,FILE='distance.dat',form='formatted', &
                                        status='unknown',err=200)
      write(*,*)'The file distance.dat has been opened!'
!
!_____ menu
!
 10   call  choose_dstn(K1,K2,i_Max,Method,iQuit)
      if(iQuit.eq.1) then
        close (77)
        return
      end if
      write(77,*)'________ Method = ',Method,' _________'
      if(Method.eq.'pair_limiting') write(77,*)'K1=',K1,' and K2=',K2
!
!_____ scan all atoms in the cell
!
      i_all=0
      do 100 j=1,ITI
         jj=j ; jjj=ITI
         if(Method.eq.'pair_limiting' .and. K2.lt.K1) then
            jj=1 ; jjj=j
         end if
         if(Method.eq.'pair_limiting' .and. j.ne.K1) go to 100
         do 90 j1=jj,jjj
            if(Method.eq.'pair_limiting' .and. j1.ne.K2 ) go to 90
            i_all=i_all+1
            if(i_all.gt.N0LT0) then
               write(*,*) 'WARNING: exceeded the number of neighbours; stop here'
               go to 101
            end if
!
!_____ distances between j and j1 for all images
!
            short=100000.0
            i=0
            do i1=-1,1
               do i2=-1,1
                  do 3 i3=-1,1
                     if(j.eq.j1 .and. i1.eq.0 .and. i2.eq.0 &
                                              .and. i3.eq.0) go to 3
                     i=i+1
                     x(1)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+TI(1,j1)
                     x(2)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+TI(2,j1)
                     x(3)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+TI(3,j1)
                     ar=sqrt( (x(1)-TI(1,j))**2 + (x(2)-TI(2,j))**2 + &
                          (x(3)-TI(3,j))**2 )
                     if(ar.le.short) short=ar
                     write(line(i),1) 'ijk[',i1,',',i2,',',i3,']: {', &
                          TI(1,j),',',TI(2,j),',',TI(3,j),'} and {', &
                          x(1),',',x(2),',',x(3),'} => ',ar,' A'
                     distan(i)=ar
 3                continue
               end do
            end do
            dist_short(i_all)=short
            i1_all(i_all)=j
            i2_all(i_all)=j1
 90      continue
 100  continue
 1    format(a4,2(i2,a1),i2,a4,2(f6.3,a1),f6.3,a7, &
           2(f6.3,a1),f6.3,a5,f6.3,a2)
!
!_____ give the info due to the method chosen
!
101   if(Method.eq.'pair_limiting') then
!
!_____ pair-limiting case: all the distances in the right order for the
!      given pair (only i_Max spheres; it is monitored by iM)
!
         ii=26
         if(K1.ne.K2) ii=27
         call sort(distan,ii,isort)
         iM=1
         d=distan(isort(1))
         write(77,*)'_____ result _____'
         do i=1,ii
            if(abs(distan(isort(i))-d).gt.tiny) then
               iM=iM+1
               d=distan(isort(i))
            end if
            if(iM.le.i_Max) then
               write(*,'(a)') line(isort(i))
               write(77,'(a)') line(isort(i))
           end if
        end do
!
!_____ all-shortest case: we give all the shortest distances for all
!      pairs in the right order
!
      else
         iT=ITI*(ITI+1)/2
         call sort(dist_short,iT,isort)
         write(77,*)'_____ result _____'
         do i=1,iT
            is=isort(i)
            write(*,'(a6,i3,a5,i3,a4,f10.5)') &
         'atoms ',i1_all(is),' and ',i2_all(is),' => ',dist_short(is)
            write(77,'(a6,i3,a5,i3,a4,f10.5)') &
         'atoms ',i1_all(is),' and ',i2_all(is),' => ',dist_short(is)
         end do
      end if
      go to 10
!
!.... errors
200   write(*,*)'FATAL! Cannot open distance.dat file'
      return
      end subroutine distances

      subroutine problem(Which_Code,kpoint,nkp,YES_xyz)
      use real8
      use tetrag1
      implicit none
      character :: Which_Code*6,YES_xyz*4,cha2*2
      real(8) :: kpoint(Nkpoint,3)
!
      integer :: nkp,l0,i

!...................................................................
!............. Choose the problem: DOS or BAND structure ...........
!...................................................................
!
      kpmethod='  mp'
      z_supp =.false.
 2    write(*,*) &
           '/-------------------------------------------------\\'
      write(*,*) &
           '|................. K-point menu ..................|'
      write(*,*) &
          '\\-------------------------------------------------/'

      if(.not.z_supp) then
         write(*,*)'     0. BULK calculation'
         call INVER(AJ,BJ0)
      else
         write(*,*) &
         '     0. SLAB calculation: suppressed Z coord. in the k-space'
         call INVER2(AJ,BJ0)
      end if
      write(*,'(10x,a)')'NEW reciprocal lattice vectors (up to 2*PI):'
      write(*,'(10x,a,3(x,f10.5))') 'BJ0(1):   ',(BJ0(1,i),i=1,3)
      write(*,'(10x,a,3(x,f10.5))') 'BJ0(2):   ',(BJ0(2,i),i=1,3)
      write(*,'(10x,a,3(x,f10.5))') 'BJ0(3):   ',(BJ0(3,i),i=1,3)

      write(*,*)'     1. DOS '
      write(*,*)'     2. BAND: eigenvalues along a k-direction'
      write(*,*)'     3. Self-consistent (ordinary) calculation'
      if(nkp.ne.0) write(*,*)'     S. Save'
      write(*,*)'     Q. Return to the main menu'
      write(*,*)
      write(*,*)'Specify the character and press ENTER ------->'
      read(*,'(a)',err=2) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![0]........... slab/bulk

      IF(cha2(l0:).eq.'0') THEN

         if(z_supp) then
            z_supp=.false.
         else
            z_supp=.true.
         end if

![1]........... DOS

      ELSE IF(cha2(l0:).eq.'1') THEN

         write(*,*)'...............................................'
         write(*,*)'... I am going to prepare an input for DOS ....'
         write(*,*)'...............................................'
         call DOS_kp(Which_Code,kpoint,nkp)

![2]........... band

      ELSE IF(cha2(l0:).eq.'2') THEN

         write(*,*)'...............................................'
         write(*,*)'... I am going to prepare an input for BAND ...'
         write(*,*)'...............................................'
         call BAND_kp(Which_Code,kpoint,nkp)

![3]........... scf

      ELSE IF(cha2(l0:).eq.'3') THEN

         write(*,*)'...............................................'
         write(*,*)'... I am going to prepare an input for SCF ....'
         write(*,*)'...............................................'
         call Manh_Pack(Which_Code,kpoint,nkp)

![S]........... save

      ELSE IF(cha2(l0:).eq.'S' .and. nkp.ne.0) THEN

         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

![Q]........... leave menu

      ELSE IF(cha2(l0:).eq.'Q') THEN

         write(*,*)'... Buy.'
         return
      else
         write(*,*)'Incorrect item number! Try again!'
      end if
      go to 2
      end subroutine problem

      subroutine get_masses()
      use real8
      use mendeleev
      use tetrag1
      implicit none
      logical :: Err
!
      integer :: is,k

      do is=1,Nsp
         call check_Mendel(Species(is),k,Err,.true.)
         if(.not.Err) then
            AtMass(is)=At_Masses(k)
         else
            AtMass(is)=1000.0
         end if
         if(AtMass(is).eq.0.0) then
            write(*,*) &
        'ERROR! Atomic mass for '//Species(is)//' is NOT available!'
            write(*,*)'Press ENTER when ready ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
         end if
      end do
      return
      end subroutine get_masses

      subroutine initialise(nkp,read_c)
      use real8
      use tetrag1
      use siesta
      implicit none
      logical :: read_c
!
      integer :: is,k,nkp

      nkp=0
      nlines=0
      read_c=.false.
      do k=1,N0LT
         relax_flag(1,k)='T'
         relax_flag(2,k)='T'
         relax_flag(3,k)='T'
      end do
      do is=1,N0KD
         Species(is)='  '
      end do
      ITI=0
      return
      end subroutine initialise

      subroutine ask_species(Nsp,Species,UNIT,Err)
      implicit none
!     implicit none
!.......................................................................
! Two options:
!    UNIT=0     -> ask to enter from keyboard
!    otherwise  -> read all from a single Line from unit UNIT
!.......................................................................
      character :: Species(Nsp)*2,cha2*2,line*200
      integer :: LinEnd(100),LinPos(100),NumLin,UNIT
      logical :: Err,found
!
      integer :: Nsp,i,l0,i0,k,ii,iErr
!
 10   found=.false. ;  Err=.false.
      if(UNIT.ne.0) then
         call CutStr(Line,NumLin,LinPos,LinEnd,UNIT,0,iErr)
         if(NumLin.eq.Nsp .and.iErr.eq.0) found=.true.
      end if
!
      do i=1,Nsp

 1       write(*,'(a25,i3,a8)')'___> Atoms in species ',i,' <____'
         if(.not.found) then
            write(*,'(a,i5,a)') &
                 'Chemical element (character*2) of species ',i,' ?'
            read(*,'(a)') cha2 ; write(8,'(a)') cha2
            call right(cha2,2,l0)
            if(l0.eq.2) then
               Species(i)=' '//cha2(l0:)
            else
               Species(i)=cha2
            end if
         else
            i0=LinEnd(i)-LinPos(i)+1 ; if(i0.gt.2) go to 200
            if(i0.eq.1) then
               Species(i)=' '//line(LinPos(i):LinEnd(i))
            else if(i0.eq.2) then
               Species(i)=line(LinPos(i):LinEnd(i))
            end if
         end if

!___________ checking from NAZV
         call check_Mendel(Species(i),k,Err,.true.)
         if(Err) then
            if(UNIT.eq.0) then
               go to 1
            else
               go to 10
            end if
         end if

!___________ checking if = to that given previously
         if(i.gt.1) then
            do ii=1,i-1
               if(Species(i).eq.Species(ii)) then
                  write(*,'(2(a,i3),a)') &
            'ERROR! Species ',i,' and ',ii,' are the same. Try again!'
                  if(UNIT.ne.0) go to 200
                  go to 1
               end if
            end do
         end if

      end do
      return
!............ errors
 200  write(*,*) 'ERROR in reading species'
      Err=.true.
      end subroutine ask_species

      subroutine write_final_cp2k(YES_xyz)
!.............................................................................
! reads the CP2K output xyz file with the latest geometry (as geometries at
! all iterations are given in the file, only the latest is needed) and writes
! the final seed.inp file with the new geometry keeping all other stuff intack
!.............................................................................
      use real8
      use tetrag1
      implicit none
      integer :: LinEnd(100),LinPos(100),NumLin
      character(len=FLEN) :: seed1
      character :: cha2*2,spc*2,line*200
      real(8) :: kpoint(Nkpoint,3)
      character :: YES_xyz*4
!
      integer :: j,l0seed1,nn,j0,nat,isp,n,iErr,l0
!
!............ open the xyz file
!
 1    write(*,*)'Specify the output XYZ file from your QUICKSTEP run:'
      write(*,'(/a)')'**** XYZ files in the current directory: ***'
      call system('ls *.xyz ')
      write(*,'(a)') '************************************************'
      write(*,'(a)') '*** Full name to be given including extention **'
      write(*,'(a/)')'************************************************'
      read(*,'(a)') seed1  ; write(8,'(a)') seed1
      call right(seed1,FLEN,l0seed1)
      open(13,file=seed1(l0seed1:),status='old',err=10)
      read(13,*,err=8) nn
      if(nn.ne.ITI) then
         write(*,*) 'ERROR: wrong number of atoms'
         write(*,*) 'ERROR: *.XYZ is inconsistent with *.INP file'
         close (13) ; go to 1
      end if
!
!............. read the new geometry
!
!______________ find the number j of geometry blocks

      j=0
      do
         read(13,'(a)',err=8,end=2) line
         if(index(line,'i =').ne.0) then
            j=j+1 ; write(*,*) 'geometry found = ',j
         end if
      end do
 2    write(*,*)'... ',j,' geometries found ...'

!______________ read geometry from the last block

      rewind (13) ; j0=0
      do
         read(13,'(a)',err=8) line
         if(index(line,'i =').ne.0) j0=j0+1
         if(j.eq.j0) exit
      end do
      nat=0
      do isp=1,Nsp
         do n=1,NspN(isp)
            nat=nat+1
            call CutStr(Line,NumLin,LinPos,LinEnd,13,0,iErr)
            cha2=line(LinPos(1):LinEnd(1)) ; call right(cha2,2,l0)
            spc=cha2 ; if(l0.eq.2) spc=' '//cha2(l0:)
            if(spc.ne.Species(isp)) then
               write(*,*)'ERROR:  wrong order of species'
               write(*,*)'ERROR: *.XYZ is inconsistent with *.INP file'
               close (13) ; go to  1
            end if
            read(line(LinPos(2):),*,err=8,end=8) TI(1:3,nat)
         end do
      end do
      write(*,*)'... the geometry was read successfully! ...'
      close (13) ; go to 20
 8    write(*,*)'ERROR: cannot read atomic coordinates'
 10   write(*,*)'ERROR! File '//seed1(l0seed1:)//' is bad.'
      close(13)
      go to 1
!
!............... write the new file
!
 20   write(*,*)'... writing geometry and k-points ...'
      call write_kp(0,kpoint,'QUICKS',YES_xyz,.false.)
      write(*,*)'Done!'
      return
      end subroutine write_final_cp2k

      subroutine read_CP2K_xyz_last()
        use tetrag1
        implicit none
        integer :: k,ln,ir,iErr,ITI1,iA
        integer :: LinEnd(100),LinPos(100),NumLin
        character :: name*100,Line*200

!........ name of the CP2K output xyz file
        write(*,'(/a)') '**** XYZ files in the current directory: ***'
        call system('ls *.xyz')
        write(*,'(a)')'*************************************************************'
        write(*,'(a)') '***             Extension .xyz must NOT be given         ***'
        write(*,'(a)')'*************************************************************'
        write(*,'(a/)')'Give the name of the CP2K xyz file (WITHOUT the xyz extension!):'
        read(*,'(a)') name ; write(8,'(a)') name
        call right(name,100,ln)
        open(1,file=name(ln:)//'.xyz',status='old',err=10)
        open(2,file='coordinates.inc')
        ir=0
        do
           read(1,'(a)',end=1) line
           if(index(line,'i = ').ne.0) ir=ir+1
        end do
1       write(*,*) 'WARNING: ',ir,' relaxation steps found'

!......... read geometry from the last relaxation iteration        
        rewind (1)
        do k=1,ir
           read(1,*) ITI1
           if(ITI1.ne.ITI) go to 11
           read(1,*)
           do iA=1,ITI
              call CutStr(Line,NumLin,LinPos,LinEnd,1,0,iErr)
              if(k.eq.ir) write(2,'(a)') Line(LinPos(1):LinEnd(4))
           end do
        end do
        close(1) ; close(2)
        write(*,*)'Done!'
        return
!
10      close(1)
        write(*,*) 'ERROR: no file ['//name(ln:)//'.xyz] found'
        return
11      close(1)
        write(*,*) 'ERROR: file ['//name(ln:)//'.xyz] is BAD'
      end subroutine read_CP2K_xyz_last

      subroutine read_CP2K_xyz_any()
        use tetrag1
        implicit none
        integer :: k,ln,ir,iErr,ITI1,iA,ir1,l,l0,l1
        integer :: LinEnd(100),LinPos(100),NumLin
        character :: name*100,Line*200,cha*3,nxyz*100,cha2*2,name1*100
        logical :: Yes_name

!........ name of the CP2K output xyz file
        write(*,'(/a)') '**** XYZ files in the current directory: ***'
        call system('ls *.xyz')
        write(*,'(a)')'*************************************************************'
        write(*,'(a)') '***             Extension .xyz must NOT be given         ***'
        write(*,'(a)')'*************************************************************'
        write(*,'(a/)')'Give the name of the CP2K xyz file (WITHOUT the xyz extension!):'
        read(*,'(a)') name ; write(8,'(a)') name
        call right(name,100,ln)
        open(1,file=name(ln:)//'.xyz',status='old',err=10)
        ir=0
        do
           read(1,'(a)',end=1) line
           if(index(line,'i = ').ne.0) ir=ir+1
        end do
1       write(*,*) 'WARNING: ',ir,' relaxation steps found'
        rewind (1)

        if(ir.lt.10) then
           write(cha(1:1),'(i1)') ir ; l=1
        else if(ir.lt.100) then
           write(cha(1:2),'(i2)') ir ; l=2
        else if(ir.lt.1000) then
           write(cha(1:3),'(i3)') ir ; l=3
        else
           write(*,*)'WARNING: can only process iterations between 1 and 999'
           ir=999 ; cha(1:3)='999' ; l=3
        end if
        ln=6+l+4 ; nxyz(1:ln)='coord_'//cha(1:l)//'.xyz'
        
        Yes_name=.false. ; ir1=ir
        
21      write(*,*)'/---------------------------------------------------\\'
        write(*,*)'|......................  MENU .......................|'
        write(*,*)'\\---------------------------------------------------/'
        
!......... open the output xyz file        

        write(*,'(a,i5)') '  I. Relaxation iteration number: ',ir1
        write(*,'(a,a)')  '  N. Name of the output XYZ file: ',nxyz(1:ln)
        write(*,'(a,i5)') '  S. Save the XYZ file'
        write(*,'(a)')    '  Q. Quit.'
        write(*,*)
        write(*,*)'Specify the character and press ENTER ------->'
        read(*,'(a)',err=21) cha2  ; write(8,'(a)') cha2
        call right(cha2,2,l0)
        
![I].......... relaxation number

        IF(cha2(l0:).eq.'I') THEN

3          write(*,*)'Choose the relaxation step number between 1 and ',ir,':'
           read(*,*,err=3) ir1 ; write(8,*) ir1
           if(ir1.lt.1 .or. ir1.gt.ir .or. ir1.gt.999) go to 3
           if(ir1.lt.10) then
              write(cha(1:1),'(i1)') ir1 ; l=1
           else if(ir1.lt.100) then
              write(cha(1:2),'(i2)') ir1 ; l=2
           else if(ir1.lt.1000) then
              write(cha(1:3),'(i3)') ir1 ; l=3
           end if
           ln=6+l+4 ; nxyz(1:ln)='coord_'//cha(1:l)//'.xyz'

![N].......... XYZ file name

        ELSE IF(cha2(l0:).eq.'N') THEN

           write(*,*)'Give the name of the XYZ file (without .xyz extension):'
           read(*,'(a)') name1 ; write(8,'(a)') name1
           call right(name1,100,l1)
           ln=100-l1+1+4
           nxyz(1:ln)=name1(l1:)//'.xyz'
!           write(*,'(2i5,3a)') l1,ln,name,name(ln:),nxyz(1:l1)

![S].......... save the XYZ file

        ELSE IF(cha2(l0:).eq.'S') THEN

           open(2,file=nxyz(1:ln))
           write(2,'(i10/)') ITI
        
!_________________ read geometry from the relaxation iteration ir1

           do k=1,ir1
              read(1,*) ITI1
              if(ITI1.ne.ITI) go to 11
              read(1,*)
              do iA=1,ITI
                 call CutStr(Line,NumLin,LinPos,LinEnd,1,0,iErr)
                 if(k.eq.ir1) write(2,'(a)') Line(LinPos(1):LinEnd(4))
              end do
           end do
           close(2)
           rewind (1)
           write(*,*)'Done! The geometry was saved in [ '//nxyz(1:ln)//' ]'

![Q]...... quit

        ELSE IF(cha2(l0:).eq.'Q') THEN
           close(1) 
           return
        ELSE
           write(*,*) 'Wrong! Try again!'
        END IF
        go to 21
        
!..................... errors ..................
        
10      close(1)
        write(*,*) 'ERROR: no file ['//name(ln:)//'] found'
        return
11      close(1) ; close(2)
        write(*,*) 'ERROR: file ['//name(ln:)//'] is BAD'
      end subroutine read_CP2K_xyz_any
      
