      subroutine quadr(Y,X,N,a,b,c,err)
!.............................................................
! Perform quadratical interpolation Y=a+b*X+c*X*X for the grid
! of points Y(i), X(i), i=1,...,N
!.....Output:
!            a,b,c - coefficients
!            err - relative error of the interpolation
!.............................................................
      use real8
      implicit none
      real(8) :: Y(N),X(N)
!
      integer :: N,i
      real(8) :: a,b,c,err,x1,x2,x3,x4,y1,yx1,yx2,det,detc
!
!......... Compute the moments of the data points:
      x1=0.0 ; x2=0.0 ; x3=0.0 ; x4=0.0 ; y1=0.0 ; yx1=0.0 ; yx2=0.0
      do i=1,N
         x1=x1+X(i) ; x2=x2+X(i)*X(i)
         x3=x3+X(i)*X(i)*X(i) ; x4=x4+X(i)*X(i)*X(i)*X(i)
         y1=y1+Y(i) ; yx1=yx1+Y(i)*X(i)
         yx2=yx2+Y(i)*X(i)*X(i)
      end do
      x1=x1/N ; x2=x2/N ; x3=x3/N ; x4=x4/N
      y1=y1/N ; yx1=yx1/N ; yx2=yx2/N
!
!.......... compute the linear coefficients a,b,c
      det=(x2*x1-x3)**2-(x1*x1-x2)*(x2*x2-x4)
      detc=(y1*x1-yx1)*(x2*x1-x3)-(y1*x2-yx2)*(x1*x1-x2)
      c=detc/det
      b=( (y1*x1-yx1)-c*(x2*x1-x3) )/(x1*x1-x2)
      a=y1-b*x1-c*x2
!
!.......... compute the error of the interpolation
      err=0.0
      do i=1,N
         write(6,'(i3,3(1x,d21.14))') i,X(i),Y(i),a+b*X(i)+c*X(i)*X(i)
         err=err+(Y(i)-(a+b*X(i)+c*X(i)*X(i)))**2
      end do
      err=err/N
      end subroutine quadr

      logical function compare_2_real(a,b,unit)
!.................................................................
!  compare two real numbers a,b
!  unit - unit number for printing the warning (if more than
!         5% difference)
!.................................................................
      use real8
      implicit none
      integer :: unit
      real(8),parameter :: tiny=0.001d0
!
      real(8) :: a,b,diff

      compare_2_real=.true.

      if(abs(a).lt.tiny .and. abs(b).lt.tiny) then
!         write(unit,*) 'both are close to zero => ok!'
      else if(abs(a).lt.tiny) then
         diff=abs(a/b)*100
         if(diff.gt.5.0) then
            write(unit,'(a,e12.6,a,f10.2,a,e12.6)') &
                 'WARNING: ',a,'  is ',diff,' % of ',b
            compare_2_real=.false.
         end if
      else if(abs(b).lt.tiny) then
         diff=abs(b/a)*100
         if(diff.gt.5.0) then
            write(unit,'(a,e12.6,a,f10.2,a,e12.6)') &
                 'WARNING: ',b,'  is ',diff,' % of ',a
            compare_2_real=.false.
         end if
      else
         diff=abs((a-b)/b)*100
         if(diff.gt.5.0) then
            write(unit,'(2(a,e12.6),a,f10.2,a)') &
          'WARNING: ',a,' is different from ',b,' by ',diff,' %'
            compare_2_real=.false.
         end if
      end if
      end function compare_2_real

      subroutine diag(F,A,E,F1,Nm,N)
      use real8
      implicit none
!....... diagonalization of a square matrix F
      real(8) :: F(Nm,Nm),A(Nm),E(Nm),F1(Nm,Nm)
!
      integer :: N,Nm,i,j
      real(8) :: epsH

!.......................................................................
!................... I N P U T   F O R   H O U L D:.....................
!  F  - initial square matrix (N*N) which must be diagonalized;
!       only left thriangular part of it must actually be filled.
!  E  - 1-dim. vector of eigenvalues
!  One temporary 1-dim. vector AU of the dimension N
!  Nm - total dimension of the square F matrix
!  N  - actual (active) dimension of the square F matrix
!  epsH - precision
!................... O U T P U T  F R O M  H O U L D:..................
!  F1 -  eigenvectors will be allocated by columns
!.......................................................................
!
      do i=1,N
         do j=1,N
            F1(i,j)=F(i,j)
         end do
      end do
!....... call diagonalisation of the Symmetrical matrix F1
      epsH=1.0E-7
      CALL HOULD (E,F1,N,Nm,epsH,A)
!
!........... Write eigenvalues and eigenvectors
!      write (*,'(a,10(x,f10.5))') 'Eigenvalues => ',(E(i),I=1,N)
!      do j=1,N
!        write(*,*) (F1(j,i),i=1,N)
!      end do
      return
      end subroutine diag

      subroutine HOULD (D,Z,N,Nm,EPS,E)
      use real8
      implicit none
      real(8) :: D(Nm),E(Nm),Z(Nm,Nm)
!
      integer :: IN,N,Nm,i,l,k,j,k1,m,im,im1
      real(8) :: eps,g,h,f,p,b,em,ei,r,di,c,s

      DO 110 IN=2,N
         I=N+2-IN
         L=I-2
         F=Z(I,I-1)
         G=0.d0
         IF(L.LT.1) GO TO 20
         DO 10 K=1,L
10       G=G+Z(I,K)**2
20       H=F*F+G
         IF(G.GE.1.E-14) GO TO 30
         E(I)=F
         H=0.d0
         GO TO 100
30       L=L+1
         G= SQRT(H)
         IF(F.LT.0) GO TO 40
         G=-G
40       E(I)=G
         H=H-F*G
         Z(I,I-1)=F-G
         F=0.d0
         DO 70 J=1,L
            Z(J,I)=Z(I,J)/H
            G=0.
            DO 50 K=1,J
50          G=G+Z(J,K)*Z(I,K)
            K1=J+1
            IF(K1.GT.L) GO TO 65
            DO 60 K=K1,L
60          G=G+Z(K,J)*Z(I,K)
65          E(J)=G/H
            F=F+G*Z(J,I)
70      CONTINUE
        P=F/(H+H)
        DO 90 J=1,L
           F=Z(I,J)
           G=E(J)-P*F
           E(J)=G
           DO 80 K=1,J
   80      Z(J,K)=Z(J,K)-F*E(K)-G*Z(I,K)
   90   CONTINUE
  100   D(I)=H
  110 CONTINUE
!     TRIDIAGONALIZACIJAS BEIGAS
      D(1)=0.d0
      E(1)=0.d0
      DO 160 I=1,N
      L=I-1
      DI=D(I)
      IF(DI.EQ.0.) GO TO 145
      DO 140 J=1,L
      G=0.d0
      DO 120 K=1,L
 120  G=G+Z(I,K)*Z(K,J)
      DO 130 K=1,L
 130  Z(K,J)=Z(K,J)-G*Z(K,I)
 140  CONTINUE
 145  D(I)=Z(I,I)
       Z(I,I)=1.
      IF(L.LT.1) GO TO 155
      DO 150 J=1,L
      Z(I,J)=0.d0
  150 Z(J,I)=0.d0
  155 CONTINUE
  160 CONTINUE
!     SAFORMETA P MATRICA
      DO 170 I=2,N
  170 E(I-1)=E(I)
      E(N)=0.d0
      B=0.d0
      F=0.d0
      DO 330 L=1,N
      J=0
      H=( ABS(D(L))+ ABS(E(L)))*EPS
      IF(B.LT.H) B=H
      DO 180 M=L,N
      EM= ABS(E(M))
      IF(EM.LE.B) GO TO 190
  180 CONTINUE
  190 IF(M.EQ.L) GO TO 320
  200 IF(J.NE.30) GO TO 220
      GO TO 450
  220 J=J+1
      EM=E(L)
      P=(D(L+1)-D(L))/(EM+EM)
      R= SQRT(P*P+1.)
      IF(P) 230,240,240
  230 EM=P-R
      GO TO 250
  240 EM=P+R
  250 H=D(L)-E(L)/EM
      DO 260 I=L,N
  260 D(I)=D(I)-H
      F=F+H
      P=D(M)
      C=1.d0
      S=0.d0
      IM1=M-1
      IF(IM1.LT.L) GO TO 315
      DO 310 IM=L,IM1
      I=IM1+L-IM
      EI=E(I)
      G=C*EI
      H=C*P
      IF( ABS(P)- ABS(EI)) 280,270,270
  270 C=EI/P
      R= SQRT(C*C+1.)
      E(I+1)=S*P*R
      S=C/R
      C=1.d0/R
      GO TO 290
  280 C=P/EI
      R= SQRT(C*C+1.)
      E(I+1)=S*EI*R
      S=1.d0/R
      C=C/R
  290 DI=D(I)
      P=C*DI-S*G
      DI=C*G+S*DI
      D(I+1)=H+S*DI
      DO 300 K=1,N
      H=Z(K,I+1)
      EI=Z(K,I)
      Z(K,I+1)=S*EI+C*H
      Z(K,I)=C*EI-S*H
  300 CONTINUE
  310 CONTINUE
  315 CONTINUE
      E(L)=S*P
      D(L)=C*P
      EI= ABS(E(L))
      IF(EI.GT.B) GO TO 200
  320 D(L)=D(L)+F
  330 CONTINUE
!     D-IPASVERTIBAS,Z-IPASVEKTORI
      I=0
  340 I=I+1
      IF(I.GE.N) GO TO 360
      H=D(I)
      F=D(I+1)
      IF(H.LE.F) GO TO 340
      D(I)=F
      D(I+1)=H
      DO 350 K=1,N
      H=Z(K,I)
      Z(K,I)=Z(K,I+1)
      Z(K,I+1)=H
  350 CONTINUE
      IF(I.NE.1) I=I-2
      GO TO 340
  360 CONTINUE
  450 CONTINUE
      RETURN
      end subroutine HOULD

      subroutine INVER(AI,BI)
!...............................................................
!....... build reciprocal basic vectors BI(number,component) (in
! units of 2*PI) from the direct ones, AI(number,component)
!...............................................................
      use real8
      implicit none
      real(8) :: one=1.0d0
      reaL(8),PARAMETER :: tiny=0.0001
      real(8) :: AI(3,3), BI(3,3)
!
      real(8) :: DET

      DET= AI(1,1)*(AI(2,2)*AI(3,3)-AI(2,3)*AI(3,2)) &
          -AI(2,1)*(AI(1,2)*AI(3,3)-AI(1,3)*AI(3,2)) &
          +AI(3,1)*(AI(1,2)*AI(2,3)-AI(1,3)*AI(2,2))
      if(abs(DET).lt.tiny) then
         write(*,*)'ERROR! The box volume is too small! Stop!'
         stop
      end if
      DET=one/DET
      BI(1,1)= (AI(2,2)*AI(3,3)-AI(2,3)*AI(3,2))*DET
      BI(1,2)=-(AI(2,1)*AI(3,3)-AI(2,3)*AI(3,1))*DET
      BI(1,3)= (AI(2,1)*AI(3,2)-AI(2,2)*AI(3,1))*DET
      BI(2,1)=-(AI(1,2)*AI(3,3)-AI(1,3)*AI(3,2))*DET
      BI(2,2)= (AI(1,1)*AI(3,3)-AI(1,3)*AI(3,1))*DET
      BI(2,3)=-(AI(1,1)*AI(3,2)-AI(1,2)*AI(3,1))*DET
      BI(3,1)= (AI(1,2)*AI(2,3)-AI(2,2)*AI(1,3))*DET
      BI(3,2)=-(AI(1,1)*AI(2,3)-AI(1,3)*AI(2,1))*DET
      BI(3,3)= (AI(1,1)*AI(2,2)-AI(1,2)*AI(2,1))*DET
      RETURN
      end subroutine INVER

      subroutine INVER2(AI,BI)
!...............................................................
!....... build reciprocal basic vectors BI(number,component) (in
! units of 2*PI) from the direct ones, AI(number,component) for
! the 2-dimensional case (3-component is suppressed)
!...............................................................
      use real8
      implicit none
      real(8) :: one=1.0d0,zero=0.0d0
      reaL(8),PARAMETER :: tiny=0.0001d0
      real(8) :: AI(3,3), BI(3,3)
!
      real(8) :: DET,a1_2,a2_2,a1_a2

      a1_2=AI(1,1)**2+AI(1,2)**2+AI(1,3)**2
      a2_2=AI(2,1)**2+AI(2,2)**2+AI(2,3)**2
      a1_a2=AI(1,1)*AI(2,1)+AI(1,2)*AI(2,2)+AI(1,3)*AI(2,3)
      DET= a1_2 * a2_2  -  a1_a2*a1_a2
      if(abs(DET).lt.tiny) then
         write(*,*)'ERROR! The box 2D-volume is too small! Stop!'
         stop
      end if
      DET=one/DET
      BI(1,1)=( a2_2*AI(1,1) - a1_a2*AI(2,1) )*DET
      BI(1,2)=( a2_2*AI(1,2) - a1_a2*AI(2,2) )*DET
      BI(1,3)=( a2_2*AI(1,3) - a1_a2*AI(2,3) )*DET
      BI(2,1)=( a1_2*AI(2,1) - a1_a2*AI(1,1) )*DET
      BI(2,2)=( a1_2*AI(2,2) - a1_a2*AI(1,2) )*DET
      BI(2,3)=( a1_2*AI(2,3) - a1_a2*AI(1,3) )*DET
      BI(3,1)=zero
      BI(3,2)=zero
      BI(3,3)=zero
      return
      end subroutine INVER2

      real(8) function scalar(C1,C2,Ndim)
      use real8
      implicit none
      real(8) :: C1(Ndim),C2(Ndim)
!
      integer :: i,Ndim
      real(8) :: s

      s=0.0
      do i=1,Ndim
         s=s+C1(i)*C2(i)
      end do
      scalar=s
      return
      end function

      subroutine check_orth(C,Nm,N,Ndim,Ndim0)
      use real8
      implicit none
      real(8) :: C(Ndim0,Nm)
      real(8),parameter :: tiny=0.000001d0
      logical :: ok
!
      integer :: Ndim,Ndim0,N,Nm,i,j
      real(8) :: s,scalar

      ok=.true.
      do i=1,N
         do j=1,N
            s= scalar(C(1,i),C(1,j),Ndim)
            if(i.eq.j .and. abs(s-1.0d0).gt.tiny) ok=.false.
            if(i.ne.j .and. abs(s).gt.tiny) ok=.false.
            if(.not.ok) write(9,*) i,j,s
         end do
      end do
      if(.not.ok) then
         stop 'BAD check orthogonalisation'
      else
         write(9,*)'GOOD! orthogomalisation is Fine!'
      end if
      return
      end subroutine check_orth

      subroutine Plot(ng,file,len,title,title_pl,x1,x2, &
                                 xaxis,yaxis,where,l3,Up_lim)
!......................................................................
!   Plot curves eighter on the screen or on to a ps-file
!......................................................................
! title - the title of the plot (char*50)
! xaxis - the title of the x-axis (char*20)
! yaxis - the title of the y-axis (char*20)
! where - where to print: on the 'Screen' or on the 'Postsc' (char*6)
!......................................................................
!  x1 - left boundary of the x-interval
!  x2 - left boundary of the x-interval
!......................................................................
! ng - number of curves to be plotted simultraneously; they
!      correspond to columns 2,3,... in the data file;
! file - name of the data file for the GNUPLOT
! len - lenght of the data files name
! title_pl(i) - subtitle for each curve, i=1,...,ng
!......................................................................
! test.gnu - standart name of the file  used by the GNUPLOT;
! file.ps  - name of the postscript file prepared by GNUPLOT.
! l3 - reserved UNIT for the files used here.
!......................................................................
      use real8
      implicit none
      character :: title*50,xaxis*20,yaxis*20,where*6
      character :: file*12,title_pl(ng)*9,cha
!
      integer :: ng,len,l3,i
      real(8) :: x1,x2,Up_lim

!.......... common part for both regimes ............................
      call system('rm test.gnu')
      open (l3, file='test.gnu', status='new')
      write (l3,300) xaxis,yaxis
300   format ('#set data style lines'/ &
              'set format y "%.4f"'/ &
              'set key'/ &
              'set xlabel "',a,'" '/ &
              'set ylabel "',a,'" ')
      write (l3,305) title
305   format ('set title "', a, '" ')
      if(Up_lim.ne.0.0) then
        write(l3,306) Up_lim
 306    format('set yrange [0:',f10.5,']')
      end if
      write(l3,'(2(a,f10.5),a)') 'set xrange [',x1,':',x2,']'
!.......... distinct part ...........................................
      if(where.eq.'Screen') then
         write (l3,*) 'set terminal x11'
         write (l3,401)
 401     format ('#set terminal post  "Times-Roman" 14')
         write(l3,'(a)')'#set output "'//file(1:len)//'.ps"'
      else
         write (l3,301)
 301     format ('set terminal post  "Times-Roman" 14')
         write(l3,'(a)')'set output "'//file(1:len)//'.ps"'
      end if
!.......... common part: .........................................
!_____ plot commands
      if(ng.eq.1) then
         write (l3,*)  'plot "'//file(1:len)// &
              '" u 1:2 t "'//title_pl(1)//'" w l'//char(92)
      else
         write (l3,*)  'plot "'//file(1:len)// &
              '" u 1:2 t "'//title_pl(1)//'" w l'//char(92)
         do i=2,ng
            write(cha,'(i1)') i+1
            write (l3,*)', "'//file(1:len)//'" u 1:'// &
                 cha//' t "'//title_pl(i)//'" w l'//char(92)
         end do
      end if
 10   write(l3,*)' '
      if(where.eq.'Screen') write (l3,*)'pause -1'
      close (l3)
      call system ('gnuplot test.gnu')
!.......... Check postscript file if it was specified ................
      if(where.ne.'Screen') &
          write(6,*)'The postscript file '// &
                      file(1:len)//'.ps" has been created!'
      return
      end subroutine Plot

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine do_sets_from_list(list_at,ITI,n,set_beg,set_end,SETS)
      implicit none
!...............................................................................
! Creates sets of continuous numbers out of the true/false list list_at()
!...............................................................................
! INPUT: a logical list of atoms contained in list_at of length ITI (# of atoms)
!...............................................................................
! OUTPUT: n          - number of coninuous atomic numbers (up to 100 allowed)
!         set_beg(i) - first number of the list i
!         set_end(i) - last number of the list i
!...............................................................................
!     implicit none
      logical :: list_at(*)
      integer :: SETS,set_beg(SETS),set_end(SETS)
!
      integer :: ITI,n,i,i_prev

!_____________ find continuous sets of numbers
      n=0
      i_prev=-1
      do i=1,ITI
         if(list_at(i)) then

            if(i.eq.i_prev+1) then
               set_end(n)=i
               i_prev=i
            else
               n=n+1
               if(n.gt.SETS) then
                  write(*,*) 'FATAL! Number of sets > ',SETS,' !'
                  stop 'in do_sets_from_list; check [real8.inc] file'
               end if
               set_beg(n)=i
               set_end(n)=i
               i_prev=i
            end if

         end if
      end do
!      write(*,*) 'sets found = ',n
!      do i=1,n
!         write(*,*) i,set_beg(i),'-',set_end(i)
!      end do
      return
      end subroutine do_sets_from_list

      subroutine do_nice_list(list_at,ITI,list,len,N_lists,long_list)
!........................................................................
! create a nice list (of length len) out of a logical list of atoms
! contained in list_at
!........................................................................
! N_lists - the maximum allowed length of the character list (it is only
!           used for printing in the routine calling this one)
!.......................................................................
      use real8
      implicit none
      character(*) :: list
      character :: cha1*10,cha2*10
      logical :: list_at(*),long_list
      integer :: set_beg(SETS),set_end(SETS)
!
      integer :: ITI,n,N_lists,len,i1,i2,i,len1,len2

!_____________ find continuous sets of numbers

      call do_sets_from_list(list_at,ITI,n,set_beg,set_end,SETS)

!_____________ compile the nice list
      if(n.eq.0) then
         len=1 ; list(1:1)=' '
      else
         i1=0
         do i=1,n
            call number_to_char(set_beg(i),cha1,len1)
            if(set_end(i).eq.set_beg(i)) then
               i2=i1+len1
            else
               call number_to_char(set_end(i),cha2,len2)
               i2=i1+len1+len2+1
            end if
            if(i2.gt.N_Lists) then
               len=i1-1 ; long_list=.true. ; return
            else
               if(set_end(i).eq.set_beg(i)) then
                  list(i1+1:i2)=cha1(1:len1)
               else
                  list(i1+1:i2)=cha1(1:len1)//'-'//cha2(1:len2)
               end if
               i1=i2+1 ; list(i1:i1)=','
            end if
         end do
         len=i2
      end if
      long_list=.false.
      end subroutine do_nice_list

      subroutine number_to_char(num,cha,len)
      implicit none
!     implicit none
      character :: cha*10
!
      integer :: i,num,len,l

      write(cha,'(i10)') num
      do i=1,10
         if(cha(i:i).ne.' ') then
            l=i ; go to 10
         end if
      end do
      len=10
      return
 10   len=11-l
      do i=l,10
         cha(i-l+1:i-l+1)=cha(i:i) ; cha(i:i)=' '
      end do
      end subroutine number_to_char

      subroutine print_long_char(list,len,long_list)
      implicit none
!....................................................................
!     Prints nicely a list (of length len) indicating if it has been
!     cut by portions of 100 characters
!....................................................................
!     implicit none
      character(*) :: list
      logical :: long_list
!
      integer :: i,len,i2

      do i=1,len,100
         i2=min(i+99,len)
         if(i2.eq.len .and. long_list) then
            write(*,'(a)') list(i:i2)//' ... (cut)'
         else
            write(*,'(a)') list(i:i2)
         end if
      end do
      return
      end subroutine print_long_char

      subroutine write_list1(listat,ITI)
      implicit none
!....................................................................
!     Prints a list of atomic numbers for which listat(n)=..true.
!      -> into a file for CHIMERA
!....................................................................
!     implicit none
      logical :: listat(*)
      integer,dimension(:),allocatable :: list
!
      integer :: i,ITI,nat,j,im,k

      allocate(list(ITI))
      i=0
      do nat=1,ITI
         if(listat(nat)) then
            i=i+1 ; list(i)=nat
         end if
      end do
      open(35,file='tetr.slc',form='formatted',status='unknown')
      do j=1,i,10
         im=j+9 ; if(im.gt.i) im=i
         write(35,*) (list(k),k=j,im)
      end do
      close(35)
      deallocate(list)
      end subroutine write_list1

      subroutine write_list(listat)
      use real8
      use tetrag1
      use bb
      implicit none
!....................................................................
!     Prints a list of atomic numbers for which listat(n)=..true.
!      -> into a file for CHIMERA
!....................................................................
      logical :: listat(*),ask_checked
      integer,dimension(:),allocatable :: list
!
      integer :: i,nat,j,k,L_ext,i1,i2,i3,jj,im

      L_ext=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)*ITI
      allocate(list(L_ext))

      jj=0 ; nat=0 
      DO i=1,Nsp
         do i1=M11,N11
            do i2=M22,N22
               do i3=M33,N33

                  DO k=1,NspN(i)
                     nat=nat+1
                     if(ask_checked(i,k,listat)) then
                        jj=jj+1 ; list(jj)=nat
                     end if
                  END DO

               end do
            end do
         end do
      END DO
      
      open(35,file='tetr.slc',form='formatted',status='unknown')
      do j=1,jj,10
         im=j+9 ; if(im.gt.jj) im=jj
         write(35,*) (list(k),k=j,im)
      end do
      close(35)
      deallocate(list)
      end subroutine write_list

      logical function ask_checked(i1,k1,listat)
      use real8
      use tetrag1
!.....................................................................        
! it gives TRUE if atom of species 'i1' and species number 'k1' was
! selected in listat()
!.....................................................................        
      implicit none
      integer nat,i,k,k1,i1
      logical :: listat(*)
      
      nat=0
      DO i=1,Nsp
         do k=1,NspN(i)
            nat=nat+1
            if(i.eq.i1 .and. k.eq.k1) then
               ask_checked=listat(nat) ; return
            end if
         end do
      END DO
      end function ask_checked
      
      subroutine vect_prod(x,y,z,norm,err)
      implicit none
!.....................................................................
! a vector product (x) x (y) = z is calculated
! if norm=.true., vector z is normalised to 1.
!.....................................................................
!     implicit none
      real(8) :: x(3),y(3),z(3),s
      real(8),parameter :: tiny=0.0001d0
      logical :: err,norm
!
      z(1)=x(2)*y(3)-x(3)*y(2)
      z(2)=x(3)*y(1)-x(1)*y(3)
      z(3)=x(1)*y(2)-x(2)*y(1)
      s=z(1)*z(1)+z(2)*z(2)+z(3)*z(3)
      if(s.lt.tiny) then
         err=.true. ; return
      else
         err=.false.
         if(norm) then
            s=sqrt(s) ; z=z/s
         end if
      end if
      end subroutine vect_prod

      subroutine gen_rot_mtrx(w,C,angle)
!.....................................................................
! Rotational matrix C() is worked out from the direction w() of the
! axis and the angle
!.....................................................................
!  w() - rotational axis
!  angle - rotational angle (in degrees, either in or out)
!.....................................................................
      use real8
      implicit none
      real(8) C(3,3),w(3),cs,sn
!
      real(8) angle

      cs=cos(angle) ; sn=sin(angle)
      C(1,1)=cs+(1.0-cs)*w(1)*w(1)
      C(1,2)=w(1)*w(2)*(1-cs)-w(3)*sn
      C(1,3)=w(1)*w(3)*(1-cs)+w(2)*sn
      C(2,1)=w(2)*w(1)*(1-cs)+w(3)*sn
      C(2,2)=cs+(1.0-cs)*w(2)*w(2)
      C(2,3)=w(2)*w(3)*(1-cs)-w(1)*sn
      C(3,1)=w(3)*w(1)*(1-cs)-w(2)*sn
      C(3,2)=w(3)*w(2)*(1-cs)+w(1)*sn
      C(3,3)=cs+(1.0-cs)*w(3)*w(3)
      end subroutine gen_rot_mtrx







