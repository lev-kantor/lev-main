module tetr_param
implicit none
!........................................................................
!............ Parameter statements ......................................
!........................................................................
!..... 1st parameter in this routine: maximal number of k-points:
!
        integer,parameter :: Nkpoint=200
!
!..... 2nd: maximal UC->LUC extention; maximal number of sublattices
! N0KD  - max. # of atomic species
        integer,parameter :: MG00 = 125, N0LT =5000, N0KD = 10

!...... for the cluster: max number of neighbours
        integer,parameter :: neighb0 = 30
end module tetr_param
