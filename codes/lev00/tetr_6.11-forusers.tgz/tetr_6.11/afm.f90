module afm
implicit none
!.......... number of vertical tip displacements
        integer,parameter :: Ndispl0=100


end module afm
