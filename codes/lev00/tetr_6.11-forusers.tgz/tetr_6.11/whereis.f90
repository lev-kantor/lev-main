module whereis
implicit none
!........... tetr directory
!  tetr_dir(tetr_l0:) - tetr directory
!      common /where_is/ tetr_dir,tetr_l0
       character :: tetr_dir*200
       integer :: tetr_l0
end module whereis
