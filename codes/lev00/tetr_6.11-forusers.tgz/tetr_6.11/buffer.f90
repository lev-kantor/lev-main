module buffer
use tetr_param
implicit none
!     common /buffer/ AX,TI1,BX, &
!                     ITI1,NspN1,Nsp1, &
!                     Genrt1,Species1,relax_flag1

      character :: Species1(N0KD)*2,relax_flag1(3,N0LT)
      real(8) :: AX(3,3),TI1(3,N0LT),BX(3,3)
      integer ::  ITI1,NspN1(N0KD),Nsp1
      logical :: Genrt1(N0LT)
end module buffer
