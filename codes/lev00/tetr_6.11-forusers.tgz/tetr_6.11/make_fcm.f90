      subroutine make_fcm(Which_Code)
!...............................................................
! The force constant matrix is constructed out of all components
! due to every irrep. Then atomic masses can be changed and the
! new frequencies obtained (e.g. isotopic shifts).
!
!    Similarly, one can estimate the vibrational frequencies if
! chemically similar species are used, e.g. Ge instead of Si, so
! that the same FCM is used with different masses.
!...............................................................
      use real8
      use tetrag1
      use pgroup
      use working
      use symgenv
      use matrix
      use systema
      use atom_info
      use mlists
      use buffer0
      use bb
      implicit none
      character (LEN=200) :: Line
      integer :: LinEnd(100),LinPos(100),NumLin
      integer :: IRA_left(N0IR)
      logical :: Err,Yes_solved,Yes_fixed,Diff_Order_of_Atoms
      logical :: mchange(N0LT),yes_chosen,proj_at(N0LT)
      logical :: ChargeS,listat(N0LT),Changed_Mass,IR_normalise
      character :: cha2*2,cha1,name*50
      character :: title_pl(9)*9,Title*50,cha5*5,cha4*4
      real(8),dimension(:),allocatable :: Freq,Freq_ru,Freq_ll
      real(8) :: Atom_Mass(N0LT),RR(MG0,3),RA(3)
      real(8) :: Q(3,3,N0LT),chrg(3,3)
      integer :: Num_proj_atom(8),j_proj_atom(8)
      real(8) :: I_of_w
      real(8),dimension(:),allocatable :: Pref
      character :: cch*72,Which_Code*6
!
      real(8),parameter :: K_B=8.617343e-5      ! in eV/K
      real(8),parameter :: H_bar=4.13566733e-15 ! in eV*sec
      real(8),parameter :: tiny=0.00001
      logical :: Add_Hs=.false.
      character*4 :: Yes_xyz='Xmol'
      real(8) :: ampl=0.05d0,Temp=300.0d0,zangle=0.0d0
      real(8),dimension(3) :: Direct=(/0.0d0,0.0d0,-1.0d0/), &
                              Pol_E=(/1.0d0,0.0d0,0.0d0/)
      character*9 :: I_of_w_aver='  no_aver'
      real(8) :: step=0.1,Up_lim=0.0
      integer :: N_disp=1,ibound=10
      real(8),dimension(9) :: sigma=(/10.0,20.0,30.0,40.0,50.0, &
                                60.0,70.0,80.0,90.0/)
!
      integer :: IA,is,i,j,io,N,k,nt,iN,Ndim,iErr,Ntp,Np_atoms,na
      integer :: l0,nat,iV,iang,i0,i1,i2,Nnn,l1,l2
      integer :: ir1,ir2,irep,length,Ndispl
      real(8) :: E_L,E_R,Temp1,Temp2,stepT,prod_freq_log,ww
      real(8) :: sigmam,omega,freq1,fren,zero,en,amp,s,st
      real(8) :: rad,dd,w2,ddm,amass,ex,dos,pdos,Pref_Iw

      M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0

!
!........... keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
!
!............. read the info from mol_vibr()
!
      open(23,file='vibr_info.dat',form='formatted',status='old',err=5)
      read(23,'(2(i5,x),a8)',err=5,end=5) NEPR,Nsp,system
      if(system.eq.' K-POINT') return
      read(23,'(a3,20(x,a3))',err=5,end=5) GroupN,(NAZVIR(IA),IA=1,NEPR)
      read(23,'(20(a2,x))',err=5,end=5)  (Species(is),is=1,Nsp)
      read(23,*,err=5,end=5) (IRA_left(IA),IA=1,NEPR)
      read(23,*,err=5,end=5) (NALFA(IA),IA=1,NEPR)
      read(23,*,err=5,end=5) NORB,MG,(KG(i),i=1,MG)
      read(23,*,err=5,end=5) (KAN(io),(R1(io,j),j=1,3),io=1,NORB)
      read(23,*,err=5,end=5) (ISORT1(io),io=1,NORB)
      read(23,*,err=5,end=5) &
           ((orb_to_old(io,nat),nat=1,KAN(io)),io=1,NORB)
      read(23,'(20(l1,x))',err=5,end=5) (Fix(io),io=1,NORB),Yes_Fixed
      read(23,'(5(f10.5,x))',err=5,end=5) ((TRAN(N,j),j=1,3),N=1,MG)
      read(23,*,err=56,end=56) (ICMPL(IA),IA=1,NEPR)
      go to 57
 56   write(*,*)'<= trying to continue; old format =>'
      ICMPL=0
 57   if(system.eq.'LATT-TRA') then
         read(23,*,err=5,end=5) AI,BI,AJ,BJ,IJ
         read(23,*,err=5,end=5)  ITI,((TI(j,n),j=1,3),n=1,ITI)
         read(23,*,err=5,end=5)  (NspN(i),i=1,Nsp)
         read(23,*,err=5,end=5) ((Vkp(k,j),j=1,3),k=1,MG)
         read(23,*,err=5,end=5) ((Vk_rep(IA,j),j=1,3),IA=1,NEPR)
      end if
      close (23)
      go to 7
 5    write(*,*)'FATAL! File [vibr_info.dat] is bad or absent!'
      return

!
!............. check if atoms are in different order
!
 7    Diff_Order_of_Atoms=.false.
      nt=0
      do io=1,NORB
         do iN=1,KAN(io)
            nt=nt+1
            if(nt.ne.orb_to_old(io,iN)) Diff_Order_of_Atoms=.true.
         end do
      end do
!
!.............. collect necessary info
!               Ndim - total dimension  of the problem
!                  j - counts degrees of freedom
      j=0
      do io=1,NORB
         if( .not.Fix(io) ) j=j+3*KAN(io)
      end do
      Ndim=j
      write(*,*)'===> Total atomic dimension found = ',Ndim
      allocate(at_info(Ndim)) ; allocate(xyz_info(Ndim))
      allocate(species_info(Ndim)) ; allocate(old_atom_from_vibr(Ndim))
      j=0
      nat=0
      do io=1,NORB
         if( .not.Fix(io) ) then
            do iN=1,KAN(io)
               do k=1,3
                  j=j+1
                  at_info(j)=iN+nat
                  xyz_info(j)=k
                  species_info(j)=ISORT1(io)
                  mchange(iN+nat)=.false.
                  old_atom_from_vibr(j)=orb_to_old(io,iN)
               end do
            end do
         end if
         nat=nat+KAN(io)
      end do
      Ndim=j
!
!............... set default masses on atoms
!
      call mass_default(Atom_Mass)
!
!............... construct the Force Constant Matrix ...............
!............... in Cartesian representation  (G_mat)  .............
!
      call do_F_mat_files(IRA_left,NEPR,N0IR,Err)
      if(Err) return
!
!............... determine the number of displacements
!
      do IA=1,NEPR
         if(IRA_left(IA).ne.0) then         
            if(IA.lt.10) then
               write(cha1,'(i1)') IA
               open (23,file='F_'//cha1//'.mat',form='formatted', &
                    status='old',err=19)
            else
               write(cha2,'(i2)') IA
               open (23,file='F_'//cha2//'.mat',form='formatted', &
                    status='old',err=19)
            end if
            call CutStr(Line,NumLin,LinPos,LinEnd,23,0,iErr)
            if(iErr.ne.0) go to 19
            if(index(Line,'# amplitudes').ne.0) then
               read(line(LinPos(3):),*,err=19,end=19) Ndispl
            end if
            close (23)
            exit
         end if
      end do
      write(*,*)'==> Number of amplitudes found = ',Ndispl
      
!
!.......... calculate force constant matrices using right-upper, left-lower
!           and average method of symmetrisation of the FCM
!
      allocate(F_mat(Ndim,Ndim)) ; allocate(G_mat(Ndim,Ndim))
      allocate(EigV(Ndim,Ndim)) ; allocate(EigR(Ndim))
      allocate(Freq_ru(Ndim)) ; allocate(Freq_ll(Ndim)) ; allocate(Freq(Ndim))

      call build_fcm(Ndim,IRA_left,Err,'right-u',Which_Code,Ndispl)
      call calculate_freq(Ndim,Freq_ru,Atom_Mass,prod_freq_log)
      if(Err) then
         write(*,*)'ERROR when constructing force constant matrix (RU)'
         return
      end if
      call build_fcm(Ndim,IRA_left,Err,'left-lw',Which_Code,Ndispl)
      call calculate_freq(Ndim,Freq_ll,Atom_Mass,prod_freq_log)
      if(Err) then
         write(*,*)'ERROR when constructing force constant matrix (LL)'
         return
      end if
      call build_fcm(Ndim,IRA_left,Err,'average',Which_Code,Ndispl)
      call calculate_freq(Ndim,Freq,Atom_Mass,prod_freq_log)
      if(Err) then
         write(*,*)'ERROR when constructing force constant matrix (AV)'
         return
      end if

      Yes_solved=.true.
      E_L=0.0
      E_R=max(Freq(Ndim),Freq_ru(Ndim),Freq_ll(Ndim))+3*sigma(1)
!
!..................................................................
!..................... Main menu starts here ......................
!..................................................................
!
      Changed_Mass=.false. ; Yes_chosen=.false. ; ChargeS=.false.
      IR_normalise=.false.
      Temp1=10.0; Temp2=500.0 ; Ntp=10 ; stepT=(Temp2-Temp1)/Ntp

 21   write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      if(Diff_Order_of_Atoms) &
         write(*,'(a)') ' ++++ IMPORTANT: order of atoms CHANGED! ++++'
      if(system.eq.'MOLECULE') then
         write(*,'(2a)')' MOLECULE: lattice translations IGNORED'
      else
         write(*,'(2a)')' SUPERCELL: lattice translations USED'
         write(*,*)'... CURRENT lattice vectors for the supercell:...'
         write(*,'(a,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      end if
      write(*,'(a)')
      write(*,*)'========= CHOOSE an OPTION:'
      write(*,'(a)')

      write(*,'(a)') ' Am. Change atomic masses for a range of atoms'

!________ action

      write(*,'(a)') &
      '------ A c t i o n s  w i t h  v i b r a t i o n s  ----------'
      if(Yes_solved) then
         write(*,'(a)') ' Ei. Solve the eigenvalue problem <= Done!'
         write(*,'(5x,a,e16.10)') &
           'Nat. logarithm of product of frequencies = ',prod_freq_log
         write(*,'(a)') ' Sv. Show eigenvalues/vectors'
         write(*,'(a)') ' Sa. Show frequencies and normal modes'
         write(*,'(a)') ' Vs. Write xyz movie file for a mode'
      else
         write(*,'(a)') ' Ei. Solve the eigenvalue problem'
      end if

!_______ Free energy

      write(*,'(a)') &
      '----------------------- F r e e   e n e r g y ----------------'
      if(Yes_solved) &
           write(*,'(a)') ' Fr. Show the free energy (eV)'
      write(*,'(a,i10)') &
           ' Np. [Free energy]: Number of temperature points: ',Ntp
      write(*,'(2(a,f10.5),a)') &
      ' Tr. [Free energy]: Temperature range: [',Temp1,' - ',Temp2,']'
      stepT=(Temp2-Temp1)/Ntp
      write(*,'(a,f10.5,a)') &
           '                    Temperature step = ',stepT,' K'

!_______ DOS options

      write(*,'(a)') &
      '------------------------ p h o n o n   D O S -----------------'
      if(Yes_solved) then
         write(*,'(a)') &
              ' D1. Calculate the phonon DOS: different dispersions'
         if(Yes_chosen) write(*,'(a)') &
              ' D2. Calculate the phonon DOS: projected on atoms'
         write(*,*)'     Dispersion to be used = ',sigma(1)
      end if
      if(.not.Yes_chosen) then
         write(*,'(a)')' pD. Choose atoms for projected phonon DOS'
      else
         write(*,'(a)') &
              ' pD. Choosen atoms for projected phonon DOS:'
         write(*,'(10x,9(i3,x))') (Num_proj_atom(k),k=1,Np_atoms)
!         write(*,'(10x,9(i3,a,i3,a,x))')
!     &     (Num_proj_atom(k),'{=',j_proj_atom(k),'}',k=1,Np_atoms)
      end if

!________ IR intensity option

      write(*,'(a)') &
      '---------------------- IR  i n t e n s i t y -----------------'
      write(*,'(a,f10.5)')'  T. For I(w): Temperature (K): ',Temp
      if(I_of_w_aver.eq.'  no_aver') then
         write(*,'(a)') &
           ' Av. For I(w): particular polarisation direction'
         write(*,'(a)')   '  D. For I(w): direction of E in E/M wave:'
         write(*,'(15x,3(f10.5,x))') (Pol_E(i),i=1,3)
      else if(I_of_w_aver.eq.' pol_aver') then
         write(*,'(a)') &
      ' Av. For I(w): aver. polarisations: given propagation direction'
         write(*,'(a)')   '  D. For I(w): direction of the wave:'
         write(*,'(15x,3(f10.5,x))') (Direct(i),i=1,3)
      else if(I_of_w_aver.eq.'zpol_aver') then
         write(*,'(a)') &
      ' Av. For I(w): aver. polarisations: given angle with Z axis'
         write(*,'(a,f10.5)') &
              '  D. For I(w): propagation direction angle: ',zangle
      else if(I_of_w_aver.eq.'full_aver') then
         write(*,'(a)')' Av. For I(w): full average over ALL directions'
      end if
      if(ChargeS) then
         write(*,'(a)') ' Bc. For I(w): Born charges on atoms: KNOWN'
         write(*,'(a)') &
              ' CM. For I(w): modify Born charges on a set of atoms'
         write(*,'(a)') ' Pf. For I(w): show prefactors'
         if(Yes_solved) &
           write(*,'(a)')   ' Iw. Calculate the IR intensity curve I(w)'
      else
         write(*,'(a)')' Bc. For I(w): Born charges on atoms: NOT KNOWN'
      end if

!_____ show if the FCM is good enough (error analysis)

      if(.not.Changed_Mass) then
         write(*,'(a)') &
        '------ C h e c k i n g   p r e c i s i o n  o f  F C M -------'
         write(*,'(a)')' Pr. Compare DOS using three FCMs'
      end if

!_____ show info

      write(*,'(a)') &
      '-------------- G e n e r a l  I n f o r m a t i o n ----------'
      write(*,'(a)')' Co. Show information about atoms'
      if(ChargeS) write(*,'(a)')' SB. Show Born charges'
      write(*,'(a)')' Sy. Show the point symmetry group info'

!________ settings for graphics

      write(*,'(a)') &
      '------------- S e t t i n g s:  D O S  a n d  I(w) -----------'
      write(*,'(a,i1)')' Nd. Number of dispersions/broadenings: ',N_disp
      if(N_disp.eq.1) then
         write(*,'(a,f10.5)') &
              ' Sg. Dispersion for DOS/I(w) (cm^-1): ',sigma(1)
      else
         write(*,'(a)') ' Sg. Dispersions for DOS/I(w) (cm^-1): '
         write(*,'(10x,9(f10.5,x))') (sigma(i),i=1,N_disp)
      end if
      sigmam=0.0
      do i=1,N_disp
         if(sigma(i).gt.sigmam) sigmam=sigma(i)
      end do

      write(*,'(a,f10.5)')' St. Step for DOS/I(w) (cm^-1): ',step
      if(IR_normalise) then
         write(*,'(a,f10.5)')' NI. Normalise the IR spectrum: YES'
      else
         write(*,'(a,f10.5)')' NI. Normalise the IR spectrum: NO'
      end if
      if(Up_lim.ne.0.0) then
         write(*,'(a,f10.5)')' Up. Upper limit for DOS/I(w): ',Up_lim
      else
         write(*,'(a,f10.5)')' Up. Upper limit for DOS/I(w): not set'
      end if
      write(*,'(2(a,f10.5),a)') &
           ' EB. Energy interval for DOS:  [',E_L,',',E_R,']'
      write(*,'(2(a,f10.5),a)') &
           '     Energy interval for I(w): [',E_L,',',2*E_R,']'

!___________ general settings

      write(*,'(a)') &
      '---------------- G e n e r a l  S e t t i n g s --------------'
!      write(*,'(a)')
!     &   ' XY. Format of <geom.xyz> file is for '//YES_xyz
      write(*,'(a)') &
         '  W. Write <geom.xyz> file to preview the current geometry'
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,'(a)') &
                 ' Hs. H atoms to be added to <geom.xyz> file: YES'
         else
            write(*,'(a)') &
                 ' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      write(*,'(a,f10.5)')' Da. Distortion amplitude for movies: ',ampl
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)
!
![Am]............. atomic masses
!
      IF(cha2(l0:).eq.'Am') THEN

         call Tag_Am(NumLin,ITI,Err,Ndim,mchange)
         if(NumLin.eq.0) then
            call mass_default(Atom_Mass)
            write(*,*)'WARNING! Default masses are set!'
            Changed_Mass=.false.
            go to 14
         end if
         if(Err) go to 12

 3       write(*,*)'Give the new mass for these atoms (a.u.m.):'
         read(*,*,err=3) amass  ; write(8,*) amass
         nat=0
         do io=1,NORB
            do iN=1,KAN(io)
               nat=nat+1
               if(mchange(nat)) Atom_Mass(nat)=amass
            end do
         end do
         Changed_Mass=.true.
 14      Yes_solved=.false. ; Yes_chosen=.false.
 12      do j=1,ITI
            mchange(j)=.false.
         end do

![Ei]...... solve the eigenvalue problem

      ELSE IF(cha2(l0:).eq.'Ei') THEN

!____________ calculate the dynamical matrix with given masses at atoms
!              and diagonalise it; then calculate eigenvlues

         call calculate_freq(Ndim,Freq,Atom_Mass,prod_freq_log)
         Yes_solved=.true.

![Sv]...... show eigenvalues/vectors prior to W_all multiplication
!           (i.e. mixing of generalised displacements)

      ELSE IF(cha2(l0:).eq.'Sv' .and. Yes_solved) THEN

         write(*,*)'>>>>>>>> RESULT of diagonalisation: <<<<<<<<<<<'
         call print_eigenproblem(EigR,EigV,Ndim,Ndim,6)
         open(37,file='EIGEN_all.res',status='unknown')
         call print_eigenproblem(EigR,EigV,Ndim,Ndim,37)
         close (37)
         write(*,'(/a)') &
            '*******************************************************'
         write(*,'(a)') &
           '   Full table can also be seen in the file EIGEN_all.res'
         write(*,'(a/)') &
            '*******************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![Sa]...... show frequencies (in cm^-1) and normal modes;
!       if a frequency is imaginary (EigR < 0), it is set to -1

      ELSE IF(cha2(l0:).eq.'Sa' .and. Yes_solved ) THEN

         call show_normal_coord(Ndim,Freq,Species,6)
         open(37,file='N_MODES_all.res',status='unknown')
         call show_normal_coord(Ndim,Freq,Species,37)
         close (37)
         write(*,'(/a)') &
          '**********************************************************'
         write(*,'(a)') &
          '   Full table can also be seen in the file N_MODES_all.res'
         write(*,'(a/)') &
          '**********************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![Fr]...... show the quasiharmonic free energy from all frequencies

      ELSE IF(cha2(l0:).eq.'Fr' .and. Yes_solved) THEN

         open(72,file='free.en', form='formatted')
         write(*,'(a)') '... Writing free energy into [free.en]'
         write(72,*)'#.... T(K) ... Zero en.(eV) ... Free en.(eV) ...'
         write(*,*) '#.... T(K) ... Zero en.(eV) ... Free en.(eV) ...'
         do k=1,Ndim
            if(EigR(k).ge.0.0d0) then
               omega=sqrt( EigR(k)*.9648667d+28 )
               freq1=omega*53.08837459d-13
               if(freq1.gt.0.01) then
                  write(*,*)'# freq = ',freq1,' cm^-1'
                  write(72,*)'# freq = ',freq1,' cm^-1'
               end if
            end if
         end do

         do i=1,Ntp+1
            Temp=Temp1+(i-1)*stepT ; fren=0.0d0 ; zero=0.0d0

            do k=1,Ndim
               if(EigR(k).ge.0.0d0) then
                  omega=sqrt(EigR(k)*.9648667d+28 ) ; en = H_bar*omega
                  freq1=omega*53.08837459d-13
                  if(freq1.gt.0.01) then
                     ex=exp(-en/(K_B*Temp))  ; zero=zero + en/2.
                     fren=fren + K_B*Temp*log(1.0d0-ex)
                  end if
               end if
            end do

            write(72,'(5x,f10.5,2(5x,e16.10))') Temp, zero, fren + zero
            write(*,'(5x,f10.5,2(5x,e16.10))') Temp, zero, fren + zero

         end do
         close(72)
         write(*,'(a/)') &
            '*******************************************************'
         write(*,'(a)')'   Free energy vs. T is written into [free.en]'
         write(*,'(a/)') &
            '*******************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![Np]...... number of points of T for the free energy

      ELSE IF(cha2(l0:).eq.'Np') THEN

 34      write(*,*)'Specify the number of T points for the free energy:'
         read(*,*,err=34) Ntp  ; write(8,*) Ntp
         if(Ntp.lt.1) go to 34

![Tr]...... Temperature range for the free energy

      ELSE IF(cha2(l0:).eq.'Tr') THEN

 35      write(*,*)'Specify the min and max temperatures (in K):'
         read(*,*,err=35) Temp1, Temp2  ; write(8,*) Temp1,Temp2
         if(Temp1.lt.1.0 .or. Temp2 .lt. 1.0 &
                             .or. Temp1.gt.Temp2) go to 35

![Vs]...... create a xyz-movie for a normal mode

      ELSE IF(cha2(l0:).eq.'Vs' .and. Yes_solved) THEN

         if(Ndim.gt.1) then
 16          write(*,'(a,i3)') &
              'Specify a normal mode vector between 1 and ',Ndim
            read(*,*,err=16) iV  ; write(8,*) iV
            if(iV.lt.1 .or. iV.gt.Ndim) go to 16
         else
            iV=1
         end if
         open(37,file='geom.xyz',form='formatted')
         do iang=0,360,10
            amp=2*ampl*sin(iang*pi/180.0)
            call distorted_xyz_all(Ndim,iV,amp,Species,ITI, &
                                                37,YES_xyz,Add_Hs)
         end do
         close (37)

![Pr]...... display the DOS using upper-right, left-lower and average FCMs

      ELSE IF(cha2(l0:).eq.'Pr' .and. (.not.Changed_Mass) ) THEN

         if(N_disp.gt.1) then
            write(*,*)'WARNING: the first dispersion will only be used'
            write(*,*)'       Disp = ',sigma(1)
            write(*,*)'Press ENTER when ready ...'
            read(*,*)  ; write(8,'(a)') 'PressEnter'
         end if
         open(31,file='dos_err.dat',form='formatted',status='unknown')
         ww=0.0
         do while (ww.lt.Freq(Ndim)+3*sigma(1))
            ww=ww+step
            write(31,'(10(f10.5,x))') ww,dos(ww,Ndim,Freq,sigma(1)), &
                                     dos(ww,Ndim,Freq_ru,sigma(1)),  &
                                     dos(ww,Ndim,Freq_ll,sigma(1))
         end do
         close (31)

         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title   ; write(8,'(a)') trim(Title)
         title_pl(1)= ' average '
         title_pl(2)= 'right-upp'
         title_pl(3)= 'left-lowe'
         call Plot(3,'dos_err.dat ',11, &
                  Title,title_pl,E_L,E_R, &
                 'Frequency (cm^-1)   ', &
                 'DOS (arb.units)     ', 'Screen', 31,Up_lim)
         call Plot(3,'dos_err.dat ',11, &
                  Title,title_pl,E_L,E_R, &
                 'Frequency (cm^-1)   ', &
                 'DOS (arb.units)     ', 'Postsc', 31,Up_lim)


![D1]...... calculate DOS for a set of dispersions

      ELSE IF(cha2(l0:).eq.'D1' .and. Yes_solved) THEN

         open(31,file='dos.dat',form='formatted',status='unknown')
         ww=0.0
         do while (ww.lt.Freq(Ndim)+3*sigmam)
            ww=ww+step
            write(31,'(10(f10.5,x))') &
                 ww,(dos(ww,Ndim,Freq,sigma(i)),i=1,N_disp)
         end do
         close (31)

         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title   ; write(8,'(a)') trim(Title)
         do i=1,N_disp
            write(cha5,'(f5.1)') sigma(i)
            title_pl(i)= 's = '//cha5
         end do
         call Plot(N_disp,'dos.dat     ',7, &
                  Title,title_pl,E_L,E_R, &
                 'Frequency (cm^-1)   ', &
                 'DOS (arb.units)     ', 'Screen', 31,Up_lim)
         call Plot(N_disp,'dos.dat     ',7, &
                  Title,title_pl,E_L,E_R, &
                 'Frequency (cm^-1)   ', &
                 'DOS (arb.units)     ', 'Postsc', 31,Up_lim)

![D2]...... calculate projected DOS for a set of atoms

      ELSE IF(cha2(l0:).eq.'D2' .and. Yes_solved .and. Yes_chosen) THEN

         open(31,file='dos_proj.dat',form='formatted',status='unknown')
         s=sigma(1)
         ww=0.0
         do while (ww.lt.Freq(Ndim)+3*s)
            ww=ww+step
            st=dos(ww,Ndim,Freq,s)
            write(31,'(10(f10.5,x))') ww,st, &
               (pdos(ww,Ndim,Freq,s,j_proj_atom(k)),k=1,Np_atoms)
         end do
         close (31)

         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title   ; write(8,'(a)') trim(Title)
         title_pl(1)='total DOS'
         do k=1,Np_atoms
            write(cha4,'(i4)') Num_proj_atom(k)
            title_pl(k+1)='atom '//cha4
         end do
         call Plot(Np_atoms+1,'dos_proj.dat',12, &
                  Title,title_pl,E_L,E_R, &
                 'Frequency (cm^-1)   ', &
                 'Proj-DOS (arb.units)', 'Screen', 31,Up_lim)
         call Plot(Np_atoms+1,'dos_proj.dat',12, &
                  Title,title_pl,E_L,E_R, &
                 'Frequency (cm^-1)   ', &
                 'Proj-DOS (arb.units)', 'Postsc', 31,Up_lim)

![pD]...... choose atoms for projected DOS

      ELSE IF(cha2(l0:).eq.'pD') THEN

         do j=1,ITI
            proj_at(j)=.false.
         end do
 31      write(*,*)'Give atomic numbers for projected DOS on one line'
         write(*,*) &
           'using dashes, commas and spaces (up to 8 atoms in total):'
         read(*,'(a)') line  ; write(8,'(a)') trim(line)
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 31
         nt=0
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*,err=31) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*,err=31) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*,err=31) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 31
            do j=i1,i2
               nt=nt+1
               if(nt.gt.8) then
                  write(*,*) &
                   'WARNING: The list is longer than 8 and will be cut'
               else
                  proj_at(j)=.true.
                  Num_proj_atom(nt)=j
               end if
            end do
         end do
         Np_atoms=nt
         if(nt.gt.8) Np_atoms=8
         Yes_chosen=.true.

!____________ determine degrees of freedom j corresponding to projected atoms

         Err=.false.
         do k=1,Np_atoms
            do j=1,Ndim,3
               if(at_info(j).eq.Num_proj_atom(k)) then
                  j_proj_atom(k)=j
                  go to 51
               end if
            end do
            Err=.true.
            write(*,'(a,i5,a)') 'ERROR: atom ',Num_proj_atom(k), &
                         ' is fixed and thus cannot be chosen'
 51      end do
         if(Err) Yes_chosen=.false.

![Co]...... show information about orbits

      ELSE IF(cha2(l0:).eq.'Co') THEN

         write(*,'(a)') 'Tot--Orb-Species-Number-------'// &
      '--atom coordinates---------Radius--Fix-|----Mass----|-Old#-'
         nt=0
         do io=1,NORB
            is=ISORT1(io)
            if(Fix(io)) then
               cha1='Y'
            else
               cha1='N'
            end if
            RA(1:3)=R1(io,1:3)
            call pvrt0(RA,RR,Nnn)
            do iN=1,KAN(io)
               nt=nt+1
               rad=sqrt(RR(iN,1)**2+RR(iN,2)**2+RR(iN,3)**2)
               write(*,'(i4,x,2(i3,x),a2,x,i5,x,4(f10.5,x),x,a,x,f9.5,x,a,i4)') &
                 nt,io,is,Species(is),iN,(RR(iN,j),j=1,3),rad, &
                 cha1//' | ',Atom_mass(nt),'| ',orb_to_old(io,iN)
            end do
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![SB]...... show Born charges on atoms

      ELSE IF(cha2(l0:).eq.'SB' .and. ChargeS) THEN

         write(*,'(a)') 'Tot-Species-|--------Born--charge---'// &
          '---------------------------------------------------|-Old#-'
         nt=0
         do io=1,NORB
            is=ISORT1(io)
            if(Fix(io)) then
               cha1='Y'
            else
               cha1='N'
            end if
            RA(1:3)=R1(io,1:3)
            call pvrt0(RA,RR,Nnn)
            do iN=1,KAN(io)
               nt=nt+1
               rad=sqrt(RR(iN,1)**2+RR(iN,2)**2+RR(iN,3)**2)
               if(ChargeS) then
                  nat=orb_to_old(io,iN)
                  write(cch,'(9(f7.3,x))') ((Q(i,j,nat),j=1,3),i=1,3)
               else
                  cch='                         --- Not available ---' &
                       //'                          '
               end if
               write(*,'(i4,x,i3,x,a2,a3,a72,a,i4)') &
                 nt,is,Species(is),' | ',cch,' |',orb_to_old(io,iN)
            end do
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n','y')
         write(*,'(2a)') 'Point symmetry group:       ',GroupN
         if(MG.gt.12) then
            write(*,'(a,12(a4,1x))') 'Group operators:            ', &
                 (NAZ(KG(i)),i=1,12)
            do i=13,MG,12
               l1=i
               l2=l1+12
               if(l2.gt.MG) l2=MG
               write(*,'(a,12(a4,1x))') (NAZ(KG(j)),j=l1,l2)
            end do
         else
            write(*,'(a,12(a4,1x))') 'Group operators:            ', &
                 (NAZ(KG(i)),i=1,MG)
         end if
         write(*,'(a,12(i2,2x))')  'Irreducible represenations #: ', &
              (i,i=1,NEPR)
         write(*,'(a,12(x,a3))')'Their names:                  ', &
              (NAZVIR(i),i=1,NEPR)
         write(*,'(a,12(x,i2,x))')'Their dimensions:            ', &
              (NALFA(i),i=1,NEPR)
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![Da]...... displacement amplitude

      ELSE IF(cha2(l0:).eq.'Da') THEN

 13      write(*,*)'Specify the amplitude of distortion (in A):'
         read(*,*,err=13) ampl  ; write(8,*) ampl

![XY]...... ask the code for movie.xyz file

!      ELSE IF(cha2(l0:).eq.'XY') THEN

!         if(YES_xyz.eq.'Ymol') then
!            YES_xyz='Xmol'
!         else if(YES_xyz.eq.'Xmol') then
!            YES_xyz='Ymol'
!         end if

![Hs]...... add Hydrogens to movie.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else
            Add_Hs=.true.
         end if

![Sg]...... sigma for the DOS

      ELSE IF(cha2(l0:).eq.'Sg') THEN

 15      write(*,'(a,i1,a)')'Specify ',N_disp,' dispersions (in cm^-1):'
         read(*,*,err=15) (sigma(i),i=1,N_disp)
         write(8,*) (sigma(i),i=1,N_disp)
         do i=1,N_disp
            if(sigma(i).lt.0.0) go to 15
         end do

![Nd]...... number of dispersions

      ELSE IF(cha2(l0:).eq.'Nd') THEN

 17      write(*,*)'Specify the number of dispersions: '
         read(*,*,err=17) N_disp  ; write(8,*) N_disp
         if(N_disp.lt.1 .or. N_disp.gt.9) go to 17

![St]...... step for the DOS

      ELSE IF(cha2(l0:).eq.'St') THEN

 26      write(*,*)'Specify (in cm^-1) step for the DOS:'
         read(*,*,err=26) step  ; write(8,*) step

![NI]...... whether to normalise the IR spectrum

      ELSE IF(cha2(l0:).eq.'NI') THEN

         if(IR_normalise) then
            IR_normalise=.false.
         else
            IR_normalise=.true.
         end if

![Up]...... upper limit for the DOS

      ELSE IF(cha2(l0:).eq.'Up') THEN

 27      write(*,*)'Specify the upper limit for the DOS/I(w):'
         read(*,*,err=27) Up_lim  ; write(8,*) Up_lim

![EB]...... left/right limits for the DOS

      ELSE IF(cha2(l0:).eq.'EB') THEN

 53      write(*,*) 'Specify the left and right limits for the DOS:'
         write(*,*)'Hit ENTER to change to the default value'
         read(*,'(a)') line  ; write(8,'(a)') trim(line)
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(NumLin.eq.0) then
            write(*,*)'Restoring default value ...'
            E_L=0.0
            E_R=max(Freq(Ndim),Freq_ru(Ndim),Freq_ll(Ndim))+3*sigmam
         else
            read(Line(LinPos(1):LinEnd(1)),*,err=53) E_L
            read(Line(LinPos(2):LinEnd(2)),*,err=53) E_R
         end if
         if(E_L.ge.E_R) go to 53

![T]...... temperature in K

      ELSE IF(cha2(l0:).eq.'T') THEN

 28      write(*,*)'Specify the temperature (in K) for I(w):'
         read(*,*,err=28) Temp  ; write(8,*) Temp

![Av]...... if average over all directions of E or not

      ELSE IF(cha2(l0:).eq.'Av') THEN

         if(I_of_w_aver.eq.'  no_aver') then
            I_of_w_aver=' pol_aver'
         else if(I_of_w_aver.eq.' pol_aver') then
            I_of_w_aver='zpol_aver'
         else if(I_of_w_aver.eq.'zpol_aver') then
            I_of_w_aver='full_aver'
         else if(I_of_w_aver.eq.'full_aver') then
            I_of_w_aver='  no_aver'
         end if

![D]...... direction of polarisation (E-direction) or direction of the wave

      ELSE IF(cha2(l0:).eq.'D' .and. I_of_w_aver.ne.'full_aver') THEN

 29      if(I_of_w_aver.eq.' pol_aver') then
            write(*,*)'Specify direction of the E/M wave:'
            read(*,*,err=29) Direct  ; write(8,*) Direct
            dd=sqrt(Direct(1)**2+Direct(2)**2+Direct(3)**2)
            if(dd.lt.tiny) go to 29
            Direct(1)=Direct(1)/dd
            Direct(2)=Direct(2)/dd
            Direct(3)=Direct(3)/dd
         else if(I_of_w_aver.eq.'zpol_aver') then
            write(*,*)'Specify propagation direction angle with the '// &
                 ' Z axis (in Degrees):'
            read(*,*,err=29) zangle  ; write(8,*) zangle
            Direct(1)=zangle
         else if(I_of_w_aver.eq.'  no_aver') then
            write(*,*)'Specify E direction in the E/M wave:'
            read(*,*,err=29) Pol_E  ; write(8,*) Pol_E
            dd=sqrt(Pol_E(1)**2+Pol_E(2)**2+Pol_E(3)**2)
            if(dd.lt.tiny) go to 29
            Pol_E(1)=Pol_E(1)/dd
            Pol_E(2)=Pol_E(2)/dd
            Pol_E(3)=Pol_E(3)/dd
         end if

![Bc]...... Born charges on atoms

      ELSE IF(cha2(l0:).eq.'Bc') THEN

         write(*,*) &
           '**    Specify the file name with Born charges on atoms:  **'
         write(*,*) &
           '***** should be in the SAME ORDER as in GEOMETRY FILE  ****'
         read(*,'(a)') name  ; write(8,'(a)') trim(name)
         call right(name,50,l1)
         open(79,file=name(l1:),form='formatted',status='old',err=71)

!_________ Important: atoms in the file are ordered in the original order!
!          We should assign charges corresponding to the new order by orbits
! TO DO: put the corresponding reading statements for each coed to read
!        from their outputs directly when available

         if(Which_Code.eq.'SIESTA') then
            read(79,*)
            do na=1,ITI
               read(79,*,err=71,end=71) ((Q(i,j,na),j=1,3),i=1,3)
            end do
         else if(Which_Code.eq.'  VASP') then
            read(79,*)
            do na=1,ITI
               read(79,*,err=71,end=71) ((Q(i,j,na),j=1,3),i=1,3)
            end do
         else if(Which_Code.eq.'VASP52') then
            read(79,*)
            do na=1,ITI
               read(79,*,err=71,end=71) ((Q(i,j,na),j=1,3),i=1,3)
            end do
         else
            write(*,*)'*** There is NO yet support for other codes ***'
            ChargeS=.false.
            go to 21
         end if
         close (79)
         ChargeS=.true.
         go to 21
 71      write(*,'(a)') 'ERROR! The file '// &
              name(l1:)//' with Born charges is absent or bad'
         write(*,'(a)') '       I(w) cannot be calculated'
         ChargeS=.false.

![CM]...... modify charges on atoms

      ELSE IF(cha2(l0:).eq.'CM' .and. ChargeS) THEN

         write(*,*) &
              '-------------------------------------------------------'
         write(*,*) &
              'Specify atoms for which the SAME charges will be given:'
         write(*,*) '      [in the OLD order (as in the geometry file)]'
         write(*,*) &
              '-------------------------------------------------------'
         call Tag(NumLin,ITI,listat,lists,length,N_lists,long_lists)
         if(NumLin.eq.0) go to 21
 32      write(*,*) &
              'Specify the Born charge tensor (3x3) for these atoms:'
         read(*,*,err=32) ((chrg(i,j),j=1,3),i=1,3)
         write(8,*) ((chrg(i,j),j=1,3),i=1,3)
         do na=1,ITI
            if(listat(na)) then
               do i=1,3
                  Q(i,1:3,na)=chrg(i,1:3)
               end do
            end if
         end do

![Pf]...... Prefactors for IR intensity: for information only

      ELSE IF(cha2(l0:).eq.'Pf' .and. ChargeS) THEN

         allocate(Pref(Ndim))
         do j=1,Ndim
            if(Freq(j).gt.tiny) then
               Pref(j)= &
           Pref_Iw(j,Ndim,Q,Atom_Mass,I_of_w_aver,Direct,Pol_E,.true.)
            else
               Pref(j)=0.0d0
            end if
         end do
         do irep=1,Ndim,ibound
            ir1=irep ; ir2=ir1+ibound-1
            if(ir2.gt.Ndim) ir2=Ndim
            write(*,'(a,10(x,f10.5))') '* Frequency (cm^-1): ', &
                                                   (Freq(i),i=ir1,ir2)
            write(*,'(a,10(x,f10.5))') 'Prefactor (arb.un.): ', &
                                                   (Pref(i),i=ir1,ir2)
            write(*,*) &
                 '---------------------------------------------------'
         end do
         deallocate(Pref)
         write(*,*)'Press ENTER when ready ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![Iw]...... IR intensity calculated here for a set of broadening parameters

      ELSE IF(cha2(l0:).eq.'Iw' .and. ChargeS .and. Yes_solved) THEN

         ww=1.0
         w2=2*Freq(Ndim)+3*sigmam

!______________ determine the normalisation factor
         if(IR_normalise) then
            ddm=0.0d0
            do while (ww.lt.w2)
               ww=ww+step
               dd=I_of_w(ww,Ndim,Freq,sigma(1),Temp,Q,Atom_Mass, &
                    I_of_w_aver,Direct,Pol_E)
               if(dd.gt.ddm) ddm=dd
            end do
            write(*,*)'Max value for normalisation = ',ddm
         end if
!_______________ actual calculation

         ww=1.0
         open(31,file='I_of_w.dat',form='formatted',status='unknown')
         do while (ww.lt.w2)
            ww=ww+step
            if(IR_normalise) then
               write(31,'(10(f10.5,x))') ww,(I_of_w(ww,Ndim,Freq, &
                    sigma(i),Temp,Q,Atom_Mass,I_of_w_aver,Direct,Pol_E)/ &
                    ddm,i=1,N_disp)
            else
               write(31,'(10(e12.7,x))') ww,(I_of_w(ww,Ndim,Freq, &
               sigma(i),Temp,Q,Atom_Mass,I_of_w_aver,Direct,Pol_E), &
                    i=1,N_disp)
            end if
         end do
         close (31)

!_______________ plot
         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title   ; write(8,'(a)') trim(Title)
         do i=1,N_disp
            write(cha5,'(f5.1)') sigma(i)
            title_pl(i)= 's = '//cha5
         end do
         call Plot(N_disp,'I_of_w.dat  ',10, &
                  Title,title_pl,E_L,2*E_R, &
                 'Frequency (cm^-1)   ', &
                 'I(w) (arb.units)    ', 'Screen', 31,Up_lim)
         call Plot(N_disp,'I_of_w.dat  ',10, &
                  Title,title_pl,E_L,2*E_R, &
                 'Frequency (cm^-1)   ', &
                 'I(w) (arb.units)    ', 'Postsc', 31,Up_lim)

![W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W') THEN

!___________ constract all lattice sites  and write geom.xyz
         call dump_orb_xyz(YES_xyz,Add_Hs)

![Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         deallocate(F_mat) ; deallocate(G_mat) 
         deallocate(EigV) ; deallocate(EigR)
         deallocate(Freq) ; deallocate(Freq_ll) ; deallocate(Freq_ru)
         deallocate(at_info) ; deallocate(xyz_info)
         deallocate(species_info) ; deallocate(old_atom_from_vibr)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
!
!.......... error in reading mat file
!
19    write(*,*) 'ERROR! F_?.mat file is bad or absent'
      end subroutine make_fcm

      subroutine build_fcm(Ndim,IRA_left,Err,WhichForce,Which_Code,Ndispl)
!..................................................................................
! Force constant matrix is constructed from all irreps in one go in G_mat.
!..................................................................................
      use real8
      use tetrag1
      use pgroup
      use working
      use symgenv
      use matrix
      use systema
      use atom_info
      implicit none
      integer :: IRA_left(N0IR)
      character :: WhichForce*7,Which_Code*6
      logical :: Err1,W_files(N0IR),Yes_W_all,F_files(N0IR),Yes_F_mat
      logical :: Err
      integer,dimension(3) :: kk=(/3,1,2/)
      real(8),dimension(:,:),allocatable :: F
!
      integer :: j,j1,Ndim,IA,iN,k,iN1,k1,iR,iR1,jj,Ndispl,IRA_l
      real(8) :: s

      G_mat=0.0d0
!
      DO 10 IA=1,NEPR
         IRA_l=IRA_left(IA)
         W_files(IA)=.true. ; F_files(IA)=.true.
         if(IRA_l.eq.0) go to 10
         write(*,*)'irrep= ',IA,' # of vectors = ',IRA_l

!___________ read in the W_all matrix for this irrep
         call read_W_all_matrix(IA,IRA_l,Err1)
         if(Err1) then
            write(*,*) 'FATAL! Cannot get W-matrix for irrep = ',IA
            W_files(IA)=.false.
         end if

!___________ read in the F matrix for this irrep
         allocate(F(IRA_l,IRA_l))
         call read_F_matrix(IA,F,IRA_l,ITI,Err1, &
                                   WhichForce,Which_Code,Ndispl)
         if(Err1) then
            write(*,*)'FATAL! Cannot get F-matrix for irrep = ',IA
            F_files(IA)=.false.
         end if

!___________ build up the force constant matrix in Cartesian
!            coordinates

         do j=1,Ndim
            iN=at_info(j)
            k=kk(xyz_info(j))

            do j1=j,Ndim
               iN1=at_info(j1)
               k1=kk(xyz_info(j1))

               do iR=1,IRA_l
                  do iR1=1,IRA_l

                     s=0.0d0
                     do jj=1,NALFA(IA)
                        s=s+W_all(k,iN,iR,jj)*W_all(k1,iN1,iR1,jj)
                     end do
                     G_mat(j,j1)=G_mat(j,j1)+s*F(iR,iR1)

                  end do
               end do

            end do
         end do
         deallocate(F)

 10   END DO

!___________ decide if to proceed

      Err=.false.
      Yes_W_all=.true. ; Yes_F_mat=.true.
      do IA=1,NEPR
         if(.not.W_files(IA)) Yes_W_all=.false.
         if(.not.F_files(IA)) Yes_F_mat=.false.
      end do
      if((.not.Yes_W_all) .or. (.not.Yes_F_mat)) then
         write(*,*)'FATAL! Some files are missing, cannot proceed!'
         Err=.true.
         return
      end if
      return
      end subroutine build_fcm

      subroutine mass_default(Atom_Mass)
!.................................................................
! set Atom_Mass(atom) to AtMass(species)
!.................................................................
      use real8
      use tetrag1
      use symgenv
      implicit none
      real(8) :: Atom_Mass(N0LT)
!
      integer :: nat,io,is,iN

      nat=0
      do io=1,NORB
         is=ISORT1(io)
         do iN=1,KAN(io)
            nat=nat+1
            Atom_Mass(nat)=AtMass(is)
         end do
      end do
      return
      end subroutine mass_default

      subroutine distorted_xyz_all(Ndim,iV,ampl,Species,ITI, &
                                             unit,YES_xyz,Add_Hs)
!..............................................................................
!     New atomic positions corresponding to the excitation of one diaplcement
! vector iV (with amplitude ampl) are calculated and then dumped into a unit.
!..............................................................................
      use real8
      use pgroup
      use symgenv
      use working
      use matrix
      use atom_info
      implicit none
      real(8) :: RR(MG0,3),RA(3),x(3)
      integer :: unit
      character :: YES_xyz*4,Species(N0KD)*2
      logical :: Err,Add_Hs
!
      integer :: nnn,ITI,iV,Ndim,iOrb,is,j,j1,mendl,nat
      real(8) :: ampl

!................. write number of atoms
      nnn=ITI
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(unit,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(unit,'(a/i5)') '1',nnn
      end if

      j=-2
      do iOrb=1,NORB
         is=ISORT1(iOrb)
         call check_Mendel(Species(is),mendl,Err,.false.)
         RA(1:3)=R1(iOrb,1:3)
         call PVRT0(RA,RR,Nnn)
         do nat=1,Nnn
            if( .not.Fix(iOrb) ) then
               j=j+3
               x(1)=RR(nat,1) + EigV(j  ,iV)*ampl
               x(2)=RR(nat,2) + EigV(j+1,iV)*ampl
               x(3)=RR(nat,3) + EigV(j+2,iV)*ampl
            else
               x(1:3)=RR(nat,1:3)
            end if
            if(YES_xyz.eq.'Xmol') then
               write(unit,'(a2,5x,3(f16.10,1x),a)') &
                    Species(is),(x(j1),j1=1,3)
!     &              Species(is),(x(j1),j1=1,3),' 0 0 0'
            else if(YES_xyz.eq.'Ymol') then
               write(unit,'(i2,5x,3(f16.10,1x))') &
                    mendl,(x(j1),j1=1,3)
            end if

         end do
      end do

      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(unit,'(a)')'2     0.0 0.0 0.0  '
         write(unit,'(a)')'3     15.0 0.0 0.0 '
         write(unit,'(a)')'4     0.0 15.0 0.0 '
         write(unit,'(a)')'5     0.0 0.0 15.0 '
      end if
      return
      end subroutine distorted_xyz_all

      subroutine show_normal_coord(Ndim,Freq,Species,unit)
!.............................................................
! nice print of the normal modes for all irreps
! Ndim - total number of normal modes for all irreps
!.............................................................
      use real8
      use pgroup
      use symgenv
      use working
      use matrix
      use atom_info
      implicit none
      real(8) :: RR(MG0,3),RA(3),Freq(Ndim)
      integer :: rep,unit
      character :: Species(N0KD)*2
      integer :: ibound=10
      character,dimension(3) :: a=(/'x','y','z'/)
!
      integer :: irep,Ndim,ir1,ir2,j,iOrb,nat,iold,k,nt,Nnn,is
!
!........... write on the screen/file
!
      write(unit,'(a/)') &
           '****************** normal displacements **************'

      do irep=1,Ndim,ibound
         ir1=irep
         ir2=ir1+ibound-1 ; if(ir2.gt.Ndim) ir2=Ndim
         write(unit,'(a,20(x,f10.5))') '    Frequency  (in cm^-1) ', &
                 (Freq(rep),rep=ir1,ir2)
         write(unit,'(2x,a,20(2x,i5,4x))') &
           'old#   atom#     x/y/z   ',(rep,rep=ir1,ir2)
         j=0
         do iOrb=1,NORB
            if((.not.Fix(iOrb))) then
               RA(1:3)=R1(iOrb,1:3) ; is=ISORT1(iOrb)
               call PVRT0(RA,RR,Nnn)
               do nat=1,Nnn
                  iold=orb_to_old(iOrb,nat)
                  do k=1,3
                     j=j+1 ; nt=at_info(j)
                     write(unit,'(i3,x,a,x,i5,a,20(x,f10.5))') &
                          iold,Species(is),nt,a(k),RR(nat,k), &
                          (EigV(j,rep),rep=ir1,ir2)
                  end do
               end do
               write(unit,*) &
                 '---------------------------------------------------'
            end if
         end do

         if(ir2.eq.Ndim) return
         if(unit.eq.6) then
            write(*,'(a)')'... Hit ENTER to continue ...'
            read(*,*)  ; write(8,'(a)') 'PressEnter'
         end if

      end do
      end subroutine show_normal_coord

      real(8) function dos(w,Ndim,Freq,sigma)
!.................................................................
!  calculates DOS at w (units: cm^-1)
!.................................................................
      use real8
      implicit none
      real(8) :: Freq(Ndim)
!
      integer :: k,Ndim
      real(8) :: sg2,sq,w,sigma,dw

      sg2=sigma*sigma
      sq=1.0/sqrt(2*pi*sigma)
      dos=0.0d0
      do k=1,Ndim
         if(Freq(k).gt.0.0) then
            dw=w-Freq(k)
            dos=dos+exp(-dw*dw/(2*sg2))*sq
         end if
      end do
      return
      end function

      real(8) function pdos(w,Ndim,Freq,sigma,j)
!....................................................................
!  calculates DOS at w (units: cm^-1) projected on atom associated
!  with degrees of freedom (j,j+1,j+2)=(x,y,z)
!....................................................................
      use real8
      use matrix
      implicit none
      real(8) :: Freq(Ndim)
!
      integer :: k,Ndim,j
      real(8) :: sg2,sq,w,sigma,dw,s

      sg2=sigma*sigma
      sq=1.0/sqrt(2*pi*sigma)
      pdos=0.0d0
      do k=1,Ndim
         if(Freq(k).gt.0.0) then
            dw=w-Freq(k)
            s=EigV(j,k)**2+EigV(j+1,k)**2+EigV(j+2,k)**2
            pdos=pdos+exp(-dw*dw/(2*sg2))*sq*s
         end if
      end do
      return
      end function

      real(8) function I_of_w(w,Ndim,Freq,sigma,Temp, &
                                    Q,Atom_Mass,I_of_w_aver,Dir,Pol)
!....................................................................
!  calculates I(w) (arb units) at w (units: cm^-1)
!....................................................................
      use real8
      use matrix
      use atom_info
      implicit none
      real(8),intent(in):: Freq(Ndim),Atom_Mass(N0LT)
      real(8),intent(in):: Q(3,3,N0LT)
      real(8),parameter :: K_B=8.617343e-5       ! in eV/K
      real(8),parameter :: H_bar=4.13566733e-15  ! in eV*sec
      real(8),parameter :: tiny=0.001d0
      real(8) :: Lorenz,Dir(3),Pol(3)
      character :: I_of_w_aver*9
!
      integer :: Ndim,j
      real(8) :: w,Temp,sigma,xa,omega,ex,Ph_popul,dwM,dwP,g1,g2
      real(8) :: ss,Pref_Iw

      I_of_w=0.0d0
      do j=1,Ndim
         if(Freq(j).gt.tiny) then

!
!____________ prefactor depending on the method: the given direction of E (Pol)
!             or, if averaged, the direction of propagation (Dir), or
!             yet different if for complete averaging

            xa=Pref_Iw(j,Ndim,Q,Atom_Mass,I_of_w_aver,Dir,Pol,.false.) 


!____________ Bose-Einstein population for each phonon mode, frequencies
!             are in sec^-1

            omega=sqrt( EigR(j)*.9648667e+28 )
            ex=H_bar*omega/ (K_B*Temp)
            Ph_popul=1.0d0/(exp(ex)-1.0)
!            write(*,'(i3,5(x,e12.6))') j,Ph_popul

!____________ lorenzians at w+w(Ph) and w-w(Ph), frequencies are in cm^-1;
!             in fact, the Lorenzian at w+w(Ph) is small, but I leave it in
!             anyway

            dwM= w-Freq(j)
            dwP= w+Freq(j)
            g1=Lorenz(dwM,sigma)
            g2=Lorenz(dwP,sigma)
            ss=( (1.0+Ph_popul)*g1+ Ph_popul*g2 )/Freq(j)
!            write(*,'(5(x,e12.6))') dwM,dwP,sig,ss,xa

!____________ summing up over modes

            I_of_w=I_of_w + xa*ss

         end if
      end do
!      I_of_w=I_of_w/(4*pi)
      return
      end function

      real(8) function Lorenz(x,sigma)
!.......... lorenzian at x with the width sigma
      use real8
      implicit none
!
      real(8) :: sigma,x

      lorenz=(sigma/pi)/(x*x+sigma*sigma)
      return
      end function

      real(8) function &
           Pref_Iw(j,Ndim,Q,Atom_Mass,I_of_w_aver,Dir,Pol,verb)
!................................................................
! prefactors for the I(w) due to the given eigenvalue j
!................................................................
      use real8
      use matrix
      use atom_info
      implicit none
      real(8),intent(in) :: Q(3,3,N0LT),Atom_Mass(N0LT)
      real(8) :: x(3),Dir(3),Pol(3),xA(3),xA_perp(3)
      character :: I_of_w_aver*9
      logical :: verb
!
      integer :: k,nat,j,Ndim,i1
      real(8) :: aa,sin_teta,sin2,s,freq

!________________ loop over atoms via degrees of freedom: k,k+1,k+2 correspond
!                 to x,y,z of the atom nat=at_info(k)

      if(verb) then
         write(*,'(a)')'========== Calculating prefactors ==========='
         write(*,'(a,i3)')'Vibrational mode ',j
      end if
      x(1)=0.0
      x(2)=0.0
      x(3)=0.0
      do k=1,Ndim,3
         nat=old_atom_from_vibr(k)
         xA(1)=Q(1,1,nat)*EigV(k,j)+Q(1,2,nat)*EigV(k+1,j)+ &
                                         Q(1,3,nat)*EigV(k+2,j)
         xA(2)=Q(2,1,nat)*EigV(k,j)+Q(2,2,nat)*EigV(k+1,j)+ &
                                         Q(2,3,nat)*EigV(k+2,j)
         xA(3)=Q(3,1,nat)*EigV(k,j)+Q(3,2,nat)*EigV(k+1,j)+ &
                                         Q(3,3,nat)*EigV(k+2,j)
         if(verb) then
            write(*,'(a,i5,a,3(f10.5,x),a,f10.5)') &
                    'Atom ',nat,' tau = (',(xA(i1),i1=1,3), &
                         '), m_pref= ', 1.0/sqrt(Atom_mass(nat))
         end if
         if(I_of_w_aver.eq.'  no_aver') then
            x(1:3)=x(1:3)+xA(1:3)/sqrt(Atom_mass(nat))
         else if(I_of_w_aver.eq.' pol_aver') then
            s=xA(1)*Dir(1)+xA(2)*Dir(2)+xA(3)*Dir(3)
            xA_perp(1:3)=xA(1:3)-s*Dir(1:3)
            x(1:3)=x(1:3)+xA_perp(1:3)/sqrt(Atom_mass(nat))
         else if(I_of_w_aver.eq.'zpol_aver') then
            x(1:3)=x(1:3)+xA(1:3)/sqrt(Atom_mass(nat))
         else if(I_of_w_aver.eq.'full_aver') then
            x(1:3)=x(1:3)+xA(1:3)/sqrt(Atom_mass(nat))
         end if
      end do
      if(I_of_w_aver.eq.'  no_aver') then
         s=x(1)*Pol(1)+x(2)*Pol(2)+x(3)*Pol(3)
         aa=s*s
      else if(I_of_w_aver.eq.' pol_aver') then
         aa=(x(1)*x(1)+x(2)*x(2)+x(3)*x(3))/2.0
      else if(I_of_w_aver.eq.'zpol_aver') then
         sin_teta=sin(Dir(1))
         sin2=sin_teta*sin_teta
         aa=(x(1)*x(1)+x(2)*x(2))*(1.0-0.5*sin2)+x(3)*x(3)*sin2
      else if(I_of_w_aver.eq.'full_aver') then
         aa=(x(1)*x(1)+x(2)*x(2)+x(3)*x(3))/3.0
      end if
      if(verb) then
         write(*,'(a,3(f10.5,x))')'Final vector = ',(x(i1),i1=1,3)
         write(*,'(a,f10.5)')'prefactor = ',aa
      end if
!
!...... final claculation of the prefactors
!
!      freq =sqrt( EigR(j)*.9648667e+28 )*53.08837459E-13
      freq =sqrt( EigR(j) )
      Pref_Iw=aa * freq**3
      end function

      subroutine dump_orb_xyz(YES_xyz,Add_Hs)
!................................................................
! write geom.xyz file for XMOL
!................................................................
      use real8
      use tetrag1
      use symgenv
      implicit none
      character :: YES_xyz*4
      real(8) :: x(3),RR(MG0,3)
      logical :: Err,Add_Hs
!
      integer :: nnn,nt,io,is,iN,mendl,j

!__________ open xyz file

      open(37,file='geom.xyz',form='formatted',status='unknown')
      nnn=ITI
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(37,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(37,'(a/i5)') '1',nnn
      end if

!___________ write all atoms

      nt=0
      do io=1,NORB
         is=ISORT1(io)
         call check_Mendel(Species(is),mendl,Err,.false.)
         x(1:3)=R1(io,1:3)
         call pvrt0(x,RR,Nnn)
         do iN=1,KAN(io)
            nt=nt+1
            if(YES_xyz.eq.'Xmol') then
               write(37,'(a2,5x,3(f16.10,1x),a)') &
                    Species(is),(RR(iN,j),j=1,3)
!     &              Species(is),(RR(iN,j),j=1,3),' 0 0 0'
            else if(YES_xyz.eq.'Ymol') then
               write(37,'(i2,5x,3(f16.10,1x))') &
                    mendl,(RR(iN,j),j=1,3)
            end if
         end do
      end do

      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(37,'(a)')'2     0.0 0.0 0.0  '
         write(37,'(a)')'3     15.0 0.0 0.0 '
         write(37,'(a)')'4     0.0 15.0 0.0 '
         write(37,'(a)')'5     0.0 0.0 15.0 '
      end if
      close (37)
      return
      end subroutine dump_orb_xyz

      subroutine calculate_freq(Ndim,Freq,Atom_Mass,prod_freq_log)
!............................................................................
! calculate frequencies from the force-constant matrix G_mat
!............................................................................
      use real8
      use matrix
      use atom_info
      implicit none

      real(8) :: Freq(Ndim),Atom_Mass(N0LT)
      real(8),parameter :: tiny=0.00001
!
      integer :: j,Ndim,nat,nat1,j1,k
      real(8) :: am,prod_freq_log

      do j=1,Ndim
         nat=at_info(j)
         do j1=j,Ndim
            nat1=at_info(j1)
            am=Atom_Mass(nat)*Atom_Mass(nat1)
            F_mat(j,j1)=G_mat(j,j1)/sqrt(am)
            F_mat(j1,j)=F_mat(j,j1)
         end do
      end do

!_________  and diagonalise it
      allocate(Work(Ndim))
      call diag(F_mat,Work,EigR,EigV,Ndim,Ndim)
      deallocate(Work)
      
!_________ eigenvalues EigR() are in [eV/(a.u.m.*A^2)];
!          change sqrt(EigR) into cm^-1, these will be frequencies (=Freq);
!          also, take product of frequencies (except for the imaginary ones,
!          if exist)

      prod_freq_log=0.0d0
      do k=1,Ndim
         if(EigR(k).ge.tiny) then
            Freq(k)=sqrt( EigR(k)*.9648667d+28 )*53.08837459d-13
            prod_freq_log=prod_freq_log + dlog(Freq(k))
         else
            Freq(k)=-1.0d0
         end if
      end do
      end subroutine calculate_freq
