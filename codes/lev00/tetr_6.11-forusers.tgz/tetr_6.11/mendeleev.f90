module mendeleev
implicit none

!
!............. Mendeleev's table of the first 82 elements
      character :: NAZV(112)*2
      data NAZV/' H','He', &
           'Li','Be',' B',' C',' N',' O',' F','Ne', &
           'Na','Mg','Al','Si',' P',' S','Cl','Ar', &
           ' K','Ca','Sc','Ti',' V','Cr','Mn','Fe','Co','Ni','Cu', &
                'Zn','Ga','Ge','As','Se','Br','Kr', &
           'Rb','Sr',' Y','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag', &
                'Cd','In','Sn','Sb','Te',' I','Xe', &
          'Cs','Ba', 'La','Ce','Pr','Nd','Pm','Sm','Eu','Gd','Tb', &
                 'Dy','Ho','Er','Tm','Yb','Lu', &
           'Hf','Ta',' W','Re','Os','Ir','Pt','Au','Hg','Tl','Pb', &
                 'Bi','Po','At','Rn', &
           'Fr','Ra', &
           'Ac','Th','Pa',' U','Np','Pu','Am','Cm','Bk','Cf','Es', &
                 'Fm','Md','No','Lr', &
                    'Rf','Db','Sg','Bh','Hs','Mt','Ds','Rg','Cn'/

!
!............. atomic masses in the same order (in a.u.m.)
      real(8) ::  At_Masses(112)
!                       H      He
      data At_Masses/1.00797,4.0026, &
!       Li     Be       B       C        N        O        F       Ne 
      6.941, 9.0122, 10.811, 12.01115,14.0067, 15.9994, 18.9984, 20.183, &
!       Na        Mg      Al      Si      P        S      Cl      Ar 
      22.9898, 24.312, 26.9815, 28.086, 30.9738, 32.064, 35.453, 39.948, &
!       K       Ca     Sc      Ti     V       Cr      Mn     Fe 
      39.102, 40.08, 44.956, 47.90, 50.942, 51.996, 54.938, 55.847, &
!       Co       Ni      Cu     Zn     Ga    Ge     As    Se      Br 
      58.9332, 58.71, 63.54, 65.37, 69.72, 72.59, 74.92, 78.96, 79.91, &
!       Kr   Rb      Sr     Y      Zr     Nb     Mo    Tc      Ru 
      83.8, 85.47, 87.62, 88.905, 91.22, 92.91, 95.94, 99.0, 101.07, &
!           Rh      Pd &
          102.91, 106.4, &
!     Ag       Cd     In       Sn      Sb      Te     I       Xe 
      107.87, 112.4, 114.82, 118.69, 121.75, 127.60, 126.9, 131.3, &
!            Cs     Ba &
          132.91, 137.34, &
!        La     Ce      Pr      Nd      Pm    Sm       Eu      Gd 
      138.91, 140.12, 140.91, 144.24, 145.0, 150.35, 151.96, 157.25, &
!            Tb 
            158.92, &
!       Dy     Ho      Er     Tm       Yb     Lu 
      162.5, 164.93, 167.26, 168.93, 173.04, 174.97, &
!       Hf      Ta     W       Re     Os     Ir     Pt      Au 
      178.49, 180.95, 183.85, 186.2, 190.2, 192.2, 195.09, 196.97, &
!         Hg       Tl 
          200.59, 204.37, &
!       Pb      Bi     Po     At     Rn     Fr     Ra 
      207.19, 208.98, 210.0, 210.0, 222.0, 223.0, 226.05, &
!       Ac     Th      Pa     U      Np 
      227.0, 232.04, 231.0, 238.03, 237.0, &
!       Pu    Am     Cm     Bk     Cf     Es     Fm    Md    No   Lr 
      242.0, 243.0, 247.0, 249.0, 251.0, 254.0, 253., 256., 253., 257., &
!       Rf    Db    Sg    Bh    Hs    Mt    Ds    Rg    Cn &
      9*0.0/
end module mendeleev
