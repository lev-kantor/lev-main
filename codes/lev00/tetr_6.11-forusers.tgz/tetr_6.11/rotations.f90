      subroutine specify_angle(cntp,C_rot)
!...................................................................
! specify rotation and the central point cntp()
!...................................................................
! order = 'Rot' - rotation
! order = 'Flp' - flipping in a plane (i.e. rotation by 180 degrees
!                 around an axis within a plane)
!...................................................................
      use real8
      implicit none
      character :: cha2*2,order*3
      character*12 :: angstr='<AtomNumber>'
      character*11 :: units='    degrees'
      real(8) :: cntp(3)
      real(8) :: rn(3),x1(3),x2(3),x3(3),rn1(3),C_rot(3,3),w_rot(3)
      real(8),parameter :: tiny=0.000001d0
!
      integer :: l0,j,i
      real(8) :: angle,ww,angle1

      angle=0.0 ; cntp=0.0 ; order='   ' ; w_rot=0.0

!___________ specify the angles of rotation and the central point

 21   write(*,'(a)') &
      '----------------------------------------------------------------'
      write(*,'(/a)') &
      '------ METHOD 1: general rotation around unit vector  ----------'
      write(*,'(a)') '       ^^^^^^^^  '
      ww=abs( sqrt(w_rot(1)**2 + w_rot(2)**2 + w_rot(3)**2) - 1.0 )
      if(ww.gt.tiny) then
         write(*,'(3(a,f10.5),a)')' Rd. Rotation axis <== undefined'
      else
         write(*,'(3(a,f10.5),a)') &
         ' Rd. Rotation axis: (',w_rot(1),',',w_rot(2),',',w_rot(3),')'
         if(order.eq.'Rot') then
            write(*,'(a,f10.5,a)') &
          ' Ra. Angle about unit vector => ',angle,' rad   <=== ACTIVE'
            write(*,'(5x,a)')'___________Rotation matrix:_____________'
            write(*,'(8x,3(f10.5,x))') (C_rot(1,j),j=1,3)
            write(*,'(8x,3(f10.5,x))') (C_rot(2,j),j=1,3)
            write(*,'(8x,3(f10.5,x))') (C_rot(3,j),j=1,3)
         else
            write(*,'(a,f10.5,a)') &
                 ' Ra. Angle about unit vector => ',angle,' rad'
         end if
      end if
!
      write(*,'(/a)') &
      '------ METHOD 2: by flipping in a plane (by 3 points) ----------'
      write(*,'(a)') &
       '       ^^^^^^^^  (e.g. flipping a molecule above a surface)'
      if(order.eq.'Flp') then
         write(*,'(a)') &
         ' Fl. Flipping with respect to a plane           <=== ACTIVE'
         write(*,'(5x,a,3(x,f10.5))') &
                  'Old plane normal: ', (rn(i),i=1,3)
         write(*,'(5x,a,3(x,f10.5))') &
                              'Rotation axis:   ', (w_rot(i),i=1,3)
         write(*,'(5x,a,f10.5,a)') &
                             'Rotation angle: ',angle1,' degrees'
         write(*,'(5x,a)')'___________Rotation matrix:_______________'
         write(*,'(8x,3(f10.5,x))') (C_rot(1,j),j=1,3)
         write(*,'(8x,3(f10.5,x))') (C_rot(2,j),j=1,3)
         write(*,'(8x,3(f10.5,x))') (C_rot(3,j),j=1,3)
         rn1(1)=C_rot(1,1)*rn(1)+C_rot(1,2)*rn(2)+C_rot(1,3)*rn(3)
         rn1(2)=C_rot(2,1)*rn(1)+C_rot(2,2)*rn(2)+C_rot(2,3)*rn(3)
         rn1(3)=C_rot(3,1)*rn(1)+C_rot(3,2)*rn(2)+C_rot(3,3)*rn(3)
         write(*,'(5x,a,3(x,f10.5))') &
                  'New plane normal: ', (rn1(i),i=1,3)
      else
         write(*,'(a)') ' Fl. Flipping with respect to a plane'
      end if


!_____ show settings
      write(*,'(/a)') &
      '-------------- g e n e r a l  s e t t i n g s ------------------'
      write(*,'(3(a,f10.5),a)') '  C. Point an the axis: (',cntp(1),',', &
                                        cntp(2),',',cntp(3),')'
      write(*,'(a)') &
           ' An. [For input] Coordinates are specified in: '//angstr
      write(*,'(a)') &
           ' Un. [For input] Angles are given in: '//units
      write(*,'(a)') &
      '----------------------------------------------------------------'
      write(*,'(a)') '  P. Done. Return back to the main menu!'
      write(*,'(a)') '  Q. ABORT: return to the main menu, DO NOTHING!'
      write(*,'(a)')
      write(*,'(a)')'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![An]...... choose the way the coordinates are given

      IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if

![Un]...... choose the way the angles are given

      ELSE IF(cha2(l0:).eq.'Un') THEN

         if(units.eq.'    radians') then
            units='    degrees'
         else if(units.eq.'    degrees') then
            units='Pi-fraction'
         else if(units.eq.'Pi-fraction') then
            units='    radians'
         end if

![Ra]...... specify the general angle of rotation around an arbitary axis
!           w_rot()

      ELSE IF(cha2(l0:).eq.'Ra' .and. ww.lt.tiny) THEN

 56      write(*,*)'Specify the angle in '//units//':'
         read(*,*,err=56) angle ; write(8,*) angle
         if(units.eq.'    degrees') then
            angle=angle*pi/180.0
         else if(units.eq.'Pi-fraction') then
            angle=angle*pi
         end if
         order='Rot'
         call gen_rot_mtrx(w_rot,C_rot,angle)

![Rd]...... specify the rotation axis (unit vector) w_rot()

      ELSE IF(cha2(l0:).eq.'Rd') THEN

         call ask_vector_rot(w_rot,cntp,angstr)
         order='   '

![Fl]...... specify 3 points for the plane to flip in this plane: we
!           specify a plane, and then choose the rotation axis within
!           the plane; after that the rotation matrix is calculated
!           assuming 180 degrees rotation (e.g. flipping a molecule
!           above a surface)

      ELSE IF(cha2(l0:).eq.'Fl') THEN

!___________ current normal rn()
         write(*,*)'Specify three points on the plane:'
         call normal_3points(x1,x2,x3,rn,angstr)
!___________ required position of the rotation axis within the plane
         call ask_vector_in_plane(w_rot,.true.,cntp,rn,angstr)
!___________ work out the whole rotation matrix C_rot(3,3)
         angle1=pi
         call gen_rot_mtrx(w_rot,C_rot,angle1)
         order='Flp'

![C]...... central position

      ELSE IF(cha2(l0:).eq.'C') THEN

         write(*,*)'Specify the central position in '//angstr
         call givepoint(cntp(1),cntp(2),cntp(3),angstr)

![P]...... normal return

      ELSE IF(cha2(l0:).eq.'P') THEN
         return

![Q]...... abort

      ELSE IF(cha2(l0:).eq.'Q') THEN

         C_rot=0.0 ; cntp=0.0
         C_rot(1,1)=1.0 ; C_rot(2,2)=1.0 ; C_rot(3,3)=1.0
      return
!
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine specify_angle

      subroutine rotate_atom(x,y,z,x1,y1,z1,cntp,C)
!.................................................................
! Carries out rotations of an atom  r=(x,y,z) to (x1,y1,z1)
! C      - rotation matrix
! cntp() - central point of the rotation
!.................................................................
      use real8
      implicit none
      real(8) :: cntp(3),C(3,3)
!
      real(8) :: x,y,z,x0,y0,z0,x1,y1,z1

!.... displace atom wrt the central position before the rotation
      x0=x-cntp(1) ; y0=y-cntp(2) ; z0=z-cntp(3)

!..................if Method=2: via the plane

      x1= C(1,1)*x0 + C(1,2)*y0 + C(1,3)*z0 + cntp(1)
      y1= C(2,1)*x0 + C(2,2)*y0 + C(2,3)*z0 + cntp(2)
      z1= C(3,1)*x0 + C(3,2)*y0 + C(3,3)*z0 + cntp(3)
      end subroutine rotate_atom

      subroutine rotate_system(AJ,AX)
!.................................................................
!     choose new direction of lattice vectors by keeping  their
!     mutual arrangement = rotate the system
!.................................................................
      use real8
      implicit none
      real(8) :: AJ(3,3),AL(3,3),AN(3),AX(3,3),third(3,3)
      real(8) :: C_rot(3,3),AJ1(3,3)
      character :: cha2*2
      real(8),parameter :: tiny=0.000001d0
!
      integer :: l0,i,i1,j1,j2,jj,j3,j
      real(8) :: x1,x2,ALn,delta,det,alpha,beta,ann,gama

      third=reshape((/0,3,2,3,0,1,2,1,0/),shape(third))

      AJ1=AJ
 21   write(*,'(a)')'[ROTATE THE SYSTEM]..... Choose the method:'
      write(*,'(a/)') ' ^^^^^^^^^^^^^^^^^'
      write(*,'(a)') '  1. New directions of 2 lattice vectors'
      write(*,'(a)') '  2. Rotate around origin by an angle'
      write(*,'(a)') '  P. Proceed with new lattice vectors'
      write(*,'(a/)')'  Q. Quit with the old vectors'
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

!
![1].... old method 'by new direction of 2 lattice vectors'
!
      IF(cha2(l0:).eq.'1') then

!___________ calculate scalar products
         do i=1,3
            do i1=1,3
               AL(i,i1)=AJ(i,1)*AJ(i1,1)+AJ(i,2)*AJ(i1,2)+ &
                    AJ(i,3)*AJ(i1,3)
            end do
         end do

 1       write(*,*)'...................................................'
         write(*,*)' Rotation of the coordinate system is specified by '
         write(*,*)' giving new directions for a pair of two primitive'
         write(*,*)' lattice vectors using existing coordinate system:'
         write(*,*)' MIND: the angle between them should be preserved!'
         write(*,*)'..................................................'
 35      write(*,*)'Which vectors (1, 2 or 1, 3 or 2, 3):'
         read(*,*,err=35) j1,j2 ; write(8,*) j1,j2
         if(j1.lt.0 .or. j1.gt.3 .or. j2.lt.0 .or. j2.gt.3 .or. &
                                                   j1.eq.j2) go to 35
 51      write(*,'(a36,i1,a10)') &
              'Give direction along lattice vector ',j1,' as x,y,z:'
         read(*,*,err=51) (AJ(j1,i),i=1,3)
         write(8,*) (AJ(j1,i),i=1,3)
 52      write(*,'(a36,i1,a10)') &
              'Give direction along lattice vector ',j2,' as x,y,z:'
         read(*,*,err=52) (AJ(j2,i),i=1,3)
         write(8,*) (AJ(j2,i),i=1,3)
!
!_________ give correct lengthes for vectors j1,j2
!
         x1=sqrt(AL(j1,j1))/sqrt(AJ(j1,1)**2+AJ(j1,2)**2+AJ(j1,3)**2)
         x2=sqrt(AL(j2,j2))/sqrt(AJ(j2,1)**2+AJ(j2,2)**2+AJ(j2,3)**2)
         AJ(j1,1:3)=AJ(j1,1:3)*x1 ; AJ(j2,1:3)=AJ(j2,1:3)*x2
!
!_________ check the angle between j1 and j2 by checking their scalar product
!
         ALn=AJ(j1,1)*AJ(j2,1)+AJ(j1,2)*AJ(j2,2)+AJ(j1,3)*AJ(j2,3)
         delta = abs(AL(j1,j2)-ALn)-tiny
         if(delta .gt. tiny) then
            write(*,*)'Error! Wrong direction by ',delta,' ! Try again!'
            write(*,*)'new 1 => ',(AJ(j1,jj),jj=1,3)
            write(*,*)'new 2 => ',(AJ(j2,jj),jj=1,3)
            write(*,*)'their dot product = ',ALn
            write(*,*)'        should be = ',AL(j1,j2)
            go to 51
         end if
!
!_________ find the correct 3rd vector, j3. It is represented in
!          the same way in the old case as in the new one via:
!          AJ(j3)=alpha*AJ(j1)+beta*AJ(j2)+gama*AN,
!          where AN is a normal vector to AJ(j1) and AJ(j2). Coefficients
!          alpha, beta and gama do not depend on the rotation.
!
         j3=third(j1,j2)
         det=AL(j1,j1)*AL(j2,j2)-AL(j1,j2)*AL(j1,j2)
         alpha=(AL(j1,j3)*AL(j2,j2)-AL(j1,j2)*AL(j2,j3))/det
         beta=(AL(j1,j1)*AL(j2,j3)-AL(j1,j3)*AL(j1,j2))/det
         AN(1)=AX(j1,2)*AX(j2,3)-AX(j1,3)*AX(j2,2)
         AN(2)=AX(j1,3)*AX(j2,1)-AX(j1,1)*AX(j2,3)
         AN(3)=AX(j1,1)*AX(j2,2)-AX(j1,2)*AX(j2,1)
         ann=AN(1)**2+AN(2)**2+AN(3)**2
         gama=(AX(j3,1)*AN(1)+AX(j3,2)*AN(2)+AX(j3,3)*AN(3))/ann
         AN(1)=AJ(j1,2)*AJ(j2,3)-AJ(j1,3)*AJ(j2,2)
         AN(2)=AJ(j1,3)*AJ(j2,1)-AJ(j1,1)*AJ(j2,3)
         AN(3)=AJ(j1,1)*AJ(j2,2)-AJ(j1,2)*AJ(j2,1)
         do i=1,3
            AJ(j3,i)=alpha*AJ(j1,i)+beta*AJ(j2,i)+gama*AN(i)
         end do
!
![2].... new method: rotation directly
!
      ELSE IF(cha2(l0:).eq.'2') then

         call specify_rot_matrix(C_rot)
         do j=1,3
            AL(j,1)=C_rot(1,1)*AJ(j,1)+C_rot(1,2)*AJ(j,2) + &
                                               C_rot(1,3)*AJ(j,3)
            AL(j,2)=C_rot(2,1)*AJ(j,1)+C_rot(2,2)*AJ(j,2) + &
                                               C_rot(2,3)*AJ(j,3)
            AL(j,3)=C_rot(3,1)*AJ(j,1)+C_rot(3,2)*AJ(j,2) + &
                                               C_rot(3,3)*AJ(j,3)
         end do
         AJ=AL
!
![P]....  quit
!
      ELSE IF(cha2(l0:).eq.'P') THEN
         return
!
![Q]....  quit
!
      ELSE IF(cha2(l0:).eq.'Q') THEN
         AJ=AJ1
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine rotate_system

      subroutine specify_rot_matrix(C_rot)
!...................................................................
! specify rotation matrix
!...................................................................
      use real8
      implicit none
      character :: cha2*2,order*3
      character*12 :: angstr='<AtomNumber>'
      character*11 :: units='    degrees'
      real(8) :: cntp(3)
      real(8) :: C_rot(3,3),w_rot(3)
      real(8),parameter :: tiny=0.000001
!
      integer :: j,l0
      real(8) :: angle,ww

      angle=0.0 ; w_rot=0.0

!___________ specify the angles of rotation

 21   write(*,'(a)') &
      '[SPECIFY ROTATIONAL MATRIX]-------------------------------------'
      write(*,'(a)') ' ^^^^^^^^^^^^^^^^^^^^^^^^^'
      ww=abs( sqrt(w_rot(1)**2 + w_rot(2)**2 + w_rot(3)**2) - 1.0 )
      if(ww.gt.tiny) then
         write(*,'(3(a,f10.5),a)')' Rd. Rotation axis <== undefined'
      else
         write(*,'(3(a,f10.5),a)') &
         ' Rd. Rotation axis: (',w_rot(1),',',w_rot(2),',',w_rot(3),')'
         if(order.eq.'Rot') then
            write(*,'(a,f10.5,a)') &
          ' Ra. Angle about unit vector => ',angle,' rad   <=== ACTIVE'
            write(*,'(5x,a)')'___________Rotation matrix:_____________'
            write(*,'(8x,3(f10.5,x))') (C_rot(1,j),j=1,3)
            write(*,'(8x,3(f10.5,x))') (C_rot(2,j),j=1,3)
            write(*,'(8x,3(f10.5,x))') (C_rot(3,j),j=1,3)
         else
            write(*,'(a,f10.5,a)') &
                 ' Ra. Angle about unit vector => ',angle,' rad'
         end if
      end if
!
!_____ show settings
      write(*,'(/a)') &
      '-------------- g e n e r a l  s e t t i n g s ------------------'
      write(*,'(a)') &
           ' An. [For input] Coordinates are specified in: '//angstr
      write(*,'(a)') &
           ' Un. [For input] Angles are given in: '//units
      write(*,'(a)') &
      '----------------------------------------------------------------'
      write(*,'(a)') '  P. Done. Return back to the main menu!'
      write(*,'(a)') '  Q. ABORT: return to the main menu, DO NOTHING!'
      write(*,'(a)')
      write(*,'(a)')'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![An]...... choose the way the coordinates are given

      IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if

![Un]...... choose the way the angles are given

      ELSE IF(cha2(l0:).eq.'Un') THEN

         if(units.eq.'    radians') then
            units='    degrees'
         else if(units.eq.'    degrees') then
            units='Pi-fraction'
         else if(units.eq.'Pi-fraction') then
            units='    radians'
         end if

![Ra]...... specify the general angle of rotation around an arbitary axis
!           w_rot()

      ELSE IF(cha2(l0:).eq.'Ra' .and. ww.lt.tiny) THEN

 56      write(*,*)'Specify the angle in '//units//':'
         read(*,*,err=56) angle ; write(8,*) angle
         if(units.eq.'    degrees') then
            angle=angle*pi/180.0
         else if(units.eq.'Pi-fraction') then
            angle=angle*pi
         end if
         order='Rot'
         call gen_rot_mtrx(w_rot,C_rot,angle)

![Rd]...... specify the rotation axis (unit vector) w_rot()

      ELSE IF(cha2(l0:).eq.'Rd') THEN

         call ask_vector_rot(w_rot,cntp,angstr)
         order='   '

![P]...... normal return

      ELSE IF(cha2(l0:).eq.'P') THEN
         return

![Q]...... abort

      ELSE IF(cha2(l0:).eq.'Q') THEN

         C_rot=0.0 ; C_rot(1,1)=1.0 ; C_rot(2,2)=1.0 ; C_rot(3,3)=1.0
         return
!
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine specify_rot_matrix

