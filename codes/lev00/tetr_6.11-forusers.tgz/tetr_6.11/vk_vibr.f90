module vk_vibr
use tetr_param
implicit none
!----------  For the Vk method specifically ------------
!
!  Prim_Ext_Cell(j1) - atom number of each primitive cell atom j1
!                      in the list of all atoms of the extended cell
!  TI1 - atomic positions in the primitive cell
!
!      common/vk_method/ TI1, &
!                        ITI_prim,MG_luc, &
!                        Prim_Ext_Cell
       integer :: Prim_Ext_Cell(N0LT),ITI_prim,MG_luc
       real(8) :: TI1(3,N0LT)




end module vk_vibr
