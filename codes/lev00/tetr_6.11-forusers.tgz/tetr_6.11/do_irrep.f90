       subroutine do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
!...............................................................
! IA - irrep
! ITI - total number of atoms in the system
! R1(orbit,xyz) - 1st atoms of orbits in the right order
! NORB - number of orbits
! N_cond - number of  translations/rotations conditions
! C_cond(yzx-component, Atom , condition number) - vectros of
!           conditions;
!_______ OUTPUT:
! IRALF(IA) - repetition number for the irrep IA
! IRA - number of linearly inependent symmetry-adapted vectors
!       (together with conditions!)
! W_all(yzx, A , F , irrep dim) -
!        - trasformation matrix for the whole system and
!          given irrep IA, where:
!
! yzx - component of atom A coordinate
!  F  - total repetition (over all orbits); it is attached to
!       conditions, i.e. actual displacements starts at iF=N_cond+1
!  A  - overall atomic index which runs orbit after orbit in the
!       correct order; inside every orbit it runs in the order
!       suggested by pvrt-like routines.
!...............................................................
      use real8
      use pgroup
      use symgenv
      use working
      implicit none
      real(8) :: C_cond(3,N0LT,6)
      integer :: IRA1(3)
      real(8) :: Work(K0DM0+6),R(3),BJ(3,3)
      character :: Species(N0KD)*2
!
      integer :: IA,ITI,IRA,N_Cond,iF,iN,k,j,iN1,I,iN2,iF1,iiN,NREP

      write(*,'(a,i2,a)') '===========> irrep = ',IA,' <=============='
!      write(9,'(a,i2,a)') '===========> irrep = ',IA,' <=============='
!
!............ put vectors of conditions to W_all as first vectors
!             (only row 1 is needed here; do it though for all for later use)
!
      if(N_Cond.gt.0) then

         do iF=1,N_cond
            do iN=1,ITI
               do k=1,3
                  do j=1,NALFA(IA)
                     W_all(k,iN,iF,j)=C_cond(k,iN,iF)
                  end do
               end do
            end do
         end do
!???????????
!         write(9,'(/a/)')
!     &        '>>>>>>>>> all vectors of conditions <<<<<<'
!         call show_W_all_matrix1(IA,N_Cond,Species,1,N_Cond,9)
!         call check_orth(W_all(1,1,1,1),K0DM0+6,N_Cond,3*ITI,3*N0LT)
!???????????
      end if
!
!......... do loop over orbits; the construction of all matrices is done
!          for each orbit separately;
!          we compute: transf. matrix W and NREP
!
      IRALF(IA)=0 ; iN1=1
      do I=1,NORB
         NREP=0
         if(.not.Fix(I)) then
            R(1:3)=R1(I,1:3)
            call VANJA(R,1,I,IA,NREP,BJ)
         end if
         iN2=iN1+KAN(I)-1
!
!______ compile the matrix W_all from W calculated for the given orbit I
!       iF - current overall repetition index (starting from N_Cond+1).
!       iN1 - 1st atom of the current orbit in the overall list of atoms
!       (Only elements belonging to the given orbit are non-zero)
!
         do iF=IRALF(IA)+1,IRALF(IA)+NREP
            if(iF.gt.K0DM0) &
                 stop 'ERROR! Increase K0DM0 in sym_par.inc'
            iF1=iF+N_Cond
            do j=1,NALFA(IA)
               do k=1,3
                  do iN=1,ITI
                     if(iN.ge.iN1.and.iN.le.iN2.and.(.not.Fix(I))) then
                        iiN=iN-iN1+1
                        W_all(k,iN,iF1,j)=W(j,iF-IRALF(IA),iiN,k)
                     else
                        W_all(k,iN,iF1,j)=0.0d0
                     end if
                  end do
               end do
            end do
         end do
         IRALF(IA)=IRALF(IA)+NREP

         iN1=iN2+1
      end do

!???????????
!      write(6,'(/a/)')
!     &     '>>>>>>>>> all vectors after VANJA, before orth. <<<<<<'
!      call show_W_all_matrix1(IA,N_Cond+IRALF(IA),Species,
!     ,     1,N_Cond+IRALF(IA),6)
!???????????
!
!........... exit if IRALF(IA)=0
!
      if(IRALF(IA).eq.0) then
         write(*,*)'WARNING! This irrep is not contained at all!'
         IRA=N_cond
         return
      end if
!
!.......... if IRALF(IA).ne.0, we orthogonalise W_all to
!           the rotational/translational conditions (if any)
!
![4]........ orthogonalise/normalise W_all (from N_Cond+1) to the vectors of
!            conditions (1,...,N_Cond) and between themselves.
!      IRA - the final number of linearly independent vectors (including
!            those of the conditions)
!
!   We may consider only the 1st row of every irrep, since this is sufficient
!   for calculating frequencies and thus necessary atomic displacmenets.
!   However, since the other rows are needed, e.g. for constructing vibrations
!   themselves, which can be done at the stage of the solution of the dynamical
!   problem, we obtain diaplacement vectors for each row separately (although
!   the transformation does not depend on the row index) for the later use.
!
      do j=1,NALFA(IA)
         call ortho_norm(W_all(1,1,1,j),K0DM0+6,IRA,N_cond+IRALF(IA), &
                            3*ITI,3*N0LT,Work,N_cond)
         write(*,'(a,i1,a,i5)') 'row = ',j,', vectors left = ',IRA
         IRA1(j)=IRA
         if(j.gt.1) then
            if(IRA1(j).ne.IRA1(j-1)) then
               write(*,*) &
                    'FATAL error in do_irrep (diffr result for rows)'
               write(*,'(a,i2,a,3(i2,x))') &
                 'error for IA= ',IA,' IRA = ',(IRA1(i),i=1,IRALF(IA))
               stop
            end if
         end if
      end do
      IRA=IRA1(1)

!???????????
!      write(6,'(/a/)')
!     &     '>>>>>>>>> all vectors after VANJA and orthog. <<<<<<'
!      call show_W_all_matrix1(IA,IRA,Species,1,IRA,6)
!      call check_orth(W_all(1,1,1,1),K0DM0+6,IRA,3*ITI,3*N0LT)
!???????????

      if(IRA-N_cond.eq.0) then
         write(6,*)'RESULT: no vectors left for this irrep !!!'
         return
      else
         write(6,'(a23,i5)')'RESULT: vectors left = ',IRA-N_cond
      end if
      return
      end subroutine do_irrep

      subroutine write_G_matrix(IA,IRA,N_Cond,AtMass)
!..................................................................
! Construct the G-matrix for the given irrep IA and save it into
! a file G_{irrep number}.mat
!
!______ INPUT:
!      IA - irrep
!      IRA - # of lineraly independent vectors (incl. conditions)
!   N_Cond - # of transl.-rotat. conditions
!..................................................................
      use real8
      use symgenv
      use working
      implicit none
      real(8) :: AtMass(N0KD)
      character :: cha1,cha2*2
!
      integer :: IA,IRA,N_Cond,iF,iFi,iF1,iFi1,is,k,iOrb,iN,nat
      real(8) :: s
!
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (23,file='G_'//cha1//'.mat',form='formatted')
      else
         write(cha2,'(i2)') IA
         open (23,file='G_'//cha2//'.mat',form='formatted')
      end if
      do iF=N_cond+1,IRA
         iFi=iF-N_cond
         do iF1=N_cond+1,IRA
            iFi1=iF1-N_cond

            s=0.0d0
            iN=0
            do iOrb=1,NORB
               is=ISORT1(iOrb)
               do nat=1,KAN(iOrb)
                  iN=iN+1
                  do k=1,3
                     s=s+W_all(k,iN,iF,1)*W_all(k,iN,iF1,1)/AtMass(is)
                  end do
               end do
            end do

            write(23,*) iFi, iFi1, s
         end do
      end do
      close (23)
      return
      end subroutine write_G_matrix

      subroutine show_W_all_matrix1(IA,IRA,Species,I1,I2,unit)
!.............................................................
! nice print of the symmetry-adapted displacements I1,...,I2
! IA     - given irrep
! IRA    - total number of linearly independent vectors
!
!.............................................................
!    At the same time, the vectors are written into a file
! Vector_IA.dat for future reference.
!.............................................................
      use real8
      use pgroup
      use symgenv
      use working
      implicit none
      real(8) :: RR(MG0,3),RA(3)
      integer :: rep,unit
      character,dimension(3) :: a=(/'y','z','x'/)
      character :: Species(N0KD)*2
      integer,dimension(3) :: kk=(/2,3,1/)
!
      integer :: IA,IRA,I1,I2,iN,iOrb,is,Nnn,nat,k,i,j

      if(I1.lt.0 .or. I1.gt.I2 .or. I2.gt.IRA) stop 'error in show_W'
!
!........... write on the scree/file
!
      write(unit,'(a/)') &
           '********** symmetry-adapted displacements ***********'
      write(unit,'(20x,a)') '<---(repetition,row)--->'
      write(unit,'(2x,a,20(3x,a,i2,a,i1,a,2x))') &
           '     atom#   x/y/z   ', &
               (('(',rep,',',i,')',i=1,NALFA(IA)),rep=I1,I2)
      iN=0
      do iOrb=1,NORB
         RA(1:3)=R1(iOrb,1:3)
         is=ISORT1(iOrb)
         call PVRT0(RA,RR,Nnn)
         do nat=1,Nnn
            iN=iN+1
            do i=1,3
               k=kk(i)
               write(unit,'(a,x,i5,a,20(x,f10.5))') &
                    Species(is),iN,a(i),RR(nat,k), &
                 ((W_all(i,iN,rep,j),j=1,NALFA(IA)),rep=I1,I2)
            end do
         end do
         write(unit,*) &
              '---------------------------------------------------'
      end do
      return
      end subroutine show_W_all_matrix1

      subroutine READGR(KodErr,unit)
!....................................................................
! This program read file 'SYMGRP.REP' with all attributes of given
! point group
!....................................................................
      use real8
      use pgroup
      use whereis
      implicit none
      character :: GN1*3,GN*3,int*5,int1*5
      integer :: unit
!
      integer :: KodErr,K2,K3,J,K1,K,L

      KodErr=0
      open(unit=3,file=tetr_dir(tetr_l0:)//'/symgrp.rep', &
           status='old', err=102)
 20   READ(unit,'(a3)',END=2000) GN
      if(GN.ne.GROUPN) go to 20
 21   READ(unit,'(a3)',END=2000) GN1
      IF(GN1.NE.'***') GO TO 21
      READ(unit,'(24i4)') MG,NEPR,K2,K3
      READ(unit,'(24i4)') (NALFA(J),J=1,NEPR)
      READ(3,'(24i4)') (ICMPL(J),J=1,NEPR)
      if(MG.gt.MG0) go to 50
      if(NEPR.gt.N0IR) go to 51
      if(K2.gt.N0IR2) go to 52
      if(K3.gt.N0IR3) go to 53
      READ(unit,'(a3)') GN1
      K1=NEPR-K2-K3
      do K=1,K1
         read(unit,'(a3)') NAZVIR(K)
         read(unit,'(12X,24F10.7)') (XX(K,L),L=1,MG)
      end do
      READ (unit,'(a3)') GN1
      DO K=1,K2
         READ(unit,'(a3)') NAZVIR(K1+K)
         READ(unit,'(12X,24F10.7)') (D2ALFA(1,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D2ALFA(2,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D2ALFA(1,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D2ALFA(2,2,L,K),L=1,MG)
         DO L=1,MG
            XX(K1+K,L)=D2ALFA(1,1,L,K)+D2ALFA(2,2,L,K)
         END DO
      END DO
      READ (unit,'(a3)')GN1
      DO K=1,K3
         READ(unit,'(a3)') NAZVIR(K1+K2+K)
         READ(unit,'(12X,24F10.7)') (D3ALFA(1,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(2,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(3,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(1,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(2,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(3,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(1,3,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(2,3,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(3,3,L,K),L=1,MG)
         DO L=1,MG
            XX(K1+K2+K,L)=D3ALFA(1,1,L,K)+D3ALFA(2,2,L,K) &
                 +D3ALFA(3,3,L,K)
         END DO
      END DO
      close (unit)
      return
!........... error messages......................................
 102  write(*,*)'FATAL! Open file error symgrp.rep !!! '
      KodErr=1
      return
!__________ check for MG
 50   WRITE(int,300)MG
      WRITE(int1,300)MG0
 300  FORMAT(I5)
      write(*,*)'FATAL! Point group '//GN//' has MG= '//int// &
           ' > then MG0= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      return
!___________check for NEPR
 51   WRITE(int,300) NEPR
      WRITE(int1,300) N0IR
      write(*,*)'FATAL! Point group '//GN//' has NEPR= '//int// &
           ' > then N0IR= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      RETURN
!___________check K2
 52   WRITE(int,300) K2
      WRITE(int1,300) N0IR2
      write(*,*)'FATAL! Point group '//GN//' has K2= '//int// &
           ' > then N0IR2= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      RETURN
!____________check  K3
 53   WRITE(int,300) K3
      WRITE(int1,300) N0IR3
      write(*,*)'FATAL! Point group '//GN//' has K3= '//int// &
           ' > then N0IR3= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      RETURN
!.................if the group GN has nor been found at all
 2000 write(*,*)'*readgr* FATAL!!!   The group ' &
           //GROUPN//' has not been found in SYMGRP.REP file'
      CLOSE(unit)
      KodErr=1
      RETURN
      end subroutine READGR

      subroutine irina(TI,Nsp,NspN,BJ,Err)
!.......................................................................
!   Nsp        - number of species
!   NspN(is)   - number of atoms in each species is
!   TI(xyz,at) - coordinates of all atoms in the system
!....... OUTPUT:
!   NORB        - number of orbits
!   KAN(orb)    - number of atoms in the orbit
!   R1(orb,xyz) - coordinates of the 1st atom of the orbit
!.......................................................................
      use real8
      use pgroup
      use symgenv
      use systema
      implicit none
      real(8) :: RA(3),RRR(MG0,3),RL(3),TI(3,N0LT),BJ(3,3)
      logical :: Err,ask_equiv
      integer :: NspN(N0KD)
      real(8),parameter :: tiny=0.0001d0
!
      integer :: NAT1,Nsp,iOrb,iAt,is,in,I1,NAT,N1,number_of_atom
      real(8) :: AR
!
!........  Choose orbits iOrb in a loop over all atoms
!
      NAT1=0 ; iOrb=0 ; iAt=0
      do is=1,Nsp
         do in=1,NspN(is)
            iAt=iAt+1
            RA(1:3)=TI(1:3,iAt)
            if(iAt.eq.1) go to 6

!___________ checking if RA is in already existing orbits
            do I1=1,iOrb
               RL(1:3)=R1(I1,1:3)
               call PVRT0(RL,RRR,N1)
               do NAT=1,N1
                  RL(1:3)=RRR(NAT,1:3)-RA(1:3)
                  if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA')then
                     if(ask_equiv(RL,BJ,3,tiny)) go to 1
                  else
                     AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
                     if(AR.lt.tiny) go to 1
                  end if
               end do
            end do

!.........Construction of the new orbit (all rotations)
 6          CALL PVRT0(RA,RRR,N1)
            NAT1=NAT1+N1 ; iOrb=iOrb+1
            KAN(iOrb)=N1 ; ISORT1(iOrb)=is
            R1(iOrb,1:3)=RA(1:3)
            do nat=1,N1
               RL(1:3)=RRR(nat,1:3)
               orb_to_old(iOrb,nat)=number_of_atom(RL,Err)
               if(Err) then
                  write(*,*) 'ERROR: inconsistency in IRINA' ; return
               end if
            end do
 1       end do
      end do
!....... set the number of orbits and check the total number of atoms
      NORB=iOrb
      if(NAT1.ne.iAt) then
         write(*,*)'ERROR! IRINA: wrong coordinates/group!'
         Err=.true.
      end if
      end subroutine irina

      integer function number_of_atom(x,Err)
!..................................................................
!  gives the atom number in the list TI from the point x
!..................................................................
      use real8
      use tetrag1
      use systema
      implicit none
      real(8) :: x(3),rl(3)
      logical :: Err,ask_equiv
!
      integer :: nat
      real(8) :: ar

      do nat=1,ITI
         rl(1:3)=x(1:3)-TI(1:3,nat)
         if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA') then
            if(ask_equiv(RL,BJ,3,tiny_equiv)) go to 1
         else
            ar=rl(1)*rl(1)+rl(2)*rl(2)+rl(3)*rl(3)
            if(AR.lt.tiny_equiv) go to 1
         end if
      end do
      Err=.true.
      return
 1    number_of_atom=nat
      Err=.false.
      return
      end function number_of_atom
