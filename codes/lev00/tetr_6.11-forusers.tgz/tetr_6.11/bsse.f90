      subroutine BSSE_script(Which_Code)
!...................................................................
! generate BSSE script + do the electron density if needed
!...................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      character :: cha5*5,answer,Which_Code*6
      logical :: Diff_D
!
      integer :: im,lc
!
!............. create directory structure and write input files
!
      write(*,*)'... creating directory BSSE'

!_________ ask about whether to save the density of each individual part
      Diff_D=.false.
      write(*,*)'Do you want to save the electron density of each part'
      write(*,*)'for the density difference plots (y/other)?'
      read(*,'(a)') answer ; write(8,'(a)') answer
      if(answer.eq.'y' .or. answer.eq.'Y') Diff_D=.true.
!
!_________ do the directory structure + input files
      call system('mkdir BSSE')
      do im=1,iMol
         write(cha5,'(i5)') im
         do lc=1,5
            if(cha5(lc:lc).ne.' ') go to 1
         end do
 1       write(*,*)'... creating directory BSSE/'//cha5(lc:)
         call system('mkdir BSSE/'//cha5(lc:))
         if(Which_Code.eq.'SIESTA') THEN
            write(*,*)'... writing BSSE/'//cha5(lc:)//'/INPUT_FILE.fdf'
            call write_SIESTA_part_noghost(im,cha5,lc,Diff_D,0)
         else if(Which_Code.eq.'QUICKS') THEN
            write(*,*)'... writing BSSE/'//cha5(lc:)//'/cp2k.inp'
            call write_CP2K_part_noghost(im,cha5,lc,Diff_D,0)
         end if
         write(*,*)'... creating directory BSSE/'//cha5(lc:)//'-ghost'
         call system('mkdir BSSE/'//cha5(lc:)//'-ghost')
         if(Which_Code.eq.'SIESTA') THEN
            write(*,*) &
              '... writing BSSE/'//cha5(lc:)//'-ghost/INPUT_FILE.fdf'
            call write_SIESTA_part_ghost(im,cha5,lc)
         else if(Which_Code.eq.'QUICKS') THEN
            write(*,*) &
              '... writing BSSE/'//cha5(lc:)//'-ghost/cp2k.inp'
            call write_CP2K_part_ghost(im,cha5,lc)
         end if
      end do
!
!............. writing the BSSE script
!
      open(32,file='BSSE_script.run',status='unknown')
      write(32,'(a/)') '#! /bin/csh'
      write(32,'(a)') "echo '#..... BSSE calculation ..."// &
           "....................' > BSSE_info"
      write(32,'(a)') "echo '################"// &
                        "###############################' >> BSSE_info"
      if(Which_Code.eq.'SIESTA') THEN
         write(32,'(a//a/a/a/a/)') 'if ( -e INPUT_FILE.fdf ) '// &
              '/bin/mv INPUT_FILE.fdf INPUT_FILE_orig.fdf', &
              'set fin=0', &
              '#','#................. loop over partitions','#'
      else if(Which_Code.eq.'QUICKS') THEN
         write(32,'(a//a/a/a/a/)') 'if ( -e cp2k.inp ) '// &
              '/bin/mv cp2k.inp cp2k_orig.inp', &
              'set fin=0', &
              '#','#................. loop over partitions','#'
      end if
      write(cha5,'(i5)') iMol
      do lc=1,5
         if(cha5(lc:lc).ne.' ') go to 2
      end do
 2    write(32,'(a,'//cha5(lc:)//'(x,i3),a/)') &
                                   'foreach part ( ',(im,im=1,iMol),' )'
      write(32,'(a)') "echo '#______ Partition'"// &
           " $part '____________________________' >> BSSE_info"
      write(32,'(a/a/a)') '#','#[1]... without ghost orbitals','#'

      if(Which_Code.eq.'SIESTA') THEN
         write(32,'(3x,a)') '/bin/cp BSSE/$part/INPUT_FILE.fdf .'
         write(32,'(3x,a)') 'siesta |tee OUTCAR'
         write(32,'(3(3x,a/))') "awk 'BEGIN {n1=-100}"//char(92), &
              "   /Final energy/ {n1=NR}"//char(92), &
              "   NR == n1 + 8  { f=$4; print f } ' OUTCAR > tmp"
         write(32,'(3x,a)') 'set en1=`cat tmp`'
      else if(Which_Code.eq.'QUICKS') THEN
         write(32,'(3x,a)') '/bin/cp BSSE/$part/cp2k.inp .'
         write(32,'(3x,a)') 'cp2k |tee OUTCAR'
         write(32,'(3x,a)') "set a=`grep 'ENERGY|' OUTCAR `"
         write(32,'(3x,a)') 'set en1=$a[$#a]'
      end if

      write(32,'(a)') &
        "   echo '# energy without ghost orbitals = ' $en1 >> BSSE_info"
      write(32,'(3x,a)') '/bin/mv OUTCAR BSSE/$part/.'
      if(Diff_D) then
         if(Which_Code.eq.'SIESTA') THEN
            write(32,'(3x,a)') &
                 '/bin/mv '//SystemLabel(isysl0:)//'.RHO  BSSE/$part/.'
         else if(Which_Code.eq.'QUICKS') THEN
            write(32,'(3x,a)') &
                 '/bin/mv A-ELECTRON_DENSITY-1_0.cube  BSSE/$part/.'
         end if
      end if
!
      write(32,'(a/a/a)') '#','#[2]... with ghost orbitals','#'
      if(Which_Code.eq.'SIESTA') THEN
         write(32,'(3x,a)') '/bin/cp BSSE/$part-ghost/INPUT_FILE.fdf .'
         write(32,'(3x,a)') 'siesta |tee OUTCAR'
         write(32,'(3(3x,a/),/3x,a)') "awk 'BEGIN {n1=-100}"//char(92), &
              '   /Final energy/ {n1=NR}'//char(92), &
              "   NR == n1 + 8  { f=$4; print f } ' OUTCAR > tmp", &
              'set en2=`cat tmp`'
      else if(Which_Code.eq.'QUICKS') THEN
         write(32,'(3x,a)') '/bin/cp BSSE/$part-ghost/cp2k.inp .'
         write(32,'(3x,a)') 'cp2k |tee OUTCAR'
         write(32,'(3x,a)') "set a=`grep 'ENERGY|' OUTCAR `"
         write(32,'(3x,a)') 'set en2=$a[$#a]'
      end if

      write(32,'(a)') &
        "   echo '# energy with ghost orbitals    = ' $en2 >> BSSE_info"
      write(32,'(3x,a)') '/bin/mv OUTCAR BSSE/$part-ghost/.'
!
      write(32,'(a/a/a)') '#','#[3]... calculation','#'
      write(32,'(a/a/a/a/)') '   echo > null'
      if(Which_Code.eq.'SIESTA') then
         write(32,'(a)') &
        "   awk 'BEGIN { e=('$en1')-('$en2'); print e }' null > tmp"
      else if(Which_Code.eq.'QUICKS') then
         write(32,'(a)') &
      "  awk 'BEGIN { e=('$en1')-('$en2'); print e*27.21 }' null > tmp"
      end if
      write(32,'(a/a)') &
         '   set en12=`cat tmp`', "   echo '# energy difference"// &
         "             = ' $en12 >> BSSE_info"
      write(32,'(a/a/a/a/)') '   echo > null', &
         "   awk 'BEGIN { e=('$fin')+('$en12'); print e }' null > tmp", &
         '   set fin=`cat tmp`', "   echo '# BSSE correction "// &
         "update        = ' $fin >> BSSE_info"
!
      write(32,'(a/)') 'end'

      write(32,'(a)') "echo '################"// &
                        "###############################' >> BSSE_info"
      write(32,'(a)')  "echo '# Final BSSE correction (in eV) "// &
           "     = ' $fin >> BSSE_info"
      close (32)
      call system('chmod u+x BSSE_script.run')
      end subroutine BSSE_script

      subroutine write_SIESTA_part_noghost(im,cha5,l,Diff_D,dir)
!.....................................................................
! write SIESTA fdf input file for partition im as a file
! without other atoms as ghosts
!.....................................................................
! dir=0 - then it writes the files into BSSE subdirectory
! dir=1 - then it writes the files into Dens_Diff subdirectory
!.....................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      character :: cha5*5,Spec(N0KD)*2
      logical :: present(N0KD),Err,cgsteps,Diff_D,saverho,saveall,savedm
      logical :: typeofrun
      integer :: NspN1(N0LT)
      integer :: dir
!
      integer :: im,l,Nsp1,ITI1,nat,ii,i,j,j1,nl,mendl,nat1,k

!....... analyse atoms first:
!        Nsp1     - new number of species
!        ITI1     - number of atoms
!        Nsp1(is) - number of atoms in species
!
      Nsp1=0 ; ITI1=0 ; nat=0
      do i=1,Nsp
         present(i)=.false.
         ii=0
         do j=1,NspN(i)
            nat=nat+1
            if(Mol_index(nat).eq.im) then
               ii=ii+1 ; present(i)=.true.
            end if
         end do
         if(present(i)) then
            Nsp1=Nsp1+1
            NspN1(Nsp1)=ii ; ITI1=ITI1+ii ; Spec(Nsp1)=Species(i)
         end if
      end do
      write(*,*)'......> Partition ',im,' information <.......'
      write(*,'(a,i5)') 'atoms   = ',ITI1
      write(*,'(a,i5)') 'species = ',Nsp1
      do i=1,Nsp1,15
         j1=i+15
         if(j1.gt.Nsp1) j1=Nsp1
         write(*,'(a,15(i5,x))') 'atoms in species: ',(NspN1(j),j=i,j1)
      end do
!
!........ write the input file
!
      if(dir.eq.0) then
         open(32,file='BSSE/'//cha5(l:)//'/INPUT_FILE.fdf', &
              status='unknown')
      else
         open(32,file='Dens_Diff/'//cha5(l:)//'/INPUT_FILE.fdf', &
              status='unknown')
      end if
      if(Diff_D) write(32,'(a)') 'SystemLabel '//SystemLabel(isysl0:)
      Cgsteps=.false.
      saverho=.false.
      saveall=.false.
      savedm=.false.
      typeofrun=.false.
      do nl=1,nlines
         if(index(lines(nl),'MD.NumCGSteps').ne.0) then
            write(32,'(a)') 'MD.NumCGSteps 0'
            cgsteps=.true.
         else if(index(lines(nl),'UseSaveData').ne.0) then
            write(32,'(a)') 'UseSaveData false'
            saveall=.true.
         else if(index(lines(nl),'DM.UseSaveDM').ne.0) then
            write(32,'(a)') 'DM.UseSaveDM false'
            savedm=.true.
         else if(index(lines(nl),'MD.TypeOfRun').ne.0) then
            write(32,'(a)') 'MD.TypeOfRun CG'
            typeofrun=.true.
         else  if(index(lines(nl),'SaveRho').ne.0) then
            if(Diff_D) then
               write(32,'(a)') 'SaveRho true'
            else
               write(32,'(a)') 'SaveRho false'
            end if
            saverho=.true.
         else
            write(32,'(a)') lines(nl)
         end if
      end do
      if(.not.cgsteps) write(32,'(a)') 'MD.NumCGSteps 0'
      if(.not.saverho.and.Diff_D) write(32,'(a)') 'SaveRho true'
      if(.not.saveall) write(32,'(a)') 'UseSaveData false'
      if(.not.savedm) write(32,'(a)') 'DM.UseSaveDM false'
      if(.not.typeofrun) write(32,'(a)') 'MD.TypeOfRun CG'

      write(32,'(/a,i5)') 'NumberOfSpecies ',Nsp1
      write(32,'(a,i5/)') 'NumberOfAtoms   ',ITI1
      write(32,'(a)') '%block ChemicalSpeciesLabel'
      do i=1,Nsp1
         call check_Mendel(Spec(i),mendl,Err,.false.)
         if(Err) write(*,'(a)') 'WARNING: wrong species '// &
              Spec(i)//' in SIESTA input'
         write(32,'(i5,x,i2,x,a)') i,mendl,Spec(i)
      end do
      write(32,'(a/)') '%endblock ChemicalSpeciesLabel'

      write(32,'(a,f10.5,a)') 'LatticeConstant ',vscale,' Ang'
      write(32,'(a)') '%block LatticeVectors'
      do i=1,3
         write(32,*) (AJ(i,j)/vscale,j=1,3)
      end do
      write(32,'(a/)') '%endblock LatticeVectors'
      write(32,'(a)') 'AtomicCoordinatesFormat Ang'
      write(32,'(a)')'%block AtomicCoordinatesAndAtomicSpecies'

      nat=0 ; nat1=0 ; Nsp1=0
      do i=1,Nsp
         if(present(i)) Nsp1=Nsp1+1
         do k=1,NspN(i)
            nat=nat+1
            if(Mol_index(nat).eq.im) then
               nat1=nat1+1
               write(32,'(3(f10.5,x),i5,a,a,i5)') &
                 (TI(j,nat)/vscale,j=1,3),Nsp1,' # ',Species(i),nat1
            end if
         end do
      end do
      write(32,'(a)')'%endblock AtomicCoordinatesAndAtomicSpecies'
      write(*,*)'Written geometry to BSSE/'//cha5(l:)//'/INPUT_FILE.fdf'
      close (32)
      end subroutine write_SIESTA_part_noghost

      subroutine write_SIESTA_part_ghost(im,cha5,l)
!.....................................................................
! write SIESTA fdf input file for partition im as a file
! with other atoms as ghosts
!.....................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      character :: cha5*5,Spec(N0KD)*3
      logical :: Err,cgsteps,saveall,savedm
      integer :: NspN1(N0LT),ik(N0LT),isp(N0LT)
!
      integer :: im,l,Nsp1,nat,i,ii1,ii2,j,nat1,j1,nl,k,is,mendl
!
!....... analyse atoms first:
!        Nsp1     - new number of species
!        ITI      - number of atoms
!        Nsp1(is) - number of atoms in species
!
      Nsp1=0 ; nat=0
      DO i=1,Nsp

         ii1=0 ; ii2=0
         do j=1,NspN(i)
            nat1=nat+j
            if(Mol_index(nat1).eq.im) then
               ii1=ii1+1 ; ik(j)=1
            else
               ii2=ii2+1 ; ik(j)=2
            end if
         end do

         Nsp1=Nsp1+1
         do j=1,NspN(i)
            nat1=nat+j
            if(ik(j).eq.ik(1)) then
               isp(nat1)=Nsp1
            else
               isp(nat1)=Nsp1+1
            end if
         end do
         if(ik(1).eq.1) then
            NspN1(Nsp1)=ii1 ; Spec(Nsp1)=' '//Species(i)
            if(ii2.ne.0) then
               NspN1(Nsp1+1)=ii2 ; Spec(Nsp1+1)='-'//Species(i)
            end if
         else
            NspN1(Nsp1)=ii2 ; Spec(Nsp1)='-'//Species(i)
            if(ii1.ne.0) then
               NspN1(Nsp1+1)=ii1 ; Spec(Nsp1+1)=' '//Species(i)
            end if
         end if
         if(ii1.ne.0 .and. ii2.ne.0) Nsp1=Nsp1+1
         nat=nat+NspN(i)

      END DO
      write(*,*)'......> Partition ',im,' information <.......'
      write(*,'(a,i5)') 'atoms   = ',ITI
      write(*,'(a,i5)') 'species = ',Nsp1
      do i=1,Nsp1,15
         j1=i+15
         if(j1.gt.Nsp1) j1=Nsp1
         write(*,'(a,15(i5,x))') 'atoms in species: ',(NspN1(j),j=i,j1)
      end do
!
!........ write the input file
!

      open(32,file='BSSE/'//cha5(l:)//'-ghost/INPUT_FILE.fdf', &
           status='unknown')
      cgsteps=.false.
      saveall=.false.
      savedm=.false.
      do nl=1,nlines
         if(index(lines(nl),'MD.NumCGSteps').ne.0) then
            write(32,'(a)') 'MD.NumCGSteps 0'
            cgsteps=.true.
         else if(index(lines(nl),'UseSaveData').ne.0) then
            write(32,'(a)') 'UseSaveData false'
            saveall=.true.
         else if(index(lines(nl),'DM.UseSaveDM').ne.0) then
            write(32,'(a)') 'DM.UseSaveDM false'
            savedm=.true.
         else  if(index(lines(nl),'SaveRho').ne.0) then
            write(32,'(a)') 'SaveRho false'
         else
            write(32,'(a)') lines(nl)
         end if
      end do
      if(.not.cgsteps) write(32,'(a)') 'MD.NumCGSteps 0'
      if(.not.saveall) write(32,'(a)') 'UseSaveData false'
      if(.not.savedm) write(32,'(a)') 'DM.UseSaveDM false'

      write(32,'(/a,i5)') 'NumberOfSpecies ',Nsp1
      write(32,'(a,i5/)') 'NumberOfAtoms   ',ITI
      write(32,'(a)') '%block ChemicalSpeciesLabel'
      do i=1,Nsp1
         call check_Mendel(Spec(i)(2:3),mendl,Err,.false.)
         if(Err) write(*,'(a)') 'WARNING: wrong species '// &
              Spec(i)//' in SIESTA input'
         if(Spec(i)(1:1).eq.'- ') mendl=-mendl
         write(32,'(i5,x,i4,x,a)') i,mendl,Spec(i)(2:3)
      end do
      write(32,'(a/)') '%endblock ChemicalSpeciesLabel'

      write(32,'(a,f10.5,a)') 'LatticeConstant ',vscale,' Ang'
      write(32,'(a)') '%block LatticeVectors'
      do i=1,3
         write(32,*) (AJ(i,j)/vscale,j=1,3)
      end do
      write(32,'(a/)') '%endblock LatticeVectors'
      write(32,'(a)') 'AtomicCoordinatesFormat Ang'
      write(32,'(a)')'%block AtomicCoordinatesAndAtomicSpecies'
      nat=0
      do i=1,Nsp
         do k=1,NspN(i)
            nat=nat+1
            is=isp(nat)
            write(32,'(3(f10.5,x),i5,a,a,i5)') &
                 (TI(j,nat)/vscale,j=1,3),is,' # ',Spec(is)(2:3),nat
         end do
      end do
      write(32,'(a)')'%endblock AtomicCoordinatesAndAtomicSpecies'
      write(*,*) &
         'Written geometry to BSSE/'//cha5(l:)//'-ghost/INPUT_FILE.fdf'
      close (32)
      end subroutine write_SIESTA_part_ghost

      subroutine Dens_Diff_script(Which_Code)
!...................................................................
! generate script for the electron density difference calculation
!...................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      character :: cha5*5,Which_Code*6
!
      integer :: im,lc
!
!............. create directory structure and write input files
!
      write(*,*)'... creating directory Dens_Diff'
!
!_________ do the directory structure + input files
      call system('mkdir Dens_Diff')
      do im=1,iMol
         write(cha5,'(i5)') im
         do lc=1,5
            if(cha5(lc:lc).ne.' ') go to 1
         end do
 1       write(*,*)'... creating directory Dens_Diff/'//cha5(lc:)
         call system('mkdir Dens_Diff/'//cha5(lc:))
         if(Which_Code.eq.'SIESTA') then
             write(*,*) &
               '... writing Dens_Diff/'//cha5(lc:)//'/INPUT_FILE.fdf'
             call write_SIESTA_part_noghost(im,cha5,lc,.true.,1)
         else if(Which_Code.eq.'  VASP' .or. &
                                        Which_Code.eq.'VASP52') then
             write(*,*)'... writing Dens_Diff/'//cha5(lc:)//'/POSCAR'
             call write_POSCAR_file(im,cha5,lc,Which_Code)
         else if(Which_Code.eq.'QUICKS') then
             write(*,*)'... writing Dens_Diff/'//cha5(lc:)//'/qs.inp'
             call write_QUICKS_file(im,cha5,lc)
         end if
      end do
!
!............. writing the density script
!
      open(32,file='Dens_Diff_script.run',status='unknown')
      write(32,'(a/)') '#! /bin/csh'
      if(Which_Code.eq.'SIESTA') then
         write(32,'(a//a/a/a/)') 'if ( -e INPUT_FILE.fdf ) '// &
           '/bin/mv INPUT_FILE.fdf INPUT_FILE_orig.fdf', &
           '#','#................. loop over partitions','#'
      else if(Which_Code.eq.'  VASP' .or. &
                                        Which_Code.eq.'VASP52') then
         write(32,'(a)') 'if ( -e POSCAR ) /bin/mv POSCAR POSCAR.org'
      else if(Which_Code.eq.'QUICKS') then
         write(32,'(a)') 'if ( -e qs.inp ) /bin/mv qs.inp qs.inp.org'
      end if
      write(cha5,'(i5)') iMol
      do lc=1,5
         if(cha5(lc:lc).ne.' ') go to 2
      end do
 2    write(32,'(a,'//cha5(lc:)//'(x,i3),a/)') &
                                   'foreach part ( ',(im,im=1,iMol),' )'
      if(Which_Code.eq.'SIESTA') then
         write(32,'(3x,a)') '/bin/cp Dens_Diff/$part/INPUT_FILE.fdf .'
         write(32,'(3x,a)') 'siesta |tee OUTCAR'
         write(32,'(3x,a)') '/bin/mv OUTCAR Dens_Diff/$part/.'
         write(32,'(3x,a)') &
            '/bin/mv '//SystemLabel(isysl0:)//'.RHO  Dens_Diff/$part/.'
      else if(Which_Code.eq.'  VASP' .or. &
                                        Which_Code.eq.'VASP52') then
         write(32,'(3x,a)') '/bin/cp Dens_Diff/$part/POSCAR .'
         write(32,'(3x,a)') 'vasp |tee OUTCAR'
         write(32,'(3x,a)') '/bin/mv OUTCAR Dens_Diff/$part/.'
         write(32,'(3x,a)') '/bin/mv CHRCAR Dens_Diff/$part/.'
      else if(Which_Code.eq.'QUICKS') then
         write(32,'(3x,a)') '/bin/cp Dens_Diff/$part/qs.inp .'
         write(32,'(3x,a)') 'cp2k |tee OUTCAR'
         write(32,'(3x,a)') '/bin/mv OUTCAR Dens_Diff/$part/.'
         write(32,'(3x,a)') &
              '/bin/mv A-ELECTRON_DENSITY-1_0.cube Dens_Diff/$part/.'
      end if
!
      write(32,'(a/)') 'end'
      close (32)
      call system('chmod u+x Dens_Diff_script.run')
      end subroutine Dens_Diff_script

      subroutine write_POSCAR_file(im,cha5,lc,Which_Code)
!.........................................................................
!.........................................................................
      use real8
      use tetrag1
      implicit none
      character :: cha5*5,Spec(N0KD)*2,cha1,cha2*2,Which_Code*6
      logical :: present(N0KD)
      integer :: NspN1(N0LT)
!
      integer :: im,lc,Nsp1,ITI1,nat,i,j,ii,j1,k,lvt
!
!....... analyse atoms first:
!        Nsp1     - new number of species
!        ITI1     - number of atoms
!        Nsp1(is) - number of atoms in species
!
      Nsp1=0 ; ITI1=0 ; nat=0
      do i=1,Nsp
         present(i)=.false. ; ii=0
         do j=1,NspN(i)
            nat=nat+1
            if(Mol_index(nat).eq.im) then
               ii=ii+1 ; present(i)=.true.
            end if
         end do
         if(present(i)) then
            Nsp1=Nsp1+1 ; NspN1(Nsp1)=ii ; ITI1=ITI1+ii
            Spec(Nsp1)=Species(i)
         end if
      end do
      write(*,*)'......> Partition ',im,' information <.......'
      write(*,'(a,i5)') 'atoms   = ',ITI1
      write(*,'(a,i5)') 'species = ',Nsp1
      do i=1,Nsp1,15
         j1=i+15 ; if(j1.gt.Nsp1) j1=Nsp1
         write(*,'(a,15(i5,x))') 'atoms in species: ',(NspN1(j),j=i,j1)
      end do
!
!........ write the input file
!
      open(32,file='Dens_Diff/'//cha5(lc:)//'/POSCAR',status='unknown')
      if(Nsp.lt.10) then
         write(cha1,'(i1)') Nsp ; cha2=' '//cha1
      else
         write(cha2,'(i2)') Nsp
      end if
      call right(vtitle,80,lvt)
      write(32,'(2a,'//cha2//'(a,x))') &
               vtitle(lvt:),' -> Species: ',(Species(i),i=1,Nsp)
      write(32,*) vscale
      write(32,*) AJ(1,1)/vscale, AJ(1,2)/vscale, AJ(1,3)/vscale
      write(32,*) AJ(2,1)/vscale, AJ(2,2)/vscale, AJ(2,3)/vscale
      write(32,*) AJ(3,1)/vscale, AJ(3,2)/vscale, AJ(3,3)/vscale
      if(Which_Code.eq.'VASP52') &
           write(32,'('//cha2//'(a,x))') (Species(i),i=1,Nsp)
      write(32,*) (NspN1(i),i=1,Nsp1)
      write(32,'(a)')'Cartesian'
      nat=0
      do i=1,Nsp
         do k=1,NspN(i)
            nat=nat+1
            if(Mol_index(nat).eq.im) &
                     write(32,'(3(f16.12,x))') (TI(j,nat)/vscale,j=1,3)
         end do
         write(32,*)
      end do
      close (32)
      write(*,*)'Written geometry to '//seed(l0seed:)
      end subroutine write_POSCAR_file

      subroutine write_final_siesta()
!.....................................................................
! write SIESTA fdf input file by taking geometry from the XV file
!.....................................................................
      use real8
      use tetrag1
      use siesta
      use buffer0
      implicit none
      character(len=FLEN) :: seed0
      logical :: Err,list_at(N0LT),frozen
      integer :: set_beg(SETS),set_end(SETS),old_to_new(N0LT)
      real(8) :: x(3)
!
      integer :: i,l0seed0,i2,nl,ll,n,j,k,nat,mendl

      write(*,*) Where_siesta
!
!................ save the current setting in /buffer0/
!
      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
!
![1]..... analyse what is available
!
![1a]__________ XV file was read in first; should keep the geometry and read
!               lines() from the initial fdf file
      if(where_siesta.eq.'SIE-XV') then
         write(*,'(a)') &
       'Specify SYSTEM LABEL (char*',FLEN,') for the related SIESTA fdf file:'
         write(*,'(a)') &
       '                                   ^^^^^^^^^^^^'
         write(*,'(/a)')'**** Input files in the current directory: ***'
         call system('ls *.fdf ')
         write(*,'(a)') '**********************************************'
         write(*,'(a)') '*  Extention .fdf should NOT be specified!   *'
         write(*,'(a/)')'**********************************************'
         read(*,'(a)') seed0 ; write(8,'(a)') seed0
         call right(seed0,FLEN,l0seed0)
         do i=1,ITI
            old_to_new(i)=i
         end do
         write(*,*) &
                  'Reading the rest from '//seed0(l0seed0:)//'.fdf  ...'
         open(73,file=seed0(l0seed0:)//'.fdf',form='formatted', &
                 status='old',err=100)
         write(*,*)'... file '//seed0(l0seed0:)//'.fdf'// ' openned ...'
         call get_rest_from_SIESTA(ITI,Nsp,73)
         call get_relax_flags_SIESTA(73,ITI,relax_flag,old_to_new)
         close (73)

![1b]__________ fdf file was read in first; should read in new geometry from
!               the XV file

      else if(where_siesta.eq.'SIESTA') then
         write(*,*) &
       'Specify SYSTEM LABEL (char*',FLEN,') for the related SIESTA  XV file:'
         write(*,'(a)') &
       '                                   ^^^^^^^^^^^^'
         write(*,'(/a)')'*** Output files in the current directory: ***'
         call system('ls *.XV')
         write(*,'(a)') '**********************************************'
         write(*,'(a)') '*   Extention .XV should NOT be specified!   *'
         write(*,'(a/)')'**********************************************'
         read(*,'(a)') seed0 ; write(8,'(a)') seed0
         call right(seed0,FLEN,l0seed0)
         Err=.false.
         call get_all_from_SIESTAXV(seed0,l0seed0,Err)
         if(Err) go to 110
      end if
!
![2]...... write the final fdf file
!
      open(32,file='INPUT_FILE-relaxed.fdf',status='unknown')
      i2=0
      do nl=1,nlines
         if(index(lines(nl),'SystemLabel').ne.0) then
            write(32,'(a)') 'SystemLabel '//seed0(l0seed0:)
            i2=1
         else
            ll=0
            do i=200,1,-1
               if(lines(nl)(i:i).ne.' ') then
                  ll=i ; exit
               end if
            end do
            if(ll.ne.0) then
               if(lines(nl)(1:1).eq.'#') then
                  write(32,'(/a)') lines(nl)(1:ll)
               else
                  write(32,'(a)') lines(nl)(1:ll)
               end if
               go to 10
            end if
         end if
 10   end do
      if(i2.eq.0) write(32,'(a)') 'SystemLabel '//seed0(l0seed0:)

!__________________ geometry constraints if any

      frozen=.false.
      do i=1,ITI
         if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' &
                                   .or. relax_flag(3,i).eq.'F') then
            frozen=.true.
            write(32,'(/a)') '%block GeometryConstraints'
            go to 5
         end if
      end do
      if(.not.frozen) go to 15
!__________firstly, for all atoms which are completely frozen
 5    do i=1,ITI
         if(relax_flag(1,i).eq.'F' .and. relax_flag(2,i).eq.'F' &
                                   .and. relax_flag(3,i).eq.'F') then
            list_at(i)=.true.
         else
            list_at(i)=.false.
         end if
      end do
      call do_sets_from_list(list_at,ITI,n,set_beg,set_end,SETS)
      do i=1,n
         if(set_beg(i).eq.set_end(i)) then
            write(32,'(a,i10)') 'position ',set_beg(i)
         else
            write(32,'(a,i10,a,i10)') 'position from ', &
                 set_beg(i),' to ',set_end(i)
         end if
      end do
!__________secondly, for all atoms which are frozen in some directions only
      do i=1,ITI
         if(.not.list_at(i)) then
            if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' &
                                   .or. relax_flag(3,i).eq.'F') then
               do j=1,3
                  x(j)=0.0
                  if(relax_flag(j,i).eq.'F') x(j)=1.0
               end do
               write(32,'(a,i5,3(x,f4.1))') 'position ',i,x
            end if
         end if
      end do
      write(32,'(a/)') '%endblock GeometryConstraints'

!__________________ geomtry part now

 15   write(32,'(/a,i5)') 'NumberOfSpecies ',Nsp
      write(32,'(a,i5/)') 'NumberOfAtoms   ',ITI
      write(32,'(a)') '%block ChemicalSpeciesLabel'
      do i=1,Nsp
         call check_Mendel(Species(i),mendl,Err,.false.)
         if(Err) write(*,'(a)') 'WARNING: wrong species '// &
                               Species(i)//' in SIESTA input'
         write(32,'(i5,x,i2,x,a)') i,mendl,Species(i)
      end do
      write(32,'(a/)') '%endblock ChemicalSpeciesLabel'
      write(32,'(a,f10.5,a)') 'LatticeConstant ',vscale,' Ang'
      write(32,'(a)') '%block LatticeVectors'
      do i=1,3
         write(32,*) (AJ(i,j)/vscale,j=1,3)
      end do
      write(32,'(a/)') '%endblock LatticeVectors'
      write(32,'(a)') 'AtomicCoordinatesFormat Ang'
      write(32,'(a)')'%block AtomicCoordinatesAndAtomicSpecies'
      nat=0
      do i=1,Nsp
         do k=1,NspN(i)
            nat=nat+1
            write(32,'(3(f10.5,x),i5,a,a,i5)') &
                    (TI(j,nat)/vscale,j=1,3),i,' # ',Species(i),nat
         end do
      end do
      write(32,'(a)')'%endblock AtomicCoordinatesAndAtomicSpecies'
      close (32)
      write(*,*)'Created INPUT_FILE-relaxed.fdf file!'
      go to 120
!
!........... errors
100   write(*,*)'FATAL! Error while opening siesta fdf file!'
      go to 115
110   write(*,*)'FATAL! Error while opening/reading siesta XV file!'
115   write(*,*)' ---------->      CANNOT proceed     <------------'
120   call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
      end subroutine write_final_siesta

      subroutine BSSE_input_QUICKS()
!..............................................................................
! It writes an input file for the current geometry to perform BSSE calculation
! using internal tools of QUICKSTEP
!..............................................................................
! as there is no relaxation required, ignore constraints
!..............................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      logical :: fragm(N0LT),err
      integer :: set_beg(SETS),set_end(SETS)
      character :: cha1*10,cha2*10,listl*250
!
      integer :: nl,i0,k,l1,l2,i,j,ln,n,nat,is,n0
!
!.............. open input file
!
      write(*,*) &
         'QUICKSTEP: writing input file BSSE_'//seed(l0seed:)//' ...'
      open(88,file='BSSE_'//seed(l0seed:),status='unknown')
!
      nl=0
 1    nl=nl+1

!___________ BSSE related: add to &GLOBAL
         if(index(lines(nl),'RUN_TYPE').ne.0) then
            i0=index(lines(nl),'RUN')
            write(88,'(a)') lines(nl)(:i0-1)//'RUN_TYPE BSSE'

!___________ Make sure that only one iteration
         else if(index(lines(nl),'&GEO_OPT').ne.0) then
            n0=nl
 3          n0=n0+1
            if(index(lines(n0),'&END') .eq.0) go to 3
            do k=nl,n0-1
               if(index(lines(k),'MAX_ITER').eq.0) &
                                  write(88,'(a)') trim(lines(k))
            end do
            write(88,'(a)') lines(nl)(:i0-1)//'MAX_ITER 0'
            write(88,'(a)') trim(lines(n0))
            nl=n0

!___________ BSSE related: add to &KIND extra species with '_ghost'
         else if(index(lines(nl),'&KIND').ne.0) then
            if(index(lines(nl),'_ghost') .ne.0) write(*,'(a/a)') &
                 'WARNING: your input file seems to contain already', &
                 '         BSSE information => please, CHECK!'
            i0=index(lines(nl),'&')
            call find_word(lines(nl)(i0+5:),100-i0-4,l1,l2,err)
            if(err) then
               write(*,*)'ERROR: species symbol is missing after &KIND!'
            else
               write(*,'(a)') &
                    '... doing species '//lines(nl)(i0+4+l1:i0+4+l2)
            end if
            n0=nl
 10         n0=n0+1
            if(index(lines(n0),'&END') .eq.0) go to 10
            do k=nl,n0
               write(88,'(a)') trim(lines(k))
            end do
            write(88,'(a)') lines(nl)(:i0+4+l2)//'_ghost'
            write(88,'(a)') lines(nl)(:i0-1)//'  GHOST'
            do k=nl+1,n0
               if(index(lines(k),'POTENTIAL').eq.0) &
                                    write(88,'(a)') trim(lines(k))
            end do
            nl=n0

!___________ BSSE related: add to &BSSE block all fragments (our "molecules")
! First, we create lists corresponding to the given molecule:
!        n      - number of coninuous atomic numbers (up to 100 allowed)
!    set_beg(i) - first number of the list i
!    set_end(i) - last number of the list i
! Then we create a long list (listl, up to 250 in length) and write with the LIST command

         else if(index(lines(nl),'&DFT').ne.0) then
            i0=index(lines(nl),'&')
            write(88,'(a)') lines(nl)(:i0-1)//'&BSSE'
            do i=1,iMol
               write(88,'(a,2x,a)') lines(nl)(:i0-1),'&FRAGMENT'
               do j=1,ITI
                  fragm(j)=.false.
                  if(Mol_index(j).eq.i) fragm(j)=.true.
               end do
               call do_sets_from_list(fragm,ITI,n,set_beg,set_end,SETS)
               ln=0
               do k=1,n
                  call number_to_char(set_beg(k),cha1,l1)
                  call number_to_char(set_end(k),cha2,l2)
                  if(ln.eq.0) then
                     if(set_beg(k).eq.set_end(k)) then
                        ln=l1
                        listl(1:ln)=cha1(1:l1)
                     else
                        ln=l1+l2+2
                        listl(1:ln)=cha1(1:l1)//'..'//cha2(1:l2)
                     end if
                  else
                     if(set_beg(k).eq.set_end(k)) then
                        listl(ln+1:ln+l1+1)=' '//cha1(1:l1)
                        ln=ln+l1+1
                     else
                        listl(ln+1:ln+l1+l2+3)= &
                          ' '//cha1(1:l1)//'..'//cha2(1:l2)
                        ln=ln+l1+l2+3
                     end if
                  end if
                  if(ln.gt.227 .and. k.lt.n) then
                     write(88,'(a,3x,a)') &
                               lines(nl)(:i0-1),'LIST '//listl(:ln)
                     write(*,*)'WARNING: only 1 LIST command is allowed'
                     write(*,*) &
                        'Your list of atoms is too long and will split.'
                     write(*,*)'Do not forget to edit the input file!'
                     write(*,*)'Please hit ENTER ...'
                     read(*,*) ; write(8,'(a)') 'PressEnter'
                     ln=0
                  end if
               end do
               write(88,'(a,3x,a)') lines(nl)(:i0-1),'LIST '//listl(:ln)
               write(88,'(a,2x,a)') lines(nl)(:i0-1),'&END FRAGMENT'
            end do
            write(88,'(a)') lines(nl)(:i0-1)//'&END BSSE'
            write(88,'(a)') trim(lines(nl))

!___________ cell + coordinates

         else if(index(lines(nl),'&END').ne.0 .and. &
                          index(lines(nl),'SUBSYS').ne.0 ) then

            write(88,'(a)') '  &CELL'
            write(88,'(a,3(x,f14.9))')'A ',(AJ(1,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'B ',(AJ(2,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'C ',(AJ(3,j),j=1,3)
            write(88,'(a)') '  &END CELL'
!
            write(88,'(a)') '  &COORD'
            nat=0
            do is=1,Nsp
               do n=1,NspN(is)
                  nat=nat+1
                  write(88,'(a,3(x,f14.9))') &
                       Species(is),(TI(j,nat),j=1,3)
               end do
            end do
            write(88,'(a)') '  &END COORD'
            write(88,'(a)') trim(lines(nl))

!___________ constraints
!            itype  (from 0 to 7) - the type of the contsraint
!            ig - type number

         else if(index(lines(nl),'&FIXED_ATOMS').ne.0) then
            write(*,*)'QUICKSTEP: found &FIXED_ATOMS - ignored'
         else
            write(88,'(a)') trim(lines(nl))
         end if
      if(nl.lt.nlines) go to 1
      close (88)
      end subroutine BSSE_input_QUICKS

      subroutine write_QUICKS_file(im,cha5,lc)
!.....................................................................
! write QUICKSTEP fdf input file for partition im as a file
! which would print the electron density.
! it writes the files into Dens_Diff subdirectory
!.....................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      character :: cha5*5
      logical :: Yes_PRINT,Yes_CUBE
!
      integer :: im,lc,nl,n0,i0,n,np1,np2,nat,is,j,k
!
!.............. open input file
!
      open(88,file='Dens_Diff/'//cha5(lc:)//'/qs.inp',status='unknown')
!
      nl=0
 1    nl=nl+1
         if(index(lines(nl),'&GLOBAL').ne.0) then
!___________ change/provide the PROJECT name
!___________ choose RUN type in &GLOBAL
            n0=nl
 4          n0=n0+1
            if(index(lines(n0),'&END').eq.0 .or. &
                       index(lines(n0),'GLOBAL').eq.0) go to 4
            do n=nl,n0-1
               if(index(lines(n),'RUN_TYPE').ne.0) then
                  i0=index(lines(n),'RUN')
                  write(88,'(a)') lines(n)(:i0-1)//'RUN_TYPE GEO_OPT'
               else if(index(lines(n),'PROJECT').eq.0) then
                  write(88,'(a)') trim(lines(n))
               end if
            end do
            write(88,'(a)') '    PROJECT A'
            write(88,'(a)') '  &END GLOBAL'
            nl=n0

         else if(index(lines(nl),'&DFT').ne.0) then
!___________ choose to print the density: skip the line with the command
!            if present initially
!  nl,n0   - line numbers enclosing the whole DFT block
!  np1,np2 - line numbers enclosing the &PRINT block (if present)

            Yes_PRINT=.false. ; Yes_CUBE=.false.
            n0=nl ; np1=0 ; np2=0
 2          n0=n0+1
            if(index(lines(n0),'&PRINT').ne.0) then
               Yes_PRINT=.true. ; np1=n0
            end if
            if(index(lines(n0),'&END').ne.0 .and. &
                       index(lines(n0),'PRINT').ne.0) np2=n0
            if(index(lines(n0),'&E_DENSITY_CUBE').ne.0) Yes_CUBE=.true.
            if(index(lines(n0),'&END').eq.0 .or. &
                         index(lines(n0),'DFT').eq.0) go to 2
!
            if(Yes_CUBE) then
               do n=nl,n0-1
                  write(88,'(a)') trim(lines(n0))
                  if(index(lines(n0),'E_DENSITY_CUBE').ne.0 .and. &
                       index(lines(n0),'&END').ne.0) then
                     write(88,'(a)') '      STRIDE 1'
                     write(88,'(a)') '   &END E_DENSITY_CUBE'
                  end if
               end do
             else if(Yes_PRINT) then
               do n=nl,np1
                  write(88,'(a)') trim(lines(n0))
               end do
               write(88,'(a)') '   &E_DENSITY_CUBE'
               write(88,'(a)') '      STRIDE 1'
               write(88,'(a)') '   &END E_DENSITY_CUBE'
               do n=np1+1,n0
                  write(88,'(a)') trim(lines(n0))
               end do
            else
               write(88,'(a)') trim(lines(nl))
               write(88,'(a)') ' &PRINT'
               write(88,'(a)') '   &E_DENSITY_CUBE'
               write(88,'(a)') '      STRIDE 1'
               write(88,'(a)') '   &END E_DENSITY_CUBE'
               write(88,'(a)') ' &END PRINT'
               do n=nl+1,n0
                  write(88,'(a)') trim(lines(n))
               end do
            end if
            nl=n0

!___________ Make sure that only one iteration
         else if(index(lines(nl),'&GEO_OPT').ne.0) then
            n0=nl
 3          n0=n0+1
            if(index(lines(n0),'&END') .eq.0) go to 3
            do k=nl,n0-1
               if(index(lines(k),'MAX_ITER').eq.0) &
                                  write(88,'(a)') trim(lines(k))
            end do
            write(88,'(a)') lines(nl)(:i0-1)//'MAX_ITER 0'
            write(88,'(a)') trim(lines(n0))
            nl=n0

!___________ cell + coordinates

         else if(index(lines(nl),'&END').ne.0 .and. &
                          index(lines(nl),'SUBSYS').ne.0 ) then

            write(88,'(a)') '  &CELL'
            write(88,'(a,3(x,f14.9))')'A ',(AJ(1,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'B ',(AJ(2,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'C ',(AJ(3,j),j=1,3)
            write(88,'(a)') '  &END CELL'
!
            write(88,'(a)') '  &COORD'
            nat=0
            do is=1,Nsp
               do n=1,NspN(is)
                  nat=nat+1
                  if(Mol_index(nat).eq.im) &
                       write(88,'(a,3(x,f14.9),a,i5)') &
                          Species(is),(TI(j,nat),j=1,3),' # ',nat
               end do
            end do
            write(88,'(a)') '  &END COORD'
            write(88,'(a)') trim(lines(nl))

!___________ constraints
!            itype  (from 0 to 7) - the type of the contsraint
!            ig - type number

         else if(index(lines(nl),'&FIXED_ATOMS').ne.0) then
            write(*,*)'QUICKSTEP: found &FIXED_ATOMS - ignored'
         else
            write(88,'(a)') trim(lines(nl))
         end if
      if(nl.lt.nlines) go to 1
      close (88)
      end subroutine write_QUICKS_file

      subroutine write_CP2K_part_noghost(im,cha5,l,Diff_D,dir)
!..............................................................................
! It writes an input file for the current geometry to perform BSSE calculation
! for QUICKSTEP using tools of TETR -> for noghost "part" im
!..............................................................................
! as there is no relaxation required, ignore constraints
!..............................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      logical :: Diff_D
      integer :: dir
      character :: cha5*5
      logical :: Yes_PRINT,Yes_CUBE
!
      integer :: im,l,nl,n0,n,i0,np1,np2,nat,is,j,k,i
!
!.............. open input file
!
      write(*,*) 'QUICKSTEP: writing input file BSSE/' &
                           //cha5(l:)//'/cp2k.inp ...'
      open(88,file='BSSE/'//cha5(l:)//'/cp2k.inp',status='unknown')

      nl=0
 1    nl=nl+1
         if(index(lines(nl),'&GLOBAL').ne.0) then
!___________ change/provide the PROJECT name
!___________ choose RUN type in &GLOBAL
            n0=nl
 4          n0=n0+1
            if(index(lines(n0),'&END').eq.0 .or. &
                       index(lines(n0),'GLOBAL').eq.0) go to 4
            do n=nl,n0-1
               if(index(lines(n),'RUN_TYPE').ne.0) then
                  i0=index(lines(n),'RUN')
                  write(88,'(a)') lines(n)(:i0-1)//'RUN_TYPE GEO_OPT'
               else if(index(lines(n),'PROJECT').eq.0) then
                  write(88,'(a)') trim(lines(n))
               end if
            end do
            write(88,'(a)') '    PROJECT A'
            write(88,'(a)') '  &END GLOBAL'
            nl=n0

         else if(index(lines(nl),'&DFT').ne.0 .and. Diff_D) then
!___________ choose to print the density: skip the line with the command
!            if present initially
!  nl,n0   - line numbers enclosing the whole DFT block
!  np1,np2 - line numbers enclosing the &PRINT block (if present)

            Yes_PRINT=.false. ; Yes_CUBE=.false.
            n0=nl ; np1=0 ; np2=0
 2          n0=n0+1
            if(index(lines(n0),'&PRINT').ne.0) then
               Yes_PRINT=.true. ; np1=n0
            end if
            if(index(lines(n0),'&END').ne.0 .and. &
                       index(lines(n0),'PRINT').ne.0) np2=n0
            if(index(lines(n0),'&E_DENSITY_CUBE').ne.0) Yes_CUBE=.true.
            if(index(lines(n0),'&END').eq.0 .or. &
                         index(lines(n0),'DFT').eq.0) go to 2
!
            if(Yes_CUBE) then
               do n=nl,n0
                  write(88,'(a)') trim(lines(n0))
                  if(index(lines(n0),'E_DENSITY_CUBE').ne.0 .and. &
                       index(lines(n0),'&END').ne.0) then
                     write(88,'(a)') '      STRIDE 1'
                     write(88,'(a)') '   &END E_DENSITY_CUBE'
                  end if
               end do
            else if(Yes_PRINT) then
               do n=nl,np1
                  write(88,'(a)') trim(lines(n0))
               end do
               write(88,'(a)') '   &E_DENSITY_CUBE'
               write(88,'(a)') '      STRIDE 1'
               write(88,'(a)') '   &END E_DENSITY_CUBE'
               do n=np1+1,n0
                  write(88,'(a)') trim(lines(n0))
               end do
            else
               write(88,'(a)') trim(lines(nl))
               write(88,'(a)') ' &PRINT'
               write(88,'(a)') '   &E_DENSITY_CUBE'
               write(88,'(a)') '      STRIDE 1'
               write(88,'(a)') '   &END E_DENSITY_CUBE'
               write(88,'(a)') ' &END PRINT'
               do n=nl+1,n0
                  write(88,'(a)') trim(lines(n))
               end do
            end if
            nl=n0

!___________ Make sure that only one iteration
         else if(index(lines(nl),'&GEO_OPT').ne.0) then
            n0=nl
 3          n0=n0+1
            if(index(lines(n0),'&END') .eq.0) go to 3
            do k=nl,n0-1
               if(index(lines(k),'MAX_ITER').eq.0) &
                                  write(88,'(a)') trim(lines(k))
            end do
            write(88,'(a)') '   MAX_ITER 0'
            write(88,'(a)') trim(lines(n0))
            nl=n0

!___________ cell + coordinates + species

         else if( index(lines(nl),'&SUBSYS').ne.0 ) then

            write(88,'(a)') trim(lines(nl))
            i0=index(lines(nl),'&SUBSYS')

!___________________write species
            do i=1,Nsp
               write(88,'(a,2x,a)') &
                       lines(nl)(:i0-1),'&KIND '//Species(i)
               if(cp2k_sp_all(i)) then
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'ELEMENT '//cp2k_element(i)
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'BASIS_SET '//cp2k_basis_set(i)
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'POTENTIAL '//cp2k_potential(i)
               else
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'ELEMENT ==> missing <=='
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'BASIS_SET ==> missing <=='
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'POTENTIAL ==> missing <=='
               end if
               write(88,'(a,2x,a)') lines(nl)(:i0-1),'&END KIND '
            end do

!___________________ write cell & coordinates
            write(88,'(a)') '  &CELL'
            write(88,'(a,3(x,f14.9))')'A ',(AJ(1,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'B ',(AJ(2,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'C ',(AJ(3,j),j=1,3)
            write(88,'(a)') '  &END CELL'
!
             write(88,'(a)') '  &COORD'
            nat=0
            do is=1,Nsp
               do n=1,NspN(is)
                  nat=nat+1
                  if(Mol_index(nat).eq.im) &
                       write(88,'(a,3(x,f14.9),i5)') &
                          Species(is),(TI(j,nat),j=1,3),nat
               end do
            end do
            write(88,'(a)') '  &END COORD'
            write(88,'(a)') trim(lines(nl+1))
            nl=nl+1

!___________ constraints
         else if(index(lines(nl),'&FIXED_ATOMS').ne.0) then
            write(*,*)'QUICKSTEP: found &FIXED_ATOMS - ignored'
         else
            write(88,'(a)') trim(lines(nl))
         end if
      if(nl.lt.nlines) go to 1
      close (88)
      write(*,*) 'QUICKSTEP: closing input file BSSE/' &
                           //cha5(l:)//'/cp2k.inp ...'
      end subroutine write_CP2K_part_noghost

      subroutine write_CP2K_part_ghost(im,cha5,l)
!..............................................................................
! It writes an input file for the current geometry to perform BSSE calculation
! using internal tools of QUICKSTEP
!..............................................................................
! as there is no relaxation required, ignore constraints
!..............................................................................
      use real8
      use tetrag1
      use siesta
      implicit none
      character :: cha5*5
!
      integer :: nl,i0,n0,k,j,nat,is,n,im,l,i
!
!.............. open input file
!
      write(*,*) 'QUICKSTEP: writing input file BSSE/' &
                               //cha5(l:)//'-ghost/cp2k.inp ...'
      open(88,file='BSSE/'//cha5(l:)//'-ghost/cp2k.inp', &
           status='unknown')

      nl=0
 1    nl=nl+1

!___________ Make sure it is GEO_OPT
         if(index(lines(nl),'RUN_TYPE').ne.0) then
            i0=index(lines(nl),'RUN')
            write(88,'(a)') lines(nl)(:i0-1)//'RUN_TYPE GEO_OPT'

!___________ Make sure that only one iteration
         else if(index(lines(nl),'&GEO_OPT').ne.0) then
            n0=nl
 3          n0=n0+1
            if(index(lines(n0),'&END') .eq.0) go to 3
            do k=nl,n0-1
               if(index(lines(k),'MAX_ITER').eq.0) &
                                  write(88,'(a)') trim(lines(k))
            end do
            write(88,'(a)') '   MAX_ITER 0'
            write(88,'(a)') trim(lines(n0))
            nl=n0

!___________ cell + coordinates + species
!___________ BSSE related: add to &KIND extra species with '_ghost'

         else if( index(lines(nl),'&SUBSYS').ne.0 ) then

            write(88,'(a)') trim(lines(nl))
            i0=index(lines(nl),'&SUBSYS')

!___________________write species
            do i=1,Nsp
               write(88,'(a,2x,a)') &
                       lines(nl)(:i0-1),'&KIND '//Species(i)
               if(cp2k_sp_all(i)) then
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'ELEMENT '//cp2k_element(i)
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'BASIS_SET '//cp2k_basis_set(i)
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'POTENTIAL '//cp2k_potential(i)
               else
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'ELEMENT ==> missing <=='
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'BASIS_SET ==> missing <=='
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'POTENTIAL ==> missing <=='
               end if
               write(88,'(a,2x,a)') lines(nl)(:i0-1),'&END KIND '

!_________________add ghost equivalent
               write(88,'(a,2x,a)') &
                    lines(nl)(:i0-1),'&KIND '//Species(i)//'_ghost'
               write(88,'(a,4x,a)') lines(nl)(:i0-1),'GHOST'
               if(cp2k_sp_all(i)) then
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'ELEMENT '//cp2k_element(i)
                  write(88,'(a,4x,a)') &
                       lines(nl)(:i0-1),'BASIS_SET '//cp2k_basis_set(i)
               else
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'ELEMENT ==> missing <=='
                  write(88,'(a,4x)') &
                       lines(nl)(:i0-1),'BASIS_SET ==> missing <=='
               end if
               write(88,'(a,2x,a)') lines(nl)(:i0-1),'&END KIND '

            end do


!___________cell
            write(88,'(a)') '  &CELL'
            write(88,'(a,3(x,f14.9))')'A ',(AJ(1,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'B ',(AJ(2,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'C ',(AJ(3,j),j=1,3)
            write(88,'(a)') '  &END CELL'

!___________ coordinates
            write(88,'(a)') '  &COORD'
            nat=0
            do is=1,Nsp
               do n=1,NspN(is)
                  nat=nat+1
                  if(Mol_index(nat).eq.im) then
                     write(88,'(a,3(x,f14.9),i5)') &
                          Species(is),(TI(j,nat),j=1,3),nat
                  else
                     write(88,'(a,3(x,f14.9),i5)') &
                      Species(is)//'_ghost',(TI(j,nat),j=1,3),nat
                  end if
               end do
            end do
            write(88,'(a)') '  &END COORD'
            write(88,'(a)') trim(lines(nl))
            nl=nl+1

!___________ constraints
         else if(index(lines(nl),'&FIXED_ATOMS').ne.0) then
            write(*,*)'QUICKSTEP: found &FIXED_ATOMS - ignored'
         else
            write(88,'(a)') trim(lines(nl))
         end if
      if(nl.lt.nlines) go to 1
      close (88)
      write(*,*) 'QUICKSTEP: closing input file BSSE/' &
                               //cha5(l:)//'-ghost/cp2k.inp ...'
      end subroutine write_CP2K_part_ghost
