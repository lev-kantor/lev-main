module buffer0
use tetr_param  
implicit none
!     common /buffer0/ A0,TI0,B0,ITI0, &
!          NspN0,Nsp0,Species0,relax_flag0
      character :: Species0(N0KD)*2,relax_flag0(3,N0LT)
      real(8) :: A0(3,3),TI0(3,N0LT),B0(3,3)
      integer ::  ITI0,NspN0(N0KD),Nsp0

end module buffer0
