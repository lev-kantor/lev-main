module systema
implicit none
!......................................................................
!  system = either LATTICE or MOLECULE. Determines whether point group
!           or translational operations are to be used when checking
!           equivalence of two points.
!     common /latt_mol/ system
      character :: system*8
end module systema
