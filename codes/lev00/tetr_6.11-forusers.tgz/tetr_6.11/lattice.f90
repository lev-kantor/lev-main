      subroutine build_lat(Yes_Cell)
!........................................................................
!     This code builds a supercell. It gives:
!............
! AI(vector,component) - basic direct translations of the primitive cell
! AJ(vector,component) - basic direct translations of the supercell
! TI1(component,number) - all sublattices in the primitive cell
! TI(component,number) - all sublattices in the supercell
! ITI - total number of the sublattices (supercell)
! MG_luc - an integer dim(LUC)/dim(UC) extention number;
! TRAN(number,component) - all lattice sites inside the LUC generated
!                          (but only for the 1st sublattice);
!........................................................................
!  It also asks for:
!     Nsp - number of species in the system;
!     NspN(i) - number of atoms of the given species, i (=1,..,Nsp)
!........................................................................
      use real8
      use tetrag1
      use pgroup
      implicit none
      character :: cha2*2
      real(8) :: R(3),TI1(3,N0LT)
      integer :: NspN_prim(N0KD)
      logical :: NumSpecies,NumAtomsSpecies,Yes_Cell,ask_equiv,exist,Err
      logical ::Basic_Primitive,Atom_Positions,SuperCellVectors
      character*12 :: angstr='<Angstroms> '
      character*4 :: YES_xyz='Xmol'
      integer :: M11=0,N11=0,M22=0,N22=0,M33=0,N33=0
      logical :: Add_Hs=.false.
!
      integer MG_luc,i,j,ITI_prim,l0,k,k1,k2,is,kk,j1,iErr,L_ext1
      real(8) :: aMG_luc
!
!........... keep the current geometry (if exists) as default in /buffer0/

      if(ITI.ne.0) then
         exist=.true.
         call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         write(*,*)'WARNING: existing setting may be lost!'
      else
         exist=.false.
      end if

!========================================================================
!===================== MENU starts here =================================
!========================================================================
      NumSpecies=.false. ; NumAtomsSpecies=.false.
      Atom_Positions=.false. ; Basic_Primitive=.false.
      SuperCellVectors=.false. ; origin=.false. ; Yes_Cell=.false.
      ITI=0 ; ITI_prim=0 ; Nsp=0 ; MG_luc=1

!............. default: unit extention matrix
      do i=1,3
         do j=1,3
            IJ(i,j)=0
         end do
         IJ(i,i)=1
      end do

 21   write(*,*)
      write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,*)
      write(*,*)'========= CHOOSE AN OPTION:'
      write(*,*)

      if(NumSpecies) then
         write(*,*)'  1. Number of species: ',Nsp
         write(*,'(10x,20(a2,x))') (Species(i),i=1,Nsp)
         if(NumAtomsSpecies) then
            write(*,*) &
              '  2. Number of atoms in every species (PRIMITIVE CELL): '
            write(*,*) '     ',(NspN_prim(i),i=1,Nsp)
            write(*,*) &
                 '     Total number of atoms in the cell:  ',ITI_prim
         else
            write(*,*) &
              '  2. Number of atoms in every species:  <===== undefined'
            write(*,*) &
              '     Total number of atoms in the cell: <===== undefined'
         end if
      else
         write(*,*)'  1. Number of species:            <===== undefined'
      end if

      if(Basic_Primitive) then
         write(*,*) '  3. Basic translations of the PRIMITIVE CELL:'
         write(*,'(8x,a,5x,3(f10.5,x))') 'vector 1 => ',(AI(1,i),i=1,3)
         write(*,'(8x,a,5x,3(f10.5,x))') 'vector 2 => ',(AI(2,i),i=1,3)
         write(*,'(8x,a,5x,3(f10.5,x))') 'vector 3 => ',(AI(3,i),i=1,3)
      else
         write(*,*) &
       '  3. Basic translations of the PRIMITIVE CELL <===== undefined'
      end if

      if(NumAtomsSpecies.and.Basic_Primitive) then
         if(Atom_Positions) then
            write(*,*) &
          '  4. Positions of atoms in the PRIMITIVE CELL:  <===== Done!'
         else
            write(*,*) &
      '  4. Positions of atoms in the PRIMITIVE CELL:  <===== undefined'
         end if
      end if

!_____ extention matrix {cell -> supercell}

      write(*,*) &
      '-------------- Extention matrix {cell -> supercell} -----------'
      if(Basic_Primitive) then
         write(*,*) ' /5. Specify directly'
         write(*,*) ' \6. By specifying supercell lattice vectors'
      else
         write(*,*) '  5. Specify directly'
      end if
      ITI=ITI_prim*MG_luc
      write(*,'(16x,a,5x,3(i3,x),a)') '| ',(IJ(1,i),i=1,3),' |'
      write(*,'(a,5x,3(i3,x),a,i3)') &
           '       IJ(i,j)= | ',(IJ(2,i),i=1,3),' |,  ext=',MG_luc
      write(*,'(16x,a,5x,3(i3,x),a)') '| ',(IJ(3,i),i=1,3),' |'
      if(SuperCellVectors) then
         write(*,*) '     Total number of atoms in the supercell: ',ITI
         write(*,*) '     Basic translations of the SUPERCELL:'
         write(*,'(8x,a,5x,3(f10.5,x))') 'vector 1 => ',(AJ(1,i),i=1,3)
         write(*,'(8x,a,5x,3(f10.5,x))') 'vector 2 => ',(AJ(2,i),i=1,3)
         write(*,'(8x,a,5x,3(f10.5,x))') 'vector 3 => ',(AJ(3,i),i=1,3)
      end if

      if(SuperCellVectors .and. Basic_Primitive .and. &
                                NumAtomsSpecies.and.Atom_Positions) then
         if(YES_Cell) then
            write(*,*)'  7. FINAL STEP: Generate it! <===== Done!'
         else
            write(*,*)'  7. FINAL STEP: Generate it!'
         end if
      end if

!_____ show settings
      write(*,*) &
      '---------- v i s u a l i a s i o n   s e t t i n g s ---------'
      write(*,'(8x,a)') &
           '>>>>> Current setting for the breeding box: <<<<<'
      write(*,'(13x,a,3(i2,a,i2,a))') '[',M11,'...',N11,'] x [', M22, &
                                 '...',N22,'] x [', M33,'...',N33,']'
      L_ext1=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)
      write(*,'(8x,2(a,i3))') &
           '>>>>> extension = ',L_ext1,', # of atoms= ',ITI*L_ext1

      write(*,*) &
           ' Bb. Set the size of the breeding box for visualisation'
      write(*,*) &
              ' B0. Nullify the breeding box (make the UNIT extension)'

!      if(YES_xyz.ne.'None') then
!         write(*,*)
!     & ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
!      else
!         write(*,*)
!     &        ' XY. Do NOT produce <geom.xyz> file after every change'
!      end if
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: YES'
         else
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      if(Yes_Cell .and. YES_xyz.ne.'None') write(*,*) &
         '  W. Write <geom.xyz> file for preview using current breeding'

      write(*,*) &
      '-------------- g e n e r a l  s e t t i n g s ----------------'
!___________ set YES_xyz to the visualisation code:
!            make geom.xyz file automatically after every change
      if(origin) then
         write(*,*) ' Or. Move atoms closer to origin: YES'
      else
         write(*,*) ' Or. Move atoms closer to origin: NO'
      end if

      write(*,*) &
           ' An. [For input] Coordinates are specified in: '//angstr

      if(Yes_Cell) then
         write(*,*) &
           ' Co. Show current atomic positions in fractional/Cartesian'
         write(*,*)' Sy. Show the point symmetry'
!         write(*,*)'  S. Save the curent geometry'
         write(*,*)'  P. Proceed: keep the curent setting'
      end if

      write(*,*)'  Q. Quit: return to the previous setting (if exists)'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![XY]...... ask whether to produce geom.xyz file automatically

!      IF(cha2(l0:).eq.'XY') THEN

!         if(YES_xyz.eq.'None') then
!            YES_xyz='Ymol'
!         else if(YES_xyz.eq.'Ymol') then
!            YES_xyz='Xmol'
!         else if(YES_xyz.eq.'Xmol') then
!            YES_xyz='None'
!         end if

![Hs]...... add Hydrongens to geom.xyz or not

      IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else
            Add_Hs=.true.
         end if

![An]...... choose the way how the coordinates are given

      ELSE IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<Fractional>'
         end if

![Or]...... bring atoms closer to origin

      ELSE IF(cha2(l0:).eq.'Or') THEN

         if(origin) then
            origin=.false.
         else
            origin=.true.
         end if

![Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co' .and. Yes_Cell) THEN
         call show_atoms_notag()

![Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy' .and. Yes_Cell) THEN

         call check_symmetry('n','y')
         write(*,*)'Hit ENTER when done ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![Bb].... ask extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'Bb') THEN

!___________ ask extensions along the existing lattice vectors for the
!            breeding box
         call ask_breeding_box(M11,N11,M22,N22,M33,N33)
         if(Yes_Cell) &
              call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![B0].... nullify the extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'B0') THEN

         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         if(Yes_Cell) &
              call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W' .and. Yes_Cell .and. &
                                                YES_xyz.ne.'None') THEN

!___________ constract all lattice sites  and write geom.xyz
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![1]...... number of species

      ELSE IF(cha2(l0:).eq.'1') THEN

 31      write(*,*)'Give number of species in the primitive cell:'
         read(*,*,err=31) Nsp ; write(8,*) Nsp
         if(Nsp.lt.1) go to 31
         call ask_species(Nsp,Species,0,Err)
         NumSpecies=.true.

![2]...... number of atoms of every species in the PRIMITIVE CELL

      ELSE IF(cha2(l0:).eq.'2' .and. NumSpecies) THEN

 32      write(*,*) 'Give numbers of atoms of every species'// &
              ' in the PRIMITIVE cell:'
         read(*,*,err=32) (NspN_prim(i),i=1,Nsp)
         write(8,*) (NspN_prim(i),i=1,Nsp)
         ITI_prim=0
         do i=1,Nsp
            ITI_prim=ITI_prim+NspN_prim(i)
            if(NspN_prim(i).lt.1) go to 32
         end do
         NumAtomsSpecies=.true.

![3]...... primitive basic translations

      ELSE IF(cha2(l0:).eq.'3') THEN

         call latt_type(0)
         call INVER(AI,BI)
         Basic_Primitive=.true.
         do K=1,3
            do K1=1,3
               AJ(K,K1)=0.0
               do K2=1,3
                  AJ(K,K1)=AJ(K,K1)+IJ(K,K2)*AI(K2,K1)
               end do
            end do
         end do
         call INVER(AJ,BJ)
         SuperCellVectors=.true.

![4]...... atomic positions in the primitive cell

      ELSE IF(cha2(l0:).eq.'4' .and. &
          Basic_Primitive.and.NumAtomsSpecies) THEN

         j=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN_prim(k)

!_______________ give atomic position
 16            j=j+1
               if(angstr.eq.'<Angstroms> ') then
 17               write(*,'(a,i3,a)') &
                       'Give position of atom ',is,' in Angstroms:'
                  read(*,*,err=17) (TI1(i,j),i=1,3)
                  write(8,*) (TI1(i,j),i=1,3)
               else if(angstr.eq.'<Fractional>') then
 18               write(*,'(a,i3,a)') 'Give position of atom ',is, &
                                      ' in fractional coordinates:'
                  read(*,*,err=18) (r(i),i=1,3)
                  write(8,*) (r(i),i=1,3)
                  TI1(1,j)=r(1)*AI(1,1)+r(2)*AI(2,1)+r(3)*AI(3,1)
                  TI1(2,j)=r(1)*AI(1,2)+r(2)*AI(2,2)+r(3)*AI(3,2)
                  TI1(3,j)=r(1)*AI(1,3)+r(2)*AI(2,3)+r(3)*AI(3,3)
               end if

!_______________ check the position for equivalence with others
               do kk=1,j-1
                  r(1)=TI1(1,j)-TI1(1,kk)
                  r(2)=TI1(2,j)-TI1(2,kk)
                  r(3)=TI1(3,j)-TI1(3,kk)
                  if(ask_equiv(r,BI,3,tiny_equiv)) then
                     write(*,*) &
                       'ERROR! Current atom is equivalent to ',kk,' !'
                     j=j-1
                     go to 16
                  end if
               end do

            end do
         end do
         ITI_prim=j
         Atom_Positions=.true.

![5]...... primitive cell -> supercell extention matrix: direct method

      ELSE IF(cha2(l0:).eq.'5') THEN

 33      write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'
 3       write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=3) (IJ(1,j),j=1,3)
         write(8,*)  (IJ(1,j),j=1,3)
 4       write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=4) (IJ(2,j),j=1,3)
         write(8,*) (IJ(2,j),j=1,3)
 5       write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=5) (IJ(3,j),j=1,3)
         write(8,*) (IJ(3,j),j=1,3)
         MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) - &
              IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) + &
              IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         write(*,*) 'cell ==> supercell extention = ',MG_luc
         if(abs(MG_luc).lt.tiny_equiv) then
            write(*,*) 'ERROR! Zero extention!'
            go to  33
         end if
         ITI=ITI_prim*MG_luc
         do K=1,3
            do K1=1,3
               AJ(K,K1)=0.0
               do K2=1,3
                  write(*,*) '===>  ',k,k1,k2
                  write(*,*) AJ(K,K1)
                  write(*,*) IJ(K,K2)
                  write(*,*) AI(K2,K1)
                  AJ(K,K1)=AJ(K,K1)+IJ(K,K2)*AI(K2,K1)
               end do
            end do
         end do
         call INVER(AJ,BJ)
         SuperCellVectors=.true.

![6]...... primitive cell -> supercell extention matrix: by giving
!          supercell lattice vectors

      ELSE IF(cha2(l0:).eq.'6' .and. Basic_Primitive) THEN

         call latt_type(2)

!_________check if the vectors AJ are some linear combinations
!     of the primitive vectors, AI

         do i=1,3
            do j=1,3
               IJ(i,j)=AJ(i,1)*BI(j,1)+AJ(i,2)*BI(j,2)+AJ(i,3)*BI(j,3)
            end do
         end do
         call INVER(AJ,BJ)
         aMG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) - &
              IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) + &
              IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         MG_luc=nint(aMG_luc)
         write(*,*) 'cell ==> supercell extention = ',MG_luc
         if(abs(MG_luc-aMG_luc).gt.tiny_equiv) then
            write(*,*)'IMPORTANT! Your supercell turns out to be'
            write(*,*)'    inconsistent with your primitive cell!'
            write(*,*)'------- Try again! --------'
            SuperCellVectors=.false.
            go to 21
         end if
         ITI=ITI_prim*MG_luc
         SuperCellVectors=.true.

![7]...... finally generate the supercell by employing all internal
!          translations TRAN

      ELSE IF(cha2(l0:).eq.'7' .and. SuperCellVectors .and. &
        Basic_Primitive .and. NumAtomsSpecies .and. Atom_Positions) THEN

         if(ITI.gt.N0LT) then
            write(*,*)'ERROR! ITI > N0LT=',N0LT,' in tetr_pram.inc'
            Yes_Cell=.false.
            go to 21
         end if

!____________ generate internal translations
         call LACE(MG_luc,iErr)

!____________ generate positions of all atoms in the supercell
         j=0
         j1=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN_prim(k)
               j1=j1+1
               do k1=1,MG_luc
                  j=j+1
                  R(1)=TRAN(k1,1)+TI1(1,j1)
                  R(2)=TRAN(k1,2)+TI1(2,j1)
                  R(3)=TRAN(k1,3)+TI1(3,j1)
                  if (origin) call reducn(R,AJ,BJ)
                  TI(1,j)=R(1)
                  TI(2,j)=R(2)
                  TI(3,j)=R(3)
               end do
            end do
            NspN(k)=NspN_prim(k)*MG_luc
         end do
         Yes_Cell=.true.

!___________ constract all lattice sites  and write geom.xyz
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

![P].... finish: continue with the current setting

      ELSE IF(cha2(l0:).eq.'P' .and. Yes_Cell) THEN

         if(exist) write(*,*) 'WARNING! Previous setting will be lost!'

         return

![S].... create geometry/k-points file

!      ELSE IF(cha2(l0:).eq.'S' .and. Yes_Cell) THEN

!         write(*,*)'... writing geometry and k-points ...'
!         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

![Q].... finish: quit, restore the previous setting if exist

      ELSE IF(cha2(l0:).eq.'Q') THEN

         if(exist) &
         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine build_lat

      subroutine latt_type(iask)
!.....................................................................
!     It chooses 1 of 14 possible Bravais lattices. In addition:
! iask=0 - (primitive UC case) generates direct lattice basic vectors;
! iask=2 - (supercell case) generates direct lattice basic vectors
!.....................................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: AX(3,3)
      character :: answer,type*3,system1*2
      real(8),parameter :: tiny=0.00001d0
!
      integer number,i,j,iask
      real(8) a00,b00,c00,alpha,beta,gamma,d00

 1    write(*,*)'--------------------------------------------------'
      write(*,*)'--------- Choose one Bravais lattices: -----------'
      write(*,*)'--------------------------------------------------'
      write(*,*)'  0.Manually'
      write(*,*)'  1.Triclinic system'
      write(*,*)'  2.Monoclinic system. Simple lattice'
      write(*,*)'  3.Monoclinic system. Side-centered lattice'
      write(*,*)'  4.Orthorhombic system. Simple lattice'
      write(*,*)'  5.Orthorhombic system. Fcc-1 lattice'
      write(*,*)'  6.Orthorhombic system. Fcc-2 lattice'
      write(*,*)'  7.Orthorhombic system. Bcc lattice'
      write(*,*)'  8.Tetragonal system. Simple lattice'
      write(*,*)'  9.Tetragonal system. Bcc-1 lattice'
      write(*,*)' 10.Tetragonal system. Bcc-2 lattice (diff.setting)'
      write(*,*)' 11.Cubic system. Simple lattice'
      write(*,*)' 12.Cubic system. Bcc lattice'
      write(*,*)' 13.Cubic system. Fcc lattice'
      write(*,*)' 14.Rhombohedral system.'
      write(*,*)' 15.Hexagonal system'
      write(*,*)
      write(*,*)'-------> Choose the appropriate number ------->'
      read(*,*,err=5) number ; write(8,*) number
 2    if(number.eq.0) then
 51      write(*,*)'Give the first lattice vector as x,y,z:'
         read(*,*,err=51) (AX(1,i),i=1,3)
         write(8,*)  (AX(1,i),i=1,3)
 52      write(*,*)'Give the second lattice vector as x,y,z:'
         read(*,*,err=52) (AX(2,i),i=1,3)
         write(8,*)  (AX(2,i),i=1,3)
 53      write(*,*)'Give the third lattice vector as x,y,z:'
         read(*,*,err=53) (AX(3,i),i=1,3)
         write(8,*)  (AX(3,i),i=1,3)
         do i=1,3
            do j=1,3
               if(iask.eq.0) then
                  AI(i,j)=AX(i,j)
               else
                  AJ(i,j)=AX(i,j)
               end if
            end do
         end do
         go to 15
      else if(number.eq.1) then
         system1='Tr'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=(            a,            0,           0 )'
         write(*,*)'A2=( b*cos(alpha), b*sin(alpha),           0 )'
         write(*,*)'A3=(  c*cos(beta),  c*f(angles), c*g(angles) )'
         write(*,*)
 21      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=21) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c,alpha,beta,gama}'
         write(6,*)'[lengths - Angstroms; angles - degrees]:'
         read(*,*,err=10) a00,b00,c00,alpha,beta,gamma
         write(8,*) a00,b00,c00,alpha,beta,gamma
      else if(number.eq.2) then
         system1='Mo'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( a, d, 0 )'
         write(*,*)'A2=( 0, b, 0 )'
         write(*,*)'A3=( 0, 0, c )'
         write(*,*)
 22      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=22) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c,d} (Angstroms):'
         read(*,*,err=10) a00,b00,c00,d00
         write(8,*)  a00,b00,c00,d00
      else if(number.eq.3) then
         system1='Mo'
         type='SC0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( a, b,  0 )'
         write(*,*)'A2=( 0, c, -d )'
         write(*,*)'A3=( 0, c,  d )'
         write(*,*)
 23      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=23) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c,d} (Angstroms):'
         read(*,*,err=10) a00,b00,c00,d00
         write(8,*) a00,b00,c00,d00
      else if(number.eq.4) then
         system1='Or'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( a, 0, 0 )'
         write(*,*)'A2=( 0, b, 0 )'
         write(*,*)'A3=( 0, 0, c )'
         write(*,*)
 24      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=24) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c} (Angstroms):'
         read(*,*,err=10) a00,b00,c00 ; write(8,*) a00,b00,c00
      else if(number.eq.5) then
         system1='Or'
         type='FC1'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=(  a, b, 0 )'
         write(*,*)'A2=( -a, b, 0 )'
         write(*,*)'A3=(  0, 0, c )'
         write(*,*)
 25      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=25) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c} (Angstroms):'
         read(*,*,err=10) a00,b00,c00 ; write(8,*) a00,b00,c00
      else if(number.eq.6) then
         system1='Or'
         type='FC2'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( 0, b, c ) '
         write(*,*)'A2=( a, 0, c )'
         write(*,*)'A3=( a, b, 0 )'
         write(*,*)
 26      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=26) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c} (Angstroms):'
         read(*,*,err=10) a00,b00,c00 ; write(8,*) a00,b00,c00
      else if(number.eq.7) then
         system1='Or'
         type='BC0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( -a,  b,  c )'
         write(*,*)'A2=(  a, -b,  c )'
         write(*,*)'A3=(  a,  b, -c )'
         write(*,*)
 27      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=27) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,b,c} (Angstroms):'
         read(*,*,err=10) a00,b00,c00 ; write(8,*) a00,b00,c00
      else if(number.eq.8) then
         system1='Tt'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( a, 0, 0 )'
         write(*,*)'A2=( 0, a, 0 )'
         write(*,*)'A3=( 0, 0, c )'
         write(*,*)
 28      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=28) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,c} (Angstroms):'
         read(*,*,err=10) a00,c00 ; write(8,*) a00,c00
      else if(number.eq.9) then
         system1='Tt'
         type='BC1'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( -a,  a,  c )'
         write(*,*)'A2=(  a, -a,  c )'
         write(*,*)'A3=(  a,  a, -c )'
         write(*,*)
 29      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=29) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,c} (Angstroms):'
         read(*,*,err=10) a00,c00 ; write(8,*) a00,c00
      else if(number.eq.10) then
         system1='Tt'
         type='BC2'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( 0, a, c )'
         write(*,*)'A2=( a, 0, c )'
         write(*,*)'A3=( a, a, 0 )'
         write(*,*)
 30      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=30) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,c} (Angstroms):'
         read(*,*,err=10) a00,c00 ; write(8,*) a00,c00
      else if(number.eq.11) then
         system1='Cu'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( a, 0, 0 )'
         write(*,*)'A2=( 0, a, 0 )'
         write(*,*)'A3=( 0, 0, a )'
         write(*,*)
 31      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=31) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a} (Angstroms):'
         read(*,*,err=10) a00 ; write(8,*) a00
      else if(number.eq.12) then
         system1='Cu'
         type='BC0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( -a,  a,  a )'
         write(*,*)'A2=(  a, -a,  a )'
         write(*,*)'A3=(  a,  a, -a )'
         write(*,*)
 32      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=32) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a} (Angstroms):'
         read(*,*,err=10) a00 ; write(8,*) a00
      else if(number.eq.13) then
         system1='Cu'
         type='FC0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( 0, a, a )'
         write(*,*)'A2=( a, 0, a )'
         write(*,*)'A3=( a, a, 0 )'
         write(*,*)
 33      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=33) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a} (Angstroms):'
         read(*,*,err=10) a00 ; write(8,*) a00
      else if(number.eq.14) then
         system1='Rh'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=(    a,            0, c )'
         write(*,*)'A2=( -a/2,  sqrt(3)/2*a, c )'
         write(*,*)'A3=( -a/2, -sqrt(3)/2*a, c )'
         write(*,*)
 34      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=34) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,alpha}'
         write(6,*)'[ lengthes - Angstroms; angles - degrees ]:'
         read(*,*,err=10) a00,alpha ; write(8,*) a00,alpha
      else if(number.eq.15) then
         system1='He'
         type='SL0'
         write(6,*)'The basic lattice vectors are:'
         write(*,*)
         write(*,*)'A1=( a*sqrt(3)/2, -a/2, 0 )'
         write(*,*)'A2=(           0,    a, 0 )'
         write(*,*)'A3=(           0,    0, c )'
         write(*,*)
 35      write(*,*)'Use this setting (y,Y/other char)?'
         read(*,'(a)',err=35) answer ; write(8,'(a)') answer
         if(answer.ne.'Y'.and.answer.ne.'y') go to 1
         write(6,*)'UC is built from {a,c} (Angstroms):'
         read(*,*,err=10) a00,c00 ; write(8,*) a00,c00
      else
         go to 5
      end if
!
!.........generate direct lattice vectors for the primitive UC
      alpha=alpha*pi/180.0 ; beta=beta*pi/180.0 ; gamma=gamma*pi/180.0
      call DirLatt(a00,b00,c00,d00,alpha,beta,gamma,iask,system1,type)
 15   if(iask.eq.0) then
         write(*,*)'... Lattice vectors for the primitive UC ...'
         write(*,'(a,5x,3(f10.5,x))') 'AI(1):   ',(AI(1,i),i=1,3)
         write(*,'(a,5x,3(f10.5,x))') 'AI(2):   ',(AI(2,i),i=1,3)
         write(*,'(a,5x,3(f10.5,x))') 'AI(3):   ',(AI(3,i),i=1,3)
      else
         write(*,*)'... Lattice vectors for the supercell ...'
         write(*,'(a,5x,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,5x,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,5x,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      end if
!
!____ ask about vectors
 4    write(*,*) &
           'Did you wish just these to generate (Y,y/other char)?'
      read(*,'(a)',err=7) answer ; write(8,'(a)') answer
      if(answer.ne.'y'.and.answer.ne.'Y') go to 1
      return
!........... errors
 5    write(*,*)'Incorrect item number! Try again!'
      go to 1
 7    write(*,*)'Error! Try again!'
      go to 4
 10   write(*,*)'Error! Try again!'
      go to 2
      end subroutine latt_type

      subroutine DirLatt(a00,b00,c00,d00,alpha,beta,gama,iask, &
                                                        system1,type)
!.......................................................................
!      Direct lattice basic translation vectors AI are built.
!.......................................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: AI1(3,3)
      character :: system1*2,type*3
!
      integer :: iask,i,j
      real(8) :: a00,b00,c00,alpha,beta,gama,d00,aN
!
      do i=1,3
         do j=1,3
            AI1(i,j)=0.0
         end do
      end do
!
!.......... Triclinic system
      if(System1.eq.'Tr') then
          write(6,*)'WARNING!..UC is built from {a,b,c,alpha,beta,gama}'
          aN=(cos(gama)-cos(alpha)*cos(beta))/sin(alpha)
          AI1(1,1)=a00
            AI1(2,1)=b00*cos(alpha)
            AI1(2,2)=b00*sin(alpha)
              AI1(3,1)=c00*cos(beta)
              AI1(3,2)=c00*aN
              AI1(3,3)=c00*sqrt(sin(beta)**2-aN*aN)
!
!.......... Monoclinic system
      else if(System1.eq.'Mo') then
          write(6,*)'WARNING!..UC is built from {a,b,c,d} ONLY'
!___________________ Simple lattice
          if(Type.eq.'SL0') then
             AI1(1,1)=a00
             AI1(1,2)=d00
               AI1(2,2)=b00
                 AI1(3,3)=c00
!___________________ Side-centered
          else
             AI1(1,1)=a00
             AI1(1,2)=b00
               AI1(2,2)=c00
               AI1(2,3)=-d00
                 AI1(3,2)=c00
                 AI1(3,3)=d00
          end if
!
!.......... Orthorhombic system
      else if(System1.eq.'Or') then
          write(6,*)'WARNING!..UC is built from {a,b,c} ONLY'
!___________________ Simple lattice
          if(Type.eq.'SL0') then
             AI1(1,1)=a00
               AI1(2,2)=b00
                 AI1(3,3)=c00
!___________________ Face-centered (1) lattice
          else if(Type.eq.'FC1') then
             AI1(1,1)=a00
             AI1(1,2)=b00
               AI1(2,1)=-a00
               AI1(2,2)= b00
                 AI1(3,3)=c00
!___________________ Face-centered (2) lattice
          else if(Type.eq.'FC2') then
             AI1(1,2)=b00
             AI1(1,3)=c00
               AI1(2,1)=a00
               AI1(2,3)=c00
                 AI1(3,1)=a00
                 AI1(3,2)=b00
!___________________ Body-centered lattice
          else
             AI1(1,1)=-a00
             AI1(1,2)= b00
             AI1(1,3)= c00
               AI1(2,1)= a00
               AI1(2,2)=-b00
               AI1(2,3)= c00
                 AI1(3,1)= a00
                 AI1(3,2)= b00
                 AI1(3,3)=-c00
          end if
!
!.......... Tetragonal system
      else if(System1.eq.'Tt') then
          write(6,*)'WARNING!..UC is built from {a,c} ONLY'
!___________________ Simple lattice
          if(Type.eq.'SL0') then
             AI1(1,1)=a00
               AI1(2,2)=a00
                 AI1(3,3)=c00
!___________________ Body-centered lattice (1)
          else if(Type.eq.'BC1') then
             AI1(1,1)=-a00
             AI1(1,2)= a00
             AI1(1,3)= c00
               AI1(2,1)= a00
               AI1(2,2)=-a00
               AI1(2,3)= c00
                 AI1(3,1)= a00
                 AI1(3,2)= a00
                 AI1(3,3)=-c00
!___________________ Body-centered lattice (2)
          else if(Type.eq.'BC2') then
             AI1(1,2)=a00
             AI1(1,3)=c00
               AI1(2,1)=a00
               AI1(2,3)=c00
                 AI1(3,1)=a00
                 AI1(3,2)=a00
          end if
!
!.......... Cubic system
      else if(System1.eq.'Cu') then
          write(6,*)'WARNING!..UC is built from {a} ONLY'
!___________________ Simple lattice
          if(Type.eq.'SL0') then
             AI1(1,1)=a00
               AI1(2,2)=a00
                 AI1(3,3)=a00
!___________________ Body-centered lattice
          else if(Type.eq.'BC0') then
             AI1(1,1)=-a00
             AI1(1,2)= a00
             AI1(1,3)= a00
               AI1(2,1)= a00
               AI1(2,2)=-a00
               AI1(2,3)= a00
                 AI1(3,1)= a00
                 AI1(3,2)= a00
                 AI1(3,3)=-a00
!___________________ Face-centered lattice
          else
             AI1(1,2)=a00
             AI1(1,3)=a00
               AI1(2,1)=a00
               AI1(2,3)=a00
                 AI1(3,1)=a00
                 AI1(3,2)=a00
          end if
!
!.......... Rhombohedral system
      else if(System1.eq.'Rh') then
           write(6,*)'WARNING!..UC is built from {a,c} ONLY'
           AI1(1,1)=a00
           AI1(1,3)=c00
             AI1(2,1)=-a00*0.5
             AI1(2,2)= sqrt(3.0)/2.0*a00
             AI1(2,3)= c00
               AI1(3,1)=-a00*0.5
               AI1(3,2)=-sqrt(3.0)/2.0*a00
               AI1(3,3)= c00
!
!.......... Hexagonal system
      else
           write(6,*)'WARNING!..UC is built from {a,c} ONLY'
           AI1(1,1)=a00*sqrt(3.0)*0.5
           AI1(1,2)=-a00*0.5
             AI1(2,2)=a00
               AI1(3,3)=c00
      end if
!
!............ AI1 --> AI (iask=0) or AJ (iask=2)
      do i=1,3
         do j=1,3
           if(iask.eq.0) then
             AI(i,j)=AI1(i,j)
           else
             AJ(i,j)=AI1(i,j)
           end if
         end do
      end do
      return
      end subroutine DirLatt

      subroutine LACE(MG_luc,iErr)
!.....................................................................
!  construction of all MMG internal LUC translations :
!                  TRAN(number,component)
!.....................................................................
      use real8
      use tetrag1
      implicit none
      real(8) ::  x(3)
!
      integer :: iErr, MG_luc,L,nop,N,N1,N2,N3,now,iAsk
      real(8) :: vol_UC,vol_LUC

      iErr=0

!....... work out the extention L

      vol_UC=AI(1,1)*(AI(2,2)*AI(3,3)-AI(3,2)*AI(2,3))- &
             AI(2,1)*(AI(1,2)*AI(3,3)-AI(3,2)*AI(1,3))+ &
             AI(3,1)*(AI(1,2)*AI(2,3)-AI(1,3)*AI(2,2))
      vol_LUC=AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(3,2)*AJ(2,3))- &
              AJ(2,1)*(AJ(1,2)*AJ(3,3)-AJ(3,2)*AJ(1,3))+ &
              AJ(3,1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2))
      L=nint( abs(vol_LUC/vol_UC) )
      MG_luc=L
      write(*,*)'.... current extention = ',L
      if(L.gt.MG00) then
         iErr=1 ;  return
      end if

!....... find all internal translations that are different by modulo
!        wrt large translations AJ

      nop=0
      N=-1
30    N=N+1
      now=0
      do N3=-N,N
         do  N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
!
!____________ over the reciprocal lattice
               x(1) = N1*AI(1,1) + N2*AI(2,1) + N3*AI(3,1)
               x(2) = N1*AI(1,2) + N2*AI(2,2) + N3*AI(3,2)
               x(3) = N1*AI(1,3) + N2*AI(2,3) + N3*AI(3,3)

!_____________ reduce to the [0,1) interval in fractional coordinates
!              wrt to the large cell AJ
               call reducn2(x,AJ,BJ)

!____________ check if this is already there
               if(nop.ge.1) then
                  call ask(x,BJ,TRAN,MG00,nop,IASK)
                  if(IASK.eq.1) go to 250
               end if
               nop=nop+1 ; now=now+1
               if(nop.gt.MG00) then
                  write(*,*) &
                    'ERROR! No of translations > MG00 in tetr_param.inc'
                  iErr=1 ; return
               end if

!_____________ save
               TRAN(nop,1:3)=x(1:3)

 250        end do
         end do
      end do
      if(now.gt.0) go to 30
      if(nop.ne.MG_luc) then
         write(*,*)'PROBLEM: MG_luc = ',MG_luc,' =/= nop=',nop
         iErr=1
      end if
      end subroutine LACE

