        subroutine permut(GfamX,PgrX,MGx,KGx,iErr)
!....................................................................
!..... From the input:
!   GfamX - the group family (Oh or D6h);
!   PgrX  - the group label  (Oh,Td,C2. etc.);
!   MGx   - the order of the group (might be incorrect - ignored);
!   KGx   - the list of elements (from the whole list in C() ):
!           might be incomplete (but the number must be equal to or
!           smaller than MGx).
!.....................................................................
!...... The routine considers the group label and the elements  ......
!...... specified in the input and using this information:      ......
!......  - chooses the whole group PgrX matching this elements; ......
!......  - takes all the group elements KGx in the correct order......
!......  - takes the correct order of the group MGx             ......
!.....................................................................
!   The number of elements in the input needn't be equal to the
!   actual number of them in the group; it is sufficient to specify
!   only the group generators, indicating (by an axis) the direction
!   of the group, etc.
!....................................................................
!   iErr = 1 in the case of FATAL errors; otherwise, iErr=0
!....................................................................
      use real8
      use pgroup
      use symgenv
      implicit none
      character :: GfamX*3,PgrX*3
      integer :: KGx(*)
!
      integer :: iG,MGx,iErr,NofE,k,k0
!
!................ Choose the family first: 1 (for Oh) or 2 (for D6h)
!.......... Try to check all Oh groups: all elements are in NGROUP(k,iG)
!              and all names are in GNAM(iG,1)
      do 150 iG=1,98
         if(GNAM(iG,1).ne.PgrX) go to 150
!___________________ determine the number of elements NofE
         NofE=48
         do k=2,48
            if(NGROUP(k,iG).eq.0) then
               NofE=k-1
               go to 60
            end if
         end do
!________________check the elements: loop over all elements specified
!                    in the input (group generators, at least)
 60      do 70 k=1,MGx
            do k0=1,NofE
               if(NGROUP(k0,iG).eq.KGx(k)) go to 70
            end do
            go to 150
 70      end do
!_______________o.k., the first found group is iG:
         GfamX='Oh '
         PgrX=GNAM(iG,1)
         MGx=NofE
         do k=1,MGx
            KGx(k)=NGROUP(k,iG)
         end do
         go to 160
 150  end do
!
!_______ Try to check all D6h groups: all elements are in NGROU1(k,iG)
!     and all names are in GNAM(iG,2)
      do 100 iG=1,54
         if(GNAM(iG,2).ne.PgrX) go to 100
!___________________determine the number of elements NofE
         NofE=24
         do k=2,24
            if(NGROU1(k,iG).eq.0) then
               NofE=k-1
               go to 40
            end if
         end do
!________________check the elements: loop over all elements specified
!     in the input
 40      do 50 k=1,MGx
            do k0=1,NofE
               if(NGROU1(k0,iG).eq.KGx(k)) go to 50
            end do
            go to 100
 50      end do
!_______________o.k., the first found group is iG:
         GfamX='D6h'
         PgrX=GNAM(iG,2)
         MGx=NofE
         do k=1,MGx
            KGx(k)=NGROU1(k,iG)
         end do
         go to 160
 100  end do
      go to 200
!.............. print the group and all its elements
 160  write(*,*)'....... The group family is '//GfamX//' ...'
!      write(*,*)'....... The group is recognized and it is found'//
!     ,                                      ' to be '//PgrX//' ...'
!      write(*,*)'....... The group elements are:'
!      write(*,1)(KGx(k),NAZ(KGx(k)),k=1,MGx)
! 1    format(8(i2,'[',a4,'] '))
!      write(*,*)'..O.K.!.Identification of the group processed '//
!     &                                                  'correctly! ...'
      iErr=0
      return
!.............. error messages .........................................
 200  write(*,*)'.FATAL!.<Permut>.The group contradicts with the '// &
                                                           'elements!'
       iErr=1
       return
      end subroutine permut

