      subroutine point_gr()
!.....................................................................
!    Choose interactively your point group (an element by element)
! amongst all elements of the crystal class obtained from the direct
! lattice vectors, AJ
!.....................................................................
      use real8
      use tetrag1
      use pgroup
      implicit none
      character :: answer*1,iAdopt(48)*1,Group0*3
!
      integer :: i,item,ig,ig1,iB,igg,iDo,num
!
!........ obtain the group GroupB of the Bravais lattice (crystal
!         class) with MGb, KGb
!........ obtain the laggest symmorphic group GroupN of the system
!         with MGp, KGp;
!
      call check_symmetry('y','y')
!
!________ Adopt(B-list number) - shows (by '*') whether every element
!         from the GroupB has been already chosen or not (' ')
      do i=1,MGb
        iAdopt(i)=' '
      end do
!
!.....................................................................
!........... build the group .........................................
!.....................................................................
!
      write(*,*)'.....................................................'
      write(*,*)'....... NOW WE ARE BUILDING THE LUC POINT GROUP .....'
      write(*,*)'.....................................................'
 5    write(*,*)'Choose an option:'
      write(*,*)
      write(*,*)'  1. Adopt the largest symmorphic group '//GroupN
      write(*,*)'  2. Proceed generation from '//GroupN
      write(*,*)'  3. Start generation from scratch'
      write(*,*)'  4. Stop [quit tetr]'
      write(*,*)
      write(*,*)'----------> Choose the appropriate number:'
      read(*,*,err=5) item ; write(8,*) item
      if(item.eq.1) then
         return
      else if(item.eq.2) then
         if(GroupN.eq.GroupB) return
         ig=MGp
         ig1=ig
      else if(item.eq.3) then
         ig=2
         KGp(1)=1
         KGp(2)=48
         GroupN='Ci '
         ig1=ig
      else if(item.eq.4) then
         stop "I owe you nothing!"
      else
         write(*,*)'Error! try again!'
         go to 5
      end if
!
!.............. proceed with generation of the group GroupN
!
!______________ choose iAdopt(element) for all elements of groupB
      iDo=0
 1    do 7 i=1,ig1
        do iB=1,MGb
          if(KGb(iB).eq.KGp(i)) then
            igg=ig-1
            if(iDo.eq.0) igg=ig
            if(i.gt.igg) then
              iAdopt(iB)='+'
            else
              iAdopt(iB)='*'
            end if
            go to 7
          end if
        end do
 7    continue
!
!______________ plot a tabel of elements
      write(*,*)'______ Your crystal class group is '//GroupB
      write(*,*)'       with elements:'
      write(*,'(6(a2,i2,a6,3x))') &
                       ( '['//iAdopt(i),i,'] '//NAZ(KGb(i)),i=1,MGb )
      write(*,*)'______ So far your system group is '//GroupN
      write(*,*)
 9    write(*,*)'Stop (S,s), a step Back (B,b), Proceed (other char)?'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=9) answer ; write(8,'(a)') answer
      if(answer.eq.'B'.or.answer.eq.'b') then
        if(iDo.eq.0) then
          write(*,*)'Hi! Nothing undo! Ignored!'
          go to 9
        end if
        do i=ig,ig1
          do iB=1,MGb
            if(KGb(iB).eq.KGp(i)) iAdopt(iB)=' '
          end do
        end do
        GroupN=Group0
        ig=ig-1
        ig1=ig
        iDo=0
        go to 1
      else if(answer.eq.'s'.or.answer.eq.'S') then
        MGp=ig1
        return
      else
        if(GroupN.eq.GroupB) then
          write(*,*)'WARNING! There are NO additional elements!'
          go to 1
        end if
        Group0=GroupN
        ig=ig1
        go to 11
      end if
!
!......... ask for additional elements ........................
 11   write(*,*)'Using this list of group elements, enter a new one'
      write(*,*)'by quoting its number (elements marked by * or + '
      write(*,*)'are already in your group!):'
      read(*,*,err=1) num ; write(8,*) num
      if(num.lt.1.or.num.gt.MGb) then
        write(*,*)'Error! This number is out of range!'
        go to 1
      end if
      if(iAdopt(num).eq.'*'.or.iAdopt(num).eq.'+') then
        write(*,*)'This element is already in your group. Ignored!'
        go to 1
      end if
!
!_____ try to add it to the KGp-set
      iDo=1
      ig=ig+1
      KGp(ig)=KGb(num)
!
!__________ multiply all (ig) elements built so far to each
!           other to produce a complete group with ig1 elements
!           and with C-list numbers stored in KGb
!
      call gener_prod(ig,ig1,KGp)
      call give_name(ig1,KGp,GroupN)
      go to 1
      end subroutine point_gr

      subroutine system_gr(inver_yes)
!................ ....................................................
!    BY applying all the elements of GroupB to the vectors of
! sublattices, TI, the largest symmorphic crystal point group is
! obtained. All group elements are stored in KGp(element), their
! order is MGp and the name is GroupN.
!....................................................................
! inver_yes = 'y' - the inversion will be included into the system
!                   group GroupN (for the DOS) in any rate;
! inver_yes = 'n' - the inversion won't be included into GroupN
!                  (when invoked from 'change' just to test the group)
!.....................................................................
      use real8
      use tetrag1
      use pgroup
      implicit none
      real(8) :: r(3)
      integer :: iSort(N0LT)
      logical :: iCheck(48),ask_coinc
      character :: inver_yes
!
      integer :: i,j,k,iGb,ig,ic,jGb,jG,ig1,kk
!
!...... fill in iSort(sublattice) by atomic sorts
!
      k=0
      do i=1,Nsp
        do j=1,NspN(i)
          k=k+1
          iSort(k)=i
        end do
      end do
!
!...... set iCheck to .false. for all the elements
!
      do iGb=1,MGb
        iCheck(iGb)=.false.
      end do
!
!...... a loop over all still unadopted group elements stored in
!   C( , ,i); it is done by cycles since elements adopted are
!   multiplied by each other to produce a group every time.
!     ig - counts adopted elements from the C-list; iCheck = .true.
!     ic - counts (for every cycle) number of adopted elements;
!   The process is continued unless ic=0.
!
      ig=0
 10   ic=0
      do 100 jGb=1,MGb
        if(iCheck(jGb)) go to 100
        jG=KGb(jGb)
        if(jG.eq.48 .and. inver_yes.eq.'y') go to 50
!        write(13,'(a,i3,a,i3)') '........ jGb=',jgb,' jG=',jg
!
!__________ loop over all sublattices
        do j=1,ITI
          r(1)=C(1,1,jG)*TI(1,j)+C(2,1,jG)*TI(2,j)+C(3,1,jG)*TI(3,j)
          r(2)=C(1,2,jG)*TI(1,j)+C(2,2,jG)*TI(2,j)+C(3,2,jG)*TI(3,j)
          r(3)=C(1,3,jG)*TI(1,j)+C(2,3,jG)*TI(2,j)+C(3,3,jG)*TI(3,j)
          if(.not.ask_coinc(r,iSort(j),iSort,kk)) go to 100
!          if(answer.eq.'n') go to 100
        end do
!
!__________ yes, this element, jGb, should be adopted
 50     ic=ic+1
        ig=ig+1
        KGp(ig)=jG
!
!__________ yes, multiply all (ig) elements built so far to each
!           other to produce a complete group with ig1 elements
!           and with C-list numbers stored in KGb
!
        call gener_prod(ig,ig1,KGp)
!
!__________ set iCheck for all adopted elements
        do 60 i=1,ig1
          do j=1,MGb
            if(KGp(i).eq.KGb(j)) then
              iCheck(j)=.true.
              go to 60
            end if
          end do
 60     continue

 100  continue
!
!....... new cycle?
      if(ic.gt.0) go to 10
!
!.......... set up finally MGp and GroupN
      MGp=ig1
      call give_name(ig1,KGp,GroupN)
      return
      end subroutine system_gr

      subroutine bravais()
!....................................................................
!    BY applying all the point group elements to the direct lattice
! vectors, AJ, the crystal class point group is obtained.
! All group elements are stored in KGb(element), their order is MGb
! and the name is GroupB.
!....................................................................
      use real8
      use tetrag1
      use pgroup
      implicit none
      real(8) :: r(3)
      logical :: iCheck(64),ask_equiv
!
      integer :: iG,ic,jG,j,i,ig1
!
!...... set iCheck to .false. for all the elments
!
      do iG=1,64
        iCheck(iG)=.false.
      end do
!
!...... a loop over all still unadopted groups elements stored in
!   C( , ,i); it is done by cycles since elements adopted are
!   multiplied by each other to produce a group every time.
!     ig - counts adopted elements from the C-list; iCheck = .true.
!     ic - counts (for every cycle) number of adopted elements;
!   The process is continued unless ic=0.
!
      ig=0
 10   ic=0
      do 100 jG=1,64
        if(iCheck(jG)) go to 100
!
!__________ loop over three lattice vectors
        do j=1,3
           r(1)=C(1,1,jG)*AJ(j,1)+C(2,1,jG)*AJ(j,2)+C(3,1,jG)*AJ(j,3)
           r(2)=C(1,2,jG)*AJ(j,1)+C(2,2,jG)*AJ(j,2)+C(3,2,jG)*AJ(j,3)
           r(3)=C(1,3,jG)*AJ(j,1)+C(2,3,jG)*AJ(j,2)+C(3,3,jG)*AJ(j,3)
           if(.not.ask_equiv(r,BJ,3,tiny_equiv)) go to 100
        end do
!
!__________ yes, this element, jG, should be adopted
        ic=ic+1
        ig=ig+1
        KGb(ig)=jG
!
!__________ yes, multiply all (ig) elements built so far to each
!           other to produce a complete group with ig1 elements
!           and with C-list numbers stored in KGb
!
        call gener_prod(ig,ig1,KGb)
!
!__________ set iCheck for all adopted elements
        do i=1,ig1
          iCheck(KGb(i))=.true.
        end do
 100  continue
!
!....... new cycle?
      if(ic.gt.0) go to 10
!
!.......... set up finally MGb and GroupB
      MGb=ig1
      call give_name(ig1,KGb,GroupB)
      return
      end subroutine bravais

      subroutine gener_prod(ig,ig1,KGx)
!....................................................................
!   It tries to build a point group from ig generators
! currently available in KGx(i), i=1,..,ig , and replies with:
! ig1 - the order of the group generated by all possible products
!       of elements KGx(i).
! KGx(i), i=1,...,ig1 - for all elements including also new ones;
!....................................................................
      use real8
      implicit none
      logical :: iCheck(48)
      integer :: KGx(48)
!
      integer :: ig,ig1,ig0,j,j1,jK,n
!
!...... initialize iCheck by .true. if an element in KGp(i) is present,
! and by .false. if not.
!
      ig1=ig
      do j=1,48
        iCheck(j)=.true.
        if(j.gt.ig1) iCheck(j)=.false.
      end do
      ig0=ig1
!
!.......... double loop over elements with iCheck=.true.:
!  by myltiplication, new elements are obtained increasing the
!  range of loops, untill all elements of the group will be eghausted.
!
 10   do 100 j=1,48
        if(.not.iCheck(j)) go to 100
        do 90 j1=1,48
          if(.not.iCheck(j1)) go to 100
!___________ product of KGx(j)*KGx(j1) is jK (from the C-list)
          call Find_Rot(j,j1,jK,KGx)
!___________ check whether it is a new element
          do 20 n=1,48
            if(.not.iCheck(n)) go to 20
            if(KGx(n).eq.jK) go to 90
 20       continue
          ig1=ig1+1
          iCheck(ig1)=.true.
          KGx(ig1)=jK
 90     continue
 100  continue
!
!________ check whether it is necessary to repeat the loops
      if(ig1.gt.ig0) then
          ig0=ig1
          go to 10
      end if
      return
      end subroutine gener_prod

      subroutine give_name(MGx,KGx,GroupX)
!....................................................................
! It gives:
! GroupX  - the group label to be checked with;
!..... From the input:
! KGx   - the list of generators (in terms of elements in C() );
! MGx   - the order of the generator set in KGx(i);
!....................................................................
      use real8
      use pgroup
      implicit none
      character :: GroupX*3
      integer :: KGx(48)
!
      integer :: iG,NofE,k,k0,MGx

!......................................................................
!   Find out the name of the group which uniqely corresponds to:
!                         KGx(i), i=1, .., MGx
!   Try one family after another: 1 (for Oh) or 2 (for D6h)
!......................................................................
!
!...........Try to check all Oh groups: all elements are in NGROUP(k,iG)
! and all names are in GNAM(iG,1)
!
      do 150 iG=1,98
!________ determine the number of elements NofE in the group iG
        NofE=N_of_E(iG,1)
        if(NofE.ne.MGx) go to 150
!________ check the elements
        do 70 k=1,MGx
            do k0=1,NofE
              if(NGROUP(k0,iG).eq.KGx(k)) go to 70
            end do
            go to 150
 70     continue
!________ o.k., the group found is iG:
        GroupX=GNAM(iG,1)
        go to 200
 150  end do
!
!....... Try to check all D6h groups: all elements are in NGROU1(k,iG)
!        and all names are in GNAM(iG,2)
!
      do 100 iG=1,54
!________ determine the number of elements NofE
        NofE=N_of_E(iG,2)
        if(NofE.ne.MGx) go to 100
!______________ check the elements
        do 50 k=1,MGx
           do k0=1,NofE
              if(NGROU1(k0,iG).eq.KGx(k)) go to 50
           end do
           go to 100
 50     end do
!_______________ o.k., the group found is iG:
        GroupX=GNAM(iG,2)
        go to 200
 100  end do
 200  return
      end subroutine give_name

      subroutine Find_Rot(I1,I2,K,KGx)
!.....................................................................
!     Seeks for the rotation K which results from the rotations I1*I2
!  (numbers I1,I2 are from the KGx list, while K is from the common
!  C() list).
!.....................................................................
      use real8
      use tetrag1
      use pgroup
      implicit none
      real(8) :: c1(3,3)
      integer :: KGx(48)
      real(8),parameter :: tiny=0.00001d0
!
      integer :: KGi1,KGi2,i,j,KGi,K,I1,I2

      KGi1=KGx(I1)
      KGi2=KGx(I2)
!.......... build the rotation I1*I2 --> c1
      do i=1,3
         do j=1,3
            c1(i,j)=C(i,1,KGi1)*C(1,j,KGi2)+C(i,2,KGi1)*C(2,j,KGi2)+ &
                 C(i,3,KGi1)*C(3,j,KGi2)
         end do
      end do
!........... find the appropriate rotation from the C() list
      do 20 KGi=1,64
         do i=1,3
            do j=1,3
               if(abs(C(i,j,KGi)-c1(i,j)).gt.tiny) go to 20
            end do
         end do
         K=KGi
         return
 20   end do
      return
      end subroutine Find_Rot

      subroutine elem_numb()
!.................................................................
!    Fills in N_of_E(98,2) by numbers of elements for all groups
!.................................................................
      use real8
      use pgroup
      implicit none
!
      integer :: iG,k

!  Try one family after another: 1 (for Oh) or 2 (for D6h)
!
!......... Start from all Oh groups: all elements are in NGROUP(k,iG)
!
      do 150 iG=1,98
        N_of_E(iG,1)=48
        do k=2,48
           if(NGROUP(k,iG).eq.0) then
              N_of_E(iG,1)=k-1
              go to 150
           end if
        end do
 150  continue
!
!....... Now, all D6h groups: all elements are in NGROU1(k,iG)
!
      do 250 iG=1,54
        N_of_E(iG,2)=24
        do k=2,24
           if(NGROU1(k,iG).eq.0) then
              N_of_E(iG,2)=k-1
              go to 250
           end if
        end do
 250  continue
      return
      end subroutine elem_numb
    
