module space
use sym_par
use tetr_param
implicit none
!      TRAN(number,component) - sites inside LUC (just for 1 species)
!      Vkp(#,xyz) - k-points (up to 2*pi) corresponding to the given
!                   UC -> LUC expansion (when system ='LATT-TRA')
!      Nvkp       - number of k-points (= extention)
!      kCompl(#)  = 0 if the k-point number # does not have the negative
!                     counterpart;
!                 = 1 if it has and is the original vector;
!                 =-1 is the negative of the original vector;
! Vk_rep(ir,xyz)  - k-vector corresponding to irrep ir (when system='LATT-TRA')
!
      real(8) ::  TRAN(MG00,3),Vkp(Nkpoint,3),Vk_rep(N0IR,3)
      integer :: Nvkp,kCmpl(Nkpoint)
!     common /spacegr/ TRAN,Vkp,Vk_rep, &
!                  Nvkp,kCmpl
end module space
