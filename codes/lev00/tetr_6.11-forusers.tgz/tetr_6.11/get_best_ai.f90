      subroutine get_best_AI(AJ,HH,KK,LL,IJ,xn,icase,iPrnt)
      use real8
      implicit none
!.....................................................................
!    A new set of unit cell (UC) direct lattice vectors AJ(#,xyz) of
! minimal length is built here from incoming basic vectors AJ(#,xyz).
!    The new set gives the same unit cell volume and the first two
! vectors will lie in the plane specified either by:
!      icase=0 - three Miller's indices HH,KK,LL;
!      icase=1 - normal vector xn().
!....................................................................
!     The method works as follows: first, one shortest possible
! lattice vector lying in the plane is built. This is done by Evien's
! type "shells". Then, starting from the same shell, we run the same
! algorithm again for lattice vectors which are not parallel to the
! first one chosen and again we choose the shortest possible in the plane.
! Then, finally, the third vector is chosen which has a non-vanishing
! component normal to the plane.
!....................................................................
!     During every search we always check two more "shells" to make
! sure that there are no more vectors shorter than the one already
! found.
!....................................................................
      real(8) :: Xs(3),AJ(3,3),AJ1(3,3),xn(3)
      integer :: IJ(3,3)
      logical :: found,current,answer
      integer :: HH,KK,LL,icase
      real(8),parameter :: tiny=0.000001
!
      integer :: i_luc,N,N1,N2,N3,iPrnt,ishell,i,j
      real(8) :: DET1,xsl_min,vol_min,sp,xsl,vol,DET

!
!...... save AJ in AJ1
!
      call send(AJ,3,3,AJ1)
!
!...... UC volume
!
      DET1= AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(2,3)*AJ(3,2)) &
          -AJ(2,1)*(AJ(1,2)*AJ(3,3)-AJ(1,3)*AJ(3,2)) &
          +AJ(3,1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2))
!
!....... The both lattices are built by shells numbered using the.......
!   index N=0,1,2,... where N=0 belongs to the 0 site; inside every
!   shell the lattice vectors are computed as N1*a1+N2*a2+N3*a3,
!   where a1,a2,a3 are basic translations AJ.
!.... found =.true. -  if a successful vector is found at all
!    current=.true. -  if a successful vector is found in the current shell
!....... i_luc - is used to count new UC basic lattice vectors being built
!
      i_luc=1
 10   found=.false.
      xsl_min=1.0e+10 ; vol_min=1.0e+10

      N=0
 30   N=N+1
      current=.false.
      do N3=-N,N
         do N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
!
!____________ summation over the direct lattice
               Xs(1)=N1*AJ1(1,1)+N2*AJ1(2,1)+N3*AJ1(3,1)
               Xs(2)=N1*AJ1(1,2)+N2*AJ1(2,2)+N3*AJ1(3,2)
               Xs(3)=N1*AJ1(1,3)+N2*AJ1(2,3)+N3*AJ1(3,3)
!
!_________________ check for the first two lattice vectors if they lie
!                  in the plane perpendicular to the HH,KK,LL reciprocal
!                  lattice vector
!
               if(iPrnt.ge.13) write(9,*) 'N=',N,'    ',N1,N2,N3
               if(i_luc.ne.3) then
                  if(icase.eq.0) then
                     if(HH*N1+KK*N2+LL*N3.ne.0) go to 250
                  else if(icase.eq.1) then
                     sp=abs(Xs(1)*xn(1)+Xs(2)*xn(2)+Xs(3)*xn(3))
                     if(sp.gt.tiny) go to 250
                  end if
               end if
!
!_________________ check if the vector Xs is linearly dependent with
!                  the previously found AJ-vectors or not
               if(i_luc.ne.1) then
                  call ask_lin_dep(Xs,AJ,i_luc-1,answer)
                  if(answer) go to 250
               end if
!
!_________________ check its lenght
               xsl= sqrt( Xs(1)*Xs(1) + Xs(2)*Xs(2) + Xs(3)*Xs(3) )
               if(iPrnt.ge.13) &
                    write(9,'(a,3(1x,f10.5),3x,f10.5,2(x,l1))') &
                    ' xs => ',(Xs(i),i=1,3),xsl,found,current
               if(i_luc.lt.3) then
                  if(xsl.ge.xsl_min) go to 250
               else
                  vol= abs(AJ(1,1)*(AJ(2,2)*Xs(3)-AJ(2,3)*Xs(2)) &
                       -AJ(2,1)*(AJ(1,2)*Xs(3)-AJ(1,3)*Xs(2)) &
                       +Xs(1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2)))
                  if(vol.gt.vol_min) then
                     go to 250
                  else if(abs(vol-vol_min).lt.tiny) then
                     if(xsl.ge.xsl_min) go to 250
                  end if
               end if
!
!_________________ okay, accept it!
 40            xsl_min=xsl
               if(i_luc.eq.3) vol_min=vol
               AJ(i_luc,1:3)=Xs(1:3)
               IJ(i_luc,1)=N1 ; IJ(i_luc,2)=N2 ; IJ(i_luc,3)=N3
               found=.true. ; current=.true.
               if(iPrnt.ge.13)write(9,'(a,i1,3(1x,f10.5),5x,f10.5,2l1)') &
                    '__found so far__ ',i_luc,(AJ(i_luc,j),j=1,3), &
                    xsl_min, found,current
!
 250        end do
         end do
      end do
!
!........ if not found, go to the next shell
!
      if(.not.found) go to 30
!
!........ if found for the first time, go for another two shells
!
      if(found) then
         if(current) then
            ishell=1
         else
            if(iPrnt.ge.13) write(9,*) 'isehll=',ishell
            if(ishell.eq.2)  go to 50
            ishell=ishell+1
         end if
      end if
      go to 30
!
!........ build the next vector now starting from the very beginning again
!
 50   if(i_luc.lt.3) then
         i_luc=i_luc+1
         if(iPrnt.ge.13) &
              write(9,'(a,i1)') '========> going to i_luc=',i_luc
         go to 10
      end if
!
!...... check the new UC volume
!
      DET= AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(2,3)*AJ(3,2)) &
          -AJ(2,1)*(AJ(1,2)*AJ(3,3)-AJ(1,3)*AJ(3,2)) &
          +AJ(3,1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2))
      if(abs(abs(DET1/DET)-1.0).gt.tiny) then
         write(*,*)'BAD news! New UC has a different volume.'
         write(*,*)'UNDO this step, please, and report the problem'
      end if
!
!............ print
      if(iPrnt.ge.13) then
         write(9,'(a)')'..get_best_ai.. old UC vectors AJ1:'
         write(9,'(a,3(1x,f10.5))') 'AJ1(1, ) => ', (AJ1(1,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ1(2, ) => ', (AJ1(2,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ1(3, ) => ', (AJ1(3,j),j=1,3)
         write(9,'(a)')'..get_best_ai.. new UC vectors AJ:'
         write(9,'(a,3(1x,f10.5))') 'AJ(1, ) => ', (AJ(1,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ(2, ) => ', (AJ(2,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ(3, ) => ', (AJ(3,j),j=1,3)
      end if
      end subroutine get_best_AI

      subroutine send(X,n,m,Y)
      use real8
      implicit none
!................. matrix X(n,m) is copied into matrix Y
      real(8) :: X(n,m),Y(n,m)
!
      integer :: n,m

      Y=X
      end subroutine send

      subroutine ask_lin_dep(Xs,AJ,i_chk,answer)
!...................................................................
!     Checks if vector Xs is linearly dependent on i_chk vectors
! AJ(#,xyz), #=1,...,i_chk  (i_chk is either 1 or 2).
!
! OUTPUT:  answer=.true. if vector Xs is linearly dependent.
!                                     ^^
!...................................................................
      use real8
      implicit none
      real(8) :: Xs(3),AJ(3,3),Z(3)
      real(8) :: tiny=0.0000001d0
      logical :: answer
!
      integer :: i_chk
      real(8) :: xsl,ajl,scalr

      answer=.false.

      if(i_chk.eq.1) then
!.......... If i_chk=1, then we simply check if they are collinear
         xsl= sqrt(Xs(1)*Xs(1) + Xs(2)*Xs(2) + Xs(3)*Xs(3))
         ajl= sqrt(AJ(1,1)*AJ(1,1) + AJ(1,2)*AJ(1,2) + AJ(1,3)*AJ(1,3))
         scalr=abs(AJ(1,1)*Xs(1) + AJ(1,2)*Xs(2) + AJ(1,3)*Xs(3))
         if(abs(scalr-xsl*ajl).lt.tiny) answer=.true.
      else
!.......... If i_chk=2, then we check if Xs is perpendicular to
!           the vector product of the two AJ's or not
         Z(1)=AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2)
         Z(2)=AJ(1,3)*AJ(2,1)-AJ(1,1)*AJ(2,3)
         Z(3)=AJ(1,1)*AJ(2,2)-AJ(1,2)*AJ(2,1)
         scalr=Z(1)*Xs(1) + Z(2)*Xs(2) + Z(3)*Xs(3)
         if(abs(scalr).lt.tiny) answer=.true.
      end if
      end subroutine ask_lin_dep
