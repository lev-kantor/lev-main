module buffer_index
use tetr_param
  implicit none
!     common /buffer_index/ Mol_index1,iMol1
      integer :: Mol_index1(N0LT),iMol1

end module buffer_index
