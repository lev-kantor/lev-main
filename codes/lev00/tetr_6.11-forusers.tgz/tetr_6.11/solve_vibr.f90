      subroutine solve_vibr(E_mat,G_mat,EigR,EigV,Ndim,Err)
!............................................................................
! solves a generalised eigenproblem
!      E_mat * u = w^2 * G_mat * u
!............................................................................
!  EigR - eigenvalues (frequencies squared)
!  EigV - eigenvectors (by columns)
!............................................................................
      use real8
      implicit none
      real(8) :: E_mat(Ndim,Ndim),G_mat(Ndim,Ndim)
      real(8),dimension(:,:),allocatable :: A
      real(8),dimension(:),allocatable :: Work
      real*8,dimension(:,:),allocatable :: G_m
      real*8,dimension(:),allocatable :: sNorm
      real(8) :: EigV(Ndim,Ndim),EigR(Ndim)
      logical :: Err
!
      integer :: Ndim,i,j,k,k1
      real(8) :: s,ss

      Err=.false.
      write(*,*)
      write(*,*)'>>>>>>>>>>>> Final E-matrix: <<<<<<<<<<<<'
      write(*,*)
      do i=1,Ndim
         write(*,'(i3,x,8(e12.6,x))') i, (E_mat(i,j),j=1,Ndim)
      end do
      write(*,*)

      write(*,*)'>>>>>>>>>>>> Present G-matrix: <<<<<<<<<<<<<'
      write(*,*)
      do i=1,Ndim
         write(*,'(i3,x,8(e12.6,x))') i, (G_mat(i,j),j=1,Ndim)
      end do
!
!............. allocate working arrays
!
      allocate(Work(Ndim)) ; allocate(A(Ndim,Ndim))
!      
!............. diagonalisation of G_mat * E_mat
!
      if(Ndim.eq.1) then
         EigR(1)=G_mat(1,1)*E_mat(1,1)
         EigV(1,1)=1.0d0
         return
      end if

!_________ diagonalise G
      write(6,'(a)')'Diagonalising G*E ...'
      call diag(G_mat,Work,EigR,EigV,Ndim,Ndim)
      do i=1,Ndim
         if(EigR(i).lt.0.0) then
            Err=.true. ; return
         end if
      end do

!_________ calculate G^{1/2} in G
      allocate(G_m(Ndim,Ndim))
      write(6,'(a)')'Done! Calculating G^{1/2} in G ...'
      do i=1,Ndim
         do j=1,Ndim
            s=0.0
            do k=1,Ndim
               s=s+sqrt(EigR(k))*EigV(i,k)*EigV(j,k)
            end do
            G_m(i,j)=s
         end do
      end do

!_________ calculate matrix F1=G^{1/2} * E * G^{1/2}
      do i=1,Ndim
         do j=1,Ndim
            s=0.0d0
            do k=1,Ndim
               do k1=1,Ndim
                  s=s+G_m(i,k)*E_mat(k,k1)*G_m(k1,j)
               end do
            end do
            A(i,j)=s
         end do
      end do

!_________  and diagonalise it
      call diag(A,Work,EigR,EigV,Ndim,Ndim)
!      write(*,*) '_____> Eigenvalues: '
!      write(*,*) (EigR(i),i=1,Ndim)

!_________restore eigenvectors of the original matrix G*E by
!         multiplying EigV on G^{1/2}
      allocate(sNorm(Ndim))
      do k=1,Ndim
         ss=0.0d0
         do i=1,Ndim
            s=0.0d0
            do j=1,Ndim
               s=s+G_m(i,j)*EigV(j,k)
            end do
            A(i,k)=s
            ss=ss+s*s
         end do
         sNorm(k)=1.0/sqrt(ss)
      end do
      deallocate(G_m)

!________renormalise eigenvectors and set them to EigV
      do k=1,Ndim
         do i=1,Ndim
            EigV(i,k)=A(i,k)*sNorm(k)
         end do
      end do
!
!........ deallocate 
!
      deallocate(SNorm) ; deallocate(A) ; deallocate(Work)
      
      end subroutine solve_vibr

      subroutine print_eigenproblem(E,V,Ndim,Ndim0,unit)
!...................................................................................
! Prints out a nice eigenvector/values table into unit.
!...................................................................................
!  E(#)   - eigenvalue #
!  V(j,#) - eigenvector #, component j (in columns)
!  Ndim0  - physical dimension of the arrays
!  Ndim   - actual (logical) dimension of the problem (arrays)
!...................................................................................
      use real8
      implicit none
      integer :: unit
      real(8) :: E(Ndim0),V(Ndim0,Ndim0)
!
      integer :: Ndim,Ndim0,iEig,iE1,iE2,j,i

!............. print out by 10 entries at a time

      write(unit,'(/a/)') &
           '============ Eigenvectors - Eigenvalues  ============='
      do iEig=1,Ndim,10
         iE1=iEig
         iE2=iE1+9
         if(iE2.gt.Ndim) iE2=Ndim
         write(unit,'(a,10(e12.6,1x))') 'Eigenvalues: ',(E(i),i=iE1,iE2)
         write(unit,'(a)') &
              '------------------------------------------------'
         write(unit,'(a,10(6x,i2,5x))') 'Eigenvectors: ',(i,i=iE1,iE2)
         do j=1,Ndim
            write(unit,'(13x,10(e12.6,1x))') (V(j,i),i=iE1,iE2)
         end do
         write(unit,'(a)') &
              '------------------------------------------------'
         if(iE2.eq.Ndim) return
         if(unit.eq.6) then
            write(*,'(a)')'... Hit ENTER to continue ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
         end if
      end do
      end subroutine print_eigenproblem

      subroutine show_normal_displ(IA,IRA,Freq,Species,unit,Show_fixed)
!.............................................................
! nice print of the normal modes for irrep IA:
! IA     - given irrep
! IRA    - total number of normal modes for this irrep IA
!.............................................................
      use real8
      use pgroup
      use symgenv
      use working
      implicit none
      real(8) :: RR(MG0,3),RA(3),Freq(IRA)
      integer :: rep,unit,NALF
      character Species(N0KD)*2
      logical Show_fixed
      character,dimension(3) :: a=(/'y','z','x'/),aa=(/'x','y','z'/)
      integer,dimension(3) :: kk=(/2,3,1/),kkk=(/3,1,2/)
!
      integer :: IA,IRA,ibound,irep,ir1,ir2,i,iOrb,iN0,is,Nnn
      integer :: iN,iold,k,j,nat
!
!.......... set boundaries of the table depending on the irrep dimension
!
      NALF=NALFA(IA) ; if(iCmpl(IA).eq.1) NALF=1

      if(NALF.eq.1) then
         ibound=10
      else if(NALF.eq.2) then
         ibound=5
      else
         ibound=3
      end if
!
!........... write on the screen/file
!
      write(unit,'(a/)') &
           '****************** normal displacements **************'

      do irep=1,IRA,ibound
         ir1=irep
         ir2=ir1+ibound-1 ; if(ir2.gt.IRA) ir2=IRA

         write(unit,'(24x,a)') '   <-------(number,row)------->'
         write(unit,'(a,20(x,f10.5))') '    Frequency  (in cm^-1) ', &
                 ((Freq(rep),j=1,NALF),rep=ir1,ir2)
         write(unit,'(2x,a,20(3x,a,i2,a,i1,a,2x))') &
           'old#   atom#     x/y/z   ', &
           (('(',rep,',',i,')',i=1,NALF),rep=ir1,ir2)

         iN0=0
         do iOrb=1,NORB
            if((.not.Fix(iOrb)) .or. Show_fixed) then
               RA(1:3)=R1(iOrb,1:3)
               is=ISORT1(iOrb)
               call PVRT0(RA,RR,Nnn)
               do nat=1,Nnn
                  iN=iN0+nat
                  iold=orb_to_old(iOrb,nat)
                  do i=1,3
                     k=kkk(i)
                     write(unit,'(i3,x,a,x,i5,a,20(x,f10.5))') &
                       iold,Species(is),iN,aa(i),RR(nat,i), &
                       ((W_all(k,iN,rep,j),j=1,NALF),rep=ir1,ir2)
                  end do
               end do
               write(unit,*) &
                 '---------------------------------------------------'
            end if
            iN0=iN0+KAN(iOrb)
         end do

         if(ir2.eq.IRA) return
         if(unit.eq.6) then
            write(*,'(a)')'... Hit ENTER to continue ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
         end if

      end do
      end subroutine show_normal_displ



