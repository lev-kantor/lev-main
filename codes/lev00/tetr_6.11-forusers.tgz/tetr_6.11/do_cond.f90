      subroutine do_cond(N_Cond,C_cond,AtMass)
!...............................................................
! R1(orbit,xyz) - 1st atoms of orbits in the right order
! NORB - number of orbits
!_______ OUTPUT:
! N_cond - number of  translations/rotations conditions
! C_cond(yzx-component, Atom , condition number) - vectors of
!            conditions;
!...............................................................
!     Everything is done with respect to Cartesian spherical
! harmonics, not displacements, so that:
!  x-displacement => Y(l=1,m=1) = y3
!  y-displacement => Y(l=1,m=-1)= y1
!  z-displacement => Y(l=1,m=0) = y2
!
!     Thus, vectors are expanded with respect to y1,y2,y3,
! NOT displacements!
!...............................................................
      use real8
      use symgenv
      implicit none
      real(8) :: C_cond(3,N0LT,6),RR(MG0,3),x(3)
      real(8) :: Work(6),AtMass(N0KD)
      integer,dimension(3) :: kk=(/3,1,2/)
!
      integer :: j1,N_Cond,j,iN,iOrb,is,nat,k,k1,N1,j0,N_Cond1
!
!.......... we build up translation/rotation conditions:
!      N_cond - number of conditions
!      C_cond(yzx, atom, cond. #) - vector of conditions
!
![1]........ make conditions in C_cond: traslations (1st three vectors)
!
      do j1=1,3
         j=kk(j1)

         iN=0
         do iOrb=1,NORB
            is=ISORT1(iOrb)
            do nat=1,KAN(iOrb)
               iN=iN+1
               do k=1,3
                  k1=kk(k)
                  C_cond(k1,iN,j)=0.0
                  if(k1.eq.j) C_cond(j,iN,j)=AtMass(is)
               end do
            end do
         end do

      end do
!
![2]......... make conditions in C_cond: rotations (2nd two/three vectors).
!         if Linear=.true. then there is no condition for the z-component
!         Vectors are constructed as angluar momenta for the rotations around x,y,z axes,
!         e.g. Lz=\sum_i m_i [r_i x k], where k is the direction along z.
!
      iN=0
      do iOrb=1,NORB
         is=ISORT1(iOrb)
         x(1)=R1(iOrb,1)
         x(2)=R1(iOrb,2)
         x(3)=R1(iOrb,3)
         call PVRT0(x,RR,N1)
         do nat=1,N1
            iN=iN+1
            C_cond(3,iN,4)= 0.0
            C_cond(1,iN,4)=-AtMass(is)*RR(nat,3)
            C_cond(2,iN,4)= AtMass(is)*RR(nat,2)
            C_cond(3,iN,5)= AtMass(is)*RR(nat,3)
            C_cond(1,iN,5)= 0.0
            C_cond(2,iN,5)=-AtMass(is)*RR(nat,1)
            C_cond(3,iN,6)=-AtMass(is)*RR(nat,2)
            C_cond(1,iN,6)= AtMass(is)*RR(nat,1)
            C_cond(2,iN,6)= 0.0
         end do
      end do
!
![3]........ orthogonalise/normalise vectors of conditions
!
      j0=0
      call ortho_norm(C_cond,6,N_cond1,N_cond,3*iN,3*N0LT,work,j0)
      return
      end subroutine do_cond

      subroutine show_C(C_cond,N_cond,Species)
      use real8
      use symgenv
      implicit none
      real(8) :: C_cond(3,N0LT,6)
      integer,dimension(3) :: kk=(/2,3,1/)
      character Species(N0KD)*2
      character,dimension(3) :: a=(/'y','z','x'/)
!
      integer :: iN,N_Cond,iOrb,is,nat,iold,k1,k,iC

      write(*,*)' '
      write(*,'(a)')'********** Vectors of conditions ***********'
!      write(*,'(a)') '  atom    /-------translations--------\\'//
      write(*,'(a)') &
           'old#  atom    /-------translations--------\\'// &
           '     /---------rotations--------\\'
      iN=0
      do iOrb=1,NORB
         is=ISORT1(iOrb)
         do nat=1,KAN(iOrb)
            iN=iN+1
            iold=orb_to_old(iOrb,nat)

            do k1=1,3
               k=kk(k1)
               if(k1.eq.1) then
                  write(*,'(i3,x,a,i3,a1,6(x,f10.5))') &
                 iold,Species(is),iN,a(k),(C_cond(k1,iN,iC),iC=1,N_Cond)
               else
                  write(*,'(6x,i3,a1,6(x,f10.5))') &
                       iN,a(k),(C_cond(k1,iN,iC),iC=1,N_Cond)
               end if
            end do

         end do
      end do
      return
      end subroutine show_C

      subroutine ortho_norm(C,Nm,N,NN,Ndim,Ndim0,Alpha,j0)
!.........................................................................
!   Orthogonalise/normalise NN vectors C (dimension Ndim) to
! previously orthogonal/normalised first j0 vectors using the
! Gramm-Shmidt procedure (must be: j0 < NN =< Nm).
!   Note that j0 can be also 0.
!   Linearly dependent vectors are recognised and removed from C,
! N=NN is adjusted appropriately (i.e. reduced) to be the final number
! of linearly independent vectors.
!
!...... INPUT:
!  C(i,#) - vectors to orthogonalise
!     Nm  - max number of vectors (2nd physical dimension of an array)
!     NN  - actual number of vectors (should be =< Nm)
!     j0  - number of already orthonormal vectors at the beginning of the
!           whole set (#=1,...,j0); j0 may be equal to 0; should be =< NN
!  Ndim0  - max size of each vector (1st physical dimension of an array)
!  Ndim   - actual size of each vector
!
!......OUTPUT:
!  C(i,#) - orthogonormal vectors
!     N   - actual number left after dropping linearly dependent vectors
!           (N >= j0)
!.........................................................................
      use real8
      implicit none
      real(8) :: C(Ndim0,Nm),Alpha(Nm)
      real(8),parameter :: tiny=0.00001d0
!
      integer :: Nm,N,NN,Ndim,Ndim0,j0,j00,i,j,k,j1
      real(8) :: beta,s,aNorm,scalar

      N=NN
      j00=j0
      write(*,*)'Shmidt: initial number of vectors N=',N
!
!____ normalise the 1st vector
!
      if(j00.eq.0) then
         beta=1./sqrt( scalar(C(1,1),C(1,1),Ndim) )
         do i=1,Ndim
            C(i,1)=C(i,1)*beta
         end do
         j00=1
         if(N.eq.1) return
      end if
!
!____ now the whole procedure comes in as a loop which starts from
!     the 2nd vector
!
      j=j00
 20   j=j+1
!_________ calculate all Alpha's first
      do k=1,j-1
         Alpha(k) = scalar(C(1,j),C(1,k),Ndim)
      end do
!_________calculate new orthogonal (but unnormalised yet) j-th vector
      do i=1,Ndim
         s=0.0
         do k=1,j-1
            s=s+Alpha(k)*C(i,k)
         end do
         C(i,j)=C(i,j)-s
      end do
!_________ normalise the j-th vector; if the norm of it is zero, then
!          we remove this vector from the original list and reduce N
      aNorm= scalar(C(1,j),C(1,j),Ndim)
      if(aNorm.lt.tiny) then
         write(*,'(a12,i3,a22)')'_> Vector j=',j,' is lin. dependent'
         if(j.eq.N) then
            N=N-1
            go to 30
         else
            do j1=j+1,N
               do i=1,Ndim
                  C(i,j1-1)=C(i,j1)
               end do
            end do
            N=N-1
            j=j-1
         end if
      else
         beta=1./sqrt(aNorm)
         do i=1,Ndim
            C(i,j)=C(i,j)*beta
         end do
      end if
      if(j.lt.N) go to 20
 30   write(*,*)'Shmidt: final number of vectors N=',N
      return
      end subroutine ortho_norm

