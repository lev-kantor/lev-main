      subroutine reducn(x,AJ,BJ)
!..................................................................
!    It translates the point x() (in Cartesian coordinates) to the
! position in which it has fractional coordinates between -1 and 1.
!    Vectors BJ are reciprocal to AJ (up to 2*pi).
!..................................................................
      use real8
      implicit none
      real(8) :: x(3),AJ(3,3),BJ(3,3),r(3)
      real(8),parameter :: tiny=0.000001d0
!
      integer :: i
!
!________ get coefficients r() in the decomposition of x() with
!         respect to AJ. These coefficients are some ratios like iX/jX, ...
!
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)+BJ(1,3)*x(3)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)+BJ(2,3)*x(3)
      r(3)=BJ(3,1)*x(1)+BJ(3,2)*x(2)+BJ(3,3)*x(3)
!
!________ extract the integer part from the coefficients and do them
!         closer to the nearest integer if the difference is small
!
      do i=1,3
        if(abs(r(i)-nint(r(i))).lt.tiny) r(i)=nint(r(i))
        r(i)=r(i)-int(r(i))
      end do
!
!________ return the point r() to the Cartesian representation, x()
!         as before
!
      x(1)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
      x(2)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
      x(3)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
      return
      end subroutine reducn

      subroutine reducn1(x,AJ,BJ)
!..................................................................
!    It translates the point x() (in Cartesian coordinates) to the
! position in which it has fractional coordinates between -0.5
! and 0.5 .
!    Vectors BJ are reciprocal to AJ (up to 2*pi).
!..................................................................
      use real8
      implicit none
      real(8) :: x(3),AJ(3,3),BJ(3,3),r(3)
      real(8),parameter :: tiny=0.000001d0
!
      integer :: i
!
!________ get fractional coordinates of r()
!
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)+BJ(1,3)*x(3)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)+BJ(2,3)*x(3)
      r(3)=BJ(3,1)*x(1)+BJ(3,2)*x(2)+BJ(3,3)*x(3)
!
!________ remove the integer part from the fractional coordinates
! and then put them between -0.5 and 0.5
!
      do i=1,3
        if(abs(r(i)-nint(r(i))).lt.tiny) r(i)=nint(r(i))
        r(i)=r(i)-int(r(i))
        if(r(i).gt.0.5) then
           r(i)=r(i)-1.0
        else if(r(i).lt.-0.5) then
           r(i)=r(i)+1.0
        end if
      end do
!
!________ return the point r() to the Cartesian representation, x()
!         as before
!
      x(1)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
      x(2)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
      x(3)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
      return
      end subroutine reducn1

      subroutine reducn2(x,AJ,BJ)
!..................................................................
!    It translates the point x() (in Cartesian coordinates) to the
! position in which it has fractional coordinates between 0 and 1.
!    Vectors BJ are reciprocal to AJ (up to 2*pi).
!..................................................................
      use real8
      implicit none
      real(8) :: x(3),AJ(3,3),BJ(3,3),r(3)
      real(8),parameter :: tiny=0.000001d0
!
      integer :: i
!
!________ get coefficients r() in the decomposition of x() with
!         respect to AJ. These coefficients are some ratios like iX/jX, ...
!
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)+BJ(1,3)*x(3)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)+BJ(2,3)*x(3)
      r(3)=BJ(3,1)*x(1)+BJ(3,2)*x(2)+BJ(3,3)*x(3)
!
!________ extract the integer part from the coefficients and do them
!         closer to the nearest integer if the difference is small
!
      do i=1,3
        if(abs(r(i)-nint(r(i))).lt.tiny) r(i)=nint(r(i))
        r(i)=r(i)-int(r(i))
        if(r(i).lt.0.0) r(i)=1+r(i)
      end do
!
!________ return the point r() to the Cartesian representation, x()
!         as before
!
      x(1)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
      x(2)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
      x(3)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
      return
      end subroutine reducn2


!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      logical function thesame(x,ITI,TI)
!..................................................................
!  checks if x() is equal to any of the atoms TI() in the cluster
!..................................................................
      use real8
      implicit none
      real(8) :: x(3),TI(3,N0LT)
      real(8),parameter :: tiny=0.000001
!
      integer :: ic,ITI
      real(8) :: ar

      do ic=1,ITI
         ar=(x(1)-TI(1,ic))**2+(x(2)-TI(2,ic))**2+ &
              (x(3)-TI(3,ic))**2
         if(ar.lt.tiny) then
            thesame=.true.
            write(*,*) 'equiv to ic=',ic,' with ',TI(1:3,ic)
            return
         end if
      end do
      thesame=.false.
      end function thesame

      logical function thesame1(i,ITI,TI)
!..................................................................
!  checks if atom i is equal to any of the other atoms TI() in the
!  cluster
!..................................................................
      use real8
      implicit none
      real(8) :: TI(3,N0LT)
      real(8),parameter :: tiny=0.000001d0
!
      integer :: i,ITI,ic
      real(8) :: ar

      do ic=1,ITI
         if(ic.ne.i) then
            ar=(TI(1,i)-TI(1,ic))**2+(TI(2,i)-TI(2,ic))**2+ &
                 (TI(3,i)-TI(3,ic))**2
            if(ar.lt.tiny) then
               thesame1=.true.
               return
            end if
         end if
      end do
      thesame1=.false.
      return
      end function thesame1

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine check_Mendel(Spec,k,Err,verbose)
!     implicit none
      use mendeleev
      implicit none
      logical :: Err,verbose
      character :: Spec*2
!
      integer :: k

      Err=.false.

!___________ checking from NAZV
      do k=1,112
         if(NAZV(k).eq.Spec) then
            if(verbose) write(*,'(a,i2,a)')'Species '//Spec// &
                 ' => recognised as #',k,' in Mendeleev''s Table'
            return
         end if
      end do
      write(*,*)'ERROR! Species '//Spec//' has not been recognised!'
      Err=.true.
      k=83
      return
      end subroutine check_Mendel

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine ask(R,BJ,TRAN,MMM,MG,IASK)
!..............................................................
! check, if vector R is contained in TRAN
!     Answer: iask=1 means R is already there
!             iask=2 means R is new (not contained)
!..............................................................
      use real8
      implicit none
      real(8) :: R(3),RL(3),TRAN(MMM,3),BJ(3,3)
      logical :: ask_equiv
      real(8),parameter :: tiny=0.000001d0
!
      integer :: IASK,NA,MMM,MG

      IASK=2
      do NA=1,MG
         RL(1:3)=TRAN(NA,1:3)-R(1:3)

!____ this vector RL must not be represented as an integer combination of AJ's

         if(ask_equiv(RL,BJ,3,tiny)) then
            IASK=1 ; return
         end if
      end do
      return
      end subroutine ask

      subroutine ask1(R,BJ,TRAN,MMM,MG,IASK,toler)
!..............................................................
! the same as 'ask()' but TRAN is defined differently
! and a tolerance is ported from outside (=toler)
!..............................................................
! check, if vector R is contained in TRAN
!     Answer: iask=1 means R is already there
!             iask=2 means R is new (not contained)
!..............................................................
      use real8
      implicit none
      real(8) :: R(3),RL(3),TRAN(3,MMM),BJ(3,3)
      logical :: ask_equiv
!
      integer :: IASK,MMM,MG,NA
      real(8) :: toler

      IASK=2
      do NA=1,MG
         RL(1:3)=TRAN(1:3,NA)-R(1:3)

!____ this vector RL must not be represented as an integer combination of AJ's

         if(ask_equiv(RL,BJ,3,toler)) then
            IASK=1 ; return
         end if
      end do
      end subroutine ask1

!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine sort(d,n,is)
!................................................................
! sorting routine:
!   the reference index vector is(j) of numbers is constructed
!   corresponding to asccend of vectors d(j).
!................................................................
      use real8
      implicit none
      real(8) :: d(n)
      integer :: is(n)
!
      integer :: i,n,k,ip,iss

      do i=1,n
        is(i)=i
      end do
      if(n.eq.1) return
 10   ip=0
      do k=1,n-1
        if( d(is(k)) .gt. d(is(k+1)) ) then
          ip=1
          iss=is(k)
          is(k)=is(k+1)
          is(k+1)=iss
        end if
      end do
      if(ip.eq.1) go to 10
      return
      end subroutine sort

      logical function ask_coinc(r,jSort,iSort,k)
!...................................................................
!   It checks whether the atom of the sort jSort and with vector
! r() is equivalent to some atom of the system.
!...................................................................
!  k = equivalent atom number (between 1 and ITI) if answer='y',
!  k - meaningless otherwise
!...................................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: r(3),r1(3)
      integer :: iSort(N0LT)
      logical :: ask_equiv
!
      integer :: jSort,k

      do k=1,ITI
         if(iSort(k).eq.jSort) then
            r1(1)=r(1)-TI(1,k)
            r1(2)=r(2)-TI(2,k)
            r1(3)=r(3)-TI(3,k)
            ask_coinc=ask_equiv(r1,BJ,3,tiny_equiv)
            if(ask_coinc) return
         end if
      end do
      ask_coinc=.false.
      return
      end function ask_coinc

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      logical function ask_equiv(r,XJ,iCase,tiny_equiv)
!........................................................................
!    It checks whether vector r() is equivalent to lattice translations
!  reciprocal to vectors XJ (up to 2*pi):
!
!  if XJ - reciprocal lattice vectors, then r() must be in the direct
!          space;
!  if XJ - direct lattice vectors, then r() must be in the reciprocal
!          space;
!........................................................................
!  iCase = 3 - if 3D space;
!  iCase = 2 - if 2D space
!........................................................................
!  .true. - if r() is equivalent to latice translations
!  .false.- if not.
!........................................................................
      use real8
      implicit none
      real(8) :: r(3),XJ(3,3),x(3)
!
      integer :: i,iCase
      real(8) :: tiny_equiv

      ask_equiv=.false.
!
!____ multiply on all direct lattice vectors: the result must be integer
! if r() is an arbitrary sum of reciprocal lattice vectors (note, r() is
! defined up to 2*pi because of the choice of BJ used to generate it)
!
      do i=1,iCase
         x(i)=r(1)*XJ(i,1)+r(2)*XJ(i,2)+r(3)*XJ(i,3)
         if( abs(x(i)-nint(x(i))) .gt. tiny_equiv ) return
      end do
      ask_equiv=.true.
!      write(*,'(a,3(f10.5,x))')'EQUIVALENT: expans. coeff. are ',x
      end function ask_equiv

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine PVRT0(RA,R,Nnn)
      use real8
      use tetrag1
      use pgroup
      use systema
      implicit none
      real(8) :: RA(3),R(MG0,3),RL(3)
      logical :: ask_equiv,as
!
      integer :: I1,Nnn,I,KGI,J
      real(8) :: AR

      I1=1
      R(1,1:3)=RA(1:3)
      if(MG.eq.1) go to 4
      do 3 I=2,MG
         KGI=KG(I)
         I1=I1+1
         R(I1,1)=C(1,1,KGI)*RA(1)+C(1,2,KGI)*RA(2)+C(1,3,KGI)*RA(3)+ &
              TRAN(I,1)
         R(I1,2)=C(2,1,KGI)*RA(1)+C(2,2,KGI)*RA(2)+C(2,3,KGI)*RA(3)+ &
              TRAN(I,2)
         R(I1,3)=C(3,1,KGI)*RA(1)+C(3,2,KGI)*RA(2)+C(3,3,KGI)*RA(3)+ &
              TRAN(I,3)
         do J=1,I1-1
            RL(1:3)=R(I1,1:3)-R(J,1:3)
            if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA'.or. &
                 system.eq.' K-POINT') then
               as=ask_equiv(RL,BJ,3,tiny_equiv)
               if(as) go to 2
            else
               AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
               if(AR.lt.tiny_equiv) go to 2
            end if
         end do
         go to 3
 2       I1=I1-1
    3 end do
    4 Nnn=I1
      return
      end subroutine PVRT0

!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine list_dash(listat,nlist,tmp,string,length,long)
      implicit none
!     implicit none
!........................................................................
! creates a string of numbers separated by commas or dashes (if changed
! continuously);
!........................................................................
! long= .false. if the string is not long enough to accomodate the list
!........................................................................
      logical :: listat(nlist),tmp(nlist),long
      character :: string*100,cha10*10
!
      integer :: i,nlist,length,j,n_digits,i1,j0,k,k1

      long=.true.
      do i=1,100
         string(i:i)=' '
      end do

      do i=1,nlist
         tmp(i)=listat(i)
      end do
      write(*,*) (tmp(i),i=1,nlist)

      j=1
      do 10 i=1,nlist
         if(tmp(i)) then
!__________ number of digits
            n_digits=log(real(i))/log(10.)+1
            write(cha10,'(i10)') i
            i1=10-n_digits+1
            j0=j+n_digits
            if(j0-1.le.99) then
               string(j:j0-1)=cha10(i1:)
            else
               long=.false.
               length=100
               return
            end if
            j=j0

!___________ check if there are data continusly after it
            if(i.lt.nlist) then
               do k=i+1,nlist
                  if(.not.tmp(k)) go to 5
                  tmp(k)=.false.
                  n_digits=log(real(k))/log(10.)+1
                  write(cha10,'(i10)') k
                  k1=10-n_digits+1
                  if(j0+n_digits.le.99) then
                     string(j0:j0+N_digits)='-'//cha10(k1:)
                  else
                     long=.false.
                     length=100
                     return
                  end if
                  j=j0+n_digits+1
               end do
            end if

 5          string(j:j)=','
            j=j+1
         end if
 10   end do
      string(j-1:j-1)=' '
      length=j-1
      return
      end subroutine list_dash

      subroutine which_atom_after_rot(r,Irot,nat,Err)
!...................................................................
! rotates point r() by operation Irot (no translations), and gets
! the atom number matching the resulting point.
! Err = .true. if the matching atom not found.
!...................................................................
      use real8
      use tetrag1
      use pgroup
      implicit none
      real(8) :: x(3),r(3),r1(3)
      logical :: ask_equiv,Err
!
      integer :: Irot,nat,KGI,k1

      Err=.false.
!
!..... apply rotation
      KGI=KGp(Irot)
      x(1)=C(1,1,KGI)*r(1)+C(1,2,KGI)*r(2)+C(1,3,KGI)*r(3)
      x(2)=C(2,1,KGI)*r(1)+C(2,2,KGI)*r(2)+C(2,3,KGI)*r(3)
      x(3)=C(3,1,KGI)*r(1)+C(3,2,KGI)*r(2)+C(3,3,KGI)*r(3)
!
!..... find the atom
      do k1=1,ITI
         r1(1)=x(1)-TI(1,k1)
         r1(2)=x(2)-TI(2,k1)
         r1(3)=x(3)-TI(3,k1)
         if(ask_equiv(r1,BJ,3,tiny_equiv)) then
!___________ matching atom found
            nat=k1
            return
         end if
      end do
!
!.... matching atom NOT found
      Err=.true.
      return
      end subroutine which_atom_after_rot

      logical function collinear(v1,v2)
!.......................................................
! checks if two vectors v1 and v2 are collinear or not
!.......................................................
      use real8
      implicit none
      real(8) :: v1(3),v2(3)
      real(8),parameter :: tiny=0.000001d0
!
      real(8) :: s1,s2,s3

      s1=v1(2)*v2(3)-v1(3)*v2(2)
      s2=v1(3)*v2(1)-v1(1)*v2(3)
      s3=v1(1)*v2(2)-v1(2)*v2(1)
      if(abs(s1)+abs(s2)+abs(s3).lt.tiny) then
         collinear=.true.
         return
      end if
      collinear=.false.
      return
      end function collinear

      logical function perpend(v1,v2)
!.......................................................
! checks if two vectors v1 and v2 are perpendicular
!.......................................................
      use real8
      implicit none
      real(8) ::v1(3),v2(3)
      real(8),parameter :: tiny=0.000001d0
!
      real(8) :: s

      s=v1(1)*v2(1)+v1(2)*v2(2)+v1(3)*v2(3)
      if(abs(s).lt.tiny) then
         perpend=.true.
         return
      end if
      perpend=.false.
      return
      end function perpend

      subroutine cross_product(v1,v2,v)
!.......................................................
! calculates v= v1 x v2
!.......................................................
      use real8
      implicit none
      real(8) :: v1(3),v2(3),v(3)
      v(1)=v1(2)*v2(3)-v1(3)*v2(2)
      v(2)=v1(3)*v2(1)-v1(1)*v2(3)
      v(3)=v1(1)*v2(2)-v1(2)*v2(1)
      return
      end subroutine cross_product

