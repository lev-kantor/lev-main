module reference
use tetr_param  
implicit none
!     common /reference/ AZ,TIz,ITIz, &
!                        NspNz,Nspz,Speciesz
      real(8) :: AZ(3,3),TIz(3,N0LT)
      character :: Speciesz(N0KD)*2
      integer ::  ITIz,NspNz(N0KD),Nspz
end module reference
