      subroutine wyckoff(line,l0)
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
!    Wyckoff general positions for the group are obtained in a symbolic
! form.
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      use real8
      use pgroup
      implicit none
      real(8) :: q(3),d(3,3)
      character :: cha(3,3)*2,fr(3)*4,line1*6,line2*6,line3*6
      character :: line(48,3)*10,ch1,ch2
      integer :: l0(48,3,2),k(3)
      real(8),parameter ::  tiny=0.00001d0
      character,dimension(3) :: ch=(/'x','y','z'/)
!
      integer :: iRot,KGI,i,j,l1,l2,l3,ia,ib,n,m
      real(8) :: s
!
!............ implying a general Wyckoff point (xx,yy,zz) in fractional
!  coordinates wrt conventional unit cell, get for every group operation
!  coefficients other positions.
!
!  The positions are generally given as:
!
!               r=r1*AJ(1)+r2*AJ(2)+r3*AJ(3)
! where:
!           r1=d(1,1)*xx+d(1,2)*yy+d(1,3)*zz
!           r2=d(2,1)*xx+d(2,2)*yy+d(2,3)*zz
!           r3=d(3,1)*xx+d(3,2)*yy+d(3,3)*zz
!
      do Irot=1,MGp

         KGI=KGp(Irot)

!_________ get an ordinary rotation first
         do i=1,3
            do j=1,3
               s=0.0
               do ia=1,3
                  do ib=1,3
                     s=s+BJc(i,ia)*C(ia,ib,KGI)*AJc(j,ib)
                  end do
               end do
               d(i,j)=s
               if(abs(s).lt.tiny) then
                  cha(i,j)=''
               else if(abs(s-1.0).lt.tiny) then
                  cha(i,j)='+'//ch(j)
               else if(abs(s+1.0).lt.tiny) then
                  cha(i,j)='-'//ch(j)
               else
                  write(*,*)'Err: for Irot=',Irot,' d(',i,',',j,')=',s
               end if
            end do
         end do

!______________ get the fractional translation

         do i=1,3
            q(i)=FrTr(1,Irot)*BJc(i,1)+FrTr(2,Irot)*BJc(i,2)+ &
                                            FrTr(3,Irot)*BJc(i,3)
            if(q(i).lt.0.0) q(i)=q(i)+1.0
            if(abs(q(i)-nint(q(i))).lt.tiny) q(i)=nint(q(i))
            call fract(q(i),n,m)
            write(ch1,'(i1)') n
            write(ch2,'(i1)') m

            if(n.eq.0) then
               fr(i)='    '
               k(i)=6
            else if(q(i).gt.0.0) then
               fr(i)='+'//ch1//'/'//ch2
               k(i)=10
            else if(q(i).lt.0.0) then
               fr(i)='-'//ch1//'/'//ch2
               k(i)=10
            end if
         end do

!______________ print out the result in the form of the Tables

         call shrink(cha(1,1),cha(1,2),cha(1,3),line1,l1)
         call shrink(cha(2,1),cha(2,2),cha(2,3),line2,l2)
         call shrink(cha(3,1),cha(3,2),cha(3,3),line3,l3)
         line(Irot,1)=line1//fr(1)
         line(Irot,2)=line2//fr(2)
         line(Irot,3)=line3//fr(3)
         l0(Irot,1,1)=l1
         l0(Irot,1,2)=k(1)
         l0(Irot,2,1)=l2
         l0(Irot,2,2)=k(2)
         l0(Irot,3,1)=l3
         l0(Irot,3,2)=k(3)

      end do
      return
      end subroutine wyckoff

      subroutine fract(x,n,m)
!.................................................................
! x is represnted to the nearest n/m with integral n,m and
! |n/m|<1. It is assumed that m=<10.
!.................................................................
      use real8
      implicit none
      real(8) :: x,e
      real(8),parameter :: tiny=0.00001d0
!
      integer :: n,m,i,j
      real(8) :: y

      if(abs(x).lt.tiny) then
         n=0
         m=1
         return
      end if

!________ get rid of an integer part (will be between -1 and 1)

      x=x-int(x)
      y=abs(x)

!________ trying denominator from 2 to 10
      do i=2,10
         j=nint(y*i)
         e=j-y*i
!         write(*,*) y,i,j,e
         if(abs(e).lt.tiny) then
            m=i
            n=j
            return
         end if
      end do
      write(*,*)'ERROR in fract for x=',x,' Stop!'
      stop
      end subroutine fract

      subroutine shrink(a,b,c,line,l0)
      implicit none
!     implicit none
      character a*2,b*2,c*2
      character line*6
!
      integer :: l0

      if(a.eq.'  ' .and. b.eq.'  '.and. c.eq.'  ') then
         line='     0'
         l0=6
      else if(a.eq.'  ' .and. b.eq.'  ') then
         line='    '//c
         l0=5
         if(c(1:1).eq.'+') l0=6
      else if(a.eq.'  ' .and. c.eq.'  ') then
         line='    '//b
         l0=5
         if(b(1:1).eq.'+') l0=6
      else if(c.eq.'  ' .and. b.eq.'  ') then
         line='    '//a
         l0=5
         if(a(1:1).eq.'+') l0=6
      else if(a.eq.'  ') then
         line='  '//b//c
         l0=3
         if(b(1:1).eq.'+') l0=4
      else if(b.eq.'  ') then
         line='  '//a//c
         l0=3
         if(a(1:1).eq.'+') l0=4
      else if(c.eq.'  ') then
         line='  '//a//b
         l0=3
         if(a(1:1).eq.'+') l0=4
      else
         line=a//b//c
         l0=1
         if(a(1:1).eq.'+') l0=2
      end if
      return
      end subroutine shrink
