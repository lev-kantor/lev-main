      subroutine build(AJ,BJ,iErr)
!....................................................................
!  The space group, i.e. sufficient set of its elements (the so-called
!  crystal class, the group which is ishomorphic to a point group),
!
!           ( rotation | fractional_translation ),
!
! is built here from the space group symbol, SpaceSmb, using the
! table of all 230 space group generators.
!....................................................................
! Input (from structure.inc):
! ^^^^^^^^^^^^^^^^^^^^^^^^^^^
!   SpaceSmb  - symbol for the space group;
!   a00,b00,c00,alpha,beeta,gama  - cell parameters (angles in degrees);
!   Table - International reference table to be used
!
! Output (to structure.inc):
! ^^^^^^^^^^^^^^^^^^^^^^^^^^
!   AI(#,xyz) - standard set of lattice vectors
!   BI(#,xyz) - reciprocal lattice vectors
!   System1    - crystal system (="singonia");
!   Type      - type of the Bravais lattice;
!   MGp - order of the factor group (# of point group operations)
!   KGp(#) - reference to the rotational C-matrix for rotation #
!   FrTr(xyz,#) - fractional translation associated with the rotation #
!....................................................................
      use real8
      use pgroup
      implicit none
      integer :: KGg(MG0)
      real(8) :: FrTrGr(MG0,3),AJ(3,3),BJ(3,3)
!
      integer :: iErr,k,MGg,i
!
!......... read the group generators from the list in the file 'space.grp'
!          and build the lattice (AI and BI)
!
      call ReadGrp(MGg,KGg,FrTrGr,AJ,BJ,iErr)
      if(iErr.eq.1) then
         write(*,*)'ERROR while building up the space group'
         return
      end if
!
!........... build the whole rotational group from the GfamP, GROUPp:
!    MGp - the correct group order MGp
!    KGp - the correct list of elements
!
      MGp=MGg
      do k=1,MGg
         KGp(k)=KGg(k)
      end do
      call permut(GfamP,GROUPp,MGp,KGp,iErr)
      if(iErr.eq.1) go to 400
!
!.......... restore the whole space group (the crystal class), i.e.
!  find all the fractional translations FrTr(i,j) (i=1,2,3)
!  corresponding to all rotations KGp (j=1,...,MGp)
!
      call do_fract(MGg,KGg,FrTrGr)
      write(*,'(a)')'_i__KG__NAZ___{Fractional translation}_____'
      do i=1,MGp
         write(*,'(2(i2,1x),a4,3(1x,f10.5))') i,KGp(i),NAZ(KGp(i)), &
                                 FrTr(1,i),FrTr(2,i),FrTr(3,i)
      end do
      return
!............ Error messages ........................................
400   write(*,*)'.<BUILD>.Execution interrupted due to FATAL errors.'
      return
      end subroutine build

      subroutine ReadGrp(MGg,KGg,FrTrGr,AJ,BJ,jErr)
!.......................................................................
!........... read the group from the list of space groups generators....
!   GfamP  - the group family (Oh or D6h);
!   GROUPp - the group label  (Oh,Td,C2, etc.);
!   MGg    - the number of the group generators;
!   KGg    - the list of generators (from the whole list in C() );
!   FrTrGr - fractional translations for the generators;
!   System - system ("singonia") of the Bravais lattices:
!            Triclinic (Tr), Orthorhombic (Or), Tetragonal (Tt),
!            Cubic (Cu), Rhombohedral (Rh), Hexagonal (He),
!            Monoclinic (Mo);
!   Type   - type of the Bravais lattice:
!            SL? - simple lattice
!            BC? - body-centered
!            FC? - face-centered
!            SC? - side-centered.
!            The symbol ? (=1,2) is used to distinguish additionally
!            the lattices (if it is necessary).
!.......................................................................
!     The file 'space.grp' gives generators of the space group ( both
! rotations {KGg(k),k=1,MGg} and fractional translations {FrTrGr(k)} )
! together with: singonia, type of the Bravais lattice, point group
! and point group family symbols (the latter is actually useless info).
!.......................................................................
      use real8
      use pgroup
      use whereis
      implicit none
      character :: Line*200,Space*6,na4*4
      integer :: LinPos(100),LinEnd(100),NumLin
      integer :: KGg(MG0)
      real(8) :: FrTrGr(MG0,3),AJ(3,3),BJ(3,3)
      character*12,dimension(7) :: Tsystem=(/'Triclinic   ', &
           'Monoclinic  ','Orthorhombic','Tetragonal  ','Cubic       ', &
           'Rhombohedral','Hexagonal   '/)
      character*2,dimension(7) :: &
                iSystem=(/'Tr','Mo','Or','Tt','Cu','Rh','He'/)
      character*2,dimension(5) :: iType=(/'SL','BC','FC','SC','Oc'/)
      character*14,dimension(5) :: iName=(/'simple lattice', &
        'body-centered ','face-centered ', &
           'side-centered ','rectn-centered'/)
!
      integer :: jErr,iSet1,iSet,iErr,i0,iLi,i,MGg,k,ig
      real(8) :: p1,p2,p3
!
!............ fill the 1st element - the unit element
      KGg(1)=1 ; FrTrGr(1,1:3)=0.0
      Space=SpaceSmb
      jErr=0
!
!........... open file of the list of the space groups generators

      open (19,FILE=tetr_dir(tetr_l0:)//'/space.grp.intern', &
                        ACCESS='SEQUENTIAL',status='old',err=103)
!
!.....................................................................
!......... find the records with the space group symbol SpaceSmb .....
!.....................................................................
!
!........ count all occurencies of the group (i.e. all settings)
      iSet1=0
 5    read (19,'(a)',END=6,ERR=100) Line
      if(INDEX(Line,'.....> '//Space).ne.0) iSet1=iSet1+1
      go to 5
 6    write(*,*) '... ',iSet1,' different settings found  ...'
!
!........ select the particular setting
!
      if(iSet1.gt.1)  then
         rewind(19) ; iSet=0
         write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<'
         write(*,*)
         write(*,*)'========= choose ONE setting:'
         write(*,*)
 66      read (19,'(a)',END=67,ERR=100) Line
         if(INDEX(Line,'.....> '//Space).ne.0) then
            iSet=iSet+1
            call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
            write(*,'(a,i1,2a)')'[',iSet,'] ', &
                                      Line(LinPos(3):LinEnd(NumLin))
         end if
         go to 66
 67      write(*,*)
 68      write(*,*)'----------> Choose an appropriate option:'
         read(*,*,err=68) iSet
         write(8,*) iSet
         if(iSet.lt.0 .or. iSet.gt.iSet1) go to 68
         write(*,*) '... Setting ',iSet,' has been chosen ...'
      else
         iSet=1
      end if
!
!.........  find the particular setting iSet of the required space group
!
      rewind (19) ; iSet1=0
10    read (19,'(a)',END=100,ERR=100) Line
      i0=INDEX(Line,'.....> '//Space)
      if(i0.ne.0) iSet1=iSet1+1
      if(iSet1.lt.iSet) go to 10
      write(*,*)'......O.K.! '//Space//' space group is found !!!'
      write(*,*) line
!
!.....................................................................
!......... read System and Type of the Bravais lattice ...............
!.....................................................................
!
!      call SkipL(19,iErr) ; if(iErr.eq.1) go to 100
      call CutStr(Line,NumLin,LinPos,LinEnd,19,0,iErr)
      if(iErr.eq.1.or.NumLin.lt.2) go to 100
!
!........... identify the group name
      iLi=LinEnd(3)-LinPos(3)+1
      if(iLi.eq.1) then
         GROUPp=Line(LinPos(3):LinEnd(3))//'  '
      else if(iLi.eq.2) then
         GROUPp=Line(LinPos(3):LinEnd(3))//' '
      else  if(iLi.eq.3) then
         GROUPp=Line(LinPos(3):LinEnd(3))
      else
         go to 100
      end if
      write(*,*)'.... Crystal point-group is '//GROUPp

!......... read System, Type
      Read(Line(LinPos(1):LinEnd(1)),'(a)',END=100,ERR=100) System1
      do i=1,7
         if(System1.eq.iSystem(i)) then
            write(*,*)'.... Singonia is: '//Tsystem(i)
            go to 15
         end if
      end do
 15   Read(Line(LinPos(2):LinEnd(2)),'(a)',END=100,ERR=100) Type
      do i=1,5
         if(Type(1:2).eq.iType(i)) then
            write(*,*)'.... Bravais lattice is: '//iName(i)
            go to 20
         end if
      end do
!
!.....................................................................
!........... identify the point group elements .......................
!.....................................................................
!
!.......... identify the number of generators
 20   call SkipL(19,iErr)
      if(iErr.eq.1) go to 100
      Read(19,*,END=100,ERR=100) MGg

!........... read all the group generators specified in any order
!       (the unit element is set automatically as the 1st one)
!
      ig=1
      if(MGg.eq.0) go to 30
      call SkipL(19,iErr)
      if(iErr.eq.1) go to 100
 11   call CutStr(Line,NumLin,LinPos,LinEnd,19,0,iErr)
      if(iErr.eq.1.or.NumLin.lt.1) go to 100
      do 2 k=1,NumLin
         ig=ig+1
         if(ig.gt.MGg+1) go to 30
         iLi=LinEnd(k)-LinPos(k)+1
         if(iLi.eq.1) then
            na4='   '//Line(LinPos(k):LinEnd(k))
         else if(iLi.eq.2) then
            na4='  '//Line(LinPos(k):LinEnd(k))
         else if(iLi.eq.3) then
            na4=' '//Line(LinPos(k):LinEnd(k))
         else if(iLi.eq.4) then
            na4=Line(LinPos(k):LinEnd(k))
         end if
         call element(na4,KGg(ig),iErr)
         if(iErr.eq.1) go to 100
 2    end do
      if(ig.lt.MGg+1) go to 11
!
!.....................................................................
!........... from {System , Type} find:
!     AJ - basic translations of the direct lattice in the correct
!          units (due to a00,b00,c00,alpha,beeta,gama) of the
!          conventional cell
!.....................................................................
!
 30   call DirLatt1(AJ,iErr)
      if(iErr.eq.1) go to 123
      write(*,*)'....... Direct lattice basic translations are: ....'
      do i=1,3
         write(*,7) i,AJ(i,1),AJ(i,2),AJ(i,3)
 7       format(i1,' => (',f10.5,',',f10.5,',',f10.5,')')
      end do
!
!___________________ get the reciprocal lattice vectors BI(#,comp)
! (in the units of 2*PI) from the direct ones, AJ(#,comp)
!
      call INVER(AJ,BJ)
!
!.....................................................................
!......... read fractional translations of the group generators ......
!......... and set them to the correct units: they are written  ......
!......... one vector per line in the file 'space.grp.intern'   ......
!......... with respect to the corresponding CONVENTIONAL CELL  ......
!.....................................................................
!
!
!......... construct the conventional unit cell .................
!
      call conv_cell(AJ,AJc,BJc,T_matr,System1,Type)
      write(*,*)'....... Conventional cell basic translations are: ....'
      do i=1,3
         write(*,7) i,AJc(i,1),AJc(i,2),AJc(i,3)
      end do

!......... obtain fractional translations (in Cartesian coordinates)
!
      if(MGg.eq.0) go to 40
      do k=2,MGg+1
         call SkipL(19,iErr)
         if(iErr.eq.1) go to 100
         Read(19,*,END=100,ERR=100) p1,p2,p3
         FrTrGr(k,1)=p1*AJc(1,1)+p2*AJc(2,1)+p3*AJc(3,1)
         FrTrGr(k,2)=p1*AJc(1,2)+p2*AJc(2,2)+p3*AJc(3,2)
         FrTrGr(k,3)=p1*AJc(1,3)+p2*AJc(2,3)+p3*AJc(3,3)
      end do

!......... final number of generators
 40   MGg=MGg+1
!......... if everything is o.k.
      write(*,*) &
       '...(((( space.grp.intern )))) - file was read correctly !...'
      close (19)
      return
!
!............. error messages .....................................
 100  write(6,*)'FATAL! Error while reading space.grp file ...'
      go to 123
 103  write(6,*)'FATAL! Can not open space.grp file ...'
 123  jErr=1
      return
      end subroutine ReadGrp

      subroutine element(na4,Num,iErr)
!....................................................................
!   Gives the number (with respect to the list of rotations
! in C(..) ) for the rotational element Line(1:iLi)
!....................................................................
!     implicit none
      use pgroup
      implicit none
      character :: na4*4
!
      integer :: Num,iErr,J

!_ _ _ _ _ _ _ _ Check all names using their correct list and find Num
      do J=1,64
         if(na4.EQ.NAZ(J)) then
            Num=J
            return
         end if
      end do
!...........if no:
      write(*,*)'FATAL!...The name '//na4//' can not be identified'
      iErr=1
      return
      end subroutine element

      subroutine DirLatt1(AJ,iErr)
!.......................................................................
!      Direct lattice basic translation vectors AJ are built here
!.......................................................................
      use real8
      use pgroup
      implicit none
      real(8) :: AJ(3,3)
      character :: answer
!
      integer :: iErr
      real(8) :: aN,T1,T2

      AJ=0.0
!.......... ask if a general input is desirable
      answer='n'
!      if(System1.ne.'Tr') then
!         write(*,*)'General specification of the lattice (y/any)'
!         read(*,'(a)') answer
!      end if
!
!.......... Triclinic/General system
      if(answer.eq.'y' .or. System1.eq.'Tr') then
 1       write(*,*) &
         'Specify cell via {a,b,c} (A) and {alpha,beta,gamma} (degrees)'
         read(*,*,err=1) a00,b00,c00,alph,beet,gam
         write(8,*) a00,b00,c00,alph,beet,gam
         alph=alph/180.*pi
         beet=beet/180.*pi
         gam=gam/180.*pi
         aN=(cos(gam)-cos(alph)*cos(beet))/sin(alph)
         AJ(1,1)=a00
         AJ(2,1)=b00*cos(alph)
           AJ(2,2)=b00*sin(alph)
           AJ(3,1)=c00*cos(beet)
             AJ(3,2)=c00*aN
             AJ(3,3)=c00*sqrt(sin(beet)**2-aN*aN)
         return
      end if
!
!.......... Monoclinic system
      if(System1.eq.'Mo') then
!___________________ Simple lattice
          if(Type.eq.'SL1') then
 2           write(*,*) &
             '  Specify cell via {a,b,c} (A) and {beta} (degrees)'
             read(*,*,err=2) a00,b00,c00,gam
             write(8,*) a00,b00,c00,gam
             beet=gam/180.*pi
             AJ(1,1)=a00
               AJ(2,2)=b00
                  AJ(3,1)=c00*cos(beet)
                  AJ(3,3)=c00*sin(beet)
          else if(Type.eq.'SL0') then
 22          write(*,*) &
             '  Specify cell via {a,b,c} (A) and {gamma} (degrees)'
             read(*,*,err=22) a00,b00,c00,gam
             write(8,*) a00,b00,c00,gam
             gam=gam/180.*pi
             AJ(1,2)=-a00
               AJ(2,1)=b00*sin(gam)
               AJ(2,2)=-b00*cos(gam)
                  AJ(3,3)=c00

!___________________ Side-centered
          else
 3           write(*,*) &
             '  Specify cell via {a,b,c} (A) and {gamma} (degrees)'
             read(*,*,err=3) a00,b00,c00,gam
             write(8,*) a00,b00,c00,gam
             gam=gam/180.*pi
             AJ(1,2)=-a00
               AJ(2,1)= 0.5*b00*sin(gam)
               AJ(2,2)=-0.5*b00*cos(gam)
               AJ(2,3)=-0.5*c00
                 AJ(3,1)= 0.5*b00*sin(gam)
                 AJ(3,2)=-0.5*b00*cos(gam)
                 AJ(3,3)= 0.5*c00
          end if
!
!.......... Orthorhombic system
      else if(System1.eq.'Or') then
 4       write(*,*) '  Specify cell via {a,b,c} (A)'
         read(*,*,err=4) a00,b00,c00 ; write(8,*) a00,b00,c00
!___________________ Simple lattice
          if(Type.eq.'SL0') then
             AJ(1,1)=a00
               AJ(2,2)=b00
                 AJ(3,3)=c00

!___________________ Face-centered (1) lattice (base-centered)
          else if(Type.eq.'FC1') then
             AJ(1,1)= 0.5*a00
             AJ(1,2)= 0.5*b00
               AJ(2,1)= 0.5*a00
               AJ(2,2)=-0.5*b00
                 AJ(3,3)=c00

!___________________ Face-centered (2) lattice
          else if(Type.eq.'FC2') then
             AJ(1,1)= 0.5*a00
             AJ(1,3)= 0.5*c00
               AJ(2,2)= 0.5*b00
               AJ(2,3)= 0.5*c00
                 AJ(3,1)= 0.5*a00
                 AJ(3,2)= 0.5*b00

!___________________ Body-centered lattice
          else if(Type.eq.'BC0') then
             AJ(1,1)= 0.5*a00
             AJ(1,2)= 0.5*b00
             AJ(1,3)= 0.5*c00
               AJ(2,1)=-0.5*a00
               AJ(2,2)=-0.5*b00
               AJ(2,3)= 0.5*c00
                AJ(3,1)= 0.5*a00
                AJ(3,2)=-0.5*b00
                AJ(3,3)=-0.5*c00

!___________________ centred rectangular (for 2D space groups, type =oc)
          else if(Type.eq.'Oc2') then
             AJ(1,1)= 0.5*a00
             AJ(1,2)= 0.5*b00
               AJ(2,2)=b00
                AJ(3,3)=c00
          end if
!
!.......... Tetragonal system
      else if(System1.eq.'Tt') then
 8       write(*,*)'  Specify cell via {a,c} (A)'
         read(*,*,err=8) a00,c00 ; write(8,*) a00,c00
!___________________ Simple lattice
          if(Type.eq.'SL0') then
             AJ(1,1)=a00
               AJ(2,2)=a00
                 AJ(3,3)=c00
!___________________ Body-centered lattice (1)
          else if(Type.eq.'BC1') then
             AJ(1,1)=-0.5*a00
             AJ(1,2)= 0.5*a00
             AJ(1,3)= 0.5*c00
               AJ(2,1)= 0.5*a00
               AJ(2,2)=-0.5*a00
               AJ(2,3)= 0.5*c00
                 AJ(3,1)= 0.5*a00
                 AJ(3,2)= 0.5*a00
                 AJ(3,3)=-0.5*c00
          end if
!
!.......... Cubic system
      else if(System1.eq.'Cu') then
 10      write(*,*) '  Specify cell via {a} (A)'
         read(*,*,err=10) a00 ; write(8,*) a00
!___________________ Simple lattice
         if(Type.eq.'SL0') then
            AJ(1,1)=a00
             AJ(2,2)=a00
              AJ(3,3)=a00
!___________________ Body-centered lattice
          else if(Type.eq.'BC0') then
             AJ(1,1)=-a00*0.5
             AJ(1,2)= a00*0.5
             AJ(1,3)= a00*0.5
               AJ(2,1)= a00*0.5
               AJ(2,2)=-a00*0.5
               AJ(2,3)= a00*0.5
                 AJ(3,1)= a00*0.5
                 AJ(3,2)= a00*0.5
                 AJ(3,3)=-a00*0.5
!___________________ Face-centered lattice
          else
             AJ(1,2)=a00*0.5
             AJ(1,3)=a00*0.5
               AJ(2,1)=a00*0.5
               AJ(2,3)=a00*0.5
                 AJ(3,1)=a00*0.5
                 AJ(3,2)=a00*0.5
          end if
!
!.......... Rhombohedral system
      else if(System1.eq.'Rh') then
 11      write(*,*) '  Specify cell via {a} (A) and {alpha} (degrees)'
         read(*,*,err=11) a00,alph ; write(8,*) a00,alph
         alph=alph/180.*pi
         if(alph.gt.pi*2.0/3.0) go to 100
         T1=a00*sqrt((1.0-cos(alph))*2./3.)
         T2=a00*sqrt((1.0+2*cos(alph))/3.)
           AJ(1,2)=-T1
           AJ(1,3)= T2
             AJ(2,1)=sqrt(3.)/2.0*T1
             AJ(2,2)=T1*0.5
             AJ(2,3)=T2
               AJ(3,1)=-sqrt(3.)/2.0*T1
               AJ(3,2)= T1*0.5
               AJ(3,3)= T2
!
!.......... Hexagonal system: (rotated) setting from Bradkey & Cracknell
      else
 12      write(*,*) '  Specify cell via {a,c} (A)'
         read(*,*,err=12) a00,c00 ; write(8,*) a00,c00
         AJ(1,1)=a00
           AJ(2,1)=-0.5*a00
           AJ(2,2)= 0.5*a00*sqrt(3.0)
             AJ(3,3)=c00
      end if
      return
!
!............. error messages .....................................
 100  write(*,*)'FATAL!... UC shape is inconsistent with the lattice'
      iErr=1
      return
      end subroutine DirLatt1

      subroutine do_fract(MGg,KGg,FrTrGr)
!.....................................................................
!    The routine builds up the complete space group of elements in the
! form: ( KGp(j) | FrTr(i,j) ), where
!    KGp(j) - rotation C( , ,KGp(j)),
!    FrTr(i,j) - fractional translation,
!    i=1,2,3 and j=1,...,MGp.
!.....................................................................
      use real8
      use pgroup
      implicit none
      logical :: iCheck(MG0)
      integer :: KGg(MG0)
      real(8) :: FrTrGr(MG0,3),TrK(3)
!
      integer :: j,k,MGg,j1,jK
!
!...... initialize iCheck by .true. if FrTr is present, and by
! .false. if not. Then, fill FrTr by known fract. translations
      do j=1,MGp
         iCheck(j)=.false.
         do k=1,MGg
            if(KGg(k).eq.KGp(j)) then
               FrTr(1,j)=FrTrGr(k,1)
               FrTr(2,j)=FrTrGr(k,2)
               FrTr(3,j)=FrTrGr(k,3)
               iCheck(j)=.true.
            end if
         end do
      end do
!
!.......... double loop over elements with iCheck=.true.:
!  by myltiplication, new elements are obtained, and new translations
!  are found, increasing the range of loops, untill all elements of the
!  group will be eghousted.
!
 10   do 100 j=1,MGp
         if(.not.iCheck(j)) go to 100
         do 90 j1=1,MGp
            if(.not.iCheck(j1)) go to 90
!___________product of j,j1 is jK
            call Find_Rot1(j,j1,jK)
!___________find fractional translation for jK, if it is 'new'
            if(.not.iCheck(jK)) then
               call Find_Trn(j,j1,TrK)
               FrTr(1,jK)=TrK(1)
               FrTr(2,jK)=TrK(2)
               FrTr(3,jK)=TrK(3)
               iCheck(jK)=.true.
            end if
 90      continue
 100  continue
!________check whether it is necessary to repeat the loops
      do j=1,MGp
         if(.not.iCheck(j)) go to 10
      end do
      return
      end subroutine do_fract

      subroutine Find_Rot1(I1,I2,K)
!.....................................................................
!     Seeks for the rotation K which results from the product I1 x I2
!  of rotations I1,I2 (numbers I1,I2,K are from the KGp list).
!.....................................................................
      use real8
      use pgroup
      implicit none
      real(8) :: c1(3,3)
      real(8),parameter :: tiny=0.00001d0
!
      integer :: KGi1,KGi2,I1,I2,K,i,j,Irot,KGi

      KGi1=KGp(I1)
      KGi2=KGp(I2)
!..........build the rotation I1*I2 --> c1
      do i=1,3
         do j=1,3
            c1(i,j)=C(i,1,KGi1)*C(1,j,KGi2)+C(i,2,KGi1)*C(2,j,KGi2)+ &
                 C(i,3,KGi1)*C(3,j,KGi2)
         end do
      end do
!...........find the appropriate rotation from the KGp list
      do 20 Irot=1,MGp
         KGi=KGp(Irot)
         do i=1,3
            do j=1,3
               if(abs(C(i,j,KGi)-c1(i,j)).gt.tiny) go to 20
            end do
         end do
         K=Irot
         return
 20   continue
      return
      end subroutine Find_Rot1

      subroutine transform(Q,Q1,Irot)
!.....................................................................
!  Vector Q is transformed by the space-group operation Irot
!  (from KGp set) which includes the accompanying fractional
!  translation to give Q1, i.e. (rot|fract.transl) * Q = Q1
!.....................................................................
      use real8
      use pgroup
      implicit none
      real(8) :: Q(3),Q1(3)
!
      integer :: KGI,Irot

      KGI=KGp(Irot)
      Q1(1)=C(1,1,KGI)*Q(1)+C(1,2,KGI)*Q(2)+C(1,3,KGI)*Q(3)+FrTr(1,Irot)
      Q1(2)=C(2,1,KGI)*Q(1)+C(2,2,KGI)*Q(2)+C(2,3,KGI)*Q(3)+FrTr(2,Irot)
      Q1(3)=C(3,1,KGI)*Q(1)+C(3,2,KGI)*Q(2)+C(3,3,KGI)*Q(3)+FrTr(3,Irot)
      return
      end subroutine transform

      subroutine Find_Trn(I1,I2,TrK)
!.....................................................................
!     Get the fractional translation TrK(3) corresponding to
! the product of the group elements I1*I2 with fractional translations
! Tr1=Tr(I1) and Tr2=Tr(I2), respectively:
!   Tr3 = Rot(I1)* Tr2 + Tr1 == (Rot(I1)|Tran(I1))*Tr2
!.....................................................................
      use real8
      use pgroup
      use tetrag1
      implicit none
      real(8) :: TrK(3)
!
      integer :: I1,I2
!
!___________ act by the group element first
!
      call transform(FrTr(1,I2),TrK,I1)
!
!___________ return the image to the 0-th cell if necessary
!
      call reducn(TrK,AJ,BJ)
      return
      end subroutine Find_Trn

      subroutine conv_cell(AI,AJ,BJ,T,System,Type)
!................................................................
!    Direct (AJ) and reciprocal (BJ) vectors of the conventional
! cell are constructed from direct primitive vectors (AI).
!   T - transformation matrix between the two cells.
!................................................................
      use real8
      implicit none
      real(8) :: AI(3,3),AJ(3,3),BJ(3,3),T(3,3)
      character :: System*2,Type*3
!
      integer :: i,j

      do i=1,3
         do j=1,3
            t(i,j)=0.0
         end do
         t(i,i)=1.0
      end do
!
!.......... Triclinic system
      if(System.eq.'Tr') then
!         write(*,*)'Using unit matrix to translate to conventional cell'
!
!.......... Monoclinic system
      else if(System.eq.'Mo') then
!___________________ Simple lattice
          if(Type(1:2).eq.'SL') then
!___________________ base-centered
          else
             t(2,3)= 1.0
             t(3,2)=-1.0
          end if
!
!.......... Orthorhombic system
      else if(System.eq.'Or') then
!___________________ Simple lattice
          if(Type.eq.'SL0') then
!___________________ Face-centered (1) lattice (base-centered)
          else if(Type.eq.'FC1') then
             t(1,2)= 1.0
             t(2,2)=-1.0
             t(2,1)= 1.0
!___________________ Face-centered (2) lattice
          else if(Type.eq.'FC2') then
             do i=1,3
                do j=1,3
                   t(i,j)=1.0
                end do
             end do
             t(1,2)=-1.0
             t(2,1)=-1.0
             t(3,3)=-1.0
!___________________ Body-centered lattice
          else if(Type.eq.'BC0') then
             t(1,3)= 1.0
             t(2,2)=-1.0
             t(2,3)=-1.0
             t(3,1)= 1.0
             t(3,2)= 1.0
             t(3,3)= 0.0
!___________________ centred rectangular (for 2D space groups, type =oc)
          else if(Type.eq.'Oc2') then
             t(1,1)= 2.0
             t(1,2)=-1.0
          end if
!
!.......... Tetragonal system
      else if(System.eq.'Tt') then
!___________________ Simple lattice
          if(Type.eq.'SL0') then
!___________________ Body-centered lattice (1)
          else if(Type.eq.'BC1') then
             do i=1,3
                do j=1,3
                   t(i,j)=1.0
                end do
                t(i,i)=0.0
             end do
          end if
!
!.......... Cubic system
      else if(System.eq.'Cu') then
!___________________ Simple lattice
          if(Type.eq.'SL0') then
!___________________ Body-centered lattice
          else if(Type.eq.'BC0') then
             do i=1,3
                do j=1,3
                   t(i,j)=1.0
                end do
                t(i,i)=0.0
             end do
!___________________ Face-centered lattice
          else
             do i=1,3
                do j=1,3
                   t(i,j)=1.0
                end do
                t(i,i)=-1.0
             end do
          end if
!
!.......... Rhombohedral (trigonal) system
      else if(System.eq.'Rh') then
!
!.......... Hexagonal system:
      else
      end if

!...................................................................
![2]......... building conventional unit cell ......................
!...................................................................

      do i=1,3
         do j=1,3
            AJ(i,j)=t(i,1)*AI(1,j)+t(i,2)*AI(2,j)+t(i,3)*AI(3,j)
         end do
      end do
!      write(9,*)'Conventional unit cell vectors:'
!      do i=1,3
!         write(9,'(i1,a,3(f10.5,x))') i,' => ',(AJ(i,j),j=1,3)
!      end do
!
!____________ reciprocal vectors for the conventional cell
!
      call INVER(AJ,BJ)
      return
      end subroutine conv_cell

