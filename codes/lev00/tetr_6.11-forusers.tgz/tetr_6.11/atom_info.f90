module atom_info
use sym_par
  implicit none
!...............................................................................
! info arrays for atoms in orbits to facilitate access if some orbits are fixed
! (see file: make_fcm.f)
!...............................................................................
!    at_info(j)       - actual atom across orbits (in the new order corresponding to
!                         orbits) for degree of freedom j=1,...,Ndim
!     xyz_info(j)       - x,y,z for degree of freedom j
! species_info(j)       - species # for j
! old_atom_from_vibr(j) - old atom number for vibrational degree of freedom j
!
       integer,dimension(:),allocatable :: at_info,xyz_info,species_info, &
                  old_atom_from_vibr

end module atom_info
