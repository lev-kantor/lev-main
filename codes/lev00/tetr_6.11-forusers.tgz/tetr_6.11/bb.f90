module Bb
  implicit none
  integer :: M11=0,N11=0,M22=0,N22=0,M33=0,N33=0
end module Bb
