module working
use tetr_param  
use sym_par
implicit none
!      common /trasf/ W_all
       real(8) :: W_all(3,N0LT,K0DM0+6,3)
end module working
