module buffer_c
use tetr_param
  implicit none
!     common /buffer_c/ TIc,ITIc,First_atom_c,isortc, &
!                       Natom_in_cellc
       real(8) :: TIc(3,N0LT)
       integer :: ITIc,isortc(N0LT),Natom_in_cellc(N0LT),First_atom_c
end module buffer_c
