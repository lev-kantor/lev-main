      subroutine hat()
!     implicit none
      use whereis
      implicit none
      character :: line*30
      logical :: file_exist
!
      write(*,*)'......................................................'
      write(*,*)'... TETR is an interface to VASP/SIESTA/QUICKSTEP ....'
      write(*,*)'......................................................'
      write(*,*)'>>>>>>>>  1st release: 25.07.1994'
      include 'build.hat'
      call system('date > tmp.date')
      open(1,file='tmp.date')
      read(1,'(a)') line
      close (1,status='delete')
      write(*,*)'>>>>>>>>  today      : '//line
      write(*,*)'......................................................'
      write(*,*)'......      inquiries to L. Kantorovich      .........'
      write(*,*)'......................................................'

!............ get the home directory of tetr

      call system('echo $HOME_TETR > tmp.date')
      open(1,file='tmp.date')
      read(1,'(a)') tetr_dir
      close (1,status='delete')

!      tetr_dir=' /Users/lev/Software/TOOLS/TETR'

      call right(tetr_dir,200,tetr_l0)
      if(tetr_l0.eq.200) then
         write(*,*)'FATAL! Variable $HOME_TETR is not set!'
         stop
      end if
      if(tetr_dir(200:).eq.'/') then
         write(*,*)'ERROR: $HOME_TETR ends with "/" . Remove it!'
         stop
      end if
!      write(*,'(a)') tetr_dir(tetr_l0:)

!........... checking existence of tetr there

      if(.not.file_exist('tetr                ',4)) stop
      write(*,'(a)')'.... TETR home directory: '//tetr_dir(tetr_l0:)

!........... checking symgrp.rep

      if(.not.file_exist('symgrp.rep          ',10)) stop

!........... checking space.grp.int

      if(.not.file_exist('space.grp.intern    ',16)) stop

!........... checking group.list.int

      if(.not.file_exist('group.list.intern   ',17)) stop

!........... checking collect_forces

      if(.not.file_exist('collect_forces      ',14)) stop

!........... checking get_forces

      if(.not.file_exist('get_forces          ',10)) stop

!........... checking sym_for_siesta.info

      if(.not.file_exist('sym_for_siesta.info ',19)) stop

!............ everything is fine

      return
    end subroutine hat




