module sym_par
implicit none
! N0RB  - total max. # of orbits
! MG0   - max. # of group elements
! N0IR  - max. # total number of any irr.repr. (1,2,3-dim.)
! N0IR2 - max. # of 2-dim.irr.repr.
! N0IR3 - max. # of 3-dim.irr.repr.
! K0DM0 - max repetition number for irreps

      integer,parameter :: N0RB=2000,MG0=64,N0IR=100,N0IR2=40
      integer,parameter :: N0IR3=4,K0DM0=2000,L0GM=15*(15-1)/2+15

end module sym_par
