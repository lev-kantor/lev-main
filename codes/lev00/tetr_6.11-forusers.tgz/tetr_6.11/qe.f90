module qe
use tetr_param
implicit none
!...... something needed for QE

!     common /QE/ QE_kpoint,QE_weight,QE_masses, &
!               QE_nkp,psp_l0,Nsp_QE, &
!               psp_names
      real(8) :: QE_kpoint(Nkpoint,3),QE_weight(Nkpoint),QE_masses(N0KD)

      character :: psp_names(N0KD)*50
      integer :: psp_l0(N0KD),QE_nkp,Nsp_QE
end module qe
