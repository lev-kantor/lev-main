module symgenv
use sym_par  
use tetr_param
implicit none

![2]...... info about the current orbit of atoms:
!         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
! W(dim,rep,atom,m+2) - transformation matrix for the current orbit:
!                         dim  - components of 2D or 3D irreps
!                         rep  - repetition number
!                         atom - atom from the orbit
!                         m=-1,0,1; corresponds to y,z,x atomic coordinates
! GAMA()              - gamma matrix (repetition-repetition) to orthogonalise symmetry
!                       adapted coordinates (?)
! M1                  = 2*L1+1, where L1 = 3 in our case (displacements are like p-functions)
! N_orb               - number of atoms in the current orbit
! MGN                 - number of elements in the local group
! KJ(gen)             - group element number for the orbit generator gen
! KH(gl)              - group element number for the local group element gl
!

!     common /transf/ W,GAMA, &
!                     M1,N_orb,MGN,KJ,KH
      real(8) :: W(3,9,MG0,3),GAMA(L0GM)
      integer :: M1,N_orb,MGN,KJ(MG0),KH(MG0)

![3].................. info about the whole system/molecule
!                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
! R1(orb,xyz)        - coordinates of the 1st atom of orbit orb
! KAN(orb)           - number of atoms in orbit orb
! PVTRKM()           - working array
! IRALF(ir)          - repetition number for the irrep ir
! ISORT1(orb)        - atomic species number for orbit orb
! orb_to_old(orb,nt) - actual atomic number in the list TI() for atom  nt
!                      from the orbit orb
! Fix(orb)           - .true. if the orbit orb is fixed
! NORB               - number of orbits
! Linear             - if the system/molecule is linear along the Z axis

!     common /whole_sym/  R1, &
!                 KAN,ISORT1,IRALF,NORB, &
!                 PVTRKM,orb_to_old, &
!                 Linear,Fix
      real(8) :: R1(N0RB,3)
      integer :: KAN(N0RB),ISORT1(N0RB),IRALF(N0IR),NORB, &
                  PVTRKM(15,2,N0RB,N0IR),orb_to_old(N0RB,MG0)
      Logical Linear,Fix(N0RB)
end module symgenv
