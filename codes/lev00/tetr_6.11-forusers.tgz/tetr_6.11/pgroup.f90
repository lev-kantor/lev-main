module pgroup
use pgroup_base
use sym_par  
use tetr_param
implicit none

!................ general group information
!                 ^^^^^^^^^^^^^^^^^^^^^^^^^
!     NALFA(ir)       - dimension of irrep ir
!       NEPR          - # of irreps for this point group
!        MG           - # of elements in the group
!       KG(g)         - the placement # of the group element g in the transformation arrays C()
!     NAZVIR(ir)      - irrep ir name
!       GROUPN        - group name
!     XX(ir,g)        - character of irrep ir, element g
! D2ALPHA(i,j,g,ir)   - matrix (i,j) corresponding to 2D irrep ir (in the list of 2D irreps),
!                       element g
! D3ALPHA(i,j,g,ir)   - matrix (i,j) corresponding to 3D irrep ir (in the list of 2D irreps),
!                       element g
!  ICMPL(ir)          - is 0 for irreducible and 1 for reducible irreps; the
!                       latter are constructed artificialy by combining 2
!                       complex conjugate 1D irreps into one real 2D irrep.
!
!     common /GRUPA/  XX,D2ALFA,D3ALFA, &
!                     NALFA,NEPR,MG, &
!                     KG,ICMPL,NAZVIR,GROUPN
      real(8) :: XX(N0IR,MG0),D2ALFA(2,2,MG0,N0IR2), &
                  D3ALFA(3,3,MG0,N0IR3)
      integer :: KG(MG0),ICMPL(N0IR),NALFA(N0IR),NEPR,MG
      character :: NAZVIR(N0IR)*3,GROUPN*3

!
!............ point group of the LARGE lattice (LUC)
!  GroupB - the Bravais lattice point group name;
!  MGp - the group order (less than 48);
!  KGp(element) - for every group element (from 1 till MGp) it gives
!                 the direct reference to the corresponding matrix
!                 which is contained in common /p_group/
!                 as C(3,3,KGp(element))
!  MGb - the Bravais lattice group order;
!  KGb(element) - a list of elements for the Bravais lattice group
!                 made in the same way as in KGp(element)
!
!     common /group/ MGp,KGp,MGb,KGb,GroupB
      integer :: MGp,KGp(48),MGb,KGb(48)
      character :: GroupB*3
!
!............ all point-group operations ordered in some dummy way
!     common /p_group/ C
      real(8) :: C(3,3,64)
      
!............ some necessary stuff for the space group is here
!  FrTr(xyz,rot) - fractional translation associated with rotation
!  GROUPp        - name of the point group
!  GfamP         - point group family (either Oh or D6h)
!  System1       - crystal system (="singonia")
!  Type          - Bravais lattice type
!  SpaceSmb      - space group
! iSblGo(#,rot)  - maps up one sublattice to another under
!                  the given rotation

!     common /sp_group/ FrTr, &
!                       iSblGo, &
!                       GROUPp,GfamP,System1,Type,SpaceSmb
      real(8) :: FrTr(3,MG0)
      integer :: iSblGo(N0LT,MG0)
      character :: System1*2,Type*3,SpaceSmb*6
      character :: GROUPp*3, GfamP*3

! AJc - conventional cell direct basic translations
! BJc - corresponding reciprocal basic translations
! T_matr - tranformation matrix from primitive to conventional cell
! primitive - if .true., then reduction of fractional translations is done
!             wrt primitive basic vectors; otherwise (default) - wrt
!             basic translations of the conventional cell as in Tables

!_____________ Unit cell geometry: 3 lengthes and 3 angles
!     common /unitcell/ a00,b00,c00,alpha,beeta,gamma,alph,beet,gam, &
!                       AJc,BJc,T_matr, &
!                       primitive
      real(8) :: a00,b00,c00,alpha,beeta,gamma,alph,beet,gam, &
                        AJc(3,3),BJc(3,3),T_matr(3,3)
      logical :: primitive
      
CONTAINS
  subroutine C_matrix()
    real CC(3,3,64)
    real,parameter :: r3=0.8660254,r3m=-0.8660254
!................. Oh - rotations .............................
    CC=reshape( (/1.,0.,0.,   0.,1.,0.,   0.,0.,1., &
       0.,1.,0., -1.,0.,0., 0.,0.,1.,   0.,0.,-1., 0.,1.,0.,   1.,0.,0., &
       1.,0.,0.,  0.,0.,1., 0.,-1.,0., -1.,0.,0.,  0.,-1.,0.,  0.,0.,1., &
       0.,-1.,0., 1.,0.,0., 0.,0.,1.,   1.,0.,0.,  0.,-1.,0., 0.,0.,-1., &
       1.,0.,0.,  0.,0.,-1., 0.,1.,0.,  -1.,0.,0., 0.,1.,0.,  0.,0.,-1., &
       0.,0.,1.,  0.,1.,0., -1.,0.,0.,  0.,0.,-1., -1.,0.,0., 0.,1.,0., &
       0.,1.,0.,  0.,0.,1.,  1.,0.,0.,  0.,0.,-1.,  1.,0.,0., 0.,-1.,0., &
       0.,-1.,0., 0.,0.,-1., 1.,0.,0.,  0.,-1.,0.,  0.,0.,1., -1.,0.,0., &
       0.,0.,1.,  1.,0.,0.,  0.,1.,0.,  0.,1.,0.,  0.,0.,-1., -1.,0.,0., &
       0.,0.,1.,  -1.,0.,0., 0.,-1.,0., 0.,1.,0.,  1.,0.,0.,  0.,0.,-1., &
       0.,-1.,0., -1.,0.,0., 0.,0.,-1., -1.,0.,0., 0.,0.,1.,  0.,1.,0., &
       -1.,0.,0., 0.,0.,-1., 0.,-1.,0., 0.,0.,-1., 0.,-1.,0., -1.,0.,0., &
        0.,0.,1., 0.,-1.,0., 1.,0.,0., 1.,0.,0.,  0.,1.,0.,   0.,0.,-1., &
       -1.,0.,0., 0.,1.,0., 0.,0.,1.,  1.,0.,0.,   0.,-1.,0.,  0.,0.,1., &
       0.,-1.,0., 1.,0.,0., 0.,0.,-1., -1.,0.,0.,  0.,0.,-1.,  0.,1.,0., &
       0.,0.,1.,  0.,-1.,0., -1.,0.,0., 0.,1.,0., -1.,0.,0.,  0.,0.,-1., &
       -1.,0.,0.,   0.,0.,1.,   0.,-1.,0.,  &
!................. D6h - rotations .............................
       0.,0.,-1.,  0.,-1.,0.,  1.,0.,0., &
       0.,0.,1., -1.,0.,0., 0.,1.,0., 0.,-1.,0.,  0.,0.,1.,   1.,0.,0., &
       0.,1.,0., 0.,0.,1., -1.,0.,0., 0.,-1.,0.,  0.,0.,-1., -1.,0.,0., &
       0.,0.,1., 1.,0.,0., 0.,-1.,0., 0.,0.,-1.,  1.,0.,0.,   0.,1.,0., &
       0.,0.,-1., -1.,0.,0., 0.,-1.,0., 0.,1.,0., 0.,0.,-1.,  1.,0.,0., &
       0.,1.,0., 1.,0.,0., 0.,0.,1.,  0.,-1.,0., -1.,0.,0.,   0.,0.,1., &
       0.,0.,1., 0.,1.,0., 1.,0.,0.,  0.,0.,-1.,  0.,1.,0.,  -1.,0.,0., &
       1.,0.,0., 0.,0.,1., 0.,1.,0.,  1.,0.,0.,   0.,0.,-1., 0.,-1.,0., &
      -1.,0.,0., 0.,-1.,0., 0.,0.,-1., 0.5,r3,0.,r3m,0.5,0.,0.,0.,1., &
      -0.5, r3,0.,r3m,-0.5,0.,0.,0.,1., -0.5,r3m,0.,r3,-0.5,0.,0.,0.,1., &
       0.5,r3m,0.,r3,0.5,0.,0.,0., 1., -0.5,r3m,0.,r3m,0.5,0.,0.,0.,-1., &
       0.5,r3m,0.,r3m,-0.5,0.,0.,0.,-1., 0.5,r3,0.,r3,-0.5,0.,0.,0.,-1., &
      -0.5,r3,0.,r3, 0.5,0.,0.,0.,-1., -0.5,r3m,0.,r3,-0.5,0.,0.,0.,-1., &
       0.5,r3m,0.,r3, 0.5,0.,0.,0.,-1., 0.5,r3,0.,r3m, 0.5,0.,0.,0.,-1., &
      -0.5,r3,0.,r3m,-0.5,0.,0.,0.,-1., 0.5, r3,0.,r3,-0.5,0.,0.,0., 1., &
      -0.5,r3,0.,r3, 0.5,0.,0.,0., 1., -0.5,r3m,0.,r3m,0.5,0.,0.,0., 1., &
      0.5,r3m,0.,r3m,-0.5,0.,0.,0., 1./),shape(C))
    C=CC
    
 end subroutine C_matrix
  
end module pgroup
