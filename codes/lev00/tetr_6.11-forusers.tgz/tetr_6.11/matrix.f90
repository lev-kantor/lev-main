module matrix
use sym_par  
implicit none
!............ matrices for options V2, V3
       real(8),dimension(:,:),allocatable :: G_mat,F_mat
!........... memory for eigenproblem
       real(8),dimension(:,:),allocatable :: EigV
       real(8),dimension(:),allocatable :: Work,EigR
end module matrix
