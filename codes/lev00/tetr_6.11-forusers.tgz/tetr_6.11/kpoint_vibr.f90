      subroutine kpoint_vibr(Which_Code,kpoint,nkp)
!....................................................................
!         It does vibrations of supercells using an Abel group of
!  internal translations.
! (1) a supercell is obtained from the given primitive cell; the 3x3
!     extention matrix is obtained together with reciprocal lattice
!     vectors for both systems ("small" and "large")
! (2) the group of internal translations is obtained, including:
!     (i) internal translations
!     (ii) k-points in the BZ of the "small" (primitive) system that
!          correspond to the Gamma point in the reduced BZ of the
!          "large" (supercell) system
!     (iii) all irreducible representations for this group;
! (3) all atoms are broken down into orbits
! (5) masses of atoms for every species (a.e.m.) are taken from default
! (6) the matrix of masses is calculated and written into a file
! (7) the group-theoretical analysis is performed for every irrep
! (8) then it is possible either to construct geometries that correspond
!     to activated mode one by one, or, preferably, all in one go using
!     option Au (automatic).
!....................................................................
      use real8
      use tetrag1
      use pgroup
      use symgenv
      use working
      use systema
      use buffer
      use buffer0
      implicit none
      integer :: iFix(N0RB),x(3)
      character :: cha2*2
      character :: Which_Code*6,cha1,cha17*17
      character :: cha(3)*2
      integer :: IRA_left(N0IR),Prim_Ext_Cell(N0LT)
      real(8) :: kpoint(Nkpoint,3),C_cond(3,N0LT,6)
      real(8) :: TII(3,N0LT)
      logical :: Yes_masses,Yes_Fixed,Yes_irrep_info,active
      logical :: Yes_ampl,Err,Yes_extention

      integer :: Ndispl=2
      real(8) :: ampl1=0.05
      logical :: Add_Hs=.false.,Show_fixed=.false.
      character*2,dimension(12) :: numb=(/' 1',' 2',' 3',' 4',' 5', &
                               ' 6',' 7',' 8',' 9','10','11','12'/)
      character*4 :: Yes_xyz='Xmol'
      real(8),dimension(2) :: ampl=(/0.01,0.015/)
!
      integer :: is,i,N_Cond,Nm,IA,l0,n_IA,nkp,nat
      integer :: IA_active,j,MG_luc,ITI_prim,k,j1,k1,n,ifx,iV1,iV2,iErr
      real(8) :: s,sn,cs
!
!........... keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
!
!..................................................................
!..................... Main menu starts here ......................
!..................................................................
!
      Yes_irrep_info=.false. ; active=.false. ; Yes_ampl=.false.
      Yes_extention=.false. ; Yes_masses=.true. ; Yes_Fixed=.false.
      do is=1,Nsp
         if(AtMass(is).lt.tiny_equiv) Yes_masses=.false.
      end do
      AI=AJ ; IJ=0.0
      do i=1,3
         IJ(i,i)=1
      end do
      N_Cond=0 ; Nm=2

 21   write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,'(10x,2a/)') &
           '<<SUPERCELL>> ----- CURRENT lattice vectors: ----'
      write(*,'(a,10x,a,10x,a,10x,a)') &
           ' #                SUPERCELL                        '// &
           'PRIMITIVE CELL             EXTENSION'
      write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') &
      '(1) ',(AJ(1,i),i=1,3),' | ',(AI(1,i),i=1,3),' | ',(IJ(1,i),i=1,3)
      write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') &
      '(2) ',(AJ(2,i),i=1,3),' | ',(AI(2,i),i=1,3),' | ',(IJ(2,i),i=1,3)
      write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') &
      '(3) ',(AJ(3,i),i=1,3),' | ',(AI(3,i),i=1,3),' | ',(IJ(3,i),i=1,3)

      write(*,'(a)')
      write(*,*)'========= CHOOSE an OPTION:'
      write(*,'(a)')

      if(.not.Yes_masses) write(*,'(a)') &
            ' Am. Specify atomic masses for every species <- undefined'

      if(.not.Yes_extention) then
         write(*,'(a)') &
         ' /Su. Construct a supercell manually <= undefined'
         write(*,'(a)') &
         ' \Sk. Construct a supercell based on a k-point <= undefined'
      else
         write(*,'(a)') &
         ' /Su. Construct a supercell manually <= Done!'
         write(*,'(a)') &
         ' \Sk. Construct a supercell based on a k-point <= Done!'
      end if

      if(Yes_masses .and. Yes_extention) then
         if(Yes_irrep_info) then
            write(*,'(a)') &
             ' Ir. Collect info about symmetry adapted vectors <- Done'
         else
            write(*,'(a)') &
         ' Ir. Collect info about symmetry adapted vectors <- undefined'
         end if
      end if

!_____ actions with the active irrep

      if(Yes_irrep_info) then
         write(*,'(a)') &
      '------ A c t i o n s  w i t h  A c t i v e  I r r e p ----------'
         do IA=1,MG
            if(active .and. IA.eq.IA_active) then
               cha17='  <=== now active'
            else
               cha17='                 '
            end if
            if(IA.lt.10) then
               write(cha1,'(i1)') IA
               write(*,'(a,i5,a)')' '//cha1//'. Kpoint ;'// &
                       ' # of vectors = ',IRA_left(IA),cha17
            else
               write(cha2,'(i2)') IA
               write(*,'(a,i5,a)')' '//cha2//'. Kpoint ;'// &
                    ' # of vectors = ',IRA_left(IA),cha17
            end if
         end do
      end if

      if(active) then
         if(IRA_left(IA_active).eq.1) then
            iV1=1 ; iV2=1
            Yes_ampl=.true.
            write(*,'(2(a,i3))') &
            '     Pair of vectors to be activated: ',iV1,' and ',iV2
         else
            if(Yes_ampl) then
               write(*,'(2(a,i3))') &
                ' Vn. Pair of vectors to be activated: ',iV1,' and ',iV2
            else
               write(*,'(2(a,i3))') &
                ' Vn. Pair of vectors to be activated: <= undefined'
            end if
         end if
      end if

!_____ automatic

      if(active) then
         write(*,'(a)') &
      '------------------- A u t o m a t i c   o p t i o n ------------'
         write(*,'(a)') &
          ' Au. Generate: input_for.tetr + directories + scripts'
      else if(Yes_irrep_info) then
         write(*,'(a)') &
      '------------------- A u t o m a t i c   o p t i o n ------------'
         write(*,'(a)') &
          ' Au. FULLY AUTOMATIC: input_for.tetr + directories + scripts'
      end if

!_____ show info

      write(*,'(a)') &
      '-------------- G e n e r a l  I n f o r m a t i o n ------------'
      if(Yes_extention) then
         write(*,'(a)') ' Co. Show geometric information about orbits'
         write(*,'(a)') ' Kp. Show all k-points'
      end if

!_____ show settings

      write(*,'(a)') &
      '---------------- G e n e r a l  S e t t i n g s ----------------'
      write(*,*)' UU. ******  RESTORE the original lattice ******'
      if(Yes_masses) then
         write(*,'(a)') &
             ' Am. Atomic masses for every species:'
         write(*,'(5x,6(f10.5,x,3a,2x))') &
              (AtMass(is),'[',Species(is),']',is=1,Nsp)
      end if
      if(Ndispl.lt.4) then
         write(*,'(a,2(f10.5,x))') &
              ' Da. Distortion amplitude: ',ampl(1)
      else
         write(*,'(a,2(f10.5,x))') &
              ' Da. Distortion amplitude: ',ampl(1),ampl(2)
      end if
      write(*,'(a,i1)') &
           ' Nd. Number of displacements (for [Au] only): ',Ndispl
      write(*,'(a,i3)') &
        ' Nm. A parameter for finding the "smallest" extension: ',Nm
      if(active .and. Yes_ampl) write(*,'(a)')'  S. Save geometry file'
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)
      if(cha2.eq.'  ') go to 21

![IA]..... first of all, check if active irrep is chosen

      IF(Yes_irrep_info) THEN

         read(cha2(l0:),'(i2)', err=27) n_IA

!__________________ deactivate the irrep if chosen 2nd time
         if(active.and.n_IA.eq.IA_active) then
            active=.false.
            go to 21
         end if

!___________________ activate the irrep if the 1st time

         do IA=1,MG
            if(n_IA.eq.IA) then
               if(IRA_left(IA).eq.0) then
                  write(*,*)'Error! Try again!' ; go to 21
               end if
               IA_active=IA
               active=.true. ; Yes_ampl=.false.
               go to 21
            end if
         end do

      END IF

![Am]...... specify atomic masses

 27   IF(cha2(l0:).eq.'Am') THEN

         call choose_masses(Species,AtMass,Nsp,Yes_masses)

!______________ reset logical flags since masses changed
         active=.false.
         Yes_irrep_info=.false.
         Yes_ampl=.false.

![Su]...... specify the supercell
![Sk]
      ELSE IF(cha2(l0:).eq.'Su' .or. cha2(l0:).eq.'Sk') THEN

!___________ keep the existing geometry in /buffer/

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ specify extention matrix

         if(cha2(l0:).eq.'Su') then
 34         write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'
 3          write(*,*)' Give elements 11,12,13 of it:'
            read(*,*,err=3) (IJ(1,j),j=1,3)
            write(8,*)  (IJ(1,j),j=1,3)
 4          write(*,*)' Give elements 21,22,23 of it:'
            read(*,*,err=3) (IJ(2,j),j=1,3)
            write(8,*)  (IJ(2,j),j=1,3)
 5          write(*,*)' Give elements 31,32,33 of it:'
            read(*,*,err=3) (IJ(3,j),j=1,3)
            write(8,*)  (IJ(3,j),j=1,3)
            MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) - &
                 IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) + &
                 IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
            write(*,*) 'cell ==> supercell extention = ',MG_luc
            if(abs(MG_luc).lt.tiny_equiv) then
               write(*,*) 'ERROR! Zero extention!' ; go to  34
            end if
         else if(cha2(l0:).eq.'Sk') then
            call integer_kp(Nm,IJ,MG_luc)
            write(*,*) 'cell ==> supercell extention = ',MG_luc
         end if
         ITI_prim=ITI ; ITI=ITI*MG_luc

!_________ build the supercell and keep the primitive cell in AI, BI
         AI=AJ ; BI=BJ
         do k=1,3
            AJ(1,k)=IJ(1,1)*AI(1,k)+IJ(1,2)*AI(2,k)+IJ(1,3)*AI(3,k)
            AJ(2,k)=IJ(2,1)*AI(1,k)+IJ(2,2)*AI(2,k)+IJ(2,3)*AI(3,k)
            AJ(3,k)=IJ(3,1)*AI(1,k)+IJ(3,2)*AI(2,k)+IJ(3,3)*AI(3,k)
         end do
         call INVER(AJ,BJ)

!____________ generate internal translations TRAN(n,xyz)
         call LACE(MG_luc,iErr)
         if(iErr.eq.1) stop 'ERROR in LACE! STOP'
         MG=MG_luc

!____________ generate positions of all atoms in the supercell.
!     Prim_Ext_Cell(j1) - atom number of each primitive cell atom j1
!                         in the list of all atoms of the extended cell
         j=0 ; j1=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN(k)
               j1=j1+1
               Prim_Ext_Cell(j1)=j+1
               do k1=1,MG_luc
                  j=j+1
                  TII(1:3,j)=TRAN(k1,1:3)+TI1(1:3,j1)
                  relax_flag(1:3,j)=relax_flag1(1:3,j1)
               end do
            end do
            NspN(k)=NspN(k)*MG_luc
         end do
!________ get the k-points of the original BZ of the "small" (primitive)
!         system (unit cell) that transform into the Gamma point of the
!         reduced BZ corresponding to the "large" (extended) supercell

         call build_k_points(MG,Err) ; if(Err) return
!
         Yes_extention = .true.
         Yes_irrep_info=.false.
         active=.false.

![Ir]...... collect info about symmetry-adapted vectors
!           IRA_left(IA) - number of linearly independent symmetry-adapted
!                          coordinates

      ELSE IF(cha2(l0:).eq.'Ir'.and.Yes_masses.and.Yes_extention) THEN

         do IA=1,MG
            IRA_left(IA)=ITI_prim*3
         end do
         NEPR=MG
         Yes_irrep_info=.true.

!______________ write all the info for later use (eigenvalues)
         open(23,file='vibr_info.dat',form='formatted')
         write(23,'(2(i5,x),a8)') NEPR,Nsp,system
         write(23,*) MG
         write(23,'(20(a2,x))')  (Species(is),is=1,Nsp)
         write(23,*) (AtMass(is),is=1,Nsp)
         write(23,*)  (IRA_left(i),i=1,NEPR)
         write(23,'(l1)') Yes_Fixed
         write(23,*) ((TRAN(N,j),j=1,3),N=1,MG)
         write(23,*) AI,BI,AJ,BJ,IJ
         write(23,*) ITI,((TII(j,n),j=1,3),n=1,ITI)
         write(23,*) (Prim_Ext_Cell(i),i=1,ITI)
         write(23,*) ITI_prim,((TI1(j,n),j=1,3),n=1,ITI_prim)
         write(23,*) (NspN(i),i=1,Nsp)
         write(23,*) ((Vkp(k,j),j=1,3),k=1,MG)
         write(23,*) (kCmpl(k),k=1,MG)
         close (23)
         write(*,*)'WARNING: general info written to [vibr_info.dat]'

![Vn]...... give an atom and its component to excite

      ELSE IF(cha2(l0:).eq.'Vn' .and. active) THEN

         if(IRA_left(IA_active).gt.1) then
            IA=IA_active
 8          write(*,'(a,i3,a)') &
                 'Specify an atom number from 1 to ',ITI_prim, &
                 ' and its component from 1 to 3'// &
                 ' to distort the system:'
            read(*,*,err=8) iV1,iV2 ; write(8,*) iV1,iV2
            if(iV1.lt.1 .or. iV1.gt.ITI) go to 8
            if(iV2.lt.1 .or. iV2.gt.3) go to 8
            Yes_ampl=.true.
         end if

![Au]...... an input file for tetr will be saved that can generate all geometries
!           of the active irrep automatically

      ELSE IF(cha2(l0:).eq.'Au' .and. Yes_irrep_info) THEN

         call automatic(iFix,N_Cond,Ndispl,Yes_Fixed,ifx,ampl,active, &
                         IRA_left,C_Cond,IA_active,system)
         write(*,'(9(/a))') &
        '.........................................................', &
        '=================> Now, do the following: <==============', &
        '     1. check script run_DFT_script and edit if necessary', &
        '     2. run the script to calculate DFT forces'
         write(*,'(3(a/))') &
        '     3. run option V2 and/or V3 of tetr to '// &
              'get eigenvectors/values', &
        '........................................................' , &
        'press ENTER when ready ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![Da]...... displacement amplitude

      ELSE IF(cha2(l0:).eq.'Da') THEN

 13      if(Ndispl.lt.3) then
            write(*,*)'Specify the amplitude of distortion (in A):'
            read(*,*,err=13) ampl(1) ; write(8,*) ampl(1)
         else
            write(*,*)'Specify 2 amplitudes of distortion (in A):'
            read(*,*,err=13) ampl(1),ampl(2)
            write(8,*) ampl(1),ampl(2)
         end if

![Nd]...... displacements number: for [Au] option only

      ELSE IF(cha2(l0:).eq.'Nd') THEN

         if(Ndispl.eq.1) then
            Ndispl=2
         else  if(Ndispl.eq.2) then
            Ndispl=4
         else
            Ndispl=1
         end if

![Nm]...... the size of sets of integer numbers for each row of the extension
!           matrix U is defined here (the bigger this integer, the more combinations
!           are tried)

      ELSE IF(cha2(l0:).eq.'Nm') THEN

 14      write(*,*)'To determine the sampling of 3x3 integer matrices'
         write(*,*)'needed to find the "smallest" supercell which'
         write(*,*)'reproduces the required k point,'
         write(*,*)'enter a positive integer starting from 1:'
         read(*,*,err=14) Nm ; write(8,*) Nm
         if(Nm.lt.1) Nm=-Nm
         if(Nm.eq.0) go to 14

![Co].....show information about updated positions

      ELSE IF(cha2(l0:).eq.'Co'.and.Yes_extention) THEN

         write(*,'(a)') "============================================"// &
              "============================"
         write(*,'(a,i3)') "  Number of Atoms in Extended Cell: ", ITI
         write(*,'(a)') "--------------------------------------------"// &
              "----------------------------"
         write(*,'(a)') "  Number  |   Orbit   | Species  |          "// &
              "    Position      "
         write(*,'(a)') "--------------------------------------------"// &
              "----------------------------"
         i=0
         do is=1,Nsp
            do nat=1,NspN(is)
               i=i+1
               j=i/MG ; if(j*MG.ne.i) j=j+1
               write(*,'(3x,i2,10x,i2,8x,a2,8x,3(f12.7,2x))') &
                                       i,j,Species(is),(TII(k,i),k=1,3)
            end do
         end do

![Kp].... show the symmetry and check the condition for the k-points
!         (ok-check)

      ELSE IF(cha2(l0:).eq.'Kp' .and. Yes_extention) THEN

         write(*,'(a/)') &
              '... k-points of the original BZ for this extention ...'
         write(*,'(a)') ' # type|      in Cartesian (no 2*pi)     '// &
           '  | ok-check  |           in fractional ', &
           '------------------------------------------------------'// &
           '-------------------------------------'
         do k=1,MG
            do j=1,3
               s=Vkp(k,1)*AJ(j,1)+Vkp(k,2)*AJ(j,2)+Vkp(k,3)*AJ(j,3)
               cs=cos(2*pi*s) ; sn=sin(2*pi*s)
               if(abs(cs-1.0).lt.tiny_equiv .and. &
                                        abs(sn).lt.tiny_equiv) then
                  cha(j)='ok'
               else
                  cha(j)='no'
               end if
            end do
            x(1)=AI(1,1)*Vkp(k,1)+AI(1,2)*Vkp(k,2)+AI(1,3)*Vkp(k,3)
            x(2)=AI(2,1)*Vkp(k,1)+AI(2,2)*Vkp(k,2)+AI(2,3)*Vkp(k,3)
            x(3)=AI(3,1)*Vkp(k,1)+AI(3,2)*Vkp(k,2)+AI(3,3)*Vkp(k,3)

            write(*,'(i3,x,i2,a,3(f10.5,x),a,3(a,x),a,3(x,f10.5))') &
              k,kCmpl(k),' | ',(Vkp(k,j),j=1,3),' | ',cha,' | ',x
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)  ; write(8,'(a)') 'PressEnter'

![S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S' .and. active .and. Yes_ampl) THEN

         call get_new_TI_kp(iV1,iV2,ampl(1),IA_active,MG,TII)
         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.true.)

![UU].... restore the original lattice

      ELSE IF(cha2(l0:).eq.'UU') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         Yes_extention = .false.
         Yes_irrep_info=.false.
         active=.false.
         Yes_Fixed=.false.

![Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine kpoint_vibr

      subroutine get_new_TI_kp(iAt,ixyz,ampl,Nkp,MG,TII)
!..............................................................................
!     New atomic positions corresponding to the excitation of one displcement
! vector iAt,ixyz (with amplitude ampl) are calculated and then dumped into a unit.
!   Here iAt corespond to atom number and ixyz to x,y,z.
!   TII - positions of atoms in the undistorted supercell
!..............................................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: TII(3,N0LT)
!
      integer :: iAt,ixyz,Nkp,itr,k,is,nat,iN,MG
      real(8) :: ampl,s

!..... iN - counts atoms inside the primitive cell
!     nat - counts atoms inside the extended cell
!     itr - counts internal translations TRAN

      TI=TII
      iN=0 ; nat=0
      do k=1,Nsp
         do is=1,NspN(Nsp)/MG
            iN=iN+1
            do itr=1,MG
               nat=nat+1
               if(iN.eq.iAt) then
                  s=2*pi*(Vkp(Nkp,1)*TRAN(itr,1)+Vkp(Nkp,2)*TRAN(itr,2)+ &
                                               Vkp(Nkp,3)*TRAN(itr,3) )
                  if(kCmpl(Nkp).eq.0) then
                     TI(ixyz,nat)=TII(ixyz,nat)+ampl*cos(s)/sqrt(MG*1.)
                  else if(kCmpl(Nkp).eq.1) then
                     TI(ixyz,nat)=TII(ixyz,nat)+ampl*cos(s)/sqrt(MG/2.)
                  else if(kCmpl(Nkp).eq.-1) then
                     TI(ixyz,nat)=TII(ixyz,nat)+ampl*sin(s)/sqrt(MG/2.)
                  end if
              end if
            end do
         end do
      end do

      end subroutine get_new_TI_kp

      subroutine show_norm_dspl_Vk(IA,Ndim,Freq,nsp,NspN,Species, &
           unit)
!.............................................................
! nice print of the normal modes for irrep IA:
! IA     - given irrep
! IRA    - total number of normal modes for this irrep IA
!.............................................................
      use real8
      use matrix
      use space
      use vk_vibr
      implicit none
      real(8) :: RA(3),Freq(Ndim)
      integer :: rep,unit,NALF,index(N0LT,3),NspN(N0KD)
      character :: Species(N0KD)*2
      character,dimension(3),parameter :: a=(/'x','y','z'/)
!
      integer :: IA,Ndim,Nsp,nat,is,n,iR,irep,nn,l,ir1,ir2,i,ibound
      real(8) :: s,c
!
!.......... set boundaries of the table depending on the irrep dimension
!
      NALF=1 ; ibound=10
      nat=0 ; iR=0
      do is=1,Nsp
         do n=1,NspN(is)/MG_luc
            nat=nat+1
            do i=1,3
               iR=iR+1
               index(nat,i)=iR
            end do
         end do
      end do
!
!........... write on the screen/file
!
      write(unit,'(a/)') &
           '****************** normal displacements **************'

      do irep=1,Ndim,ibound
         ir1=irep
         ir2=ir1+ibound-1 ; if(ir2.gt.Ndim) ir2=Ndim

         write(unit,'(24x,a)') '   <-------(number,row)------->'
         write(unit,'(a,20(x,f10.5))') '  Frequency  (in cm^-1) ', &
                 (Freq(rep),rep=ir1,ir2)
         write(unit,'(a,5x,a,3x,20(3x,a,i2,a,4x))') &
           'at# Sp cell',' x/y/z', ('(',rep,')',rep=ir1,ir2)

         nat=0 ; nn=0
         do is=1,Nsp
            do n=1,NspN(is)/MG_luc
               nat=nat+1

               do l=1,MG_luc
                  nn=nn+1
                  RA(1:3)=TRAN(l,1:3)+TI1(1:3,nat)

                  s=2*pi*(Vkp(IA,1)*TRAN(l,1)+Vkp(IA,2)*TRAN(l,2) + &
                       Vkp(IA,3)*TRAN(l,3))

                  if(kCmpl(IA).eq.0) then
                     c=cos(s)/sqrt(MG_luc*1.0d00)
                  else
                     c=cos(s)/sqrt(MG_luc/2.0d00)
                     s=sin(s)/sqrt(MG_luc/2.0d00)
                  end if

                  do i=1,3
                     iR=index(nat,i)
                     if(kCmpl(IA).eq.0) then
                        write(unit,'(i3,x,a,x,i3,x,a,21(x,f10.5))') &
                             nn,Species(is),nat,a(i),RA(i), &
                             (EigV(iR,rep)*c,rep=ir1,ir2)
                     else
                   write(unit,'(2(i3,x,a,x),f10.5,20(x,f10.5,4x,a,5x))') &
                             nn,Species(is),nat,a(i),RA(i), &
                   (EigV(iR,rep)*c+EigV(iR,rep+1)*s,'--', rep=ir1,ir2,2)
                     end if
                  end do

               end do
            end do
         end do

         write(unit,*) &
                 '---------------------------------------------------'
         if(ir2.eq.Ndim) return
         if(unit.eq.6) then
            write(*,'(a)')'... Hit ENTER to continue ...'
            read(*,*)  ; write(8,'(a)') 'PressEnter'
         end if

      end do
      end subroutine show_norm_dspl_Vk

      subroutine distorted_xyz_Vk(IA,IRA,rep,ampl,Species,Nsp,NspN,ITI, &
                                                   unit,Add_Hs)
!..............................................................................
!     New atomic positions corresponding to the excitation of one diaplcement
! vector iV,j (with amplitude ampl) are calculated and then dumped into a unit.
!   Here iV corespond to the vector number for row=1. If row index j
! is different from 1 (for 2D and 3D irreps), then the vector corresponding to
! the rowj is used.
!..............................................................................
      use real8
      use matrix
      use space
      use vk_vibr
      implicit none
      real(8) :: x(3)
      integer :: unit,NspN(N0KD),rep
      character :: Species(N0KD)*2
      logical :: Add_Hs
!
      integer :: IA,IRA,nnn,is,n,iR,Nsp,ITI,l,j,nat,nn
      real(8) :: ampl,s,c

!................. write number of atoms
      nnn=ITI
      if(Add_Hs) nnn=nnn+3
      write(unit,'(i5/)') nnn

      nat=0 ; nn=0 ; iR=0
      do is=1,Nsp
         do n=1,NspN(is)/MG_luc
            nat=nat+1
            iR=iR+1

            do l=1,MG_luc
               nn=nn+1

               s=2*pi*(Vkp(IA,1)*TRAN(l,1)+Vkp(IA,2)*TRAN(l,2) + &
                    Vkp(IA,3)*TRAN(l,3))
               if(kCmpl(IA).eq.0) then
                  c=cos(s)/sqrt(MG_luc*1.0d00)
                  x(1)=TRAN(l,1)+TI1(1,nat) + ampl*EigV(iR,rep)*c
                  x(2)=TRAN(l,2)+TI1(2,nat) + ampl*EigV(iR+1,rep)*c
                  x(3)=TRAN(l,3)+TI1(3,nat) + ampl*EigV(iR+2,rep)*c
               else
                  c=cos(s)/sqrt(MG_luc/2.0d00)
                  s=sin(s)/sqrt(MG_luc/2.0d00)
                  x(1)=TRAN(l,1)+TI1(1,nat) + &
                       ampl*(EigV(iR,rep)*c+EigV(iR,rep+1)*s)
                  x(2)=TRAN(l,2)+TI1(2,nat) + &
                       ampl*(EigV(iR+1,rep)*c+EigV(iR+1,rep+1)*s)
                  x(3)=TRAN(l,3)+TI1(3,nat) + &
                       ampl*(EigV(iR+2,rep)*c+EigV(iR+2,rep+1)*s)
               end if
               write(unit,'(a2,5x,3(f16.10,1x),a)') &
                    Species(is),(x(j),j=1,3)
!     &              Species(is),(x(j),j=1,3),' 0 0 0'

            end do
            iR=iR+2
         end do
      end do

      if(Add_Hs) then
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      end if
      return
      end subroutine distorted_xyz_Vk

      subroutine integer_kp(Nm,U,det_min)
      implicit none
!.............................................................................
!     finds the smalles extended cell (extnension matrix U) which would reproduce
!     the given k-point (in components via the reciprical lattice vector of the
!     primitve cell):
!                            [ m(1)/n , m(2)/n , m(3)/n ]
!.............................................................................
!     implicit none
      integer :: U(3,3),n,m(3),determ,Nm,im,det,det_min,j
      integer :: i1,i2,i3,i1_min,i2_min,i3_min
      integer,dimension(:,:),allocatable :: set1
      real(8) :: a1,a2,a3

!.......... enter the k point of interest
 1    write(*,*)'|===================================================|'
      write(*,*)'|K-vector is given by 3 expansion coefficients wrt  |'
      write(*,*)'| reciprocal lattice vectors of the primitive cell. |'
      write(*,*)'|===================================================|'
      write(*,*)'Enter the required vector K as three fractions:'
      write(*,*)'     m(1)/n , m(2)/n , m(3)/n '
      write(*,*)'Enter first 3 integer numerators m(i):'
      read(*,*,err=1) m(1),m(2),m(3)  ; write(8,*) m(1),m(2),m(3)
 2    write(*,*)'Enter the common denominator n:'
      read(*,*,err=2) n  ; write(8,*) n

!.......... determine the dimension of set()
      call sets_info(Nm,im)
      write(*,'(2(a,i5))') 'Nm = ',Nm,' corresponds to im = ',im
      allocate(set1(im,3))

!..........set up a set for the 3 rows of the transformation matrix
!          from the small to large direct lattice vectors
      call sets(set1,im,Nm)

!.......... select the appropriate ones

      det_min=100000
      do i1=1,im
         do i2=1,im
            do i3=1,im
               if(i1.eq.i2 .or. i1.eq.i3 .or. i2.eq.i3) go to 10
               U(1,1:3)=set1(i1,1:3)
               U(2,1:3)=set1(i2,1:3)
               U(3,1:3)=set1(i3,1:3)
               a1=1.0*(m(1)*U(1,1)+m(2)*U(1,2)+m(3)*U(1,3))/n
               a2=1.0*(m(1)*U(2,1)+m(2)*U(2,2)+m(3)*U(2,3))/n
               a3=1.0*(m(1)*U(3,1)+m(2)*U(3,2)+m(3)*U(3,3))/n

               if(int(a1).eq.a1 .and. &
                    int(a2).eq.a2 .and. int(a3).eq.a3) then
                  det=determ(U)
                  if(det.lt.det_min .and. det.ne.0) then
                     i1_min=i1 ; i2_min=i2 ; i3_min=i3 ; det_min=det
                  end if
               end if
 10         end do
         end do
      end do
      U(1,1:3)=set1(i1_min,1:3)
      U(2,1:3)=set1(i2_min,1:3)
      U(3,1:3)=set1(i3_min,1:3)
      write(*,*) '... found the best extension matrix:'
      write(*,'(a,3(x,i5))') '(1,1)-(1,3) =>',(U(1,j),j=1,3)
      write(*,'(a,3(x,i5))') '(2,1)-(2,3) =>',(U(2,j),j=1,3)
      write(*,'(a,3(x,i5))') '(3,1)-(3,3) =>',(U(3,j),j=1,3)
      write(*,'(a,i5)')'with extension = ',det_min

      deallocate(set1)
      end subroutine integer_kp

      subroutine sets_info(Nm,i)
      implicit none
!     implicit none
      integer N,Nm,N1,N2,N3,i
      N=0 ; i=0
 30   N=N+1
      if(N.gt.Nm) return
      do N3=-N,N
         do  N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
               i=i+1
!               write(*,*)i,' => ',N1,N2,N3
 250        end do
         end do
      end do
      go to 30
      end subroutine sets_info

      subroutine sets(set,im,Nm)
      implicit none
!     implicit none
      integer set(im,3),N,Nm,N1,N2,N3,i,im
      N=0 ; i=0
 30   N=N+1
      if(N.gt.Nm) return
      do N3=-N,N
         do  N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
               i=i+1
               set(i,1)=N1 ; set(i,2)=N2 ; set(i,3)=N3
 250        end do
         end do
      end do
      go to 30
      end subroutine sets

      integer function determ(U)
      implicit none
!     implicit none
      integer U(3,3)
      determ= U(1,1)*(U(2,2)*U(3,3)-U(2,3)*U(3,2)) &
          -U(2,1)*(U(1,2)*U(3,3)-U(1,3)*U(3,2)) &
           +U(3,1)*(U(1,2)*U(2,3)-U(1,3)*U(2,2))
      determ=abs(determ)
      end function determ




