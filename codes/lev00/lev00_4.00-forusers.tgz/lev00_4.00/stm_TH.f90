subroutine stm_TH(grid)
!....................................................................
!   A box is chosen inside the cell and the density in the box is
! written into a file in the cube gOpenMol format.
!....................................................................
use param
use atoms
use menu
implicit none
real*8,parameter :: tiny=0.0001
real*8 GRID(NGX,NGY,NGZ)
real*8,dimension(3) :: Center=(/0.0,0.0,0.0/),Face=(/1.0,1.0,1.0/)
integer,dimension(3) :: ngrid=(/20,20,20/)
real*8 Direct(3,3),da(3),vect(3,3),Bot,Top,corner(3),LDOS,Zmin,Zmax,Zdw,Zup,a,b
integer nChrg,j,i,ix,iy,iz,i1,i2,i3,nat,j1,Nltrp
logical Yes_Do,Yes_Z,Yes_Curr,Yes_XY,Yes_Spctr,Yes_Empty_lines,Yes_exp
character cha2*2,Title*50,title_pl(8)*7,cha1
character Line*200
integer LinEnd(100),LinPos(100),NumLin,iErr,idw,iup
integer M1,M2,M3,N1,N2,N3,L_ext
real*8,allocatable,dimension(:) :: dos,zz
data Title/'                                                  '/
real*8,allocatable,dimension(:,:) :: Jmin,Jmax
real*8,allocatable,dimension(:,:) :: LatPos
real*8,allocatable,dimension(:)   :: Zldos
real*8 Imin,Imax,z,x(3),denval,z1,z2,zz1,R(3),R1(3),R2(3),spctr(8),Imin1
!
!................. setting for the box orientation (fixed here)
     Direct=0.0 ; Direct(1,1)=1.0 ; Direct(2,2)=1.0 ; Direct(3,3)=1.0
!................. initial setting for the Z-window for atoms to be shown in [Sh]
     Zmax=0.0 ; Zmin=-2.0 
!................. initialisation for spectrosopy
     Nltrp=1 ; allocate(LatPos(3,Nltrp))
!................. initialisation of the breeding box
     M1=0 ; M2=0 ; M3=0 ; N1=0 ; N2=0 ; N3=0
!................. start the main menu
!
      Yes_Do=.false. ; Yes_Z=.false. ; Yes_Curr=.false. ; Yes_XY=.false. 
      Yes_Spctr=.false. ; Yes_Empty_lines=.true. ; Yes_exp=.false.
1     write(*,*) 
      write(*,*)'............MENU for STM/TH ...........................'
      write(*,*)'***[ Surface MUST be perpendicular to the Z axis ! ]***'
      write(*,*)'......... Change these parameters if necessary:........'
      write(*,*)

      write(*,'(a)') '---------- T H - S T M   i m a g e  -------------'
      write(*,'(a,2(f10.5,a))') '   1. Surface area center is at: (', &
                Center(1),',',Center(2),')'

      write(*,'(a)')'      Directions of the surface area are fixed along:'
      write(*,'(10x,a,3(f10.5,a))') &
          '1   <',Direct(1,1),',',Direct(1,2),',',Direct(1,3),'  >'
      write(*,'(10x,a,3(f10.5,a))') &
          '2   <',Direct(2,1),',',Direct(2,2),',',Direct(2,3),'  >'
      write(*,'(a,2(1x,f10.5))') &
          '   2. Lengths of the surface area (in A) are: ',Face(1),Face(2)
      corner(1:2)=Center(1:2)-0.5*Face(1:2)

      if(Yes_Z) then
         Face(3)=Top-Bot ; corner(3)=Bot 
         write(*,'(5x,a,3(1x,f10.5))') &
              '>>>> the starting point (corner) of the box is at ', &
              (corner(i),i=1,3)
         if(Yes_Curr) then
            write(*,'(a,f10.5)') '   I. Value of LDOS within the window = ',LDOS
         else
            write(*,'(a)') '   I. Value of LDOS within the window = UNDERFINED'
         end if
      end if
      
      if(Yes_exp) then
         write(*,'(a)') '  Ex. Exponential fit for large Z values - IS set'
      else
         write(*,'(a)') '  Ex. Exponential fit for large Z values - NOT set'
      end if

      write(*,'(a,3(1x,i3))') &
      '   4. The grid  in the box in 3 directions: ',(ngrid(i),i=1,3)
      nChrg=ngrid(1)*ngrid(2)*ngrid(3)
      write(*,'(5x,a,i10)')'>>>> total number of grid points = ',nChrg
      if(Yes_Z) then
         do i=1,3
            da(i)=Face(i)/ngrid(i) ; vect(i,1:3)=Direct(i,1:3)*da(i)
         end do
         write(*,'(5x,a,3(x,f10.5))')'>>>> steps along 3 directions are ', &
              (da(i),i=1,3)
         if(Yes_Curr) then
            if(.not.Yes_Do) then
               write(*,'(a)') '  Ci. Calculate IMAGE of constant LDOS topography'
            else
               write(*,'(a)') '  Ci. Calculate constant LDOS topography - DONE!'
               write(*,'(a)') '  Vi. PREVIEW the LDOS' 
               write(*,'(a)') '  Ps. Create the Postscript of the LDOS' 
            end if
         end if
      end if
      write(*,'(a)') '  Sh. SHOW (X,Y)-coordinates of surface atoms within the PLOT'
      write(*,'(a)') '------------ S p e c t r o s c o p y ------------'
      write(*,'(a,i3)') '  Np. Number of points along Z axis = ',ngrid(3)
      write(*,'(a,i3)') '  Nl. Number of lateral points for 1D spectoscopy plots = ',Nltrp
      if(Yes_XY) then
         write(*,'(a)') '  XY. Lateral points - KNOWN'
         write(*,'(a)') '  Sl. Show Lateral points'
         if(Yes_Z) then
            if(Yes_Spctr) then
               write(*,'(a)') '  Cs. Calculate spectroscopy curves - DONE!'
               write(*,'(a)') '  Vs. PREVIEW all spectroscopy curves' 
            else
               write(*,'(a)') '  Cs. Calculate spectroscopy curves'
            end if
         end if
      else
         write(*,'(a,i3)') '  XY. Specify lateral points - yet UNDEFINED'
      end if
      
      if(CHIMERA) then
         write(*,*)    '---------- v i s u a l i a s i o n   s e t t i n g s ---------'
         L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
         write(*,'(a,3(i2,a,i2,a),i3,a,i5)') &
          '>>> Box: [',M1,'...',N1,'] x [', M2,'...',N2,'] x [', &
                M3,'...',N3,'], ext = ',L_ext,', # of atoms= ',NIONS*L_ext
         write(*,*)    '  Bb. Breeding box size'
         write(*,*)    '  B0. Nullify the breeding box'
      end if

      write(*,'(a)') '-------  G e n e r a l  s e t t i n g s ---------'
      if(Yes_Z) then
         write(*,'(2(a,f10.5))') &
              '  BT. Bottom and top of the box (along Z, in A) are: ',Bot,',',Top
         write(*,'(5x,2(a,e12.6),a)') '>>>> LDOS window found = [ ',Imin,',',Imax,' ]'
      else
         write(*,'(a)') &
              '  BT. Bottom and top of the box (along Z, in A) are UNDERFINED'
      end if
      
      write(*,'(a)') '  An. Coordinates are specified in: '//angstr
      write(*,'(a)') '  Co. Show current atomic positions in fractional/Cartesian'
      write(*,'(2(a,f10.5),a)') &
           '  zW. Z-window to SHOW (X,Y)-positions of atoms: [ ',Zmin,',',Zmax,' ]'
      if(Yes_Empty_lines) then
         write(*,'(a)')'  El. Add empty lines in the constant LDOS file <--- YES'
      else
         write(*,'(a)')'  El. Add empty lines in the constant LDOS file <--- NO'
      end if
      if(type_prv.eq.'2d-old-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 2D + contours'
         write(*,*) ' cl. PREVIEW/Ps: number of contour levels = ',nclasses
      else if(type_prv.eq.'2d-col-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 2D + colours'
      else if(type_prv.eq.'2d-gray') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 2D + gray palette'
      else if(type_prv.eq.'3d-old-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D + grid lines'
      else if(type_prv.eq.'3d-c-2d') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D + 2D underneath; in colour'
      else if(type_prv.eq.'3d-g-2d') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D + 2D underneath; in gray'
      else if(type_prv.eq.'3d-col-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D; in colour'
      else if(type_prv.eq.'3d-col-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D; in colour'
     end if

      write(*,'(a)') '------------ C a l c u l a t o r ----------------'
      write(*,'(a)') '  cT. Centre of a triangle of points/atoms'
      write(*,'(a)') '  mD. Middle distance between two points/atoms'
      write(*,'(a)') '------- L e a v e   t h e   m e n u -------------'
      write(*,'(a)')'   Q. Return to the previous menu'
      write(*,*)
      write(*,*)'------> Choose the item and press ENTER:'
      read (*,'(a)',err=1) cha2
!
![1]__________ give the central point
!
      IF(trim(cha2).eq.'1') THEN
         write(*,*)'Give the center of your surface area :'
         write(*,*)'*** Z coordinate will be ignored ***'
         call givepoint(Center(1),Center(2),Center(3),angstr)
         Yes_Do=.false.
!
![2]__________ choose lengths of the area sides
!
      ELSE IF(trim(cha2).eq.'2') THEN
 12      WRITE(*,'(a)')'Give lengths of the surface area (in A)'
         read(*,*,err=12) (Face(j),j=1,2)
         Face(1)=abs(Face(1)) ; if(Face(1).lt.tiny) go to 12
         Face(2)=abs(Face(2)) ; if(Face(2).lt.tiny) go to 12
         Yes_Do=.false.
!
![BT]__________ choose bottom and top of the box (along Z)
!
      ELSE IF(trim(cha2).eq.'BT') THEN
 14      WRITE(*,'(a)')'Give BOTTOM and TOP of the surface area (in A)'
         read(*,*,err=14) Bot,Top
         if(Top-Bot .lt. tiny) go to 14
!
!___________________ analyse the LDOS: find the window of currents for the
!                    heights between Bot and Top
         write(*,*)'... Analysing the LDOS ...'
         allocate (Jmin(NGX,NGY)) ; allocate (Jmax(NGX,NGY))
         do ix=1,NGX
            do iy=1,NGY
               Imin=1.e10 ; Imax=-1.e10
               do iz=1,NGZ
                  z = (ix-1)*DIRC(1,3)/NGX + (iy-1)*DIRC(2,3)/NGY + (iz-1)*DIRC(3,3)/NGZ
                  if(z.ge.Bot .and. z.le.Top) then
                     if(grid(ix,iy,iz) .gt. Imax) Imax=grid(ix,iy,iz)
                     if(grid(ix,iy,iz) .lt. Imin) Imin=grid(ix,iy,iz)
                  endif
               end do
               Jmin(ix,iy)=Imin ; Jmax(ix,iy)=Imax
            end do
         end do
!_______________________ find the lagest minimum value Imin and the smallest maximum
!                        value Imax across all lateral grid points
         Imax= 1.e10 ; Imin=-1.e10
         do ix=1,NGX
            do iy=1,NGY
               if(Jmin(ix,iy) .ge. Imin) Imin=Jmin(ix,iy)
               if(Jmax(ix,iy) .lt. Imax) Imax=Jmax(ix,iy)
            end do
         end do
         deallocate (Jmin) ; deallocate (Jmax)
         write(*,'(2(a,f10.5),a)') '... LDOS window found = [ ',Imin,',',Imax,' ]'
         if(Imin.gt.Imax) then
            write(*,'(a)')'ERROR! The LDOS window cannot be established '
            write(*,'(2(a,f10.5))') '      as ',Imin,' was found to be > than ',Imax
            write(*,'(a)')'       Either specify different BOTTOM and/or TOP values'
            write(*,'(a)')'       or rerun your cell with larger vacuum gap.'
            write(*,*)'Hit ENTER when done ...' ; read(*,*)
         else
            Yes_Z=.true. ; Yes_Do=.false. ; Yes_Spctr=.false. ; Yes_Curr=.false.
         end if
!
![4]__________ choose the grid in the box
!
      ELSE IF(trim(cha2).eq.'4') THEN
 13      write(*,'(a)') 'Specify the number of grid points in all 3 directions:'
         read(*,*,err=13) (ngrid(i),i=1,3)
         do i=1,3
           if(ngrid(i).lt.1) go to 13
         end do
         Yes_Do=.false. ; Yes_exp=.false.
!
![I]__________ choose LDOS value within the window
!
      ELSE IF(trim(cha2).eq.'I' .and. Yes_Z) THEN

         Imin1=Imin 
         if(Yes_exp) Imin1=0.0
         write(*,*) Imin,Imin1,Imax,Yes_exp

21       write(*,'(2(a,f10.5),a)')'Specify the LDOS value within [ ',Imin1,',',Imax,' ]'
         read(*,*,err=21) LDOS
         if(LDOS.lt.Imin1 .or. LDOS.gt.Imax) then
            write(*,*)'ERROR! The current should be within the range!'
            write(*,*)'Hit ENTER when done ...' ; read(*,*)
            Yes_Curr=.false.
         else
            Yes_Curr=.true. ; Yes_Do=.false.
         end if
!
![Ex]__________ work out an exponential fit
!
      ELSE IF(trim(cha2).eq.'Ex') THEN
         if(Yes_exp) then
            Yes_exp=.false. ; go to 1
         end if
         allocate(Zldos(ngrid(3))) ; allocate(zz(ngrid(3))) 
         write(*,'(a)') 'Opening the file for the constant LDOS ....'
         open(31,file='ldos.dat',form='formatted',status='unknown')
         do i1=0,ngrid(1)-1
            do i2=0,ngrid(2)-1
               do i3=0,ngrid(3)-1
!_________________________ Cartesian position of the grid point in the box
                  x(1)= i1*vect(1,1)+i2*vect(2,1)+i3*vect(3,1)+corner(1)
                  x(2)= i1*vect(1,2)+i2*vect(2,2)+i3*vect(3,2)+corner(2)
                  x(3)= i1*vect(1,3)+i2*vect(2,3)+i3*vect(3,3)+corner(3)
!_________________________ interpolate the density at x()
                  call reducn(x,DIRC,BCELL)
                  call interpolate(x,BCELL,denval,grid)
                  Zldos(i3+1)=denval ; zz(i3+1)=x(3)
               end do
!__________________________ try the exponential fit
               call critical_points(Zldos,zz,ngrid(3),Zdw,Zup,idw,iup,a,b)
 !              write(*,'(2(a,i5),4(a,f10.5),a)')&
 !        '(i1,i2)=(',i1,',',i2,'), [Zdw,Zup] = [',Zdw,',',Zup,'], fit=',a,'*exp(-',b,'*z)' 
               if(a.le.0.0 .or. b.le.0.0) then
                  write(*,*)'WARNING! Exponential fit fails for the grid points:'
                  write(*,*)'         (i1,i2)=(',i1,',',i2,') => exiting'
                  write(*,*)'Hit ENTER when done ...'
                  read(*,*)
                  Yes_exp=.false. ; go to 15
               end if
            end do
         end do
         Yes_exp=.true. 
15       deallocate(Zldos) ; deallocate(zz) ; close(31)
         go to 1
!
![Ci]__________ calculate the current topography
!
      ELSE IF(trim(cha2).eq.'Ci' .and. Yes_Z .and. Yes_Curr) THEN

         allocate(Zldos(ngrid(3))) ; allocate(zz(ngrid(3))) 
         write(*,'(a)') 'Opening the file for the constant LDOS ....'
         open(31,file='ldos.dat',form='formatted',status='unknown')
         do i1=0,ngrid(1)-1
            do i2=0,ngrid(2)-1

               do i3=0,ngrid(3)-1
!_________________________ Cartesian position of the grid point in the box
                  x(1)= i1*vect(1,1)+i2*vect(2,1)+i3*vect(3,1)+corner(1)
                  x(2)= i1*vect(1,2)+i2*vect(2,2)+i3*vect(3,2)+corner(2)
                  x(3)= i1*vect(1,3)+i2*vect(2,3)+i3*vect(3,3)+corner(3)
!_________________________ interpolate the density at x()
                  call reducn(x,DIRC,BCELL)
                  call interpolate(x,BCELL,denval,grid)
                  Zldos(i3+1)=denval ; zz(i3+1)=x(3)
               end do

!_________________________ determine the height corresponding to the given value LDOS

               x(1)= i1*vect(1,1)+i2*vect(2,1)+corner(1)-Center(1)
               x(2)= i1*vect(1,2)+i2*vect(2,2)+corner(2)-Center(2)
               if(LDOS.gt.Imin) then
                  do i3=1,ngrid(3)-1
                     if( (LDOS.ge.Zldos(i3) .and. LDOS.lt.Zldos(i3+1)) .or. &
                          (LDOS.ge.Zldos(i3+1) .and. LDOS.lt.Zldos(i3)) ) then
                        z1=i1*vect(1,3)+i2*vect(2,3)+i3*vect(3,3)+corner(3)
                        z2=i1*vect(1,3)+i2*vect(2,3)+(i3+1)*vect(3,3)+corner(3)
                        zz1=z1+(LDOS-Zldos(i3))*(z2-z1)/(Zldos(i3+1)-Zldos(i3))
                        exit
                     end if
                  end do
               else 
!__________________________ do the exponential fit
                  call critical_points(Zldos,zz,ngrid(3),Zdw,Zup,idw,iup,a,b)
                  zz1=-log(LDOS/a)/b
               end if
               write(31,'(3(e13.5,x))') x(1),x(2),zz1 
            end do
            if(Yes_Empty_lines) write(31,*)
         end do
         close (31)
         write(*,*)'Done! The file <ldos.dat> created!'
         deallocate(Zldos) ; deallocate(zz)
         Yes_Do=.true.
!
![Vi]__________ preview LDOS image
!
      ELSE IF(trim(cha2).eq.'Vi' .and. Yes_Do) THEN
         call Plot3d('ldos.dat',8,Title, &
              'X-coordinate (A)    ','Y-coordinate (A)    ', &
              'Z-coordinate        ','Screen', 33,nclasses,type_prv)
!
![Ps]__________ create a Postscript file for the LDOS
!
      ELSE IF(trim(cha2).eq.'Ps' .and. Yes_Do) THEN
         call Plot3d('ldos.dat',8,Title, &
              'X-coordinate (A)    ','Y-coordinate (A)    ', &
              'Z-coordinate        ','Postsc', 33,nclasses,type_prv)
         write(*,*)'... Postscript file <ldos.dat.ps> has been created' 
!
![Sh]__________ show atomic positions via their X,Y coordinates on the PLOT [V];
!               only atoms within the specified Z-window [Zmin,Zmax] are given 
!
      ELSE IF(trim(cha2).eq.'Sh') THEN
         write(*,'(a)')'*****************************************************'
         write(*,'(a)')'*** Only atoms within the Z-window are shown.     ***'
         write(*,'(a)')'*** Only atoms within the surface area are shown. ***'
         write(*,'(2(a,f10.5),a)') &
                       '*** Z-window = [',Zmin,',',Zmax,']            ***'
         write(*,*)    '*****************************************************'
         nat=0
         do i=1,NSPEC
            write(*,'(3a,i5)')'.... Species <',Species(i),'> ......> ',i
            write(*,'(a)')' Tot   Sp#      |-X-in-PLOT-| |-Y-in-PLOT-| [--actual-Z-]'
            do j=1,NspN(i)
               nat=nat+1
               if(TI(3,nat).ge.Zmin .and. TI(3,nat).le.Zmax) then
                  x(1:2)=TI(1:2,nat)-Center(1:2)
                  if(abs(x(1)).le.0.5*Face(1) .and. abs(x(2)).le.0.5*Face(2)) then 
                     write(*,'(2(x,i5),2(4x,f10.5),2x,a,f10.5,a)') &
                          nat,j,(x(j1),j1=1,2),'  [',TI(3,nat),' ]'
                  end if
               end if
            end do 
         end do
         write(*,*)'Hit ENTER when done ...' ; read(*,*)
!
![Np]__________ number of points along Z for spectroscopy
!
      ELSE IF(trim(cha2).eq.'Np') THEN
68       write(*,*)'Specify number of points for 1D plots:'
         read(*,*,err=68) ngrid(3)
         if(ngrid(3).lt.2) go to 68
         Yes_Spctr=.false.
!
![Nl]__________ number of lateral points for spectroscopy
!
      ELSE IF(trim(cha2).eq.'Nl') THEN
         deallocate(LatPos)
69       write(*,*)'Specify number of lateral points for 1D plots (<10):'
         read(*,*,err=69) Nltrp
         if(Nltrp.lt.1 .or. Nltrp.gt.8) go to 69
         allocate(LatPos(3,Nltrp)) 
         Yes_Spctr=.false. ; Yes_XY=.false.
!
![XY]__________ specify lateral points for spectroscopy
!
      ELSE IF(trim(cha2).eq.'XY') THEN
         do i=1,Nltrp
            write(*,'(a,i2,a)') &
                 'Specify X,Y,Z of the lateral point [',i,'] (only X,Y are kept)'
            call givepoint(LatPos(1,i),LatPos(2,i),LatPos(3,i),angstr)
            write(cha1,'(i1)') i
            title_pl(i)='point '//cha1
         end do
         Yes_XY=.true. ;  Yes_Spctr=.false.

!
![Sl]__________ show the lateral points for spectroscopy
!
      ELSE IF(trim(cha2).eq.'Sl' .and. Yes_XY) THEN
         write(*,'(a)')' #  --actual-X- --actual-Y- |  X-in-2D-PLOT Y-in-2D-PLOT'
         do i=1,Nltrp
            write(*,'(i2,2(x,f10.5),3x,a,2(x,f10.5))') &
     i,LatPos(1,i),LatPos(2,i),' | ',LatPos(1,i)-Center(1),LatPos(2,i)-Center(2)
         end do
         write(*,*)'Hit ENTER when done ...' ; read(*,*)
!
![Cs]__________ calculate spectroscopy curves
!
      ELSE IF(trim(cha2).eq.'Cs' .and. Yes_XY .and. Yes_Z) THEN
         open(31,file='spectr.dat',form='formatted',status='unknown')
         do i3=0,ngrid(3)-1
            do i=1,Nltrp
               x(1)=LatPos(1,i) ; x(2)=LatPos(2,i)  ; x(3)=corner(3)+(i3-1)*da(3)
!_________________________ interpolate the density at R() (will be changed!)
               R=x
               call reducn(R,DIRC,BCELL)
               call interpolate(R,BCELL,spctr(i),grid)
            end do
            write(31,'(f10.5,9(x,f10.5))') x(3),(spctr(i),i=1,Nltrp)
         end do
         Yes_Spctr=.true.
!__________________________ check the exponential fit
         rewind(31)
         allocate(dos(ngrid(3))) ; allocate(zz(ngrid(3))) 
         do i=1,Nltrp
            write(*,*)'===============> lateral point ',i,' <================='
            do i3=1,ngrid(3)
               read(31,'(a)') line
               call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
               read(line(LinPos(1):LinEnd(1)),*) zz(i3)
               read(line(LinPos(i+1):LinEnd(i+1)),*) dos(i3)
            end do
            call critical_points(dos,zz,ngrid(3),Zdw,Zup,idw,iup,a,b)
            write(*,'(4(a,f10.5),a)')'[Zdw,Zup] = [',Zdw,',',Zup,'], fit=',a,'*exp(-',b,'*z)' 
            rewind(31)
         end do
         close(31)
         deallocate(dos) ; deallocate(zz)
!
![Vs]__________ preview spectroscopy curves
!
      ELSE IF(trim(cha2).eq.'Vs' .and. Yes_Spctr) THEN
         call Plot_bunch(Nltrp,'spectr.dat',10,Title,title_pl, &
                'Z (A)               ',&
                'LDOS (arb. units)   ', 'Screen', 33)
!
![An]__________ choose the way how the coordinates are given
!
      ELSE IF(trim(cha2).eq.'An') THEN
         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if
!
![Co].... display atomic positions
!
      ELSE IF(trim(cha2).eq.'Co') THEN
         call show_atoms()
!
![cT]__________ centre of a triangle
!
      ELSE IF(trim(cha2).eq.'cT') THEN
         write(*,*)'Give the 1st point/atom:'
         call givepoint(R(1),R(2),R(3),angstr)
         write(*,*)'Give the 2nd point/atom:'
         call givepoint(R1(1),R1(2),R1(3),angstr)
         write(*,*)'Give the 3rd point/atom:'
         call givepoint(R2(1),R2(2),R2(3),angstr)
         x=(R+R1+R2)/3.0
         write(*,*)'The centre of the triangle is at:',(x(i),i=1,3)

!
![mD]__________ middle distance between two points
!
      ELSE IF(trim(cha2).eq.'mD') THEN
         write(*,*)'Give the 1st point/atom:'
         call givepoint(R(1),R(2),R(3),angstr)
         write(*,*)'Give the 2nd point/atom:'
         call givepoint(R1(1),R1(2),R1(3),angstr)
         x=(R+R1)/2.0
         write(*,*)'The middle distance between the points is at:', &
              (x(i),i=1,3)
!
![3D].... contour or 3-dimensional for preview
!
      ELSE IF(trim(cha2).eq.'3D') THEN
         if(type_prv.eq.'2d-old-') then
            type_prv='2d-col-'
         else if(type_prv.eq.'2d-col-') then
            type_prv='2d-gray'
         else if(type_prv.eq.'2d-gray') then
            type_prv='3d-old-'
         else if(type_prv.eq.'3d-old-') then
            type_prv='3d-c-2d'
         else if(type_prv.eq.'3d-c-2d') then
            type_prv='3d-g-2d-'
         else if(type_prv.eq.'3d-g-2d') then
            type_prv='3d-col-'
         else if(type_prv.eq.'3d-col-') then
            type_prv='2d-old-'
         end if
!
![cl].... number of contour levels for preview
!
      ELSE IF(trim(cha2).eq.'cl' .and. type_prv.eq.'2d-old-') THEN
75       write(*,*)'Specify the number of contour levels (2D only; must be > 2):'
         read(*,*,err=75) nclasses
         if(nclasses.lt.2) go to 75
!
![zW].... Z-window: z-values of atoms to be shown in option 'Sh'
!
      ELSE IF(trim(cha2).eq.'zW') THEN
76       write(*,*)'Specify the Z window of coordinates for atoms to be shown in [Sh].'
         write(*,*)'Give the low and high Z coordinates (A):'
         read(*,*,err=76) Zmin,Zmax
         if(Zmax-Zmin.lt.tiny) go to 76
!
![El].... whether add or not empty lines when saving the constant LDOS plot 
!
      ELSE IF(trim(cha2).eq.'El') THEN
         if(Yes_Empty_lines) then
            Yes_Empty_lines=.false.
         else
            Yes_Empty_lines=.true.
         end if
         
![Bb].... ask extensions for the breeding box

      ELSE IF(trim(cha2).eq.'Bb' .and. CHIMERA) THEN

!___________ ask extensions along the existing lattice vectors for the 
!            breeding box and update geom.xyz

         call ask_breeding_box(M1,N1,M2,N2,M3,N3)
         call create_xyz(M1,N1,M2,N2,M3,N3)

![B0].... nullify the extensions for the breeding box

      ELSE IF(trim(cha2).eq.'B0' .and. CHIMERA) THEN

         M1=0 ; N1=0 ; M2=0 ; N2=0 ; M3=0 ; N3=0
         call create_xyz(M1,N1,M2,N2,M3,N3)
!
![Q]__________ return to the previous menu
!
      ELSE IF(trim(cha2).eq.'Q') THEN
         deallocate(LatPos)
         return
      ELSE
         write(*,*)'ERROR! Try again!'
      END IF
      go to 1
end subroutine stm_TH

subroutine critical_points(dos,z,n,Zdw,Zup,idw,iup,a,b)
!..........................................................................
!  dos(z) curve is analysed to choose (i=1,..,n):
!
!       Zdw - point on the curve where the intensity is at a min (large z)
!       Zup - point on the curve where the intensity is at a max (small z)
! 
! At least 5 consequitive points are to be on the slope between Zup and Zdw
!..........................................................................
! From the interval [Zdw,Zup] an exponential fit a*exp(-b*z) is built
! by square-least fit method of log(dos(i))=log(a)-b*z(i), =idw,..,iup
!..........................................................................
implicit none
real*8 dos(n),z(n),Zup,Zdw,a,b,x,y,x2,xy,w,w1
!real* a1,b1
integer j,i3,n,iup,idw
logical first,yes_found

   Zup=z(n) ; Zdw=z(1)
   first=.true. ; yes_found=.false.

!........... find the lowest point at large z
   do i3=n,2,-1
      if(dos(i3-1).ge.dos(i3)) then
         if(first) then
            Zup=z(i3) ; j=1 ; first=.false. ; iup=i3
         else
            j=j+1
            if(j.ge.5) then
               yes_found=.true. ; exit
            end if
         end if
      else
         first=.true. ; Zup=z(i3) ; j=1 ; iup=i3
      end if
   end do
!   write(*,*) 'found Zup= ',Zup,' at iup=',iup

!........... find the highest point at small z

   idw=1
   do i3=iup-1,1,-1
      if(dos(i3-1).lt.dos(i3)) then
         idw=i3 ; Zdw=z(idw)  ; exit
      end if
   end do
!   write(*,*) 'found Zdw= ',Zdw,' at idw=',idw

!.......... use weight
!   b1=-log(dos(idw)/dos(iup)) / (z(idw)-z(iup))
!   a1=exp(log(dos(idw))+b1*z(idw))
!   write(*,*) a1,b1
   w1=0.0 ; x=0.0 ; y=0.0 ; x2=0.0 ; xy=0.0
   do j=idw,iup
!      w=exp(-b1*(z(j)-z(idw))) 
      w=1.0
      w1=w1+w
      x=x+w*z(j) ; y=y+w*log(dos(j)) ; x2=x2+w*z(j)*z(j) ; xy=xy+w*z(j)*log(dos(j))
   end do
   a=exp( (y*x2-x*xy) / (w1*x2-x*x )  )
   b= -(w1*xy-x*y) / (w1*x2-x*x )  
!   write(*,*) a,b
end subroutine critical_points
