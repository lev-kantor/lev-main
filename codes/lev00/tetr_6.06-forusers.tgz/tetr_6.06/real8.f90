module real8
use tetr_param
use sym_par
implicit none
!        implicit none
         real(8),parameter :: pi=3.141592654d0

!............ parameters for strings ...................................
!    LENG2 - max number of words in a string (for CutStrT routine)
!    LENG1 - max length of the striong Line  (for CutStrT routine)
!    SETS  - max number of sets to be created in lists (do_sets_from_list)

         integer,parameter :: LENG2=1000,LENG1=2*LENG2,SETS=LENG1/5

end module real8
