module effective_atom
  implicit none
  real*8,dimension(:),allocatable :: eigval,Ham,Dk
  real*8,dimension(:,:),allocatable :: eigvect
!..... cp2k parameters  
!  n_of_states - number of state available from cp2k
!  n_of_AOs - the number of atomic basis in cp2k calculation
!  nw - the number of omega values in the Gamma(w) function
!  i_He - the state to be excluded as related to the Effective Atom
  integer :: n_of_states,n_of_AOs,nw,i_He
!..... characterising the energy levels from cp23k calculation  
!  W1,W2 - minimum and maximum energies of KS states
!  delta - smearing used in representing the delta function
!  dw  - energy interval for integrations over energy 
  real*8 :: W1,W2,delta,dw,pi=3.14159
!..... parameters of the effective atom
!  Gamma_R - gamma for the tip (right lead)
!  E_at - energy level of the effective atom (eV)
!  T - temperature (K)
!  mu - chemical potential (Fermi energy) (eV)
  real*8 :: Gamma_R,E_at,kB=8.61733D-5,T,mu
  
CONTAINS

real*8 function deltaf(x)
  implicit none
  real*8 :: x
  deltaf=delta/((delta*delta+x*x)*pi)
end function deltaf

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine input()
  implicit none
  open(1,file='input.dat',status='old',err=1)
!.... sp2k dimensions
  read(1,*,err=1) nw
!.... parameters: tip's gamma and effective atom energy (eV)
  read(1,*,err=1) Gamma_R,E_at
  read(1,*,err=1) T
!... chemnical potential: from a.u. (cp2k) to eV  
  read(1,*,err=1) mu ; mu=mu*27.21
  read(1,*,err=1) delta
  close(1)
  return
1 write(9,*)'ERROR: file <input.dat> not found or bad!'
  stop 'in input()'
end subroutine input

  
subroutine read_Ham(name,ln,err)
!.... reading the Hamiltonian matrix  
!.... only need the last row of the Hamilton matrix assuming the He atom comes last in the list
  implicit none
  character :: name*100
  integer :: ln,k1,k2,i,j
  real*8 :: a
  logical :: err

  write(9,*) name(ln:)
  err=.false.
  open(1,file=name(ln:),status='old',err=1)
  k1=1
  do
     k2=k1+3 ; if(k2.gt.n_of_AOs) k2=n_of_AOs
     do i=1,n_of_AOs
        if(i.lt.n_of_AOs) then
           read(1,*,err=1) (a,j=k1,k2)
        else
           read(1,*,err=1) (Ham(j),j=k1,k2)
        end if
     end do
     if(k2.eq.n_of_AOs) exit
     k1=k2+1
  end do
  close (1)
  write(9,*) '>>> File ',name(ln:),' read in successfully!'
  Ham=Ham*27.21
  return

1 write(9,*)'ERROR! The file '//name(ln:)//' is not found or bad!'
  err=.true.
end subroutine read_Ham

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine read_eig_dim(name,ln,err)
!.... determine N_of_AOs,n_of_states
  implicit none
  character :: name*100,line*100
  integer :: ln,i,j
  logical :: err
  real*8 :: a

!________________ determine n_of_AOs  

  err=.false.
  open(1,file=name(ln:),status='old',err=1)
  write(9,*) 'opened '//name(ln:)
  read(1,'(/)')
  i=0
  do 
     read(1,'(a)') line
     read(line,*,err=2) a
     i=i+1
  end do
2 n_of_AOs=i

!________________ determine n_of_states
  rewind(1)

  i=0
  do
     read(1,*,err=3) a
     do j=1,n_of_AOs
        read(1,*,err=1) a
     end do
     i=i+1
  end do
3 n_of_states=i
  close(1)
  return

1 write(9,*)'ERROR! The file '//name(ln:)//' is not found or bad!'
  err=.true.
end subroutine read_eig_dim

subroutine read_eig(name,ln,err)
!.... reading the eigenvectors/values; determine the minimum and the maximum energies.
!.... Determine which state to be excluded as having the largest He contribution
  implicit none
  character :: name*100
  integer :: ln,i,j
  real*8 :: He_max
  logical :: err

  write(9,*) name(ln:)
  err=.false.
  open(1,file=name(ln:),status='old',err=1)

  W1=1.0E10 ; W2=-1.0E10 ;  He_max=0.0
  do i=1,n_of_states
     read(1,*,err=1) eigval(i)
     eigval(i)= eigval(i)*27.21
     if(eigval(i).gt. W2) W2=eigval(i)
     if(eigval(i).lt. W1) W1=eigval(i)

     do j=1,n_of_AOs
        read(1,*,err=1) eigvect(j,i)
     end do
     if(abs(eigvect(n_of_AOs,i)).gt.He_max) then
        He_max=abs(eigvect(n_of_AOs,i))
        i_He=i
     end if
  end do
  close(1)
  write(9,*)'W1 = ',W1,' W2 = ',W2
  dw=(W2-W1)/nw
  write(9,*)'The state ',i_He,' has to be EXCLUDED: He coeff = ',eigvect(n_of_AOs,i_He)
  write(9,*) '>>> File ',name(ln:),' read in successfully!'
  return

1 write(9,*)'ERROR! The file '//name(ln:)//' is not found or bad!'
  err=.true.
end subroutine read_eig

subroutine make_Tk()
  implicit none
  integer :: k,i
  real*8 :: s
  do k=1,n_of_states
     s=0.0d0
     do i=1,n_of_AOs-1
        s=s+eigvect(i,k)*Ham(i)
     end do
     Dk(k)=s
!     write(*,*) eigval(k),Dk(k),Dk(k)*Dk(k)
  end do
end subroutine make_Tk

real*8 function gamma(w)
!..... level width function  
  implicit none
  real*8 :: w,s
  integer :: k,m

  m=n_of_AOs-1
  s=0.0d0
  do k=1,n_of_states
     if(k.ne.i_He) then
        s=s+Dk(k)*Dk(k)*deltaf(w-eigval(k))
     end if
  end do
  gamma=s*2*pi
  
end function gamma

real*8 function re_se(w)
!....... real part of the self-energy: calculated by eliminating the singularity  
  implicit none
  real*8 :: w,s,ww,deriv,re
  integer :: i

  s=0.0d0
  do i=0,nw
     ww=W1+i*dw
     if(abs(w-ww).lt.dw) then
          deriv = (gamma(w+0.01)-gamma(w))/0.01
        s=s+deriv
     else
        s=s+(gamma(ww)-gamma(w))/(ww-w)
     end if
  end do
  s=s*dw
  re = gamma(w)*log(abs((W2+0.1-w)/(W1-0.1-w)))
  re_se = -(s + re)/(2*pi)
end function re_se

real*8 function transmission(w,V)
!..... for the current
!  V - voltage (eV)
!.... transmission function  
  implicit none
  real*8 :: w,V,a,b,g

  g=gamma(w+V)
  a=w-E_at-re_se(w+V)
  b=Gamma_R + g
  transmission= (2.0/pi) * Gamma_R * g /( a*a+0.25*b*b )
end function transmission

real*8 function fermi(w)
!....... Fermi function at energy w (in eV)
!  kB - Boltzmann's constant (eV/K)
  implicit none
  real*8 :: w,beta

  beta=1.0d0/(kB*T)
  fermi=1.0d0/(exp(beta*(w-mu))+1.0d0)
end function fermi

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

real*8 function current(V)
!..... current
!  V  - voltage (eV)
  implicit none
  real*8 :: V,s,eps=0.001,w,ff,f1,f2
  integer :: i
  logical :: first

  first=.false.
  s=0.0d0
  do i=0,nw
     w=W1+i*dw
     ff=fermi(w)-fermi(w+V)
     if(abs(ff).gt.eps) then
        if(.not.first) then
           first=.true.
           f1=w
        end if
        s=s+ff*transmission(w,V)
     else
        if(first) then
           f2=w
           exit
        end if
     end if
  end do
  current=s*dw
  write(9,*) 'V = ',V,' energies = [ ',f1,',',f2,' ]'
end function current

end module effective_atom

  
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine preparation(name_ham,lh,name_eig,le)
  use effective_atom
  implicit none
!..... names of cp2k output data
  character :: name_ham*100,name_eig*100
  integer :: lh,le
  logical :: err

!...... determine dimensions of the job

  call read_eig_dim(name_eig,le,err)
  write(9,*) 'n_of_AOs= ',n_of_AOs 
  write(9,*) 'n_of_states =',n_of_states
  if(err) then
     write(9,*)  '===> Reading Eigenvectors/Values error'
     stop
  end if
  
!...... input parametes and cp2k dimensions
  
  call input()
  allocate(eigval(n_of_states),eigvect(n_of_AOs,n_of_states))
  
!.... reading the Hamiltonian matrix  
!.... only need the last row of the Hamilton matrix assuming the He atom comes last in the list

  allocate(Ham(n_of_AOs))
  call read_Ham(name_ham,lh,err)
  if(err) then
     write(9,*)  '===> Reading Ham error'
     stop
  end if
  
!.... reading the eigenvectors/values; determine the minimum and the maximum energies.
!.... Determine which state to be excluded as having the largest He contribution

  call read_eig(name_eig,le,err)
  if(err) then
     write(9,*) '===> Reading eigenvectors/values error'
     stop 
  end if
!.... calcualtion of the vector Dk

  allocate(Dk(n_of_states))
  call make_Tk()
  deallocate(eigvect,Ham)

end subroutine preparation
