subroutine EA_model_one(Which_Code)
!.............................................................................
! Using the current surface geometry, it will create a CP2K file
! for the calculation of the current and dI/dV for this structure
!.............................................................................
!.........................     only model 4     ..............................
!.............................................................................
  use real8
  use tetrag1
  use mlists
  implicit none
  integer :: nw
  integer :: i,j,l0,ln,io,iorb,iorbf,iorbt
  character :: Labels(N0LT)*2
  integer :: length,iAt,ii,iA,is,NoSp(N0KD),lengthT
  character :: dir*17,cha2*2
  real*8 :: slab,s
  real*8 :: T,delt,mu,GammaT,Ea
  real*8 :: del
  integer :: iT0,iT1,iC0,iC1,ic,method
  real*8,parameter :: tiny=0.0001
  logical :: YES_Lv,tagYES,Yes_Mv,Yes_No,Yes_dir
  logical :: tagC,tagT,listat(N0LT),listatT(N0LT),lis
  logical :: tagPt,listatPt(N0LT)
  character :: Which_Code*6,YES_xyz*4,reg(N0LT)*2
  character*12 :: name*100

!..... check if this is the slab geonmetry
  
  slab=abs(AJ(3,1)) + abs(AJ(3,2)) + abs(AJ(1,3)) + abs(AJ(2,3))
  if(slab.ne.0.0) then
     write(*,*)'CANNOT PROCEED: this is NOT a slab geometry!'
     write(*,*)'>>>>>>>>>>>>> Make sure: <<<<<<<<<<<<<<'
     write(*,*)'  (i) the 3rd lattice vector is along Z'
     write(*,*)' (ii) the 1st and 2nd lattice vectors are within XY plane'
     write(*,*)'Press ENTER when ready'
     read(*,*)
     return
  end if
    write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'WARNING 1: slab atoms must go conitnuously within the XY plane.'
  write(*,*)'           Correct in the M menu if this is not the case first.'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'WARNING 2: the TIP in the input must be at the LOWEST POSITION '
  write(*,*)'           Lower the tip before proceeding!'               
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
!
!========================================================================
!===================== MENU starts here =================================
!========================================================================
!
  iAt=0
  do i=1,Nsp
     do ii=1,NspN(i)
        iAt=iAt+1 ; Labels(iAt)=Species(i)
     end do
  end do
  YES_xyz='Xmol' ; YES_Lv=.true. ; tagYES=.false. 
  listat=.false. ; Yes_No=.false.
  delt=0.08 ; T=300.0 ; Nw=1000 ; mu=-0.1246 ; method=4 ; del=0.002
  tagC=.false. ; tagT=.false. ; tagPt=.false.
  reg='  '; Yes_Mv=.false. ; Yes_dir=.false.


21 write(*,*)'/---------------------------------------------------\\'
  write(*,*)'|......................  MENU .......................|'
  write(*,*)'\\---------------------------------------------------/'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,'(a)') '......... CURRENT lattice vectors ...'
  do i=1,3
     write(*,'(a,i1,a,3(f10.5,x))') '[',i,'] ',(AJ(i,j),j=1,3)
  end do
  write(*,'(a,5x,20(a2,x))') '>>> Species: ',(Species(i),i=1,Nsp)
  write(*,*)'>>>>> METHOD 4 >>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'>> Atoms in CP2K input WILL come in order: S, T, C   <<'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)

  write(*,*)'=============  Define the SYSTEM  ==================='

  write(*,'(a)')  ' Tc. Tag C region atoms'
  if(tagC) call print_long_char(lists,length,long_lists)
  tagYES=tagC
  write(*,'(a)')  ' Tt. Tag T region atoms (may not be ALL of the physical tip)'
  if(tagT) call print_long_char(listsT,lengthT,long_listsT)
  tagYES=tagC.and.tagT

  if(Yes_Mv) then
     write(*,'(a)') ' Si. [For save] Place CP2K input files with @include into directories:'
     write(*,'(a)') '     The file name: '//name(ln:)//'.inp'
  else
     write(*,'(a)') ' Si. [For save] CP2K input with @include: UNDEFINED'
  end if
  if(.not.Yes_dir) then
     write(*,'(a)') ' Dr. Destination directory for CP2K input UNDEFINED'
  else
     write(*,'(a)') ' Dr. Destination directory for CP2K input is : '//trim(dir)
  end if

  if(tagYES .and. Yes_Mv .and. Yes_dir) write(*,'(a)') '  S. Save reodered CP2K input file'

  write(*,'(a)')  ' ================ For the calculation of the CURRENT ==================='
  
  write(*,'(a,f10.5)')  ' Nw. Step for the frequency integration = ',del
  write(*,'(a,f10.5)')  '  T. Temperature = ',T
  write(*,'(a,f10.5)')  ' Mu. Chemical potential = ',mu
  write(*,'(a,f10.5)')  '  D. A delta to numerically represent the delta function = ',delt
  if(Yes_No) then
     write(*,'(a)')     ' No. Number of orbitals for each species:'
     write(*,'(5(10x,a,i5,a))') (Species(is)//' [',NoSp(is),'] ',is=1,Nsp)
     if(tagYES) then
        iA=0  ; iorb=0 ; iorbf=0 
        do is=1,Nsp
           do i=1,NspN(is)
              iA=iA+1
              lis=listat(iA); if(method.eq.4) lis=listat(iA).or.listatT(iA)
              if(.not.lis) then
                 iorb=iorb+NoSp(is)
                 iorbf=iorbf + NoSp(is)
              end if
           end do
        end do
        if(method.eq.4) then
           iorbt=iorb
           iA=0
           do is=1,Nsp
              do i=1,NspN(is)
                 iA=iA+1
                 if(listatT(iA)) then
                    iorbt=iorbt+NoSp(is)
                    iorbf=iorbf + NoSp(is)
                 end if
              end do
           end do
        end if
        iA=0
        do is=1,Nsp
           do i=1,NspN(is)
              iA=iA+1
              if(listat(iA)) iorbf=iorbf + NoSp(is)
           end do
        end do
        write(*,'(a,i10)')      '     The S subsystem orbitals span from 1 to ',iorb
        write(*,'(2(a,i10))')   '     The T subsystem orbitals span from ',iorb+1,' to ',iorbt
        write(*,'(2(a,i10))')   '     The C subsystem orbitals span from ',iorbt+1,' to ',iorbf
        If(Yes_dir) write(*,'(a)')  ' Sd. Save [input.dat] file for the current calculation'
     end if
  else
     write(*,'(a)')     ' No. Number of orbitals for each species: UNDEFINED'
  end if
  
  write(*,'(a)')  ' ======================== S E T T I N G S =============================='
  write(*,'(a)')  ' Co. Show atomic positions '
  write(*,'(a)') '  Q. Quit.'
  write(*,*)
  write(*,*)'Specify the character and press ENTER ------->'
  read(*,'(a)',err=21) cha2  ; write(8,'(a)') cha2
  call right(cha2,2,l0)

![T]........... temperature

  IF(cha2(l0:).eq.'T') THEN

     write(*,*)'Enter the temperarture (K):'
     read(*,*,err=21) s ; write(8,*) s
     if(s.lt.0.0) go to 21
     T=s
     
![Mu]........... chemical potential

  ELSE IF(cha2(l0:).eq.'Mu') THEN

     write(*,*)'Enter the chemical potential (eV):'
     read(*,*,err=21) s ; write(8,*) s
     mu=s

![D]........... a small delta to handle numerically the delta function

  ELSE IF(cha2(l0:).eq.'D') THEN

     write(*,*)'Enter the value of the delta to be used in the Lorenzian:'
     read(*,*,err=21) s ; write(8,*) s
     if(s.lt.0.0) go to 21
     delt=s

![No]........... give number of AOs for every species in the system

  ELSE IF(cha2(l0:).eq.'No') THEN

     Yes_No=.false.
     write(*,*)'Enter the number of AOs in CP2K corresponding to each species:'
     do is=1,Nsp
        write(*,*) 'Give the number of AOs for '//Species(is)//':'
        read(*,*,err=21) i
        if(i.lt.1) go to 21
        NoSp(is)=i
     end do
     Yes_No=.true.
     
![Nw]........... frequency integration grid / integration step

  ELSE IF(cha2(l0:).eq.'Nw') THEN

     write(*,*)'Enter the integration step:'
     read(*,*) del
     if(del.le.0.0) go to 21
     
     
![Sd].......... save input.dat file for the current calculation

  ELSE IF(cha2(l0:).eq.'Sd' .and. TagYES .and. Yes_No .and. Yes_dir) THEN

     open(19,file=trim(dir)//'/input.dat')
     write(19,*) del
     if(method.eq.1 .or. method.eq.2) write(19,*) GammaT,Ea
     write(19,*) T
     write(19,*) mu 
     write(19,*) delt
     if(method.ne.4) then
        write(19,'(2(i10,x),a)') iorb,iorbf,'  <= SC-system'
     else
        write(19,'(3(i10,x),a)') iorb,iorbt,iorbf,'  <= STC-system'
     end if
     write(19,*) 'T F F'
     close(19)

![Tc].......... tag C atoms

  ELSE IF(cha2(l0:).eq.'Tc') THEN

     listat=.false. ; tagC=.false.
     
     call TTag(tagC,ITI,TI,Labels,listat,lists,length,N_lists,long_lists)
     do i=1,ITI
        if(listat(i)) then
           tagC=.true. ;  exit
        end if
     end do
     
![Tt].......... tag T atoms: must not be C atoms

  ELSE IF(cha2(l0:).eq.'Tt' .and. method.eq.4) THEN

     listatT=.false. ; tagT=.false.
     
     call TTag(tagT,ITI,TI,Labels,listatT,listsT,lengthT,N_lists,long_listsT)
     do i=1,ITI
        if(listatT(i)) then
           if(listatT(i) .and. listat(i)) then
              listatT=.false.
              write(*,*)'ERROR!Some of the T[ip] atoms are in the C[entral] region!'
              TagT=.false. ; exit
           else
              TagT=.true. 
           end if
        end if
     end do
     
![Dr]...... destination directory for the file

  ELSE IF(cha2(l0:).eq.'Dr') THEN

     write(*,*)'Specify the destinaiton directory for the CP2K file (up to 20 characters):'
     read(*,'(a)') dir
     write(*,*) '... creating directory '//trim(dir)
     call system('mkdir '//trim(dir))
     Yes_dir=.true.
     
![S].......... Save 
        
  ELSE IF(cha2(l0:).eq.'S' .and. tagYES .and. Yes_Mv .and. Yes_dir) THEN

!______ determine positions of the atom(s), create the correct directory
!       structure and write the input file in each directory.
! 
! IMPORTANT [necessary for CURRENT]:
!           Method 1-3: C atom(s) is(are) assumed last in the list 
!           Method 4: atoms are in order: S,T, then C 
! Hence, atoms will be reodered in the CP2K input !!!

!______________ create file [coordinates.inc] with atomic positions in each directory
!______________ IMPORTANT: atoms are reodered in the CP2K input !!!

     open(19,file='coordinates1.inc')
     open(29,file='relax_flags1.inc')
     iAt=0
              
!________ S atoms first (methods 1-4) [iAt - counts atoms in the new order]

     iA=0 ; ic=0
     do is=1,Nsp
        do i=1,NspN(is)
           iA=iA+1 
           lis=listat(iA); if(method.eq.4) lis=listat(iA).or.listatT(iA)
           if(.not.lis) then
              iAt=iAt+1 ; ic=ic+1
              write(19,'(a,3(x,f10.5))') Species(is),TI(1:3,iA)
              if(relax_flag(1,iA).eq.'F' .or. relax_flag(2,iA).eq.'F' &
                   .or. relax_flag(3,iA).eq.'F') then
                 write(29,'(a,i5)') 'LIST ',iAt
              end if
           end if
        end do
     end do
              
!________ T atoms (method 4 only)
! iT0 - number of the first T atom in the new order
! iT1 - number of the last T atom in the new order

     if(method.eq.4) then              
        iA=0 ; iT0=ic+1 ; ic=0
        do is=1,Nsp
           do i=1,NspN(is)
              iA=iA+1 
              if(listatT(iA)) then
                 iAt=iAt+1 ; ic=ic+1
                 write(19,'(a,3(x,f10.5))') Species(is),TI(1:3,iA)
                 if(relax_flag(1,iA).eq.'F' .or. relax_flag(2,iA).eq.'F' &
                      .or. relax_flag(3,iA).eq.'F') then
                    write(29,'(a,i5)') 'LIST ',iAt
                 end if
              end if
           end do
        end do
        iT1=iT0+ic-1
     end if
                 
!________ C atoms (methods 1-4)       
              
     iA=0
     iC0=ic+1 ; if(method.eq.4) iC0=iT1+1 ; ic=0
     do is=1,Nsp
        do i=1,NspN(is)
           iA=iA+1 
           if(listat(iA)) then
              iAt=iAt+1 ; ic=ic+1
              write(19,'(a,3(x,f10.5))') Species(is),TI(1:3,iA)
              if(relax_flag(1,iA).eq.'F' .or. relax_flag(2,iA).eq.'F' &
                   .or. relax_flag(3,iA).eq.'F') then
                 write(29,'(a,i5)') 'LIST ',iAt
              end if
           end if
        end do
     end do
     iC1=iC0+ic-1
     
     close(19) ; close(29)

     write(*,'(a)') 'mv coordinates1.inc '//trim(dir)//'/coordinates.inc'
     call system('mv coordinates1.inc '//trim(dir)//'/coordinates.inc')
     write(*,'(a)') 'mv relax_flags1.inc '//trim(dir)//'/relax_flags.inc'
     call system('mv relax_flags1.inc '//trim(dir)//'/relax_flags.inc')
     
!_______________ copy CP2K input into the designated subdirectory
     
     write(*,'(a)') 'cp '//name(ln:)//'.inp '//trim(dir)//'/input_SCT.inp'
     call system('cp '//name(ln:)//'.inp '//trim(dir)//'/input_SCT.inp')
           
![Co].... display atomic positions

  ELSE IF(cha2(l0:).eq.'Co') THEN

     do iA=1,ITI
        reg(iA)(2:2)=' ' ; if(listatPt(iA)) reg(iA)(2:2)='p'
        if(listat(iA)) then
           reg(iA)(1:1)='C '
        else if(method.eq.4 .and. listatT(iA)) then
           reg(iA)(1:1)='T'
        else
           reg(iA)='S '
        end if
     end do
     call show_atoms_EA(reg)

![Si].... move the final CP2K input file with @include statements into each directory 

  ELSE IF(cha2(l0:).eq.'Si') THEN

     if(Yes_Mv) then
        Yes_Mv=.false.
     else
        write(*,*)'*** Enter the input file NAME [NAME.inp] {without .inp extension} ***'
        write(*,*)'*** containing statements:                                        ***'
        write(*,*)'***                                                               ***'
        write(*,*)'***   @include coordinates.inc (instead of atoms of the system)   ***'
        write(*,*)'***   @include relax_flags.inc (within &FIXED_ATOMS block)        ***'
        write(*,*)'***                                                               ***'
        write(*,*)'*** This input file will be used to run CP2K.                     ***'
        read(*,'(a)') name ; write(*,'(a)') name
        call right(name,100,ln)
        open(19,file=name(ln:)//'.inp',status='old',iostat=io)
        if(io.eq.0) then
           write(*,*)'... file '//name(ln:)//'.inp exists. Proceed.'
           close (19)
        else
           write(*,*)'... file '//name(ln:)//'.inp does NOT exists.'
           go to 21
        end if
        Yes_Mv=.true.
     end if

![Q]...... quit

  ELSE IF(cha2(l0:).eq.'Q') THEN
      
!.......... return the original settings

     return
  ELSE
     write(*,*) 'Wrong! Try again!'
  END IF
  go to 21
     
!..................................................................................      
!............................. MENU ENDS ..........................................
!..................................................................................      
end subroutine EA_model_one
