subroutine cp2k_update(name,l)
  implicit none
  character*200,dimension(:),allocatable :: lines
  integer,dimension(:),allocatable :: len
  character*200 :: Line1
  character*100 :: name
  integer :: i,l,j,li,i0,k,ln,ii,lw,lv,i1
  integer :: LinEnd(100),LinPos(100),NumLin,iErr

!....... determine the number of lines in the input file  

  open(1,file=name(l:),status='old',form='formatted')
  i=0
1 do
     read(1,'(a)',end=2,err=2) line1
     i=i+1
  end do
2 li=i
!  write(*,*) 'Found i= ',i,' lines in the file'
  allocate(lines(li),len(li))
  rewind(1)
  do i=1,li
     read(1,'(a)') lines(i)
  end do
  close(1)

!....... identify and substitute the parameters found with "values"
  ii=0
  do i=1,li

!     write(*,*)'.... analysing line i = ',i
     call CutStr(lines(i),NumLin,LinPos,LinEnd,0,0,iErr)
     len(i)=LinEnd(NumLin)
     i0=index(lines(i)(LinPos(1):LinEnd(1)),'@SET')
     if(i0.ne.0) then
        ln=LinEnd(2)-LinPos(2)+1
        ii=ii+1
!        write(*,*)'...(',ii,') found parameter '//lines(i)(LinPos(2):LinEnd(2))
!        write(*,*)'            with the value '//lines(i)(LinPos(3):LinEnd(3))
        
        do k=1,Li
!           write(*,*)'............. analysing line k = ',k
           i0=index(lines(k),'$'//lines(i)(LinPos(2):LinEnd(2))//' ')
           i1=index(lines(k),'${'//lines(i)(LinPos(2):LinEnd(2))//'}')
           if(i0.ne.0 .and. i.ne.k) then
              lw=LinEnd(2)-LinPos(2)+2
              lv=LinEnd(3)-LinPos(3)+1
              call replace_word(lines(k),'$'//lines(i)(LinPos(2):LinEnd(2)),lw,lines(i)(LinPos(3):LinEnd(3)),lv)
           else if(i1.ne.0 .and. i.ne.k) then
              lw=LinEnd(2)-LinPos(2)+4
              lv=LinEnd(3)-LinPos(3)+1
              call replace_word(lines(k),'${'//lines(i)(LinPos(2):LinEnd(2))//'}',lw,lines(i)(LinPos(3):LinEnd(3)),lv)
           end if
        end do
        
     end if       
  end do

!....... write the new input file

  call system('mv '//name(l:)//' '//name(l:)//'_keep')
  open(1,file=name(l:),status='new',form='formatted')

  do i=1,li
     write(1,'(a)') lines(i)(1:len(i))
  end do
  close(1)
  deallocate(len,lines)

end subroutine cp2k_update
  
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine replace_word(line,word,lw,value,lv)
!===========================================================================
! replace $word (of length lw excluding $) in line by value (of length lv)
!===========================================================================
  implicit none
  character :: line*200,line1*200
  character*(*) :: word,value
  integer :: lw,lv,NL,LP(100),LE(100),iErr,i,ip,ll,l1

!  write(*,'(a)') line
!  write(*,'(a)') 'word = '//word(1:lw)
!  write(*,'(a)') 'value = '//value(1:lv)
  
!....... find the poisition i in line where $word is
  call CutStr(line,NL,LP,LE,0,0,iErr)
  do i=1,NL
     if(index(line(LP(i):LE(i)),word(1:lw)).ne.0) exit
  end do
  ip=i
!  write(*,*) '... found word at No = ',i

!....... replace $word with value  
  
  do i=1,200
     line1(i:i)=' '
  end do
  if(ip.eq.1) then
     line1(1:lv)=value(1:lv)
     ll=LE(NL)-LP(2)+1
     line1(lv+2:lv+2+ll-1)=line(LP(2):LE(NL))
  else if(ip.lt.NL) then
     line1(1:LE(ip-1))=line(1:LE(ip-1))
     l1=LP(ip)+lv-1
     line1(LP(ip):l1)=value(1:lv)
     ll=LE(NL)-LP(ip+1)+1
     line1(l1+2:l1+2+ll-1)=line(LP(ip+1):LE(NL))
  else
     line1(1:LE(ip-1))=line(1:LE(ip-1))
     l1=LP(ip)+lv-1
     line1(LP(ip):l1)=value(1:lv)
  end if
  line=line1
!  write(*,'(a)') line

end subroutine replace_word
