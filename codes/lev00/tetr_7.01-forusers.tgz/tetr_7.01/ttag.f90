      subroutine TagB(NumLin,ITI,listb,L_ext)
!.......................................................................
!       Specific version of Tag() for the Tb option of the M-menu        
!.......................................................................
! analyses the Line with NumLin words (by LinPos and LinEnd), each word
! may contain either a number or two numbers separated by a dash, and
! creates .true. in the vector listb() for atoms that are selected
!
!    listb(atoms in the list)     = .true.
!    listb(atoms not in the list) = .false.
!.......................................................................
      use real8
      use bb  
      implicit none
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin
      character (LEN=LENG1) :: Line
      logical :: listb(L_ext)
!
      integer :: i,iErr,ITI,i0,i1,i2,L_ext,j

      listb=.false.

!............ now nicely ask

 44   write(*,*)'=====> To remove atoms from visualisation: <======'
      write(*,*)'Specify atoms using space and/or comma to separate lists'
      write(*,*)'and a dash (without space) to indicate from/to'
      write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
      write(*,*)
      write(*,*)'=====> To return removed atoms to visualisation press ENTER <======'
      write(*,*)
      read(*,'(a)') line ; write(8,'(a)') trim(line)
      call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
      if(iErr.ne.0) go to 44
      if(NumLin.eq.0) then
         write(*,*)'WARNING! The tagging is disabled!' ; return
      end if

!............ produce the listat

      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=44) i1 ; i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=44) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=44) i2
         end if
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.L_ext) go to 44
         do j=i1,i2
            listb(j)=.true.
         end do
      end do

      end subroutine TagB

      subroutine TagS(NumLin,ITI,ts_list,ts_atoms)
!.......................................................................
!       Specific version of Tag() for the Ts option of the M-menu        
!.......................................................................
! analyses the Line with NumLin words (by LinPos and LinEnd), each word
! may contain either a number or two numbers separated by a dash, and
! creates .true. in the vector listb() for atoms that are selected
!
!    ts_list(atoms in the list)     = .true.
!    ts_list(atoms not in the list) = .false.
!.......................................................................
      use real8
      use bb  
      implicit none
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin,ts_atoms(N0LT)
      character (LEN=LENG1) :: Line
      logical :: ts_list(N0LT)
!
      integer :: i,iErr,ITI,i0,i1,i2,j

!............ now nicely ask

 44   write(*,*)'=====> To remove atoms from visualisation: <======'
      write(*,*)'Specify atoms using space and/or comma to separate lists'
      write(*,*)'and a dash (without space) to indicate from/to'
      write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25.'
      write(*,*)
      write(*,*)'If the atoms have been selected, entering new atoms will ADDED.'
      write(*,*)
      write(*,*)'=====> To return removed atoms to visualisation just press ENTER <======'
      write(*,*)
      read(*,'(a)') line ; write(8,'(a)') trim(line)
      call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
      if(iErr.ne.0) go to 44
      if(NumLin.eq.0) then
         write(*,*)'WARNING! The tagging is disabled!'
         ts_list=.false.
         do i=1,ITI
            ts_atoms(i)=i
         end do
         return
      end if

!............ produce the listat

      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=44) i1 ; i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=44) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=44) i2
         end if
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.N0LT) go to 44
         do j=i1,i2
            ts_list(ts_atoms(j))=.true.
         end do
      end do

!....... create the ts_atoms mapping: ts_atom("remained atom number")="actual atom number"

      j=0
      do i=1,ITI
         if(.not. ts_list(i)) then
            j=j+1 ; ts_atoms(j)=i
         end if
      end do

      end subroutine TagS

      subroutine Tag(NumLin,ITI,listat,list,len,N_lists,long_list)
!.......................................................................
! analyses the Line with NumLin words (by LinPos and LinEnd), each word
! may contain either a number or two numbers separated by a dash, and
! compiles a list for tagging, namely, it sets:
!
!    listat(atoms in the list)     = .true.
!    listat(atoms not in the list) = .false.
!    list(1:len)  - contains a nicely written list of atoms
!.......................................................................
      use real8
      use bb  
      implicit none
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin
      character (LEN=LENG1) :: Line
      logical :: listat(*),long_list
      character(*) :: list
!
      integer :: i,iErr,ITI,len,N_lists,i0,i1,i2,L_ext

      L_ext=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)*ITI
!........... initialise the listat first
      listat(1:ITI)=.false.

!............ now nicely ask

 44   write(*,*) &
              'Specify atoms using space and/or comma to separate lists'
      write(*,*)'and a dash (without space) to indicate from/to'
      write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
      write(*,*)'Use the word [all] if all atoms need to be chosen.'
      read(*,'(a)') line ; write(8,'(a)') trim(line)
      call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
      if(iErr.ne.0) go to 44
      if(NumLin.eq.0) then
         write(*,*)'WARNING! The tagging is disabled!' ; return
      else if(Numlin.eq.1 .and. line(LinPos(1):LinEnd(1)).eq.'all') then
         listat(1:ITI)=.true.
         call filter(listat,1,ITI)
         go to 45
      end if

!............ produce the listat

      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=44) i1 ; i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=44) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=44) i2
         end if
         
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.L_ext) go to 44
         call filter(listat,i1,i2)
      end do

!__________ compose the nice list

45    call do_nice_list(listat,ITI,list,len,N_lists,long_list)
      end subroutine Tag

      subroutine filter(listat,j1,j2)
      use real8
      use tetrag1
      use bb
      implicit none
!.......................................................................
!  For all atoms i in the primitive cell it sets elements of logical
!  listat(i) to .true. if they correspond to atom numbers between j1 
!  and j2 of a (possibly) extended cell. This way, even if the supercell 
!  is extended and atoms are chosen, only the appropriate atoms  in 
!  the primitive cell will be actually correctly selected.      
!.......................................................................
! jj - atom number in the primitive cell
!.......................................................................
      logical :: listat(*)
      integer :: nat,jj,i1,i2,i3,k,i,j1,j2,prim_no

      nat=0 
      DO i=1,Nsp
         do i1=M11,N11
            do i2=M22,N22
               do i3=M33,N33

                  DO k=1,NspN(i)
                     nat=nat+1
                     if(nat.ge.j1 .and. nat.le.j2) then
                        jj=prim_no(i,k) ; listat(jj)=.true.
                     end if
                     if(nat.gt.j2) return
                  END DO

               end do
            end do
         end do
      END DO
      end subroutine filter

      integer function prim_no(i1,k1)
      use real8
      use tetrag1
!.....................................................................        
! it gives TRUE if atom of species 'i1' and species number 'k1' was
! selected in listat()
!.....................................................................        
      implicit none
      integer nat,i,k,k1,i1
      
      nat=0
      DO i=1,Nsp
         do k=1,NspN(i)
            nat=nat+1
            if(i.eq.i1 .and. k.eq.k1) then
               prim_no=nat ; return
            end if
         end do
      END DO
      end function prim_no

      subroutine TTag(TagYes,ITI,TI,Labels,listat,list,len,N_lists,long_list)
!.......................................................................
! compiles a list for tagging, namely, it sets:
!
!    listat(atoms in the list)     = .true.
!    listat(atoms not in the list) = .false.
!    list(1:len)  - contains a nicely written list of atoms
!.......................................................................
! A number of options are offered in a little menu, including:
!   - by coordinates
!   - by numbers
!   - by species
! You can apply one option after another builging this way a complicated
! list.
!.......................................................................
! If asked by numbers, then it analyses the Line with NumLin words
! (by LinPos and LinEnd), each word may contain either a number or two
! numbers separated by a dash, and
!.......................................................................
! N_lists - the maximum allowed length of the character list (it is only
!           used for printing in the routine calling this one)
!.......................................................................
      use real8
      use bb
      implicit none
      character (LEN=LENG1) :: Line
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin
      logical :: listat(*),TagYes,long_list
      character(*) :: list
      character :: cha*10,chb*10,cha2*2,Labels(*)*2,ch,spec*2
      real(8) :: TI(3,N0LT),Rad=1.0d0
      real(8),dimension(3) :: cp=(/0.0d0,0.0d0,0.0d0/)
!
      integer :: ITI,len,N_lists,l0,iErr,i,i0,i1,i2,j,nat,L_ext
      real(8) :: x1,x2,y1,y2,z1,z2,d

!........... initialise the listat first
      listat(1:ITI)=.false.
      x1=-1.e10 ; x2=1.e10 ; y1=-1.e10 ; y2=1.e10 ; z1=-1.e10
      z2= 1.e10 ; TagYes=.false.
      L_ext=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)*ITI
!
!.......................................................................
!.............. menu starts here .......................................
!.......................................................................
!
 21   write(*,'(/a/)')'========= CHOOSE how to tag atoms'
      if(TagYes) then
         write(*,*) '     >> Current set of tagged atoms: '
         call do_nice_list(listat,ITI,list,len,N_lists,long_list)
         call print_long_char(list,len,long_list)
      end if
      write(*,*)
      write(*,'(2x,3a)') char(47), &
                 '========================================',char(92)
      write(*,'(a)')' | You can execute each Produce option many |'
      write(*,'(a)')' |  times until the final list is obtained  |'
      write(*,'(2x,3a)') char(92), &
                 '========================================',char(47)
      write(*,*)
      write(*,'(a)')'  N. Produce: by atomic numbers'
      write(*,'(a)')' Sp. Produce: by species'
      write(*,'(a)')' Si. Produce: inside the sphere'
      write(*,'(a)')' So. Produce: outside the sphere'
      write(*,'(a)')' Cr. Produce: by coordinates X,Y,Z intervals'
      write(*,'(a)')'  E. Empty the list; you can start again!'

!_____ show settings
      write(*,*) ' Co. Show atoms with current tagging'
      write(*,'(a)') &
      '-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,'(3(a,f10.5),a)') &
              ' Cp. The central point: (',cp(1),',',cp(2),',',cp(3),')'
      write(*,'(a,f10.5)')'  R. The sphere radius: ',Rad
      call interval(x1,x2,cha,chb)
      write(*,'(a)')'  X. X-interval:         ('//cha//','//chb//')'
      call interval(y1,y2,cha,chb)
      write(*,'(a)')'  Y. Y-interval:         ('//cha//','//chb//')'
      call interval(z1,z2,cha,chb)
      write(*,'(a)')'  Z. Z-interval:         ('//cha//','//chb//')'
      write(*,'(a)')'  Q. Quit with the empty list'
      write(*,'(a)')'  P. Exit: quit with the current list'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![N]...... choose atoms by numbers

      IF(cha2(l0:).eq.'N') THEN

 44      write(*,*) &
              'Specify atoms using space and/or comma to separate lists'
         write(*,*)'and a dash (without space) to indicate from/to'
         write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
         write(*,*)'Use the word [all] if all atoms need to be chosen.'
         read(*,'(a)') line ; write(8,'(a)') trim(line)
         call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
         if(iErr.ne.0) go to 44
         if(NumLin.eq.0) then
            go to 21
         else if(Numlin.eq.1 .and. line(LinPos(1):LinEnd(1)).eq.'all') then
            listat(1:ITI)=.true.
            call filter(listat,1,ITI)
         else 
!________________ produce the listat
            do i=1,NumLin
               i0=index(line(LinPos(i):LinEnd(i)),'-')
               if(i0.eq.0) then
                  read(line(LinPos(i):LinEnd(i)),*) i1
                  i2=i1
               else
                  read(line(LinPos(i):LinPos(i)+i0-2),*) i1
                  read(line(LinPos(i)+i0:LinEnd(i)),*) i2
               end if
               if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.L_ext) go to 44
               call filter(listat,i1,i2)
            end do
         end if
         TagYes=.true.

![Sp]...... choose atoms of the same species

      ELSE IF(cha2(l0:).eq.'Sp') THEN

         write(*,*) 'Choose the species [ALL atoms of this '// &
              'species will be selected]:'
         read(*,'(a)') cha2 ; write(8,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec=' '//cha2(l0:)
         else
            spec=cha2
         end if
         i=0
         do nat=1,ITI
            if(spec.eq.Labels(nat)) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.eq.0) then
            write(*,*)'ERROR: wrong species!'
         else
            write(*,*)'... Number of selected atoms = ',i
         end if
         if(i.gt.0) TagYes=.true.

![Si]...... choose atoms inside the sphere

      ELSE IF(cha2(l0:).eq.'Si') THEN

         i=0
         do nat=1,ITI
            d=sqrt( (TI(1,nat)-Cp(1))**2 + (TI(2,nat)-Cp(2))**2 + &
                 (TI(3,nat)-Cp(3))**2 )
            if(d.le.Rad) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

![So]...... choose atoms outside the sphere

      ELSE IF(cha2(l0:).eq.'So') THEN

         i=0
         do nat=1,ITI
            d=sqrt( (TI(1,nat)-Cp(1))**2 + (TI(2,nat)-Cp(2))**2 + &
                 (TI(3,nat)-Cp(3))**2 )
            if(d.gt.Rad) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

![Cr]...... choose atoms by coordinates

      ELSE IF(cha2(l0:).eq.'Cr') THEN

         i=0
         do nat=1,ITI
            if((TI(1,nat).gt.x1 .and. TI(1,nat).lt.x2) .and. &
                 (TI(2,nat).gt.y1 .and. TI(2,nat).lt.y2) .and. &
                    (TI(3,nat).gt.z1 .and. TI(3,nat).lt.z2) ) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

![E]...... empty the list

      ELSE IF(cha2(l0:).eq.'E') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         TagYes=.false.

![Co]...... show atoms with tagging

      ELSE IF(cha2(l0:).eq.'Co') THEN

         write(*,*)' #  Species               Position            Tag'
         do i=1,ITI
            ch=' '
            if(listat(i)) ch='Y'
            write(*,'(i5,x,a,4x,3(f10.5,x),2x,a)') &
                 i,Labels(i),(TI(j,i),j=1,3),ch
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![X]...... choose X interval

      ELSE IF(cha2(l0:).eq.'X') THEN

         write(*,*) &
              'Specify the interval of atomic coordinates: A < X < B.'
 1       write(*,*) &
        'Give the smallest (left) boundary of X (hit ENTER for -Infty):'
         call read_number_or_infty(x1,-1,iErr)
         if(iErr.ne.0) go to 1
 2       write(*,*) &
        'Give the largest (right) boundary of X (hit ENTER for Infty):'
         call read_number_or_infty(x2,1,iErr)
         if(iErr.ne.0) go to 2

![Y]...... choose Y interval

      ELSE IF(cha2(l0:).eq.'Y') THEN

         write(*,*) &
              'Specify the interval of atomic coordinates: A < Y < B.'
 3       write(*,*) &
        'Give the smallest (left) boundary of Y (hit ENTER for -Infty):'
         call read_number_or_infty(y1,-1,iErr)
         if(iErr.ne.0) go to 3
 4       write(*,*) &
        'Give the largest (right) boundary of Y (hit ENTER for Infty):'
         call read_number_or_infty(y2,1,iErr)
         if(iErr.ne.0) go to 4

![Z]...... choose Z interval

      ELSE IF(cha2(l0:).eq.'Z') THEN

         write(*,*) &
              'Specify the interval of atomic coordinates: A < Z < B.'
 5       write(*,*) &
        'Give the smallest (left) boundary of Z (hit ENTER for -Infty):'
         call read_number_or_infty(z1,-1,iErr)
         if(iErr.ne.0) go to 5
 6       write(*,*) &
        'Give the largest (right) boundary of Z (hit ENTER for Infty):'
         call read_number_or_infty(z2,1,iErr)
         if(iErr.ne.0) go to 6

![Cp]...... choose Central point

      ELSE IF(cha2(l0:).eq.'Cp') THEN

 7       write(*,*)'Specify the Central Point:'
         read(*,*,err=7) Cp ; write(8,*) Cp

![R]...... choose radius

      ELSE IF(cha2(l0:).eq.'R') THEN

 8       write(*,*)'Specify the radius of the sphere:'
            read(*,*,err=8) Rad ; write(8,*) Rad

![Q]...... quit and do nothing

      ELSE IF(cha2(l0:).eq.'Q') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         TagYes=.false.
         return

![P]...... exit with the current list

      ELSE IF(cha2(l0:).eq.'P') THEN
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine TTag

      subroutine interval(x1,x2,cha,chb)
      implicit none
!......................................................................
! creates interval (x1,x2) in the character form as: (cha,chb)
!......................................................................
!     implicit none
      real(8) :: x1,x2
      character :: cha*10,chb*10
      if(x1.le.-1.0e10) then
         cha='-Infinity '
      else
         write(cha,'(f10.5)') x1
      end if
      if(x2.ge. 1.0e10) then
         chb='+Infinity '
      else
         write(chb,'(f10.5)') x2
      end if
      end subroutine interval

      subroutine read_number_or_infty(a,icase,iErr)
!......................................................................
!     reads a number or replaces it with:
!  icase=-1:  -infinity
!  icase= 1:  +infinity
!......................................................................
      use real8
      implicit none
      character :: Line*20
!
      integer :: iErr,icase,i0
      real(8) :: a

      iErr=0
      if(icase.eq.-1) then
         write(*,*) 'Enter number or I for -Infinity:'
      else if(icase.eq.1) then
         write(*,*) 'Enter number or I for Infinity:'
      end if
      read(*,'(a)') line ; write(8,'(a)') trim(line)
      i0=index(line,'I')
      if(i0.ne.0) then
         if(icase.eq.-1) a=-1.0e10
         if(icase.eq. 1) a= 1.0e10
      else
         read(line,*,err=1) a
      end if
      return
 1    iErr=1
      end subroutine read_number_or_infty

      subroutine Tag_Am(NumLin,ITI,Err,Ndim,mchange)
!.......................................................................
! choose atoms for specifying new masses
!.......................................................................
      use real8
      use atom_info
      implicit none
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin
      character (LEN=LENG1) :: Line
      logical :: Err,mchange(N0LT)
!
      integer :: ITI,Ndim,i,i0,i1,i2,j,nt,iErr

 2    write(*,'(a)') &
           'Specify a range of atoms with a new mass. '
      write(*,'(a)')'Use dash (without space) to indicate from/to'
      write(*,'(a)')'within the same list, e.g.: 1-5,9 7-8,15 25.'
      write(*,'(a)') &
           'Press ENTER with no atom numbers for the default values'
      read(*,'(a)') line ; write(8,'(a)')  trim(line)
      call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
      if(iErr.ne.0) go to 2
      if(NumLin.eq.0) return
      Err=.false.
      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=2) i1
            i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=2) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=2) i2
         end if
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 2
         do nt=i1,i2
            do j=1,Ndim,3
               if(at_info(j).eq.nt) then
                  mchange(nt)=.true.
                  go to 11
               end if
            end do
            Err=.true.
            write(*,'(a,i5,a)') 'ERROR: atom ',nt, &
                 ' is fixed and thus cannot be chosen'
 11      end do
      end do
      return
      end subroutine Tag_Am


     subroutine TagCl(NumLin,ITI,listat,list,len,N_lists,long_list)
!.......................................................................
! analyses the Line with NumLin words (by LinPos and LinEnd), each word
! may contain either a number or two numbers separated by a dash, and
! compiles a list for tagging, namely, it sets:
!
!    listat(atoms in the list)     = .true.
!    listat(atoms not in the list) = .false.
!    list(1:len)  - contains a nicely written list of atoms
!.......................................................................
      use real8
      implicit none
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin
      character (LEN=LENG1) :: Line
      logical :: listat(*),long_list
      character(*) :: list
!
      integer :: i,iErr,ITI,len,N_lists,i0,i1,i2

!........... initialise the listat first
      listat(1:ITI)=.false.

!............ now nicely ask

 44   write(*,*) &
              'Specify atoms using space and/or comma to separate lists'
      write(*,*)'and a dash (without space) to indicate from/to'
      write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
      read(*,'(a)') line ; write(8,'(a)') trim(line)
      call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
      if(iErr.ne.0) go to 44
      if(NumLin.eq.0) then
         write(*,*)'WARNING! The tagging is disabled!' ; return
      end if

!............ produce the listat

      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=44) i1 ; i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=44) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=44) i2
         end if
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 44
         listat(i1:i2)=.true.
      end do

!__________ compose the nice list

      call do_nice_list(listat,ITI,list,len,N_lists,long_list)
      end subroutine TagCl

      subroutine TTagCl(TagYes,ITI,TI,Labels,listat,list,len,N_lists, &
           long_list)
!.......................................................................
! compiles a list for tagging, namely, it sets:
!
!    listat(atoms in the list)     = .true.
!    listat(atoms not in the list) = .false.
!    list(1:len)  - contains a nicely written list of atoms
!.......................................................................
! A number of options are offered in a little menu, including:
!   - by coordinates
!   - by numbers
!   - by species
! You can apply one option after another builging this way a complicated
! list.
!.......................................................................
! If asked by numbers, then it analyses the Line with NumLin words
! (by LinPos and LinEnd), each word may contain either a number or two
! numbers separated by a dash, and
!.......................................................................
! N_lists - the maximum allowed length of the character list (it is only
!           used for printing in the routine calling this one)
!.......................................................................
      use real8
      implicit none
      character (LEN=LENG1) :: Line
      integer :: LinEnd(LENG2),LinPos(LENG2),NumLin
      logical :: listat(*),TagYes,long_list
      character(*) :: list
      character :: cha*10,chb*10,cha2*2,Labels(*)*2,ch,spec*2
      real(8) :: TI(3,N0LT),Rad=1.0d0
      real(8),dimension(3) :: cp=(/0.0d0,0.0d0,0.0d0/)
!
      integer :: ITI,len,N_lists,l0,iErr,i,i0,i1,i2,j,nat
      real(8) :: x1,x2,y1,y2,z1,z2,d

!........... initialise the listat first
      listat(1:ITI)=.false.
      x1=-1.e10 ; x2=1.e10 ; y1=-1.e10 ; y2=1.e10 ; z1=-1.e10
      z2= 1.e10 ; TagYes=.false.
!
!.......................................................................
!.............. menu starts here .......................................
!.......................................................................
!
 21   write(*,'(/a/)')'========= CHOOSE how to tag atoms'
      if(TagYes) then
         write(*,*) '     >> Current set of tagged atoms: '
         call do_nice_list(listat,ITI,list,len,N_lists,long_list)
         call print_long_char(list,len,long_list)
      end if
      write(*,*)
      write(*,'(2x,3a)') char(47), &
                 '========================================',char(92)
      write(*,'(a)')' | You can execute each Produce option many |'
      write(*,'(a)')' |  times until the final list is obtained  |'
      write(*,'(2x,3a)') char(92), &
                 '========================================',char(47)
      write(*,*)
      write(*,'(a)')'  N. Produce: by atomic numbers'
      write(*,'(a)')' Sp. Produce: by species'
      write(*,'(a)')' Si. Produce: inside the sphere'
      write(*,'(a)')' So. Produce: outside the sphere'
      write(*,'(a)')' Cr. Produce: by coordinates X,Y,Z intervals'
      write(*,'(a)')'  E. Empty the list; you can start again!'

!_____ show settings
      write(*,*) ' Co. Show atoms with current tagging'
      write(*,'(a)') &
      '-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,'(3(a,f10.5),a)') &
              ' Cp. The central point: (',cp(1),',',cp(2),',',cp(3),')'
      write(*,'(a,f10.5)')'  R. The sphere radius: ',Rad
      call interval(x1,x2,cha,chb)
      write(*,'(a)')'  X. X-interval:         ('//cha//','//chb//')'
      call interval(y1,y2,cha,chb)
      write(*,'(a)')'  Y. Y-interval:         ('//cha//','//chb//')'
      call interval(z1,z2,cha,chb)
      write(*,'(a)')'  Z. Z-interval:         ('//cha//','//chb//')'
      write(*,'(a)')'  Q. Quit with the empty list'
      write(*,'(a)')'  P. Exit: quit with the current list'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![N]...... choose atoms by numbers

      IF(cha2(l0:).eq.'N') THEN

 44      write(*,*) &
              'Specify atoms using space and/or comma to separate lists'
         write(*,*)'and a dash (without space) to indicate from/to'
         write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
         read(*,'(a)') line ; write(8,'(a)') trim(line)
         call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
         if(iErr.ne.0) go to 44
         if(NumLin.eq.0) go to 21

!________________ produce the listat
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 44
            do j=i1,i2
               listat(j)=.true.
            end do
         end do
         TagYes=.true.

![Sp]...... choose atoms of the same species

      ELSE IF(cha2(l0:).eq.'Sp') THEN

         write(*,*) 'Choose the species [ALL atoms of this '// &
              'species will be selected]:'
         read(*,'(a)') cha2 ; write(8,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec=' '//cha2(l0:)
         else
            spec=cha2
         end if
         i=0
         do nat=1,ITI
            if(spec.eq.Labels(nat)) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.eq.0) then
            write(*,*)'ERROR: wrong species!'
         else
            write(*,*)'... Number of selected atoms = ',i
         end if
         if(i.gt.0) TagYes=.true.

![Si]...... choose atoms inside the sphere

      ELSE IF(cha2(l0:).eq.'Si') THEN

         i=0
         do nat=1,ITI
            d=sqrt( (TI(1,nat)-Cp(1))**2 + (TI(2,nat)-Cp(2))**2 + &
                 (TI(3,nat)-Cp(3))**2 )
            if(d.le.Rad) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

![So]...... choose atoms outside the sphere

      ELSE IF(cha2(l0:).eq.'So') THEN

         i=0
         do nat=1,ITI
            d=sqrt( (TI(1,nat)-Cp(1))**2 + (TI(2,nat)-Cp(2))**2 + &
                 (TI(3,nat)-Cp(3))**2 )
            if(d.gt.Rad) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

![Cr]...... choose atoms by coordinates

      ELSE IF(cha2(l0:).eq.'Cr') THEN

         i=0
         do nat=1,ITI
            if((TI(1,nat).gt.x1 .and. TI(1,nat).lt.x2) .and. &
                 (TI(2,nat).gt.y1 .and. TI(2,nat).lt.y2) .and. &
                    (TI(3,nat).gt.z1 .and. TI(3,nat).lt.z2) ) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

![E]...... empty the list

      ELSE IF(cha2(l0:).eq.'E') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         TagYes=.false.

![Co]...... show atoms with tagging

      ELSE IF(cha2(l0:).eq.'Co') THEN

         write(*,*)' #  Species               Position            Tag'
         do i=1,ITI
            ch=' '
            if(listat(i)) ch='Y'
            write(*,'(i5,x,a,4x,3(f10.5,x),2x,a)') &
                 i,Labels(i),(TI(j,i),j=1,3),ch
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![X]...... choose X interval

      ELSE IF(cha2(l0:).eq.'X') THEN

         write(*,*) &
              'Specify the interval of atomic coordinates: A < X < B.'
 1       write(*,*) &
        'Give the smallest (left) boundary of X (hit ENTER for -Infty):'
         call read_number_or_infty(x1,-1,iErr)
         if(iErr.ne.0) go to 1
 2       write(*,*) &
        'Give the largest (right) boundary of X (hit ENTER for Infty):'
         call read_number_or_infty(x2,1,iErr)
         if(iErr.ne.0) go to 2

![Y]...... choose Y interval

      ELSE IF(cha2(l0:).eq.'Y') THEN

         write(*,*) &
              'Specify the interval of atomic coordinates: A < Y < B.'
 3       write(*,*) &
        'Give the smallest (left) boundary of Y (hit ENTER for -Infty):'
         call read_number_or_infty(y1,-1,iErr)
         if(iErr.ne.0) go to 3
 4       write(*,*) &
        'Give the largest (right) boundary of Y (hit ENTER for Infty):'
         call read_number_or_infty(y2,1,iErr)
         if(iErr.ne.0) go to 4

![Z]...... choose Z interval

      ELSE IF(cha2(l0:).eq.'Z') THEN

         write(*,*) &
              'Specify the interval of atomic coordinates: A < Z < B.'
 5       write(*,*) &
        'Give the smallest (left) boundary of Z (hit ENTER for -Infty):'
         call read_number_or_infty(z1,-1,iErr)
         if(iErr.ne.0) go to 5
 6       write(*,*) &
        'Give the largest (right) boundary of Z (hit ENTER for Infty):'
         call read_number_or_infty(z2,1,iErr)
         if(iErr.ne.0) go to 6

![Cp]...... choose Central point

      ELSE IF(cha2(l0:).eq.'Cp') THEN

 7       write(*,*)'Specify the Central Point:'
         read(*,*,err=7) Cp ; write(8,*) Cp

![R]...... choose radius

      ELSE IF(cha2(l0:).eq.'R') THEN

 8       write(*,*)'Specify the radius of the sphere:'
            read(*,*,err=8) Rad ; write(8,*) Rad

![Q]...... quit and do nothing

      ELSE IF(cha2(l0:).eq.'Q') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         TagYes=.false.
         return

![P]...... exit with the current list

      ELSE IF(cha2(l0:).eq.'P') THEN
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine TTagCl
