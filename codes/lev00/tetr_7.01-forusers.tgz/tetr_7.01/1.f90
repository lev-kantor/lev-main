program test
  implicit none
  character*17 :: dir

  read(*,'(a)') dir
  write(*,'(a)') 'directory is : ['//trim(dir)//']'


  
end program test
