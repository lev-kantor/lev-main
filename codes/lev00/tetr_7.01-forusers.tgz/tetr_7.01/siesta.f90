module siesta
implicit none
! this memory is used for siesta and quickstep input files storage

! nlines - number of lines in the siesta input to be saved
!          (not relevant to tetr)
! lines()  - they are saved here ; uses nlines
! SystemLabel - system label for siesta run (read in from the
!               fdf file)
! isysl0 - 1st position in SystemLabel

!     common /siesta/ nlines,isysl0, &
!            lines, &
!            SystemLabel

      integer :: nlines,isysl0
      character :: lines(1000)*200,Systemlabel*50

!....... it is .true. if the SP2K geometry is read in for the first time;
!        .false. otherwise
      logical :: yes_lines
      
end module siesta
