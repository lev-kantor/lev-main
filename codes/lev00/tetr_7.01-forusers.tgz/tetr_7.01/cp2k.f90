module cp2k_attr
use tetr_param

  implicit none
!........... cp2k related stuff

  logical :: cp2k_ghost(N0KD),cp2k_sp_all(N0KD)
  character :: cp2k_basis_set(N0KD)*30,cp2k_potential(N0KD)*30,cp2k_element(N0KD)*3
  
end module cp2k_attr

