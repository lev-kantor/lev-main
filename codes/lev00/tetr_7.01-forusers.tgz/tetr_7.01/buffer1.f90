module buffer1
use tetr_param
  implicit none
!     common /buffer1/ AY,TI3,BY,ITI3, &
!          NspN3,Nsp3,Species3,relax_flag3
      character :: Species3(N0KD)*2,relax_flag3(3,N0LT)
      real(8) :: AY(3,3),TI3(3,N0LT),BY(3,3)
      integer ::  ITI3,NspN3(N0KD),Nsp3
      
!........... cp2k related stuff

      logical :: cp2k_ghost3(N0KD),cp2k_sp_all3(N0KD)
      character :: cp2k_basis_set3(N0KD)*30,cp2k_potential3(N0KD)*30, &
                    cp2k_element3(N0KD)*3
end module buffer1
