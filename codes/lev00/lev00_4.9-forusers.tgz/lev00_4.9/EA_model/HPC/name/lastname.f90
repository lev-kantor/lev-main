program name
  implicit none
!...........................................................
!  out of the list of names with identical beginning 
!  and end parts, identify the internal different part
!  (the number) using the first name in the list as a
! a reference, and select the name with the largest number.
!............................................................
  character*100,dimension(:),allocatable :: names 
  integer,dimension(:),allocatable :: ln
  character*100 :: line
  integer :: i,j,i1,i2,m2,jj
  logical :: beg
  
!.... read all names from the file names.dat  
  open(1,file='names.dat')
  i=0
  do
     read(1,'(a)',end=1) line
     i=i+1
  end do
1 rewind 1
  allocate(names(i),ln(i))
  do j=1,i
     read(1,'(a)') names(j)
     call right(names(j),100,ln(j))
     write(*,'(i3,x,i2,x,a)') j,ln(j),names(j)(ln(j):)
  end do
  close(1)

!.... identify the position of the number
  m2=0
  do j=1,i
     i1=index(names(j),'1_0_')
     i2=index(names(j),'.Log')
     write(*,'(3a)') names(j), ' ',names(j)(i1+4:i2-1)
     read(names(j)(i1+4:i2-1),*) i1
     if(i1.gt.m2) then
        m2=i1 ; jj=j
     end if
     write(*,*) i1,m2,jj
  end do
  write(*,*) names(jj)(ln(jj):)
  
!.... remove all other files
!  do j=1,i
!     if(j.ne.m2) call system('/bin/rm '//names(j)(ln(j):))
!  end do
!  write(*,'(a)') 'mv '//names(m2)(ln(m2):)//' KS-last.Log' 
!  call system('mv '//names(m2)(ln(m2):)//' KS-last.Log' )
  
end program name

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine right(char,len,len00)
  implicit none
  character*(*) :: char
  integer :: len,j,len00,i,jj
  
  do i=len,1,-1
     j=i
     if(char(i:i).ne.' ') go to 1
  end do
1 jj=len-j
  do i=j,1,-1
     char(jj+i:jj+i) = char(i:i)
  end do
  do i=1,jj
     char(i:i)=' '
  end do
  len00=jj+1
  return
end subroutine right
