program eff_at_current
!............................................................................  
!          Extraction of KS and overlap matrices and writing them into      !
!           separate files                                                  !
!............................................................................  
  implicit none
  integer :: i,j,k,i0,iargc,lh,i1,iErr,iCom
!  real*8 :: 
  character*100 :: line*100,name_ham*100
  integer :: LinEnd(100),LinPos(100),NumLin
  logical :: found
  
!..... get the names of the file from the command line

  i0=iargc()
  write(*,*) i0
  if(i0.eq.0) then
     write(*,*)'>>>> ERROR: incorrect usage. Check option -h <<<<'
     stop
  else
     call getarg(1,name_ham) ; write(*,'(a)') name_ham
     i1=index(name_ham,'-h')
     if(i1.ne.0) then
        write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>> USAGE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
        write(*,*)'    '
        write(*,*)'                curr name'
        write(*,*)'    '
        write(*,*)'    where:'
        write(*,*)'          name - file name with the KS and overlap  matrices'
        write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
        stop
     end if
     call right(name_ham,100,lh)
     write(*,*) '>>> KS+overlap matrices file <'//name_ham(lh:)//'>'
  end if

!....... determine the number of orbitals

  open(1,file=name_ham(lh:),status='old',err=1)
  write(*,*) 'opened '//name_ham(lh:)
  
  i=0 ; found=.false.
  do
     call CutStr(Line,NumLin,LinPos,LinEnd,1,0,iErr)
     if( index(Line(LinPos(1):LinEnd(1)),'OVERLAP').ne.0) then
        read(1,'(//)')
        call CutStr(Line,NumLin,LinPos,LinEnd,1,0,iErr)
        read(line(LinPos(1):LinEnd(1)),'(i5)') i
        write(*,*) i
        if(i.eq.1 .and. .not.found) then
           found=.true.
        else
           exit
        end if
     end if
  end do
  write(*,*) i
  close(1)

  stop
1 write(*,*)'ERROR: in opening '//name_ham(lh:)//' file'  
  
end program eff_at_current

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine right(char,len,len00)
  implicit none
  character*(*) :: char
  integer :: len,j,len00,i,jj
  
  do i=len,1,-1
     j=i
     if(char(i:i).ne.' ') go to 1
  end do
1 jj=len-j
  do i=j,1,-1
     char(jj+i:jj+i) = char(i:i)
  end do
  do i=1,jj
     char(i:i)=' '
  end do
  len00=jj+1
  return
end subroutine right

subroutine CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iCom,iErr)
  implicit none
!.................................................................
!....It reads the line from the file UNIT=NFIL as a string   .....
!.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
!.... substrings. Their number is NumLin, while starting and .....
!.... ending positions are LinPos and LinEnd.                .....
!.................................................................
! Up to 100 substrings is implied to be in the initial string Line.
!.................................................................
!  If NFIL=0 it is assumed that the string Line*80 exists and
!  must not be read from the external source, but must be taken
!  as an input from the parent program
!.................................................................
!  iErr=1 in the case of error input; oterwise iErr=0
!.................................................................
!  Commas are also interpreted as string division symbols
!  alongside spaces if iCom=1; not, if iCom=/=1.
!.................................................................
!  Equal signs are also interpreted as string division symbols
!  alongside spaces if iCom=2; not, if iCom=/=2.
!.................................................................
!
      character :: Line*100
      character :: cha
      integer :: LinEnd(100),LinPos(100),NumLin
!
      integer :: iErr,iCom,NFIL,i,i0,icase

      iErr=0
      if(NFIL.ne.0)  then
         call SkipL(NFIL,iErr)
         if(iErr.ne.0) go to 10
         read (NFIL,'(a)',err=10,end=10) Line
      end if
      NumLin=0 ; icase=0
!............ replace commas, if present, by spaces
      if(iCom.eq.1) then
         do i=1,100
            if(Line(i:i).eq.',') Line(i:i)=' '
         end do
      end if
!............ replace equal sign, if present, by spaces
      if(iCom.eq.2) then
         do i=1,100
            if(Line(i:i).eq.'=') Line(i:i)=' '
         end do
      end if
!............ Loop over all characters in the Line(1:200)............
      do 5 i=1,100
         i0=i
         cha=Line(i:i)
!________ if the 1st not blank character is found
         if(cha.ne.' '.and.cha.ne.'     '.and.icase.eq.0) then
            NumLin=NumLin+1
            if(NumLin.gt.100) go to 10
            LinPos(NumLin)=i
            icase=1
         end if
!_________ if the 1st blank character is found after the substring
         if(cha.eq.' '.and.icase.eq.1) then
            LinEnd(NumLin)=i-1
            icase=0
         end if
 5    end do
      if(icase.eq.1) LinEnd(NumLin)=100
      return
 10   iErr=1
      return
end subroutine CutStr

subroutine SkipL(NFIL,iErr)
      implicit none
!.......................................................................x
!...... Program skips all "empty" string containing comments, etc.......
!...... All lines, containing **,--,==,*-, ## annd -* symbols are.......
!...... recognized as the comments lines and are skipped. The    .......
!...... driver is set up at the beginning of the first "nonempty".......
!...... record                                                   .......
!.......................................................................
!  iErr=1 in the case of error input; oterwise iErr=0
!.................................................................
!
      character :: Line*100
      integer,parameter :: nComm=6
      character*2,dimension(nComm) :: &
           Comm=(/'*-','-*','--','==','**','##'/)
!
      integer :: i,NFIL,iErr,j

!.......... read the current line from the driver NFIL
1     read (NFIL,'(a)',err=10,end=10) Line
!_________ analyze Line if it is empty
      if(Line(1:1).eq.CHAR(0)) go to 1
      if(Line(1:1).eq."") go to 1
!_________ analyze Line if it is filled by simple blanks
      do i=1,100
         if(Line(i:i).ne.CHAR(0).and.Line(i:i).ne.' ') go to 2
      end do
      go to 1
!_________ analyze Line for the comment symbols; in the case if any
!          one from the list Comm() was found at the beginning of the Line,
!          it reads the next line
 2    do j=1,100
         if(Line(j:j).ne.' ') then
            do i=1,nComm
               if(INDEX(Line(j:j+1),Comm(i)).ne.0) go to 1
            end do
            iErr=0 ; go to 5
         end if
      end do
!_________ return to the beginning of the "nonempty" line (record)
 5    backspace NFIL
      return
!......... in the case of an error
10    iErr=1
end subroutine SkipL
