real*8 function gamma_s(w)
  use surface
  use tools
  
!..... level width function  
  implicit none
  real*8 :: w,s
  integer :: k,m

  m=n_of_AOs-1
  s=0.0d0
  do k=1,n_of_states
     if(k.ne.i_He) then
        s=s+Dk(k)*Dk(k)*deltaf(w-eigval(k))
     end if
  end do
  gamma_s=s*2*pi
  
end function gamma_s

real*8 function gamma_t(w)
  use tip
  use tools
  
!..... level width function  
  implicit none
  real*8 :: w,s
  integer :: k,m

  m=n_of_AOs_t-1
  s=0.0d0
  do k=1,n_of_states_t
     if(k.ne.i_He_t) then
        s=s+Dk_t(k)*Dk_t(k)*deltaf(w-eigval_t(k))
     end if
  end do
  gamma_t=s*2*pi
  
end function gamma_t

real*8 function re_se(w)
  use surface
  use tools
!....... real part of the self-energy: calculated by eliminating the singularity  
  implicit none
  real*8 :: w,s,ww,deriv,re,gamma_s
  integer :: i

  s=0.0d0
  do i=0,nw
     ww=W1+i*dw
     if(abs(w-ww).lt.dw) then
        deriv = (gamma_s(w+0.01)-gamma_s(w))/0.01
        s=s+deriv
     else
        s=s+(gamma_s(ww)-gamma_s(w))/(ww-w)
     end if
  end do
  s=s*dw
  re = gamma_s(w)*log(abs((W2+0.1-w)/(W1-0.1-w)))
  re_se = -(s + re)/(2*pi)
end function re_se

real*8 function re_se_tip(w)
  use tip
  use tools
!....... real part of the self-energy: calculated by eliminating the singularity  
  implicit none
  real*8 :: w,s,ww,deriv,re,gamma_t
  integer :: i

  s=0.0d0
  do i=0,nwt
     ww=W1t+i*dwt
     if(abs(w-ww).lt.dwt) then
        deriv = (gamma_t(w+0.01)-gamma_t(w))/0.01
        s=s+deriv
     else
        s=s+(gamma_t(ww)-gamma_t(w))/(ww-w)
     end if
  end do
  s=s*dwt
  re = gamma_t(w)*log(abs((W2t+0.1-w)/(W1t-0.1-w)))
  re_se_tip = -(s + re)/(2*pi)
end function re_se_tip

real*8 function transmission(w,V)
!..... for the current
!  V - voltage (eV)
!.... transmission function  
  use surface
  use tip
  use tools
  implicit none
  real*8 :: w,V,a,b,g,re_se,gamma_s,gamma_t,gt,re_se_tip

  g=gamma_s(w+V) ; gt=gamma_t(w)
  a=w-E_at-re_se(w+V)-re_se_tip(w)
  b=gt + g
  transmission= (2.0/pi) * gt * g /( a*a+0.25*b*b )
  
end function transmission

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

real*8 function current(V)
  use surface
  use tip
  use tools
  
!..... current
!  V  - voltage (eV)
  implicit none
  real*8 :: V,s,eps=0.001,w,ff,f1,f2,transmission
  integer :: i
  logical :: first

  first=.false.
  s=0.0d0
  do i=0,nw
     w=W1m+i*dwm
     ff=fermi(w)-fermi(w+V)
     if(abs(ff).gt.eps) then
        if(.not.first) then
           first=.true.
           f1=w
        end if
        s=s+ff*transmission(w,V)
    else
        if(first) then
           f2=w
           exit
        end if
     end if
  end do
  current=s*dwm
  write(9,*) 'V = ',V,' energies = [ ',f1,',',f2,' ]'
end function current
