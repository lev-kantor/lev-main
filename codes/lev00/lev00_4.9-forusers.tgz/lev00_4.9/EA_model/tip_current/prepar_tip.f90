module tip
  implicit none
  real*8,dimension(:),allocatable :: eigval_t,Dk_t
!..... cp2k parameters  (Tip)
!  n_of_states - number of state available from cp2k
!  n_of_AOs - the number of atomic basis in cp2k calculation
!  i_He - the state to be excluded as related to the Effective Atom
  integer :: n_of_states_t,n_of_AOs_t,i_He_t
!..... characterising the energy levels from cp23k calculation  
!  W1,W2 - minimum and maximum energies of KS states
  real*8 :: W1t,W2t,dwt
  
CONTAINS

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine preparation_tip(name_ham,lh,name_eig,le)
  implicit none
  real*8,dimension(:,:),allocatable :: eigvect
  real*8,dimension(:),allocatable :: Ham

!..... names of cp2k output data
  character :: name_ham*100,name_eig*100
  integer :: lh,le
  logical :: err

!...... determine dimensions of the job

  call read_eig_dim_tip(name_eig,le,err)
  write(9,*) 'n_of_AOs_t= ',n_of_AOs_t 
  write(9,*) 'n_of_states_t =',n_of_states_t
  if(err) then
     write(9,*)  '===> Reading Eigenvectors/Values error'
     stop
  end if
  
!...... cp2k dimensions
  
  allocate(eigval_t(n_of_states_t),eigvect(n_of_AOs_t,n_of_states_t))
  
!.... reading the Hamiltonian matrix  
!.... only need the last row of the Hamilton matrix assuming the He atom comes last in the list

  allocate(Ham(n_of_AOs_t))
  call read_Ham_tip(name_ham,lh,err,Ham)
  if(err) then
     write(9,*)  '===> Reading Ham error'
     stop
  end if
  
!.... reading the eigenvectors/values; determine the minimum and the maximum energies.
!.... Determine which state to be excluded as having the largest He contribution

  call read_eig_tip(name_eig,le,err,eigvect)
  if(err) then
     write(9,*) '===> Reading eigenvectors/values error'
     stop 
  end if
!.... calcualtion of the vector Dk

  allocate(Dk_t(n_of_states_t))
  call make_Tk_tip(eigvect,Ham)
  deallocate(eigvect,Ham)

end subroutine preparation_tip

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  
subroutine read_Ham_tip(name,ln,err,Ham)
!.... reading the Hamiltonian matrix  
!.... only need the last row of the Hamilton matrix assuming the He atom comes last in the list
  implicit none
  character :: name*100
  integer :: ln,k1,k2,i,j
  real*8 :: a,Ham(n_of_AOs_t)
  logical :: err

  write(9,*) name(ln:)//'_tip'
  err=.false.
  open(1,file=name(ln:)//'_tip',status='old',err=1)
  k1=1
  do
     k2=k1+3 ; if(k2.gt.n_of_AOs_t) k2=n_of_AOs_t
     do i=1,n_of_AOs_t
        if(i.lt.n_of_AOs_t) then
           read(1,*,err=1) (a,j=k1,k2)
        else
           read(1,*,err=1) (Ham(j),j=k1,k2)
        end if
     end do
     if(k2.eq.n_of_AOs_t) exit
     k1=k2+1
  end do
  close (1)
  write(9,*) '>>> File ',name(ln:),'_tip read in successfully!'
  Ham=Ham*27.21
  return

1 write(9,*)'ERROR! The file '//name(ln:)//'_tip is not found or bad!'
  err=.true.
end subroutine read_Ham_tip

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine read_eig_dim_tip(name,ln,err)
!.... determine N_of_AOs,n_of_states
  implicit none
  character :: name*100,line*100
  integer :: ln,i,j,ios
  logical :: err
  real*8 :: a

!________________ determine n_of_AOs  

  err=.false.
  open(1,file=name(ln:)//'_tip',status='old',err=1)
  write(9,*) 'opened '//name(ln:)//'_tip'
  read(1,'(/)')
  i=0
  do 
     read(1,'(a)') line
     if(line(1:1).eq."") exit
     read(line,*) a
     i=i+1
  end do
  n_of_AOs_t=i

!________________ determine n_of_states
  rewind(1)

  i=0
  do
     read(1,*,IOSTAT=ios) a
     if(ios.ne.0) exit
     read(1,*) 
     do j=1,n_of_AOs_t
        read(1,*,err=1) a
     end do
     read(1,*) 
     i=i+1
  end do
  n_of_states_t=i
  close(1)
  return

1 write(9,*)'ERROR! The file '//name(ln:)//'_tip is not found or bad!'
  err=.true.
end subroutine read_eig_dim_tip

subroutine read_eig_tip(name,ln,err,eigvect)
  use tools
!.... reading the eigenvectors/values; determine the minimum and the maximum energies.
!.... Determine which state to be excluded as having the largest He contribution
  implicit none
  character :: name*100
  integer :: ln,i,j
  real*8 :: He_max,eigvect(n_of_AOs_t,n_of_states_t)
  logical :: err

  write(9,*) name(ln:)//'_tip'
  err=.false.
  open(1,file=name(ln:)//'_tip',status='old',err=1)

  W1t=1.0E10 ; W2t=-1.0E10 ;  He_max=0.0
  do i=1,n_of_states_t
     read(1,*,err=1) eigval_t(i)
     eigval_t(i)= eigval_t(i)*27.21
     if(eigval_t(i).gt. W2t) W2t=eigval_t(i)
     if(eigval_t(i).lt. W1t) W1t=eigval_t(i)

     do j=1,n_of_AOs_t
        read(1,*,err=1) eigvect(j,i)
     end do
     if(abs(eigvect(n_of_AOs_t,i)).gt.He_max) then
        He_max=abs(eigvect(n_of_AOs_t,i))
        i_He_t=i
     end if
  end do
  close(1)
  write(9,*)'W1t = ',W1t,' W2t = ',W2t
  dwt=(W2t-W1t)/nwt
  write(9,*)'The state ',i_He_t,' has to be EXCLUDED: He coeff = ',eigvect(n_of_AOs_t,i_He_t)
  write(9,*) '>>> File ',name(ln:),'_tip read in successfully!'
  return

1 write(9,*)'ERROR! The file '//name(ln:)//'_tip is not found or bad!'
  err=.true.
end subroutine read_eig_tip

subroutine make_Tk_tip(eigvect,Ham)
  implicit none
  integer :: k,i
  real*8 :: s,eigvect(n_of_AOs_t,n_of_states_t),Ham(n_of_AOs_t)
!  write(9,*)'.......Dk...........'
  do k=1,n_of_states_t
     s=0.0d0
     do i=1,n_of_AOs_t-1
        s=s+eigvect(i,k)*Ham(i)
     end do
     Dk_t(k)=s
!     write(9,*) k,eigval(k),Dk(k),Dk(k)*Dk(k)
  end do
end subroutine make_Tk_tip


end module tip


  
