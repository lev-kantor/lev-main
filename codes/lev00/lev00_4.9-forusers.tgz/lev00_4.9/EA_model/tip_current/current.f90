program eff_at_current
!............................................................................  
!                                                                           !
!          Calculation of the current using the Effective Atom model        !
!                                                                           !
! [Essential input is in input.dat]                                         !
!............................................................................  
  use surface
  use tip
  use tools
  implicit none
  integer :: i0,iargc,lh,le,i,i1
  real*8 :: V,w,re_se,gamma_s,current,transmission,gamma_t,re_se_tip
  character*100 :: name_ham,name_eig,Volt,name_verb
  logical :: verb
  
!..... get the names of the files from the command line

  verb=.false.
  i0=iargc()
  if(i0.eq.0) then
     write(*,*)'>>>> ERROR: incorrect usage. Check option -h <<<<'
     stop
  else
     call getarg(1,name_ham)
     i1=index(name_ham,'-h')
     if(i1.ne.0) then
        write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>> USAGE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
        write(*,*)'    '
        write(*,*)'                curr name1 name2 Vol [-v]'
        write(*,*)'    '
        write(*,*)'    where:'
        write(*,*)'          name1 - file name with the Hamiltonian matrix (a.u.)'
        write(*,*)'          name2 - file name with eigenvectors/values (a.u.)'
        write(*,*)'            Vol - the value of the voltage (Volt) '
        write(*,*)'             -v - verbose run (if present) [optional]'
        write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
        stop
     end if
     call right(name_ham,100,lh)
     write(9,*) '>>> Hamiltonian matrix: file <'//name_ham(lh:)//'>'
     if(i0.ne.3 .and. i0.ne.4) then
        write(*,*)'>>>> ERROR: incorrect usage. Check option -h <<<<'
        stop
     end if
     call getarg(2,name_eig)
     call right(name_eig,100,le)
     write(9,*) '>>> Eigenvalues/vector: file <'//name_eig(le:)//'>'
     call getarg(3,Volt)
     read(Volt,*,err=1) V
     write(9,*) '>>> Voltage = ',V,' Volts'
     if(i0.eq.4) then
        call getarg(4,name_verb)
        i1=index(name_verb,'-v')
        if(i1.ne.0) verb=.true.
     end if
  end if
  if(verb) then
     write(9,*)'>>> verbose run  = TRUE '
  else 
     write(9,*)'>>> verbose run = FALSE'
  end if

!...... input parametes
  call input()
  
!...... preparation of the local DOS and Dk  
  call preparation_surface(name_ham,lh,name_eig,le)
  call preparation_tip(name_ham,lh,name_eig,le)

!...... plot the current  

!  open(1,file='j.dat')
!  do i=0,10
!     V=i*0.2
!     write(1,*) V,current(V)
!  end do
!  close(1)

  
  W1m=min(W1,W1t) ; W2m=max(W2,W2t) ; dwm=(W2m-W1m)/nw
  write(9,*)'... combined w-interval = [ ',W1m,',',W2m,' ], step = ',dwm
!  write(*,*) 'dw= ',dw
  write(*,*) current(V)

!.............................................................
!............... plot important functions ....................  
!.............................................................

  if(.not.verb) stop

!.... plot the level width function Gam(w); dw - the w step; delta - for Lorenzian

  open(1,file='gamma.dat')
  do i=0,nw
     w=W1m+i*dwm
     write(1,*) w,gamma_s(w+V),gamma_s(w),gamma_t(w+V),gamma_t(w)
  end do
  close(1)

!_______ plotting Re of self-energy

  open(1,file='re_se.dat')
  do i=0,nw
     w=W1m+i*dwm
     write(1,*) w,re_se(w+V),re_se(w),re_se_tip(w+V),re_se_tip(w)
  end do
  close(1)
  
!_______ plotting transmission
  
  open(1,file='trsms.dat')
  do i=0,nw
     w=W1m+i*dwm
     write(1,*) w,transmission(w,V)
  end do
  close(1)

  stop
1 write(9,*)'ERROR in reading V from the command line'  
  
end program eff_at_current

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine right(char,len,len00)
  implicit none
  character*(*) :: char
  integer :: len,j,len00,i,jj
  
  do i=len,1,-1
     j=i
     if(char(i:i).ne.' ') go to 1
  end do
1 jj=len-j
  do i=j,1,-1
     char(jj+i:jj+i) = char(i:i)
  end do
  do i=1,jj
     char(i:i)=' '
  end do
  len00=jj+1
  return
end subroutine right

