module tools
  implicit none
  real*8 :: pi=3.14159,kB=8.61733D-5
!..... parameters of the effective atom
!  Gamma_R - gamma for the tip (right lead)
!  E_at - energy level of the effective atom (eV)
!  T - temperature (K)
!  mu - chemical potential (Fermi energy) (eV)
  real*8 :: Gamma_R,E_at,T,mu,delta
!  nw - the number of omega values in the Gamma(w) function
  integer :: nw,nwt
  real*8 :: W1m,W2m,dwm

CONTAINS

real*8 function deltaf(x)
  implicit none
  real*8 :: x
  deltaf=delta/((delta*delta+x*x)*pi)
end function deltaf

real*8 function fermi(w)
!....... Fermi function at energy w (in eV)
!  kB - Boltzmann's constant (eV/K)
  implicit none
  real*8 :: w,beta

  beta=1.0d0/(kB*T)
  fermi=1.0d0/(exp(beta*(w-mu))+1.0d0)
end function fermi

subroutine input()
  implicit none
  open(1,file='input.dat',status='old',err=1)
!.... sp2k dimensions
  read(1,*,err=1) nw ; nwt=nw
!.... parameters: tip's gamma and effective atom energy (eV)
  read(1,*,err=1) Gamma_R,E_at
  read(1,*,err=1) T
!... chemnical potential: from a.u. (cp2k) to eV  
  read(1,*,err=1) mu ; mu=mu*27.21
  read(1,*,err=1) delta
  close(1)
  return
1 write(9,*)'ERROR: file <input.dat> not found or bad!'
  stop 'in input()'
end subroutine input

end module tools
