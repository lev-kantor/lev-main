subroutine cp2k_dens(grid,charge,spin,iErr)
!..............................................................
!    read density from name=cp2k_cube_name file of cp2k
!..............................................................
!    spin = .false. - total charge
!         = .true.  - spin density
!..............................................................
use param
use atoms
use code
implicit none
real*8,parameter :: A_au=1.889725989,au_A=1.0/A_au
real*8,parameter :: tiny=0.01
real*8 GRID(NGX,NGY,NGZ),DIR(3,3)
real*8 charge,factor,VOL,REC(3,3)
logical spin,cont
integer iErr,i,j,ijk,j0,iz,iy,ix,NIONS_,NGX_,NGY_,NGZ_,nat
real*8,dimension(:),allocatable :: dens
character name*100,answer

   if(spin) then
      write(*,*)'======================================================'
      write(*,*)'=========== CP2K files in this directory =============' 
      write(*,*)'======================================================'
      call system('ls *-SPIN_DENSITY-*.cube')
      Write(*,*)'======================================================'
      write(*,*)' Give the name of the SPIN DENSITY file:'
      read(*,'(a)') name 
      open(19,file=trim(name),form='formatted',status='old',err=101)
   else
      open(19,file=trim(cp2k_cube_name),err=100)
   end if
!
!.......... skipping stuff and checking
!     VOL - volume (in a.u.) of the individual grid cell
!     VOL*NPLWV*au_A**3=VOLC
!
   read(19,*) ; read(19,*)
   read(19,*) NIONS_ ; if(NIONS_.ne.NIONS) go to 100
   Read(19,*) NGX_,DIR(1,1),DIR(1,2),DIR(1,3)
   read(19,*) NGY_,DIR(2,1),DIR(2,2),DIR(2,3)
   read(19,*) NGZ_,DIR(3,1),DIR(3,2),DIR(3,3)
   write(*,'(3(f10.5,x))') DIR(1,1:3),DIR(2,1:3),DIR(3,1:3)
   if(NGX.ne.NGX_ .or. NGY.ne.NGY_ .or. NGZ.ne.NGZ_) go to 100
   DIR(1,:)=NGX*DIR(1,:) ;  DIR(2,:)=NGY*DIR(2,:) ;  DIR(3,:)=NGZ*DIR(3,:)

!   call bastr(DIR,REC,VOL,0) ; write(*,*) 'cube VOL = ',VOL,' a.u.'
!   write(*,*) 'input VOLC = ',VOLC*A_au**3,' a.u.'

   DIR=DIR*au_A
   write(*,'(a)')'..........in the density .........|........from input...............'
   do j=1,3
      write(*,'(3(f10.5,x),a,3(f10.5,x))') (DIR(j,i), i=1,3),' | ',(DIRC(j,i), i=1,3)
   end do
   cont=.true.
   do i=1,3
      do j=1,3
         if(abs(DIRC(i,j)-DIR(i,j)).gt.tiny) then
            write(*,*) 'WARNING! Mismatch of lattice vectors!'
            write(*,'(2i2,3(x,e12.6))') i,j,DIRC(i,j),DIR(i,j),abs(DIRC(i,j)-DIR(i,j))
            cont=.false.
         end if
      end do
   end do
   if(.not.cont) then
      write(*,*)'... CONTINUE (y/n)'
      read(*,'(a)') answer
      if(answer.eq.'N' .or. answer.eq.'n') go to 100 
   end if

!........... skipping atomic positions (not checking)
   do nat=1,NIONS
      read(19,*)
   end do
!
!........... reading the cube file of the density
!
   allocate(dens(NGZ))
   factor=VOLC*A_au**3 ; charge=0.0 ; ijk=0 ; j0=NPLWV/10

!   call bastr(DIR,REC,VOL,0)
!   factor=VOL*A_au**3 ; charge=0.0 ; ijk=0 ; j0=NPLWV/10

   do ix=1,NGX
      do iy=1,NGY
         ijk=ijk+NGZ
         read(19,*,err=100,end=100) (dens(iz),iz=1,NGZ)
         do iz=1,NGZ
            grid(ix,iy,iz)=dens(iz)*factor
            charge=charge+grid(ix,iy,iz)
         end do
         if(ijk/j0*j0.eq.ijk) &
              write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
      end do
   end do
   write(*,*)'Done!'
   write(*,'(a,e12.6)')'The charge is = ',charge/NPLWV
   go to 300
!
!.......errors
 100  write(*,*)'FATAL! File '//trim(cp2k_cube_name)//' does not exist, bad or wrong!'
      iErr=1 ; go to 300
 101  write(*,*)'FATAL! File '//trim(name)//' does not exist, bad or wrong!'
!
!......... finish
300   deallocate(dens)
      return
end subroutine cp2k_dens

subroutine cp2k_dens_manip(unit1,unit2,unit3,c1,c2, &
         filenA,filenB,filen,totdensA,totdensB,totdens,NPLWV,Merge,iErr)
!.........................................................................
!    reading density from unit1, unit2 of CP2K and
!    manipulaiting into:
!                         density=c1*den1+c2*den2
!.........................................................................
! If Merge=.True., then two densities merge with each other, including
! atomic positions. The latter are sorted as required by TETR algorithms.
!.........................................................................
!use param
use atoms
use code
implicit none
real*8,parameter :: tiny=0.001
real*8,parameter :: A_au=1.889725989,au_A=1.0/A_au
integer unit1,unit2,unit3,iErr,i,j,NGX1,NGY1,NGZ1,NGX2,NGY2,NGZ2
integer j0,ijk,iz,iy,ix,NPLWV,NIONS1,NIONS2,nat,sp1,NIONS3
real*8 DIR1(3,3),DIR2(3,3),c1,c2,REC1(3,3)
real*8,dimension(:),allocatable :: dens
real*8,dimension(:,:),allocatable :: TI1,TI2,TI3
integer,dimension(:),allocatable :: men1,men2,men3
real  ,dimension(:),allocatable :: dens1,dens2
logical,dimension(:),allocatable :: tag
real*8 totdensA,totdensB,totdens,factor,dummy
character filenA*100,filenB*100,filen*101
logical formA, formB, alloc,al1,al2,Merge

      al1=.false. ; al2=.false. ; alloc=.false.
!................. open A-density file

      write(*,*) 'Trying reading A-density '// trim(filenA)//' as FORMATTED ...'
      open(unit1,file=trim(filenA),status='old',form='formatted',err=100)
      read(unit1,*,err=100) ; read(unit1,*,err=100)
      read(unit1,*,err=100) NIONS1 
      read(unit1,*,err=100) NGX1,(DIR1(1,j),j=1,3)
      read(unit1,*,err=100) NGY1,(DIR1(2,j),j=1,3) 
      read(unit1,*,err=100) NGZ1,(DIR1(3,j),j=1,3) 
      call bastr(DIR1,REC1,VOLC,0) ; VOLC=VOLC*NGX1*NGY1*NGZ1*au_A**3
!      write(*,*)'VOLC=',VOLC
!____________ read atomic positions
      allocate(TI1(3,NIONS1)) ; allocate(men1(NIONS1)) ; al1=.true.
      do nat=1,NIONS1
         read(unit1,*,err=100) men1(nat),dummy,TI1(1:3,nat)
      end do
      formA=.true.
      
!................. open B-density file

      write(*,*) 'Trying reading B-density '// trim(filenB)//' as FORMATTED ...'
      open(unit2,file=trim(filenB),status='old',form='formatted',err=101)
      read(unit2,*,err=101) ; read(unit2,*,err=101)
      read(unit2,*,err=101) NIONS2 
      read(unit2,*,err=101) NGX2,(DIR2(1,j),j=1,3) 
      read(unit2,*,err=101) NGY2,(DIR2(2,j),j=1,3)
      read(unit2,*,err=101) NGZ2,(DIR2(3,j),j=1,3) 
!____________ skip atomic positions: may not necessarily be the same!
      allocate(TI2(3,NIONS2)) ; allocate(men2(NIONS2)) ; al2=.true.
      do nat=1,NIONS2
         read(unit2,*,err=101) men2(nat),dummy,TI2(1:3,nat)
      end do
      formB=.true.

!................. open the final file as formatted

      write(*,*)'Writing density to '//trim(filen)//' as FORMATTED ...'
      open(unit3,file=trim(filen),status='unknown',form='formatted',err=102)

!................. checking lattice vectors and the grid

!__________ checking lattice vectors

      do i=1,3
         do j=1,3
            if(abs(DIR2(i,j)-DIR1(i,j)).gt.tiny) then
               write(*,*)'ERROR: lattice vectors check NOT passed!'
               iErr=2 ; go to 200
            end if
         end do
      end do
      write(*,*)'... Lattice vectors: check passed!'

!_____________checking grid

      write(*,'(a,3(i5,x))')  '(A) ... found grid: ',NGX1,NGY1,NGZ1
      write(*,'(a,3(i5,x))')  '(B) ... found grid: ',NGX2,NGY2,NGZ2
      if(NGX2.ne.NGX1 .or.NGY2.ne.NGY1 .or.NGZ2.ne.NGZ1) then
         write(*,*)'ERROR: grid check NOT passed!'
         iErr=2 ; go to 200
      else
         write(*,*)'... Grid: check passed!'
         NPLWV=NGX1*NGY1*NGZ1
      end if

!................. if the densities are merged, we need to merge atomic positions;
!  we do NOT check for equivalent atoms assuming they are different. We also assume 
!  that in each file the atoms have already been ordered by species (e.g. by TETR).
!
      if(Merge) then
         NIONS3=NIONS1+NIONS2
         allocate(tag(NIONS2)) ; tag=.false.
         allocate(TI3(3,NIONS3)) ; allocate(men3(NIONS3)) 
         nat=0 ; sp1=men1(1)
         do i=1,NIONS1
            if(men1(i).eq.sp1) then
               call append_atom(i,TI1,NIONS1,men1,nat,TI3,NIONS3,men3)
            else
               do j=1,NIONS2
                  if(men2(j).eq.sp1) then
                     call append_atom(j,TI2,NIONS2,men2,nat,TI3,NIONS3,men3)
                     tag(j)=.true.
                  end if
               end do
               sp1=men1(i)
               call append_atom(i,TI1,NIONS1,men1,nat,TI3,NIONS3,men3)
            end if
         end do
!___________________ append to the last species from the 1st set (if any in the 2nd)
         do j=1,NIONS2
            if(men2(j).eq.sp1) then
               call append_atom(j,TI2,NIONS2,men2,nat,TI3,NIONS3,men3)
               tag(j)=.true.
            end if
         end do
!___________________ append other species from the 2nd set not present in the 1st (if any)
         do j=1,NIONS2
            if(.not.tag(j)) then
               call append_atom(j,TI2,NIONS2,men2,nat,TI3,NIONS3,men3)
            end if
         end do
!____________________ finish
         deallocate(TI1) ; deallocate(men1)
         allocate(TI1(3,NIONS3)) ; allocate(men1(NIONS3)) ; al1=.true.
         NIONS1=NIONS3 ; Ti1=Ti3 ; men1 = men3
         deallocate(TI3) ; deallocate(men3) ; deallocate(tag)
      end if

!................. start READING/WRITING

      write(unit3,'(a)')'-Quickstep+LEV00-'
      write(unit3,'(a)')' ELECTRON DENSITY'
      write(unit3,'(i10,a)') NIONS1,'   0.0 0.0 0.0'
      write(unit3,'(i10,3(x,f10.5))') NGX1,(DIR1(1,j),j=1,3)
      write(unit3,'(i10,3(x,f10.5))') NGY1,(DIR1(2,j),j=1,3)
      write(unit3,'(i10,3(x,f10.5))') NGZ1,(DIR1(3,j),j=1,3)
      dummy=0.0
      do nat=1,NIONS1
         write(unit3,'(i10,4(x,f10.5))') men1(nat),dummy,TI1(1:3,nat)
      end do

!____________allocate for reading density _______________________
      allocate(dens(NGZ1)) ; allocate(dens1(NGZ1)) ; allocate(dens2(NGZ1))
      alloc=.true. 
!
      factor=VOLC*A_au**3
      Totdensa = 0.0 ; totdensB = 0.0 ; totdens  = 0.0 ; ijk=0 ; j0=NPLWV/10

      do ix=1,NGX1
         do iy=1,NGY1
            ijk=ijk+NGZ1
            read(unit1,*,err=100,end=100) (dens1(iz),iz=1,NGZ1)
            read(unit2,*,err=101,end=101) (dens2(iz),iz=1,NGZ1)
            do iz=1,NGZ1
               dens(iz)=c1*dens1(iz)+c2*dens2(iz)
               totdensA=totdensA+dens1(iz)*factor
               totdensB=totdensB+dens2(iz)*factor
               totdens =totdens + dens(iz)*factor
            end do
            write(unit3,'(6(e13.5))') (dens(iz),iz=1,NGZ1)
            if(ijk/j0*j0.eq.ijk) &
                 write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
         end do
      end do
      write(*,*)'Done!'
      go to 200
!
!.......errors
 100  write(*,*)'FATAL! File '//trim(filenA)//' not found or bad!'
      iErr=1
      go to 200
 101  write(*,*)'FATAL! File '//trim(filenB)//' not found or bad!'
      iErr=1
      go to 200
 102  write(*,*)'FATAL! File '//trim(filen)//' cannlot be opened!'
      iErr=1

!............ finish

200   if(alloc) then
         deallocate(dens) ; deallocate(dens1) ; deallocate(dens2)
      end if
      if(al1) then
         deallocate(TI1) ; deallocate(men1)
      end if
      if(al2) then
         deallocate(TI2) ; deallocate(men2)
      end if
end subroutine cp2k_dens_manip

subroutine append_atom(j,TI,NIONS,men,nat,TI3,NIONS3,men3)
implicit none
integer nat,NIONS,NIONS3,men(NIONS),men3(NIONS3),j
real*8 TI(3,NIONS),TI3(3,NIONS3)
   nat=nat+1
   TI3(1:3,nat)=TI(1:3,j) ; men3(nat)=men(j) 
!   write(*,'(a,2i5,3(x,f10.5))') 'Append: ',nat, men3(nat),TI3(1:3,nat)
end subroutine append_atom

subroutine check_dens_cp2k(unit1,filen,NGX1,NGY1,NGZ1,Tot,iErr)
!..............................................................
!    read density from name=cp2k_cube_name file of CP2K
!..............................................................
implicit none
real*8,parameter :: A_au=1.889725989,au_A=1.0/A_au
real*8,parameter :: tiny=0.001
real*8 DIR(3,3)
real*8 factor,VOLC,RECC(3,3),Tot
logical alloc
integer iErr,j,ijk,j0,iz,iy,ix,NIONS1,NGX1,NGY1,NGZ1,nat,unit1
real*8,dimension(:),allocatable :: dens
character filen*100

   iErr=0
   write(*,*)'... opening density file '//trim(filen)//' ...'
   open(unit1,file=trim(filen),status='old',err=100)
!
!.......... skipping stuff and checking
!     VOL - volume (in a.u.) of the individual grid cell
!     VOL*NPLWV*au_A**3=VOLC
!
   read(unit1,*) ; read(unit1,*)
   read(unit1,*) NIONS1
   Read(unit1,*) NGX1,DIR(1,1),DIR(1,2),DIR(1,3) ; DIR(1,1:3)=DIR(1,1:3)*NGX1
   read(unit1,*) NGY1,DIR(2,1),DIR(2,2),DIR(2,3) ; DIR(2,1:3)=DIR(2,1:3)*NGY1
   read(unit1,*) NGZ1,DIR(3,1),DIR(3,2),DIR(3,3) ; DIR(3,1:3)=DIR(3,1:3)*NGZ1
   DIR=DIR*au_A
   write(*,'(a)')'... found lattice vectors:'
   write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR(1,j),j=1,3)
   write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR(2,j),j=1,3)
   write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR(3,j),j=1,3)
   write(*,'(a,3(i5,x))')  '... found grid: ',NGX1,NGY1,NGZ1

!........... skipping atomic positions (not checking)
   do nat=1,NIONS1
      read(unit1,*)
   end do
!
!........... reading the cube file of the density
!
   allocate(dens(NGZ1)) ; alloc=.true.
   call bastr(DIR,RECC,VOLC,1)
   factor=VOLC*A_au**3 ; Tot=0.0 ; ijk=0 ; j0=NGX1*NGY1*NGZ1/10

   do ix=1,NGX1
      do iy=1,NGY1
         ijk=ijk+NGZ1
         read(unit1,*,err=100,end=100) (dens(iz),iz=1,NGZ1)
         do iz=1,NGZ1
            Tot=Tot+dens(iz)*factor
         end do
         if(ijk/j0*j0.eq.ijk) &
              write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
      end do
   end do
   write(*,*)'Done!'
   go to 300
!
!.......errors
 100  write(*,*)'FATAL! File '//trim(filen)//' does not exist, bad or wrong!'
      iErr=1
      go to 300
!
!......... finish
300   if(alloc) deallocate(dens)
      close(unit1)
end subroutine check_dens_cp2k

    
    
