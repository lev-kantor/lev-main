program order
  implicit none
  integer :: i,n
  real*8 :: c
  real*8,dimension(:),allocatable :: dos,x,y,z

!............. dimension and allocate  
  i=0
  open(1,file='current.dat')
  do 
     read(1,*,end=1) c,c,c,c
     i=i+1
  end do
1 n=i
  write(*,*)'... found ',n,' lines'
  allocate(dos(n),x(n),y(n),z(n))

!............. read the file
  rewind(1)
  do i=1,n
     read(1,*) x(i),y(i),z(i),dos(i)
  end do


  
end program order
