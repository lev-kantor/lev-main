subroutine get_param_cp2k(Err)
use param
use atoms
use code
use kpoints
implicit none
!.................................................................
!  reads output file and creates all parameters from module PARAM
!.................................................................
character Line*200,name*100,cha2*2,filename*100
integer LinEnd(100),LinPos(100),i0,jsp,nat,NIONS_
logical                             :: found=.false.,Err1=.true.,Err
integer                             :: isp,NumLin,iErr,i,k
character*2, dimension(:), allocatable :: spec
!
   Err=.false.
   write(*,*)'======================================================'
   write(*,*)'=========== CP2K files in this directory =============' 
   write(*,*)'======================================================'
   call system('ls *')
   write(*,*)'======================================================'
   do
      write(*,*)' Give the name of the INPUT file:'
      read(*,'(a)') name
!
      open(14,file=trim(name),form='formatted',status='old',err=111)
      write(*,'(a)') '# Analyzing CP2K input file <'//trim(name)//'>...'
      exit
111   write(*,'(a)')'ERROR openining/reading file '//trim(name)//' !'
   end do
!........... open the input file and read all include files; write as tmp.inp
!
   open(16,file='tmp.inp')
   do
      read(14,'(a)',end=3) line
      call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
      if(iErr.ne.0) go to 18
      if(index(line,'@include').ne.0 .or. index(line,'@INCLUDE').ne.0) then
         filename=line(LinPos(2)+1:LinEnd(2)-1)
         i0=0
         open(15,file=trim(filename),err=20)
         write(*,*)' ... file '//trim(filename)//' opened'
         do 
            read(15,'(a)',err=20,end=112) line ; i0=i0+1
            write(16,'(a)') trim(line)
         end do
112      write(*,*)'... found ',i0,' lines in "'//trim(filename)//'"'
         close(15)
      else
         write(16,'(a)') trim(line)
      end  if
   end do
3  close(16) ; close(14)
!
!...... read in whatever possible from the CP2K input file
!
   open(16,file='tmp.inp')

!________ reading number of atoms
 
   NIONS=0
   call find_string('&COORD',6,line,16,.true.,iErr)
   do
      call CutStr(Line,NumLin,LinPos,LinEnd,16,0,iErr)
      if(iErr.ne.0) go to 19
      if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) go to 50
      NIONS=NIONS+1 
   end do
50 write(*,'(a,i5)')'QUICKSTEP: number of atoms found  = ',NIONS
   rewind(16)

!_________ reading number of species

   allocate(spec(NIONS))
   call find_string('&COORD',6,line,16,.true.,iErr)
   if(iErr.eq.1) then
      write(*,*)'ERROR! Input file is bad' ; stop
   end if
   NSPEC=1
   do nat=1,NIONS
      call CutStr(Line,NumLin,LinPos,LinEnd,16,0,iErr)
      if(iErr.ne.0) go to 19
      read(line(LinPos(1):LinEnd(1)),*) spec(nat)
      if(LinEnd(1)-LinPos(1).eq.0) then
         cha2=' '//spec(nat)
      else
         cha2=spec(nat)
      end if
      spec(nat)=cha2
      if(nat.eq.1) then
         spec(1)=cha2
      else
         do i=1,nat-1
            if(cha2.eq.spec(i)) go to 11
         end do
         NSPEC=NSPEC+1 
      end if
11 end do
   write(*,'(a,i5)')'QUICKSTEP: number of species found  = ',NSPEC
   rewind (16)
!
!...................... now determine species themselves ...............
!
   allocate(Species(NSPEC)) ; allocate(Mendel(NSPEC))
   do nat=1,NIONS
      if(nat.eq.1) then
         Species(1)=spec(1) ; jsp=1
      else
         do i=1,jsp
            if(spec(nat).eq.Species(i)) go to 12
         end do
         jsp=jsp+1 ; Species(jsp)=spec(nat)
      end if
!___________ checking from NAZV
      call check_Mendel(Species(jsp),k,Err1,.true.)
      if(Err1) then
         write(*,*)'WARNING! Species '//Species(jsp)//' - not recognised!'
         write(*,*)'         Attempting to proceed ...'
      end if
      mendel(jsp)=k
12 end do
   write(*,*) 'Species found are: ',(Species(isp),' ',isp=1,NSPEC)
15 deallocate(spec)
   close (16)
!
!__________ number of k-points is set to 1
!
   NKPTS=1 ; yeskp=.false.

!
!...... read in whatever possible from the CP2K output file
!
   write(*,*)'======================================================'
   write(*,*)'=========== CP2K files in this directory =============' 
   write(*,*)'======================================================'
   call system('ls *')
   write(*,*)'======================================================'
   do
      write(*,*)' Give the name of the OUTPUT file or skip this step (type: Skip):'
      read(*,'(a)') nameout
      if(index(nameout,'Skip').eq.1) go to 1
      name=nameout
!
      open(16,file=trim(name),form='formatted',status='old',err=113)
      write(*,'(a)') '# Analyzing CP2K file <'//trim(name)//'>...'
      exit
113   write(*,'(a)')'ERROR opening file '//trim(name)//' !'
   end do
!
!___________ determine the spin state
!
   call find_string('Number of spin states',21,line,16,.true.,iErr)
   if(iErr.eq.1) then
      write(*,*)'FATAL! Cannot find spin information. Skip this step'
      go to 1
   end if
   call CutStr(line,NumLin,LinPos,LinEnd,0,0,iErr)
   read(line(LinPos(6):LinEnd(6)),*,err=1) ISPIN
   if(ISPIN.eq.1) then
      write(*,*)'This is NOT spin-polarised calculation'
   else if(ISPIN.eq.2) then
      write(*,*)'This IS spin-polarised calculation'
   else
      go to 1
   end if
   go to 2
1  write(*,*) 'DEFAULT: NOT a spin-polarised calculation'
   ISPIN=1
2  close(16)
!
!___________ count the number of  bands
!
   NBANDS=1 ; yesen=.false.
!
!__________ check for the charge density grid used from the density file (if exists)
!
   NGX=1 ; NGY=1 ; NGZ=1
   yes_cp2k_cube=.true.
5  write(*,*)'======================================================'
   write(*,*)'=========== CP2K files in this directory =============' 
   write(*,*)'======================================================'
   call system('ls *.cube')
!   call system('ls *-ELECTRON_DENSITY-*.cube')
   Write(*,*)'======================================================'
   do
      write(*,*)' Give the name of the ELECTRONIC DENSITY file or skip this step (type: Skip):'
      read(*,'(a)') cp2k_cube_name
      if(index(cp2k_cube_name,'Skip').eq.1) then
         yes_cp2k_cube=.false. ; return
      end if
      name=cp2k_cube_name
!
      open(16,file=trim(name),form='formatted',status='old',err=114)
      write(*,'(a)') '# Analyzing CP2K file <'//trim(cp2k_cube_name)//'>...'
      exit
114   write(*,'(a)')'ERROR opening file '//trim(cp2k_cube_name)//' !'
   end do
!
!___________ determine the grid size
!
   read(16,*) ;  read(16,*) ; read(16,*,err=18) NIONS_
   if(NIONS_.ne.NIONS) then
      write(*,*)'ERROR! This is the wrong density file!'
      close(16) ; go to 5
   end if
   read(16,*,err=18) NGX ; read(16,*,err=18) NGY ; read(16,*,err=18) NGZ 
   close(16)
   write(*,'(a,3(x,i5))')'QUICKSTEP: grid found  => ',NGX,NGY,NGZ
   return
!
!____________ errors
!
18 write(*,'(a)')'ERROR 1 reading file '//trim(name)//' !'
   stop
19 write(*,'(a)')'ERROR 2 reading file '//'tmp.inp'//' !'
   stop
20 write(*,'(a)')'ERROR 3 reading file '//trim(filename)//' !'
  end subroutine get_param_cp2k


