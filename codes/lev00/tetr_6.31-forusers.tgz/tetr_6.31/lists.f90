module mlists
implicit none
!...................................................................
!     Here we define a number of character lists variables used to
!  present some of the chosen atoms (in lists)
!...................................................................

      integer,parameter :: N_lists=500
      character (LEN=N_lists) listfr,lists,listip,lisurf
      character (LEN=N_lists) listsT,long_listsT
      logical long_listfr,long_lists,long_listip,long_lisurf

end module mlists
