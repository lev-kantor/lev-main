subroutine EA_model_mesh(Which_Code)
!.............................................................................
! Using the current surface geometry, it will position tip atoms 
! on a mesh of points above the surface and saves the input files
! (CP2K only currently) in a directory structure.
!.............................................................................
  use real8
  use tetrag1
  use mlists
  implicit none
  integer :: NGX_,NGY_,NGZ_,NGX1,NGY1,NGZ1,nw,method
  integer :: i,ix,iy,iz,lx,ly,lz,j,ll,l0,anum,anum1,anum2,ln,io,iorb,iorbf,iorbt
  character :: Labels(N0LT)*2
  integer :: length,iAt,ii,ref_at,iA,is,NoSp(N0KD),lengthT
  character :: chx*4,chy*4,chz*4,dir*17,cha2*2
  real*8 :: zup,zdw,slab,zupdw,middle,vec1(2),vec2(2),Cp(3),Zupper,vec3(3),s
  real*8 :: v1,v2,v12,delta(3),TI1(3,N0LT),T,delt,mu,GammaT,Ea
  real*8 :: displ(3),displ_prev(3),displ_delta(3),del,displ0(3)
  integer :: iT0,iT1,iC0,iC1,ic
  real*8,parameter :: tiny=0.0001
  logical :: err,YES_Lv,periodic,tagYES,ref_Tip_At,Yes_Mv,Yes_No
  logical :: tagC,tagT,listat(N0LT),listatT(N0LT),lis,Yes_grid3,Yes_grid
  character :: Which_Code*6,YES_xyz*4,Type*2,reg(N0LT),answer
  character*12 :: angstr='<AtomNumber>',name*100

!..... check if this is the slab geonmetry
  
  slab=abs(AJ(3,1)) + abs(AJ(3,2)) + abs(AJ(1,3)) + abs(AJ(2,3))
  if(slab.ne.0.0) then
     write(*,*)'CANNOT PROCEED: this is NOT a slab geometry!'
     write(*,*)'>>>>>>>>>>>>> Make sure: <<<<<<<<<<<<<<'
     write(*,*)'  (i) the 3rd lattice vector is along Z'
     write(*,*)' (ii) the 1st and 2nd lattice vectors are within XY plane'
     write(*,*)'Press ENTER when ready'
     read(*,*)
     return
  end if
  
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'WARNING: slab atoms go conitnuously along the Z axis.'
  write(*,*)'         Correct in the M menu if this is not the case first.'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  
!______ bracket the atoms of the slab on the Z axis

  zup=-1.0e10  ; zdw=1.0e10
  do i=1,ITI
     if(TI(3,i).gt.zup) zup=TI(3,i)
     if(TI(3,i).lt.zdw) zdw=TI(3,i)
  end do
  zupdw=zdw+AJ(3,3)
  middle = zup+0.5*(zupdw-zup)
!
!========================================================================
!===================== MENU starts here =================================
!========================================================================
!
  iAt=0
  do i=1,Nsp
     do ii=1,NspN(i)
        iAt=iAt+1 ; Labels(iAt)=Species(i)
     end do
  end do
  periodic=.false.
  vec1(1)=AJ(1,1) ; vec1(2)=AJ(1,2)
  vec2(1)=AJ(2,1) ; vec2(2)=AJ(2,2)
  vec3(1)=0.0; vec3(2)=0.0 ; vec3(3)=middle-zup
  Cp(1)=0.0 ; Cp(2)=0.0 ; Cp(3)=Zup
  Zupper=middle ; YES_xyz='Xmol' ; YES_Lv=.true. ; tagYES=.false. ; Yes_grid=.false.
  listat=.false. ; ref_Tip_At=.false. ; Type='3D' ; Yes_Mv=.false. ; Yes_No=.false.
  NGX_=3 ; NGY_=3; NGZ_=3
  delt=0.08 ; T=300.0 ; Nw=1000 ; mu=-0.1246 ; method=3 ; del=0.002
  tagC=.false. ; tagT=.false. ; reg=' '; Yes_grid3=.false.

21 write(*,*)'/---------------------------------------------------\\'
  write(*,*)'|......................  MENU .......................|'
  write(*,*)'\\---------------------------------------------------/'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,'(a)') '......... CURRENT lattice vectors ...'
  do i=1,3
     write(*,'(a,i1,a,3(f10.5,x))') '[',i,'] ',(AJ(i,j),j=1,3)
  end do
  write(*,'(a,5x,20(a2,x))') '>>> Species: ',(Species(i),i=1,Nsp)
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'>>>> The slab is found between ',zdw,' and ',zup,' (in A)'
  write(*,*)'>>>> The middle of the vacuum gap = ',middle
  write(*,*)'>>>> The allowed range of Z values = [ ',zup,',',middle,' ]'
  write(*,*)'>>>>> METHODS 1-3 >>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'>>  C-atoms WILL come at the END of the CP2K input   <<'
  write(*,*)'>>>>> METHOD 4 >>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'>> Atoms in CP2K input WILL come in order: S, T, C   <<'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)
  if(method.eq.1) then
     write(*,'(a)') ' Mt. METHOD 1: S+He system'
     write(*,'(a)') '==========================================================' 
     write(*,'(a)') '== SC system contains S[urface] and He atom, no tip  =====' 
     write(*,'(a)') '==========================================================' 
  else if(method.eq.2) then
     write(*,'(a)') ' Mt. METHOD 2: [S-He and He+T] model'
     write(*,'(a)') '============================================================' 
     write(*,'(a)') '==  (i) SC system contains S[urface] and He atom {STEP 1} ==' 
     write(*,'(a)') '== (ii) CT system contains He atom and T[ip]     {STEP 2} ==' 
     write(*,'(a)') '============================================================' 
  else if(method.eq.3) then
     write(*,'(a)')         ' Mt. METHOD 3: [S+C and C+T] model'
     write(*,'(a)') '============================================================' 
     write(*,'(a)') '== (i) SC system contains S[urface] and C[entral] atoms   ==' 
     write(*,'(a)') '==     where some of the atoms can be relaxed.   {STEP 1} =='
     write(*,'(a)') '== (ii) CT system contains C[entral] and T[ip] atoms      ==' 
     write(*,'(a)') '==  where C atoms are in the relaxed SC geometry {STEP 2} =='
     write(*,'(a)') '============================================================' 
  else if(method.eq.4) then
     write(*,'(a)')         ' Mt. METHOD 4: S+C+T  model'
     write(*,'(a)') '==========================================================' 
     write(*,'(a)') '== SCT system contains S[urface], C[entral] and T[ip]   ==' 
     write(*,'(a)') '==     atoms some of which can be relaxed.              =='
     write(*,'(a)') '==========================================================' 
  end if
  write(*,'(a,3(f10.5,a,x),a)') &
       ' Cp. The corner point of the box: [',Cp(1),',',Cp(2),',',Cp(3),' ]'
  write(*,'(a,f10.5)') ' Up. Upper Z point of the box: ',Zupper

  write(*,'(a,a)') ' Dm. Dimensionality of the grid: '//Type
  if(Type.eq.'1D') then
     NGX_=0 ; NGY_=0
     if(NGZ_.eq.0) then
        write(*,'(a,i5))') ' Gr. Grid along the 3rd vector: UNDEFINED'
        Yes_grid3=.false. ; Yes_grid=.false.
     else
        write(*,'(a,i5))') ' Gr. Grid along the 3rd vector: ',NGZ_
        Yes_grid3=.true. ; Yes_grid=.true.
     end if
     write(*,'(a)') '     >>> 1D grid ONLY - general direction      <<<'
     write(*,'(a)') '     >>> Default: vertical grid (spectroscopy) <<<'
  else if(Type.eq.'2D') then
     NGZ_=0 ; vec3=0.0
     write(*,'(a)') '     >>> Horizontal in-plane grid ONLY - constant height <<<'
     write(*,'(a,2(i5,a))')  &
              ' Gr. Grid along the 1st and 2nd vectors: ',NGX_,',',NGY_
  else
     write(*,'(a,3(i5,a))')  &
              ' Gr. Grid along the 1st, 2nd and 3rd vectors: ',NGX_,',',NGY_,',',NGZ_
     write(*,'(a)') '     >>> Full spatial grid - appropriate for constant current <<<'
  end if

  if(NGX_.eq.0 .or. NGY_.eq.0) then
     vec1=0.0 ; vec2=0.0
     write(*,'(2(a,f10.5),a)') &
          '     The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
     write(*,'(2(a,f10.5),a)') &
          '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
  else
     write(*,'(2(a,f10.5),a)') &
          ' Vp. The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
     write(*,'(2(a,f10.5),a)') &
          '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
  end if

  if(Type.eq.'1D') then
     if(Yes_grid3) write(*,'(3(a,f10.5),a)') &
          ' V3. The 3rd vector (chosen direction) is (',vec3(1),',',vec3(2),',',vec3(3),')'
  else
     write(*,'(3(a,f10.5),a)') &
          '     The 3rd vector (perpendicular to XY) is (',vec3(1),',',vec3(2),',',vec3(3),')'
  end if
  
  if(NGX_.eq.0 .or. NGY_.eq.0) then
     periodic=.false.
     write(*,'(a)')  '     The STM box CANNOT be periodically extended within the XY plane'
  else
     if(periodic) then
        write(*,'(a)')  '  P. The STM box CAN be periodically extended within the XY plane'
     else
        write(*,'(a)')  '  P. The STM box CANNOT be periodically extended within the XY plane'
     end if
  end if
  
  write(*,'(a)')  ' Tc. Tag C atoms'
  if(tagC) then
     call print_long_char(lists,length,long_lists)
     if(ref_Tip_At) then
        write(*,'(a,i5)')  ' Ta. Reference C atom: ',ref_at
        write(*,'(5x,a,3(f10.5,x))') 'delta = ',delta(1:3)
     else
        write(*,'(a)')  ' Ta. Specify reference C atom'
     end if
  end if
  tagYES=tagC
  if(method.eq.4) then
     write(*,'(a)')  ' Tt. Tag T atoms'
     if(tagT) call print_long_char(listsT,lengthT,long_listsT)
     tagYES=tagC.and.tagT
  end if
  if(Yes_Mv) then
     write(*,'(a)') ' Si. [For save] Place CP2K input with @include:'
     write(*,'(a)') '     The file name: '//name(ln:)//'.inp'
  else
     write(*,'(a)') ' Si. [For save] Place CP2K input with @include: UNDEFINED'
  end if
  if(tagYES .and. ref_Tip_At .and. Yes_Mv .and. Yes_grid) then
     write(*,'(a)') '  S. Save the directory structure with all tip positions'
  end if

  write(*,'(a)')  ' ================ For the calculation of the CURRENT ==================='
  
  if(method.eq.1) then
     write(*,'(a,f10.5)')  ' Ea. Effective He atom on-site energy = ',Ea
     write(*,'(a,f10.5)')  '  G. Tip level width parameter = ',GammaT
  else if(method.eq.2) then
     write(*,'(a,f10.5)')  ' Ea. Effective atom on-site energy = ',Ea
  end if
!  write(*,'(a,i5)')     ' Nw. Integration grid for frequency = ',Nw
  write(*,'(a,f10.5)')     ' Nw. Step for the frequency integration = ',del
  write(*,'(a,f10.5)')  '  T. Temperature = ',T
  write(*,'(a,f10.5)')  ' Mu. Chemical potential = ',mu
  write(*,'(a,f10.5)')  '  D. A delta to numerically represent the delta function = ',delt
  if(Yes_No) then
     write(*,'(a)')     ' No. Number of orbitals for each species:'
     write(*,'(5(10x,a,i5,a))') (Species(is)//' [',NoSp(is),'] ',is=1,Nsp)
     if(tagYES) then
        iA=0  ; iorb=0 ; iorbf=0 
        do is=1,Nsp
           do i=1,NspN(is)
              iA=iA+1
              lis=listat(iA); if(method.eq.4) lis=listat(iA).or.listatT(iA)
              if(.not.lis) then
                 iorb=iorb+NoSp(is)
                 iorbf=iorbf + NoSp(is)
              end if
           end do
        end do
        if(method.eq.4) then
           iorbt=iorb
           iA=0
           do is=1,Nsp
              do i=1,NspN(is)
                 iA=iA+1
                 if(listatT(iA)) then
                    iorbt=iorbt+NoSp(is)
                    iorbf=iorbf + NoSp(is)
                 end if
              end do
           end do
        end if
        iA=0
        do is=1,Nsp
           do i=1,NspN(is)
              iA=iA+1
              if(listat(iA)) iorbf=iorbf + NoSp(is)
           end do
        end do
        write(*,'(a,i5)')      '     The S subsystem orbitals span from 1 to ',iorb
        if(method.ne.4) then
           write(*,'(2(a,i5))')   '     The C subsystem orbitals span from ',iorb+1,' to ',iorbf
        else
           write(*,'(2(a,i5))')   '     The T subsystem orbitals span from ',iorb+1,' to ',iorbt
           write(*,'(2(a,i5))')   '     The C subsystem orbitals span from ',iorbt+1,' to ',iorbf
        end if
        write(*,'(a)')  ' Sd. Save [input.dat] file for the current calculation'
     end if
  else
     write(*,'(a)')     ' No. Number of orbitals for each species: UNDEFINED'
  end if
  
  write(*,'(a)')  ' ======================== S E T T I N G S =============================='
  if(CHIMERA) then
     if(YES_Lv) then
        write(*,'(a)') ' Vs. Show lattice vectors and vectors defining the box'
        write(*,'(a)') ' Lv. Show lattice vectors - YES'
     else
        write(*,'(a)') ' Vs. Show only vectors defining the box'
        write(*,'(a)') ' Lv. Show lattice vectors - NO'
     end if
  end if
  write(*,'(a)') ' An. [For input] Coordinates are specified in: '//angstr
  write(*,'(a)')  ' Co. Show atomic positions '
  write(*,'(a)') '  Q. Quit.'
  write(*,*)
  write(*,*)'Specify the character and press ENTER ------->'
  read(*,'(a)',err=21) cha2  ; write(8,'(a)') cha2
  call right(cha2,2,l0)

![Vp].......... two in-plane vectors along the 1st & 2nd directions to define the box

  IF(cha2(l0:).eq.'Vp' .and. (NGX_.ne.0 .and. NGY_.ne.0) ) THEN

8    write(*,*)'>>>>>>>>>> Two IN-PLANE VECTORS of the box <<<<<<<<<<<<<<'

     if(angstr.eq.'<AtomNumber>') then
5       write(*,*)'Give the atom at the beginning of both vectors:'
        read(*,*,err=5) anum ; write(8,*) anum
6       write(*,*)'Give the atom at the end of the 1st vector:'
        read(*,*,err=6) anum1 ; write(8,*) anum1
        if(anum.eq.anum1) go to 5
        vec1(1)=TI(1,anum1)-TI(1,anum) ; vec1(2)=TI(2,anum1)-TI(2,anum)
7       write(*,*)'Give the atom at the end of the 2nd vector:'
        read(*,*,err=7) anum2 ; write(8,*) anum2
        if(anum.eq.anum2 .or. anum1.eq.anum2) go to 7
        vec2(1)=TI(1,anum2)-TI(1,anum) ; vec2(2)=TI(2,anum2)-TI(2,anum)
     else
11      write(*,*)'Give 2 Cartesian ompoenents (X,Y) of the 1st vector to define the box:'
        read(*,*,err=11) vec1(1),vec1(2) ; write(8,*) vec1(1),vec1(2)
        v1=sqrt(vec1(1)*vec1(1)+vec1(2)*vec1(2))
        if(v1.lt.tiny) go to 11
12      write(*,*)'Give 2 Cartesian compoenents (X,Y) of the 2nd vector to define the box:'
        read(*,*,err=12) vec2(1),vec2(2) ; write(8,*) vec2(1),vec2(2)
        v2=sqrt(vec2(1)*vec2(1)+vec2(2)*vec2(2))
        if(v2.lt.tiny) go to 12
!______________ check if the 2 vectors are colllinear        
        v12=vec1(1)*vec2(1)+vec1(2)*vec2(2)
        if(1.0-v12/(v1*v2) .lt. tiny) then
           write(*,*) 'ERROR! The two vectors are (nearly) collinear!'
           go to 8
        end if
     end if

![Dm].......... dimensionality of the grid

  ELSE IF(cha2(l0:).eq.'Dm') THEN

     if(Type.eq.'3D') then
        Type='2D'
     else if(Type.eq.'2D') then
        Type='1D'
        vec3(1:2)=0.0d0 ; vec3(3)=Zupper-Cp(3)
     else 
        Type='3D'
     end if

![V3].......... for 1D  a general vector of direction

     ELSE IF(cha2(l0:).eq.'V3' .and. Type.eq.'1D' .and. Yes_grid3) THEN

        write(*,'(a)') '*** NOTE: the length of the vector corresponds to total length ***'
        write(*,'(a)') '*** of the scan along this direction, while the vector starts  ***'
        write(*,'(a)') '*** at position:                                               ***'
        write(*,'(a,3(f10.5,a))') '***          Cp = (',Cp(1),',',Cp(2),',',Cp(3),'):          ***'
        write(*,*)'Continue (y,Y/n,N):'
        read(*,'(a)') answer ; write(8,*) answer
        if(answer.eq.'N' .or. answer.eq.'n') go to 21
        if(angstr.eq.'<AtomNumber>') then
35         write(*,'(a)')'Give the atom at the beginning of the vector.'
           read(*,*,err=35) anum ; write(8,*) anum
36         write(*,*)'Give the atom at the end of the vector:'
           read(*,*,err=36) anum1 ; write(8,*) anum1
           vec3(1:3)=TI(1:3,anum1)-TI(1:3,anum)
        else 
31         write(*,*)'Give the vector along the chosen 1D in Cartesian:'
           read(*,*,err=31) vec3 ; write(8,*) vec3
           if(abs(vec3(1)**2+vec3(2)**2+vec3(3)**2).lt.0.01) then
              write(*,*)'ERROR: the vector length is nearly ZERO!'
              go to 31
           end if
        end if
        
![Mt]........... method (from 1 to 4)

  ELSE IF(cha2(l0:).eq.'Mt') THEN

     if(method.eq.1) then
        method=2
     else if(method.eq.2) then
        method=3
     else if(method.eq.3) then
        method=4
     else
        method=1
     end if
     
![T]........... temperature

  ELSE IF(cha2(l0:).eq.'T') THEN

     write(*,*)'Enter the temperarture (K):'
     read(*,*,err=21) s ; write(8,*) s
     if(s.lt.0.0) go to 21
     T=s

![Ea]........... He atom on-site energy (eV)

  ELSE IF(cha2(l0:).eq.'Ea' .and. (method.eq.1 .or. method.eq.2)) THEN

     write(*,*)'Enter the on-site He energy (eV):'
     read(*,*,err=21) s ; write(8,*) s
     if(s.lt.0.0) go to 21
     Ea=s

![G]........... level width parameter for the tip

  ELSE IF(cha2(l0:).eq.'G' .and. method.eq.1) THEN

     write(*,*)'Enter the level width tip value (eV):'
     read(*,*,err=21) s ; write(8,*) s
     if(s.lt.0.0) go to 21
     GammaT=s
     
![Mu]........... chemical potential

  ELSE IF(cha2(l0:).eq.'Mu') THEN

     write(*,*)'Enter the chemical potential (eV):'
     read(*,*,err=21) s ; write(8,*) s
     mu=s

![D]........... a small delta to handle numerically the delta function

  ELSE IF(cha2(l0:).eq.'D') THEN

     write(*,*)'Enter the value of the delta to be used in the Lorenzian:'
     read(*,*,err=21) s ; write(8,*) s
     if(s.lt.0.0) go to 21
     delt=s

![No]........... give number of AOs for every species in the system

  ELSE IF(cha2(l0:).eq.'No') THEN

     Yes_No=.false.
     write(*,*)'Enter the number of AOs in CP2K corresponding to each species:'
     do is=1,Nsp
        write(*,*) 'Give the number of AOs for '//Species(is)//':'
        read(*,*,err=21) i
        if(i.lt.1) go to 21
        NoSp(is)=i
     end do
     Yes_No=.true.
     
![Nw]........... frequency integration grid / integration step

  ELSE IF(cha2(l0:).eq.'Nw') THEN

!     write(*,*)'Enter the grid (> 10):'
!     read(*,*) Nw ; write(8,*) Nw
!     if(Nw.lt.10) go to 21
     write(*,*)'Enter the integration step:'
     read(*,*) del
     if(del.le.0.0) go to 21
     
![Cp].......... specify the corner point for the box

  ELSE IF(cha2(l0:).eq.'Cp') THEN

     write(*,*)'>>>>> Specify the corner point of the box. <<<<<'
     if(angstr.eq.'<AtomNumber>') then
9       write(*,*) &
             'Firstly, specify the X,Y cordinates of the corner point using atom number:'
        read(*,*) anum ; write(8,*) anum
        if(anum.lt.1 .or. anum.gt.ITI) go to 9
        Cp(1)=TI(1,anum) ; Cp(2)=TI(2,anum)
     else
10      write(*,*) &
             'Firstly, specify the X,Y cordinates of the corner point in Cartesian:'
        read(*,*) Cp(1),Cp(2) ; write(8,*) Cp(1),Cp(2)
     end if
13   write(*,'(2(a,f10.5),a)') 'Secondly, specify the Z. It could be within [',zup,',',middle,']'
     read(*,*,err=13) Cp(3) ; write(8,*) Cp(3)
     if(Cp(3).lt.zup .or. Cp(3).gt.middle) then
        write(*,*)'WARNING! the Z-compoenent is outside the Z-window!'
     end if
        
![Up].......... specify the z-upper point of the box

  ELSE IF(cha2(l0:).eq.'Up') THEN
     
14   write(*,*)'Specify Z of the upper point of the box within  [',zup,',',middle,']:'
     read(*,*,err=14) Zupper ; write(8,*) Zupper
     if(Zupper.lt.Cp(3) .or. Zupper.gt.middle) then
        write(*,*)'ERROR! Choose within the correct Z windows'
        go to 14
     end if

![P].......... whether the system can be periodically extended within the surface plane or not
!              This is the case if the vectors vec1, vec2 correspond to the primitive surface unit cell,
!              while the current vectors AJ(1,) and AJ(2,) are vectors extended fro them.     
     
  ELSE IF(cha2(l0:).eq.'P' .and. (NGX_.ne.0 .and. NGY_.ne.0) ) THEN

     if(periodic) then
        periodic=.false.
     else
        periodic=.true.
     end if
     
![Gr].......... specify the grid

  ELSE IF(cha2(l0:).eq.'Gr') THEN

     NGX1=NGX_ ; NGY1=NGY_ ; NGZ1=NGZ_
     if(Type.eq.'3D') then
        write(*,*)'Specify the grid along 3 vectors of the box:'
        read(*,*,err=21) NGX1,NGY1,NGZ1 ; write(8,*) NGX1,NGY1,NGZ1
!        if(NGX1 * NGY1 * NGZ1 .eq. 0)  then
!           write(*,*) 'ERROR: the grid is wrong: cannot be 0'
!           go to 21
!        end if
     else if(Type.eq.'2D') then
        write(*,*)'Specify the grid along 2 vectors of the box within the XY plane:'
        read(*,*,err=21) NGX1,NGY1 ; write(8,*) NGX1,NGY1
        if(NGX1 * NGY1 .eq. 0)  then
           write(*,*) 'ERROR: the grid is wrong: cannot be 0'
           go to 21
        end if
     else if(Type.eq.'1D') then
        write(*,*)'Specify the grid along the 3rd vector only'
        read(*,*,err=21) NGZ1 ; write(8,*) NGZ1
     end if
     if(NGX1.lt.0 .or. NGY1.lt.0 .or. NGZ1.lt.0) then
        write(*,*) 'ERROR: the grid is wrong: must be non-negative'
        go to 21
     else if(NGX1.gt.999 .or. NGY1.gt.999 .or. NGZ1.gt.999) then
        write(*,*) 'ERROR: the grid is too large, must be =< 999'
        go to 21
     end if
     NGX_=NGX1 ; NGY_=NGY1 ; NGZ_=NGZ1
     if(NGX_.ne.0 .or. NGY_.ne.0 .or. NGZ_.ne.0) Yes_grid=.true.
     
![Sd].......... save input.dat file for the current calculation

  ELSE IF(cha2(l0:).eq.'Sd' .and. TagYES .and. Yes_No) THEN

     open(19,file='input.dat')
!     write(19,*) Nw
     write(19,*) del
     if(method.eq.1 .or. method.eq.2) write(19,*) GammaT,Ea
     write(19,*) T
     write(19,*) mu 
     write(19,*) delt
     if(method.ne.4) then
        write(19,'(2(i5,x),a)') iorb,iorbf,'  <= SC-system'
     else
        write(19,'(3(i5,x),a)') iorb,iorbt,iorbf,'  <= STC-system'
     end if
     write(19,*) 'F F F'
     close(19)

![Tc].......... tag C atoms

  ELSE IF(cha2(l0:).eq.'Tc') THEN

     listat=.false. ; tagC=.false.
     
     call TTag(tagC,ITI,TI,Labels,listat,lists,length,N_lists,long_lists)
     do i=1,ITI
        if(listat(i)) then
           tagC=.true. ;  exit
        end if
     end do

![Tt].......... tag T atoms

  ELSE IF(cha2(l0:).eq.'Tt' .and. method.eq.4) THEN

     listatT=.false. ; tagT=.false.
     
     call TTag(tagT,ITI,TI,Labels,listatT,listsT,lengthT,N_lists,long_listsT)
     do i=1,ITI
        if(listatT(i) .and. listat(i)) then
           listatT=.false.
           write(*,*)'ERROR!Some of the T[ip] atoms are in the C[entral] region!'
           TagT=.false. ; exit
        else if(listatT(i)) then
           tagT=.true. ;  exit
        end if
     end do
     
![Ta].......... ref tip atom: its position defines the positions of all atoms of the tip

  ELSE IF(cha2(l0:).eq.'Ta' .and. tagC) THEN

     write(*,*)'Give the atomic number of a tip atom that will define the tip position:'
     read(*,*,err=21) ref_at ; write(8,*) ref_at
     if(ref_at.lt.0 .or. ref_at.gt.ITI .or. .not.listat(ref_at))  go to 21
     do i=1,3
        delta(i)=Cp(i)-TI(i,ref_at)
     end do
     ref_Tip_At=.true.

![Vs]...... show lattice vectors & box vectors
     
  ELSE IF(cha2(l0:).eq.'Vs' .and. CHIMERA) THEN
        
     open(35,file='vectors.vct',form='formatted',status='unknown')
     if(YES_Lv) then 
        write(35,*) '6'
        do i=1,3
           write(35,*) (AJ(i,j),j=1,3)
        end do
     else
        write(35,*) '3'
     end if
     write(35,*) vec1(1),vec1(2),' 0.0'
     write(35,*) vec2(1),vec2(2),' 0.0'
     write(35,*) vec3(1),vec3(2),vec3(3)
     close(35)

![An]...... choose the way how the coordinates are given

  ELSE IF(cha2(l0:).eq.'An') THEN

     if(angstr.eq.'<Angstroms> ') then
        angstr='<AtomNumber>'
     else if(angstr.eq.'<AtomNumber>') then
        angstr='<Angstroms> '
     end if

![Lv]...... show lattice vectors in CHINERA or not

  ELSE IF(cha2(l0:).eq.'Lv') THEN

     if(YES_Lv) then
        YES_Lv=.false.
     else 
        YES_Lv=.true.
     end if

![S].......... Save 
        
  ELSE IF(cha2(l0:).eq.'S' .and. tagYES .and. ref_Tip_At .and. Yes_Mv .and. Yes_grid) THEN

!______ determine positions of the atom(s), create the correct directory
!       structure and write the input file in each directory.
! 
! IMPORTANT [necessary for CURRENT]:
!           Method 1-3: C atom(s) is(are) assumed last in the list 
!           Method 4: atoms are in order: S,T, then C 
! Hence, atoms will be reodered in the CP2K input !!!

     TI1=TI
     do ix=0,NGX_
        call name_from_number(ix,chx,lx,err)
        do iy=0,NGY_
           call name_from_number(iy,chy,ly,err)
           do iz=NGZ_,0,-1
              call name_from_number(iz,chz,lz,err)
              
              dir=chx(lx:)//'.'//chy(ly:)//'.'//chz(lz:)
              ll=2+(5-lx)+(5-ly)+(5-lz)
              write(*,*) '... creating directory '//dir(1:ll)
              call system('mkdir '//dir(1:ll))

!_______________ displacement vector:              
! displ - the complete displacement for the given grid point ix,iy,iz 
!
              displ=0.0
              if(NGX_.ne.0 .and. NGY_.ne.0) then
                 displ(1) = delta(1) + ix*vec1(1)/NGX_ + iy*vec2(1)/NGY_
                 displ(2) = delta(2) + ix*vec1(2)/NGX_ + iy*vec2(2)/NGY_
              else if(NGX_.eq.0 .and. NGY_.ne.0) then
                 displ(1) = delta(1) + iy*vec2(1)/NGY_
                 displ(2) = delta(2) + iy*vec2(2)/NGY_
              else if(NGX_.ne.0 .and. NGY_.eq.0) then
                 displ(1) = delta(1) + ix*vec1(1)/NGX_
                 displ(2) = delta(2) + ix*vec1(2)/NGX_
              end if
              if(NGZ_.eq.0) then
                 displ(3) = delta(3)  
              else 
                 displ(3) = delta(3) + iz*vec3(3)/NGZ_
              end if
              if(Type.eq.'1D') then
                 displ(1:3) = delta(1:3) + iz*vec3(1:3)/NGZ_
              end if
              
!_______________ displace atoms

              do iA=1,ITI
                 lis=listat(iA); if(method.eq.4) lis=listat(iA).or.listatT(iA)
                 if(lis) TI1(1:3,iA)=TI(1:3,iA)+displ(1:3)
              end do

! displ_prev  - the complete displacement for the previous Z grid point in the triple loop above
! displ_delta - the relative displacement with respect to the previous grid point 


              if(iz.eq.NGZ_) then
                 if(ix.eq.0 .and. iy.eq.0) then
                    displ_delta=0.0
                    displ0=displ
                 else
                    displ_delta = displ - displ0
                 end if
              else 
                 displ_delta = displ - displ_prev
              end if
              displ_prev = displ
              
!______________ create file [coordinates.inc] with atomic positions in each directory
!______________ IMPORTANT: atoms are reodered in the CP2K input !!!

              open(19,file='coordinates.inc')
              open(29,file='relax_flags.inc')
              iAt=0
              
!________ S atoms first (methods 1-4) [iAt - counts atoms in the new order]
              iA=0 ; ic=0
              do is=1,Nsp
                 do i=1,NspN(is)
                    iA=iA+1 
                    lis=listat(iA); if(method.eq.4) lis=listat(iA).or.listatT(iA)
                    if(.not.lis) then
                       iAt=iAt+1 ; ic=ic+1
                       write(19,'(a,3(x,f10.5))') Species(is),TI1(1:3,iA)
                       if(relax_flag(1,iA).eq.'F' .or. relax_flag(2,iA).eq.'F' &
                                                 .or. relax_flag(3,iA).eq.'F') then
                          write(29,'(a,i5)') 'LIST ',iAt
                       end if
                    end if
                 end do
              end do
              
!________ T atoms (method 4 only)
! iT0 - number of the first T atom in the new order
! iT1 - number of the last T atom in the new order

              if(method.eq.4) then              
                 iA=0 ; iT0=ic+1 ; ic=0
                 do is=1,Nsp
                    do i=1,NspN(is)
                       iA=iA+1 
                       if(listatT(iA)) then
                          iAt=iAt+1 ; ic=ic+1
                          write(19,'(a,3(x,f10.5))') Species(is),TI1(1:3,iA)
                          if(relax_flag(1,iA).eq.'F' .or. relax_flag(2,iA).eq.'F' &
                                                   .or. relax_flag(3,iA).eq.'F') then
                             write(29,'(a,i5)') 'LIST ',iAt
                          end if
                       end if
                    end do
                 end do
                 iT1=iT0+ic-1
              end if
                 
!________ C atoms (methods 1-4)       
              
              iA=0
              iC0=ic+1 ; if(method.eq.4) iC0=iT1+1 ; ic=0
              do is=1,Nsp
                 do i=1,NspN(is)
                    iA=iA+1 
                    if(listat(iA)) then
                       iAt=iAt+1 ; ic=ic+1
                       write(19,'(a,3(x,f10.5))') Species(is),TI1(1:3,iA)
                       if(relax_flag(1,iA).eq.'F' .or. relax_flag(2,iA).eq.'F' &
                                                 .or. relax_flag(3,iA).eq.'F') then
                          write(29,'(a,i5)') 'LIST ',iAt
                       end if
                    end if
                 end do
              end do
              iC1=iC0+ic-1

              close(19) ; close(29)

              open(30,file='info.dat')
              write(30,*) displ
              write(30,*) displ_delta
              if(method.eq.4) write(30,*) iT0,iT1
              write(30,*) iC0,iC1
              close(30)

              write(*,'(a)') 'mv coordinates.inc '//dir(1:ll)//'/.'
              call system('mv coordinates.inc '//dir(1:ll)//'/.')
              write(*,'(a)') 'mv relax_flags.inc '//dir(1:ll)//'/.'
              call system('mv relax_flags.inc '//dir(1:ll)//'/.')
              write(*,'(a)') 'mv info.dat '//dir(1:ll)//'/.'
              call system('mv info.dat '//dir(1:ll)//'/.')

!_______________ create relaxation flags and save then in [relax_flags.inc]


              
              if(Yes_Mv) then
                 write(*,'(a)') 'cp '//name(ln:)//'.inp '//dir(1:ll)//'/input_SC.inp'
                 call system('cp '//name(ln:)//'.inp '//dir(1:ll)//'/input_SC.inp')
              end if
           end do
        end do
     end do
        
!______________ save the file for lev00      

     open(18,file='for_lev00.dat')
     write(18,*) Cp ; write(18,*) vec1 ; write(18,*) vec2
     write(18,*) vec3 ; write(18,*) NGX_,NGY_,NGZ_
     if(periodic) then
        write(18,*) '1 periodic'
     else 
        write(18,*) '0 non-periodic'
     end if
     write(18,'(2a)') Type(1:1),'  - '//Type//'-system'
     write(18,*) Zupper
     write(18,*) delta(1:3)
     write(18,'(10(l1,x))') (listat(iA),iA=1,ITI)
     close(18)
      
![Co].... display atomic positions

  ELSE IF(cha2(l0:).eq.'Co') THEN

     do iA=1,ITI
        if(listat(iA)) then
           reg(iA)='C'
        else if(method.eq.4 .and. listatT(iA)) then
           reg(iA)='T'
        else
           reg(iA)='S'
        end if
     end do
     call show_atoms_EA(reg)

![Si].... move the input file with @include statement into each directory or not

  ELSE IF(cha2(l0:).eq.'Si') THEN

     if(Yes_Mv) then
        Yes_Mv=.false.
     else
        write(*,*)'*** Enter the input file name [name.inp] with statements  ***'
        write(*,*)'***          {  without the .inp extension!  }            ***'
        write(*,*)'*** [@include coordinates.inc]                            ***'
        write(*,*)'*** instead of all atoms of the SC-system, and also       ***'
        write(*,*)'*** [@include relax_flags.inc] within &FIXED_ATOMS block  ***'
        read(*,'(a)') name ; write(*,'(a)') name
        call right(name,100,ln)
        open(19,file=name(ln:)//'.inp',status='old',iostat=io)
        if(io.eq.0) then
           write(*,*)'... file '//name(ln:)//'.inp exists. Proceed.'
           close (19)
        else
           write(*,*)'... file '//name(ln:)//'.inp does NOT exists.'
           go to 21
        end if
        Yes_Mv=.true.
     end if

![Q]...... quit

  ELSE IF(cha2(l0:).eq.'Q') THEN
      
!.......... return the original settings

     return
  ELSE
     write(*,*) 'Wrong! Try again!'
  END IF
  go to 21
     
!..................................................................................      
!............................. MENU ENDS ..........................................
!..................................................................................      
end subroutine EA_model_mesh

subroutine EA_model_mesh_tip(Which_Code)
!.............................................................................
!.......   This is for METHOD 3 only  ........................................
!.............................................................................
! At this point the EA option must have been used and the CP2K run for all
! grid points of the mesh for the surface + apex (S+C) system, so that in each
! directory we have the relaxed geometry of the S+C system (main -> 2K in TETR).
!    Then, the C system (the tip apex) must have been saved in a C_atoms.inc file 
! in each directory of the grid from the relaxed S+C system (option main -> 2K 
! with subsequent M -> SA where C atoms are actually saved in C_atoms.inc).
!
! Note that at this point, prior to using the current option (main menu -> CT), 
! C atoms are displaced appropriately in each directory and saved in C_atoms.inc. 
! 
! While going into this option, the current geometry corresponds to T+C system
! with both C and T atoms in the original geometry. 
! 
! Hence, in this option we do the following to the current geometry of T+C:
! 
!    1. read for_lev00.dat to see what are the grid and the box dimensions/position
!    2. ask which atoms belong to C (option Tp)
!    3. move the T atoms for each grid point in a loop over grid
!    4. save the moved T atoms in T_atoms.inc file in each directory 
!    5. copy into each directory the input file as input_CT.inp with the corresponding
!          @include 'C_atoms.inc' 
!          @include 'T_atoms.inc' 
!       statements. The geometry in input_CT.inp does not contain relaxation.
!.............................................................................
  use real8
  use tetrag1
  use mlists
  implicit none
  integer :: NGX_,NGY_,NGZ_,iperiodic,dim_type,iA,i,j,length,l0,ll,ln,io,iAt
  integer :: lx,ly,lz,ix,iy,iz,k,is,iorb,iorbf,NoSp(N0KD)
  real*8 :: vec1(2),vec2(2),Cp(3),vec3(3),slab,zup,zdw,zupdw,middle,delta(3)
  real*8 :: Zupper,TI1(3,N0LT)
  logical :: listat(N0LT),tagYES,YES_Lv,err,Yes_No
  character :: Which_Code*6,cha2*2
  character :: chx*4,chy*4,chz*4,dir*17,reg(N0LT)
  character :: Labels(N0LT)*2
  character*12 :: angstr='<AtomNumber>',name*100

!..... check if this is the slab geonmetry
  
  slab=abs(AJ(3,1)) + abs(AJ(3,2)) + abs(AJ(1,3)) + abs(AJ(2,3))
  if(slab.ne.0.0) then
     write(*,*)'CANNOT PROCEED: this is NOT a slab geometry!'
     write(*,*)'>>>>>>>>>>>>> Make sure: <<<<<<<<<<<<<<'
     write(*,*)'  (i) the 3rd lattice vector is along Z'
     write(*,*)' (ii) the 1st and 2nd lattice vectors are within XY plane'
     write(*,*)'Press ENTER when ready'
     read(*,*)
     return
  end if
  
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'WARNING: slab atoms go conitnuously along the Z axis.'
  write(*,*)'         Correct in the M menu if this is not the case first.'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  
!______ bracket the atoms of the slab on the Z axis

     zup=-1.0e10  ; zdw=1.0e10
     do i=1,ITI
        if(TI(3,i).gt.zup) zup=TI(3,i)
        if(TI(3,i).lt.zdw) zdw=TI(3,i)
     end do
     zupdw=zdw+AJ(3,3)
     middle = zup+0.5*(zupdw-zup)

!______________ read the file for_lev00.dat

     open(18,file='for_lev00.dat')
     read(18,*) Cp
     read(18,*) vec1 ; read(18,*) vec2 ;  read(18,*) vec3
     read(18,*) NGX_,NGY_,NGZ_
     read(18,*) iperiodic
     if(iperiodic.eq.1) then
        write(*,*) 'Found: periodic'
     else 
        write(*,*) 'Foud: non-periodic'
     end if
     read(18,*) dim_type
     write(*,'(a,i1,a1)')'Found: dimensionality = ',dim_type,'D'
     read(18,*) Zupper
     read(18,*) delta(1:3)
!     read(18,'(10(l1,x))') (listat(iA),iA=1,ITI)
     close(18)

!______________ menu

     tagYES=.false. ; YES_Lv=.true. ; Yes_No=.false. ; reg=' '
     
21   write(*,*)'/---------------------------------------------------\\'
     write(*,*)'|......................  MENU .......................|'
     write(*,*)'\\---------------------------------------------------/'
     write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
     write(*,'(a)') '......... CURRENT lattice vectors ...'
     do i=1,3
        write(*,'(a,i1,a,3(f10.5,x))') '[',i,'] ',(AJ(i,j),j=1,3)
     end do
     write(*,'(a,5x,20(a2,x))') '>>> Species: ',(Species(i),i=1,Nsp)
     write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
     write(*,*)'>>>> The slab is found between ',zdw,' and ',zup,' (in A)'
     write(*,*)'>>>> The middle of the vacuum gap = ',middle
     write(*,*)'>>>> The allowed range of Z values = [ ',zup,',',middle,' ]'
     write(*,*)
     write(*,*)'>>>>>>>>>>>>>>>>>>>>> METHOD 3 ONLY <<<<<<<<<<<<<<<<<<<'
     write(*,*)'>> C-atoms WILL come at the END of the list of atoms <<'
     write(*,*)'>>             Also, NO relaxation                   <<'
     write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
     write(*,*)
     write(*,'(a,3(f10.5,a,x),a)') &
          '    The corner point of the box: [',Cp(1),',',Cp(2),',',Cp(3),' ]'
     write(*,'(a,f10.5)') '     Upper Z point of the box: ',Zupper
     write(*,'(a,i1,a)')  '     Dimensionality of the grid: ',dim_type,'D'
     write(*,'(a,3(i5,a))')  &
              '     Grid along the 1st, 2nd and 3rd vectors: ',NGX_,',',NGY_,',',NGZ_

     if(NGX_.eq.0 .or. NGY_.eq.0) then
        vec1=0.0 ; vec2=0.0
        write(*,'(2(a,f10.5),a)') &
             '     The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
        write(*,'(2(a,f10.5),a)') &
             '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
     else
        write(*,'(2(a,f10.5),a)') &
             '     The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
        write(*,'(2(a,f10.5),a)') &
             '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
     end if
     write(*,'(3(a,f10.5),a)') &
          '     The 3rd vector (perpendicular to XY) is   (',vec3(1),',',vec3(2),',',vec3(3),')'

     write(*,'(a)')  ' Tc. Tag C atoms'
     if(tagYES) then
        call print_long_char(lists,length,long_lists)
        write(*,'(5x,a,3(f10.5,x))') 'delta = ',delta(1:3)
        write(*,'(a)') '  S. Save tip positions in the directory structure'
     end if
     if(Yes_No) then
        write(*,'(a)')     ' No. Number of orbitals for each species:'
        write(*,'(5(10x,a,i5,a))') (Species(is)//' [',NoSp(is),'] ',is=1,Nsp)
        if(tagYES) then
           iAt=0  ; iorb=0 ; iorbf=0
           do is=1,Nsp
              do i=1,NspN(is)
                 iAt=iAt+1
                 iorbf=iorbf + NoSp(is)
                 if(.not.listat(iAt)) iorb=iorb+NoSp(is)
              end do
           end do
           write(*,'(a,i5)')      '     The T subsystem orbitals span from 1 to ',iorb
           write(*,'(2(a,i5))')   '     The C subsystem orbitals span from ',iorb+1,' to ',iorbf
           write(*,'(a)')  ' Sd. Save [input1.dat] file for the calculation of the current'
        end if
     else
        write(*,'(a)')     ' No. Number of orbitals for each species: UNDEFINED'
     end if
     
     write(*,'(a)')  ' ======================== S E T T I N G S =============================='
     if(CHIMERA) then
        if(YES_Lv) then
           write(*,'(a)') ' Vs. Show lattice vectors and vectors defining the box'
           write(*,'(a)') ' Lv. Show lattice vectors - YES'
        else
           write(*,'(a)') ' Vs. Show only vectors defining the box'
           write(*,'(a)') ' Lv. Show lattice vectors - NO'
        end if
     end if
     write(*,'(a)') ' An. [For input] Coordinates are specified in: '//angstr
     write(*,'(a)') ' Co. Show atomic positions '
     write(*,'(a)') '  Q. Quit.'
     write(*,*)
     write(*,*)'Specify the character and press ENTER ------->'
     read(*,'(a)',err=21) cha2  ; write(8,'(a)') cha2
     call right(cha2,2,l0)
     
![Tc].......... tag C atoms

     IF(cha2(l0:).eq.'Tc') THEN

        listat=.false. ; tagYES=.false.
     
        call TTag(tagYES,ITI,TI,Labels,listat,lists,length,N_lists,long_lists)
        do i=1,ITI
           if(listat(i)) then
              tagYES=.true. ;  exit
           end if
        end do

![No]........... give number of AOs for every species in the system

  ELSE IF(cha2(l0:).eq.'No') THEN

     Yes_No=.false.
     write(*,*)'Enter the number of AOs in CP2K corresponding to each species:'
     do is=1,Nsp
        write(*,*) 'Give the number of AOs for '//Species(is)//':'
        read(*,*,err=21) i
        if(i.lt.1) go to 21
        NoSp(is)=i
     end do
     Yes_No=.true.
     
![Sd].......... save input1.dat file for the calculation of the current

  ELSE IF(cha2(l0:).eq.'Sd' .and. TagYES .and. Yes_No) THEN

     open(19,file='input1.dat')
     write(19,'(2(i5,x),a)') iorb,iorbf,'  <= CT-system'
     close(19)
     
![Vs]...... show lattice vectors & box vectors
     
     ELSE IF(cha2(l0:).eq.'Vs' .and. CHIMERA) THEN
        
        open(35,file='vectors.vct',form='formatted',status='unknown')
        if(YES_Lv) then 
           write(35,*) '6'
           do i=1,3
              write(35,*) (AJ(i,j),j=1,3)
           end do
        else
           write(35,*) '3'
        end if
        write(35,*) vec1(1),vec1(2),' 0.0'
        write(35,*) vec2(1),vec2(2),' 0.0'
        write(35,*) vec3(1),vec3(2),vec3(3)
        close(35)

![An]...... choose the way how the coordinates are given

     ELSE IF(cha2(l0:).eq.'An') THEN
        
        if(angstr.eq.'<Angstroms> ') then
           angstr='<AtomNumber>'
        else if(angstr.eq.'<AtomNumber>') then
           angstr='<Angstroms> '
        end if

![Lv]...... show lattice vectors in CHINERA or not

     ELSE IF(cha2(l0:).eq.'Lv') THEN
        
        if(YES_Lv) then
           YES_Lv=.false.
        else 
           YES_Lv=.true.
        end if

![S].......... Save 
        
     ELSE IF(cha2(l0:).eq.'S' .and. tagYES) THEN

!______ determine positions of the tip atom(s) (leave C atoms alone) and save them in T_atoms.inc
!______________ IMPORTANT: atoms are reodered in the CP2K input !!! Also, no relaxation in method 3.

        write(*,*)'*** Enter the name of the input file [name.inp] containing:    ***'
        write(*,*)'***  [@include T_atoms.inc] statememnt in place of the T atoms ***'
        write(*,*)'***  [@include C_atoms.inc] statememnt in place of the C atoms ***'
        write(*,*)'***      { Enter the name without the .inp extension!  }       ***'

        read(*,'(a)') name ; write(*,'(a)') name
        call right(name,100,ln)

        open(19,file=name(ln:)//'.inp',status='old',iostat=io)
        if(io.eq.0) then
           write(*,*)'... file '//name(ln:)//'.inp exists. Proceed.'
           close (19)
        else
           write(*,*)'... file '//name(ln:)//'.inp does NOT exists.'
           go to 21
        end if

        TI1=TI
        do ix=0,NGX_
           call name_from_number(ix,chx,lx,err)
           do iy=0,NGY_
              call name_from_number(iy,chy,ly,err)
              do iz=NGZ_,0,-1
                 call name_from_number(iz,chz,lz,err)
                 
                 dir=chx(lx:)//'.'//chy(ly:)//'.'//chz(lz:)
                 ll=2+(5-lx)+(5-ly)+(5-lz)
                 write(*,*) '........... working directory ...> '//dir(1:ll)//' <...'
                                  
                 iA=0
                 do k=1,Nsp
                    do is=1,NspN(k)
                       iA=iA+1
                       if(.not.listat(iA)) then
                          if(NGX_.ne.0 .and. NGY_.ne.0) then
                             TI1(1,iA)= TI(1,iA) + delta(1) + ix*vec1(1)/NGX_ + iy*vec2(1)/NGY_
                             TI1(2,iA)= TI(2,iA) + delta(2) + ix*vec1(2)/NGX_ + iy*vec2(2)/NGY_
                          else if(NGX_.eq.0 .and. NGY_.ne.0) then
                             TI1(1,iA)= TI(1,iA) + delta(1) + iy*vec2(1)/NGY_
                             TI1(2,iA)= TI(2,iA) + delta(2) + iy*vec2(2)/NGY_
                          else if(NGX_.ne.0 .and. NGY_.eq.0) then
                             TI1(1,iA)= TI(1,iA) + delta(1) + ix*vec1(1)/NGX_
                             TI1(2,iA)= TI(2,iA) + delta(2) + ix*vec1(2)/NGX_
                          else if(NGX_.eq.0 .and. NGY_.eq.0) then
                             TI1(1,iA)= TI(1,iA) + delta(1) 
                             TI1(2,iA)= TI(2,iA) + delta(2) 
                          end if
                          if(NGZ_.eq.0) then
                             TI1(3,iA)= TI(3,iA) + delta(3)  
                          else
                             TI1(3,iA)= TI(3,iA) + delta(3) + iz*vec3(3)/NGZ_
                          end if
                       end if
                    end do
                 end do
                 
!______________ create file [T_atoms.inc] with atomic positions in each directory


                 open(19,file=dir(1:ll)//'/T_atoms.inc')
                 write(*,*)'... opened file '//dir(1:ll)//'/T_atoms.inc for saving T atoms positions'

!________ T atoms first 
                 iA=0
                 do k=1,Nsp
                    do is=1,NspN(k)
                       iA=iA+1 
                       if(.not.listat(iA)) then
                          write(19,'(a,3(x,f10.5))') Species(k),TI1(1:3,iA)
                       end if
                    end do
                 end do
                 
                 close(19)
                 write(*,*)'... file '//dir(1:ll)//'/T_atoms.inc closed'
                 
                 write(*,'(a)') 'cp '//name(ln:)//'.inp '//dir(1:ll)//'/input_CT.inp'
                 call system('cp '//name(ln:)//'.inp '//dir(1:ll)//'/input_CT.inp')
              end do
           end do
        end do
              
![Co].... display atomic positions

  ELSE IF(cha2(l0:).eq.'Co') THEN

     do iA=1,ITI
        if(listat(iA)) then
           reg(iA)='C'
        else
           reg(iA)='T'
        end if
     end do
     call show_atoms_EA(reg)

![Q]...... quit

  ELSE IF(cha2(l0:).eq.'Q') THEN
      
!.......... return the original settings

     return
  ELSE
     write(*,*) 'Wrong! Try again!'
  END IF
  go to 21

end subroutine EA_model_mesh_tip

