module Eff_at
  implicit none

  real*8 :: Cp(3), vec1(3),vec2(3),vec3(3)
!  Cp - position of the zero-vertex corner of the box
!  vec1 - vector from Cp along the first in-plane side of the box  
!  vec2 - vector from Cp along the second in-plane side of the box  
!  vec3 - vector from Cp along the 3rd side of the box ( _|_ to the surface plane)

  integer :: NGX_,NGY_,NGZ_
!  the grid in the box (from 0 to NGX_, etc.)
  logical :: cp2k_cur

  integer :: iperiodic
!  iperiodic =0 if not periodic and =1 if periodic
  
end module Eff_at

  
  
  
