real*8 function gamma1(w)
  use surface

!..... level width function  
  implicit none
  real*8 :: w,s
  integer :: k,m

  m=n_of_AOs-1
  s=0.0d0
  do k=1,n_of_states
     if(k.ne.i_He) then
        s=s+Dk(k)*Dk(k)*deltaf(w-eigval(k))
     end if
  end do
  gamma1=s*2*pi
  
end function gamma1

real*8 function re_se(w)
  use surface
!....... real part of the self-energy: calculated by eliminating the singularity  
  implicit none
  real*8 :: w,s,ww,deriv,re,gamma1
  integer :: i

  s=0.0d0
  do i=0,nw
     ww=W1+i*dw
     if(abs(w-ww).lt.dw) then
        deriv = (gamma1(w+0.01)-gamma1(w))/0.01
        s=s+deriv
        write(1,*) s,deriv
     else
        s=s+(gamma1(ww)-gamma1(w))/(ww-w)
     end if
  end do
  s=s*dw
  re = gamma1(w)*log(abs((W2+0.1-w)/(W1-0.1-w)))
  re_se = -(s + re)/(2*pi)
end function re_se

real*8 function transmission(w,V)
!..... for the current
!  V - voltage (eV)
!.... transmission function  
  use surface
  implicit none
  real*8 :: w,V,a,b,g,re_se,gamma1

  g=gamma1(w+V)
  a=w-E_at-re_se(w+V)
  b=Gamma_R + g
  transmission= (2.0/pi) * Gamma_R * g /( a*a+0.25*b*b )
  write(9,*) w,g,a,b
  
end function transmission

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

real*8 function current(V)
  use surface
!..... current
!  V  - voltage (eV)
  implicit none
  real*8 :: V,s,eps=0.001,w,ff,f1,f2,transmission
  integer :: i
  logical :: first

  first=.false.
  s=0.0d0
  do i=0,nw
     w=W1+i*dw
     ff=fermi(w)-fermi(w+V)
     if(abs(ff).gt.eps) then
        if(.not.first) then
           first=.true.
           f1=w
        end if
        s=s+ff*transmission(w,V)
        write(9,'(i5,3(e12.6,x)/)') i,w,ff,s
    else
        if(first) then
           f2=w
           exit
        end if
     end if
  end do
  current=s*dw
  write(9,*) 'V = ',V,' energies = [ ',f1,',',f2,' ]'
end function current
