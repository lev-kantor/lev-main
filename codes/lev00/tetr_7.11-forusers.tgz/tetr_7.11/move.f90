program move
!...............................................................................
! an auxiliary routine for the SC calculation (method 3) to ensure the tip
! (subsystem C) at each grid point starts from the previously relaxed geometry 
! before the shift to the correct position of that grid point
!...............................................................................
  implicit none
  real*8,dimension(:,:),allocatable :: TI
  real*8 :: displ_delta(3)
  integer :: i,ITI,nat,iErr,iC0,iC1,io
  integer :: LinEnd(100),LinPos(100),NumLin
  character :: line*200
  character,dimension(:),allocatable :: species*2

!..... reading coordinates_prev.inc for the atomic positions  

  i=0
  open(1,file='coordinates_prev.inc',status='old',iostat=io)
  if(io.ne.0) go to 10
  write(*,*)'[1] ...opening file [coordinates_prev.inc] ...'
  do
     read(1,'(a)',end=1) line
     i=i+1
  end do
1 ITI=i
  write(*,*)'found ',ITI,' lines'
  allocate(TI(3,ITI),species(ITI))

  rewind(1)
  do nat=1,ITI
     call CutStr(Line,NumLin,LinPos,LinEnd,1,0,iErr)
     if(iErr.ne.0) go to 10
     if(LinEnd(1)-LinPos(1).eq.0) then
        species(nat)=' '//line(LinPos(1):LinEnd(1))
     else
        species(nat)=line(LinPos(1):LinEnd(1))
     end if
     read(line(LinPos(2):LinEnd(4)),*) TI(1:3,nat)
  end do  
  close(1)
  write(*,*)'[1] ... file [coordinates_prev.inc] closed ...'

!..... reading info.dat to determine the shift vector  

  open(1,file='info.dat',status='old',iostat=io)
  if(io.ne.0) go to 20
  write(*,*)'[2] ...opening file [info.dat] ...'
  read(1,*)
  read(1,*) displ_delta
  read(1,*) iC0,iC1
  close(1)
  write(*,*)'[2] ...file [info.dat] closed ...'

!..... moving dsignated atoms

  open(1,file='coordinates_new.inc',status='unknown',iostat=io) 
  if(io.ne.0) go to 30
  write(*,*)'[3] ...opening file [coordinates_new.inc] ...'
  do nat=1,ITI
     if(nat.ge.iC0 .and. nat.le.iC1) then
        TI(1:3,nat)=TI(1:3,nat)+displ_delta(1:3)
     end if
     write(1,'(a,x,3(x,f10.5))') species(nat),TI(1:3,nat)
  end do
  close(1)
  write(*,*)'[3] ...file [coordinates_new.inc] closed ...'
  stop
  
!...... errors
10 write(*,*)'ERROR: file [coordinates_prev.inc] is bad or absent'
   stop
20 write(*,*)'ERROR: file [info.dat] is bad or absent'
   stop
30 write(*,*)'ERROR: file [coordinates_new.inc] cannot be opened'
   stop
end program move

      subroutine CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iCom,iErr)
      implicit none
!.................................................................
!....It reads the line from the file UNIT=NFIL as a string   .....
!.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
!.... substrings. Their number is NumLin, while starting and .....
!.... ending positions are LinPos and LinEnd.                .....
!.................................................................
! Up to 100 substrings is implied to be in the initial string Line.
!.................................................................
!  If NFIL=0 it is assumed that the string Line*80 exists and
!  must not be read from the external source, but must be taken
!  as an input from the parent program
!.................................................................
!  iErr=1 in the case of error input; oterwise iErr=0
!.................................................................
!  Commas are also interpreted as string division symbols
!  alongside spaces if iCom=1; not, if iCom=/=1.
!.................................................................
!  Equal signs are also interpreted as string division symbols
!  alongside spaces if iCom=2; not, if iCom=/=2.
!.................................................................
!
      character :: Line*200
      character :: cha
      integer :: LinEnd(100),LinPos(100),NumLin
!
      integer :: iErr,iCom,NFIL,i,i0,icase

      iErr=0
      if(NFIL.ne.0)  then
         if(iErr.ne.0) go to 10
         read (NFIL,'(a)',err=10,end=10) Line
      end if
      NumLin=0 ; icase=0
!............ replace commas, if present, by spaces
      if(iCom.eq.1) then
         do i=1,200
            if(Line(i:i).eq.',') Line(i:i)=' '
         end do
      end if
!............ replace equal sign, if present, by spaces
      if(iCom.eq.2) then
         do i=1,200
            if(Line(i:i).eq.'=') Line(i:i)=' '
         end do
      end if
!............ Loop over all characters in the Line(1:200)............
      do 5 i=1,200
         i0=i
         cha=Line(i:i)
!________ if the 1st not blank character is found
         if(cha.ne.' '.and.cha.ne.'     '.and.icase.eq.0) then
            NumLin=NumLin+1
            if(NumLin.gt.100) go to 10
            LinPos(NumLin)=i
            icase=1
         end if
!_________ if the 1st blank character is found after the substring
         if(cha.eq.' '.and.icase.eq.1) then
            LinEnd(NumLin)=i-1
            icase=0
         end if
 5    end do
      if(icase.eq.1) LinEnd(NumLin)=200
      return
 10   iErr=1
      return
      end subroutine CutStr
