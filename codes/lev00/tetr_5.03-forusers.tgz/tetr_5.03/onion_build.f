      subroutine onion_build(Which_Code)
c......................................................................
c construct a cell which has layers (e.g. for SBC)
c......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'

      character Which_Code*6

 21   
