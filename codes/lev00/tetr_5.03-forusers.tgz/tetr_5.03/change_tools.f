      subroutine ask_breeding_box(M1,N1,M2,N2,M3,N3)
      include 'real8.inc'
 34   write(*,*)
     &     '....................................................'
      write(*,*)
     &     'Breeding box will be [M1,N1] x [M2,N2] x [M3,N3]:'
      write(*,*)'Take M1=M2=M3=0 to have atoms of your original cell'
      write(*,*)'going first in the supercell. Alternatively,'
      write(*,*)
     &     'apply an appropriate shift to the system afterwards.'
      write(*,*)
     &     '....................................................'
      write(*,*) 'Specify M1,N1 in the direction of AJ(1)'
      read(*,*,err=34) M1,N1
      if(M1.gt.N1) go to 34
      write(*,*) 'Specify M2,N2 in the direction of AJ(2)'
      read(*,*,err=34) M2,N2
      if(M2.gt.N2) go to 34
      write(*,*) 'Specify M3,N3 in the direction of AJ(3)'
      read(*,*,err=34) M3,N3
      if(M3.gt.N3) go to 34
      return
      end

      subroutine create_xyz(M1,N1,M2,N2,M3,N3,YES_xyz,Add_Hs)
c................................................................
c write geom.xyz file for XMOL
c................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      character YES_xyz*4
      dimension x(3)
      logical Err,Add_Hs

c__________ open xyz file

      L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
      open(37,file='geom.xyz',form='formatted',status='unknown')
      nnn=ITI*L_ext
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(37,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(37,'(a/i5)') '1',nnn
      end if

c___________ constract all lattice sites         

      nat=0
      DO i=1,Nsp
         call check_Mendel(Species(i),mendl,Err,.false.)

         do i1=M1,N1
            do i2=M2,N2
               do i3=M3,N3
                  
                  DO k=1,NspN(i)
                     x(1)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+
     +                    TI(1,k+nat)
                     x(2)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+
     +                    TI(2,k+nat)
                     x(3)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+
     +                    TI(3,k+nat)
                     if(YES_xyz.eq.'Xmol') then
                        write(37,'(a2,5x,3(f16.10,1x),a)') 
c     &                       Species(i),(x(j),j=1,3),' 0 0 0'
     &                       Species(i),(x(j),j=1,3)
                     else if(YES_xyz.eq.'Ymol') then
                        write(37,'(i2,5x,3(f16.10,1x))') 
     &                                    mendl,(x(j),j=1,3)
                     end if
                  END DO
                  
               end do
            end do
         end do
         nat=nat+NspN(i)
         
      END DO
      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(37,'(a)')'2     0.0 0.0 0.0  '
         write(37,'(a)')'3     15.0 0.0 0.0 '
         write(37,'(a)')'4     0.0 15.0 0.0 '
         write(37,'(a)')'5     0.0 0.0 15.0 '
      end if
      close (37)
      end

      subroutine create_xyz1(M1,N1,M2,N2,M3,N3,YES_xyz,Add_Hs,
     ,           Num_Vects,Add_Vects)
c................................................................
c write geom.xyz file for XMOL
c................................................................
c This is a special version for CHANGE() which can preview up to
c 5 vectors on top of the axes
c................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      character YES_xyz*4
      dimension x(3),Add_Vects(5,3)
      logical Err,Add_Hs
      integer Num_Vects

c__________ open xyz file

      L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
      open(37,file='geom.xyz',form='formatted',status='unknown')
      if(CHIMERA) then
         nnn=ITI*L_ext
      else
         nnn=ITI*L_ext+Num_Vects
      end if
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(37,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(37,'(a/i5)') '1',nnn
      end if

c___________ constract all lattice sites         

      nat=0
      DO i=1,Nsp
         call check_Mendel(Species(i),mendl,Err,.false.)

         do i1=M1,N1
            do i2=M2,N2
               do i3=M3,N3
                  
                  DO k=1,NspN(i)
                     x(1)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+
     +                    TI(1,k+nat)
                     x(2)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+
     +                    TI(2,k+nat)
                     x(3)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+
     +                    TI(3,k+nat)
                     if(YES_xyz.eq.'Xmol') then
                        write(37,'(a2,5x,3(f16.10,1x),a)') 
     &                       Species(i),(x(j),j=1,3)
c     &                       Species(i),(x(j),j=1,3),' 0 0 0'
                     else if(YES_xyz.eq.'Ymol') then
                        write(37,'(i2,5x,3(f16.10,1x))') 
     &                                    mendl,(x(j),j=1,3)
                     end if
                  END DO
                  
               end do
            end do
         end do
         nat=nat+NspN(i)
         
      END DO
      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(37,'(a)')'2     0.0 0.0 0.0  '
         write(37,'(a)')'3     15.0 0.0 0.0 '
         write(37,'(a)')'4     0.0 15.0 0.0 '
         write(37,'(a)')'5     0.0 0.0 15.0 '
      end if
      if(Num_Vects.gt.0 .and. (.not.CHIMERA)) then
         do i=1,Num_Vects
            write(37,'(a,3(x,f10.5))')
     &           'H 0.0 0.0 0.0 atom_vector ',Add_Vects(i,1:3)
         end do
      end if
      close (37)
      end
 
      subroutine check_symmetry(yes_inversion,yes_symm)
c....................................................................
c....... check the symmetry of your system ..........................
c....................................................................
c yes_inversion = 'y' - the inversion will be included into the 
c                       system group GroupN (for the DOS);
c yes_inversion = 'n' - the inversion won't be included into GroupN
c                       (when invoked from 'change' just to test 
c                       the group)
c yes_symm = 'y'  - determine the best symmetry
c          = 'n'  - no symmetry
c The inversion is always present in the BZ (no matter what is the
c real point group) because of the time-reversal symmetry. So, the
c inversion must be included for the DOS calculations.
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      character yes_inversion,yes_symm

c________ obtain the group GroupB of the Bravais lattice (crystal 
c         class) with MGb, KGb
c
      call bravais()
      write(*,*)
      write(*,*)'______ Your crystal class group is '//GroupB//
     &     ' with elements:'
      write(*,'(12(a4,1x))') (NAZ(KGb(i)),i=1,MGb)
      write(*,*)
      if(yes_symm.eq.'n') then
         write(*,*)'>>>>>>>>>>> NO SYMMETRY <<<<<<<<<<<'
         MGb=1
      end if
c
c________ obtain the laggest symmorphic group GroupN of the system
c         with MGp, KGp
c
      call system_gr(yes_inversion)
      write(*,*)
      write(*,*)'______ Your largest symmorphic group is '//GroupN//
     &     ' with elements:'
      write(*,'(12(a4,1x))') (NAZ(KGp(i)),i=1,MGp)
      write(*,*)
      return
      end

      subroutine keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c.................................................................
c
c Save lattice vectors AJ in AY(number,component) and all
c atoms TI in TI2(comp,number). BJ is kept in BY as well.
c.................................................................
c  All is stored in /buffer1/
c.................................................................
      include 'real8.inc'
      dimension AJ(3,3),TI(3,N0LT),BJ(3,3),NspN(N0KD)
      character relax_flag(3,N0LT)
      common /buffer1/ AY(3,3),TI3(3,N0LT),BY(3,3),ITI3,
     ,     NspN3(N0KD),Nsp3,Species3(N0KD),relax_flag3(3,N0LT)
      character Species3*2,Species(N0KD)*2,relax_flag3
      ITI3=ITI
      do i=1,3
        do i1=1,3
          AY(i,i1)=AJ(i,i1)
          BY(i,i1)=BJ(i,i1)
        end do
      end do
      do k=1,ITI
         TI3(1,k)=TI(1,k)
         TI3(2,k)=TI(2,k)
         TI3(3,k)=TI(3,k)
         relax_flag3(1,k)=relax_flag(1,k)
         relax_flag3(2,k)=relax_flag(2,k)
         relax_flag3(3,k)=relax_flag(3,k)
      end do
      Nsp3=Nsp
      do k=1,Nsp
         NspN3(k)=NspN(k)
         Species3(k)=Species(k)
      end do
      return
      end

      subroutine restore_geom1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c.................................................................
c Restore lattice vectors AJ, etc. 
c.................................................................
c  All is stored in /buffer1/
c.................................................................
      include 'real8.inc'
      dimension AJ(3,3),TI(3,N0LT),BJ(3,3),NspN(N0KD)
      character relax_flag(3,N0LT)
      common /buffer1/ AY(3,3),TI3(3,N0LT),BY(3,3),ITI3,
     ,     NspN3(N0KD),Nsp3,Species3(N0KD),relax_flag3(3,N0LT)
      character Species3*2,Species(N0KD)*2,relax_flag3
      ITI=ITI3
      do i=1,3
        do i1=1,3
          AJ(i,i1)=AY(i,i1)
          BJ(i,i1)=BY(i,i1)
        end do
      end do
      do k=1,ITI
         TI(1,k)=TI3(1,k)
         TI(2,k)=TI3(2,k)
         TI(3,k)=TI3(3,k)
         relax_flag(1,k)=relax_flag3(1,k)
         relax_flag(2,k)=relax_flag3(2,k)
         relax_flag(3,k)=relax_flag3(3,k)
      end do
      Nsp=Nsp3
      do k=1,Nsp
         NspN(k)=NspN3(k)
         Species(k)=Species3(k)
      end do
      return
      end

      subroutine keep_mol_index(iMol,Mol_index,ITI)
c.................................................................
c keeps division of the system into parts
c.................................................................
c  All is stored in /buffer/
c.................................................................
      include 'real8.inc'
      common /buffer_index/ Mol_index1(N0LT),iMol1
      dimension Mol_index(N0LT)
      iMol1=iMol
      do k=1,ITI
         Mol_index1(k)=Mol_index(k)
      end do
      return
      end

      subroutine restore_mol_index(iMol,Mol_index,ITI)
c.................................................................
c keeps division of the system into parts
c.................................................................
c  All is stored in /buffer/
c.................................................................
      include 'real8.inc'
      common /buffer_index/ Mol_index1(N0LT),iMol1
      dimension Mol_index(N0LT)
      iMol=iMol1
      do k=1,ITI
         Mol_index(k)=Mol_index1(k)
      end do
      return
      end

      subroutine initial_mol_index(iMol,Mol_index,BSSE_tag)
c.................................................................
c keeps division of the system into parts
c.................................................................
c  All is stored in /buffer/
c.................................................................
      include 'real8.inc'
      logical BSSE_tag
      dimension Mol_index(N0LT)
      iMol=0
      do k=1,N0LT
         Mol_index(k)=0
      end do
      BSSE_tag=.false.
      return
      end

      subroutine keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,
     ,                           relax_flag,Genrt)
c.................................................................
c Save lattice vectors AJ in AX(number,component) and all
c atoms TI in TI1(comp,number). BJ is kept in BX as well.
c.................................................................
c  All is stored in /buffer/
c.................................................................
      include 'real8.inc'
      dimension AJ(3,3),TI(3,N0LT),BJ(3,3),NspN(N0KD)
      character relax_flag(3,N0LT)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,Species(N0KD)*2,relax_flag1
      logical Genrt(N0LT),Genrt1
      ITI1=ITI
      do i=1,3
        do i1=1,3
          AX(i,i1)=AJ(i,i1)
          BX(i,i1)=BJ(i,i1)
        end do
      end do
      do k=1,ITI
         TI1(1,k)=TI(1,k)
         TI1(2,k)=TI(2,k)
         TI1(3,k)=TI(3,k)
         relax_flag1(1,k)=relax_flag(1,k)
         relax_flag1(2,k)=relax_flag(2,k)
         relax_flag1(3,k)=relax_flag(3,k)
         Genrt1(k)=Genrt(k)
      end do
      Nsp1=Nsp
      do k=1,Nsp
         NspN1(k)=NspN(k)
         Species1(k)=Species(k)
      end do
      return
      end

      subroutine keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c.................................................................
c Save lattice vectors AJ in AX(number,component) and all
c atoms TI in TI1(comp,number). BJ is kept in BX as well.
c.................................................................
c  All is stored in /buffer0/
c.................................................................
      include 'real8.inc'
      dimension AJ(3,3),TI(3,N0LT),BJ(3,3),NspN(N0KD)
      character relax_flag(3,N0LT)
      common /buffer0/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     ,     NspN1(N0KD),Nsp1,Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,Species(N0KD)*2,relax_flag1
      ITI1=ITI
      do i=1,3
        do i1=1,3
          AX(i,i1)=AJ(i,i1)
          BX(i,i1)=BJ(i,i1)
        end do
      end do
      do k=1,ITI
         TI1(1,k)=TI(1,k)
         TI1(2,k)=TI(2,k)
         TI1(3,k)=TI(3,k)
         relax_flag1(1,k)=relax_flag(1,k)
         relax_flag1(2,k)=relax_flag(2,k)
         relax_flag1(3,k)=relax_flag(3,k)
      end do
      Nsp1=Nsp
      do k=1,Nsp
         NspN1(k)=NspN(k)
         Species1(k)=Species(k)
      end do
      return
      end

      subroutine restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,
     ,     relax_flag,Genrt)
c.................................................................
c Restore AJ, BJ and TI from /buffer/ values.
c.................................................................
      include 'real8.inc'
      dimension AJ(3,3),TI(3,N0LT),BJ(3,3),NspN(N0KD)
      character relax_flag(3,N0LT)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,Species(N0KD)*2,relax_flag1
      logical Genrt(N0LT),Genrt1
      ITI=ITI1
      do i=1,3
        do i1=1,3
          AJ(i,i1)=AX(i,i1)
          BJ(i,i1)=BX(i,i1)
        end do
      end do
      do k=1,ITI
         TI(1,k)=TI1(1,k)
         TI(2,k)=TI1(2,k)
         TI(3,k)=TI1(3,k)
         relax_flag(1,k)=relax_flag1(1,k)
         relax_flag(2,k)=relax_flag1(2,k)
         relax_flag(3,k)=relax_flag1(3,k)
         Genrt(k)=Genrt1(k)
      end do
      Nsp=Nsp1
      do k=1,Nsp
         NspN(k)=NspN1(k)
         Species(k)=Species1(k)
      end do
      return
      end

      subroutine restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,
     ,     relax_flag)
c.................................................................
c Restore AJ, BJ and TI from /buffer0/ values.
c.................................................................
      include 'real8.inc'
      dimension AJ(3,3),TI(3,N0LT),BJ(3,3),NspN(N0KD)
      character relax_flag(3,N0LT)
      common /buffer0/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     ,     NspN1(N0KD),Nsp1,Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,Species(N0KD)*2,relax_flag1
      ITI=ITI1
      do i=1,3
        do i1=1,3
          AJ(i,i1)=AX(i,i1)
          BJ(i,i1)=BX(i,i1)
        end do
      end do
      do k=1,ITI
         TI(1,k)=TI1(1,k)
         TI(2,k)=TI1(2,k)
         TI(3,k)=TI1(3,k)
         relax_flag(1,k)=relax_flag1(1,k)
         relax_flag(2,k)=relax_flag1(2,k)
         relax_flag(3,k)=relax_flag1(3,k)
      end do
      Nsp=Nsp1
      do k=1,Nsp
         NspN(k)=NspN1(k)
         Species(k)=Species1(k)
      end do
      return
      end

      subroutine remove_atoms(NumRem1,NumRem2,speak,ladder)
c...................................................................
c  removes atoms numbers from NumRem1 to NumRem2 from the cell
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      logical speak,ladder

      Nsp1=Nsp
      Nrem=NumRem2-NumRem1+1
c___________remove atoms from the TI/ITI list
      if(NumRem2.lt.ITI) then
         do k=NumRem2+1,ITI
            k1=k-Nrem
            TI(1,k1)=TI(1,k)
            TI(2,k1)=TI(2,k)
            TI(3,k1)=TI(3,k)
            relax_flag(1,k1)=relax_flag(1,k)
            relax_flag(2,k1)=relax_flag(2,k)
            relax_flag(3,k1)=relax_flag(3,k)
            Genrt(k1)=Genrt(k)
            Mol_index(k1)=Mol_index(k)
         end do
      end if
      ITI=ITI-Nrem

c___________remove atoms from the NspN/Nsp list
      k=0
      do i=1,Nsp
         NspN3=NspN(i)
         do j=1,NspN(i)
            k=k+1
            if(k.ge.NumRem1.and.k.le.NumRem2) NspN3=NspN3-1
         end do
         NspN(i)=NspN3
      end do

c___________remove species with zero numbers of atoms
      if(ladder) then
         i=Nsp
 82      if(NspN(i).eq.0) then
            if(speak) write(8,*)'WARNING! Species ',i,' has gone!'
            if(i.lt.Nsp) then
               do l=i+1,Nsp
                  NspN(l-1)=NspN(l)
                  Species(l-1)=Species(l)
               end do
            end if
            Nsp=Nsp-1
         end if
         i=i-1
         if(i.gt.0) go to 82
         if(speak.and.Nsp.ne.Nsp1) then
            write(*,*)'WARNING! Number of species changed!'
            write(*,*)'         New number of species = ',Nsp
         end if
      end if

c___________ restore partition index in case the whole part was removed
 9    if(iMol.eq.0) return
      im=0
 10   im=im+1
      if(im.gt.iMol) return
      do i=1,ITI
         if(Mol_index(i).eq.im) go to 10
      end do
      do i=1,ITI
         if(Mol_index(i).gt.im) Mol_index(i)=Mol_index(i)-1
      end do
      iMol=iMol-1
      go to 9
      end

      subroutine add_atom(x,jsp,errr,speak,flag1,flag2,flag3,ion,listat)
c...................................................................
c  add an atom at x(), species jsp, to the cell
c  flag1,2,3 - relaxation flags 
c  ion - atomic number of the added atom
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension x(3),r(3)
      character flag1,flag2,flag3
      logical errr,speak,ask_equiv,listat(N0LT)

      errr=.false.
c______ check the new atom
      do k=1,ITI
         r(1:3)=TI(1:3,k)-x(1:3)
         if(ask_equiv(r,BJ,3,tiny_equiv)) then
            if(speak) write(*,*)
     &           'ERROR! The NEW atom is equivalent to atom ',k
            errr=.true. ;  return
         end if
      end do

c______ move atoms in TI/ITI
      ion=ITI+1
      if(jsp.lt.Nsp) then
         do j=Nsp,jsp+1,-1
            do k=NspN(j),1,-1
               ion=ion-1  ; TI(1:3,ion+1)=TI(1:3,ion)
               relax_flag(1:3,ion+1)=relax_flag(1:3,ion)
               listat(ion+1)=listat(ion)
               Mol_index(ion+1)=Mol_index(ion)
            end do
         end do
      end if
      TI(1:3,ion)=x(1:3)
      relax_flag(1,ion)=flag1 
      relax_flag(2,ion)=flag2 
      relax_flag(3,ion)=flag3
      listat(ion)=.false. ; Mol_index(ion)=0 ; ITI=ITI+1
 
c______ move atoms in NspN/Nsp
      NspN(jsp)=NspN(jsp)+1 ; if(jsp.eq.Nsp+1) Nsp=Nsp+1

      if(speak)  write(8,'(a,i5)')
     &     'O.K.! This position is fine! Adding as # ',ion
      
      return
      end

      integer function jsp_species(Species2,Species,Nsp)
c........................................................................
c checking if Species2 is new or coicides with any of the old ones
c........................................................................
      character Species2*2,Species(Nsp)*2
      do js=1,Nsp
         if(Species(js).eq.Species2) then
            jsp_species=js
            return
         end if
      end do
      jsp_species=0
      end

      subroutine ask_displacement(angstr,dir,dmove,dd,FinPos,nat1,back)
c................................................................
c  ask how to displace atoms
c................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension dir(3),x(3),r(3)
      character angstr*12,angstr1*12
      logical FinPos,back
      data tiny/0.00001/
      back=.false.
      angstr1=angstr

c___________ ask about the target.
c            Mind: method 3 works only for a single atom to be displaced

 94   write(*,*)
     &  '---------- Specify the method to displace atom(s):----------'
      write(*,*)
     &   '  1. DIRECTION: 2 points (e.g. 2 atoms): primary and target'
      write(*,*)'  2. DIRECTION: or a vector'
      if(FinPos)
     &         write(*,*)'  3. FINAL POSITION: in Cartesian coordinates'
      write(*,*)'  4. DISPLACEMENT:   in Cartesian coordinates'
      write(*,*)
     &     '------------------ setting ------------------------------'
      write(*,*)
     &      '  5. [For input] Coordinates are specified in: '//angstr1
      write(*,*)
     &     '---------------------------------------------------------'
      write(*,*)'  6. QUIT: return to the menu and do nothing!'
      write(*,*)'----------> Choose an appropriate option:'
      read(*,*,err=94) methd
      if(methd.eq.1) then
         write(*,*)'Specify the primary point:'
         call givepoint(x(1),x(2),x(3),angstr)
         write(*,*)'Specify the target point:'
         call givepoint(r(1),r(2),r(3),angstr)
         dir(1)=r(1)-x(1)
         dir(2)=r(2)-x(2)
         dir(3)=r(3)-x(3)
 95      write(*,*)
     &           'Specify how to move towards the target (in Agstroms):'
         write(*,*)' 1. By some distance'
         write(*,*)
     &      ' 2. Primary point to be some distance away from the target'
         read(*,*,err=95) meth
         if(meth.ne.1.and.meth.ne.2) go to 95
      else if(methd.eq.2) then
 92      write(*,*)'Specify the direction vector:'
         read(*,*,err=92) dir
      else if(FinPos.and.methd.eq.3) then
 93      write(*,*)'Specify the final position in Cartesian:'
         read(*,*,err=93) r
         dir(1)=r(1)-TI(1,nat1)
         dir(2)=r(2)-TI(2,nat1)
         dir(3)=r(3)-TI(3,nat1)
      else if(methd.eq.4) then
 90      write(*,*)'Specify the displacement vector in Cartesian:'
         read(*,*,err=90) dir
      else if(methd.eq.5) then
         if(angstr1.eq.'<Fractional>') then
            angstr1='<Angstroms> '
         else if(angstr1.eq.'<Angstroms> ') then
            angstr1='<AtomNumber>'
         else if(angstr1.eq.'<AtomNumber>') then
            angstr1='<Fractional>'
         end if 
         go to 94
      else if(methd.eq.6) then
         back=.true.
         return
      else
         go to 94
      end if
      dd=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
      if(dd.lt.tiny) then
         write(*,'(a)')'Displacement direction: do NOT move'
      else
         write(*,'(a,3(x,f10.5))')
     &        'Displacement direction: ',(dir(i)/dd,i=1,3)
      end if

c___________ ask the distance
      if(methd.eq.1.or.methd.eq.2) then
 96      write(*,*)'Specify the distance (in Angstrems):'
         read(*,*,err=96) dists
         if(methd.eq.2 .or. meth.eq.1) then
            dmove=dists
         else
            dmove=dd-dists
         end if
         write(*,'(a,f10.5,a)')
     &        'Atoms in the list will be moved by ',dmove,' A'
      else if(methd.eq.4.or.methd.eq.3) then
         dmove=dd
      end if
      return
      end

      subroutine normal_3points(x1,x2,x3,rn,angstr)
c..........................................................................
c normal vector rn() to three points is obtained 
c..........................................................................
      include 'real8.inc'
      dimension rn(3),x1(3),x2(3),x3(3),x(3),y(3)
      character angstr*12
      logical err
      data tiny/0.000001/

 11   write(*,*)'Specify the first atom/point:'
      call givepoint(x1(1),x1(2),x1(3),angstr)
      write(*,*)'Specify the second atom/point:'
      call givepoint(x2(1),x2(2),x2(3),angstr)
      write(*,*)'Specify the third atom/point:'
      call givepoint(x3(1),x3(2),x3(3),angstr)
      do i=1,3
         x(i)=x2(i)-x1(i)
         y(i)=x3(i)-x1(i)
      end do
c___________work out the unit normal vector to the plane
      call vect_prod(x,y,rn,.true.,err)
      if(err) then
         write(*,*)'ERROR! Try again, plane cannot be defined'
         go to 11
      end if
      write(8,'(a,3(x,f10.5))')
     &            'Normal to the plane found = ', (rn(i),i=1,3)
      return
      end

      subroutine show_atoms(listat)
      include 'real8.inc'
      include 'tetrag1.inc'
      logical listat(N0LT)
      character cha
      open(331,file='atoms.xyz',status='unknown')
      k=0
      do i=1,Nsp
         write(331,'(3a,i5)')'.... Species <',Species(i),'> ......> ',i
         write(331,'(a)')
     &        '  Tot    #   |----------  Fractional ---------|'
     &        //'-------------  Cartesian ---------| Relax  Tag   Part'
         write(*,'(3a,i5)')'.... Species <',Species(i),'> ......> ',i
         write(*,'(a)')'  Tot    #   |----------  Fractional ---------|'
     &        //'-------------  Cartesian ---------| Relax  Tag   Part'
         do j=1,NspN(i)
            k=k+1
            a1=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
            a2=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
            a3=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
            if(listat(k)) then
               cha='Y'
            else
               cha=' '
            end if
            write(*,'(2(x,i5),x,3(x,f10.5),2x,3(x,f10.5),3x,2(a,4x),
     ,           i3)')  k,j,a1,a2,a3,(TI(j1,k),j1=1,3),
     ,           relax_flag(1,k)//relax_flag(2,k)//relax_flag(3,k),
     ,           cha,Mol_index(k)
            write(331,'(2(x,i5),x,3(x,f10.5),2x,3(x,f10.5),3x,2(a,4x),
     ,           i3)')  k,j,a1,a2,a3,(TI(j1,k),j1=1,3),
     ,           relax_flag(1,k)//relax_flag(2,k)//relax_flag(3,k),
     ,           cha,Mol_index(k)
         end do
      end do
      close (331)
      write(*,*)'Hit ENTER when done ...'
      read(*,*)
      return
      end

      subroutine show_atoms_notag()
      include 'real8.inc'
      include 'tetrag1.inc'
      k=0
      do i=1,Nsp
         write(*,'(3a,i5)')'.... Species <',Species(i),'> ......> ',i
         write(*,'(a)')' Tot   # |----------  Fractional ---------|'
     &        //'-------------  Cartesian ---------| Relax'
         do j=1,NspN(i)
            k=k+1
            a1=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
            a2=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
            a3=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
            write(*,'(2(x,i3),x,3(x,f10.5),2x,3(x,f10.5),3x,a)') 
     &           k,j,a1,a2,a3,(TI(j1,k),j1=1,3),
     ,           relax_flag(1,k)//relax_flag(2,k)//relax_flag(3,k)
         end do
      end do
      write(*,*)'Hit ENTER when done ...'
      read(*,*)
      return
      end

      subroutine 
     &   find_neighbours_for_M(m_at,xn,n_of_neighb,isp,wdth_nn)
c..................................................................
c  finds n_of_neighb neighbours for atom m_at in the cluster which
c  are:
c
c    (1) may be in the cluster already (it is not checked here!)
c    (2) are closest to the atom n_at (within a belt of width wdth_nn)
c    (3) are all of the same species (but not necessarily the
c        same as atom n_at)
c
c  isp       - the species of the newly found atoms
c  xn(xyz,i) - positions of all nn atoms i=1,n_of_neighb
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      common /reference/ AZ(3,3),TIz(3,N0LT),ITIz,
     ,                      NspNz(N0KD),Nspz,Speciesz(N0KD)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      dimension xn(3,neighb0),r(3)
      character Species1*2,Speciesz*2,relax_flag1
      logical Genrt1
      data tiny/0.000001/

      do i=1,3
         write(17,'(a,i1,3(x,f10.5))') 'AZ => ',i, AZ(i,1:3)
      end do

      xmin=1.e10 ; n=0 ; nat=0
      do i=1,Nspz
         do j=1,NspNz(i)
            nat=nat+1

            do i1=-2,2
               do i2=-2,2
                  do i3=-2,2
                     r(1:3)=i1*AZ(1,1:3)+i2*AZ(2,1:3)+i3*AZ(3,1:3)+
     +                    TIz(1:3,nat)-TI1(1:3,m_at)
                     ar=sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3))
                     if(ar.lt.xmin-wdth_nn .and. ar.gt.tiny) then
                        xmin=ar ; isp=i ; n=1 ;  xn(1:3,1)=r(1:3)
                     else if(abs(ar-xmin).lt.wdth_nn 
     &                                         .and. i.eq.isp) then
                        n=n+1 ; xn(1:3,n)=r(1:3)
                     end if
                  end do
               end do
            end do

         end do
      end do               
      n_of_neighb=n

      write(*,*)'_________> atoms found:'
      do n=1,n_of_neighb
         write(*,'(i2,x,a2,x,3(x,f10.5))') 
     &                               n,Speciesz(isp),(xn(j,n),j=1,3)
      end do
      return
      end

      subroutine normal_to_plane(AJ)
c.............................................................................
c choose the plane by specifying either a normal vector or directly the Miller 
c indices HH,KK,LL.  
c.............................................................................
      include 'real8.inc'
      dimension AJ(3,3),vn(3),AJ1(3,3),IJ(3,3),BJ1(3,3),AI(3,3),JI(3,3)
      integer HH,KK,LL
      logical Yes_nv,Yes_Done
      character cha2*2
      data tiny_equiv/0.0001/
      
      IJ=0 ; AI=AJ ; IJ(1,1)=1 ; IJ(2,2)=1 ; IJ(3,3)=1  
      Yes_nv=.false. ; Yes_Done=.false.
 21   write(*,'(a)') 
     &'====================> the METHOD: <===========================',
     &' a. Here, the plane is worked out from the direction of its',
     &'    normal. This can be given directly or via Miller indices.',
     &' b. Miller indices are convenient, but refer to the',
     &'    crystallographic cell (CC).',
     &' c. Try the extension option Su to construct the CC and then',
     &'    specify the Miller indices to it to work out the direction',
     &'    of the normal. Then you can redefine the vectors with CP.'
c     &' d. For some simple cases you can try option ET which may find',
c     &'    the smallest CC (with right angles) for your current cell.',
c     &'    Then specify Miller indices to it as above.',

      write(*,'(/a/a/)')
     &'>>> MODIFY BULK CELL: get two basic vectors WITHIN A PLANE <<<',
     &'>>>>>>>>>     Use either of the TWO METHODS below     <<<<<<<<'
      do k=1,3
         AJ1(1,k)=IJ(1,1)*AI(1,k)+IJ(1,2)*AI(2,k)+IJ(1,3)*AI(3,k)
         AJ1(2,k)=IJ(2,1)*AI(1,k)+IJ(2,2)*AI(2,k)+IJ(2,3)*AI(3,k)
         AJ1(3,k)=IJ(3,1)*AI(1,k)+IJ(3,2)*AI(2,k)+IJ(3,3)*AI(3,k)
      end do
      MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) -
     -        IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) +
     +        IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
      write(*,'(a)')
     &'[Method 1] ===================================================='
      write(*,'(a)')' Su. Construct crystallograpghic cell'      
      write(*,'(a)')
     &'     Extention matrix {cell -> crystallogrtaphic cell}:'
      write(*,'(16x,a,3(i3,x),a)') '| ',(IJ(1,i),i=1,3),' |'
      write(*,'(a,3(i3,x),a,i3)') 
     & '       IJ(i,j)= | ',(IJ(2,i),i=1,3),' |,  ext=',MG_luc
      write(*,'(16x,a,3(i3,x),a)') '| ',(IJ(3,i),i=1,3),' |'
      write(*,'(a)')'     Lattice vectors of extended cell ARE:'
      write(*,'(3x,a,3(f10.5,x))')  '     (1):   ',(AJ1(1,i),i=1,3)
      write(*,'(3x,a,3(f10.5,x))')  '     (2):   ',(AJ1(2,i),i=1,3)
      write(*,'(3x,a,3(f10.5,x))') '     (3):   ',(AJ1(3,i),i=1,3)
      write(*,'(a)')'     Initial lattice vectors ARE:'
      write(*,'(3x,a,3(f10.5,x))')  '     AI(1):   ',(AI(1,i),i=1,3)
      write(*,'(3x,a,3(f10.5,x))')  '     AI(2):   ',(AI(2,i),i=1,3)
      write(*,'(3x,a,3(f10.5,x))')  '     AI(3):   ',(AI(3,i),i=1,3)
c_________ update reciprocal vectors BJ
      call INVER(AJ1,BJ1)
c      write(*,'(a)')'     Reciprocal vectors of extended cell ARE:'
c      write(*,'(3x,a,3(f10.5,x))')  '     BJ(1):   ',(BJ1(1,i),i=1,3)
c      write(*,'(3x,a,3(f10.5,x))')  '     BJ(2):   ',(BJ1(2,i),i=1,3)
c      write(*,'(3x,a,3(f10.5,x))')  '     BJ(3):   ',(BJ1(3,i),i=1,3)
      write(*,'(a)')
     &     ' Mi. Choose direction of the normal by Miller indices'
      write(*,'(/a)')
     &'[Method 2] ===================================================='
      if(Yes_Nv) then
         write(*,'(a)')' Nv. Normal vector to the plane is:'
         write(*,'(5x,3(f10.5,x))') vn
      else
         write(*,'(a)')
     &        ' Nv. Normal vector to the plane     <== undefined!'
      end if
      write(*,'(a/)')
     &'==============================================================='
      if(Yes_Nv) then
         if(Yes_Done) then
            write(*,'(a)')
     &       ' CP. Choose lattice vectors 1,2 within the plane <= Done!'
         else
            write(*,'(a)')
     &       ' CP. Choose lattice vectors 1,2 within the plane'
         end if
      end if
      if(Yes_Done) then
         write(*,'(a)')'     NEW lattice vectors ARE:'
         write(*,'(3x,a,3(f10.5,x))')  '     AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(3x,a,3(f10.5,x))')  '     AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(3x,a,3(f10.5,x))')  '     AJ(3):   ',(AJ(3,i),i=1,3)
         MG_luc=abs(JI(1,1)*(JI(2,2)*JI(3,3)-JI(3,2)*JI(2,3)) -
     -        JI(2,1)*(JI(1,2)*JI(3,3)-JI(3,2)*JI(1,3)) +
     +        JI(3,1)*(JI(1,2)*JI(2,3)-JI(1,3)*JI(2,2)))
         write(*,'(a)')'     Extention matrix {old cell -> new cell}:'
         write(*,'(16x,a,3(i3,x),a)') '| ',(JI(1,i),i=1,3),' |'
         write(*,'(a,3(i3,x),a,i3)') 
     &        '       IJ(i,j)= | ',(JI(2,i),i=1,3),' |,  ext=',MG_luc
         write(*,'(16x,a,3(i3,x),a)') '| ',(JI(3,i),i=1,3),' |'
      end if
      write(*,'(a)')' UU. Restore the original lattice vectors'
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)


c[Su]...... general breeding

      IF(cha2(l0:).eq.'Su') THEN
c___________ specify extention matrix

 34      write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'   
 3       write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=3) (IJ(1,j),j=1,3)
 4       write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=4) (IJ(2,j),j=1,3)
 5       write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=5) (IJ(3,j),j=1,3)
         MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) -
     -        IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) +
     +        IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         write(*,*) 'cell ==> supercell extention = ',MG_luc
         if(abs(MG_luc).lt.tiny_equiv) then
            write(*,*) 'ERROR! Zero extention!'
            go to  34
         end if
         Yes_nv=.false. ; Yes_Done=.false.

c[Nv].... choose the normal vector to the plane manually

      ELSE IF(cha2(l0:).eq.'Nv') THEN

 10      write(*,*)'Give the direction of the normal to the plane:'
         read(*,*,err=10) vn
         s=sqrt(vn(1)*vn(1)+vn(2)*vn(2)+vn(3)*vn(3))
         if(s.lt.tiny_equiv) go to 10
         do i=1,3
            vn(i)=vn(i)/s
         end do
         Yes_nv=.true. ; Yes_Done=.false.

c[Mi].... choose Miller indices

      ELSE IF(cha2(l0:).eq.'Mi') THEN

c___________ ask for Miller indices
 20      write(*,*)'Specify 3 Miller indices for the (surface) plane:'
         read(*,*,err=20) HH,KK,LL

c_________ calculate the direction of the normal vector
         do k=1,3
            vn(k)=HH*BJ1(1,k)+KK*BJ1(2,k)+LL*BJ1(3,k)
         end do
         s=sqrt(vn(1)*vn(1)+vn(2)*vn(2)+vn(3)*vn(3))
         if(s.lt.tiny_equiv) go to 20
         do i=1,3
            vn(i)=vn(i)/s
         end do
         Yes_nv=.true. ; Yes_Done=.false.

c[CP].... choose a new set of lattice vectors which are within the plane

      ELSE IF(cha2(l0:).eq.'CP' .and. Yes_nv) THEN

c________ choose new basic lattice vectors so that the first two lie in the
c         specified plane: only the direction (vn) is actually used here!

         call get_best_AI(AJ,HH,KK,LL,JI,vn,1,10)
c         scal1=AJ(1,1)*vn(1)+AJ(1,2)*vn(2)+AJ(1,3)*vn(3)
c         scal2=AJ(2,1)*vn(1)+AJ(2,2)*vn(2)+AJ(2,3)*vn(3)
c         write(*,*)'Dot products of new vectors with G(hlm):'
c         write(*,'(5x,2(e12.6,x))') scal1,scal2
         Yes_Done=.true.

c[UU].... restore the original AJ

      ELSE IF(cha2(l0:).eq.'UU') THEN

         do i=1,3
            do j=1,3
               AJ(i,j)=AI(i,j)
            end do
         end do
         Yes_nv=.false. ; Yes_Done=.false.
         
c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

      subroutine ask_vector_in_plane(dir,norm,cntp,rn,angstr1)
c..............................................................
c ask for a vector (norm=.false.) or direction (i.e. normalised
c to 1 (norm=.true.) along the rotation axis within the plane
c..............................................................
c rn()   - normal to the plane
c cntp() - central point (its projection on the plane will be
c          taken if used)
c..............................................................
      include 'real8.inc'
      dimension vect(3),r1(3),r2(3),cntp(3),rn(3),dir(3)
      logical norm,done,err
      character angstr*12,angstr1*12,cha2*2
      data tiny/0.0001/

      angstr=angstr1 ; done=.false.
      
 21   write(*,'(a)')
     &     '------Specify the ROTATION AXIS within the plane -----'
      write(*,'(a/)')'      [Projection to the plane will be taken]'
      write(*,'(a,3(x,f10.5))')'     Normal to the plane: ',rn
      if(Done) then
         b=vect(1)*rn(1)+vect(2)*rn(2)+vect(3)*rn(3) ; dir=vect-b*rn
         if(norm) then
            s=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
            dir=dir/s
         end if
         write(*,'(a,3(x,f10.5))')
     &        '     Rotation axis given:            ',vect
         write(*,'(a,3(x,f10.5))')
     &        '     Rotation axis WITHIN THE PLANE: ',dir
      else
         write(*,'(a,3(x,f10.5))')
     &        '     Rotation axis within the plane: <== undefined!'
      end if
      write(*,'(a)') '  D. Axis direction: give directly'
      write(*,'(a)') 
     &     ' 2C. Axis direction: add 2nd point to the central point'
      write(*,'(5x,a,3(f10.5,x))') 'Central point: ',(cntp(i),i=1,3)
      write(*,'(a)') ' 2P. Axis direction: using arbitary 2 poins'
c_____ show settings
      write(*,'(/a)')
     &     '-------------- g e n e r a l  s e t t i n g s ----------'
      write(*,'(a)')
     &     ' An. [For input] Coordinates are specified in: '//angstr
      write(*,'(a)')
     &     '--------------------------------------------------------'
      if(Done) write(*,'(a)') 
     &     '  P. Done. Return back to the previous menu!'
      write(*,'(a)')
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[An]...... choose the way the coordinates are given

      IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if 

c[D]...... choose the direction

      ELSE IF(cha2(l0:).eq.'D') THEN

 1       write(*,*)'Give direction of the axis directly:'
         read(*,*,err=1) vect
         call vect_prod(rn,vect,dir,.false.,err)
         if(err) go to 1 ; Done=.true.

c[2C]...... choose the direction via an additional point to the central point

      ELSE IF(cha2(l0:).eq.'2C') THEN

 2       write(*,*)'Give additional point to the central point:'
         call givepoint(r1(1),r1(2),r1(3),angstr)
         vect=r1-cntp
         call vect_prod(rn,vect,dir,.false.,err)
         if(err) go to 2 ; Done=.true.

c[2P]...... choose the direction via 2 points; the central point is
c           also redefined

      ELSE IF(cha2(l0:).eq.'2P') THEN

 3       write(*,*)'Give the 1st point:'
         call givepoint(r1(1),r1(2),r1(3),angstr)
         write(*,*)'Give the 2nd point:'
         call givepoint(r2(1),r2(2),r2(3),angstr)
         vect=r2-r1 
         call vect_prod(rn,vect,dir,.false.,err)
         if(err) go to 3 ; cntp=r2 ; Done=.true.

c[Q]...... normal return

      ELSE IF(cha2(l0:).eq.'P' .and. Done) THEN
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

      subroutine ask_vector_rot(dir,cntp,angstr1)
c..............................................................
c ask for a vector for rotation
c..............................................................
c cntp() - central point (its projection on the plane will be
c          taken if used)
c..............................................................
      include 'real8.inc'
      dimension r1(3),r2(3),cntp(3),dir(3)
      logical done
      character angstr*12,angstr1*12,cha2*2
      data tiny/0.0001/

      angstr=angstr1 ; done=.false.
      
 21   write(*,'(/a)')
     &      '[Specify the ROTATION AXIS]----------------------------'
      write(*,'(a)')' ^^^^^^^^^^^^^^^^^^^^^^^^^'
      if(Done) then
         s=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3)) ; dir=dir/s
         write(*,'(a,3(x,f10.5))')
     &        '     Rotation axis given:            ',dir
      else
         write(*,'(a,3(x,f10.5))') '     Rotation axis <== undefined!'
      end if
      write(*,'(a)') '  D. Axis direction: give directly'
      write(*,'(a)') 
     &     ' 2C. Axis direction: add 2nd point to the central point'
      write(*,'(5x,a,3(f10.5,x))') 'Central point: ',(cntp(i),i=1,3)
      write(*,'(a)') ' 2P. Axis direction: using arbitary 2 poins'
c_____ show settings
      write(*,'(/a)')
     &     '-------------- g e n e r a l  s e t t i n g s ----------'
      write(*,'(a)')
     &     ' An. [For input] Coordinates are specified in: '//angstr
      write(*,'(a)')
     &     '--------------------------------------------------------'
      if(Done) write(*,'(a)') 
     &     '  P. Done. Return back to the previous menu!'
      write(*,'(a)')
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[An]...... choose the way the coordinates are given

      IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if 

c[D]...... choose the direction

      ELSE IF(cha2(l0:).eq.'D') THEN

 1       write(*,*)'Give direction of the axis directly:'
         read(*,*,err=1) dir
         s=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
         if(s.lt.tiny) go to 1 ; Done=.true.

c[2C]...... choose the direction via an additional point to the central point

      ELSE IF(cha2(l0:).eq.'2C') THEN

 2       write(*,*)'Give additional point to the central point:'
         call givepoint(r1(1),r1(2),r1(3),angstr)
         dir=r1-cntp
         s=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
         if(s.lt.tiny) go to 2 ; Done=.true.

c[2P]...... choose the direction via 2 points; the central point is
c           also redefined

      ELSE IF(cha2(l0:).eq.'2P') THEN

 3       write(*,*)'Give the 1st point:'
         call givepoint(r1(1),r1(2),r1(3),angstr)
         write(*,*)'Give the 2nd point:'
         call givepoint(r2(1),r2(2),r2(3),angstr)
         dir=r2-r1 
         s=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
         if(s.lt.tiny) go to 3 ; cntp=r2 ; Done=.true.

c[Q]...... normal return

      ELSE IF(cha2(l0:).eq.'P' .and. Done) THEN
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end


      


