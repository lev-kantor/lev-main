      program main
      real*8 a,b

 1    read(*,*) a
      b=a-int(a)
      if(b.gt.0.5) then
         b=b-1.
      else if(b.lt.-0.5) then
         b=b+1.
      end if
      write(*,*) a,b
      go to 1
      stop
      end
      
