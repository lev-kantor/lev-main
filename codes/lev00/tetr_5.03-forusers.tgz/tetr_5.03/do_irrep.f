       subroutine do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
c...............................................................
c IA - irrep
c ITI - total number of atoms in the system
c R1(orbit,xyz) - 1st atoms of orbits in the right order
c NORB - number of orbits
c N_cond - number of  translations/rotations conditions
c C_cond(yzx-component, Atom , condition number) - vectros of 
c           conditions;
c_______ OUTPUT:
c IRALF(IA) - repetition number for the irrep IA
c IRA - number of linearly inependent symmetry-adapted vectors 
c       (together with conditions!)
c W_all(yzx, A , F , irrep dim) - 
c        - trasformation matrix for the whole system and 
c          given irrep IA, where:
c
c yzx - component of atom A coordinate
c  F  - total repetition (over all orbits); it is attached to 
c       conditions, i.e. actual displacements starts at iF=N_cond+1
c  A  - overall atomic index which runs orbit after orbit in the
c       correct order; inside every orbit it runs in the order
c       suggested by pvrt-like routines.
c...............................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension C_cond(3,N0LT,6),IRA1(3)
      dimension Work(K0DM0+6),R(3),BJ(3,3)
      character Species(N0KD)*2

      write(*,'(a,i2,a)') '===========> irrep = ',IA,' <==============' 
c      write(9,'(a,i2,a)') '===========> irrep = ',IA,' <==============' 
c
c............ put vectors of conditions to W_all as first vectors
c             (only row 1 is needed here; do it though for all for later use)
c
      if(N_Cond.gt.0) then

         do iF=1,N_cond
            do iN=1,ITI
               do k=1,3
                  do j=1,NALFA(IA)
                     W_all(k,iN,iF,j)=C_cond(k,iN,iF)
                  end do
               end do
            end do
         end do
c???????????
c         write(9,'(/a/)') 
c     &        '>>>>>>>>> all vectors of conditions <<<<<<'
c         call show_W_all_matrix1(IA,N_Cond,Species,1,N_Cond,9)
c         call check_orth(W_all(1,1,1,1),K0DM0+6,N_Cond,3*ITI,3*N0LT)
c???????????
      end if
c
c......... do loop over orbits; the construction of all matrices is done
c          for each orbit separately;
c          we compute: transf. matrix W and NREP
c
      IRALF(IA)=0 ; iN1=1
      do I=1,NORB
         NREP=0
         if(.not.Fix(I)) then
            R(1:3)=R1(I,1:3)
            call VANJA(R,1,I,IA,NREP,BJ)
         end if
         iN2=iN1+KAN(I)-1
c
c______ compile the matrix W_all from W calculated for the given orbit I
c       iF - current overall repetition index (starting from N_Cond+1).
c       iN1 - 1st atom of the current orbit in the overall list of atoms
c       (Only elements belonging to the given orbit are non-zero) 
c
         do iF=IRALF(IA)+1,IRALF(IA)+NREP
            if(iF.gt.K0DM0) 
     &           stop 'ERROR! Increase K0DM0 in sym_par.inc'
            iF1=iF+N_Cond
            do j=1,NALFA(IA)
               do k=1,3
                  do iN=1,ITI
                     if(iN.ge.iN1.and.iN.le.iN2.and.(.not.Fix(I))) then
                        iiN=iN-iN1+1
                        W_all(k,iN,iF1,j)=W(j,iF-IRALF(IA),iiN,k)
                     else
                        W_all(k,iN,iF1,j)=0.0d0
                     end if
                  end do
               end do
            end do
         end do
         IRALF(IA)=IRALF(IA)+NREP

         iN1=iN2+1
      end do

c???????????
c      write(6,'(/a/)') 
c     &     '>>>>>>>>> all vectors after VANJA, before orth. <<<<<<'
c      call show_W_all_matrix1(IA,N_Cond+IRALF(IA),Species,
c     ,     1,N_Cond+IRALF(IA),6)
c???????????
c     
c........... exit if IRALF(IA)=0
c      
      if(IRALF(IA).eq.0) then
         write(*,*)'WARNING! This irrep is not contained at all!'
         IRA=N_cond
         return
      end if
c
c.......... if IRALF(IA).ne.0, we orthogonalise W_all to 
c           the rotational/translational conditions (if any)
c
c[4]........ orthogonalise/normalise W_all (from N_Cond+1) to the vectors of
c            conditions (1,...,N_Cond) and between themselves. 
c      IRA - the final number of linearly independent vectors (including
c            those of the conditions)       
c
c   We may consider only the 1st row of every irrep, since this is sufficient 
c   for calculating frequencies and thus necessary atomic displacmenets.
c   However, since the other rows are needed, e.g. for constructing vibrations 
c   themselves, which can be done at the stage of the solution of the dynamical 
c   problem, we obtain diaplacement vectors for each row separately (although
c   the transformation does not depend on the row index) for the later use.
c
      do j=1,NALFA(IA)
         call ortho_norm(W_all(1,1,1,j),K0DM0+6,IRA,N_cond+IRALF(IA),
     ,                      3*ITI,3*N0LT,Work,N_cond)
         write(*,'(a,i1,a,i5)') 'row = ',j,', vectors left = ',IRA
         IRA1(j)=IRA
         if(j.gt.1) then
            if(IRA1(j).ne.IRA1(j-1)) then
               write(*,*)
     &              'FATAL error in do_irrep (diffr result for rows)'
               write(*,'(a,i2,a,3(i2,x))') 
     &           'error for IA= ',IA,' IRA = ',(IRA1(i),i=1,IRALF(IA))
               stop
            end if
         end if
      end do
      IRA=IRA1(1)

c???????????
c      write(6,'(/a/)') 
c     &     '>>>>>>>>> all vectors after VANJA and orthog. <<<<<<'
c      call show_W_all_matrix1(IA,IRA,Species,1,IRA,6)
c      call check_orth(W_all(1,1,1,1),K0DM0+6,IRA,3*ITI,3*N0LT)
c???????????

      if(IRA-N_cond.eq.0) then
         write(6,*)'RESULT: no vectors left for this irrep !!!'
         return
      else
         write(6,'(a23,i5)')'RESULT: vectors left = ',IRA-N_cond
      end if
      return
      end

      subroutine write_G_matrix(IA,IRA,N_Cond,AtMass)
c..................................................................
c Construct the G-matrix for the given irrep IA and save it into 
c a file G_{irrep number}.mat
c
c______ INPUT:
c      IA - irrep
c      IRA - # of lineraly independent vectors (incl. conditions)      
c   N_Cond - # of transl.-rotat. conditions
c..................................................................
      include 'real8.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension AtMass(N0KD)
      character cha1,cha2*2
c
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (23,file='G_'//cha1//'.mat',form='formatted')
      else 
         write(cha2,'(i2)') IA
         open (23,file='G_'//cha2//'.mat',form='formatted')
      end if
      do iF=N_cond+1,IRA
         iFi=iF-N_cond
         do iF1=N_cond+1,IRA
            iFi1=iF1-N_cond

            s=0.0d0
            iN=0
            do iOrb=1,NORB
               is=ISORT1(iOrb)
               do nat=1,KAN(iOrb)
                  iN=iN+1
                  do k=1,3
                     s=s+W_all(k,iN,iF,1)*W_all(k,iN,iF1,1)/AtMass(is)
                  end do
               end do
            end do

            write(23,*) iFi, iFi1, s
         end do
      end do
      close (23)
      return
      end

      subroutine show_W_all_matrix1(IA,IRA,Species,I1,I2,unit)
c.............................................................
c nice print of the symmetry-adapted displacements I1,...,I2
c IA     - given irrep
c IRA    - total number of linearly independent vectors
c 
c.............................................................
c    At the same time, the vectors are written into a file
c Vector_IA.dat for future reference.
c.............................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension kk(3),RR(MG0,3),RA(3)
      integer rep,unit
      character a(3),Species(N0KD)*2
      data a/'y','z','x'/,kk/2,3,1/

      if(I1.lt.0 .or. I1.gt.I2 .or. I2.gt.IRA) stop 'error in show_W'
c  
c........... write on the scree/file
c
      write(unit,'(a/)')
     &     '********** symmetry-adapted displacements ***********'
      write(unit,'(20x,a)') '<---(repetition,row)--->'
      write(unit,'(2x,a,20(3x,a,i2,a,i1,a,2x))')
     &     '     atom#   x/y/z   ',
     &         (('(',rep,',',i,')',i=1,NALFA(IA)),rep=I1,I2)
      iN=0
      do iOrb=1,NORB
         RA(1:3)=R1(iOrb,1:3)
         is=ISORT1(iOrb)
         call PVRT0(RA,RR,Nnn)
         do nat=1,Nnn
            iN=iN+1
            do i=1,3
               k=kk(i)
               write(unit,'(a,x,i5,a,20(x,f10.5))') 
     &              Species(is),iN,a(i),RR(nat,k),
     ,           ((W_all(i,iN,rep,j),j=1,NALFA(IA)),rep=I1,I2)
            end do
         end do
         write(unit,*)
     &        '---------------------------------------------------'
      end do
      return
      end

      SUBROUTINE READGR(KodErr,unit)
c....................................................................
c This program read file 'SYMGRP.REP' with all attributes of given
c point group
c....................................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'whereis.inc'
      character GN1*3,GN*3,int*5,int1*5
      integer unit
      KodErr=0
      open(unit=3,file=tetr_dir(tetr_l0:)//'/symgrp.rep',
     &     status='old', err=102)
 20   READ(unit,'(a3)',END=2000) GN
      if(GN.ne.GROUPN) go to 20
 21   READ(unit,'(a3)',END=2000) GN1
      IF(GN1.NE.'***') GO TO 21
      READ(unit,'(24i4)') MG,NEPR,K2,K3
      READ(unit,'(24i4)') (NALFA(J),J=1,NEPR)
      READ(3,'(24i4)') (ICMPL(J),J=1,NEPR)
      if(MG.gt.MG0) go to 50
      if(NEPR.gt.N0IR) go to 51
      if(K2.gt.N0IR2) go to 52
      if(K3.gt.N0IR3) go to 53
      READ(unit,'(a3)') GN1
      K1=NEPR-K2-K3
      do K=1,K1
         read(unit,'(a3)') NAZVIR(K)
         read(unit,'(12X,24F10.7)') (XX(K,L),L=1,MG)
      end do
      READ (unit,'(a3)') GN1
      DO K=1,K2
         READ(unit,'(a3)') NAZVIR(K1+K)
         READ(unit,'(12X,24F10.7)') (D2ALFA(1,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D2ALFA(2,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D2ALFA(1,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D2ALFA(2,2,L,K),L=1,MG)
         DO L=1,MG
            XX(K1+K,L)=D2ALFA(1,1,L,K)+D2ALFA(2,2,L,K)
         END DO
      END DO
      READ (unit,'(a3)')GN1
      DO K=1,K3
         READ(unit,'(a3)') NAZVIR(K1+K2+K)
         READ(unit,'(12X,24F10.7)') (D3ALFA(1,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(2,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(3,1,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(1,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(2,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(3,2,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(1,3,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(2,3,L,K),L=1,MG)
         READ(unit,'(12X,24F10.7)') (D3ALFA(3,3,L,K),L=1,MG)
         DO L=1,MG
            XX(K1+K2+K,L)=D3ALFA(1,1,L,K)+D3ALFA(2,2,L,K)
     *           +D3ALFA(3,3,L,K)
         END DO
      END DO
      close (unit)
      return
c........... error messages......................................
 102  write(*,*)'FATAL! Open file error symgrp.rep !!! '
      KodErr=1
      return
c__________ check for MG
 50   WRITE(int,300)MG
      WRITE(int1,300)MG0
 300  FORMAT(I5)
      write(*,*)'FATAL! Point group '//GN//' has MG= '//int//
     &     ' > then MG0= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      return
c___________check for NEPR
 51   WRITE(int,300) NEPR
      WRITE(int1,300) N0IR
      write(*,*)'FATAL! Point group '//GN//' has NEPR= '//int//
     &     ' > then N0IR= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      RETURN
c___________check K2
 52   WRITE(int,300) K2
      WRITE(int1,300) N0IR2
      write(*,*)'FATAL! Point group '//GN//' has K2= '//int//
     &     ' > then N0IR2= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      RETURN
c____________check  K3
 53   WRITE(int,300) K3
      WRITE(int1,300) N0IR3
      write(*,*)'FATAL! Point group '//GN//' has K3= '//int//
     &     ' > then N0IR3= '//int1//' in SYM_PAR.inc'
      CLOSE(unit)
      KodErr=1
      RETURN
c.................if the group GN has nor been found at all
 2000 write(*,*)'*readgr* FATAL!!!   The group '
     *     //GROUPN//' has not been found in SYMGRP.REP file'
      CLOSE(unit)
      KodErr=1
      RETURN
      END

      subroutine irina(TI,Nsp,NspN,BJ,Err)
c.......................................................................
c   Nsp        - number of species
c   NspN(is)   - number of atoms in each species is
c   TI(xyz,at) - coordinates of all atoms in the system
c....... OUTPUT:
c   NORB        - number of orbits
c   KAN(orb)    - number of atoms in the orbit
c   R1(orb,xyz) - coordinates of the 1st atom of the orbit 
c.......................................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'systema.inc'
      dimension  RA(3),RRR(MG0,3),RL(3),TI(3,N0LT),BJ(3,3)
      logical Err,ask_equiv
      integer NspN(N0KD)
      data tiny/0.0001/
c
c........  Choose orbits iOrb in a loop over all atoms
c
      NAT1=0 ; iOrb=0 ; iAt=0
      do is=1,Nsp
         do in=1,NspN(is)
            iAt=iAt+1
            RA(1:3)=TI(1:3,iAt)
            if(iAt.eq.1) go to 6

c___________ checking if RA is in already existing orbits
            do I1=1,iOrb
               RL(1:3)=R1(I1,1:3)
               call PVRT0(RL,RRR,N1)
               do NAT=1,N1
                  RL(1:3)=RRR(NAT,1:3)-RA(1:3)
                  if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA')then
                     if(ask_equiv(RL,BJ,3,tiny)) go to 1
                  else
                     AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
                     if(AR.lt.tiny) go to 1
                  end if
               end do
            end do

c.........Construction of the new orbit (all rotations)
 6          CALL PVRT0(RA,RRR,N1)
            NAT1=NAT1+N1 ; iOrb=iOrb+1
            KAN(iOrb)=N1 ; ISORT1(iOrb)=is
            R1(iOrb,1:3)=RA(1:3)
            do nat=1,N1
               RL(1:3)=RRR(nat,1:3)
               orb_to_old(iOrb,nat)=number_of_atom(RL,Err)
               if(Err) then
                  write(*,*) 'ERROR: inconsistency in IRINA' ; return
               end if
            end do
 1       end do
      end do
c....... set the number of orbits and check the total number of atoms
      NORB=iOrb
      if(NAT1.ne.iAt) then
         write(*,*)'ERROR! IRINA: wrong coordinates/group!'
         Err=.true.
      end if
      end

      integer function number_of_atom(x,Err)
c..................................................................
c  gives the atom number in the list TI from the point x
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'systema.inc'
      dimension x(3),rl(3)
      logical Err,ask_equiv
      
      do nat=1,ITI
         rl(1:3)=x(1:3)-TI(1:3,nat)
         if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA') then
            if(ask_equiv(RL,BJ,3,tiny_equiv)) go to 1
         else
            ar=rl(1)*rl(1)+rl(2)*rl(2)+rl(3)*rl(3)
            if(AR.lt.tiny_equiv) go to 1
         end if
      end do
      Err=.true.
      return
 1    number_of_atom=nat
      Err=.false.
      return
      end
