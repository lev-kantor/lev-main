      subroutine do_cond(N_Cond,C_cond,AtMass)
c...............................................................
c R1(orbit,xyz) - 1st atoms of orbits in the right order
c NORB - number of orbits
c_______ OUTPUT:
c N_cond - number of  translations/rotations conditions
c C_cond(yzx-component, Atom , condition number) - vectors of
c            conditions;
c...............................................................
c     Everything is done with respect to Cartesian spherical 
c harmonics, not displacements, so that:
c  x-displacement => Y(l=1,m=1) = y3
c  y-displacement => Y(l=1,m=-1)= y1
c  z-displacement => Y(l=1,m=0) = y2
c
c     Thus, vectors are expanded with respect to y1,y2,y3, 
c NOT displacements!
c...............................................................
      include 'real8.inc'
      include 'symgenv.inc'
      dimension C_cond(3,N0LT,6),RR(MG0,3),kk(3),x(3)
      dimension Work(6),AtMass(N0KD)
      data kk/3,1,2/
c
c.......... we build up translation/rotation conditions:
c      N_cond - number of conditions
c      C_cond(yzx, atom, cond. #) - vector of conditions
c
c[1]........ make conditions in C_cond: traslations (1st three vectors)
c
      do j1=1,3  
         j=kk(j1)

         iN=0
         do iOrb=1,NORB
            is=ISORT1(iOrb)
            do nat=1,KAN(iOrb) 
               iN=iN+1
               do k=1,3
                  k1=kk(k)
                  C_cond(k1,iN,j)=0.0
                  if(k1.eq.j) C_cond(j,iN,j)=AtMass(is)
               end do
            end do
         end do

      end do
c
c[2]......... make conditions in C_cond: rotations (2nd two/three vectors).
c         if Linear=.true. then there is no condition for the z-component
c         Vectors are constructed as angluar momenta for the rotations around x,y,z axes,
c         e.g. Lz=\sum_i m_i [r_i x k], where k is the direction along z.
c
      iN=0
      do iOrb=1,NORB
         is=ISORT1(iOrb)
         x(1)=R1(iOrb,1)
         x(2)=R1(iOrb,2)
         x(3)=R1(iOrb,3)
         call PVRT0(x,RR,N1)
         do nat=1,N1
            iN=iN+1
            C_cond(3,iN,4)= 0.0
            C_cond(1,iN,4)=-AtMass(is)*RR(nat,3)
            C_cond(2,iN,4)= AtMass(is)*RR(nat,2)
            C_cond(3,iN,5)= AtMass(is)*RR(nat,3)
            C_cond(1,iN,5)= 0.0
            C_cond(2,iN,5)=-AtMass(is)*RR(nat,1)
            C_cond(3,iN,6)=-AtMass(is)*RR(nat,2)
            C_cond(1,iN,6)= AtMass(is)*RR(nat,1)
            C_cond(2,iN,6)= 0.0
         end do
      end do
c
c[3]........ orthogonalise/normalise vectors of conditions
c
      j0=0
      call ortho_norm(C_cond,6,N_cond1,N_cond,3*iN,3*N0LT,work,j0)
      return
      end
 
      subroutine show_C(C_cond,N_cond,Species)
      include 'real8.inc'
      include 'symgenv.inc'
      dimension C_cond(3,N0LT,6),kk(3)
      character a(3),Species(N0KD)*2
      data a/'y','z','x'/,kk/2,3,1/
      write(*,*)' '
      write(*,'(a)')'********** Vectors of conditions ***********'
c      write(*,'(a)') '  atom    /-------translations--------\\'//
      write(*,'(a)') 
     &     'old#  atom    /-------translations--------\\'//
     &     '     /---------rotations--------\\'
      iN=0
      do iOrb=1,NORB
         is=ISORT1(iOrb)
         do nat=1,KAN(iOrb)
            iN=iN+1
            iold=orb_to_old(iOrb,nat)

            do k1=1,3
               k=kk(k1)
               if(k1.eq.1) then
                  write(*,'(i3,x,a,i3,a1,6(x,f10.5))') 
     &           iold,Species(is),iN,a(k),(C_cond(k1,iN,iC),iC=1,N_Cond)
               else
                  write(*,'(6x,i3,a1,6(x,f10.5))') 
     &                 iN,a(k),(C_cond(k1,iN,iC),iC=1,N_Cond)
               end if
            end do

         end do
      end do
      return
      end

      subroutine ortho_norm(C,Nm,N,NN,Ndim,Ndim0,Alpha,j0)
c.........................................................................
c   Orthogonalise/normalise NN vectors C (dimension Ndim) to 
c previously orthogonal/normalised first j0 vectors using the 
c Gramm-Shmidt procedure (must be: j0 < NN =< Nm). 
c   Note that j0 can be also 0.
c   Linearly dependent vectors are recognised and removed from C, 
c N=NN is adjusted appropriately (i.e. reduced) to be the final number
c of linearly independent vectors.
c
c...... INPUT:
c  C(i,#) - vectors to orthogonalise
c     Nm  - max number of vectors (2nd physical dimension of an array)
c     NN  - actual number of vectors (should be =< Nm)
c     j0  - number of already orthonormal vectors at the beginning of the 
c           whole set (#=1,...,j0); j0 may be equal to 0; should be =< NN
c  Ndim0  - max size of each vector (1st physical dimension of an array)
c  Ndim   - actual size of each vector
c
c......OUTPUT:   
c  C(i,#) - orthogonormal vectors
c     N   - actual number left after dropping linearly dependent vectors
c           (N >= j0)
c.........................................................................
      include 'real8.inc'
      dimension C(Ndim0,Nm),Alpha(Nm)
      data tiny/0.00001/
      N=NN
      j00=j0
      write(*,*)'Shmidt: initial number of vectors N=',N
c
c____ normalise the 1st vector
c
      if(j00.eq.0) then
         beta=1./sqrt( scalar(C(1,1),C(1,1),Ndim) )
         do i=1,Ndim
            C(i,1)=C(i,1)*beta
         end do
         j00=1
         if(N.eq.1) return
      end if
c
c____ now the whole procedure comes in as a loop which starts from 
c     the 2nd vector
c
      j=j00
 20   j=j+1
c_________ calculate all Alpha's first
      do k=1,j-1
         Alpha(k) = scalar(C(1,j),C(1,k),Ndim) 
      end do
c_________calculate new orthogonal (but unnormalised yet) j-th vector
      do i=1,Ndim
         s=0.0
         do k=1,j-1                          
            s=s+Alpha(k)*C(i,k)
         end do
         C(i,j)=C(i,j)-s
      end do
c_________ normalise the j-th vector; if the norm of it is zero, then
c          we remove this vector from the original list and reduce N
      aNorm= scalar(C(1,j),C(1,j),Ndim) 
      if(aNorm.lt.tiny) then
         write(*,'(a12,i3,a22)')'_> Vector j=',j,' is lin. dependent' 
         if(j.eq.N) then
            N=N-1
            go to 30
         else
            do j1=j+1,N
               do i=1,Ndim
                  C(i,j1-1)=C(i,j1)
               end do
            end do
            N=N-1
            j=j-1
         end if
      else
         beta=1./sqrt(aNorm)
         do i=1,Ndim
            C(i,j)=C(i,j)*beta
         end do
      end if
      if(j.lt.N) go to 20
 30   write(*,*)'Shmidt: final number of vectors N=',N
      return
      end

