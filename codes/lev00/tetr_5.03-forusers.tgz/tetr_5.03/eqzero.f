      SUBROUTINE PVRT0(RA,RRR,N)
C*******************************************************************
C*******************************************************************
      INCLUDE 'symedil.cmn'
      DIMENSION RA(3),RRR(MG0,3),RL(3)
      I1=1
      RRR(1,1:3)=RA(1:3)
      IF(MMG.EQ.1) GO TO 4
        IJK=2
        IF(TYP.EQ.'T'.or.typ.eq.'P') IJK=1
      DO 3 I=2,MMG
      KGI=KG(I)
      I1=I1+1
      RRR(I1,1)=CC(1,1,KGI)*RA(1)+CC(1,2,KGI)*RA(2)+CC(1,3,KGI)*RA(3)+
     + TRAN(  I,1)
      RRR(I1,2)=CC(2,1,KGI)*RA(1)+CC(2,2,KGI)*RA(2)+CC(2,3,KGI)*RA(3)+
     + TRAN(  I,2)
      RRR(I1,3)=CC(3,1,KGI)*RA(1)+CC(3,2,KGI)*RA(2)+CC(3,3,KGI)*RA(3)+
     + TRAN(  I,3)
      K=I1-1
      DO 10 J=1,K
         RL(1:3)=RRR(I1,1:3)-RRR(J,1:3)
         GO TO (20,40),IJK
 20      CALL EQZERO(RL,BJ,IASK)
         GO TO (10,2),IASK+1
 40      AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
         IF(AR.LT.0.0001) GO TO 2
 10   CONTINUE
      GO TO 3
    2 I1=I1-1
    3 CONTINUE
    4 N=I1
      END

       SUBROUTINE EQZERO(A,BJ,IASK)
       include 'sym.par'
C Program tests,is vector A equivalent to zero vector in derect
C lattice (in modulo sence with respect to invers lattice
C BJ(1, ),BJ(2, ),BJ(3, ).
C IASK = 0  - no
C IASK = 1  - yes
       dimension A(3),BJ(3,3)
       IASK=0
       J=0
        DO 10 K=1,3
        C=A(1)*BJ(K,1)+A(2)*BJ(K,2)+A(3)*BJ(K,3)
        JC=NINT(C)
        IF(ABS(C-JC).LE.0.0001) J=J+1
  10    CONTINUE
       IF(J.EQ.3) IASK=1
       RETURN
       END

      subroutine INVLAT(AI,BI,SURFACE)
c....... build invers vectors BI from the direct ones, AI ,
C        without the multiplier 2*3.141592... which is dropped
      include 'sym.par'
      DIMENSION AI(3,3), BI(3,3)
      logical SURFACE

      if(SURFACE) then
c_________________ 2D case
         a11=AI(1,1)*AI(1,1)+AI(1,2)*AI(1,2)+AI(1,3)*AI(1,3)
         a12=AI(1,1)*AI(2,1)+AI(1,2)*AI(2,2)+AI(1,3)*AI(2,3)
         a22=AI(2,1)*AI(2,1)+AI(2,2)*AI(2,2)+AI(2,3)*AI(2,3)
         DET= a11*a22-a12*a12
         DET=1./DET
         do i=1,3
            BI(1,i)=( a22*AI(1,i)-a12*AI(2,i) )*DET
            BI(2,i)=( a11*AI(2,i)-a12*AI(1,i) )*DET
            BI(3,i)=0.0
         end do
      else
c_________________ 3D case
         DET=  AI(1,1)*(AI(2,2)*AI(3,3)-AI(2,3)*AI(3,2))
     *        -AI(2,1)*(AI(1,2)*AI(3,3)-AI(1,3)*AI(3,2))
     *        +AI(3,1)*(AI(1,2)*AI(2,3)-AI(1,3)*AI(2,2))
         DET=1./DET
         BI(1,1)= (AI(2,2)*AI(3,3)-AI(2,3)*AI(3,2))*DET
         BI(1,2)=-(AI(2,1)*AI(3,3)-AI(2,3)*AI(3,1))*DET
         BI(1,3)= (AI(2,1)*AI(3,2)-AI(2,2)*AI(3,1))*DET
         BI(2,1)=-(AI(1,2)*AI(3,3)-AI(1,3)*AI(3,2))*DET
         BI(2,2)= (AI(1,1)*AI(3,3)-AI(1,3)*AI(3,1))*DET
         BI(2,3)=-(AI(1,1)*AI(3,2)-AI(1,2)*AI(3,1))*DET
         BI(3,1)= (AI(1,2)*AI(2,3)-AI(2,2)*AI(1,3))*DET
         BI(3,2)=-(AI(1,1)*AI(2,3)-AI(1,3)*AI(2,1))*DET
         BI(3,3)= (AI(1,1)*AI(2,2)-AI(1,2)*AI(2,1))*DET
      end if
      RETURN
      END
