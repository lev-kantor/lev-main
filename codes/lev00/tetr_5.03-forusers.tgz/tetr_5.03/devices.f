      subroutine reducn(x,AJ,BJ)
c..................................................................
c    It translates the point x() (in Cartesian coordinates) to the 
c position in which it has fractional coordinates between -1 and 1.
c    Vectors BJ are reciprocal to AJ (up to 2*pi).
c..................................................................
      include 'real8.inc'
      dimension x(3),AJ(3,3),BJ(3,3),r(3)
      data tiny/0.000001/
c
c________ get coefficients r() in the decomposition of x() with
c         respect to AJ. These coefficients are some ratios like iX/jX, ...
c
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)+BJ(1,3)*x(3)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)+BJ(2,3)*x(3)
      r(3)=BJ(3,1)*x(1)+BJ(3,2)*x(2)+BJ(3,3)*x(3)
c
c________ extract the integer part from the coefficients and do them
c         closer to the nearest integer if the difference is small
c
      do i=1,3
        if(abs(r(i)-nint(r(i))).lt.tiny) r(i)=nint(r(i))
        r(i)=r(i)-int(r(i))
      end do
c
c________ return the point r() to the Cartesian representation, x()
c         as before
c
      x(1)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
      x(2)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
      x(3)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
      return 
      end

      subroutine reducn1(x,AJ,BJ)
c..................................................................
c    It translates the point x() (in Cartesian coordinates) to the 
c position in which it has fractional coordinates between -0.5 
c and 0.5 .
c    Vectors BJ are reciprocal to AJ (up to 2*pi).
c..................................................................
      include 'real8.inc'
      dimension x(3),AJ(3,3),BJ(3,3),r(3)
      data tiny/0.000001/
c
c________ get fractional coordinates of r()
c
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)+BJ(1,3)*x(3)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)+BJ(2,3)*x(3)
      r(3)=BJ(3,1)*x(1)+BJ(3,2)*x(2)+BJ(3,3)*x(3)
c
c________ remove the integer part from the fractional coordinates
c and then put them between -0.5 and 0.5
c
      do i=1,3
        if(abs(r(i)-nint(r(i))).lt.tiny) r(i)=nint(r(i))
        r(i)=r(i)-int(r(i))
        if(r(i).gt.0.5) then
           r(i)=r(i)-1.0
        else if(r(i).lt.-0.5) then
           r(i)=r(i)+1.0
        end if
      end do
c
c________ return the point r() to the Cartesian representation, x()
c         as before
c
      x(1)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
      x(2)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
      x(3)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
      return 
      end

      subroutine reducn2(x,AJ,BJ)
c..................................................................
c    It translates the point x() (in Cartesian coordinates) to the 
c position in which it has fractional coordinates between 0 and 1.
c    Vectors BJ are reciprocal to AJ (up to 2*pi).
c..................................................................
      include 'real8.inc'
      dimension x(3),AJ(3,3),BJ(3,3),r(3)
      data tiny/0.000001/
c
c________ get coefficients r() in the decomposition of x() with
c         respect to AJ. These coefficients are some ratios like iX/jX, ...
c
      r(1)=BJ(1,1)*x(1)+BJ(1,2)*x(2)+BJ(1,3)*x(3)
      r(2)=BJ(2,1)*x(1)+BJ(2,2)*x(2)+BJ(2,3)*x(3)
      r(3)=BJ(3,1)*x(1)+BJ(3,2)*x(2)+BJ(3,3)*x(3)
c
c________ extract the integer part from the coefficients and do them
c         closer to the nearest integer if the difference is small
c
      do i=1,3
        if(abs(r(i)-nint(r(i))).lt.tiny) r(i)=nint(r(i))
        r(i)=r(i)-int(r(i))
        if(r(i).lt.0.0) r(i)=1+r(i)
      end do
c
c________ return the point r() to the Cartesian representation, x()
c         as before
c
      x(1)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
      x(2)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
      x(3)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
      return 
      end


ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      logical function thesame(x,ITI,TI)
c..................................................................
c  checks if x() is equal to any of the atoms TI() in the cluster
c..................................................................
      include 'real8.inc'
      dimension x(3),TI(3,N0LT)
      data tiny/0.000001/

      do ic=1,ITI
         ar=(x(1)-TI(1,ic))**2+(x(2)-TI(2,ic))**2+
     +        (x(3)-TI(3,ic))**2
         if(ar.lt.tiny) then
            thesame=.true. 
            write(*,*) 'equiv to ic=',ic,' with ',TI(1:3,ic)
            return
         end if
      end do
      thesame=.false.
      end

      logical function thesame1(i,ITI,TI)
c..................................................................
c  checks if atom i is equal to any of the other atoms TI() in the 
c  cluster
c..................................................................
      include 'real8.inc'
      dimension TI(3,N0LT)
      data tiny/0.000001/

      do ic=1,ITI
         if(ic.ne.i) then
            ar=(TI(1,i)-TI(1,ic))**2+(TI(2,i)-TI(2,ic))**2+
     +           (TI(3,i)-TI(3,ic))**2
            if(ar.lt.tiny) then
               thesame1=.true.
               return
            end if
         end if
      end do
      thesame1=.false.
      return
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine check_Mendel(Spec,k,Err,verbose)
      include 'mendeleev.inc'
      logical Err,verbose
      character Spec*2
      Err=.false.

c___________ checking from NAZV
      do k=1,112
         if(NAZV(k).eq.Spec) then
            if(verbose) write(*,'(a,i2,a)')'Species '//Spec//
     &           ' => recognised as #',k,' in Mendeleev''s Table'
            return
         end if
      end do
      write(*,*)'ERROR! Species '//Spec//' has not been recognised!'
      Err=.true.
      k=83
      return
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine ask(R,BJ,TRAN,MMM,MG,IASK)
c..............................................................
c check, if vector R is contained in TRAN
c     Answer: iask=1 means R is already there
c             iask=2 means R is new (not contained)
c..............................................................
      include 'real8.inc'
      dimension R(3),RL(3),TRAN(MMM,3),BJ(3,3)
      logical ask_equiv
      data tiny/0.00001/

      IASK=2
      do NA=1,MG
         RL(1:3)=TRAN(NA,1:3)-R(1:3)

c____ this vector RL must not be represented as an integer combination of AJ's

         if(ask_equiv(RL,BJ,3,tiny)) then 
            IASK=1 ; return
         end if
      end do
      return
      end

      subroutine ask1(R,BJ,TRAN,MMM,MG,IASK,toler)
c..............................................................
c the same as 'ask()' but TRAN is defined differently
c and a tolerance is ported from outside (=toler)
c..............................................................
c check, if vector R is contained in TRAN
c     Answer: iask=1 means R is already there
c             iask=2 means R is new (not contained)
c..............................................................
      include 'real8.inc'
      dimension R(3),RL(3),TRAN(3,MMM),BJ(3,3)
      logical ask_equiv

      IASK=2
      do NA=1,MG
         RL(1:3)=TRAN(1:3,NA)-R(1:3)

c____ this vector RL must not be represented as an integer combination of AJ's

         if(ask_equiv(RL,BJ,3,toler)) then 
            IASK=1 ; return
         end if
      end do
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine sort(d,n,is)
c................................................................
c sorting routine: 
c   the reference index vector is(j) of numbers is constructed 
c   corresponding to asccend of vectors d(j). 
c................................................................
      include 'real8.inc'
      dimension d(n),is(n)
      do i=1,n
        is(i)=i
      end do
      if(n.eq.1) return
 10   ip=0
      do k=1,n-1
        if( d(is(k)) .gt. d(is(k+1)) ) then
          ip=1 
          iss=is(k)
          is(k)=is(k+1)
          is(k+1)=iss
        end if
      end do
      if(ip.eq.1) go to 10
      return
      end

      logical function ask_coinc(r,jSort,iSort,k)
c...................................................................
c   It checks whether the atom of the sort jSort and with vector 
c r() is equivalent to some atom of the system.
c...................................................................
c  k = equivalent atom number (between 1 and ITI) if answer='y',
c  k - meaningless otherwise
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension r(3),iSort(N0LT),r1(3)
      logical ask_equiv
      do k=1,ITI
         if(iSort(k).eq.jSort) then
            r1(1)=r(1)-TI(1,k)
            r1(2)=r(2)-TI(2,k)
            r1(3)=r(3)-TI(3,k)
            ask_coinc=ask_equiv(r1,BJ,3,tiny_equiv)
            if(ask_coinc) return
         end if
      end do
      ask_coinc=.false.
      return
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      logical function ask_equiv(r,XJ,iCase,tiny_equiv)
c........................................................................
c    It checks whether vector r() is equivalent to lattice translations
c  reciprocal to vectors XJ (up to 2*pi):
c
c  if XJ - reciprocal lattice vectors, then r() must be in the direct 
c          space;
c  if XJ - direct lattice vectors, then r() must be in the reciprocal
c          space;
c........................................................................
c  iCase = 3 - if 3D space;
c  iCase = 2 - if 2D space
c........................................................................
c  .true. - if r() is equivalent to latice translations
c  .false.- if not.
c........................................................................
      include 'real8.inc'
      dimension r(3),XJ(3,3),x(3)
      ask_equiv=.false.
c
c____ multiply on all direct lattice vectors: the result must be integer
c if r() is an arbitrary sum of reciprocal lattice vectors (note, r() is
c defined up to 2*pi because of the choice of BJ used to generate it)
c
      do i=1,iCase
         x(i)=r(1)*XJ(i,1)+r(2)*XJ(i,2)+r(3)*XJ(i,3)
         if( abs(x(i)-nint(x(i))) .gt. tiny_equiv ) return
      end do       
      ask_equiv=.true.
c      write(*,'(a,3(f10.5,x))')'EQUIVALENT: expans. coeff. are ',x
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine PVRT0(RA,R,Nnn)
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'systema.inc'
      dimension RA(3),R(MG0,3),RL(3)
      logical ask_equiv,as

      I1=1
      R(1,1:3)=RA(1:3)
      if(MG.eq.1) go to 4
      do 3 I=2,MG
         KGI=KG(I)
         I1=I1+1
         R(I1,1)=C(1,1,KGI)*RA(1)+C(1,2,KGI)*RA(2)+C(1,3,KGI)*RA(3)+
     +        TRAN(I,1)
         R(I1,2)=C(2,1,KGI)*RA(1)+C(2,2,KGI)*RA(2)+C(2,3,KGI)*RA(3)+
     +        TRAN(I,2)
         R(I1,3)=C(3,1,KGI)*RA(1)+C(3,2,KGI)*RA(2)+C(3,3,KGI)*RA(3)+
     +        TRAN(I,3)
         do J=1,I1-1
            RL(1:3)=R(I1,1:3)-R(J,1:3)
            if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA'.or. 
     &           system.eq.' K-POINT') then
               as=ask_equiv(RL,BJ,3,tiny_equiv)
               if(as) go to 2
            else
               AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
               if(AR.lt.tiny_equiv) go to 2
            end if
         end do
         go to 3
 2       I1=I1-1
    3 end do
    4 Nnn=I1
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine list_dash(listat,nlist,tmp,string,length,long)
c........................................................................
c creates a string of numbers separated by commas or dashes (if changed
c continuously);
c........................................................................
c long= .false. if the string is not long enough to accomodate the list
c........................................................................
      logical listat(nlist),tmp(nlist),long
      character string*100,cha10*10

      long=.true.
      do i=1,100
         string(i:i)=' '
      end do

      do i=1,nlist
         tmp(i)=listat(i)
      end do
      write(*,*) (tmp(i),i=1,nlist)

      j=1
      do 10 i=1,nlist
         if(tmp(i)) then
c__________ number of digits
            n_digits=log(real(i))/log(10.)+1
            write(cha10,'(i10)') i
            i1=10-n_digits+1
            j0=j+n_digits
            if(j0-1.le.99) then
               string(j:j0-1)=cha10(i1:)
            else
               long=.false.
               length=100
               return
            end if
            j=j0

c___________ check if there are data continusly after it
            if(i.lt.nlist) then
               do k=i+1,nlist
                  if(.not.tmp(k)) go to 5
                  tmp(k)=.false.
                  n_digits=log(real(k))/log(10.)+1
                  write(cha10,'(i10)') k
                  k1=10-n_digits+1
                  if(j0+n_digits.le.99) then
                     string(j0:j0+N_digits)='-'//cha10(k1:)
                  else
                     long=.false.
                     length=100
                     return
                  end if
                  j=j0+n_digits+1
               end do
            end if

 5          string(j:j)=','
            j=j+1
         end if
 10   end do
      string(j-1:j-1)=' '
      length=j-1
      return
      end

      subroutine which_atom_after_rot(r,Irot,nat,Err)
c...................................................................
c rotates point r() by operation Irot (no translations), and gets 
c the atom number matching the resulting point. 
c Err = .true. if the matching atom not found.
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension x(3),r(3),r1(3)
      logical ask_equiv,Err

      Err=.false.
c
c..... apply rotation
      KGI=KGp(Irot)
      x(1)=C(1,1,KGI)*r(1)+C(1,2,KGI)*r(2)+C(1,3,KGI)*r(3)
      x(2)=C(2,1,KGI)*r(1)+C(2,2,KGI)*r(2)+C(2,3,KGI)*r(3)
      x(3)=C(3,1,KGI)*r(1)+C(3,2,KGI)*r(2)+C(3,3,KGI)*r(3)
c
c..... find the atom
      do k1=1,ITI
         r1(1)=x(1)-TI(1,k1)
         r1(2)=x(2)-TI(2,k1)
         r1(3)=x(3)-TI(3,k1)
         if(ask_equiv(r1,BJ,3,tiny_equiv)) then
c___________ matching atom found
            nat=k1
            return
         end if
      end do
c
c.... matching atom NOT found
      Err=.true.
      return
      end

      logical function collinear(v1,v2)
c.......................................................
c checks if two vectors v1 and v2 are collinear or not
c.......................................................
      include 'real8.inc'
      dimension v1(3),v2(3)
      data tuny/0.00001/
      s1=v1(2)*v2(3)-v1(3)*v2(2)
      s2=v1(3)*v2(1)-v1(1)*v2(3)
      s3=v1(1)*v2(2)-v1(2)*v2(1)
      if(abs(s1)+abs(s2)+abs(s3).lt.tuny) then
         collinear=.true.
         return
      end if
      collinear=.false.
      return
      end

      logical function perpend(v1,v2)
c.......................................................
c checks if two vectors v1 and v2 are perpendicular
c.......................................................
      include 'real8.inc'
      dimension v1(3),v2(3)
      data tuny/0.00001/
      s=v1(1)*v2(1)+v1(2)*v2(2)+v1(3)*v2(3)
      if(abs(s).lt.tuny) then
         perpend=.true.
         return
      end if
      perpend=.false.
      return
      end

      subroutine cross_product(v1,v2,v)
c.......................................................
c calculates v= v1 x v2 
c.......................................................
      include 'real8.inc'
      dimension v1(3),v2(3),v(3)
      v(1)=v1(2)*v2(3)-v1(3)*v2(2)
      v(2)=v1(3)*v2(1)-v1(1)*v2(3)
      v(3)=v1(1)*v2(2)-v1(2)*v2(1)
      return
      end

