      subroutine eig_vibr(Which_Code)
c............. eigenvalues/vectors are calculated from given ...
c  G and F matrices for the given irrep (specified)
c...............................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'      
      include 'working.inc'
      include 'systema.inc'      
      include 'matrix.inc'
      include 'vk_vibr.inc'
      character cha1,cha2*2,cha17*17,numb(12)*2,chb1
      character cha(3)*2,WhichForce*7,Which_Code*6
      character Yes_xyz*4,chax*31,ch1*12,ch2*12,ch3*12,ch4*12
      logical G_files(N0IR),E_files(N0IR),F_files(N0IR),W_files(N0IR)
      integer IRA_left(N0IR)
      logical Add_Hs,active,Err,Yes_solved,Yes_W_all,show_interp
      logical via_Forces,lg,Err1,Err2,Err3,Show_fixed
      logical Yes_Fixed,do_IA(N0IR)
      common /buffer0/ A0(3,3),TI0(3,N0LT),B0(3,3),ITI0,
     ,     NspN0(N0KD),Nsp0,Species0(N0KD),relax_flag0(3,N0LT)
      character Species0*2,relax_flag0
      dimension Freq(K0DM0),x(3)
      double precision, parameter :: K_B=8.617343e-5       ! in eV/K
      double precision, parameter :: H_bar=4.13566733e-15  ! in eV*sec
      real*8,dimension(:,:),allocatable :: F_vk,G_vk
      data tiny/0.00001/,Add_Hs/.false./,Yes_xyz/'Xmol'/
      data numb/' 1',' 2',' 3',' 4',' 5',' 6',' 7',' 8',' 9',
     &       '10','11','12'/,show_interp/.false./
      data ch1/';   G-files['/, ch2/'],  E_files['/, ch3/'],  F_files['/
      data ch4/']   W-files['/,WhichForce/'average'/
      data ampl/0.05/,via_Forces/.true./,Show_fixed/.false./
c
c........... keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c
c............. read the info from mol_vibr()
c 
      do_IA=.true.
      open(23,file='vibr_info.dat',form='formatted',status='old',err=5)
      read(23,'(2(i5,x),a8)',err=5,end=5) NEPR,Nsp,system
      if(system.eq.' K-POINT') then
         read(23,*,err=5,end=5) MG ; MG_luc=MG
         read(23,'(20(a2,x))',err=5,end=5)  (Species(is),is=1,Nsp)
         read(23,*,err=5,end=5)  (AtMass(is),is=1,Nsp)
         read(23,*,err=5,end=5) (IRA_left(IA),IA=1,NEPR)
         read(23,'(l1)') Yes_Fixed
         read(23,*,err=5,end=5) ((TRAN(N,j),j=1,3),N=1,MG)
         read(23,*,err=5,end=5) AI,BI,AJ,BJ,IJ
         read(23,*,err=5,end=5) ITI,((TI(j,n),j=1,3),n=1,ITI)
         read(23,*,err=5,end=5) (Prim_Ext_Cell(i),i=1,ITI) 
         read(23,*,err=5,end=5) ITI_prim,((TI1(j,n),j=1,3),n=1,ITI_prim)
         read(23,*,err=5,end=5) (NspN(i),i=1,Nsp)
         read(23,*,err=5,end=5) ((Vkp(k,j),j=1,3),k=1,MG)
         read(23,*,err=5,end=5) (kCmpl(k),k=1,MG)
         do IA=1,NEPR
            NALFA(IA)=1
            write(NAZVIR(IA),'(i3)') IA 
            if(kCmpl(IA).eq.-1) do_IA(IA)=.false. 
         end do
         open(24,file='FCM.info', form='formatted')
         write(24,*)'# primitive cell:'
         write(24,*) AI,BI
         write(24,*) Nsp,(NspN(is)/MG,is=1,Nsp),ITI_prim
         write(24,*) ((TI1(j,n),j=1,3),n=1,ITI_prim)
         write(24,*)'# extended cell:'
         write(24,*) AJ,BJ
         write(24,*) MG,Nsp,(NspN(is),is=1,Nsp),ITI
         write(24,*) ((TI(j,n),j=1,3),n=1,ITI)
         write(24,*)'# internal translations:'
         write(24,*) ((TRAN(n,j),j=1,3),n=1,MG)
         close(24)
      else
         read(23,'(a3,20(x,a3))',err=5,end=5) 
     &                               GroupN,(NAZVIR(IA),IA=1,NEPR)
         read(23,'(20(a2,x))',err=5,end=5)  (Species(is),is=1,Nsp)
         read(23,*,err=5,end=5) (IRA_left(IA),IA=1,NEPR)
         read(23,*,err=5,end=5) (NALFA(IA),IA=1,NEPR)
         read(23,*,err=5,end=5) NORB,MG,(KG(i),i=1,MG)
         read(23,*,err=5,end=5) (KAN(io),(R1(io,j),j=1,3),io=1,NORB)
         read(23,*,err=5,end=5) (ISORT1(io),io=1,NORB)
         read(23,*,err=5,end=5) 
     &        ((orb_to_old(io,nat),nat=1,KAN(io)),io=1,NORB)
         read(23,'(20(l1,x))',err=5,end=5) (Fix(io),io=1,NORB),Yes_Fixed
         read(23,'(5(f10.5,x))',err=5,end=5) ((TRAN(N,j),j=1,3),N=1,MG)
         read(23,*,err=5,end=5) (ICMPL(IA),IA=1,NEPR)
         if(system.eq.'LATT-TRA') then
            read(23,*,err=5,end=5) AI,BI,AJ,BJ,IJ
            read(23,*,err=5,end=5)  ITI,((TI(j,n),j=1,3),n=1,ITI)
            read(23,*,err=5,end=5)  (NspN(i),i=1,Nsp)
            read(23,*,err=5,end=5) ((Vkp(k,j),j=1,3),k=1,MG)
            read(23,*,err=5,end=5) ((Vk_rep(IA,j),j=1,3),IA=1,NEPR)
         end if
      end if
      close (23)
      go to 7
 5    write(*,*)'FATAL! File [vibr_info.dat] is bad or absent!'
      close (5)
      return
c
c............. check availability of G-files containing combinations
c              of atomic masses
c
 7    if(system.eq.' K-POINT') then
         G_files=.true.
      else
         call exist_files(G_files,NEPR,IRA_Left,'G')
      end if
c
c............. check availability of E-files containing energies
c              at a number of atomic distortions
c
      call exist_files(E_files,NEPR,IRA_Left,'E')
c
c............. check availability of F-files containing forces on atoms
c              at a number of atomic distortions
c
      call do_F_mat_files(IRA_left,NEPR,N0IR,Err)
      if(Err) return
      call exist_files(F_files,NEPR,IRA_Left,'F')
c
c............. check availability of W-files containing the transformation
c              matrices for each irrep
c
      if(system.eq.' K-POINT') then
         W_files=.true.
      else
         call exist_files(W_files,NEPR,IRA_Left,'W')
      end if
c
c............ check if all necerssary files are available for at least one 
c             irrep
c
      do IA=1,NEPR
         if( (E_files(IA) .or. (W_files(IA) .and. F_files(IA)) ) 
     &                                    .and. G_files(IA) ) go to 19
      end do
      write(*,*)
     &  'ERROR! Some of G,F,W,E-files are unavailable for ANY irrep!'
      return
c
c..................................................................
c..................... Main menu starts here ......................
c..................................................................
c
 19   Yes_solved=.false. ;  active=.false. ; Yes_W_all=.false.
      Temp1=10.0; Temp2=500.0 ; Ntp=10 ; stepT=(Temp2-Temp1)/Ntp

 21   write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      if(system.eq.'MOLECULE') then
         write(*,'(2a)')' MOLECULE: lattice translations IGNORED' 
      else if(system.eq.' LATTICE') then
         write(*,'(2a)')' SUPERCELL: lattice translations USED'
         write(*,*)'... CURRENT lattice vectors for the supercell:...'
         write(*,'(a,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      else if(system.eq.'LATT-TRA' .or. system.eq.' K-POINT') then
         write(*,'(2a)')
     &        ' SUPERCELL: group of internal translations USED'
         write(*,'(a,10x,a,10x,a,10x,a)')
     &     ' #                SUPERCELL                        '//
     &     'PRIMITIVE CELL             EXTENTION'
         write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') 
     &'(1) ',(AJ(1,i),i=1,3),' | ',(AI(1,i),i=1,3),' | ',(IJ(1,i),i=1,3)
         write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') 
     &'(2) ',(AJ(2,i),i=1,3),' | ',(AI(2,i),i=1,3),' | ',(IJ(2,i),i=1,3)
         write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') 
     &'(3) ',(AJ(3,i),i=1,3),' | ',(AI(3,i),i=1,3),' | ',(IJ(3,i),i=1,3)
      end if
      write(*,'(a)')
      write(*,*)'========= CHOOSE an OPTION:'
      write(*,'(a)')
     &'--------------- E x i s t i n g --- I r r e p s ----------------'
      do IA=1,NEPR
         if( IRA_left(IA).ne.0 .and. do_IA(IA) ) then
            if(active .and. IA.eq.IA_active) then
               cha17='  <=== now active'
            else
               cha17='                 '
            end if
            write(chb1,'(i1)') NALFA(IA) ; if(kCmpl(IA).eq.1) chb1='2'
            if(IA.lt.10) then
               write(cha1,'(i1)') IA
               chax='  '//cha1//'. irrep ('//NAZVIR(IA)//
     &              ') is '//chb1//'D;  dim = '
            else
               write(cha2,'(i2)') IA
               chax=' '//cha2//'. irrep ('//NAZVIR(IA)//
     &              ') is '//chb1//'D;  dim = '
            end if
            if(via_Forces) then
               lg=F_files(IA).and.G_files(IA).and.W_files(IA)
               if(lg) write(*,'(a,i3,4(a,l1),a)') chax,IRA_left(IA),
     &              ch1,G_files(IA),ch3,F_files(IA),
     ,              ch4,W_files(IA),']'//cha17
            else
               lg=E_files(IA).and.G_files(IA).and.W_files(IA)
               if(lg) write(*,'(a,i3,4(a,l1),a)') chax,IRA_left(IA),
     &              ch1,G_files(IA),ch2,E_files(IA),
     ,              ch4,W_files(IA),']'//cha17
            end if
         end if
      end do

c________ action

      write(*,'(a)')
     &'------ A c t i o n s  w i t h  A c t i v e  I r r e p ----------'
      if(active) then
         if(Yes_solved) then
c            write(*,'(a)') ' Ei. Solve the eigenvalue problem <= Done!'
            write(*,'(a)') ' Sv. Show eigenvalues/vectors'
            write(*,'(a)') ' Sa. Show frequencies and normal modes'
            write(*,'(a)') ' Fr. Show the free energy contribution (eV)'
            write(*,'(a)') ' Vs. Write xyz geom file for each mode'
         else
            write(*,'(a)') ' Ei. Solve the eigenvalue problem'
         end if
      end if
      
c________ settings

      write(*,'(a)')
     &'---------------- G e n e r a l  S e t t i n g s ----------------'
      if(system.eq.'LATT-TRA' .or. system.eq.' K-POINT') then
         write(*,'(a)')' Kp. Show all k-points'
         if(system.eq.'LATT-TRA') then
            write(*,'(a)')' Sy. Show the symmetry group info'
         end if
      end if
      if(.not.via_Forces) then
         if(show_interp) then
            write(*,'(a)')
     &           ' Gn. Show interpolation for energies from F-files'
         else
            write(*,'(a)')
     &       ' Gn. Do NOT show interpolation for energies from F-files'
         end if
      else
        if(WhichForce.eq.'average') then
            write(*,'(a,f10.5)')' Wf. Which force: left-right average'
         else if(WhichForce.eq.'right-u') then
            write(*,'(a,f10.5)')' Wf. Which force: right-upper triangle'
         else if(WhichForce.eq.'left-lw') then
            write(*,'(a,f10.5)')' Wf. Which force: left-lower triangle'
         end if
      end if
c      write(*,'(a)')
c     &   ' XY. Format of <geom.xyz> file is for '//YES_xyz
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,'(a)')
     &        ' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,'(a)')
     &        ' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      if(Yes_Fixed) then
         if(.not.Show_fixed) then
            write(*,'(a)')' Sx. Show fixed atoms in tables: NO'
         else
            write(*,'(a)')' Sx. Show fixed atoms in tables: YES'
         end if
      end if
      write(*,'(a,f10.5)')' Da. Distortion amplitude for geoms: ',ampl 
      write(*,'(a,i10)')
     &     ' Np. [Free energy]: Number of temperature points: ',Ntp
      write(*,'(2(a,f10.5),a)')
     &' Tr. [Free energy]: Temperature range: [',Temp1,' - ',Temp2,']'
      stepT=(Temp2-Temp1)/Ntp
      write(*,'(a,f10.5,a)') 
     &     '                    Temperature step = ',stepT,' K'
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2  ; call right(cha2,2,l0)
      if(cha2.eq.'  ') go to 21
c
c[IA]..... first of all, choose one irrep and read/check the files
c

      read(cha2(l0:),'(i2)',err=27) n_IA
      DO IA=1,NEPR
         IF(n_IA.eq.IA .and. do_IA(IA)) then
            if(IRA_left(IA).eq.0) then
               write(*,*)'Error! Try again!' ; go to 21
            end if
            if(via_Forces) then
               lg=F_files(IA).and.G_files(IA).and.W_files(IA)
            else
               lg=E_files(IA).and.G_files(IA).and.W_files(IA)
            end if
            if(.not.lg) go to 21
            Ndim=IRA_left(IA)

            Err=.false.
c
c_______________ K-POINT method only __________________________
c
            if(system .eq. ' K-POINT')  then
              if(kCmpl(IA).eq.1 .and. 2*Ndim.gt.K0DM0)  then
                 stop 'eig_vibr.f: 2*Ndim > K0DM0'
              end if
              allocate(F_vk(Ndim,Ndim)) ; allocate(G_vk(Ndim,Ndim))
              call read_Fm_Vk(IA,Ndim,ITI,Err2,WhichForce,Which_Code,
     ,                                 AI,Nsp,NspN,F_vk,G_vk)
              Err=Err2 
              G_mat=0.0d0

              i=0
              do is=1,Nsp
                 do n=1,NspN(is)/MG_luc
                    do k=1,3
                       i=i+1 

                       j=0
                       do is1=1,Nsp
                          do n1=1,NspN(is)/MG_luc
                             do k1=1,3
                                j=j+1

                                F_mat(i,j)=F_vk(i,j)
                                if(kCmpl(IA).eq.1) then
                                   F_mat(Ndim+i,Ndim+j)=F_vk(i,j)
                                   F_mat(i,Ndim+j)=-G_vk(i,j)
                                   F_mat(Ndim+i,j)= G_vk(i,j)
                                end if

                             end do
                          end do
                       end do

                       G_mat(i,i)=1.0d0/AtMass(is)
                       if(kCmpl(IA).eq.1) 
     &                        G_mat(i+Ndim,i+Ndim)=1.0d0/AtMass(is)
                    end do
                 end do
              end do
              deallocate(F_vk) ; deallocate(G_vk)
              if(kCmpl(IA).eq.1) Ndim=2*Ndim
              Yes_W_all=.true.
c     
c_______________ OTHER methods ________________________________
c
            else

               Ndim_=Ndim
c___________ read in the G matirx for this irrep

               call read_G_matrix(IA,G_mat,Ndim,Err)
               if(Err) then
                  write(*,*)'FATAL! G-file is bad!'
                  G_files(IA)=.false.
               end if

c___________ read in the W_all matrix for this irrep
               Yes_W_all=.true.
               call read_W_all_matrix(IA,Ndim,Err1)
               if(Err1) then
                  write(*,*) 'FATAL! Cannot get W-file'
                  W_files(IA)=.false. ; Yes_W_all=.false.
               end if

c___________ read in the F matrix for this irrep 
               if(via_Forces) then
                  call read_F_matrix(IA,F_mat,Ndim,ITI,Err2,
     ,                 WhichForce,Which_Code)
                  if(Err2) then
                     write(*,*)'FATAL! F-file is bad!'
                     F_files(IA)=.false.
                  end if
                  Err=Err.and.Err1.and.Err2
               else

c___________ read in the E matrix for this irrep
                  call read_E_matrix(IA,F_mat,Ndim,Err3,show_interp)
                  if(Err3) then
                     write(*,*)'FATAL! E-file is bad!'
                     E_files(IA)=.false.
                  end if
                  Err=Err.and.Err1.and.Err3
               end if
            end if
            if(Err) go to 21
            IA_active=IA
            active=.true. ; Yes_solved=.false.
            go to 22
         END IF
      END DO
      go to 21
      
c____________ diagnalise it

 22   call solve_vibr(F_mat,G_mat,EigR,EigV,Ndim,Err)
      if(Err) then
         write(*,*)
     &  'ERROR! Cannot diagonalise: G-matrix has negative eigenvalues'
      else
         Yes_solved=.true.
      end if

c______________ calculate in W_all matrix the normal mode

      IA=IA_active
      if(Yes_W_all .and. system.ne.' K-POINT') then
         
         do iN=1,ITI
            do k=1,3
               do j=1,NALFA(IA)
                  do iR=1,IRA_left(IA)

                     s=0.0d0
                     do iR1=1,IRA_left(IA)
                        s=s+EigV(iR1,iR)*W_all(k,iN,iR1,j)
                     end do
                     work(iR)=s

                  end do
                  do iR=1,IRA_left(IA)
                     W_all(k,iN,iR,j)=work(iR)
                  end do
               end do
            end do
         end do
         
      end if
      go to 21
      
c[Sv]...... show eigenvalues/vectors prior to W_all multiplication
c           (i.e. mixing of generalised displacements)

 27   IF(cha2(l0:).eq.'Sv' .and. active .and. Yes_solved) THEN

         write(*,*)'>>>>>>>> RESULT of diagonalisation: <<<<<<<<<<<'
         call print_eigenproblem(EigR,EigV,Ndim,K0DM0,6)
         write(cha2,'(i2)') IA_active
         call posit(cha2,2,la)
         open(37,file='EIGEN_'//cha2(la:)//'.res',status='unknown')
         call print_eigenproblem(EigR,EigV,Ndim,K0DM0,37)
         close (37)
         write(*,'(/a)')
     &      '*******************************************************'
         write(*,'(a)')
     &       '   Full table can be also seen in the file EIGEN_'//
     &        cha2(la:)//'.res'
         write(*,'(a/)')
     &      '*******************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sa]...... show frequencies (in cm^-1) and normal modes; 
c       if a frequency is imaginary (EigR < 0), it is set to -1

      ELSE IF(cha2(l0:).eq.'Sa' .and. active .and. Yes_solved
     &                                       .and. Yes_W_all) THEN

         do k=1,Ndim
            if(EigR(k).ge.0.0d0) then
               Freq(k)=sqrt( EigR(k)*.9648667e+28 )*53.08837459E-13
            else
               Freq(k)=-1.0
            end if
         end do
         IA=IA_active
         write(cha2,'(i2)') IA_active ; call posit(cha2,2,la)
         open(37,file='N_MODES_'//cha2(la:)//'.res',status='unknown')
         if(system.ne.' K-POINT') then
            call show_normal_displ(IA,Ndim,Freq,Species,6,Show_fixed)
            call show_normal_displ(IA,Ndim,Freq,Species,37,Show_fixed)
         else
            call show_norm_dspl_Vk(IA,Ndim,Freq,nsp,NspN,Species,6)
            call show_norm_dspl_Vk(IA,Ndim,Freq,nsp,NspN,Species,37)
         end if
         close (37)
         write(*,'(/a)')
     &    '*********************************************************'
         write(*,'(a)')
     &       '   Full table can be also seen in the file N_MODES_'//
     &        cha2(la:)//'.res'
         write(*,'(a/)')
     &    '*********************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Fr]...... show the contribution to the quasiharmonic free energy from this irrep

      ELSE IF(cha2(l0:).eq.'Fr' .and. active .and. Yes_solved
     &                                       .and. Yes_W_all) THEN

         write(cha2,'(i2)') IA_active ; call posit(cha2,2,la)
         write(*,'(a)') 
     ,        '... Writing free energy into [free_'//cha2(la:)//'.en]'
         open(72,file='free_'//cha2(la:)//'.en', form='formatted')
         write(72,*)'#.... T(K) ... Zero en.(eV) ... Free en.(eV) ...'
         write(*,*) '#.... T(K) ... Zero en.(eV) ... Free en.(eV) ...'
         do k=1,Ndim
            if(EigR(k).ge.0.0d0) then
               omega=sqrt( EigR(k)*.9648667e+28 ) 
               write(*,*)'# freq = ',omega*53.08837459E-13,' cm^-1'
               write(72,*)'# freq = ',omega*53.08837459E-13,' cm^-1'
            end if
         end do

         do i=1,Ntp+1
            Temp=Temp1+(i-1)*stepT ; fren=0.0d0 ; zero=0.0d0

            do k=1,Ndim
               if(EigR(k).ge.0.0d0) then
                  omega=sqrt(EigR(k)*.9648667e+28 ) ; en = H_bar*omega
                  ex=exp(-en/(K_B*Temp)) 
                  zero=zero + en/2. ; fren=fren + K_B*Temp*log(1.0d0-ex)
               end if
            end do
            write(72,'(5x,f10.5,2(5x,e16.10))') Temp, zero, fren + zero
            write(*,'(5x,f10.5,2(5x,e16.10))') Temp, zero, fren + zero
         
         end do
         close(72)

c[Vs]...... create a xyz-geom for a normal mode

      ELSE IF(cha2(l0:).eq.'Vs' .and. active .and. Yes_solved
     &                                       .and. Yes_W_all) THEN

         IA=IA_active
         IRA=IRA_left(IA)
         if(IRA.gt.1) then
 6          write(*,'(a,i3)')
     &        'Specify a normal mode vector between 1 and ',IRA
            read(*,*,err=6) iV
            if(iV.lt.1 .or. iV.gt.IRA) go to 6
         else
            iV=1
         end if
         if(system.eq.' K-POINT' .and. kCmpl(IA).eq.1) then
            if(iV/2*2.eq.iV) iV=iV-1
         end if
         if(NALFA(IA).gt.1) then
 8          write(*,'(a,i3)')
     &        'Specify a normal mode row between 1 and ',NALFA(IA)
            read(*,*,err=8) j
            if(j.lt.1 .or. j.gt.NALFA(IA)) go to 8
         else
            j=1
         end if
         open(37,file='geom.xyz',form='formatted')
         do iang=0,360,10
            amp=2*ampl*sin(iang*pi/180.0)
            if(system.ne.' K-POINT') then
               call distorted_xyz(IRA,0,iV,j,amp,Species,ITI,
     ,                                          37,YES_xyz,Add_Hs)
            else
               call distorted_xyz_Vk(IA,Ndim,iV,amp,Species,Nsp,NspN,
     ,                                          ITI,37,Add_Hs)
            end if
         end do
         close (37)

c[Wf].... which force to be used to construct the force constant matrix

      ELSE IF(cha2(l0:).eq.'Wf' .and. via_Forces) THEN
 
        if(WhichForce.eq.'average') then
            WhichForce='right-u'
         else if(WhichForce.eq.'right-u') then
            WhichForce='left-lw'
         else if(WhichForce.eq.'left-lw') then
            WhichForce='average'
         end if

c[Kp].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Kp' .and. (system.eq.'LATT-TRA' 
     &                             .or. system.eq.' K-POINT')) THEN

         write(*,'(a/)')
     &        '... k-points of the original BZ for this extention ...'
         write(*,'(a)') ' # type|      in Cartesian (no 2*pi)     '//
     &     '  | ok-check  |           in fractional ',
     &     '------------------------------------------------------'//
     &     '-------------------------------------'
         do k=1,MG
            do j=1,3
               s=Vkp(k,1)*AJ(j,1)+Vkp(k,2)*AJ(j,2)+Vkp(k,3)*AJ(j,3)
               cs=cos(2*pi*s)
               sn=sin(2*pi*s)
               if(abs(cs-1.0).lt.tiny_equiv .and. 
     &                                  abs(sn).lt.tiny_equiv) then
                  cha(j)='ok'
               else
                  cha(j)='no'
               end if
            end do
            x(1)=AI(1,1)*Vkp(k,1)+AI(1,2)*Vkp(k,2)+AI(1,3)*Vkp(k,3)
            x(2)=AI(2,1)*Vkp(k,1)+AI(2,2)*Vkp(k,2)+AI(2,3)*Vkp(k,3)
            x(3)=AI(3,1)*Vkp(k,1)+AI(3,2)*Vkp(k,2)+AI(3,3)*Vkp(k,3)
            
            write(*,'(i3,x,i2,a,3(f10.5,x),a,3(a,x),a,3(x,f10.5))') 
     &        k,kCmpl(k),' | ',(Vkp(k,j),j=1,3),' | ',cha,' | ',x
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy' .and. system.eq.'LATT-TRA') THEN

         write(*,'(a)')'..... group information .....'
         write(*,'(a)')'irrep dim MRR         k-vector (fractional)' 
         write(*,'(a)')'---------------------------------------------' 
         do IA=1,NEPR
            x(1)=AI(1,1)*Vk_rep(IA,1)+AI(1,2)*Vk_rep(IA,2)+
     +                 AI(1,3)*Vk_rep(IA,3)
            x(2)=AI(2,1)*Vk_rep(IA,1)+AI(2,2)*Vk_rep(IA,2)+
     +                 AI(2,3)*Vk_rep(IA,3)
            x(3)=AI(3,1)*Vk_rep(IA,1)+AI(3,2)*Vk_rep(IA,2)+
     +                 AI(3,3)*Vk_rep(IA,3)
            write(*,'(i3,2(3x,i1),3(x,f10.5))') 
     &           IA,NALFA(IA),ICMPL(IA),(x(j),j=1,3)
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Gn]...... show interpolation for energies during reading from the
c           corresponding F-files

      ELSE IF(cha2(l0:).eq.'Gn' .and. (.not.via_Forces)) THEN

         if(show_interp) then
            show_interp=.false.
         else 
            show_interp=.true.
         end if

c[Da]...... displacement amplitude for geoms

      ELSE IF(cha2(l0:).eq.'Da') THEN

 13      write(*,*)'Specify the amplitude of distortion (in A):'
         read(*,*,err=13) ampl

c[Np]...... number of points of T for the free energy

      ELSE IF(cha2(l0:).eq.'Np') THEN

 14      write(*,*)'Specify the number of T points for the free energy:'
         read(*,*,err=14) Ntp
         if(Ntp.lt.1) go to 14


c[Tr]...... Temperature range for the free energy

      ELSE IF(cha2(l0:).eq.'Tr') THEN

 15      write(*,*)'Specify the min and max temperatures (in K):'
         read(*,*,err=15) Temp1, Temp2
         if(Temp1.lt.1.0 .or. Temp2. lt. 1.0 
     &                       .or. Temp1.gt.Temp2) go to 15

c[XY]...... ask the code for geom.xyz file 

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='Ymol'
c         end if

c[Hs]...... add Hydrogens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[Sx]...... if to show fixed atoms in tables

      ELSE IF(cha2(l0:).eq.'Sx' .and. Yes_Fixed) THEN

         if(Show_fixed) then
            Show_fixed=.false.
         else
            Show_fixed=.true.
         end if

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21

      end

      subroutine read_E_matrix(IA,F,Ndim,Err,show)
c....................................................................
c  read energies and calculate the force-constant matrix in terms
c  of generalised coordinates, the F-matrix, for given irrep IA.
c  show - if .true., interploation for each element of the F-matrix
c         is checked with gnuplot
c....................................................................
c  The structure of the E-file this routine understands is this:
c
c (1) the file consists of blocks of data for each i,j=1,Ndim
c (2) each block starts from the line:
c       #   i j
c     which starts from # and contains particular values of (i,j)
c (3) the order of block does not matter
c (4) if i.ne.j, a block for either (i,j) or (j,i) may only be 
c     present  
c (5) in each block the data are arranged as two columns of X,Y
c         X(1)  Y(1)
c         X(2)  Y(2)
c       .................
c     where X() is the amplitude (dimensionless), Y() - energy (eV)
c (6) arbitrary number of input points within a block (up to Npoints)
c     is allowed and can be different in every block
c (7) all the data should follow by the end line:
c       # end  
c....................................................................
      include 'real8.inc'
      parameter (Npoints=10)
      dimension F(K0DM0,K0DM0),X(Npoints),Y(Npoints)
      character cha1,cha2*2
      logical Err,all(K0DM0,K0DM0),all_here,show
      character Line*200
      integer LinEnd(100),LinPos(100)

      Err=.false.
c.............. initialise
      do i=1,Ndim
         do j=1,Ndim
            all(i,j)=.false.
         end do
      end do

c.............. open the file
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (23,file='E_'//cha1//'.mat',form='formatted',
     ,        status='old',err=10)
      else 
         write(cha2,'(i2)') IA
         open (23,file='E_'//cha2//'.mat',form='formatted',
     ,        status='old',err=10)
      end if

c.............. read the file and fill in the matrix F(i,j)

      k=0
 5    call CutStr(Line,NumLin,LinPos,LinEnd,23,0,iErr)
      if(iErr.ne.0) go to 9
      if(index(Line,'##').ne.0) go to 5
      if(index(Line,'#').ne.0) then
         if(k.ne.0) then
            num=k
            write(*,'(a,i2,a)')'found ',num,' points for interpolation'
            if(num.lt.3 .or. num.gt.Npoints) then
               write(*,*)'ERROR! # of points is too small or large!'
               go to 9
            end if
            call fit(F(i,j),X,Y,num,show)
            all(i,j)=.true.
         end if
         if(index(line,'end').ne.0) go to 20
         read(line(LinPos(2):),*,err=9,end=9) i,j
         if(i.lt.1 .or. i.gt.Ndim) go to 9
         if(j.lt.1 .or. j.gt.Ndim) go to 9
         write(*,'(3(a,i3),a)')
     &   '... irrep =',IA,', reading E-matrix  for (i,j)= (',i,',',j,')'
         k=0
      else
         k=k+1
         if(k.gt.Npoints) then
            write(*,*)'ERROR in reading E-file: too many points!'
            go to 9
         end if
         read(line,*,err=9) X(k),Y(k)
         write(*,*) k,X(k),Y(k)
      end if
      go to 5

c............. check if all elements were supplied and symmetrise the matrix

 20   close (23)
      all_here=.true.
      do i=1,Ndim
         do j=i,Ndim
            if(i.eq.j) then
               if(.not.all(i,i)) then
                  all_here=.false.
                  write(*,'(2(a,i3),a)')'missing (i,i) = (',i,',',i,')'
               end if
            else
               if(all(i,j)) then
                  F(j,i)=F(i,j)
               else if(all(j,i)) then
                  F(i,j)=F(j,i)
               else
                  all_here=.false.
                  write(*,'(2(a,i3),a)')
     &                             'missing (i,j) = (',i,',',j,') pair'
               end if
            end if
         end do
      end do
      if(.not.all_here) go to 10

c...............  eliminate contributions from the diagonal part: get the final
c                 matrix of second derivatives
      do i=1,Ndim
         do j=i,Ndim
            if(i.ne.j) then
               F(i,j)=0.5*( F(i,j)-F(i,i)-F(j,j))
               F(j,i)=F(i,j)
            end if
         end do
         write(*,'(i2,20(x,e12.6))') i,(F(i,j),j=1,Ndim)
      end do
      write(*,'(a,i2,a)')
     &   'The file E_IA.mat for irrep IA=',IA,' was read successfully!'
      return
c
c....... error
 9    close (23)
 10   write(*,*)'FATAL error while reading E-file for irrep = ',IA
      Err=.true.
      return
      end

      subroutine read_G_matrix(IA,G,Ndim,Err)
c..............................................................
c  read G matrix for given irrep IA
c..............................................................
      include 'real8.inc'
      dimension G(K0DM0,K0DM0)
      character cha1,cha2*2
      logical Err

      Err=.false.
      write(*,'(a,i2)')'.... G-matrix ....... for irrep= ',IA
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (23,file='G_'//cha1//'.mat',form='formatted',
     ,        status='old',err=10)
      else 
         write(cha2,'(i2)') IA
         open (23,file='G_'//cha2//'.mat',form='formatted',
     ,        status='old',err=10)
      end if
      do i=1,Ndim
         do j=1,Ndim
            read(23,*,err=9,end=9) i1,j1,G(i,j)
            if(i.ne.i1 .or. j.ne.j1) go to 9
         end do
         write(*,'(i3,10(x,e12.6))') i,(G(i,j),j=1,Ndim)
      end do
      close (23)
      write(*,'(a,i2,a)')
     &   'The file G_IA.mat for irrep IA=',IA,' was read successfully!'
      return
c
c....... error
 9    close (23)
 10   write(*,*)'FATAL error while reading G-file for irrep = ',IA
      Err=.true.
      end

      subroutine fit(F,X,Y,Np,show)
c........................................................
c  least square fit for the data (X,Y);
c    calculation of the 2nd derivative of Y(X) in F
c........................................................
      include 'real8.inc'
      character chaB,chaC,line1*55
      character cha1*14,cha2*14,cha3*14
      dimension Y(Np),X(Np)
      logical show

      write(*,*) 'Np= ',Np
      call quadr(Y,X,Np,a,b,c,err)
      Xmin=-b/(2*c)
      write(6,*) 'Xmin=',Xmin
c___________2nd derivative in the minimum
      F=2*c
      write(6,*)' Second derivative=', F

c
c............. if to show, then:
c
      if(show) then
         open(33,file='tmp.tmp',form='formatted')
         do i=1,np
            write(33,*) x(i),y(i)
         end do
         close (33)
c
c___________________ prepare gnuplot demonstration
         write(cha1,'(g14.8)') a
         chaB='+'
         if(b.lt.0.0) chaB=' '
         write(cha2,'(g14.8)') b
         chaC='+'
         if(c.lt.0.0) chaC=' '
         write(cha3,'(g14.8)') c
         line1='f(x)='//cha1//chaB//cha2//'*x'//chaC//cha3//'*x*x'
         write(*,'(a)') line1
         open (21,file='1.gnu',form='formatted')
         write(21,'(a55)') line1
         write(21,'(a)') 'plot "tmp.tmp", f(x)'
         write(21,'(a)') 'pause -1'
         close (21)
         call system('gnuplot 1.gnu') 
         call system('/bin/rm tmp.tmp')
      end if
      return
      end

      subroutine read_W_all_matrix(IA,IRA,Err)
c.............................................................
c read the symmetry-adapted displacements from W_IA.mat
c IA     - given irrep
c IRA    - the number of liunearly independent vectors left
c          after taking out transl/rot constraints
c.............................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      integer rep
      character cha1,cha2*2
      logical Err

      Err=.false.
      if(IRA.gt.K0DM0+6) then
         write(*,*) 'ERROR! Increase K0DM0 in sym_par.inc'
         go to 10
      end if
c
c........... open the file
c
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (23,file='W_'//cha1//'.mat',form='formatted',err=10)
      else 
         write(cha2,'(i2)') IA
         open (23,file='W_'//cha2//'.mat',form='formatted',err=10)
      end if
c
c........... write on the screen/file
c
      iN=0
      do iOrb=1,NORB
         do nat=1,KAN(iOrb)
            iN=iN+1
            do i=1,3
               read(23,*,err=10,end=10) 
     &            ((W_all(i,iN,rep,j),j=1,NALFA(IA)),rep=1,IRA)
            end do
         end do
      end do
      close (23)
      write(*,'(a,i2,a)')
     &   'The file W_IA.mat for irrep IA=',IA,' was read successfully!'
      return
c
c......... error
 10   Err=.true.
      write(*,*)'ERROR! W_IA.mat file is bad or absent for IA=',IA
      return
      end

      subroutine exist_files(Files,NEPR,IRA_Left,cha)
c...........................................................................
c  Checks if files cha_IA.mat (IA - irrep number) exist.
c  Files(IA = .true. is yes for this irrep IA)
c...........................................................................
      include 'real8.inc'
      dimension IRA_left(N0IR)
      logical Files(N0IR)
      character cha*1,cha1,cha2*2
      
      do 10 IA=1,NEPR
         if(IRA_left(IA).eq.0) go to 10
         Files(IA)=.false.
         if(IA.lt.10) then
            write(cha1,'(i1)') IA
            open (23,file=cha//'_'//cha1//'.mat',form='formatted',
     ,                             status='old',err=10)
         else 
            write(cha2,'(i2)') IA
            open (23,file=cha//'_'//cha2//'.mat',form='formatted',
     ,                             status='old',err=10)
         end if
         Files(IA)=.true.
         close (23)
 10   end do
      end

      subroutine read_F_matrix(IA,F,Ndim,ITI,Err,WhichForce,Which_Code)
c....................................................................
c  read F matrix for given irrep IA.
c....................................................................
c  The structure of the F-file this routine understands is this:
c
c (1) the file consists of blocks of data for each i=1,Ndim
c (2) each block starts from the line:
c       #   i  j directory=ampl
c     which starts from # and contains a particular values of i,
c     amplitude number j and the amplitude directory ampl used in 
c     option V1 of the main menu to generate the corresponding distortion
c (3) the order of blocks does not matter
c (4) for each i there could be several blocks of data corresponding to
c     1,2 or 4 values of ampl
c (5) in each block the data are arranged as three columns of forces
c     on atoms X,Y,Z (eV/A):
c       <---something before--->  X(1)  Y(1)  Z(1)
c       <---something before--->  X(2)  Y(2)  Z(2)
c       ....................
c     Atoms are ordered in the same way as in the input file created
c     by option V1 (and they will be in the output automatically in 
c     the same order then). The forces should be the last 3 columns.
c (6) all the data should follow by the end line:
c       # end  
c....................................................................
      include 'real8.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension F(K0DM0,K0DM0),ampl(K0DM0,4)
      dimension gen_force(K0DM0,K0DM0,4)
      character cha1,cha2*2,WhichForce*7,Which_Code*6
      double precision lambda12,lambda34
      logical Err,all(K0DM0,4),all_here,large_error,compare_2_real
      data tiny/0.00001/

      Err=.false.
c.............. initialise
      F=0.0d0 ; all=.false.

c.............. open the file
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (24,file='F_'//cha1//'.out',form='formatted',
     ,                                               status='unknown')
      else 
         write(cha2,'(i2)') IA
         open (24,file='F_'//cha2//'.out',form='formatted',
     ,                                               status='unknown')
      end if

c.............. read forces for all amplitudes (in gen_force)

      call read_forces(23,IA,Ndim,ITI,gen_force,Which_Code,all,Ndispl,
     ,                                                       ampl,Err)
      if(Err) go to 9

c............. check if all elements were supplied 

 20   all_here=.true.
      do iR=1,Ndim
         do iD=1,Ndispl
            if(.not.all(iR,iD)) then
               all_here=.false.
               write(*,'(2(a,i3))')'missing iR = (',iR,'), iD= ',iD
            end if
         end do
      end do

c............. calculate the force constant matrix in terms of 
c              generalised coordinates, the F-matrix, using 
c              generalised force

      do iR=1,Ndim
         if(all(iR,1)) then
            do iR1=1,Ndim
               if(Ndispl.eq.1) then
                  F(iR1,iR)=-gen_force(iR1,iR,1)/ampl(iR,1)
               else if(Ndispl.eq.2) then
                  lambda12=(ampl(iR,1)/ampl(iR,2))**2
                  a12=gen_force(iR1,iR,1)-lambda12*gen_force(iR1,iR,2)
                  am=ampl(iR,1)-lambda12*ampl(iR,2)
                  F(iR1,iR)= -a12/am
                  write(24,'(2(a,i2))')
     &                 '=====> working out iR,iR1=',iR,',',iR1
                  write(24,'(3(e12.6,x),f10.5)') 
     &             gen_force(iR1,iR,1),gen_force(iR1,iR,2),F(iR1,iR),am
               else if(Ndispl.eq.4) then
                  lambda12=(ampl(iR,1)/ampl(iR,2))**2
                  lambda34=(ampl(iR,3)/ampl(iR,4))**2
                  a12=gen_force(iR1,iR,1)-lambda12*gen_force(iR1,iR,2)
                  a34=gen_force(iR1,iR,3)-lambda34*gen_force(iR1,iR,4)
                  delta=ampl(iR,1)*ampl(iR,2)-ampl(iR,3)*ampl(iR,4)
                  a1=ampl(iR,3)*ampl(iR,4)/(ampl(iR,1)*(1.0-
     -                                          ampl(iR,1)/ampl(iR,2)))
                  a2=ampl(iR,1)*ampl(iR,2)/(ampl(iR,3)*(1.0-
     -                                          ampl(iR,3)/ampl(iR,4)))
                  F(iR1,iR)=(a1*a12-a2*a34)/delta
               end if
            end do
         else
            do iR1=1,Ndim
               F(iR1,iR)=0.0d0
            end do
         end if
      end do

      write(24,'(/a/)')
     &'>>>>>>>> Force Constant matrix before symmetrisation <<<<<<<<<<<'
      do iR=1,Ndim
         write(24,'(i3,14(x,e12.6))') iR,(F(iR1,iR),iR1=1,Ndim)
      end do

c.............. symmetrise the force constant matrix

      if(.not.all_here) then
         write(*,*)'PROBLEM: Force constant matrix is NOT complete!'
         go to 9
      end if

      write(*,'(a,i2,a)')
     &   'The file F_IA.mat for irrep IA=',IA,' was read successfully!'

      large_error=.false.
      j=0
      write(*,'(/a/)')
     &'>>>>>>>> Force Constant matrix after symmetrisation <<<<<<<<<<<<'
      write(24,'(/a/)')
     &'>>>>>>>> Force Constant matrix after symmetrisation <<<<<<<<<<<<'
      do iR=1,Ndim
         do iR1=iR,Ndim
            if(.not.compare_2_real(F(iR1,iR),F(iR,iR1),24)) then
               write(24,'(2(a,i3),a)')
     &              'WARNING! Non-diagonal elements (',iR,',',iR1,
     &              ') of FC-matrix are different as shown above'
               large_error=.true.
               j=j+1
            end if
            if(WhichForce.eq.'average') then
               F(iR,iR1)=0.5*( F(iR,iR1) + F(iR1,iR) ) 
               F(iR1,iR)=F(iR,iR1)
            else  if(WhichForce.eq.'right-u') then
               F(iR1,iR)=F(iR,iR1)
            else if(WhichForce.eq.'left-lw') then
               F(iR,iR1)=F(iR1,iR)
            end if
         end do
         write(24,'(i3,14(x,e12.6))') iR,(F(iR,iR1),iR1=1,Ndim)
c         write(*,'(i3,14(x,e12.6))') iR,(F(iR,iR1),iR1=1,Ndim)
      end do
c
c......... if large errors found
c
      if(large_error) then
         write(*,*)
     &      'WARNING! You have more than 5% error in the Hessian matrix'
         if(IA.lt.10) then
            write(*,*)
     &   'in ',j,' elements. See file F_'//cha1//'.out for more details'
         else 
            write(*,*)
     &   'in ',j,' elements. See file F_'//cha2//'.out for more details'
         end if
         write(*,*)'Consider using smaller distrotion amplitudes'
         write(*,*)'and better precision in DFT calculations'
      end if
      close (24)
      return
c     
c....... error
 9    write(*,*)'FATAL error while reading F-file for irrep = ',IA
      Err=.true.
      end

      subroutine do_F_mat_files(IRA_left,NEPR,N0IR,Err)
c....................................................................
c runs script collect_forces to assemble F_#.mat files
c....................................................................
      include 'whereis.inc'
      integer IRA_left(N0IR)
      character cha*3
      logical Err

      if(NEPR.gt.999) then
         write(*,*)
     &    'FATAL error in do_F_mat_files: will NOT work if NEPR > 999!'
         Err=.true.
         return
      end if
      do IA=1,NEPR
         if(IRA_left(IA).ne.0) then
            write(cha,'(i3)') IA
c            call system('$HOME_TETR/collect_forces '//cha)
            call system(tetr_dir(tetr_l0:)//'/collect_forces '//cha)
         end if
      end do
      Err=.false.
      return
      end

      subroutine read_Fm_Vk(IA,Ndim,ITI,Err,WhichForce,Which_Code,
     ,                                              AI,Nsp,NspN,F,G)
c....................................................................
c  read F matrix for given k-point IA (Vk method only).
c....................................................................
      include 'real8.inc'
      include 'symgenv.inc'
      include 'working.inc'
      include 'systema.inc'
      include 'vk_vibr.inc'
      include 'space.inc'
      dimension ampl(K0DM0,4)
      dimension F(Ndim,Ndim),G(Ndim,Ndim),x(3)
      dimension gen_force(K0DM0,K0DM0,4),gen_force1(K0DM0,K0DM0,4)
      character cha1,cha2*2,WhichForce*7,Which_Code*6,a(3)
      double precision l12,l34,AI(3,3)
      logical Err,all(K0DM0,4),all_here,large_error,compare_2_real
      integer NspN(N0KD)
      data tiny/0.00001/,a/'x','y','z'/

c.............. initialise
      Err=.false. ; all=.false. 
      F=0.0d0 ; G=0.0d0 ; kC=kCmpl(IA)

c.............. open the one (k point) or two (k and -k) F_#.mat 
c               files for input and one F_#.out for output 
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open(24,file='F_'//cha1//'.out',form='formatted',
     ,                                               status='unknown')
         open(34,file='D_'//cha1//'.fcm',form='formatted',
     ,                                               status='unknown')
      else 
         write(cha2,'(i2)') IA
         open(24,file='F_'//cha2//'.out',form='formatted',
     ,                                               status='unknown')
         open(34,file='D_'//cha2//'.fcm',form='formatted',
     ,                                               status='unknown')
      end if
      write(34,'(a)')'# force constant matrix'


c.............. read forces for all amplitudes (in gen_force)

      if(kC.eq.0) then
         fctr= sqrt(MG_luc*1.)
         call read_forces_Vk(23,IA,Ndim,ITI,gen_force,Which_Code,
     ,        Nsp,NspN,all,Ndispl,ampl,fctr,Err)
      else
c___________________ getting the real part of the force-constant matrix
         fctr= sqrt(MG_luc/2.)
         call read_forces_Vk(23,IA,Ndim,ITI,gen_force,Which_Code,
     ,        Nsp,NspN,all,Ndispl,ampl,fctr,Err)
c___________________ getting the imaginary part of the force-constant matrix
         fctr=-sqrt(MG_luc/2.)
         call read_forces_Vk(25,IA+1,Ndim,ITI,gen_force1,Which_Code,
     ,        Nsp,NspN,all,Ndispl,ampl,fctr,Err)
      end if
      if(Err) go to 9

c............. check if all elements were supplied 

 20   all_here=.true.
      do iR=1,Ndim
         do iD=1,Ndispl
            if(.not.all(iR,iD)) then
               all_here=.false.
               write(*,'(2(a,i3))')'missing iR = (',iR,'), iD= ',iD
            end if
         end do
      end do

c............. calculate the force constant matrix in terms of 
c              generalised coordinates, the F-matrix, using 
c              generalised force

      do iR=1,Ndim
         if(all(iR,1)) then
            do iR1=1,Ndim
               write(24,'(2(a,i2))')
     &                 '=====> working out iR,iR1=',iR,',',iR1
               if(Ndispl.eq.1) then
                  F(iR1,iR)=-gen_force(iR1,iR,1)/ampl(iR,1)
                  G(iR1,iR)=-gen_force1(iR1,iR,1)/ampl(iR,1)
               else if(Ndispl.eq.2) then
                  l12=(ampl(iR,1)/ampl(iR,2))**2
                  am=ampl(iR,1)-l12*ampl(iR,2)
                  a12=gen_force(iR1,iR,1)-l12*gen_force(iR1,iR,2)
                  F(iR1,iR)= -a12/am
                  write(24,'(3(e12.6,x),f10.5)') 
     &              gen_force(iR1,iR,1),gen_force(iR1,iR,2),F(iR1,iR),am
                  a12=gen_force1(iR1,iR,1)-l12*gen_force1(iR1,iR,2)
                  G(iR1,iR)= -a12/am
                  write(24,'(3(e12.6,x),f10.5)') 
     &            gen_force1(iR1,iR,1),gen_force1(iR1,iR,2),G(iR1,iR),am
               else if(Ndispl.eq.4) then
                  l12=(ampl(iR,1)/ampl(iR,2))**2
                  l34=(ampl(iR,3)/ampl(iR,4))**2
                  delta=ampl(iR,1)*ampl(iR,2)-ampl(iR,3)*ampl(iR,4)
                  a1=ampl(iR,3)*ampl(iR,4)/(ampl(iR,1)*(1.0-
     -                                          ampl(iR,1)/ampl(iR,2)))
                  a2=ampl(iR,1)*ampl(iR,2)/(ampl(iR,3)*(1.0-
     -                                          ampl(iR,3)/ampl(iR,4)))
                  a12=gen_force(iR1,iR,1)-l12*gen_force(iR1,iR,2)
                  a34=gen_force(iR1,iR,3)-l34*gen_force(iR1,iR,4)
                  F(iR1,iR)=(a1*a12-a2*a34)/delta
                  a12=gen_force1(iR1,iR,1)-l12*gen_force1(iR1,iR,2)
                  a34=gen_force1(iR1,iR,3)-l34*gen_force1(iR1,iR,4)
                  G(iR1,iR)=(a1*a12-a2*a34)/delta
               end if
            end do
         else
            do iR1=1,Ndim
               F(iR1,iR)=0.0d0 ; G(iR1,iR)=0.0d0
            end do
         end if
      end do

      write(24,'(/a/)')
     &'>>>>>>>> Force Constant matrix before symmetrisation <<<<<<<<<<<'
      if(system.eq.' K-POINT' .and. kC.ne.0) 
     &     write(24,'(/a/)')'======== REAL PART ======='
      do iR=1,Ndim
         write(24,'(i3,14(x,e12.6))') iR,(F(iR1,iR),iR1=1,Ndim)
      end do
      if(system.eq.' K-POINT' .and. kC.ne.0) then
         write(24,'(/a/)')'======== IMAGINARY PART ======='
         do iR=1,Ndim
            write(24,'(i3,14(x,e12.6))') iR,(G(iR1,iR),iR1=1,Ndim)
         end do
      end if

c.............. symmetrise the force constant matrix

      if(.not.all_here) then
         write(*,*)'PROBLEM: Force constant matrix is NOT complete!'
         go to 9
      end if

      write(*,'(a,i2,a)')
     &   'The file F_IA.mat for irrep IA=',IA,' was read successfully!'
      if(system.eq.' K-POINT' .and. kC.ne.0) then
         write(*,'(a,i2,a)')
     &     'file F_IA.mat for irrep IA=',IA+1,' was read successfully!'
      end if
      large_error=.false.
      j=0
      write(*,'(/a/)')
     &'>>>>>>>> Force Constant matrix after symmetrisation <<<<<<<<<<<<'
      write(24,'(/a/)')
     &'>>>>>>>> Force Constant matrix after symmetrisation <<<<<<<<<<<<'
      do iR=1,Ndim
         do iR1=iR,Ndim
            if(.not.compare_2_real(F(iR1,iR),F(iR,iR1),24)) then
               write(24,'(2(a,i3),a)')
     &              'WARNING! Non-diagonal elements (',iR,',',iR1,
     &              ') of F-matrix are different as shown above'
               large_error=.true.
               j=j+1
            end if
            if(.not.compare_2_real(G(iR1,iR),-G(iR,iR1),24)) then
               write(24,'(2(a,i3),a)')
     &              'WARNING! Non-diagonal elements (',iR,',',iR1,
     &              ') of G-matrix are different as shown above'
               large_error=.true.
               j=j+1
            end if
            if(WhichForce.eq.'average') then
               F(iR,iR1)=0.5*( F(iR,iR1) + F(iR1,iR) ) 
               G(iR,iR1)=0.5*( G(iR,iR1) - G(iR1,iR) ) 
               F(iR1,iR)=F(iR,iR1) 
               G(iR1,iR)=-G(iR,iR1)
            else  if(WhichForce.eq.'right-u') then
               F(iR1,iR)=F(iR,iR1) 
               G(iR1,iR)=-G(iR,iR1)
            else if(WhichForce.eq.'left-lw') then
               F(iR,iR1)=F(iR1,iR) 
               G(iR,iR1)=-G(iR1,iR)
            end if
         end do
         write(24,'(i3,14(x,e12.6))') iR,(F(iR,iR1),iR1=1,Ndim)
         write(24,'(i3,14(x,e12.6))') iR,(G(iR,iR1),iR1=1,Ndim)
      end do
c
c......... write elements of the force contsnat matrix for this IA
c          (k point) [ ==>  for the Vk method only]
c
       
      write(34,'(a,i3)') '# k-point number IA= ',IA
      write(34,'(a)') '# The k-point (with 2*pi, in A^{-1}):'
      write(34,*) (2*pi*Vkp(IA,j),j=1,3)
      write(34,'(a)') '# The k-point (in fractional):'
      x(1)=AI(1,1)*Vkp(IA,1)+AI(1,2)*Vkp(IA,2)+AI(1,3)*Vkp(IA,3)
      x(2)=AI(2,1)*Vkp(IA,1)+AI(2,2)*Vkp(IA,2)+AI(2,3)*Vkp(IA,3)
      x(3)=AI(3,1)*Vkp(IA,1)+AI(3,2)*Vkp(IA,2)+AI(3,3)*Vkp(IA,3)
      write(34,*) x
      write(34,'(/a/)') '# The force-constant matrix (Re):'
      write(34,'(a)') '# dim cell# Sp xyz  |==> components '
      nat=0 ; iR=0 
      do is=1,Nsp
         do n=1,NspN(is)/MG_luc
            nat=nat+1
            do i=1,3
               iR=iR+1
               write(34,'(2x,3(i3,x),a,x,3x,6(e12.6,x))') 
     ,                 iR,nat,is,a(i),(F(iR,iR1),iR1=1,Ndim)
            end do
         end do
      end do
      write(34,'(/a/)') '# The force-constant matrix (Im):'
      write(34,'(a)') '# dim cell# Sp xyz  |==> components '
      nat=0 ; iR=0 
      do is=1,Nsp
         do n=1,NspN(is)/MG_luc
            nat=nat+1
            do i=1,3
               iR=iR+1
               write(34,'(2x,3(i3,x),a,x,3x,6(e12.6,x))') 
     ,                 iR,nat,is,a(i),(G(iR,iR1),iR1=1,Ndim)
            end do
         end do
      end do

c
c......... if large errors found
c
      if(large_error) then
         write(*,*)
     &      'WARNING! You have more than 5% error in the Hessian matrix'
         if(IA.lt.10) then
            write(*,*)
     &   'in ',j,' elements. See file F_'//cha1//'.out for more details'
         else 
            write(*,*)
     &   'in ',j,' elements. See file F_'//cha2//'.out for more details'
         end if
         write(*,*)'Consider using smaller distrotion amplitudes'
         write(*,*)'and better precision in DFT calculations'
      end if
      close (24) ; close(34)
      return
c     
c....... error
 9    write(*,*)'FATAL error while reading F-file for irrep = ',IA
      Err=.true.
      end

      subroutine read_forces(NFIL,IA,Ndim,ITI,gen_force,Which_Code,
     ,                                           all,Ndispl,ampl,Err)
      include 'real8.inc'
      include 'working.inc'
      dimension ampl(K0DM0,4),forces(N0LT,3)
      dimension gen_force(K0DM0,K0DM0,4)
      character cha1,cha2*2,Which_Code*6
      logical all(K0DM0,4),Err
      character Line*200
      integer LinEnd(100),LinPos(100)
      data eVpA/51.423/

c.............. initialise
      all=.false. ; Err=.false. ; gen_force=0.0d0

      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (NFIL,file='F_'//cha1//'.mat',form='formatted',
     ,        status='old',err=9)
      else
         write(cha2,'(i2)') IA
         open (NFIL,file='F_'//cha2//'.mat',form='formatted',
     ,        status='old',err=9)
      end if

c.............. read number of displacements as the 1st line

      call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,0,iErr)
      if(iErr.ne.0) go to 9
      if(index(Line,'# amplitudes').ne.0) then
         read(line(LinPos(3):),*,err=9,end=9) Ndispl
         write(*,*)'Number of amplitudes found = ',Ndispl
         write(24,*)'Number of amplitudes found = ',Ndispl
         if(Ndispl.ne.1 .and. Ndispl.ne.2 .and. Ndispl.ne.4) go to 9 
      else
         go to 9
      end if

c.............. read the file with ATOMIC forces; 
c               they will have to be symmetrised (in the next block)

 5    call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,0,iErr)
      if(iErr.ne.0) go to 9
      if(index(Line,'##').ne.0) go to 5
      if(index(Line,'#').ne.0) then
         if(index(line,'end').ne.0) go to 10
         read(line(LinPos(2):),*,err=9) iR,iD
         do i=LinPos(4),LinEnd(4)
            if(line(i:i).eq.'=') then
               ip=i ; go to 6
            end if
         end do
         go to 9
 6       read(line(ip+1:),*,err=9) ampl(iR,iD)
         if(iR.lt.1 .or. iR.gt.Ndim) go to 9
         if(iD.lt.1 .or. iD.gt.Ndispl) go to 9
         write(24,'(3(a,i3),a,f10.5)') '... irrep =',IA,
     ,    ', F-matrix for iR= (',iR,'), iD= ',iD, ' ampl= ',ampl(iR,iD)
         do iN=1,ITI
            call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,0,iErr)
            if(iErr.ne.0 .or. NumLin.lt.3) go to 9
            read(Line(LinPos(NumLin-2):),*,err=9) (forces(iN,j),j=1,3)
c_________________ rework froces from a.u. to eV/A (only CP2K) _________
            if(Which_Code.eq.'QUICKS') then
               forces(iN,1:3)=forces(iN,1:3)*eVpA
            end if
c_______________________________________________________________________
            write(24,'(a,i3,a,3(e12.6,x))') 
     &      'at = ',iN, ' force f = ',(forces(iN,j),j=1,3)
         end do
         all(iR,iD)=.true.

c................. get the force acting on the iR-th generalised 
c                  coordinate (row index is 1), displacement iD
c  gen_force(iR1,iR,iD) - generalised force on the generalised coordinate iR1
c                         due to excitation of the generalised coordinate iR 
c                         because of the displacement ampl(iR,iD)
c
         do iR1=1,Ndim
            s=0.0
            do iN=1,ITI
               s=s+forces(iN,1)*W_all(3,iN,iR1,1)+
     +              forces(iN,2)*W_all(1,iN,iR1,1)+
     +              forces(iN,3)*W_all(2,iN,iR1,1)
            end do
            gen_force(iR1,iR,iD)=s
         end do
         write(24,'(a,6(e12.6,x))')
     &        'gen. forces = ',(gen_force(iR1,iR,iD),iR1=1,Ndim)
      end if
      go to 5
 10   close (NFIL)
      return

c............. if error

 9    close (NFIL)
      write(*,*)'FATAL error while reading F-file for irrep = ',IA
      Err=.true.
      end

      subroutine read_forces_Vk(NFIL,IA,Ndim,ITI,gen_force,Which_Code,
     ,                               Nsp,NspN,all,Ndispl,ampl,fctr,Err)
      include 'real8.inc'
      include 'working.inc'
      include 'vk_vibr.inc'
      dimension ampl(K0DM0,4),forces(N0LT,3)
      dimension gen_force(K0DM0,K0DM0,4)
      character cha1,cha2*2,Which_Code*6
      logical all(K0DM0,4),Err
      character Line*200
      integer LinEnd(100),LinPos(100),NspN(N0KD)
      data eVpA/51.423/

c.............. initialise
      all=.false. ; Err=.false. ; gen_force=0.0d0

      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (NFIL,file='F_'//cha1//'.mat',form='formatted',
     ,        status='old',err=9)
      else
         write(cha2,'(i2)') IA
         open (NFIL,file='F_'//cha2//'.mat',form='formatted',
     ,        status='old',err=9)
      end if

c.............. read number of displacements as the 1st line

      call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,0,iErr)
      if(iErr.ne.0) go to 9
      if(index(Line,'# amplitudes').ne.0) then
         read(line(LinPos(3):),*,err=9,end=9) Ndispl
         write(*,*)'Number of amplitudes found = ',Ndispl
         write(24,*)'Number of amplitudes found = ',Ndispl
         if(Ndispl.ne.1 .and. Ndispl.ne.2 .and. Ndispl.ne.4) go to 9 
      else
         go to 9
      end if

c.............. read the file with ATOMIC forces; 
c               they will have to be symmetrised (in the next block)

 5    call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,0,iErr)
      if(iErr.ne.0) go to 9
      if(index(Line,'##').ne.0) go to 5
      if(index(Line,'#').ne.0) then
         if(index(line,'end').ne.0) go to 10
         read(line(LinPos(2):),*,err=9) iR,iD
         do i=LinPos(4),LinEnd(4)
            if(line(i:i).eq.'=') then
               ip=i ; go to 6
            end if
         end do
         go to 9
 6       read(line(ip+1:),*,err=9) ampl(iR,iD)
         if(iR.lt.1 .or. iR.gt.Ndim) go to 9
         if(iD.lt.1 .or. iD.gt.Ndispl) go to 9
         write(24,'(3(a,i3),a,f10.5)') '... irrep =',IA,
     ,    ', F-matrix for iR= (',iR,'), iD= ',iD, ' ampl= ',ampl(iR,iD)
         do iN=1,ITI
            call CutStr(Line,NumLin,LinPos,LinEnd,NFIL,0,iErr)
            if(iErr.ne.0 .or. NumLin.lt.3) go to 9
            read(Line(LinPos(NumLin-2):),*,err=9) (forces(iN,j),j=1,3)
c_________________ rework froces from a.u. to eV/A (only CP2K) _________
            if(Which_Code.eq.'QUICKS') then
               forces(iN,1:3)=forces(iN,1:3)*eVpA
            end if
c_______________________________________________________________________
            write(24,'(a,i3,a,3(e12.6,x))') 
     &      'at = ',iN, ' force f = ',(forces(iN,j),j=1,3)
         end do
         all(iR,iD)=.true.

c................. get the force acting on the iR-th generalised 
c                  coordinate (row index is 1), displacement iD
c  gen_force(iR1,iR,iD) - generalised force on the generalised coordinate iR1
c                         due to excitation of the generalised coordinate iR 
c                         because of the displacement ampl(iR,iD)
c
         nat=0 ; iR1=0 
         do is=1,Nsp
            do n=1,NspN(is)/MG_luc
               nat=nat+1
               j=Prim_Ext_Cell(nat)
               do i=1,3
                  iR1=iR1+1
                  gen_force(iR,iR1,iD) = fctr*forces(j,i)
               end do
            end do
         end do
         write(24,'(a,6(e12.6,x))')
     &        'gen. forces = ',(gen_force(iR,iR1,iD),iR1=1,Ndim)
      end if
      go to 5
 10   close (NFIL)
      return

c............. if error

 9    close (NFIL)
      write(*,*)'FATAL error while reading F-file for irrep = ',IA
      Err=.true.
      end
