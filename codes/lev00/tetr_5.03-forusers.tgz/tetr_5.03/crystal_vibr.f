      subroutine crystal_vibr(Which_Code,kpoint,nkp)
c....................................................................
c         It does vibrations of supercells using an Abelian group of 
c  internal translations.
c (1) a supercell is obtained from the given primitive cell; the 3x3
c     extention matrix is obtained together with reciprocal lattice 
c     vectors for both systems ("small" and "large")
c (2) the group of internal translations is obtained, including:
c     (i) internal translations
c     (ii) k-points in the BZ of the "small" (primitive) system that
c          correspond to the Gamma point in the reduced BZ of the 
c          "large" (supercell) system
c     (iii) all irreducible representations for this group; 
c (3) all atoms are broken down into orbits
c (5) masses of atoms for every species (a.e.m.) are taken from default
c (6) the matrix of masses is calculated and written into a file 
c (7) the group-theoretical analysis is performed for every irrep
c (8) then it is possible either to construct geometries that correspond 
c     to activated mode one by one, or, preferably, all in one go using
c     option Au (automatic).
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      include 'systema.inc'      
      dimension x1(3),iFix(N0RB),x2(3),x(3)
      character cha2*2,Yes_xyz*4
      character Which_Code*6,cha1,cha17*17,numb(12)*2,Line*200
      character cha(3)*2
      integer IRA_left(N0IR)
      integer LinEnd(100),LinPos(100)
      double precision kpoint(Nkpoint,3),C_cond(3,N0LT,6)
      double precision ampl(2)
      logical Yes_masses,Add_Hs,Yes_Fixed,Yes_irrep_info,active
      logical Yes_ampl,Show_fixed,Err,Yes_extention
      common /buffer0/ A0(3,3),TI0(3,N0LT),B0(3,3),ITI0,
     ,     NspN0(N0KD),Nsp0,Species0(N0KD),relax_flag0(3,N0LT)
      character Species0*2,relax_flag0
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,relax_flag1
      logical Genrt1
      data Add_Hs/.false./,Yes_xyz/'Xmol'/
      data numb/' 1',' 2',' 3',' 4',' 5',' 6',' 7',' 8',' 9',
     &                                           '10','11','12'/
      data ampl/0.01,0.015/,Show_fixed/.false./,Ndispl/2/,ampl1/0.05/

c
c........... keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c
c..................................................................
c..................... Main menu starts here ......................
c..................................................................
c
      Yes_masses=.true.
      do is=1,Nsp
         if(AtMass(is).lt.tiny_equiv) Yes_masses=.false.
      end do
      Yes_irrep_info=.false. ; active=.false. ; Yes_ampl=.false.
      Yes_extention=.false. ; Yes_Fixed=.false.
      do i=1,3
         do j=1,3
            AI(i,j)=AJ(i,j)
            IJ(i,j)=0.0
         end do
         IJ(i,i)=1
      end do
      N_Cond=0

 21   write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,'(10x,2a/)')
     &     '<<SUPERCELL>> ----- CURRENT lattice vectors: ----' 
      write(*,'(a,10x,a,10x,a,10x,a)')
     &     ' #                SUPERCELL                        '//
     &     'PRIMITIVE CELL             EXTENTION'
      write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') 
     &'(1) ',(AJ(1,i),i=1,3),' | ',(AI(1,i),i=1,3),' | ',(IJ(1,i),i=1,3)
      write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') 
     &'(2) ',(AJ(2,i),i=1,3),' | ',(AI(2,i),i=1,3),' | ',(IJ(2,i),i=1,3)
      write(*,'(a,3(f10.5,x),a,3(f10.5,x),a,3(i3,x))') 
     &'(3) ',(AJ(3,i),i=1,3),' | ',(AI(3,i),i=1,3),' | ',(IJ(3,i),i=1,3)

      write(*,'(a)')
      write(*,*)'========= CHOOSE an OPTION:'
      write(*,'(a)')

      if(.not.Yes_masses) write(*,'(a)')
     &      ' Am. Specify atomic masses for every species <- undefined'

      if(.not.Yes_extention) then
         write(*,'(a)')
     &     ' Su. General "breeding": construct a supercell <= undefined'
      else
         write(*,'(a)')
     &      ' Su. General "breeding": construct a supercell <= Done!'
      end if

      if(Yes_extention) then
         if(Yes_Fixed) then
            write(*,'(a)') ' Fx. Some orbits are fixed.'
         else
            write(*,'(a)') ' Fx. Specify which orbits to fix'
         end if

         if(Yes_Fixed) then
            ifx=0
            do io=1,NORB
               if(Fix(io)) then
                  ifx=ifx+1 ; iFix(ifx)=io
               end if
            end do
            write(cha2,'(i2)') ifx
            write(*,'(5x,a,'//cha2//'(i3,x))') 
     &           'Fixed orbits:',(iFix(j),j=1,ifx)
         end if
      end if

      if(Yes_masses .and. Yes_extention) then
         if(Yes_irrep_info) then
            write(*,'(a)')
     &       ' Ir. Collect info about symmetry adapted vectors <- Done'
         else
            write(*,'(a)')
     &   ' Ir. Collect info about symmetry adapted vectors <- undefined'
         end if
      end if
   
c_____ actions with the active irrep

      if(Yes_irrep_info) then
         write(*,'(a)')
     &'------ A c t i o n s  w i t h  A c t i v e  I r r e p ----------'
         do IA=1,NEPR
            if(IRA_left(IA).ne.0) then
               if(active .and. IA.eq.IA_active) then
                  cha17='  <=== now active'
               else
                  cha17='                 '
               end if
               if(IA.lt.10) then
                  write(cha1,'(i1)') IA
                  write(*,'(a,i1,a,i5,a)')' '//cha1//'. irrep ('//
     &              NAZVIR(IA)//') is ',NALFA(IA),
     &                 'D; # of vectors = ',IRA_left(IA),cha17
               else
                  write(cha2,'(i2)') IA
                  write(*,'(a,i1,a,i5,a)') cha2//'. irrep ('//
     &              NAZVIR(IA)//') is ',NALFA(IA),
     &              'D; # of vectors = ',IRA_left(IA),cha17
               end if
            end if
         end do
      end if
      
      if(active) then
         if(IRA_left(IA_active).eq.1) then
            iV1=1 ; iV2=1 ; Yes_ampl=.true.
            write(*,'(2(a,i3))')
     &      '     Pair of vectors to be activated: ',iV1,' and ',iV2
         else
            if(Yes_ampl) then
               write(*,'(2(a,i3))')
     &          ' Vn. Pair of vectors to be activated: ',iV1,' and ',iV2
            else
               write(*,'(2(a,i3))')
     &          ' Vn. Pair of vectors to be activated: <= undefined'
            end if
         end if
         write(*,'(a)')
     &        ' Go. Show symmetry adapted coordinates'
         write(*,'(a)')
     &        ' Sa. Show final symmetry adapted displacements'
         if(IA_active.lt.10) then
            write(cha1,'(i1)') IA_active
            write(*,'(a)') 
     &           ' Sw. Write final symmetry adapted '//
     &                     'displacements to W_'//cha1//'.mat'
            write(*,'(a)') ' Gw. Write G-matrix for eigenvalue'//
     &           ' problem to G_'//cha1//'.mat'
         else
            write(cha2,'(i2)') IA_active
            write(*,'(a)') 
     &           ' Sw. Write final symmetry adapted '//
     &                     'displacements to W_'//cha2//'.mat'
            write(*,'(a)') ' Gw. Write G-matrix for eigenvalue'//
     &           ' problem to G_'//cha2//'.mat'
         end if
         write(*,'(a)')
     &       ' Vs. Write <geom.xyz> geom file for each displacement'
      end if

c_____ automatic

      if(active) then
         write(*,'(a)')
     &'------------------- A u t o m a t i c   o p t i o n ------------'
         write(*,'(a)')
     &    ' Au. Generate: input_for.tetr + directories + scripts'
      else if(Yes_irrep_info) then
         write(*,'(a)')
     &'------------------- A u t o m a t i c   o p t i o n ------------'
         write(*,'(a)')
     &    ' Au. FULLY AUTOMATIC: input_for.tetr + directories + scripts'
      end if

c_____ show info

      write(*,'(a)')
     &'-------------- G e n e r a l  I n f o r m a t i o n ------------'
      if(Yes_extention) then
         write(*,'(a)')
     &     ' Co. Show general geometry information about orbits'
         write(*,'(a)')
     &        ' Or. Show detailed information about given orbit'
         write(*,'(a)')' Kp. Show all k-points'
         write(*,'(a)')' Sy. Show the symmetry group info'
      end if

c_____ show settings

      write(*,'(a)')
     &'---------------- G e n e r a l  S e t t i n g s ----------------'
      write(*,*)' UU. ******  RESTORE the original lattice ******'
      if(Yes_masses) then
         write(*,'(a)')
     &       ' Am. Atomic masses for every species:'
         write(*,'(5x,6(f10.5,x,3a,2x))') 
     &        (AtMass(is),'[',Species(is),']',is=1,Nsp)
      end if
c      write(*,'(a)')
c     &   ' XY. Format of <geom.xyz> file is for '//YES_xyz
      if(Ndispl.lt.4) then
         write(*,'(a,2(f10.5,x))')
     &        ' Da. Distortion amplitude: ',ampl(1)
      else
         write(*,'(a,2(f10.5,x))')
     &        ' Da. Distortion amplitude: ',ampl(1),ampl(2)
      end if
      write(*,'(a,i1)')
     &     ' Nd. Number of displacements (for [Au] only): ',Ndispl
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,'(a)')
     &        ' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,'(a)')
     &        ' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      if(Yes_Fixed) then
         if(.not.Show_fixed) then
            write(*,'(a)')' Sx. Show fixed atoms in tables: NO'
         else
            write(*,'(a)')' Sx. Show fixed atoms in tables: YES'
         end if
      end if
      if(active .and. Yes_ampl) write(*,'(a)')'  S. Save geometry file'
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)
      if(cha2.eq.'  ') go to 21

c[IA]..... first of all, check if active irrep is chosen; if it was,
c          then construct W_all,IRA

      IF(Yes_irrep_info) THEN

         read(cha2(l0:),'(i2)',err=27) n_IA

c__________________ deactivate the irrep if chosen 2nd time
         if(active.and.n_IA.eq.IA_active) then
            active=.false. ; go to 21
         end if

c___________________ activate the irrep if the 1st time
         do IA=1,NEPR
            if(n_IA.eq.IA) then
               if(IRA_left(IA).eq.0) then
                  write(*,*)'Error! Try again!'
                  go to 21
               end if
               IA_active=IA
               call do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
               if(IRA-N_Cond.ne.IRA_left(IA)) stop 'IRA error'
               active=.true. ; Yes_ampl=.false.
               go to 21
            end if
         end do

      END IF

c[Am]...... specify atomic masses

 27   IF(cha2(l0:).eq.'Am') THEN

         call choose_masses(Species,AtMass,Nsp,Yes_masses)

c______________ reset logical flags since masses changed
         active=.false. ; Yes_irrep_info=.false. ; Yes_ampl=.false.

c[Su]...... specify the supercell

      ELSE IF(cha2(l0:).eq.'Su') THEN

c___________ keep the existing geometry in /buffer/

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ specify extention matrix

 34      write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'   
 3       write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=3) (IJ(1,j),j=1,3)
 4       write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=4) (IJ(2,j),j=1,3)
 5       write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=5) (IJ(3,j),j=1,3)
         MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) -
     -        IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) +
     +        IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         write(*,*) 'cell ==> supercell extention = ',MG_luc
         if(abs(MG_luc).lt.tiny_equiv) then
            write(*,*) 'ERROR! Zero extention!' ; go to  34
         end if
         if(ITI*MG_luc.gt.N0LT) then
            write(*,*)
     &        'ERROR! The breeding box is too big, see tetr_param.inc'
            write(*,'(3(a,i5))') 
     &               'ITI= ',ITI, ' MG_luc= ',MG_luc, ' N0LT= ',N0LT
            go to 21
         end if
         ITI=ITI*MG_luc

c_________ build the supercell and keep the primitive cell in AI, BI
         AI=AJ ; BI=BJ
         do k=1,3
            AJ(1,k)=IJ(1,1)*AI(1,k)+IJ(1,2)*AI(2,k)+IJ(1,3)*AI(3,k)
            AJ(2,k)=IJ(2,1)*AI(1,k)+IJ(2,2)*AI(2,k)+IJ(2,3)*AI(3,k)
            AJ(3,k)=IJ(3,1)*AI(1,k)+IJ(3,2)*AI(2,k)+IJ(3,3)*AI(3,k)
         end do
         call INVER(AJ,BJ)

c____________ generate internal translations
         call LACE(MG_luc,iErr)
         if(iErr.eq.1) stop 'ERROR in LACE! STOP'

c____________ generate positions of all atoms in the supercell 
         j=0
         j1=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN(k)
               j1=j1+1
               do k1=1,MG_luc
                  j=j+1
                  TI(1:3,j)=TRAN(k1,1:3)+TI1(1:3,j1)
                  relax_flag(1:3,j)=relax_flag1(1:3,j1)
               end do
            end do
            NspN(k)=NspN(k)*MG_luc
         end do

c____________ construct the group of internal translations

         call get_group_of_transl(MG_luc,Err)
         if(Err) then
            call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,
     ,                                     Species,relax_flag)
            Yes_extention = .false.
         else
            Yes_extention = .true.
         end if

         Yes_irrep_info=.false.
         active=.false.
         Yes_Fixed=.false.
         do i=1,NORB
            Fix(i)=.false.
         end do

c[Fx]...... which orbits to fix

      ELSE IF(cha2(l0:).eq.'Fx' .and. Yes_extention) THEN

         j=0
         do i=1,NORB
            if(Fix(i)) j=j+1
         end do
 2       write(*,'(a)')
     &        'Specify a range of orbits to fix, nothing to disable:'
         write(*,'(a)')'use dash (without space) to indicate from/to'
         write(*,'(a)')'within the same list, e.g.: 1-5 9,7-8 15,25'
         read(*,'(a)') line
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 2
         if(NumLin.eq.0) then
            Yes_Fixed=.false.
            do i=1,NORB
               Fix(i)=.false.
            end do
            write(*,*)'WARNING! The Fixing of orbits is disabled!'
            go to 19
         else
            if((NORB-j).lt.2) then
               write(*,*)'WARNING! No orbits left to fix anymore!'
               go to 21
            end if
            Yes_Fixed=.true.
         end if
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.NORB) go to 2
            do j=i1,i2
               Fix(j)=.true.
            end do
         end do
         j=0
         do i=1,NORB
            if(Fix(i)) j=j+1
         end do
         if(j.gt.99) then
            write(*,*)'Too many fixed orbits! Redefine!'
            go to 2
         end if

c______________ reset logical flags
 19      active=.false.
         Yes_irrep_info=.false.
         Yes_ampl=.false.
         
c[Ir]...... collect info about symmetry-adapted vectors; constraints will also
c           be applied if set:
c           IRA_left(IA) - number of linearly independent symmetry-adapted
c                          coordinates left after getting rid of constrains
c                          (for irrep IA)

      ELSE IF(cha2(l0:).eq.'Ir'.and.Yes_masses.and.Yes_extention) THEN

         IR=0
         do IA=1,NEPR
            call do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
            IRA_left(IA) = IRA-N_cond
         end do
         Yes_irrep_info=.true.

c______________ write all the info for later use (eigenvalues)
         open(23,file='vibr_info.dat',form='formatted')
         write(23,'(2(i5,x),a8)') NEPR,Nsp,system
         write(23,'(a3,20(x,a3))') GroupN,(NAZVIR(IA),IA=1,NEPR)
         write(23,'(20(a2,x))')  (Species(is),is=1,Nsp)
         write(23,*) (IRA_left(IA),IA=1,NEPR)
         write(23,*) (NALFA(IA),IA=1,NEPR)
         write(23,*) NORB,MG,(KG(i),i=1,MG)
         write(23,*) (KAN(io),(R1(io,j),j=1,3),io=1,NORB)
         write(23,*) (ISORT1(io),io=1,NORB)
         write(23,*) ((orb_to_old(io,nat),nat=1,KAN(io)),io=1,NORB)
         write(23,'(20(l1,x))') (Fix(io),io=1,NORB),Yes_Fixed
         write(23,'(5(f10.5,x))') ((TRAN(N,j),j=1,3),N=1,MG)
         write(23,*) (ICMPL(IA),IA=1,NEPR)
c______________ extra bit just for this system
         write(23,*) AI,BI,AJ,BJ,IJ
         write(23,*) ITI,((TI(j,n),j=1,3),n=1,ITI)
         write(23,*) (NspN(i),i=1,Nsp)
         write(23,*) ((Vkp(k,j),j=1,3),k=1,MG)
         write(23,*) ((Vk_rep(IA,j),j=1,3),IA=1,NEPR)
         close (23)
         write(*,*)'WARNING: general info written to [vibr_info.dat]'

c[Go].... show symmetry adapted coordinates for each orbit
c         (prior to applying constraints)

      ELSE IF(cha2(l0:).eq.'Go' .and. active) THEN

 44      if(NORB.gt.1) then
            write(*,'(a,i3,a)')
     &         'Specify the orbit number between 1 and ',NORB,':'
            read(*,*,err=44) iOrb
            if(iOrb.lt.1 .or. iOrb.gt.NORB) go to 44
         else
            iOrb=1
         end if
         if(Fix(iOrb)) then
            write(*,*)'ERROR! This orbit is fixed! Choose another one!'
            go to 44
         end if
         x1(1:3)=R1(iOrb,1:3)
         IA=IA_active
         call VANJA(x1,1,iOrb,IA,NREP,BJ)
         if(NREP.gt.0) then 
            write(*,'(a,i2,a)')
     &           '*************** irrep = ',IA,' *****************'
            call show_W_matrix(iOrb,x1,IA,NREP)
         else
            write(*,'(2(a,i3))')
     &           'Orbit ',iOrb, 'does NOT contain Irrep = ',IA
         end if

c[Sa]...... show symmetry-adapted vectors for given irrep
c         (after applying constraints)

      ELSE IF(cha2(l0:).eq.'Sa' .and. active) THEN

         IA=IA_active
         call show_W_all_matrix(IA,IRA,Species,N_Cond,Show_fixed)
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sw]...... write symmetry-adapted vectors for given irrep
c         (after applying constraints)

      ELSE IF(cha2(l0:).eq.'Sw' .and. active) THEN

         IA=IA_active
         call write_W_all_matrix(IA,IRA,N_Cond)

c[Gw]...... write G-matrix for the eigenvalue problem (option V2
c           of the main menu)

      ELSE IF(cha2(l0:).eq.'Gw' .and. active) THEN

         IA=IA_active
         call write_G_matrix(IA,IRA,N_Cond,AtMass)

c[Vn]...... give pair of vectors

      ELSE IF(cha2(l0:).eq.'Vn' .and. active) THEN

         if(IRA_left(IA_active).gt.1) then
            IA=IA_active
 8          write(*,'(a,i3,a)')
     &           'Specify a pair of vectors from 1 to ',IRA-N_Cond, 
     &           ' to distort the system:'
            read(*,*,err=8) iV1,iV2
            if(iV1.lt.1 .or. iV1.gt.iV2 .or. iV2.gt.IRA-N_Cond) go to 8
            Yes_ampl=.true.
         end if

c[Vs]...... write xyz geom files for a displacement vector

      ELSE IF(cha2(l0:).eq.'Vs' .and. active) THEN

         if(IRA-N_Cond.gt.1) then
 7          write(*,'(a,i3)')
     &        'Specify a displacement vector between 1 and ',IRA-N_Cond
            read(*,*,err=7) iV
            if(iV.lt.1 .or. iV.gt.IRA-N_Cond) go to 7
         else
            iV=1
         end if
         open(37,file='geom.xyz',form='formatted')
         do iang=0,360,10
            amp=2*ampl1*sin(iang*pi/180.0)
            call distorted_xyz(IRA,N_Cond,iV,1,amp,Species,ITI,
     ,                                             37,YES_xyz,Add_Hs)
         end do
         close (37)

c[Au]...... an input file for tetr will be saved that can generate all geometries
c           of the active irrep automatically

      ELSE IF(cha2(l0:).eq.'Au' .and. Yes_irrep_info) THEN

         call automatic(iFix,N_Cond,Ndispl,Yes_Fixed,ifx,ampl,active,
     ,                   IRA_left,C_Cond,IA_active,system)
         write(*,'(9(/a))') 
     &  '.........................................................',
     &  '=================> Now, do the following: <==============',
     &  '     1. check script run_DFT_script and edit if necessary',
     &  '     2. run the script to calculate DFT forces'
         write(*,'(3(a/))') 
     &  '     3. run option V2 and/or V3 of tetr to '//
     &        'get eigenvectors/values'
         if(Which_Code.eq.'QUICKS') then
            write(*,'(6(/a))') 
     &  '     4. Include into FORCE_EVAL box the following lines:',
     &  '           &PRINT',
     &  '             &FORCES',
     &  '               NDIGITS 12',
     &  '             &END FORCES',
     &  '           &END PRINT'
         end if
         write(*,'(3(a/))') 
     &  '........................................................' ,
     &  'press ENTER when ready ...'
         read(*,*)

c[XY]...... ask the code for geom.xyz file 

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='Ymol'
c         end if

c[Hs]...... add Hydrogens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[Sx]...... if to show fixed atoms in tables

      ELSE IF(cha2(l0:).eq.'Sx' .and. Yes_Fixed) THEN

         if(Show_fixed) then
            Show_fixed=.false.
         else
            Show_fixed=.true.
         end if

c[Da]...... displacement amplitude

      ELSE IF(cha2(l0:).eq.'Da') THEN

 13      if(Ndispl.lt.3) then
            write(*,*)'Specify the amplitude of distortion (in A):'
            read(*,*,err=13) ampl(1)
         else
            write(*,*)'Specify 2 amplitudes of distortion (in A):'
            read(*,*,err=13) ampl(1),ampl(2)
         end if

c[Nd]...... displacements number: for [Au] option only

      ELSE IF(cha2(l0:).eq.'Nd') THEN

         if(Ndispl.eq.1) then
            Ndispl=2
         else  if(Ndispl.eq.2) then
            Ndispl=4
         else 
            Ndispl=1
         end if

c[Co]...... show information about orbits

      ELSE IF(cha2(l0:).eq.'Co' .and. Yes_extention) THEN
         
         write(*,'(a)')
     &    '-No--Species-Number-----1st atom coordinates-'//
     &        '-------Radius----Fix-|-------Old#-------->'
         do io=1,NORB
            is=ISORT1(io)
            rad=sqrt(R1(io,1)**2+R1(io,2)**2+R1(io,3)**2)
            if(Fix(io)) then
               cha1='Y'
            else
               cha1='N'
            end if
            write(*,'(2(i3,x),a2,i5,x,4(f10.5,x),2x,a,2x,a,48(i3,x))') 
     &        io,is,Species(is),KAN(io),(R1(io,j),j=1,3),rad,cha1,
     ,        '| ',(orb_to_old(io,nat),nat=1,KAN(io))
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Or].... show the orbit's local group

      ELSE IF(cha2(l0:).eq.'Or' .and. Yes_extention) THEN

 33      if(NORB.gt.1) then
            write(*,'(a,i3,a)')
     &        'Specify the orbit number between 1 and ',NORB,':'
            read(*,*,err=33) iOrb
            if(iOrb.lt.1 .or. iOrb.gt.NORB) go to 33
         else
            iOrb=1
         end if
         if(Fix(iOrb)) then
            write(*,*)'ERROR! This orbit is fixed! Choose another one!'
            go to 33
         end if
         x1(1:3)=R1(iOrb,1:3)
         call orbita(x1,BJ)
         write(*,'(2a)') 'Atomic species:  ',Species(ISORT1(iOrb))
         write(*,'(a,f10.5,a)')
     &        'Atomic mass:     ',AtMass(ISORT1(iOrb)),' a.u.m.'
         write(*,'(a,i4)')'Number of atoms: ',KAN(iOrb)
         if(Fix(iOrb)) then
            write(*,'(a)')'Is orbit fixed:  YES'
         else
            write(*,'(a)')'Is orbit fixed:   NO'
         end if
         write(*,'(a,20(a4,x))')
     &        'The local group: ',(NAZ(KG(KH(i))),i=1,MGN)
         write(*,'(/a)')
     &     'Old#-Atom#--Generator-----------Atom position----------'
         do i=1,KAN(iOrb)
            k=KG(KJ(i))
            x2(1)=C(1,1,k)*x1(1)+C(1,2,k)*x1(2)+C(1,3,k)*x1(3)+TRAN(i,1)
            x2(2)=C(2,1,k)*x1(1)+C(2,2,k)*x1(2)+C(2,3,k)*x1(3)+TRAN(i,2)
            x2(3)=C(3,1,k)*x1(1)+C(3,2,k)*x1(2)+C(3,3,k)*x1(3)+TRAN(i,3)
            iold=orb_to_old(iOrb,i)
            write(*,'(i3,3x,i3,5x,a4,5x,3(x,f10.5))') 
     &                      iold,i,NAZ(KG(KJ(i))),(x2(j),j=1,3)
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Kp].... show the symmetry and check the condition for the k-points
c         (ok-check)

      ELSE IF(cha2(l0:).eq.'Kp' .and. Yes_extention) THEN

         write(*,'(a/)')
     &        '... k-points of the original BZ for this extention ...'
         write(*,'(a)') ' # type|      in Cartesian (no 2*pi)     '//
     &     '  | ok-check  |           in fractional ',
     &     '------------------------------------------------------'//
     &     '-------------------------------------'
         do k=1,MG
            do j=1,3
               s=Vkp(k,1)*AJ(j,1)+Vkp(k,2)*AJ(j,2)+Vkp(k,3)*AJ(j,3)
               cs=cos(2*pi*s)
               sn=sin(2*pi*s)
               if(abs(cs-1.0).lt.tiny_equiv .and. 
     &                                  abs(sn).lt.tiny_equiv) then
                  cha(j)='ok'
               else
                  cha(j)='no'
               end if
            end do
            x(1)=AI(1,1)*Vkp(k,1)+AI(1,2)*Vkp(k,2)+AI(1,3)*Vkp(k,3)
            x(2)=AI(2,1)*Vkp(k,1)+AI(2,2)*Vkp(k,2)+AI(2,3)*Vkp(k,3)
            x(3)=AI(3,1)*Vkp(k,1)+AI(3,2)*Vkp(k,2)+AI(3,3)*Vkp(k,3)
            
            write(*,'(i3,x,i2,a,3(f10.5,x),a,3(a,x),a,3(x,f10.5))') 
     &        k,kCmpl(k),' | ',(Vkp(k,j),j=1,3),' | ',cha,' | ',x
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy' .and. Yes_extention) THEN

         write(*,'(a)')'..... group information .....'
         write(*,'(a)')'irrep dim MRR         k-vector (fractional)' 
         write(*,'(a)')'---------------------------------------------' 
         do IA=1,NEPR
            x(1)=AI(1,1)*Vk_rep(IA,1)+AI(1,2)*Vk_rep(IA,2)+
     +                 AI(1,3)*Vk_rep(IA,3)
            x(2)=AI(2,1)*Vk_rep(IA,1)+AI(2,2)*Vk_rep(IA,2)+
     +                 AI(2,3)*Vk_rep(IA,3)
            x(3)=AI(3,1)*Vk_rep(IA,1)+AI(3,2)*Vk_rep(IA,2)+
     +                 AI(3,3)*Vk_rep(IA,3)
            write(*,'(i3,2(3x,i1),3(x,f10.5))') 
     &           IA,NALFA(IA),ICMPL(IA),(x(j),j=1,3)
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S' .and. active .and. Yes_ampl) THEN

         call get_new_TI(N_Cond,iV1,iV2,ampl(1),TI,ITI)
         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.true.)

c[UU].... restore the original lattice

      ELSE IF(cha2(l0:).eq.'UU') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         Yes_extention = .false.
         Yes_irrep_info=.false.
         active=.false.
         Yes_Fixed=.false.
         do i=1,NORB
            Fix(i)=.false.
         end do

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

      subroutine get_group_of_transl(MG_luc,Err)
c...................................................................
c (1) obtain the supercell symmetry including irreps info
c (2) split the supercell into orbits
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'systema.inc'
      logical Err

      MG=MG_luc
c________ get the k-points of the original BZ of the "small" (primitive)
c         system (unit cell) that transform into the Gamma point of the
c         reduced BZ corresponding to the "large" (extended) supercell

      call build_k_points(MG,Err)
      if(Err) return
      Nvkp=MG
c
c_________ construction of the LUC group of internal translations

      call LUC_group(Err)
      if(Err) return
c
c......... break down system into orbits:
c            R1(i,xyz) - 1st atom of orbit i
c            NORB       - number of orbits
c
      call irina(TI,Nsp,NspN,BJ,Err)
      if(Err) return
c
      return
      end

      subroutine build_k_points(MG,Err)
c...................................................................
c get the k-points of the original BZ of the "small" (primitive)
c system (unit cell) that transform into the Gamma point of the
c reduced BZ corresponding to the "large" (extended) supercell
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension x(3)
      logical Err,first
      Err=.false.
      
c............... generate all MG_luc k-points (without 2*pi). After each vector
c                K we attempt to test vector -K as well so that they would go 
c                in the right order
      nop=0
      N=-1
30    N=N+1
      now=0
      do N3=-N,N
         do  N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
c
c____________ over the reciprocal lattice
               x(1) = N1*BJ(1,1) + N2*BJ(2,1) + N3*BJ(3,1)
               x(2) = N1*BJ(1,2) + N2*BJ(2,2) + N3*BJ(3,2)
               x(3) = N1*BJ(1,3) + N2*BJ(2,3) + N3*BJ(3,3)
               first=.true.

c____________ check if this is already there
 50            if(nop.ge.1) then
                  call ask(x,AI,Vkp,Nkpoint,nop,IASK)
                  if(IASK.eq.1) then
                     if(.not.first) 
     &                        write(*,*)'... vector -K was not accepted'
                     go to 250
                  end if
               end if
               nop=nop+1 ; now=now+1
               if(nop.gt.Nkpoint) then
                  write(*,*)
     &              'ERROR! No of k-points > Nkpoint in tetr_param.inc'
                  Err=.false. ; return
               end if

c_____________ reduce to the [-0.5,+0.5] interval in fractional coordinates
c              wrt to the original BZ (primitive cell)
               call reducn1(x,BI,AI)

c_____________ save
               Vkp(nop,1:3)=x(1:3) ; kCmpl(nop)=0
               if(.not.first) then
                  kCmpl(nop-1)=1 ; kCmpl(nop)=-1
               end if
               write(*,'(a,i3,a,3(x,f10.5),a)')
     &                         '... found ',nop,' vector: [ ',x,' ]'

c_____________ attempting to add -K vector as well
               if(.not.first) go to 250
               x=-x ; first=.false. ; go to 50

 250        end do
         end do
      end do
      if(now.gt.0) go to 30
      if(nop.ne.MG) then
         write(*,*)'PROBLEM in build_k_points: nop=',nop,' =/= MG = ',MG
         Err=.true.
      end if
      end

      subroutine LUC_group(Err)
c.....................................................................
c constructs irreps of the LUC group from Vkp's (k-points)
c Method without inversion:
c   (a) k-points that do not have -k counterparts, form real irreps
c       (since K and -K are related by a "large" reciprocal 
c       translation), i.e. characters are real (ICMPL=0)
c   (b) if K and -K points are not equivalent, their characters are
c       complex conjugate of each other and are complex; in this case 
c       both are joined into one 2D reducible rep (MRR) (ICMPL=1)
c.....................................................................
c    IA - counts irreps
c    K2 - counts 2D irreps (MRR's)
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      logical Err
      character cha3*3,cha1,cha2*2
      Err=.false.

      if(MG.gt.MG0) then
         write(*,'(a,i5,a)')'ERROR! No of translations > ',MG0,
     &        ' in sym_par.inc' 
         Err=.true. ; return
      end if

c.............. construct all k-points [keep only K, discard of their -K
c               counterparts (if any)]
      k=0 ; IA=0 ; K2=0
 10   k=k+1
      IA=IA+1
      if(IA.gt.N0IR) then
         write(*,'(a,i5,a)')'ERROR! No of irreps > ',N0IR,
     &        ' in sym_par.inc' 
         Err=.true. ; return
      end if

      Vk_rep(IA,1:3)=Vkp(k,1:3)

c_________ irrep name
      if(IA.lt.10) then
         write(cha1,'(i1)') IA ; NAZVIR(IA)=' '//cha1//' ' 
      else if(IA.lt.100) then
         write(cha2,'(i2)') IA ; NAZVIR(IA)=' '//cha2
      else if(IA.lt.1000) then
         write(cha3,'(i3)') IA ; NAZVIR(IA)=cha3
      else 
         write(*,*)'WARNING: irrep No > 999 - irrep name will be cut!'
         write(cha3,'(i3)') IA ; NAZVIR(IA)=cha3
      end if

c......... construct 1D or 2D irreps depending on whether there exist both
c          vectors K and -K (kCmpl(k) should tell this)

      if(kCmpl(k).eq.0) then

c_____________ 1D
         ICMPL(IA)=0 ; NALFA(IA)=1
         do N=1,MG
            s=TRAN(N,1)*Vk_rep(IA,1)+TRAN(N,2)*Vk_rep(IA,2)+
     +           TRAN(N,3)*Vk_rep(IA,3)
            cs=cos(2*pi*s)
            XX(IA,N)=cs
         end do

      else 

c_____________ 2D
         ICMPL(IA)=1 ; NALFA(IA)=2 ; K2=K2+1
         if(K2.gt.N0IR2) then
            write(*,'(a,i5,a)')'ERROR! No of 2D irreps > ',N0IR2,
     &        ' in sym_par.inc' 
            Err=.true. ; return
         end if
         do N=1,MG
            s=TRAN(N,1)*Vk_rep(IA,1)+TRAN(N,2)*Vk_rep(IA,2)+
     +           TRAN(N,3)*Vk_rep(IA,3)
            cs=cos(2*pi*s) ; sn=sin(2*pi*s)
            XX(IA,N)=2*cs
            D2ALFA(1,1,N,K2)= cs ; D2ALFA(1,2,N,K2)= sn
            D2ALFA(2,1,N,K2)=-sn ; D2ALFA(2,2,N,K2)= cs
         end do
         k=k+1
      end if
      if(k.lt.MG) go to 10
      NEPR=IA

c........... set rotations to none: will change later if inversion be included

      do i=1,MG
         KG(i)=1
      end do
         
c........... printing

      GroupN='INT'
      write(*,'(a)')'..... group information .....'
      write(*,'(a)')'irrep dim MRR       k-vector (without 2*pi)' 
      do IA=1,NEPR
         write(*,'(i3,2(3x,i1),3(x,f10.5))') 
     &                   IA,NALFA(IA),ICMPL(IA),(Vk_rep(IA,j),j=1,3)
      end do
      end



