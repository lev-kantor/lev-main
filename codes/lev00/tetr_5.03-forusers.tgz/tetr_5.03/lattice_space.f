      subroutine lattice_space(Generated,nkp,kpoint,Which_Code)
c........................................................................
c     This code builds the primitive cell from the space group symbol
c............
c AJ(vector,component) - basic direct translations of the primitive cell
c TI(component,number) - all sublattices in the primitive cell
c ITI - total number of the sublattices (atoms in the unit cell)
c........................................................................
c  It also asks for (at least partially as the symmetry is also used):
c     Nsp - number of species in the system
c     NspN(i) - number of atoms of the given species, i (=1,..,Nsp)
c........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'whereis.inc'
      include 'symgenv.inc'
      include 'working.inc'
c
      common /buffer0/ A0(3,3),TI0(3,N0LT),B0(3,3),ITI0,
     ,     NspN0(N0KD),Nsp0,Species0(N0KD),relax_flag0(3,N0LT)
      character Species0*2,relax_flag0
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      common /buffer1/ AY(3,3),TI3(3,N0LT),BY(3,3),ITI3,
     ,     NspN3(N0KD),Nsp3,Species3(N0KD),relax_flag3(3,N0LT)
      character Species1*2,relax_flag1,spec*2,cc*100
      character Species3*2,relax_flag3,cha4*4,ch4*4,hh4*4
      character Which_Format*6,Which_Code*6,seed1*40,lists*100
c
      character answer,cha2*2,YES_xyz*4,angstr*12,Line*200
      dimension R(3),R2(3),Rnew(3,48),x(3),TI2(3,N0LT)
      dimension cntp(3),v(3)
      dimension C_rot(3,3),AC(3,3)
      double precision kpoint(Nkpoint,3),dir(3)
      integer LinPos(100),LinEnd(100),iSort(N0LT),iorbit(N0LT)
      logical ask_equiv,exist,Err,Genrt1
      logical Basic_Primitive,Add_Hs,Generated
      logical listat(N0LT),tmp(N0LT),long,TagYES,listt(N0LT)
c
      logical cartesian,back
      character Space_Groups(247)*6,line1(48,3)*10,typ
      logical Yes_SpaceGr,ThreeD,Group_3D,Conv_Cell
      integer ll1(48,3,2),list(MG0),list_rot(Mg0),local(MG0),ijk(3)
c
      data angstr/'<Frac_conv> '/,YES_xyz/'Xmol'/
      data M11/0/,N11/0/,M22/0/,N22/0/,M33/0/,N33/0/,Add_Hs/.false./
      data ijk/2,3,1/

c............ read all space groups symbols for the menu

      write(*,*) tetr_dir(tetr_l0:)//'/group.list.intern'
      open(13,file=tetr_dir(tetr_l0:)//'/group.list.intern',
     ,                         form='formatted',status='old',err=1)

c_______________ all 3D (#1 - #230) and 2D (#231 - #247) groups
      do i=1,247
         call CutStr(Line,NumLin,LinPos,LinEnd,13,0,iErr)
         if(iErr.eq.1) go to 1
         iLi=LinEnd(1)-LinPos(1)+1
         if(iLi.eq.1) then
            Space_Groups(i)=Line(LinPos(1):LinEnd(1))//'     '
         else if(iLi.eq.2) then
            Space_Groups(i)=Line(LinPos(1):LinEnd(1))//'    '
         else if(iLi.eq.3) then
            Space_Groups(i)=Line(LinPos(1):LinEnd(1))//'   '
         else if(iLi.eq.4) then
            Space_Groups(i)=Line(LinPos(1):LinEnd(1))//'  '
         else if(iLi.eq.5) then
            Space_Groups(i)=Line(LinPos(1):LinEnd(1))//' '
         else if(iLi.eq.6) then
            Space_Groups(i)=Line(LinPos(1):LinEnd(1))
         else
            go to 1
         end if
      end do
      close (13)
      go to 10
 1    write(*,*)'ERROR reading space symbol from <group.list.intern>'
      write(*,*)'Exiting this option ...'
      return
c
c........... keep the current geometry (if exists) as default in /buffer0/

 10   if(ITI.ne.0) then
         exist=.true.
         call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         write(*,*)'WARNING: existing setting may be lost!'
      else
         exist=.false.
      end if

   
c========================================================================
c===================== MENU starts here =================================
c========================================================================
 11   Yes_SpaceGr=.false. ; Basic_Primitive=.false. ; Conv_Cell=.false.
      ITI=0 ; Nsp=0
      do k=1,N0KD
         NspN(k)=0
      end do
      ThreeD=.true. ; cartesian=.false. ; primitive=.false. 
      Group_3D=.true. ; Generated=.false. ; long=.true.
c
c___________ initialise tags
      tagYES=.false. 
      do i=1,N0LT
         listat(i)=.false.
      end do

c________________ initialise /buffer/ with zero ITI,Nsp and NspN
      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)

c________________ main menu starts here

 21   write(*,*)
      write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'

      write(*,*)
      write(*,*)'========= CHOOSE AN OPTION:'
      write(*,*)
      if(Nsp.gt.0) then
         write(*,'(5x,a,i5)')'Current number of atoms in the cell: ',ITI
         write(*,'(5x,a,i5)')'Current number of species:           ',Nsp
         write(*,'(10x,10(2a,i3,a))') 
     &                        (Species(i),'[',NspN(i),'] ',i=1,Nsp)
      end if

      if(Yes_SpaceGr) then
         write(*,*)' Sp. Space group has been selected as ', SpaceSmb
         write(*,*)'     Space group system  : ',System1
         write(*,*)'     Bravais lattice type: ',Type
         if(Basic_Primitive) then
            write(*,*) ' Lt. Basic translations of the PRIMITIVE CELL:'
            write(*,'(8x,a,5x,3(f10.5,x))') 'vec 1 => ',(AJ(1,i),i=1,3)
            write(*,'(8x,a,5x,3(f10.5,x))') 'vec 2 => ',(AJ(2,i),i=1,3)
            write(*,'(8x,a,5x,3(f10.5,x))') 'vec 3 => ',(AJ(3,i),i=1,3)
         else
            write(*,*) 
     &        ' Lt. Basic translations of the CELL <===== undefined'
         end if
      else
         write(*,*)' Sp. Select the space group from the list'
      end if
      
      if(Conv_Cell) then
         write(*,*)' Su. Change matrix for the conventional cell'
         if(Basic_Primitive) then
            do k=1,3
               AC(1,k)=IJ(1,1)*AJ(1,k)+IJ(1,2)*AJ(2,k)+IJ(1,3)*AJ(3,k)
               AC(2,k)=IJ(2,1)*AJ(1,k)+IJ(2,2)*AJ(2,k)+IJ(2,3)*AJ(3,k)
               AC(3,k)=IJ(3,1)*AJ(1,k)+IJ(3,2)*AJ(2,k)+IJ(3,3)*AJ(3,k)
            end do
            write(*,*)
     &           '     Current translations of the CONVENTIONAL CELL:'
            write(*,'(8x,a,5x,3(f10.5,x))') 'vec 1 => ',(AC(1,i),i=1,3)
            write(*,'(8x,a,5x,3(f10.5,x))') 'vec 2 => ',(AC(2,i),i=1,3)
            write(*,'(8x,a,5x,3(f10.5,x))') 'vec 3 => ',(AC(3,i),i=1,3)
         end if
      else
         write(*,*)
     &' Su. Choose "bredding" matrix -> CONVENTIONAL CELL <== undefined'
      end if   

      write(*,*)' At. Manually add an atom to the cell'
      write(*,*)' Ad. Add atoms from another file'

      if(Basic_Primitive .and. Nsp.gt.0) then
         if(Generated) then
            write(*,*) 
     &             ' Gn. Generate the PRIMITIVE CELL:  <===== Done!'
         else
            write(*,*) ' Gn. Generate the PRIMITIVE CELL'
         end if
      end if

c___________ operations with multiple lists
      write(*,*)
     & '--------- operations with multiple lists of atoms ------------'
      if(tagYES .and. Nsp.ne.0) then
         write(*,*)
     &    '  T. Untag atoms (multiple lists): currently ON'
         if(long) then
            write(*,*)'     >> Current set of tagged atoms: '
     &           //lists(1:length)
         else
            write(*,*)'     >> Current set of tagged atoms:'
     &           //lists(1:length)//' ...'
         end if
         write(*,*)' Rm. Remove tagged atoms with their stars'
         write(*,*)' Rn. Rename tagged atoms: change species'
         if(Basic_Primitive) then
            write(*,*)
     &           ' Mv. Move tagged atoms to another general position'
            write(*,*)' Rt. Rotate tagged atoms about an axis'
         end if
      else if(Nsp.ne.0) then
         length=0
         write(*,*)
     &        '  T. Tag atoms (specify multiple lists): currently OFF'
      end if

c_____ show settings

      write(*,*)
     &'---------- v i s u a l i a s i o n   s e t t i n g s ---------'

       if(Basic_primitive) then
         write(*,'(8x,a)') 
     &     '>>>>> Current setting for the breeding box: <<<<<'
         write(*,'(13x,a,3(i2,a,i2,a))') '[',M11,'...',N11,'] x [', M22,
     &                           '...',N22,'] x [', M33,'...',N33,']'
         L_ext1=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)
         write(*,'(8x,2(a,i3))')
     &     '>>>>> extension = ',L_ext1,', # of atoms= ',ITI*L_ext1
         write(*,*)
     &        ' Bb. Set the size of the breeding box for visualisation'
         write(*,*) 
     &        ' B0. Nullify the breeding box (make the UNIT extension)'
      else
         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
      end if 
c      if(YES_xyz.ne.'None') then
c         write(*,*)
c     &  ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
c      else
c         write(*,*)
c     &        ' XY. Do NOT produce <geom.xyz> file after every change'
c      end if
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      if(Nsp.ne.0 .and. YES_xyz.ne.'None') write(*,*)
     &  '  W. Write <geom.xyz> file for preview using current breeding'

      write(*,*)
     &'-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,*)' UU. ******  Start AGAIN from scratch ******'
      write(*,*)'  U. ********** UNDO the last step *************'
      if(Generated) 
     &     write(*,*)' U1. Keep only the 1st atoms from each star'
c___________ set YES_xyz to the visualisation code: 
c            make geom.xyz file automatically after every change

      if(Group_3D) then
         write(*,*) ' Dm. 3D space groups (for bulk)'
      else
         write(*,*) ' Dm. Planar (2D) space groups (for surfaces)'
      end if
      if(angstr.ne.'<Frac_conv> ') then
         write(*,*)
     &        ' An. [For input] Coordinates are specified in: '//angstr
      else
         write(*,*)' An. [For input] Coordinates are in '//
     &        'Fractional wrt CONVENTIONAL cell'        
      end if

      if(Basic_Primitive) then
         write(*,*)' Sy. Show the symmetry'
         if(cartesian) then
            write(*,*)
     &           ' Ca. Fractional translations in Sy are in Cartesian'
         else
            write(*,*)
     &      ' Ca. Fractional translations in Sy wrt conventional cell'
         end if
         if(primitive) then
            write(*,*)
     &  ' Re. Fractional translations in Sy reduced wrt primitive cell'
         else
            write(*,*)
     &' Re. Fractional translations in Sy reduced wrt conventional cell'
         end if
      end if

      if(Nsp.ne.0) then
         write(*,*)
     &     ' Co. Show current atomic positions in fractional/Cartesian'
         write(*,*)'  P. Proceed: keep the curent setting'
      end if

      if(Generated) then
         write(*,*)'  S. Save.'
         write(*,*)
     & ' Sf. Save the SIESTA code to symmetrise forces & stress tensor'
      end if
      write(*,*)'  Q. Quit: return to the previous setting (if exists)'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[Sp]...... choose the space group

      IF(cha2(l0:).eq.'Sp') THEN

c___________ keep the old geometry (if exists) for undo
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,
     ,        Species,relax_flag,Genrt)

c___________ choose the group
         if(Group_3D) then
            i2=230
         else
            i2=17
         end if
         do i=1,i2,8
            jj=7
            if(i+7.gt.i2) jj=i2-i
            i1=i
            if(.not.Group_3D) i1=i+230
            write(*,'(8(a,i3,2a,2x))') 
     &                          ('[',i+j,'] ',Space_Groups(i1+j),j=0,jj)
         end do

 71      write(*,*)'Choose the space group number from the Tables:'
         read(*,*,err=71) ii
         if(ii.lt.1.or.ii.gt.i2) go to 71
         if(.not.Group_3D) ii=ii+230
         SpaceSmb=Space_Groups(ii)
         open(13,file=tetr_dir(tetr_l0:)//'/group.list.intern',
     ,                                            form='formatted')
         if(ii.gt.1) then
            do i=1,ii-1
               read(13,*) 
            end do
         end if
         call CutStr(Line,NumLin,LinPos,LinEnd,13,0,iErr)
         Type=Line(LinPos(3):LinEnd(3))
         System1=Line(LinPos(2):LinEnd(2))
         close (13)
         Yes_SpaceGr=.true.
         Generated=.false.
         Basic_Primitive=.false.

c_____________ keep only the 1st atoms of all stars
         call keep_1st_from_stars(iSort,listat,tagYES)

c[Lt]...... primitive basic translations + complete construction of the
c           space group

      ELSE IF(cha2(l0:).eq.'Lt' .and. Yes_SpaceGr) THEN

c___________ keep the old geometry (if exists) for undo
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,
     ,        Species,relax_flag,Genrt)

c___________ build the space group

         call build(AJ,BJ,iErr)
         if(iErr.eq.1) then
            write(*,*)'ERROR while building up the Space Group'
            write(*,*)'Hit ENTER when ready ...'
            read(*,*) ;             go to 21
         end if
         write(*,*)'GOOD! The space group was successfully generated!'
         Basic_Primitive=.true.
         Generated=.false.

c_____________ keep only the 1st atoms of all stars
         call keep_1st_from_stars(iSort,listat,tagYES)

c[Su].......breeding matrix [primitive -> conventional] cell

      ELSE IF(cha2(l0:).eq.'Su') THEN

c___________ specify extention matrix
 34      write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'   
 3       write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=3) (IJ(1,j),j=1,3)
 4       write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=4) (IJ(2,j),j=1,3)
 5       write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=5) (IJ(3,j),j=1,3)
         MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) -
     -        IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) +
     +        IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         write(*,*) 'cell ==> conventional cell extention = ',MG_luc
         if(abs(MG_luc).lt.tiny_equiv) then
            write(*,*) 'ERROR! Zero extention!' ; go to  34
         end if
         if(MG_luc.gt.N0LT) then
            write(*,*)
     &        'WARNING! The breeding box is too big, see tetr_param.inc'
            go to 21
         end if
         Conv_Cell=.true.

c[T].... tag atoms using a multiple lists method

      ELSE IF(cha2(l0:).eq.'T' .and. Nsp.ne.0) THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         if(tagYES) then
            tagYES=.false.
            write(*,*)'WARNING! The tagging is disabled!'
            go to 21
         end if

c__________ specify wanted atoms
 44      write(*,*)
     &        '===================================================='
         write(*,*)'Tag atoms using space and/or comma to separate '
         write(*,*)
     &        'lists and a dash (without space) to indicate from/to'
         write(*,*)'within the same list, for example: 1-5 9,7-8 15,25'
         write(*,*)
     &        '===================================================='
         write(*,*)
     &        '==== IMPORTNAT: complete stars will be used! ======='
         write(*,*)
     &        '===================================================='
         read(*,'(a)') line
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 44
         if(NumLin.eq.0) then
            tagYES=.false.
            write(*,*)'WARNING! The tagging is disabled!'
            go to 21
         end if

         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 44
            do j=i1,i2
               listat(j)=.true.
            end do
         end do

c__________ add other atoms of complete stars 

         call subl_go(iSort,.false.)
         do k=1,ITI
            if(listat(k)) then
               call list_of_star(k,list,nlist,list_rot,.true.)
               do j=1,nlist
                  listat(list(j))=.true.
               end do
            end if
         end do

c__________ compose the list

         call list_dash(listat,ITI,tmp,lists,length,long)
         tagYES=.true.

c[Rm]...... remove tagged atoms together with their stars (if were created)

      ELSE IF(cha2(l0:).eq.'Rm' .and. tagYES .and. Nsp.ne.0) THEN

c___________ keep the old geometry in /buffer/
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ remove tagged atoms
         do i=ITI1,1,-1
            if(listat(i)) 
     &           call remove_atoms1(i,i,.true.,.true.,iSort,listat)
            listat(i)=.false.
         end do
         tagYES=.false.
         Generated=.false.

c___________ construct all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Rn]...... rename tagged atoms together with their stars (if were created):
c           change species

      ELSE IF(cha2(l0:).eq.'Rn' .and. tagYES .and. Nsp.ne.0) THEN

c___________ keep the old geometry in /buffer/
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ (a) remove tagged atoms
c            (b) initialise listt to listat to keep the old list of tagged atoms

         do i=ITI1,1,-1
            listt(i)=listat(i)
            if(listat(i)) 
     &           call remove_atoms1(i,i,.true.,.true.,iSort,listat)
         end do

c__________ ask the target species number
 42      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if
c___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!'
            go to 42
         end if
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii
               go to 43
            end if
         end do
         jsp=Nsp+1
         NspN(jsp)=0
         Species(jsp)=spec

c__________ and add removed atoms as species jsp
 43      do k=1,ITI1
            if(listt(k)) then
               x(1)=TI1(1,k)
               x(2)=TI1(2,k)
               x(3)=TI1(3,k)
               if(Genrt1(k)) then
                  nst=1
               else
                  nst=2
               end if
               call add_atom1(x,jsp,.true.,ion,iSort,nst,listat)
            end if
            listat(k)=.false.
         end do
         tagYES=.false.

c___________ shift NspN/Nsp list if some species are empty
         i=Nsp
 82      if(NspN(i).eq.0) then
            write(*,*)'WARNING! Species ',i,' has gone!'
            if(i.lt.Nsp) then
               do l=i+1,Nsp
                  NspN(l-1)=NspN(l)
                  Species(l-1)=Species(l)
               end do
            end if
            Nsp=Nsp-1
         end if
         i=i-1
         if(i.gt.0) go to 82
         if(Nsp.ne.Nsp1) then
            write(*,*)'WARNING! Number of species changed!'
            write(*,*)'         New number of species = ',Nsp
         end if

         Generated=.false.

c___________ construct all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Mv]... Move atoms to another (general) position
c[Rt]... Rotate atoms about an axis

      ELSE IF((cha2(l0:).eq.'Mv' .or.cha2(l0:).eq.'Rt') .and. tagYES 
     &                       .and. Nsp.ne.0 .and. Basic_Primitive) THEN

         if(angstr.eq.'<Frac_conv> ') then
            write(*,*)
     & 'ERROR! This will NOT work with An set to CONVENTIONAL CELL.'
            write(*,*) '       Please, change to any other An option!'
            write(*,*)'Hit ENTER when done ...'
            read(*,*) ;             go to 21
         end if

c___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ check if there are equivalent atoms from the set of the exsiting ones;
c            iErr=-1 if there are; the only acceptable option is iErr=0 to proceed

         call make_irr_stars(Rnew,iSort,listat,iErr,.false.)
         if(iErr.eq.1) then
            write(*,'(a)')
     &         '====================================================',
     &         '====   WARNING! The cell is too BIG!      ==========', 
     &         '====                                      ==========', 
     &         '====  (1) remove some atoms or            ==========', 
     &         '====  (2) increase N0LT in tetr_param.inc =========='
            write(*,'(a,i7,a/a)')
     &        '====      to the value of ',iErr,'         ==========',
     &         '===================================================='
            write(*,*)'Hit ENTER when done ...'
            read(*,*)
            go to 21
         else if(iErr.eq.-1) then
            write(*,'(a)')
     &         '====================================================',
     &         '====   WARNING! Cannot proceed here       ==========', 
     &         '==== as some atoms were found EQUIVALENT. ==========', 
     &         '====                                      ==========', 
     &         '====  (1) use Gn to generate the cell and ==========', 
     &         '====      remove equivalent atoms         ==========',
     &         '====  (2) use U1 to keep only first atoms ==========', 
     &         '====      of all stars                    ==========', 
     &         '====                                      ==========', 
     &         '====  to safely proceed with this options ==========',
     &         '===================================================='
            write(*,*)'Hit ENTER when done ...'
            read(*,*)
            go to 21
         end if

c___________ ask about the target.

 94      if(cha2(l0:).eq.'Mv') then
            call ask_displacement(angstr,dir,dmove,dd,.false.,nat1,back)
            if(back) then
               do i=1,ITI
                  if(.not.tagYES) listat(i)=.false.
               end do
               go to 21
            end if
         else if(cha2(l0:).eq.'Rt') then
            call specify_angle(cntp,C_rot)
         end if
         
c___________ create list of atoms to be moved associated with stars they form

         do i=1,ITI
            listt(i)=listat(i)
         end do

c___________ loop over all stars (complete or incomplete)

         do i=1,ITI
            if(listt(i)) then

c___________________ consider each star separately; keep only the 1st
c                    atom of each star

               call list_of_star(i,list,nlist,list_rot,.false.)

c__________________________ the 1st atom in the list should be the 1st 
c                           atom of the star

               do j=1,nlist
                  jat=list(j)
                  listt(jat)=.false.
                  if(Genrt(jat)) then
                     if(j.ne.1) stop 'error in list_of_star'
                     j_st1=jat

c__________________________ move/rotate the 1st atom of the star
                     if(cha2(l0:).eq.'Mv') then
                        TI2(1,jat)=TI(1,jat)+dmove/dd * dir(1)
                        TI2(2,jat)=TI(2,jat)+dmove/dd * dir(2)
                        TI2(3,jat)=TI(3,jat)+dmove/dd * dir(3)
                     else if(cha2(l0:).eq.'Rt') then
                        call rotate_atom(TI(1,jat),TI(2,jat),TI(3,jat),
     ,                          TI2(1,jat),TI2(2,jat),TI2(3,jat),
     ,                                              cntp,C_rot)
                     end if
                  else

c__________________________ move correspondingly other atoms of this star 
                     call transform(TI2(1,j_st1),r,list_rot(j))
                     TI2(1,jat)=r(1) ; TI2(2,jat)=r(2) ; TI2(3,jat)=r(3)
                  end if
               end do
c___________________ copy non-tagged atoms to TI2 as they are
            else
               if(.not.listat(i)) then
                  TI2(1,i)=TI(1,i) ; TI2(2,i)=TI(2,i) ; TI2(3,i)=TI(3,i)
               end if
            end if
         end do

c___________ check new positions
         do k=1,ITI
            if(listat(k)) then
               do k1=1,ITI
                  if(k.ne.k1) then
                     r(1)=TI2(1,k1)-TI2(1,k)
                     r(2)=TI2(2,k1)-TI2(2,k)
                     r(3)=TI2(3,k1)-TI2(3,k)
                     if(ask_equiv(r,BJ,3,tiny_equiv)) then
                        write(*,*) 'ERROR! Found equivalences!'
                        go to 94
                     end if
                  end if
               end do
            end if
         end do
         write(*,*)'O.K.! New positions are fine!' 
         do i=1,ITI
            if(listat(i)) then
               TI(1,i)=TI2(1,i) ; TI(2,i)=TI2(2,i) ; TI(3,i)=TI2(3,i)
            end if
         end do

c___________ as atoms have been moved into new Wyckoff positions, another
c            number of them may be in stars now; rerun Gn to generate new 
c            complete stars
         Generated=.false.
         write(*,'(a)')
     &         '====================================================',
     &         '==== WARNING! The stars may be INCOMPLETE ==========', 
     &         '====                                      ==========', 
     &         '====  Run Gn to generate complete stars   ==========',
     &         '====      and build the unit cell!        ==========',
     &         '===================================================='
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[At]...... add an atom, update Species, Nsp, NspN and ITI

      ELSE IF(cha2(l0:).eq.'At') THEN
         
         if(angstr.eq.'<Frac_conv> ' .and. (.not.Conv_Cell)) then
            write(*,*)'ERROR! Set the CONVENTIONAL CELL via Su first!'
            write(*,*)'Hit ENTER when ready ...'
            read(*,*) ;             go to 21
         end if

         write(*,*)
     &   '************************************************************'
         write(*,*)
     &   '*** Specify an atom; its symmetry equivalent images, if  ***'
         write(*,*)
     &   '***  not already given, will be generated later in Gn    ***'
         write(*,*)
     &   '************************************************************'

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if

c___________ keep the old geometry for undo
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,
     ,        Species,relax_flag,Genrt)

c___________ enter the species of the atom to be added
 98      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if

c___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!'
            go to 98
         end if
         if(Nsp.gt.0) then
            do ii=1,Nsp
               if(spec.eq.Species(ii)) then
                  jsp=ii
                  go to 97
               end if
            end do
         end if
         jsp=Nsp+1 ; NspN(jsp)=0 ; Species(jsp)=spec

c__________ now enter its coordinates
 97      if(angstr.eq.'<Frac_conv> ') then
 6          write(*,*)
     &        'Give fractional coordinates wrt CONVENTIONAL cell:'
            READ(*,*,err=6) x(1),x(2),x(3)
            r(1)=x(1)*AC(1,1)+x(2)*AC(2,1)+x(3)*AC(3,1)
            r(2)=x(1)*AC(1,2)+x(2)*AC(2,2)+x(3)*AC(3,2)
            r(3)=x(1)*AC(1,3)+x(2)*AC(2,3)+x(3)*AC(3,3)
         else
            call givepoint(r(1),r(2),r(3),angstr)
         end if
         call add_atom1(r,jsp,.true.,ion,iSort,1,listat)
         Generated=.false.

c___________ construct all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Ad]....... add atoms from another file of accepted formats

      ELSE IF(cha2(l0:).eq.'Ad') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in [tetr_param.inc] file!'
            go to 21
         end if

c___________ keep the old geometry in /buffer/
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,
     ,                                                relax_flag,Genrt)

c___________ choose the read format and then read in the geometry
 111     call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
         if(Which_Format.eq.'  None') go to 21
         call initiate(Which_Format,seed1,l0seed1,Err)
         if(Err) go to 111

c___________ keep the newly read geometry in /buffer1/
         call keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)

c___________ restore the original geometry from /buffer/
         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ add atoms from /buffer1/ to the old set one by one  
         if(ITI+ITI3.gt.N0LT) then
            write(*,*)'ERROR! Increase N0LT in [tetr_param.inc] file !'
            write(*,*)'       Cannot add atoms from this file        !'
            go to 21
         end if
         nat=0
         do jsp3=1,Nsp3
            jsp=jsp_species(Species3(jsp3),Species,Nsp)
            if(jsp.eq.0) then
               jsp=Nsp+1
               Species(jsp)=Species3(jsp3)
               NspN(jsp)=0
            end if
            do k=1,NspN3(jsp3)
               nat=nat+1
               r2(1)=TI3(1,nat)
               r2(2)=TI3(2,nat)
               r2(3)=TI3(3,nat)
               call add_atom1(r2,jsp,.true.,ion,iSort,1,listat)
               listat(ion)=.true.
            end do
         end do
         Generated=.false.

c__________ compose the list

         call list_dash(listat,ITI,tmp,lists,length,long)
         tagYES=.true.

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Gn]...... Generate all atoms of the primitive cell from the current set of 
c           atoms-generators of the orbits

      ELSE IF(cha2(l0:).eq.'Gn' .and. Nsp.ne.0 
     &                                    .and. Basic_Primitive) THEN

c___________ remove tagging if exists

         do i=1,ITI
            listat(i)=.false.
         end do
         tagYES=.false.

c___________ keep the old geometry for undo
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ remove equivalent atoms from the set of the exsiting ones
c            and leave only 1st atoms of stars

         call make_irr_stars(Rnew,iSort,listat,iErr,.true.)
         if(iErr.eq.1) then
            write(*,*)'WARNING! Cannot generate unit cell atoms!'
            go to 21
         end if

c___________ generate complete stars and create the whole PRIMITIVE unit cell

         ITI_=ITI
         do nat=ITI_,1,-1
            k=iSort(nat)
            call make_star(TI(1,nat),k,nstar,Rnew)
            if(nstar.gt.1) then
               do it=2,nstar
                  call add_atom1(Rnew(1,it),k,.true.,ion,iSort,it,
     ,                 listat)
               end do
            end if
         end do

c____________ generate reference vector showing how atoms are related by 
c             the space group operators (wrt the PRIMITIVE cell)

         call subl_go(iSort,.true.)
         Generated=.true.

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[U1].... keep only 1st atoms from each star

      ELSE IF(cha2(l0:).eq.'U1' .and. Generated) THEN

c___________ keep the old geometry in /buffer/
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ keep the 1st atoms of stars
         call keep_1st_from_stars(iSort,listat,tagYES)
         call subl_go(iSort,.false.)
         Generated=.false.

c__________ compose the list

         if(tagYES) call list_dash(listat,ITI,tmp,lists,length,long)

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[U].... undo the last step: restore AJ, BJ and TI from the previous step

      ELSE IF(cha2(l0:).eq.'U') THEN

c____________ remove tagging

         do i=1,ITI
            listat(i)=.false.
         end do
         tagYES=.false.

c____________ restore here

         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         Generated=.false.
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[UU]....... start again from scratch

      ELSE IF(cha2(l0:).eq.'UU') THEN

c___________ keep the old geometry in /buffer/
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         Generated=.false.

c___________ initialise everything
         go to 11

c[Dm]...... 3D or 2D space groups

      ELSE IF(cha2(l0:).eq.'Dm') THEN

         if(Nsp.ne.0) then
            write(*,*)'WARNING: the previous geometry will be LOST'
            write(*,*)'Presss ENTER to proceed or N/n to return:'
            read(*,'(a)') answer
            if(answer.eq.'n' .or. answer.eq.'N') go to 21
         end if

         if(Group_3D) then
            Group_3D=.false.
         else
            Group_3D=.true.
         end if
         Yes_SpaceGr=.false.
         Basic_Primitive=.false.
         Generated=.false.

c_____________ keep only the 1st atoms of all stars
         call keep_1st_from_stars(iSort,listat,tagYES)
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c[XY]...... ask whether to produce geom.xyz file automatically

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'None') then
c            YES_xyz='Ymol'
c         else if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='None'
c         end if

c[Hs]...... add Hydrongens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[An]...... choose the way how the coordinates are given

      ELSE IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<Frac_conv>'
         else if(angstr.eq.'<Frac_conv> ') then
            angstr='<Fractional>'
         end if 

c[Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co' .and. Nsp.ne.0) THEN
         call show_atoms_notag_star(listat)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy' .and. Basic_Primitive) THEN

         call wyckoff(line1,ll1)
         write(*,'(a)')'>>>>>>>>>>>> Space group <<<<<<<<<<<<<<<<<<'
         write(*,'(a)')
     &   '_i__KG__NAZ______{Fractional translation}_______Int.Tables___'
         do i=1,MGp
            if(cartesian) then
               p1=FrTr(1,i)
               p2=FrTr(2,i)
               p3=FrTr(3,i)
            else
               do j=1,3
                  r(j)=FrTr(j,i)
               end do
               if(.not.primitive) then
                  call reducn(r,AJc,BJc)
                  p1=BJc(1,1)*r(1)+BJc(1,2)*r(2)+BJc(1,3)*r(3)
                  p2=BJc(2,1)*r(1)+BJc(2,2)*r(2)+BJc(2,3)*r(3)
                  p3=BJc(3,1)*r(1)+BJc(3,2)*r(2)+BJc(3,3)*r(3)
               else
                  call reducn(r,AJ,BJ)
                  p1=BJ(1,1)*r(1)+BJ(1,2)*r(2)+BJ(1,3)*r(3)
                  p2=BJ(2,1)*r(1)+BJ(2,2)*r(2)+BJ(2,3)*r(3)
                  p3=BJ(3,1)*r(1)+BJ(3,2)*r(2)+BJ(3,3)*r(3)
               end if
            end if
            write(*,'(2(i2,1x),a4,3(1x,f10.5),5x,7a)') 
     ,           i,KGp(i),NAZ(KGp(i)),p1,p2,p3,
     ,           '(',line1(i,1)(ll1(i,1,1):ll1(i,1,2)),',',
     ,           line1(i,2)(ll1(i,2,1):ll1(i,2,2)),',',
     ,           line1(i,3)(ll1(i,3,1):ll1(i,3,2)),')   '
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)
         write(*,*) 
     &   '>>>>>>>> Reciprocal lattice vectors (up tp 2*pi) <<<<<<<<<<'
         write(*,'(8x,a,5x,3(f10.5,x))') 'vec 1 => ',(BJ(1,i),i=1,3)
         write(*,'(8x,a,5x,3(f10.5,x))') 'vec 2 => ',(BJ(2,i),i=1,3)
         write(*,'(8x,a,5x,3(f10.5,x))') 'vec 3 => ',(BJ(3,i),i=1,3)
         write(*,*)'Hit ENTER when done ...'
         read(*,*)
         if(Nsp.ne.0 .and. Generated) then
            write(*,'(a)')
     &  '>>>>>>>>>>>> Group operations on cell atoms <<<<<<<<<<<<<<<<<<'
            do k=1,ITI
               write(*,*)'---- '//Species(iSort(k))//' atom ',k,
     &              ' is transformed into atoms:'
               write(*,'(12(i5,x))') (iSblGo(k,Irot),Irot=1,MGp)
            end do
            write(*,*)'Hit ENTER when done ...'
            read(*,*)
         end if

c[Ca].... show symmetry in cartesian or in fractional

      ELSE IF(cha2(l0:).eq.'Ca' .and. Basic_Primitive) THEN

         if(cartesian) then
            cartesian=.false.
         else
            cartesian=.true.
         end if

c[Re].... show fractional translations reduced wrt primitive or
c         conventional cell

      ELSE IF(cha2(l0:).eq.'Re' .and. Basic_Primitive) THEN

         if(primitive) then
            primitive=.false.
         else
            primitive=.true.
         end if

c[Bb].... ask extensions for the breeding box.

      ELSE IF(cha2(l0:).eq.'Bb' .and. Basic_Primitive) THEN

         call ask_breeding_box(M11,N11,M22,N22,M33,N33)
         if(Nsp.ne.0) 
     &        call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[B0].... nullify the extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'B0') THEN

         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         if(Nsp.ne.0) 
     &        call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[W].... write geom.xyz file for the current breeding box: visualisation only.

      ELSE IF(cha2(l0:).eq.'W' .and. Nsp.ne.0 .and. 
     &                                          YES_xyz.ne.'None') THEN

         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[P].... finish: continue with the current setting

      ELSE IF(cha2(l0:).eq.'P' .and. Generated) THEN

         if(exist) write(*,*) 
     & 'WARNING! The original setting existed before [Pc] will be LOST!'

         return

c[S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S' .and. Generated) THEN

         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

c[Sf].... generate SIESTA code (routine constr.f) to symmetrise forces
c         during atomic relaxation - according to the present symmetry

      ELSE IF(cha2(l0:).eq.'Sf' .and. Generated .and. MGp.gt.1) THEN

         if(ITI.gt.9999) then
            write(*,*)'WARNING: option NOT supported - too many atoms'
            write(*,*)'Press ENTER when ready ...'
            read(*,*)
            go to 21
         end if

         write(*,*)'... generating for SIESTA constr.f file ...'
         open(93,file='for_SIESTA_constr.file',form='formatted')
         do j=1,MGp,24
            j1=j+23
            if(j1.gt.MGp) j1=MGp
            write(93,'(a,48(x,i2,2x))')'c..operations: ',(KGp(i),i=j,j1)
            write(93,'(a,14x,48(a,x))')  'c', (NAZ(KGp(i)),i=j,j1)
         end do
         
c_________________ working out first atoms of all orbits
         do nat=1,ITI
            listt(nat)=.false.
         end do
         iorb=0
         do nat=1,ITI
            if(.not.listt(nat)) then
               iorb=iorb+1
               iorbit(iorb)=nat
               listt(nat)=.true.
               do Irot=1,MGp
                  nat1=iSblGo(nat,Irot)
                  if(.not.listt(nat1)) listt(nat1)=.true.
               end do
            end if
         end do

c_________________ working out relations between forces on 1st atoms of orbits

         do ior=1,iorb
            nat=iorbit(ior)
            write(93,'(2(a,i3),a)')
     &           'c=======> orbit= ',ior,', 1st atom = ',nat,' <======='

c______________________ local group
            ig=0
            do Irot=2,MGp
               nat1=iSblGo(nat,Irot)
               if(nat1.eq.nat) then
                  ig=ig+1
                  local(ig)=Irot
c                  write(93,'(a,3(i2,x),a)')
c     &                  'c_loc_ ',ig,local(ig),KGp(Irot),NAZ(KGp(Irot)) 
               end if
            end do
            mlg=ig
            if(mlg.le.1) then
               typ='E'
            else
               call analyse_loc_grp(typ,v,local,mlg,KGp,93,err,.false.)
c               call analyse_loc_grp(typ,v,local,mlg,KGp,93,err,.true.)
               if(err) then
                  close(93,status='delete')
                  go to 21
               end if
            end if

c______________________ print the local group and work out the force code
            do i=1,mlg,10
               i1=i+9
               if(i1.gt.mlg) i1=mlg
               write(93,'(a,10(a,x))')
     &                      'c...local: ',(NAZ(KGp(local(j))),j=i,i1) 
            end do
            call code_same_atom(nat,v,typ,93)
         end do

c_________________ working out relations between forces on different atoms
         do nat=1,ITI
            listt(nat)=.false.
         end do
         do nat=1,ITI
            call name_from_number(nat,ch4,l,err)
c
            if(.not.listt(nat)) then
               listt(nat)=.true.

               do Irot=1,MGp
                  nat1=iSblGo(nat,Irot)
                  is1=iSort(nat1)
                  Ir=KGp(Irot)
                  call name_from_number(Ir,hh4,lr,err)
                  if(.not.listt(nat1)) then
                     call name_from_number(nat1,cha4,l1,err)
                     write(93,'(3a,i5,a,i5,2a)')
     &                 'c....... force on ',Species(is1),' atom ',nat1,
     &                ' via atom ',nat,' and operation ',NAZ(Ir)
c                     write(93,*) (C(1,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)') 'c','fa(1,',cha4(l1:),')='
     &                    //'C(1,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'//
     &                      'C(1,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// 
     &                      'C(1,3,',hh4(lr:),')*fa(3,',ch4(l:),')'
c                     write(93,*) (C(2,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)')'c','fa(2,',cha4(l1:),')='
     &                    //'C(2,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'//
     &                      'C(2,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// 
     &                      'C(2,3,',hh4(lr:),')*fa(3,',ch4(l:),')'
c                     write(93,*) (C(3,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)')'c','fa(3,',cha4(l1:),')='
     &                    //'C(3,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'//
     &                      'C(3,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// 
     &                      'C(3,3,',hh4(lr:),')*fa(3,',ch4(l:),')' 

                     call cha_name(C(1,1,Ir),C(1,2,Ir),
     ,                                         C(1,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a)') 'fa(1,',cha4(l1:),')=',cc(:ll)
                     call cha_name(C(2,1,Ir),C(2,2,Ir),
     ,                                         C(2,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a)')  'fa(2,',cha4(l1:),')=',cc(:ll)
                     call cha_name(C(3,1,Ir),C(3,2,Ir),
     ,                                         C(3,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a/a)')
     &                                'fa(3,',cha4(l1:),')=',cc(:ll),'c'

                     listt(nat1)=.true.
                  end if
               end do
            end if
c
         end do
c
c___________________ stress tensor
c
         call do_stress(93,Group_3D,GROUPp)
         close(93)

c[Q].... finish: quit, restore the previous setting if exist

      ELSE IF(cha2(l0:).eq.'Q') THEN

         if(exist) 
     &   call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

      subroutine make_star(x,is,nstar,Rnew)
c.....................................................................
c    Constructs a star of vectors from the point x() using all 
c space group operations (excluding pure translations). If new vectors
c are found, they are accepted after checking with existing ones.
c.....................................................................
c x()   - vector                                              [IN] 
c is    - species number of the incoming vector               [IN]
c nstar - number of vectors in the star                       [OUT]
c Rnew  - vectors of the star                                 [OUT]
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension r(3),r1(3),x(3),Rnew(3,48)
      logical ask_equiv

      nstar=0

c______________ loop over rotations: transform the vector R by means of
c   the complete space group operation ( Irot | FrTr(Irot) ) and check
c   which vector it is equivalent to.

      do 5 Irot=1,MGp

         call transform(x,r,Irot)

c__________________check if it matches any existing sublattice vector 

         if(nstar.ge.1) then
            do k1=1,nstar
               r1(1)=r(1)-Rnew(1,k1)
               r1(2)=r(2)-Rnew(2,k1)
               r1(3)=r(3)-Rnew(3,k1)
               if(ask_equiv(r1,BJ,3,tiny_equiv)) go to 5
            end do
         end if

c_________add this "new" vector to the list in TI for future comparison

         nstar=nstar+1
         Rnew(1,nstar)=r(1) ; Rnew(2,nstar)=r(2) ; Rnew(3,nstar)=r(3)
         
 5    end do
      return
      end

      subroutine subl_go(iSort,hard)
c.....................................................................
c    The reference vector iSblGo(k,Irot), is built up that
c  indicates to which sublattice k1=iSblGo(k,Irot) the atom k
c  transforms to under the rotation Irot=1,...,MGp 
c  (is accompanied by the proper fractional translation if exists).
c.....................................................................
c  hard = .true.  - in this case an error is given if equivalent atoms
c                   are not found [must be a bug in the code or Gn has 
c                   not yet been executed]
c       = .false. - continue with the atoms resulting from the rotation
c                   given 0 if equivalent atoms do not exist 
c                   (the "soft" option)
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension r(3),r1(3),iSort(N0LT)
      logical ask_equiv,hard

      do k=1,ITI
         is=iSort(k)

         do Irot=1,MGp
            call transform(TI(1,k),r,Irot)

c__________________check if it matches any sublattice vector k1 and then the
c                   "new" vectors need to be attached

            do k1=1,ITI
               r1(1)=r(1)-TI(1,k1)
               r1(2)=r(2)-TI(2,k1)
               r1(3)=r(3)-TI(3,k1)
               if(ask_equiv(r1,BJ,3,tiny_equiv)) then
                  is1=iSort(k1)
                  go to 2
               end if
            end do
            if(hard) then
               go to 10
            else
               iSblGo(k,Irot)=0
               go to 5
            end if
c
 2          if(is.ne.is1) then
               write(*,*)'WARNING: wrong species {is,is1}=',is,is1
               write(*,*)'No worries: will be dealt with in Gn'
            end if
            iSblGo(k,Irot)=k1

 5       end do

      end do
      return
c................. error
 10   write(*,*)'FATAL! Did not find equivalence!'
      stop
      end

      subroutine add_atom1(x,jsp,speak,ion,iSort,nstar,listat)
c......................................................................
c  add an  atom at x(), species jsp, to the primitive cell
c  ion - atomic number of the added atom
c......................................................................
c  nstar - number in the star 
c  Genrt(ion)=T if it is the 1st atom of the star (=orbit)
c  Genrt(ion)=F if it is not
c......................................................................
c  no check is required for the new atom as this is done later (in Gn)
c......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension x(3),iSort(N0LT)
      logical speak,listat(N0LT)

c______ move atoms in TI/ITI
      ion=ITI+1
      if(jsp.lt.Nsp) then
         do j=Nsp,jsp+1,-1
            do k=NspN(j),1,-1
               ion=ion-1  
               TI(1,ion+1)=TI(1,ion)
               TI(2,ion+1)=TI(2,ion)
               TI(3,ion+1)=TI(3,ion)
               relax_flag(1,ion+1)=relax_flag(1,ion)
               relax_flag(2,ion+1)=relax_flag(2,ion)
               relax_flag(3,ion+1)=relax_flag(3,ion)
               iSort(ion+1)=iSort(ion)
               Genrt(ion+1)=Genrt(ion)
               listat(ion+1)=listat(ion)
            end do
         end do
      end if
      TI(1,ion)=x(1) ; TI(2,ion)=x(2) ; TI(3,ion)=x(3)
      relax_flag(1,ion)='T' 
      relax_flag(2,ion)='T' 
      relax_flag(3,ion)='T'
      iSort(ion)=jsp
      if(nstar.eq.1) then
         Genrt(ion)=.true.
      else
         Genrt(ion)=.false.
      end if
      listat(ion)=.false.
      ITI=ITI+1
 
c______ move atoms in NspN/Nsp
      NspN(jsp)=NspN(jsp)+1
      if(jsp.eq.Nsp+1) Nsp=Nsp+1

      if(speak)  write(*,'(a,i5)')
     &     'O.K.! This position is fine! Adding as # ',ion
      return
      end

      subroutine show_atoms_notag_star(listat)
      include 'real8.inc'
      include 'tetrag1.inc'
      logical listat(N0LT)
      character cha
      k=0
      do i=1,Nsp
         write(*,'(3a,i5)')'.... Species <',Species(i),'> ......> ',i
         write(*,'(a)')' Tot   # |----------  Fractional ---------|'
     &  //'-------------  Cartesian ---------| Relax Star-gen Tag'
         do j=1,NspN(i)
            k=k+1
            a1=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
            a2=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
            a3=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
            if(listat(k)) then
               cha='Y'
            else
               cha=' '
            end if
         write(*,'(2(x,i3),x,3(x,f10.5),2x,3(x,f10.5),3x,a,6x,l1,4x,a)') 
     &           k,j,a1,a2,a3,(TI(j1,k),j1=1,3),
     ,    relax_flag(1,k)//relax_flag(2,k)//relax_flag(3,k),Genrt(k),cha
         end do
      end do
      write(*,*)'Hit ENTER when done ...'
      read(*,*)
      return
      end

      subroutine keep_1st_from_stars(iSort,listat,tagYES)
c.......................................................................
c remove all atoms of stars generated from the 1st their atoms;
c              keep the 1st atoms though!
c listat - will also be kept for the 1st atoms
c.......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension iSort(N0LT)
      logical listat(N0LT),tagYES

      if(Nsp.ne.0) then
         ITI_=ITI
         do k=ITI_,1,-1
            if(.not.Genrt(k)) 
     &          call remove_atoms1(k,k,.true.,.true.,iSort,listat)
         end do
      end if
      return
      end

      subroutine list_of_star(n,list,nlist,list_rot,order)
c........................................................................
c  build up the list of atoms that are members of the same star as atom n
c  nlist - # of atoms in the list
c  list(i) - atom numbers from each member of the star, i=1,nstar
c  list_rot(i) = symmetry operation # (between 1 and MGp) that gives atom
c                list(i) of the list
c  order = T - atoms in the list will be ordered with their numbers 
c              descending
c        = F - will not be ordered, so that e.g. the 1st atom of the star
c              will be the first in the list 
c........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      integer list(MG0),list_rot(Mg0)
      logical order

c............ create unordered list
      list(1)=n
      nlist=1
      list_rot(1)=1

      do 10 Irot=1,MGp
         k=iSblGo(n,Irot)
         if(k.ne.0) then
            do k1=1,nlist
               if(k.eq.list(k1)) go to 10
            end do
            nlist=nlist+1
            list(nlist)=k
            list_rot(nlist)=Irot
         end if
 10   end do

c      write(*,'(a,i2,a)') 
c     &     '>> list of atom n=',n,' contains following atoms:'
c      write(*,'(20(i2,x))') (list(i),i=1,nlist)

c........... order list (from large to small numbers)

      if(nlist.eq.1) return
      if(order) then
 20      j=0
         do i=1,nlist-1
            if(list(i).lt.list(i+1)) then
               list1=list(i+1)
               list(i+1)=list(i)
               list(i)=list1
               list1=list_rot(i+1)
               list_rot(i+1)=list_rot(i)
               list_rot(i)=list1
               j=j+1
            end if
         end do
         if(j.ne.0) go to 20
      end if

      write(*,'(a,i2,a)') 
     &     '>> list of atom n=',n,' contains following atoms:'
      write(*,'(20(i2,x))') (list(i),i=1,nlist)

      return
      end

      subroutine make_irr_stars(Rnew,iSort,listat,iErr,remove_eq)
c......................................................................
c (1)  logical new(atom #) is generated:
c  new(atom) = T if the atom is not equivalent to any previous atom
c                as is the 1st member of its star;
c            = F if it is or is contained in previously defined stars
c (2)  remove_eq = T - then all atoms equivalent to the previously 
c                      defined atoms are removed and iErr=-1 is set
c                = F - will not be removed (but iErr=-1 is set anyway)
c......................................................................
c iErr = 0  - all atoms are nonequivalent
c       -1  - there are equivalent atoms; they are removed if 
c             remove_eq=T
c       >0  = the total number of atoms after application of the group
c             operations when it exceeds the available N0LT boundary
c......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      logical new(N0LT),ask_equiv,listat(N0LT),remove_eq
      dimension Rnew(3,48),r(3),iSort(N0LT)

      iErr=0
c............. check all atoms if they are new

      ITI_tot=0
      DO 10 k=1,ITI

         call make_star(TI(1,k),iSort(k),nstar,Rnew)
         if(k.eq.1) then
            new(k)=.true.

         else
c_______________ checking atom k with the existing stars

            do k1=1,k-1
               call make_star(TI(1,k1),iSort(k1),nstar1,Rnew)

               do n=1,nstar1
                  r(1)=TI(1,k)-Rnew(1,n)
                  r(2)=TI(2,k)-Rnew(2,n)
                  r(3)=TI(3,k)-Rnew(3,n)
                  if(ask_equiv(r,BJ,3,tiny_equiv)) then
                     new(k)=.false.
                     go to 10
                  end if
               end do
            end do
            new(k)=.true.

         end if
         if(new(k)) ITI_tot=ITI_tot+nstar

 10   END DO
      
c............. check if there are several 1st atoms that form the same 
c              stars

      do i=1,ITI
         if(.not.new(k) .and. Genrt(k)) iErr=-1
      end do

c............ remove unwanted atoms

      if(remove_eq) then
         ITI_=ITI
         do k=ITI_,1,-1
            if(.not.new(k)) 
     &           call remove_atoms1(k,k,.true.,.true.,iSort,listat)
         end do
      end if
      
c............ check if N0LT is big enough

      if(ITI_tot.gt.N0LT) then 
         write(*,*)'ERROR! Increase N0LT in tetr_param.inc to ',ITI_tot
         iErr=ITI_tot
      end if
      
      return
      end

      subroutine remove_atoms1(NumRem1,NumRem2,speak,ladder,iSort,
     ,                                                          listat)
c...................................................................
c  removes atoms numbers from NumRem1 to NumRem2 from the cell
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      logical speak,ladder,listat(N0LT)
      integer iSort(N0LT)

      Nsp1=Nsp
      Nrem=NumRem2-NumRem1+1
c___________remove atoms from the TI/ITI list
      if(NumRem2.lt.ITI) then
         do k=NumRem2+1,ITI
            k1=k-Nrem
            TI(1,k1)=TI(1,k)
            TI(2,k1)=TI(2,k)
            TI(3,k1)=TI(3,k)
            relax_flag(1,k1)=relax_flag(1,k)
            relax_flag(2,k1)=relax_flag(2,k)
            relax_flag(3,k1)=relax_flag(3,k)
            Genrt(k1)=Genrt(k)
            iSort(k1)=iSort(k)
            listat(k1)=listat(k)
         end do
      end if
      ITI=ITI-Nrem

c___________remove atoms from the NspN/Nsp list
      k=0
      do i=1,Nsp
         NspN3=NspN(i)
         do j=1,NspN(i)
            k=k+1
            if(k.ge.NumRem1.and.k.le.NumRem2) NspN3=NspN3-1
         end do
         NspN(i)=NspN3
      end do

c___________remove species with zero numbers of atoms
      if(ladder) then
         i=Nsp
 82      if(NspN(i).eq.0) then
            if(speak) write(*,*)'WARNING! Species ',i,' has gone!'
            if(i.lt.Nsp) then
               do l=i+1,Nsp
                  NspN(l-1)=NspN(l)
                  Species(l-1)=Species(l)
                  do kl=1,NspN(l)
                     iSort(kl)=iSort(kl)-1
                  end do
               end do
            end if
            Nsp=Nsp-1
         end if
         i=i-1
         if(i.gt.0) go to 82
         if(speak.and.Nsp.ne.Nsp1) then
            write(*,*)'WARNING! Number of species changed!'
            write(*,*)'         New number of species = ',Nsp
         end if
      end if

      return
      end
         
      subroutine cha_name(c1,c2,c3,ch4,l,cc,ll)
c...............................................................
c  generates a fortran code line 'cc' of length ll
c  out of 3 numbers c1,c2,c3 and the atom number ch4(l:)
c...............................................................
      include 'real8.inc'
      character cc*100,cha10*10,cc1*21,ch4*4

      l1=22-l
      ll=0
      if(c1.ne.0.0) then
         write(cha10,'(f10.5)') c1
         call find_left_space(cha10,10,lc)
         cc1(:l1)=cha10(lc+1:)//'*fa(1,'//ch4(l:)//')'
         cc(:l1)=cc1(:l1)
         ll = l1
      end if
      if(c2.ne.0.0) then
         write(cha10,'(f10.5)') c2
         call find_left_space(cha10,10,lc)
         cc1(:l1)=cha10(lc+1:)//'*fa(2,'//ch4(l:)//')'
         if(c2.lt.0.0) then
            cc(ll+1:ll+1+l1)=cc1(:l1)
            ll=ll+1+l1
         else
            cc(ll+1:ll+2+l1)='+'//cc1(:l1)
            ll=ll+2+l1
         end if
      end if
      if(c3.ne.0.0) then
         write(cha10,'(f10.5)') c3
         call find_left_space(cha10,10,lc)
         cc1(:l1)=cha10(lc+1:)//'*fa(3,'//ch4(l:)//')'
         if(c3.lt.0.0) then
            cc(ll+1:ll+1+l1)=cc1(:l1)
            ll=ll+1+l1
         else
            cc(ll+1:ll+2+l1)='+'//cc1(:l1)
            ll=ll+2+l1
         end if
      end if
      write(*,'(a)') cc(1:ll)
      return
      end

      subroutine analyse_loc_grp(type,v,local,mlg,KGp,UNIT,err,ver)
c................................................................
c vectors v() for every element of the local group local() are
c read in from 'sym_for_siesta.info'; the vectors are analysed
c and it is decided what type and which vector v() for the force
c constraint for the atom under consideration
c................................................................
c  IN: local, mlg,KGp
c OUT: type, v(), err
c................................................................
      include 'real8.inc'
      include 'pgroup_base.inc'
      include 'whereis.inc'
      dimension v(3),KGp(*),local(*),vv(3,48),v1(3)
      character line*50,type,typeR(64),typp(48)
      logical err,collinear,col,perpend,perp,ver
      integer UNIT
      data typeR/'E',23*'C',3*'P',14*'S',6*'P','I',8*'C',4*'S',4*'P'/
      err=.false.
c
c......... read vectors v() for each element of the local group into vv()     
c
      open(111,file=tetr_dir(tetr_l0:)//'/sym_for_siesta.info',err=50)
      do ig=1,mlg
         ie=KGp(local(ig))
         rewind 111
         do ir=1,2*ie-1
            read(111,'(a)',err=50,end=50) line
         end do
         read(111,*,err=50,end=50) (vv(j,ig),j=1,3)
         typp(ig)=typeR(ie)
         if(ver) write(UNIT,'(a,i2,x,a,x,a,3(x,f10.5))') 
     &                'c.loc. ',ig,NAZ(ie),typp(ig),(vv(j,ig),j=1,3)
         if(typp(ig).eq.'I') then
            type='I'
            return
         end if            
      end do
      close (111)
c
c............ analyse
c
      type=typp(1)
      v(1)=vv(1,1) ; v(2)=vv(2,1) ; v(3)=vv(3,1)
      if(ver) write(UNIT,'(a,3x,a,3(x,f10.5))') 'c ',type,v
      if(mlg.eq.1) return

      do ig=2,mlg
         if(ver) write(UNIT,'(a,i2,x,a,3(x,f10.5))') 
     &                          'c ',ig,typp(ig),(vv(j,ig),j=1,3)
         if(typp(ig).eq.'C' .or. typp(ig).eq.'S') then
            if(type.eq.'C' .or. type.eq.'S') then
               col=collinear(v,vv(1,ig))
               if(ver) write(UNIT,'(a,l1)') 'c C-C collinnear=',col
               if(.not.col) then
                  type='I'
                  return
               end if
            else if(type.eq.'P') then
               perp=perpend(v,vv(1,ig))
               if(ver) write(UNIT,'(a,l1)') 'c C-P perpendicular=',perp
               if(.not.perp) then
                  type='I'
                  return
               else
                  v(1)=vv(1,ig) ; v(2)=vv(2,ig) ; v(3)=vv(3,ig)
                  type='C'
               end if
            end if
         else if(typp(ig).eq.'P') then
            if(type.eq.'C' .or. type.eq.'S') then
               perp=perpend(v,vv(1,ig))
               if(ver) write(UNIT,'(a,l1)') 'c P-C perpendicular=',perp
               if(.not.perp) then
                  type='I'
                  return
               end if
            else if(type.eq.'P') then
               call cross_product(v,vv(1,ig),v1)
               v(1)=v1(1) ; v(2)=v1(2) ; v(3)=v1(3)
               type='C'
               if(ver) write(UNIT,'(a,3(x,f10.5))') 'c P-P cross= ',v
            end if
         end if
      end do
      
      return
c
c....... error in reading the info file
c
 50   err=.true.
      write(*,*)'ERROR in reading from [sym_for_siesta.info] file'
      write(*,*)'and thus Sf option is not available at this time'
      write(*,*)'Press ENTER when ready ...'
      read(*,*)
      return
      end

      subroutine code_same_atom(nat,v,type,UNIT)
c..............................................................
c works out symmetry relations between components of the force
c on atom nat with local symmetry: operation Irot of the type
c 'C', 'P', 'I' or 'S'.
c..............................................................
      include 'real8.inc'
      dimension v(3)
      character type,cha*4
      integer UNIT
      logical err1
c
      call name_from_number(nat,cha,l,err1)
      write(UNIT,'(3a,3(x,f10.5))') 
     &                   'c type=',type,', eigenvector = ', v

c........ analyse according to type and create the code
c
c   C = (rotation)   - the force along the eigenvector (axis)
c   P = (reflection) - the force perpendicular to the plane is zero
c   S = (C*P)        - the force along the eigenvector (axis)
c   I = (inversion)  - all 3 forces are zero
c
c_______________ inversion 
c
      if(type.eq.'I') then
         write(UNIT,'(6x,3a)')  'fa(1,',cha(l:),')=0.0'
         write(UNIT,'(6x,3a)')  'fa(2,',cha(l:),')=0.0'
         write(UNIT,'(6x,3a)')  'fa(3,',cha(l:),')=0.0'
c
c_______________ axis
c
      else if(type.eq.'C' .or. type.eq.'S') then
         do i=1,3
            if(v(i).ne.0.0) go to 5
         end do
c 5       write(UNIT,*)'making i=',i,' arbitrary'
 5       do j=1,3
            if(j.ne.i) then
               a=v(j)/v(i)
               if(a.eq.0.0) then
                  write(UNIT,'(6x,a,i1,3a)') 'fa(',j,',',cha(l:),')=0.0'
               else
                  write(UNIT,'(6x,a,i1,3a,f10.5,a,i1,3a)') 
     &           'fa(',j,',',cha(l:),')=',a,'*fa(',i,',',cha(l:),')'
               end if
            end if
         end do
c
c_______________ plane
c
         else if(type.eq.'P') then
            i0=0
            i1=0
            do i=1,3
               if(v(i).ne.0.0) then
                  if(i1.eq.0) then
                     i1=i
                  else
                     i2=i
                  end if
               else
                  i0=i0+1
               end if
            end do
c            write(UNIT,*)'making i=',i1,' arbitrary'
            if(i0.eq.2) then
               write(UNIT,'(6x,a,i1,3a)') 'fa(',i1,',',cha(l:),')=0.0'
            else if(i0.eq.1) then
               a=-v(i2)/v(i1)
                  write(UNIT,'(6x,a,i1,3a,f10.5,a,i1,3a)') 
     &           'fa(',i1,',',cha(l:),')=',a,'*fa(',i2,',',cha(l:),')'
            end if
         end if
      return
      end

      subroutine do_stress(uni,Group_3D,GROUPN)
c............................................................................
c  stress tensor str(i,j) is obtained from the crystal class point group
c............................................................................
      logical Group_3D
      integer uni
      character GROUPN*3
c
c............. 2D space groups
c
      if(.not.Group_3D) then
         write(uni,'(a)') 'c... STRESS tensor: '//
     &        'crystal class '//GROUPN//', dimension = 2D'
         write(uni,'(6x,a)') 'stress(1,3)=0.0'
         write(uni,'(6x,a)') 'stress(2,3)=0.0'
         write(uni,'(6x,a)') 'stress(3,3)=0.0'
         if(GROUPN.eq.'C1 ' .or. GROUPN.eq.'C2 ') then
            go to 10
         else
            write(uni,'(6x,a)') 'stress(1,2)=0.0'
            if(GROUPN.ne.'Cs ' .and. GROUPN.ne.'C2v') 
     &           write(uni,'(6x,a)') 'stress(2,2)=stress(1,1)'
         end if
c
c............. 3D space groups
c
      else
         write(uni,'(a)') 'c... STRESS tensor: '//
     &        'crystal class '//GROUPN//', dimension = 3D'
         if(GROUPN.eq.'C1 ' .or. GROUPN.eq.'Ci ') then
            go to 10
         else 
            write(uni,'(6x,a)') 'stress(1,3)=0.0'
            write(uni,'(6x,a)') 'stress(2,3)=0.0'
            if(GROUPN.ne.'C2h' .and. GROUPN.ne.'C2 ') then
               write(uni,'(6x,a)') 'stress(1,2)=0.0'
               if(GROUPN.eq.'D2h' .or. GROUPN.eq.'C2v' 
     &                              .or. GROUPN.eq.'D2 ') then
                  go to 10
               else if(GROUPN.ne.'T  ' .and. GROUPN.ne.'Td ' 
     &              .and. GROUPN.ne.'Th ' .and. GROUPN.ne.'Oh ' 
     &                                     .and. GROUPN.ne.'O  ') then
                  write(uni,'(6x,a)') 'stress(2,2)=stress(1,1)'
               else
                  write(uni,'(6x,a)') 'stress(2,2)=stress(1,1)'
                  write(uni,'(6x,a)') 'stress(3,3)=stress(1,1)'
               end if
            end if
         end if
      end if
c
c.............. symmetrisation (just in case)
c
 10   write(uni,'(6x,a)')'stress(2,1)=stress(1,2)'
      write(uni,'(6x,a)')'stress(3,1)=stress(1,3)'
      write(uni,'(6x,a)')'stress(3,2)=stress(2,3)'
      return
      end 

