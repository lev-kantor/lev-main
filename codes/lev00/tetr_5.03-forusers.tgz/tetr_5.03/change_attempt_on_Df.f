      subroutine change(nkp,kpoint,Which_Code)
c..........................................................................
c A number of tasks is performed:
c
c (1) a different choice of primitive lattice vectors giving equivalent
c     representation of the given lattice;
c (2) a rotation of the coordinate system; in this case a rotation of
c     the given set of lattice vectors is performed (fractional coordinates
c     of atoms will not change);
c (3) a new Cartesian origin is taken, i.e. the system is shifted by
c     a given vector, e.g. to the centre of mass;
c (4) SLAB calculation: change  the 3rd lattice vector to increase/decrease
c     the vacuum gap.
c (5) a different choice of primitive lattice vectors, e.g. with respect to
c     a plane specified by Miller indices.
c (6) large unit cell (supercell) construction ("breeding")
c
c  + a lot lot more (see the menu below!)
c...........................................................................
c     After the new coord. system or set of lattice vectors is choisen, 
c then: 
c (a) Cartesian coordinates of all atoms in the cell are recalculated;
c (b) a new crystal class symmetry group and the largest symmorphic point 
c     group of the system is provided;
c (c) user can go to the k-points generator;
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'lists.inc'

      dimension x(3),r(3),AN(3),AL(3,3),NspN2(N0KD),TI2(3,N0LT),dir(3)
      common /buffer_index/ Mol_index1(N0LT),iMol1
      common /buffer0/ A0(3,3),TI0(3,N0LT),B0(3,3),ITI0,
     ,     NspN0(N0KD),Nsp0,Species0(N0KD),relax_flag0(3,N0LT)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      common /buffer1/ AY(3,3),TI3(3,N0LT),BY(3,3),ITI3,
     ,     NspN3(N0KD),Nsp3,Species3(N0KD),relax_flag3(3,N0LT)
      common /reference/ AZ(3,3),TIz(3,N0LT),ITIz,
     ,                      NspNz(N0KD),Nspz,Speciesz(N0KD)
      character Species0*2,relax_flag0,spec*2,typ
      character Species1*2,line*200,relax_flag1
      character Species3*2,relax_flag3,seed1*40
      character Labels(N0LT)*2,Speciesz*2,fst_nd_rd(3)*2
      integer LinEnd(100),LinPos(100),iSort(N0LT),iorbit(N0LT)
      dimension Shift(3),v(3),local(MG0),vmod(3),Fr(3,N0LT)
      dimension cntp(3)
      dimension xn(3,neighb0),C_rot(3,3)
      character answer,cha2*2,angstr*12,YES_xyz*4
c      data angstr/'<Angstroms> '/
      data angstr/'<AtomNumber>'/,YES_xyz/'Xmol'/
      integer third(3,3)
      logical errr,listat(N0LT),TagYES,FinPos,Err,back,Add_Hs
      logical ask_equiv,Genrt1,listt(N0LT),BSSE_tag,Frozen_at
      logical list_fr(N0LT),thesame,list1(N0LT),found
      character Which_Format*6,Which_Code*6,cha4*4,ch4*4,hh4*4,cc*100
      double precision kpoint(Nkpoint,3)
      data third/0,3,2,3,0,1,2,1,0/,tiny/0.000001/
      data M1/0/,N1/0/,M2/0/,N2/0/,M3/0/,N3/0/,toler/0.1d0/
      data M11/0/,N11/0/,M22/0/,N22/0/,M33/0/,N33/0/,Add_Hs/.false./
      data H_at_dist/1.0/,wdth_nn/0.1/,fst_nd_rd/'st','nd','rd'/
c
c........... MENU ...........................................
c
c___________ keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)

c___________ keep the old geometry for undo

      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)
c
c___________ initialise tags
      tagYES=.false. ; listat=.false.
      call initial_mol_index(iMol,Mol_index,BSSE_tag)
c
c___________ initialise the reference geometry
      ITIz=ITI ; TIz=TI ; AZ=AJ ; NspNz=NspN ; Nspz=Nsp 
      Speciesz=Species
c
c========================================================================
c===================== MENU starts here =================================
c========================================================================

c___________ initialise the list of frozen atoms
 21   Frozen_at=.false.
      do i=1,ITI
         list_fr(i)=.false.
         if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' .or.
     &         relax_flag(3,i).eq.'F') then
            list_fr(i)=.true. ; Frozen_at=.true.
         end if
      end do
      if(Frozen_at) call do_nice_list(list_fr,ITI,listfr,lenfr,
     ,                                           N_lists,long_listfr)
c
      write(*,*)
      write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,'(a,4x,a)') '......... CURRENT lattice vectors ...',
     ,                       '.... REFERENCE lattice vectors ........' 
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x),5x,3(f10.5,x))') 
     &        '[',i,'] ',(AJ(i,j),j=1,3),(AZ(i,j),j=1,3)
      end do
      write(*,'(a)')
     &     '>>>>>>>>>>>>>>>> Current species are: <<<<<<<<<<<<<<'
      write(*,'(5x,20(a2,x))') (Species(i),i=1,Nsp)
      iAt=0
      do i=1,Nsp
         do ii=1,NspN(i)
            iAt=iAt+1 ; Labels(iAt)=Species(i)
         end do
      end do
      write(*,*)
      write(*,*)'========= CHOOSE AN OPTION:'
      write(*,*)
      write(*,*)
     &     '/==================================================\\'
      write(*,*)'||  HELP: a complex transformation is obtained by  ||'
      write(*,*)'|| applying elementary operations one after another||'
      write(*,*)'\\==================================================/'
      write(*,*)

      write(*,*)'  1. General shift of the system (new origin)'
      write(*,*)'  2. Shift the system to the center of mass'
      write(*,*)'  3. Rotate the system (the same origin)'
      write(*,*)' Sc. Scale lattice vectors & atomic positions up/down'
      write(*,*)
     &'------------ o p e r a t i o n s   w i t h   c e l l s -------'
      write(*,*)
     & '  5. Set all atoms inside the cell box (0 < fract.coord. < 1 )'
      write(*,*)
     &     ' Rf. Choose equivalent positions wrt reference input file'
      write(*,*)' 44. Cluster atoms around particular point'
      write(*,*)
     &     ' Sr. Force 1st & 2nd lattice vectors be in a surface plane'
      write(*,*)' Ex. Diagonal "breeding": construct a supercell'
      write(*,*)' Su. General  "breeding": construct a supercell'
      write(*,*)
     &' Rd. General  "reduction": reduce the cell to its primitive'
      write(*,*)' Df. Move lattice defect to an equivalent position'
      write(*,*)
     & '  8. Change one lattice vector (e.g. the 3rd to create SLAB)'
      write(*,*)
     &  '  9. Arbitrarily change lattice vectors (e.g. for molecules)'
      write(*,*)
     &'-------------- o t h e r   o p e r a t i o n s----------------'
      write(*,*)' 10. Manually add an atom to the cell'
      write(*,*)' Ad. Add atoms from another file'

c___________ BSSE calculation (with SIESTA)
      BSSE_tag=.false.
      do i=1,ITI
         if(Mol_index(i).eq.0) go to 19
      end do
      BSSE_tag=.true.
 19   if(BSSE_tag) then
         write(*,*)' B1. DIVISIONS: redo divisions from scratch' 
         write(*,*) 
     &    '     DIVISIONS: their current number = ',iMol,' <- complete'
         if(Which_Code.eq.'SIESTA') then
            write(*,*)' B2. SIESTA: BSSE + density difference script'
         else if(Which_Code.eq.'QUICKS') then
            write(*,*)
     &           ' B2. QUICKSTEP: Input file for the BSSE calculation'
         end if
         write(*,*)' B3. Generate script for density difference'
      else
         write(*,*)
     &         ' B1. DIVISIONS: divide up the system into molecules'
         write(*,*) 
     &         '     DIVISIONS: current number of divisions = ',iMol
      end if

c___________ operations with multiple lists
      if(tagYES) then
         write(*,*)
     &'-------------- m u l t i p l e   l i s t s   -----------------'
         write(*,*)
     &    '  T. Untag atoms (multiple lists): currently ON'
         write(*,*)'     >> Current set of tagged atoms: '
         call print_long_char(lists,length,long_lists)
         write(*,*)' Re. Redefine atoms to an equivalent position'
         write(*,*)'/Rm. Remove tagged atoms from the cell'
         write(*,*)
     &        '\\KT. Keep tagged atoms in the cell: remove the rest'
         write(*,*)' Rn. Rename tagged atoms: change species'
         write(*,*)' Mv. Move tagged atoms to another general position'
         write(*,*)' Rt. Rotate tagged atoms about an axis'
         write(*,*)'  H. Terminate tagged atoms with H link atoms'
      else
         length=0
         write(*,*)' Re. Redefine atoms to an equivalent position'
         write(*,*)'/Rm. Remove a range of atoms from the cell'
         write(*,*)
     &       '\\KT. Keep a range of atoms in the cell: remove the rest'
         write(*,*)' Rn. Rename a range of atoms: change species'
         write(*,*)
     &        ' Mv. Move a range of atoms to another general position'
         write(*,*)' Rt. Rotate a range of atoms about an axis'
         write(*,*)'  H. Terminate a range of atoms with H link atoms'
         write(*,*)
     &'-------------- m u l t i p l e   l i s t s   -----------------'
         write(*,*)
     &        '  T. Tag atoms (specify multiple lists): currently OFF'
         write(*,*) ' TT. Tag atoms (more complex options)'
      end if

c_____ show settings

      write(*,*)
     &'---------- v i s u a l i a s i o n   s e t t i n g s ---------'
c___________ set YES_xyz to the visualisation code: 
c            make geom.xyz file automatically after every change
      write(*,'(8x,a)')
     &     '>>>>> Current setting for the breeding box: <<<<<'
      write(*,'(13x,a,3(i2,a,i2,a))') '[',M11,'...',N11,'] x [', M22,
     &                           '...',N22,'] x [', M33,'...',N33,']'
      L_ext1=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)
      write(*,'(8x,2(a,i5))')
     &     '>>>>> extension = ',L_ext1,', # of atoms= ',ITI*L_ext1

      write(*,*)
     &        ' Bb. Set the size of the breeding box for visualisation'
      write(*,*) 
     &        ' B0. Nullify the breeding box (make the UNIT extension)'

      if(YES_xyz.ne.'None') then
         write(*,*)
     &   ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
      else
         write(*,*)
     &   ' XY. Do NOT produce <geom.xyz> file after every change'
      end if
      if(Add_Hs) then
         write(*,*)' Hs. H atoms to be added to <geom.xyz> file: YES'
      else 
         write(*,*)' Hs. H atoms to be added to <geom.xyz> file: NO'
      end if
      write(*,*)
     &   '  W. Write <geom.xyz> file for preview using current breeding'

      write(*,*)
     &'-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,*)' UU. ******  RESTORE the original setting ******'
      write(*,*)'  U. ********** UNDO the last step *************'
      if(Frozen_at) then
         write(*,*)' Fa. Frozen atoms:'
         call print_long_char(listfr,lenfr,long_listfr)
      else
         write(*,*)' Fa. Frozen atoms:     <-- not set'
      end if
      write(*,'(a)')
     & '  SR. Set current geometry as REFERENCE (for option H)'
      write(*,'(a,f10.5)')
     &        '  Tl. Tolerance when reducing the cell is: ',toler
      write(*,'(a,f10.5)')
     &        '  Hd. Distance between an atom and H is: ',H_at_dist
      write(*,'(a,f10.5)')
     &        '  Nd. Spherical belt width when finding nn is: ',wdth_nn

      write(*,*)
     &     ' An. [For input] Coordinates are specified in: '//angstr
      write(*,*)
     &     ' Co. Show current atomic positions in fractional/Cartesian'
      write(*,*)' Sy. Show the point symmetry'

      write(*,*)'  S. Save.'
      write(*,*)' ST. Save Tagged atoms in XYZ format.'
      write(*,*)' Sf. Save the SIESTA code to symmetrise forces'
      write(*,*)'  Q. Proceed/Quit'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[XY]...... ask whether to produce geom.xyz file automatically

      IF(cha2(l0:).eq.'XY') THEN

         if(YES_xyz.eq.'None') then
            YES_xyz='Ymol'
         else if(YES_xyz.eq.'Ymol') then
            YES_xyz='Xmol'
         else if(YES_xyz.eq.'Xmol') then
            YES_xyz='None'
         end if

c[Hs]...... add Hydrongens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs') THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[Fa]...... choose/modify the list of frozen atoms 

      ELSE IF(cha2(l0:).eq.'Fa') THEN

         if(Frozen_at) then
            do i=1,ITI
               if(list_fr(i)) then
                  relax_flag(1:3,i)='T' ; list_fr(i)=.false.
               end if
            end do
            write(*,*)'WARNING! The frozen atoms unselected!'
            Frozen_at=.false.  ; go to 21
         end if

c__________ specify wanted atoms
         call TTag(Frozen_at,ITI,TI,Labels,list_fr,listfr,lenfr,
     ,                                      N_lists,long_listfr)
         if(.not.Frozen_at) go to 21
         
c__________ set relaxation flags
         do i=1,ITI
            if(list_fr(i)) relax_flag(1:3,i)='F'
         end do
c         Frozen_at=.true.

c[SR]...... set the current geometry as the reference one (needed for H) 

      ELSE IF(cha2(l0:).eq.'SR') THEN

         ITIz=ITI ; TIz=TI ; AZ=AJ ; NspNz=NspN ; Nspz=Nsp 
         Speciesz=Species
      
c[Tl].... tolerance when reducing the cell size (in A)

      ELSE IF(cha2(l0:).eq.'Tl') THEN

 58      write(*,*)'Specify the tolerance:'
         read(*,*,err=58) toler
         if(toler.le.0.0) go to 58

c[Hd].... distance between atom and the terminating H (link atom)

      ELSE IF(cha2(l0:).eq.'Hd') THEN

 54      write(*,*)'Specify the distance to the terminating H atoms:'
         read(*,*,err=54) H_at_dist
         if(H_at_dist.le.0.0) go to 54

c[Nd].... when seraching for nn, a sperical belt of width wdth_nn is
c         allowed

      ELSE IF(cha2(l0:).eq.'Nd') THEN

 53      write(*,*) 'Specify the allowed width of a spherical belt'
         write(*,*) 'when searching for nearest neighbours:'
         read(*,*,err=53) wdth_nn
         if(wdth_nn.lt.0.0) go to 53

c[An]...... choose the way how the coordinates are given

      ELSE IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if 
c[Sc].... scale ll atomic positions by a factor

      ELSE IF(cha2(l0:).eq.'Sc') THEN
 57      write(*,*) 'Specify the scaling factor (to be multiplied with)'
         read(*,*,err=57) scalef
         if(scalef.lt.tiny) go to 57

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ scale the current system
         AJ=AJ*scalef
         j=0
         do k=1,Nsp
            do is=1,NspN(k)
               j=j+1 ; TI(1:3,j)=TI(1:3,j)*scalef
            end do
         end do

c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

c___________ construct all lattice sites and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &        call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[1]...... ask about shift of the system

      ELSE IF(cha2(l0:).eq.'1') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
 13      write(*,*)
     &        'Give a new origin of the coordinate system as x,y,z:'
         read(*,*,err=13) (Shift(i),i=1,3)
c
c___________ recalculate Cartesian atomic positions in TI(comp,number) 
c             (BJ are still OLD reciprocal vectors corresponding to 
c             old AJ=>AX):
c
         do k=1,ITI
            TI(1,k)=TI(1,k)-Shift(1)
            TI(2,k)=TI(2,k)-Shift(2)
            TI(3,k)=TI(3,k)-Shift(3)
         end do

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &        call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[2]...... shift the system to the center of mass

      ELSE IF(cha2(l0:).eq.'2') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c__________ ask about atomic masses
c
c 31      write(*,*)'Specify atomic masses in a.u.m. for all species:'
c         read(*,*,err=31) (AtMass(i),i=1,Nsp)
c         write(*,*)'Atomic masses are:'  
c         write(*,*) (AtMass(i),i=1,Nsp)  
c         write(*,*)'Do you want to correct masses (Y,y/other char)?'
c         read(*,'(a)') answer
c         if(answer.eq.'y'.or.answer.eq.'Y') go to 31
         do is=1,Nsp
            if(AtMass(is).eq.0.0) then
               write(*,*) 'ERROR! Atomic mass for '//Species(is)//
     &              ' is NOT available!'
               write(*,*)'Cannot proceeed! Press ENTER when ready ...'
               read(*,*)
               go to 21
            end if
         end do
         Shift(1)=0.0
         Shift(2)=0.0
         Shift(3)=0.0
         TotMass=0.0
         iAt=0
         do i=1,Nsp
            do ii=1,NspN(i)
               iAt=iAt+1
               Shift(1)=Shift(1)+TI(1,iAt)*AtMass(i)
               Shift(2)=Shift(2)+TI(2,iAt)*AtMass(i)
               Shift(3)=Shift(3)+TI(3,iAt)*AtMass(i)
               TotMass=TotMass+AtMass(i)
            end do
         end do
         Shift(1)=Shift(1)/TotMass
         Shift(2)=Shift(2)/TotMass
         Shift(3)=Shift(3)/TotMass
c
c_____ shift the system (if necessary) to the center of mass
c
         acofm=sqrt(Shift(1)**2+Shift(2)**2+Shift(3)**2)
         if(acofm.gt.tiny) then
            write(*,*)'WARNING! Center of mass is NOT in the origin!'
            write(*,'(a11,1x,3(f10.5,1x),a2)')
     &           'It is at: (', (Shift(j),j=1,3),' )'
            write(*,*)'New atomic positions are:'
            do i=1,ITI
               TI(1,i)=TI(1,i)-Shift(1)
               TI(2,i)=TI(2,i)-Shift(2)
               TI(3,i)=TI(3,i)-Shift(3)
               write(6,'(i3,5x,3(f10.5,1x))') i,(TI(jj,i),jj=1,3)
            end do
         else
            write(*,*)'GOOD! Center of mass IS in the origin!'
         end if

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[3]...... rotate

      ELSE IF(cha2(l0:).eq.'3') THEN

c___________ calculate scalar products
         do i=1,3
            do i1=1,3
               AL(i,i1)=AJ(i,1)*AJ(i1,1)+AJ(i,2)*AJ(i1,2)+
     +              AJ(i,3)*AJ(i1,3)
            end do
         end do

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

 1       write(*,*)'...................................................'
         write(*,*)' Rotation of the coordinate system is specified by ' 
         write(*,*)' giving new directions for a pair of two primitive'
         write(*,*)' lattice vectors using existing coordinate system:'  
         write(*,*)' MIND: the angle between them should be preserved!'
         write(*,*)'..................................................'
 35      write(*,*)'Which vectors (1, 2 or 1, 3 or 2, 3):'
         read(*,*,err=35) j1,j2
         if(j1.lt.0 .or. j1.gt.3 .or. j2.lt.0 .or. j2.gt.3) go to 35
         if(j1.eq.j2) go to 35
 51      write(*,'(a36,i1,a10)')
     &        'Give direction along lattice vector ',j1,' as x,y,z:'
         read(*,*,err=51) (AJ(j1,i),i=1,3)
 52      write(*,'(a36,i1,a10)')
     &        'Give direction along lattice vector ',j2,' as x,y,z:'
         read(*,*,err=52) (AJ(j2,i),i=1,3)
c
c_________ give correct lengthes for vectors j1,j2
c
         x1=sqrt(AL(j1,j1))/sqrt(AJ(j1,1)**2+AJ(j1,2)**2+AJ(j1,3)**2)
         x2=sqrt(AL(j2,j2))/sqrt(AJ(j2,1)**2+AJ(j2,2)**2+AJ(j2,3)**2)
         do i=1,3
            AJ(j1,i)=AJ(j1,i)*x1
            AJ(j2,i)=AJ(j2,i)*x2
         end do
c
c_________ check the angle between j1 and j2 by checking their scalar product
c
         ALn=AJ(j1,1)*AJ(j2,1)+AJ(j1,2)*AJ(j2,2)+AJ(j1,3)*AJ(j2,3)
         delta = abs(AL(j1,j2)-ALn)-tiny
         if(delta .gt. tiny) then
            write(*,*)'Error! Wrong direction by ',delta,' ! Try again!'
            write(*,*)'new 1 => ',(AJ(j1,jj),jj=1,3)
            write(*,*)'new 2 => ',(AJ(j2,jj),jj=1,3)
            write(*,*)'their dot product = ',ALn
            write(*,*)'        should be = ',AL(j1,j2)
            go to 51
         end if
c
c_________ find the correct 3rd vector, j3. It is represented in
c          the same way in the old case as in the new one via:
c          AJ(j3)=alpha*AJ(j1)+beta*AJ(j2)+gama*AN,
c          where AN is a normal vector to AJ(j1) and AJ(j2). Coefficients
c          alpha, beta and gama do not depend on the rotation.
c
         j3=third(j1,j2)
         det=AL(j1,j1)*AL(j2,j2)-AL(j1,j2)*AL(j1,j2)
         alpha=(AL(j1,j3)*AL(j2,j2)-AL(j1,j2)*AL(j2,j3))/det
         beta=(AL(j1,j1)*AL(j2,j3)-AL(j1,j3)*AL(j1,j2))/det
         AN(1)=AX(j1,2)*AX(j2,3)-AX(j1,3)*AX(j2,2)
         AN(2)=AX(j1,3)*AX(j2,1)-AX(j1,1)*AX(j2,3)
         AN(3)=AX(j1,1)*AX(j2,2)-AX(j1,2)*AX(j2,1)
         ann=AN(1)**2+AN(2)**2+AN(3)**2
         gama=(AX(j3,1)*AN(1)+AX(j3,2)*AN(2)+AX(j3,3)*AN(3))/ann
         AN(1)=AJ(j1,2)*AJ(j2,3)-AJ(j1,3)*AJ(j2,2)
         AN(2)=AJ(j1,3)*AJ(j2,1)-AJ(j1,1)*AJ(j2,3)
         AN(3)=AJ(j1,1)*AJ(j2,2)-AJ(j1,2)*AJ(j2,1)
         do i=1,3
            AJ(j3,i)=alpha*AJ(j1,i)+beta*AJ(j2,i)+gama*AN(i)
         end do
c
c________ ask about vectors
         write(*,*)'... NEW lattice vectors for the supercell ...'
         write(*,'(a,3(x,f10.5))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(3):   ',(AJ(3,i),i=1,3)
         write(*,*)
     &        'Did you wish just these to generate (Y,y/other char)?'
         read(*,'(a)') answer
         if(answer.ne.'y'.and.answer.ne.'Y') go to 1

c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)
c
c________ change Cartesian positions of atoms
c
         do k=1,ITI
            a1=TI1(1,k)*BX(1,1)+TI1(2,k)*BX(1,2)+TI1(3,k)*BX(1,3)
            a2=TI1(1,k)*BX(2,1)+TI1(2,k)*BX(2,2)+TI1(3,k)*BX(2,3)
            a3=TI1(1,k)*BX(3,1)+TI1(2,k)*BX(3,2)+TI1(3,k)*BX(3,3)
            TI(1,k)=a1*AJ(1,1)+a2*AJ(2,1)+a3*AJ(3,1)
            TI(2,k)=a1*AJ(1,2)+a2*AJ(2,2)+a3*AJ(3,2)
            TI(3,k)=a1*AJ(1,3)+a2*AJ(2,3)+a3*AJ(3,3)
         end do

c___________ construct all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Re]......  move atoms around. This is e.g. useful while preparing a SLAB
c           calculation.

      ELSE IF(cha2(l0:).eq.'Re') THEN

         write(*,*)
     &        '>>>>>>>>>>>>>>>>>>>> IMPORTANT! <<<<<<<<<<<<<<<<<<<<<<<<'
         write(*,*)
     &       '........................................................'
         write(*,*)
     &       'Picked atoms will be shifted by a lattice vector to an'
         write(*,*) 'equivalent position.'
         write(*,*)
     &       '........................................................'

         if(.not.tagYES) then
 61         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=61) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 61
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ ask for the integer coefficients i1,i2,i3 of the shift

 62      write(*,'(a,i3,a)')
     &        'Atoms will be moved by i1*AJ(1)+i2*AJ(2)+i3*AJ(3).'
         write(*,*)'Specify integers i1,i2,i3 for the shift:'
         read(*,*,err=62) i1,i2,i3

c___________ shift atom nat
         do nat=1,ITI
            if(listat(nat)) then
               TI(1,nat)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+TI(1,nat)
               TI(2,nat)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+TI(2,nat)
               TI(3,nat)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+TI(3,nat)
            end if
         end do

c___________ constract all lattice sites and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[5]...... set all atoms inside the cell box, i.e. with the fractional coordinates
c          between 0 and 1 

      ELSE IF(cha2(l0:).eq.'5') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ go through all atoms and "redefine" if necessary
         do nat=1,ITI
            do j=1,3
               fr1=TI(1,nat)*BJ(j,1)+TI(2,nat)*BJ(j,2)+TI(3,nat)*BJ(j,3)
               x(j)=fr1-int(fr1)
               if(fr1.lt.0.0) x(j)=x(j)+1.0
            end do
            TI(1,nat)=x(1)*AJ(1,1)+x(2)*AJ(2,1)+x(3)*AJ(3,1)
            TI(2,nat)=x(1)*AJ(1,2)+x(2)*AJ(2,2)+x(3)*AJ(3,2)
            TI(3,nat)=x(1)*AJ(1,3)+x(2)*AJ(2,3)+x(3)*AJ(3,3)
         end do

c___________ constract all lattice sites and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)


c[Rf]...... correct fractional coordinates of atoms in order for them
c           to be closer to those in a reference input file

      ELSE IF(cha2(l0:).eq.'Rf') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ choose the read format and then read in the geometry
 112     call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
         if(Which_Format.eq.'  None') go to 21
         call initiate(Which_Format,seed1,l0seed1,Err)
         if(Err) go to 112

c___________ keep the newly read geometry in /buffer1/
         call keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c
c___________ restore the original geometry from /buffer/
         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ check consistency

         do i=1,3
            do j=1,3
               if(abs(AJ(i,j)-AY(i,j)).gt.tiny) go to 300
            end do
         end do
         if(Nsp.ne.Nsp3) go to 300
         do is=1,Nsp
            if(NspN(is).ne.NspN3(is)) go to 300
            if(Species(is).ne.Species3(is)) go to 300
         end do

c___________ correct coordinates

         do nat=1,ITI
            do j=1,3
               fr1=TI(1,nat)*BJ(j,1)+TI(2,nat)*BJ(j,2)+TI(3,nat)*BJ(j,3)
               fr3=TI3(1,nat)*BJ(j,1)+
     +                          TI3(2,nat)*BJ(j,2)+TI3(3,nat)*BJ(j,3)
               x(j)=fr1-nint(fr1-fr3)
            end do
            TI(1,nat)=x(1)*AJ(1,1)+x(2)*AJ(2,1)+x(3)*AJ(3,1)
            TI(2,nat)=x(1)*AJ(1,2)+x(2)*AJ(2,2)+x(3)*AJ(3,2)
            TI(3,nat)=x(1)*AJ(1,3)+x(2)*AJ(2,3)+x(3)*AJ(3,3)
         end do

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)
         go to 21
 300     write(*,'(a)')'ERROR! The two geometries are NOT consistent!'
         write(*,'(a)')'========= > Operation ABORTED! <============='
         write(*,'(8x,a)') 'Press ENTER when ready ...'
         read(*,*)

c[44]...... new positions of atoms in the cell are found which
c           correspond to fractional coordinates between -0.5 and 0.5
c           around the origin at the specified point

      ELSE IF(cha2(l0:).eq.'44') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ specify the point

         call givepoint(x(1),x(2),x(3),angstr)

c___________ shift atoms to new positions
         
         do i=1,ITI
            r(1)=TI(1,i)-x(1)
            r(2)=TI(2,i)-x(2)
            r(3)=TI(3,i)-x(3) 
            call reducn1(r,AJ,BJ)
            TI(1,i)=r(1)+x(1)
            TI(2,i)=r(2)+x(2)
            TI(3,i)=r(3)+x(3) 
            write(6,'(i3,5x,3(f10.5,1x))') i,(TI(jj,i),jj=1,3)
         end do
         
c___________ constract all lattice sites and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Sr].... choose a new set of latttice vectors which are in the surface plane
c         specified by Miller indices or directly by the normal

      ELSE IF(cha2(l0:).eq.'Sr') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c(1)________ choose new basic lattice vectors so that the first two lie in the
c            specified plane.

         call normal_to_plane(AJ)
c
c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)
c
c________ work out fractional coordinates in new vectors
         do k=1,ITI
            Fr(1,k)=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
            Fr(2,k)=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
            Fr(3,k)=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
         end do

c(2)________ rotate the vectors so that the 1st is along X axis, the 2nd in the
c            XY plane, the 3rd as required to keep the same relative orientation
         do i=1,3
           vmod(i)=sqrt(AJ(i,1)*AJ(i,1)+AJ(i,2)*AJ(i,2)+AJ(i,3)*AJ(i,3))
         end do
         vdot12=AJ(1,1)*AJ(2,1)+AJ(1,2)*AJ(2,2)+AJ(1,3)*AJ(2,3)
         vdot13=AJ(1,1)*AJ(3,1)+AJ(1,2)*AJ(3,2)+AJ(1,3)*AJ(3,3)
         vdot23=AJ(2,1)*AJ(3,1)+AJ(2,2)*AJ(3,2)+AJ(2,3)*AJ(3,3)
         prod123=AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(3,2)*AJ(2,3))-
     -           AJ(1,2)*(AJ(2,1)*AJ(3,3)-AJ(3,1)*AJ(2,3))+
     +           AJ(1,3)*(AJ(2,1)*AJ(3,2)-AJ(3,1)*AJ(2,2))
         cos12=vdot12/(vmod(1)*vmod(2)) ; sin12=sqrt(1.0-cos12*cos12)
c________ new vectors
         AJ(1,1)=vmod(1) ; AJ(1,2:3)=0.0
         AJ(2,1)=vmod(2)*cos12 ; AJ(2,2)=vmod(2)*sin12 ; AJ(2,3)=0.0
         AJ(3,1)=vdot13/vmod(1)
         AJ(3,2)=( vdot23/vmod(2)-vdot13/vmod(1)*cos12 )/sin12
         AJ(3,3)=prod123/(vmod(1)*vmod(2)*sin12)

c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)
c
c(3)________ change Cartesian positions of atoms
c
         do k=1,ITI
           TI(1,k)=Fr(1,k)*AJ(1,1)+Fr(2,k)*AJ(2,1)+Fr(3,k)*AJ(3,1)
           TI(2,k)=Fr(1,k)*AJ(1,2)+Fr(2,k)*AJ(2,2)+Fr(3,k)*AJ(3,2)
           TI(3,k)=Fr(1,k)*AJ(1,3)+Fr(2,k)*AJ(2,3)+Fr(3,k)*AJ(3,3)
         end do

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &        call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Ex].... LUC construction: simple (diaginal) "breeding" of atoms

      ELSE IF(cha2(l0:).eq.'Ex') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ ask extensions along the existing lattice vectors for the 
c            breeding box
         call ask_breeding_box(M1,N1,M2,N2,M3,N3)

c___________ check first

         L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
         if(ITI*L_ext.gt.N0LT) then
            write(*,*)
     &        'ERROR! The breeding box is too big, see tetr_param.inc'
            go to 21
         end if

c___________ construct all lattice sites         
         jj=0
         nat=0
         DO i=1,Nsp
            write(*,'(a25,i3,a8)')'___> Atoms in species ',i,' <____'
            NspN2(i)=0
            do i1=M1,N1
               do i2=M2,N2
                  do i3=M3,N3

                     DO k=1,NspN(i)
                        jj=jj+1
                        TI(1,jj)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+
     +                       TI1(1,k+nat)
                        TI(2,jj)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+
     +                       TI1(2,k+nat)
                        TI(3,jj)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+
     +                       TI1(3,k+nat)
                        NspN2(i)=NspN2(i)+1
                        relax_flag(1,jj)=relax_flag1(1,k+nat)
                        relax_flag(2,jj)=relax_flag1(2,k+nat)
                        relax_flag(3,jj)=relax_flag1(3,k+nat)
                     END DO

                  end do
               end do
            end do
            nat=nat+NspN(i)
            NspN(i)=NspN2(i)
            write(*,*)'................ found ',NspN(i),' atoms'
         END DO
         ITI2=jj
         write(*,'(i5,a)') ITI2,' sites have been identified'
         L_ext=ITI2/ITI
         write(*,'(a,i3)')'INFO(2): found UC->LUC extension L=',L_ext
         ITI=ITI2
         
c___________ modify the lattice vectors
         do i=1,3
            AJ(1,i)=AJ(1,i)*(N1-M1+1)
            AJ(2,i)=AJ(2,i)*(N2-M2+1)
            AJ(3,i)=AJ(3,i)*(N3-M3+1)
         end do

c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

c_________ initialise division index
         call initial_mol_index(iMol,Mol_index,BSSE_tag)
         
c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Su].... LUC construction: complex "breeding" of atoms

      ELSE IF(cha2(l0:).eq.'Su') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ specify extention matrix

 34      write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'   
 3       write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=3) (IJ(1,j),j=1,3)
 4       write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=4) (IJ(2,j),j=1,3)
 5       write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=5) (IJ(3,j),j=1,3)
         MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) -
     -        IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) +
     +        IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         write(*,*) 'cell ==> supercell extention = ',MG_luc
         if(abs(MG_luc).lt.tiny) then
            write(*,*) 'ERROR! Zero extention!'
            write(*,*)'Press ENTER ...' ; read(*,*) ; go to 21
         end if
         if(ITI*MG_luc.gt.N0LT) then
            write(*,*)
     &        'ERROR! The breeding box is too big, see tetr_param.inc'
               write(*,*)'Press ENTER ...' ; read(*,*) ; go to 21
         end if
         ITI=ITI*MG_luc
         do k=1,3
            do k1=1,3
               AI(k,k1)=AJ(k,k1)
               BI(k,k1)=BJ(k,k1)
            end do
         end do
         do k=1,3
            AJ(1,k)=IJ(1,1)*AI(1,k)+IJ(1,2)*AI(2,k)+IJ(1,3)*AI(3,k)
            AJ(2,k)=IJ(2,1)*AI(1,k)+IJ(2,2)*AI(2,k)+IJ(2,3)*AI(3,k)
            AJ(3,k)=IJ(3,1)*AI(1,k)+IJ(3,2)*AI(2,k)+IJ(3,3)*AI(3,k)
         end do
         call INVER(AJ,BJ)

c____________ generate internal translations
         call LACE(MG_luc,iErr)
         if(iErr.eq.1) stop 'ERROR in LACE! STOP'

c____________ generate positions of all atoms in the supercell 
         j=0 ; j1=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN(k)
               j1=j1+1
               do k1=1,MG_luc
                  j=j+1
                  TI(1:3,j)=TRAN(k1,1:3)+TI1(1:3,j1)
                  relax_flag(1:3,j)=relax_flag1(1:3,j1)
               end do
            end do
            NspN(k)=NspN(k)*MG_luc
         end do

c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

c_________ initialise division index
         call initial_mol_index(iMol,Mol_index,BSSE_tag)
         
c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Rd].... UC construction from LUC: complex cell "reduction"

      ELSE IF(cha2(l0:).eq.'Rd') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ specify extention matrix

         write(*,*)
     &   'Choose 3x3 (real) extention matrix CURRENT => REDUCED cell:'   
 83      write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=83) (rIJ(1,j),j=1,3)
 84      write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=84) (rIJ(2,j),j=1,3)
 85      write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=85) (rIJ(3,j),j=1,3)
         rMG_luc=abs(rIJ(1,1)*(rIJ(2,2)*rIJ(3,3)-rIJ(3,2)*rIJ(2,3)) -
     -        rIJ(2,1)*(rIJ(1,2)*rIJ(3,3)-rIJ(3,2)*rIJ(1,3)) +
     +        rIJ(3,1)*(rIJ(1,2)*rIJ(2,3)-rIJ(1,3)*rIJ(2,2)))
         write(*,'(a,f10.5)') 'cell ==> factor rMG_luc      = ',rMG_luc
         r_luc=1./rMG_luc ;  i_luc=nint(1./rMG_luc)
         write(*,'(a,i4,a)') 
     &        'cell ==> supercell reduction = ',i_luc,' times'
         if(abs(rMG_luc).lt.tiny) then
            write(*,*)'ERROR! Zero reduction!'
            write(*,*)'Press ENTER ...' ; read(*,*) ; go to 21
         end if
         if(rMG_luc.gt.1.0) then
            write(*,*) 'ERROR! This is NOT a reduction! '
            write(*,*)'Press ENTER ...' ; read(*,*) ; go to 21
         end if
         do k=1,Nsp
            kk=NspN(k)/i_luc
            if(nint(NspN(k)/r_luc).ne.kk) then
               write(*,*) k,nint(NspN(k)/r_luc),kk
               write(*,*)
     &           'ERROR! The reduced cell CANNOT be the primitive one!'
               write(*,*)'Press ENTER ...' ; read(*,*) ; go to 21
            end if
         end do
         ITI=ITI/i_luc
         write(*,*)'NEW expected number of atoms = ', ITI
         AI=AJ ; BI=BJ
         do k=1,3
            AJ(1:3,k)=rIJ(1:3,1)*AI(1,k)+rIJ(1:3,2)*AI(2,k)+
     +                                         rIJ(1:3,3)*AI(3,k)
         end do
         call INVER(AJ,BJ)

c____________ generate positions of all atoms in the reduced cell and check
c             consistency
         j1=0 ; list1=.true. ; j=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN(k)
               j1=j1+1 

               if(list1(j1)) then
                  j=j+1 ; list1(j1)=.false. ; TI(1:3,j)=TI1(1:3,j1) 
                  relax_flag(1:3,j)=relax_flag1(1:3,j1)
                  r(1:3)=TI1(1:3,j1) ; j2=1
                  do nat=1,ITI1
                     if(list1(nat)) then
                        x(1:3)=r(1:3)-TI1(1:3,nat)
                        if(ask_equiv(x,BJ,3,toler)) then
                           write(*,'(2(a,i5),a)')
     &                  '... Atom ',j1,' is equiv. to atom ',nat,' ...'
                           j2=j2+1 ; list1(nat)=.false.
                        end if
                     end if
                  end do
                  if(j2.ne.i_luc) then
                     write(*,*)'ERROR! The reduced cell CANNOT'//
     &                                         ' be the primitive one!'
                     write(*,'(a,f10.5)')
     &                    '*** Your current tolerance = ',toler
                     write(*,'(a)')
     &               '*** Consider reducing the tolerance -> option Tl'
                     write(*,*)'Press ENTER ...' ; read(*,*) 
                     call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,
     ,                    Species,relax_flag,Genrt)
                     call restore_mol_index(iMol,Mol_index,ITI) 
                     go to 21
                  end if
               end if

            end do
            NspN(k)=NspN(k)/i_luc
            write(*,*)'NEW number of atoms in species ',k,' is ',NspN(k)
         end do

c_________ initialise division index
         call initial_mol_index(iMol,Mol_index,BSSE_tag)
         
c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Df]...... move the defect (atomic displacements) to an equivalent position,
c   e.g. this is needed for creating a final geometry of a surface for the transition
c   which is exactly equivalent to the initial one but shifted by a lattice vector of 
c   the original bulk lattice - for preparing the NEB calculation

      ELSE IF(cha2(l0:).eq.'Df') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

 14      write(*,*)
     &'Specify the lattice vector of the reference (e.g. bulk) lattice:'
         read(*,*,err=14) (Shift(i),i=1,3)
         go to 18
 16      write(*,*)'Specify reference lattice vectors:'
         do i=1,3
 17         write(*,*)'Give vector ',i,' ===> ...'
            read(*,*,err=17) AX(i,1:3)
         end do
         DET= AX(1,1)*(AX(2,2)*AX(3,3)-AX(2,3)*AX(3,2))
     *        -AX(2,1)*(AX(1,2)*AX(3,3)-AX(1,3)*AX(3,2))
     *        +AX(3,1)*(AX(1,2)*AX(2,3)-AX(1,3)*AX(2,2))
         if(abs(DET).lt.tiny) then
            write(*,*)'ERROR! The box volume is too small! Redefine!'
            go to 16
         end if
         call INVER(AX,BX)

c___________ move atoms by the Shift
 18      do k=1,ITI
            TI(1:3,k)=TI(1:3,k)-Shift(1:3)
         end do
c___________ find new numbers for the atoms so that it would appear as the 
c            cell atoms were moved
c         do k=1,ITI
         do k=1,1
            found=.false.
            write(1,'(a,i5,a,3(x,f10.5))') 
     &           'doing atom ',k,' => ',TI(1:3,k)
            do k1=1,ITI
               x(1:3)=TI(1:3,k)-TI1(1:3,k1)
               write(1,'(a,i5,2(a,3(f10.5,x)))') 
     &            ' ..against atom ',k1,' => ',TI1(1:3,k),' => ',x(1:3)
               do j=1,3
                  fr1=x(1)*BJ(j,1)+x(2)*BJ(j,2)+x(3)*BJ(j,3)
                  write(1,'(10x,2(x,f10.5))') fr1,abs(fr1-nint(fr1))
                  if( abs(fr1-nint(fr1)) .gt. 0.5 ) go to 15
               end do
               write(1,*) '==>>> atom ',k,' became atom ',k1
               TI3(1:3,k1)=TI(1:3,k) ; found=.true. ; exit
 15         end do
            if(.not.found) write(*,*)'WARNING: PROBLEM with atom ',k
         end do
         TI=TI3

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)


c[8]...... ask about ONE new lattice vector (e.g. for SLAB calculation)

      ELSE IF(cha2(l0:).eq.'8') THEN

         write(*,*)'>>>>>>>>>>>>>>>>>> IMPORTANT! <<<<<<<<<<<<<<<<<<<<<'
         write(*,*)
     &        'This step is to be the LAST ONE for creating vacuum gap.'
         write(*,*)
     &        'You will NOT be able to move atoms around after that.'
         write(*,*)'Make sure that atoms in the unit cell are in place.'

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

 79      write(*,*) 'Which vector to change (1, 2 or 3)?'
         read(*,*,err=79) iv
         if(iv.lt.1 .or. iv.gt.3) go to 79
 11      write(*,'(a,i1,a)') 
     &      'Give a new ',iv,'-'//fst_nd_rd(iv)//' lattice vector:'
         read(*,*,err=11) (AJ(iv,i),i=1,3)
         write(*,*) '... NEW lattice vectors for the supercell ...'
         write(*,'(a,3(x,f10.5))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(3):   ',(AJ(3,i),i=1,3)
         write(*,*)
     &        'Did you wish just these to generate (Y,y/other char)?'
         read(*,'(a)') answer
         if(answer.ne.'y'.and.answer.ne.'Y') go to 11
c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[9].... choose a new set of latttice vectors keeping atoms in 
c        the same Cartesian positions (e.g. for molecules)

      ELSE IF(cha2(l0:).eq.'9') THEN

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

 71      write(*,*) 'Give  new 1st lattice vector:'
         read(*,*,err=71) (AJ(1,i),i=1,3)
 72      write(*,*) 'Give  new 2nd lattice vector:'
         read(*,*,err=72) (AJ(2,i),i=1,3)
 73      write(*,*) 'Give  new 3rd lattice vector:'
         read(*,*,err=73) (AJ(3,i),i=1,3)
         write(*,*) '... NEW lattice vectors for the supercell ...'
         write(*,'(a,3(x,f10.5))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(3):   ',(AJ(3,i),i=1,3)
         write(*,*)
     &        'Did you wish just these to generate (Y,y/other char)?'
         read(*,'(a)') answer
         if(answer.ne.'y'.and.answer.ne.'Y') go to 71
c_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[10].... manually add an atom to the cell

      ELSE IF(cha2(l0:).eq.'10') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if
         if(angstr.eq.'<AtomNumber>') then
            write(*,*)
     &        'ERROR! Option <AtomNumber> is meaningless in this case'
            write(*,*)
     &           '       Change it in the menu to Angstrem/Fractional'
            write(*,*)'       Press ENTER when done ...'
            read(*,*) 
            go to 21
         end if

c___________ keep the old geometry for undo
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ now add atom

 98      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if
c___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!'
            go to 98
         end if
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii
               go to 97
            end if
         end do
         jsp=Nsp+1
         NspN(jsp)=0
         Species(jsp)=spec

 97      call givepoint(x(1),x(2),x(3),angstr)
         call add_atom(x,jsp,errr,.true.,'T','T','T',ion,listat)
         if(errr) go to 97

c___________ construct all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[B1].... divide the system into molecules (for BSSE with SIESTA)

      ELSE IF(cha2(l0:).eq.'B1') THEN

c__________ keep the current indeces for undo

         call keep_mol_index(iMol,Mol_index,ITI)

c__________ specify atoms for molecule iMol
         if(BSSE_tag) call initial_mol_index(Imol,Mol_index,BSSE_tag)
         iMol=iMol+1
         write(*,*)
     &           '<|........ Identify system part ',iMol,' ..........|>'
 45      write(*,*)
     &        'List atom numbers belonging to this part using spaces'
         write(*,*)
     &       'and/or comma, and a dash (without space) to indicate'
         write(*,*)'from/to within the same list, e.g.: 1-5,9 7-8,15 25'
         write(*,*)'..................................................'
         write(*,*)'Press ENTER to clear the whole existing partition'
         read(*,'(a)') line
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 45
         if(NumLin.eq.0) then
            call initial_mol_index(iMol,Mol_index,BSSE_tag)
            go to 21
         end if
c
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 45
            do j=i1,i2
               if(Mol_index(j).eq.0) then
                  Mol_index(j)=iMol
               else
                  write(*,'(2(a,i3),a)') 'OVERLAP: atom ',j,
     ,         ' is already in part ',iMol,' -> Skipping change ...'
               end if
            end do
         end do

c[B2].... generate BSSE or density difference script (SIESTA) 
c         or input file (QUICKSTEP)

      ELSE IF(cha2(l0:).eq.'B2' .and. BSSE_tag .and. 
     &     (Which_Code.eq.'SIESTA' .or. Which_Code.eq.'QUICKS')) then

         if(Which_Code.eq.'SIESTA') THEN
            call BSSE_script() 
         else if(Which_Code.eq.'QUICKS') THEN
            call BSSE_input_QUICKS()
         end if

c[B3].... generate BSSE or density difference script

      ELSE IF(cha2(l0:).eq.'B3' .and. BSSE_tag ) THEN
         
         call Dens_Diff_script(Which_Code) 

c[Ad].... add atoms from another file of accepted formats

      ELSE IF(cha2(l0:).eq.'Ad') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in [tetr_param.inc] file!'
            go to 21
         end if

c___________ keep the old geometry in /buffer/
         
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)
         
c___________ choose the read format and then read in the geometry
 111     call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
         if(Which_Format.eq.'  None') go to 21
         call initiate(Which_Format,seed1,l0seed1,Err)
         if(Err) go to 111

c___________ keep the newly read geometry in /buffer1/
         call keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)

c___________ restore the original geometry from /buffer/
         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ add atoms from /buffer1/ one by one to the old set
         nat=0
         do jsp3=1,Nsp3
            jsp=jsp_species(Species3(jsp3),Species,Nsp)
            if(jsp.eq.0) then
               jsp=Nsp+1 ; Species(jsp)=Species3(jsp3) ; NspN(jsp)=0
            end if
            do k=1,NspN3(jsp3)
               nat=nat+1 ; x(1:3)=TI3(1:3,nat) 
               call add_atom(x,jsp,errr,.true.,relax_flag3(1,nat),
     ,                 relax_flag3(2,nat),relax_flag3(3,nat),ion,listat)
               if(errr) then
                  write(*,*)'WARNING! Atom #',nat,' cannot be accepted.'
               else
                  listat(ion)=.true.
               end if
            end do
         end do
         if(Nsp.ne.Nsp1) then
            write(*,*)'WARNING! Number of species changed!'
            write(*,*)'         New number of species = ',Nsp
         end if

         call do_nice_list(listat,ITI,lists,length,N_lists,long_lists)
         tagYES=.true.
         
c___________ construct all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[T].... tag atoms using a multiple lists method

      ELSE IF(cha2(l0:).eq.'T') THEN

         listat(1:ITI)=.false.
         if(tagYES) then
            write(*,*)'WARNING! The tagging is disabled!'
            tagYES=.false. ; go to 21
         end if

c__________ specify wanted atoms
         call Tag(NumLin,ITI,listat,lists,length,N_lists,long_lists)
         if(NumLin.eq.0) then
            tagYES=.false. ; go to 21
         end if
         tagYES=.true.

c[TT].... tag atoms using more complex options

      ELSE IF(cha2(l0:).eq.'TT' .and. (.not.TagYes)) THEN

         call TTag(tagYES,ITI,TI,Labels,listat,lists,length,
     ,              N_lists,long_lists)

c[Rm].... remove atoms from the cell - many lists

      ELSE IF(cha2(l0:).eq.'Rm') THEN

         if(.not.tagYES) then
 37         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=37) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 37
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ remove tagged atoms
         do i=ITI1,1,-1
            if(listat(i)) call remove_atoms(i,i,.true.,.true.)
            listat(i)=.false.
         end do
         tagYES=.false.

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[KT].... remove atoms from the cell by specifying atoms
c         which are to stay

      ELSE IF(cha2(l0:).eq.'KT') THEN

         if(.not.tagYES) then
 38         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=38) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 38
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ remove untagged atoms
         do i=ITI1,1,-1
            if(.not.listat(i)) call remove_atoms(i,i,.true.,.true.)
            listat(i)=.false.
         end do
         tagYES=.false.

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Rn].... change species (i.e. rename atoms)

      ELSE IF(cha2(l0:).eq.'Rn') THEN

         if(.not.tagYES) then
 39         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=39) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 39
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c___________ (a) remove tagged atoms
c            (b) initialise listt to listat to keep the old list of tagged atoms

         do i=ITI1,1,-1
            listt(i)=listat(i)
            if(listat(i)) then
               call remove_atoms(i,i,.true.,.true.)
               listat(i)=.false.
            end if
         end do

c__________ ask the target species number
 42      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if
c___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!'
            go to 42
         end if
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii ; go to 43
            end if
         end do
         jsp=Nsp+1 ; NspN(jsp)=0 ; Species(jsp)=spec

c__________ and add removed atoms as species jsp
 43      do k=1,ITI1
            if(listt(k)) then
               x(1:3)=TI1(1:3,k)
               call add_atom(x,jsp,errr,.false.,relax_flag1(1,k),
     ,                    relax_flag1(2,k),relax_flag1(3,k),ion,listat)
            end if
            listat(k)=.false.
         end do
         tagYES=.false.

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Mv]... Move atoms to another (general) position

      ELSE IF(cha2(l0:).eq.'Mv') THEN

         FinPos=.false.
         if(.not.tagYES) then
 36         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=36) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 36
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
            if(nat1.eq.nat2) FinPos=.true.
         end if

c___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ ask about the target.

 94      call ask_displacement(angstr,dir,dmove,dd,FinPos,nat1,back)
         if(back) then
            do i=1,ITI
               if(.not.tagYES) listat(i)=.false.
            end do
            go to 21
         end if
         
c___________ move all atoms
         do i=1,ITI
            if(listat(i) .and. dd.gt.tiny) then
               TI2(1,i)=TI(1,i)+dmove/dd * dir(1)
               TI2(2,i)=TI(2,i)+dmove/dd * dir(2)
               TI2(3,i)=TI(3,i)+dmove/dd * dir(3)
            else
               TI2(1,i)=TI(1,i)
               TI2(2,i)=TI(2,i)
               TI2(3,i)=TI(3,i)
            end if
         end do

c______ check new positions
         do k=1,ITI
            if(listat(k) .and. dd.gt.tiny) then
               do k1=1,ITI
                  if(k.ne.k1) then
                     r(1)=TI2(1,k1)-TI2(1,k)
                     r(2)=TI2(2,k1)-TI2(2,k)
                     r(3)=TI2(3,k1)-TI2(3,k)
                     if(ask_equiv(r,BJ,3,tiny_equiv)) then
                        write(*,*) 'ERROR! Found equivalences!'
                        go to 94
                     end if
                  end if
               end do
            end if
         end do
         write(*,*)'O.K.! New positions are fine!' 
         do i=1,ITI
            if(listat(i)) then
               TI(1,i)=TI2(1,i)
               TI(2,i)=TI2(2,i)
               TI(3,i)=TI2(3,i)
            end if
            if(.not.tagYES) listat(i)=.false.
         end do

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Rt]... Rotate atoms about a general axis

      ELSE IF(cha2(l0:).eq.'Rt') THEN

         if(.not.tagYES) then
 32         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=32) nat1,nat2
            if(nat1.ge.nat2 .or. nat1.lt.1 .or. nat2.gt.ITI) go to 32
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1 .and. i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ specify angles and the central point
 33      call specify_angle(cntp,C_rot)

c___________ rotate atoms
         do i=1,ITI
            if(listat(i)) then
               call rotate_atom(TI(1,i),TI(2,i),TI(3,i),
     ,                TI2(1,i),TI2(2,i),TI2(3,i),cntp,C_rot)
            else
               TI2(1:3,i)=TI(1:3,i)
            end if
         end do

c______ check new positions
         do k=1,ITI
            if(listat(k)) then
               do k1=1,ITI
                  if(k.ne.k1) then
                     r(1:3)=TI2(1:3,k1)-TI2(1:3,k)
                     if(ask_equiv(r,BJ,3,tiny_equiv)) then
                        write(*,*) 'ERROR! Found equivalences!'
                        go to 33
                     end if
                  end if
               end do
            end if
         end do
         write(*,*)'O.K.! New positions are fine!' 
         do i=1,ITI
            if(listat(i)) TI(1:3,i)=TI2(1:3,i)
            if(.not.tagYES) listat(i)=.false.
         end do

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[H].... terminate specified atoms with hydrogens: 
c        predefined geometry (reference) is used to generate nearest neighbours

      ELSE IF(cha2(l0:).eq.'H') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if

         if(.not.tagYES) then
 56         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=56) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 56
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1 .and. i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

c__________ add H species first if not in the system already
         spec=' H'
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii ; go to 55
            end if
         end do
         jsp=Nsp+1 ; Species(jsp)=spec ; NspN(jsp)=0

c___________ now add terminating hydrogens
 55      do i=1,ITI1
            if(listat(i)) then
               call find_neighbours_for_M(i,xn,n_of_neighb,isp,wdth_nn)
               do in=1,n_of_neighb
                  x(1:3)=xn(1:3,in)+TI1(1:3,i)
                  if(.not.thesame(x,ITI1,TI1)) then
                     if(ITI+1.gt.N0LT) then
                        write(*,*)
     &                    'ERROR! Increase N0LT in tetr_param.inc file!'
                        call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,
     ,                                        Species,relax_flag,Genrt)
                        call restore_mol_index(iMol,Mol_index,ITI)
                        if(YES_xyz.ne.'None') call create_xyz(M11,N11,
     ,                                   M22,N22,M33,N33,YES_xyz,Add_Hs)
                        go to 21
                     end if
                     call shift_pos(x,TI1(1,i),H_at_dist,dir)
                     call add_atom(x,jsp,errr,.true.,
     &                                           'T','T','T',ion,listat)
                     if(errr) then
                        write(*,*) 'ERROR! Change distance to H in Hd!'
                        call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,
     ,                       Species,relax_flag,Genrt)
                        call restore_mol_index(iMol,Mol_index,ITI)
                        if(YES_xyz.ne.'None') call create_xyz(M11,N11,
     ,                       M22,N22,M33,N33,YES_xyz,Add_Hs)
                        go to 21
                     end if
                  end if
               end do
            end if
            listat(i)=.false.
         end do
         write(*,*)'Number of atoms in the cluster = ',ITI
         tagYES=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[U].... undo the last step: restore AJ, BJ and TI from the previous step

      ELSE IF(cha2(l0:).eq.'U') THEN

         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         call restore_mol_index(iMol,Mol_index,ITI)
         listat=.false. ; tagYES=.false.

c___________ restore geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[UU].... restore the default

      ELSE IF(cha2(l0:).eq.'UU') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         call initial_mol_index(iMol,Mol_index,BSSE_tag)
         listat=.false.
         
c___________ restore geom.xyz      
         if(YES_xyz.ne.'None') 
     &          call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN
         call show_atoms(listat)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n')
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Bb].... ask extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'Bb') THEN

c___________ ask extensions along the existing lattice vectors for the 
c            breeding box and update geom.xyz

         call ask_breeding_box(M11,N11,M22,N22,M33,N33)
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[B0].... nullify the extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'B0') THEN

         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W') THEN

c___________ constract all lattice sites  and write geom.xyz      
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S') THEN
         if(Frozen_at) sel_dyn=.true.
         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

c[ST].... save tagged atoms as a xyz file

      ELSE IF(cha2(l0:).eq.'ST' .and. TagYES) THEN
         write(*,*)'... writing geometry ...'
         open(74,file='geom_tagged.xyz')
         n_tagged=0
         do nat=1,ITI
            if(listat(nat)) n_tagged = n_tagged + 1
         end do
         write(*,*)'... there are ',n_tagged,' tagged atoms'
         write(74,'(i10/)') n_tagged
         nat=0
         do is=1,Nsp
            do j=1,NspN(is)
               nat=nat+1
               if(listat(nat)) write(74,'(a13,3(x,f10.5))') 
     &                               Species(is),(TI(k,nat),k=1,3)
            end do
         end do
         close(74)
         write(*,*)'... file geom_tagged.xyz created successfully ...'

c[Sf].... generate SIESTA code (routine constr.f) to symmetrise forces
c         during atomic relaxation - according to the present symmetry
c         [it can be useful even if the current code is not SIESTA!]

      ELSE IF(cha2(l0:).eq.'Sf') THEN

         if(ITI.gt.9999) then
            write(*,*)'WARNING: option NOT supported - too many atoms'
            write(*,*)'Press ENTER when ready ...'
            read(*,*)
            go to 21
         end if

c............ check symmetry
         call check_symmetry('n')
         if(MGp.eq.1) go to 21

c............ open the file
         write(*,*)'... generating for SIESTA constr.f file ...'
         open(93,file='for_SIESTA_constr.file',form='formatted')
         do j=1,MGp,24
            j1=j+23
            if(j1.gt.MGp) j1=MGp
            write(93,'(a,48(x,i2,2x))')'c..operations: ',(KGp(i),i=j,j1)
            write(93,'(a,14x,48(a,x))')  'c', (NAZ(KGp(i)),i=j,j1)
         end do

c_________________ working out first atoms of all orbits
         nat=0
         do is=1,Nsp
            do ii=1,NspN(is)
               nat=nat+1
               listt(nat)=.false.
               iSort(nat)=is
            end do
         end do
         iorb=0
         do nat=1,ITI
            r(1)=TI(1,nat)
            r(2)=TI(2,nat)
            r(3)=TI(3,nat)
            if(.not.listt(nat)) then
               iorb=iorb+1
               iorbit(iorb)=nat
               listt(nat)=.true.
               do Irot=1,MGp
                  call which_atom_after_rot(r,Irot,nat1,Err)
                  if(.not.listt(nat1)) listt(nat1)=.true.
               end do
            end if
         end do

c_________________ working out relations between forces on 1st atoms of orbits

         do ior=1,iorb
            nat=iorbit(ior)
            r(1)=TI(1,nat)
            r(2)=TI(2,nat)
            r(3)=TI(3,nat)
            write(93,'(2(a,i3),a)')
     &           'c=======> orbit= ',ior,', 1st atom = ',nat,' <======='

c______________________ local group
            ig=0
            do Irot=2,MGp
               call which_atom_after_rot(r,Irot,nat1,Err)
               if(nat1.eq.nat) then
                  ig=ig+1
                  local(ig)=Irot
c                  write(93,'(a,3(i2,x),a)')
c     &                  'c_loc_ ',ig,local(ig),KGp(Irot),NAZ(KGp(Irot)) 
               end if
            end do
            mlg=ig
            if(mlg.eq.0) then
               typ='E'
            else
               call analyse_loc_grp(typ,v,local,mlg,KGp,93,err,.false.)
c               call analyse_loc_grp(typ,v,local,mlg,KGp,93,err,.true.)
               if(err) then
                  close(93,status='delete')
                  go to 21
               end if
            end if

c______________________ print the local group and work out the force code
            do i=1,mlg,10
               i1=i+9
               if(i1.gt.mlg) i1=mlg
               write(93,'(a,10(a,x))')
     &                      'c...local: ',(NAZ(KGp(local(j))),j=i,i1) 
            end do
            call code_same_atom(nat,v,typ,93)
         end do

c............ do the calculation
         do nat=1,ITI
            listt(nat)=.false.
         end do
         do nat=1,ITI
            r(1)=TI(1,nat)
            r(2)=TI(2,nat)
            r(3)=TI(3,nat)
            call name_from_number(nat,ch4,l,err)
c
            if(.not.listt(nat)) then
               listt(nat)=.true.

               do Irot=1,MGp
                  call which_atom_after_rot(r,Irot,nat1,Err)
                  if(Err) stop 'ERROR in change option Sf'
                  Ir=KGp(Irot)

                  is1=iSort(nat1)
                  call name_from_number(Ir,hh4,lr,err)
                  if(.not.listt(nat1)) then
                     call name_from_number(nat1,cha4,l1,err)
                     write(93,'(3a,i5,a,i5,2a)')
     &                 'c....... force on ',Species(is1),' atom ',nat1,
     &                ' via atom ',nat,' and operation ',NAZ(Ir)
c                     write(93,*) (C(1,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)') 'c','fa(1,',cha4(l1:),')='
     &                    //'C(1,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'//
     &                      'C(1,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// 
     &                      'C(1,3,',hh4(lr:),')*fa(3,',ch4(l:),')'
c                     write(93,*) (C(2,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)')'c','fa(2,',cha4(l1:),')='
     &                    //'C(2,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'//
     &                      'C(2,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// 
     &                      'C(2,3,',hh4(lr:),')*fa(3,',ch4(l:),')'
c                     write(93,*) (C(3,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)')'c','fa(3,',cha4(l1:),')='
     &                    //'C(3,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'//
     &                      'C(3,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// 
     &                      'C(3,3,',hh4(lr:),')*fa(3,',ch4(l:),')' 

                     call cha_name(C(1,1,Ir),C(1,2,Ir),
     ,                                         C(1,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a)') 'fa(1,',cha4(l1:),')=',cc(:ll)
                     call cha_name(C(2,1,Ir),C(2,2,Ir),
     ,                                         C(2,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a)')  'fa(2,',cha4(l1:),')=',cc(:ll)
                     call cha_name(C(3,1,Ir),C(3,2,Ir),
     ,                                         C(3,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a/a)')
     &                                'fa(3,',cha4(l1:),')=',cc(:ll),'c'

                     listt(nat1)=.true.
                  end if
               end do

            end if
c
         end do
         close(93)

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN
         
         call check_symmetry('y')
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

