      subroutine point_gr()
c.....................................................................
c    Choose interactively your point group (an element by element)
c amongst all elements of the crystal class obtained from the direct
c lattice vectors, AJ
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      character answer*1,iAdopt(48)*1,Group0*3
c
c........ obtain the group GroupB of the Bravais lattice (crystal 
c         class) with MGb, KGb
c........ obtain the laggest symmorphic group GroupN of the system
c         with MGp, KGp;
c
      call check_symmetry('y','y')
c
c________ Adopt(B-list number) - shows (by '*') whether every element
c         from the GroupB has been already chosen or not (' ')
      do i=1,MGb
        iAdopt(i)=' '
      end do
c 
c.....................................................................
c........... build the group .........................................
c.....................................................................
c
      write(*,*)'.....................................................'
      write(*,*)'....... NOW WE ARE BUILDING THE LUC POINT GROUP .....'
      write(*,*)'.....................................................'
 5    write(*,*)'Choose an option:'
      write(*,*)
      write(*,*)'  1. Adopt the largest symmorphic group '//GroupN
      write(*,*)'  2. Proceed generation from '//GroupN
      write(*,*)'  3. Start generation from scratch'
      write(*,*)'  4. Stop [quit tetr]'
      write(*,*)
      write(*,*)'----------> Choose the appropriate number:'
      read (*,*,err=5) item
      if(item.eq.1) then
         return
      else if(item.eq.2) then
         if(GroupN.eq.GroupB) return
         ig=MGp
         ig1=ig
      else if(item.eq.3) then
         ig=2
         KGp(1)=1
         KGp(2)=48
         GroupN='Ci '
         ig1=ig
      else if(item.eq.4) then
         stop "I owe you nothing!"
      else
         write(*,*)'Error! try again!'
         go to 5
      end if
c
c.............. proceed with generation of the group GroupN
c
c______________ choose iAdopt(element) for all elements of groupB 
      iDo=0
 1    do 7 i=1,ig1
        do iB=1,MGb
          if(KGb(iB).eq.KGp(i)) then
            igg=ig-1
            if(iDo.eq.0) igg=ig
            if(i.gt.igg) then
              iAdopt(iB)='+'
            else
              iAdopt(iB)='*'
            end if
            go to 7
          end if
        end do
 7    continue
c
c______________ plot a tabel of elements
      write(*,*)'______ Your crystal class group is '//GroupB
      write(*,*)'       with elements:'
      write(*,'(6(a2,i2,a6,3x))') 
     &                 ( '['//iAdopt(i),i,'] '//NAZ(KGb(i)),i=1,MGb )
      write(*,*)'______ So far your system group is '//GroupN
      write(*,*)
 9    write(*,*)'Stop (S,s), a step Back (B,b), Proceed (other char)?'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read (*,'(a)',err=9) answer
      if(answer.eq.'B'.or.answer.eq.'b') then
        if(iDo.eq.0) then
          write(*,*)'Hi! Nothing undo! Ignored!'
          go to 9
        end if
        do i=ig,ig1
          do iB=1,MGb
            if(KGb(iB).eq.KGp(i)) iAdopt(iB)=' '
          end do
        end do
        GroupN=Group0
        ig=ig-1
        ig1=ig
        iDo=0
        go to 1
      else if(answer.eq.'s'.or.answer.eq.'S') then
        MGp=ig1
        return
      else
        if(GroupN.eq.GroupB) then
          write(*,*)'WARNING! There are NO additional elements!'
          go to 1
        end if
        Group0=GroupN
        ig=ig1
        go to 11
      end if  
c
c......... ask for additional elements ........................
 11   write(*,*)'Using this list of group elements, enter a new one'
      write(*,*)'by quoting its number (elements marked by * or + '
      write(*,*)'are already in your group!):'
      read(*,*,err=1) num
      if(num.lt.1.or.num.gt.MGb) then
        write(*,*)'Error! This number is out of range!'
        go to 1
      end if
      if(iAdopt(num).eq.'*'.or.iAdopt(num).eq.'+') then
        write(*,*)'This element is already in your group. Ignored!'
        go to 1
      end if
c
c_____ try to add it to the KGp-set
      iDo=1
      ig=ig+1
      KGp(ig)=KGb(num)
c
c__________ multiply all (ig) elements built so far to each 
c           other to produce a complete group with ig1 elements
c           and with C-list numbers stored in KGb
c
      call gener_prod(ig,ig1,KGp)
      call give_name(ig1,KGp,GroupN)
      go to 1
      end

      subroutine system_gr(inver_yes)
c................ ....................................................
c    BY applying all the elements of GroupB to the vectors of 
c sublattices, TI, the largest symmorphic crystal point group is 
c obtained. All group elements are stored in KGp(element), their 
c order is MGp and the name is GroupN.
c....................................................................
c inver_yes = 'y' - the inversion will be included into the system
c                   group GroupN (for the DOS) in any rate;
c inver_yes = 'n' - the inversion won't be included into GroupN
c                  (when invoked from 'change' just to test the group)
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension r(3),iSort(N0LT)
      logical iCheck(48),ask_coinc
      character inver_yes
c
c...... fill in iSort(sublattice) by atomic sorts
c
      k=0
      do i=1,Nsp
        do j=1,NspN(i)
          k=k+1
          iSort(k)=i
        end do
      end do
c
c...... set iCheck to .false. for all the elements
c
      do iGb=1,MGb
        iCheck(iGb)=.false.
      end do
c
c...... a loop over all still unadopted group elements stored in 
c   C( , ,i); it is done by cycles since elements adopted are
c   multiplied by each other to produce a group every time.
c     ig - counts adopted elements from the C-list; iCheck = .true.
c     ic - counts (for every cycle) number of adopted elements;
c   The process is continued unless ic=0.
c  
      ig=0
 10   ic=0
      do 100 jGb=1,MGb
        if(iCheck(jGb)) go to 100
        jG=KGb(jGb)
        if(jG.eq.48 .and. inver_yes.eq.'y') go to 50
c        write(13,'(a,i3,a,i3)') '........ jGb=',jgb,' jG=',jg
c
c__________ loop over all sublattices
        do j=1,ITI
          r(1)=C(1,1,jG)*TI(1,j)+C(2,1,jG)*TI(2,j)+C(3,1,jG)*TI(3,j)
          r(2)=C(1,2,jG)*TI(1,j)+C(2,2,jG)*TI(2,j)+C(3,2,jG)*TI(3,j)
          r(3)=C(1,3,jG)*TI(1,j)+C(2,3,jG)*TI(2,j)+C(3,3,jG)*TI(3,j)
          if(.not.ask_coinc(r,iSort(j),iSort,kk)) go to 100
c          if(answer.eq.'n') go to 100
        end do
c
c__________ yes, this element, jGb, should be adopted
 50     ic=ic+1
        ig=ig+1
        KGp(ig)=jG 
c
c__________ yes, multiply all (ig) elements built so far to each 
c           other to produce a complete group with ig1 elements
c           and with C-list numbers stored in KGb
c
        call gener_prod(ig,ig1,KGp)
c
c__________ set iCheck for all adopted elements
        do 60 i=1,ig1
          do j=1,MGb
            if(KGp(i).eq.KGb(j)) then
              iCheck(j)=.true.
              go to 60
            end if
          end do
 60     continue

 100  continue
c
c....... new cycle?
      if(ic.gt.0) go to 10
c
c.......... set up finally MGp and GroupN
      MGp=ig1
      call give_name(ig1,KGp,GroupN)
      return
      end

      subroutine bravais()
c....................................................................
c    BY applying all the point group elements to the direct lattice 
c vectors, AJ, the crystal class point group is obtained.
c All group elements are stored in KGb(element), their order is MGb
c and the name is GroupB.
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension r(3)
      logical iCheck(64),ask_equiv
c
c...... set iCheck to .false. for all the elments
c
      do iG=1,64
        iCheck(iG)=.false.
      end do
c
c...... a loop over all still unadopted groups elements stored in 
c   C( , ,i); it is done by cycles since elements adopted are
c   multiplied by each other to produce a group every time.
c     ig - counts adopted elements from the C-list; iCheck = .true.
c     ic - counts (for every cycle) number of adopted elements;
c   The process is continued unless ic=0.
c  
      ig=0
 10   ic=0
      do 100 jG=1,64
        if(iCheck(jG)) go to 100
c
c__________ loop over three lattice vectors 
        do j=1,3
           r(1)=C(1,1,jG)*AJ(j,1)+C(2,1,jG)*AJ(j,2)+C(3,1,jG)*AJ(j,3)
           r(2)=C(1,2,jG)*AJ(j,1)+C(2,2,jG)*AJ(j,2)+C(3,2,jG)*AJ(j,3)
           r(3)=C(1,3,jG)*AJ(j,1)+C(2,3,jG)*AJ(j,2)+C(3,3,jG)*AJ(j,3)
           if(.not.ask_equiv(r,BJ,3,tiny_equiv)) go to 100
        end do
c
c__________ yes, this element, jG, should be adopted
        ic=ic+1
        ig=ig+1
        KGb(ig)=jG 
c
c__________ yes, multiply all (ig) elements built so far to each 
c           other to produce a complete group with ig1 elements
c           and with C-list numbers stored in KGb
c
        call gener_prod(ig,ig1,KGb)
c
c__________ set iCheck for all adopted elements
        do i=1,ig1
          iCheck(KGb(i))=.true.
        end do
 100  continue
c
c....... new cycle?
      if(ic.gt.0) go to 10
c
c.......... set up finally MGb and GroupB
      MGb=ig1
      call give_name(ig1,KGb,GroupB)
      return
      end

      subroutine gener_prod(ig,ig1,KGx)
c....................................................................
c   It tries to build a point group from ig generators 
c currently available in KGx(i), i=1,..,ig , and replies with:
c ig1 - the order of the group generated by all possible products
c       of elements KGx(i).
c KGx(i), i=1,...,ig1 - for all elements including also new ones;
c....................................................................
      include 'real8.inc'
      logical iCheck(48)
      integer KGx(48)
c
c...... initialize iCheck by .true. if an element in KGp(i) is present, 
c and by .false. if not. 
c
      ig1=ig
      do j=1,48
        iCheck(j)=.true.
        if(j.gt.ig1) iCheck(j)=.false.
      end do
      ig0=ig1
c
c.......... double loop over elements with iCheck=.true.: 
c  by myltiplication, new elements are obtained increasing the 
c  range of loops, untill all elements of the group will be eghausted.
c
 10   do 100 j=1,48
        if(.not.iCheck(j)) go to 100
        do 90 j1=1,48
          if(.not.iCheck(j1)) go to 100
c___________ product of KGx(j)*KGx(j1) is jK (from the C-list)
          call Find_Rot(j,j1,jK,KGx)
c___________ check whether it is a new element
          do 20 n=1,48
            if(.not.iCheck(n)) go to 20
            if(KGx(n).eq.jK) go to 90
 20       continue
          ig1=ig1+1
          iCheck(ig1)=.true.
          KGx(ig1)=jK
 90     continue
 100  continue
c
c________ check whether it is necessary to repeat the loops
      if(ig1.gt.ig0) then
          ig0=ig1
          go to 10
      end if
      return
      end

      subroutine give_name(MGx,KGx,GroupX)
c....................................................................
c It gives:
c GroupX  - the group label to be checked with;
c..... From the input:
c KGx   - the list of generators (in terms of elements in C() );
c MGx   - the order of the generator set in KGx(i);
c....................................................................
      include 'real8.inc'
      include 'pgroup_base.inc'
      character GroupX*3
      integer KGx(48)
c......................................................................
c   Find out the name of the group which uniqely corresponds to:
c                         KGx(i), i=1, .., MGx
c   Try one family after another: 1 (for Oh) or 2 (for D6h)
c......................................................................
c
c...........Try to check all Oh groups: all elements are in NGROUP(k,iG)
c and all names are in GNAM(iG,1)
c
      do 150 iG=1,98
c________ determine the number of elements NofE in the group iG
        NofE=N_of_E(iG,1)
        if(NofE.ne.MGx) go to 150
c________ check the elements
        do 70 k=1,MGx
            do k0=1,NofE
              if(NGROUP(k0,iG).eq.KGx(k)) go to 70
            end do
            go to 150
 70     continue
c________ o.k., the group found is iG:
        GroupX=GNAM(iG,1)
        go to 200
 150  end do
c
c....... Try to check all D6h groups: all elements are in NGROU1(k,iG)
c        and all names are in GNAM(iG,2)
c
      do 100 iG=1,54
c________ determine the number of elements NofE
        NofE=N_of_E(iG,2)
        if(NofE.ne.MGx) go to 100
c______________ check the elements
        do 50 k=1,MGx
           do k0=1,NofE
              if(NGROU1(k0,iG).eq.KGx(k)) go to 50
           end do
           go to 100
 50     end do
c_______________ o.k., the group found is iG:
        GroupX=GNAM(iG,2)
        go to 200
 100  end do
 200  return
      end

      subroutine Find_Rot(I1,I2,K,KGx)
c.....................................................................
c     Seeks for the rotation K which results from the rotations I1*I2
c  (numbers I1,I2 are from the KGx list, while K is from the common 
c  C() list).
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension c1(3,3),KGx(48)
      data tiny/0.00001/

      KGi1=KGx(I1)
      KGi2=KGx(I2)
c.......... build the rotation I1*I2 --> c1
      do i=1,3
         do j=1,3
            c1(i,j)=C(i,1,KGi1)*C(1,j,KGi2)+C(i,2,KGi1)*C(2,j,KGi2)+
     +           C(i,3,KGi1)*C(3,j,KGi2)
         end do
      end do
c........... find the appropriate rotation from the C() list
      do 20 KGi=1,64
         do i=1,3
            do j=1,3
               if(abs(C(i,j,KGi)-c1(i,j)).gt.tiny) go to 20
            end do
         end do
         K=KGi
         return
 20   end do
      return
      end

      BLOCK DATA GROUP_def
      include 'real8.inc'
      parameter (r3=0.8660254,r3m=-0.8660254)
      include 'tetrag1.inc'
      include 'pgroup.inc'
      DIMENSION CCC1(3,3,32),CCC2(3,3,32)
      EQUIVALENCE ( C(1,1,1),CCC1(1,1,1) ),( C(1,1,33),CCC2(1,1,1) )
c................. Oh - rotations .............................
      DATA CCC1/1.,0.,0.,   0.,1.,0.,   0.,0.,1.,
     , 0.,1.,0., -1.,0.,0., 0.,0.,1.,   0.,0.,-1., 0.,1.,0.,   1.,0.,0.,
     , 1.,0.,0.,  0.,0.,1., 0.,-1.,0., -1.,0.,0.,  0.,-1.,0.,  0.,0.,1.,
     , 0.,-1.,0., 1.,0.,0., 0.,0.,1.,   1.,0.,0.,  0.,-1.,0., 0.,0.,-1.,
     , 1.,0.,0.,  0.,0.,-1., 0.,1.,0.,  -1.,0.,0., 0.,1.,0.,  0.,0.,-1.,
     , 0.,0.,1.,  0.,1.,0., -1.,0.,0.,  0.,0.,-1., -1.,0.,0., 0.,1.,0.,
     , 0.,1.,0.,  0.,0.,1.,  1.,0.,0.,  0.,0.,-1.,  1.,0.,0., 0.,-1.,0.,
     , 0.,-1.,0., 0.,0.,-1., 1.,0.,0.,  0.,-1.,0.,  0.,0.,1., -1.,0.,0.,
     , 0.,0.,1.,  1.,0.,0.,  0.,1.,0.,  0.,1.,0.,  0.,0.,-1., -1.,0.,0.,
     , 0.,0.,1.,  -1.,0.,0., 0.,-1.,0., 0.,1.,0.,  1.,0.,0.,  0.,0.,-1.,
     , 0.,-1.,0., -1.,0.,0., 0.,0.,-1., -1.,0.,0., 0.,0.,1.,  0.,1.,0.,
     , -1.,0.,0., 0.,0.,-1., 0.,-1.,0., 0.,0.,-1., 0.,-1.,0., -1.,0.,0.,
     ,  0.,0.,1., 0.,-1.,0., 1.,0.,0., 1.,0.,0.,  0.,1.,0.,   0.,0.,-1.,
     , -1.,0.,0., 0.,1.,0., 0.,0.,1.,  1.,0.,0.,   0.,-1.,0.,  0.,0.,1.,
     , 0.,-1.,0., 1.,0.,0., 0.,0.,-1., -1.,0.,0.,  0.,0.,-1.,  0.,1.,0.,
     , 0.,0.,1.,  0.,-1.,0., -1.,0.,0., 0.,1.,0., -1.,0.,0.,  0.,0.,-1.,
     , -1.,0.,0.,   0.,0.,1.,   0.,-1.,0./
c................. D6h - rotations .............................
      DATA CCC2/0.,0.,-1.,  0.,-1.,0.,  1.,0.,0.,
     , 0.,0.,1., -1.,0.,0., 0.,1.,0., 0.,-1.,0.,  0.,0.,1.,   1.,0.,0.,
     , 0.,1.,0., 0.,0.,1., -1.,0.,0., 0.,-1.,0.,  0.,0.,-1., -1.,0.,0.,
     , 0.,0.,1., 1.,0.,0., 0.,-1.,0., 0.,0.,-1.,  1.,0.,0.,   0.,1.,0.,
     , 0.,0.,-1., -1.,0.,0., 0.,-1.,0., 0.,1.,0., 0.,0.,-1.,  1.,0.,0.,
     , 0.,1.,0., 1.,0.,0., 0.,0.,1.,  0.,-1.,0., -1.,0.,0.,   0.,0.,1.,
     , 0.,0.,1., 0.,1.,0., 1.,0.,0.,  0.,0.,-1.,  0.,1.,0.,  -1.,0.,0.,
     , 1.,0.,0., 0.,0.,1., 0.,1.,0.,  1.,0.,0.,   0.,0.,-1., 0.,-1.,0.,
     ,-1.,0.,0., 0.,-1.,0., 0.,0.,-1., 0.5,r3,0.,r3m,0.5,0.,0.,0.,1.,
     ,-0.5, r3,0.,r3m,-0.5,0.,0.,0.,1., -0.5,r3m,0.,r3,-0.5,0.,0.,0.,1.,
     , 0.5,r3m,0.,r3,0.5,0.,0.,0., 1., -0.5,r3m,0.,r3m,0.5,0.,0.,0.,-1.,
     , 0.5,r3m,0.,r3m,-0.5,0.,0.,0.,-1., 0.5,r3,0.,r3,-0.5,0.,0.,0.,-1.,
     ,-0.5,r3,0.,r3, 0.5,0.,0.,0.,-1., -0.5,r3m,0.,r3,-0.5,0.,0.,0.,-1.,
     , 0.5,r3m,0.,r3, 0.5,0.,0.,0.,-1., 0.5,r3,0.,r3m, 0.5,0.,0.,0.,-1.,
     ,-0.5,r3,0.,r3m,-0.5,0.,0.,0.,-1., 0.5, r3,0.,r3,-0.5,0.,0.,0., 1.,
     ,-0.5,r3,0.,r3, 0.5,0.,0.,0., 1., -0.5,r3m,0.,r3m,0.5,0.,0.,0., 1.,
     , 0.5,r3m,0.,r3m,-0.5,0.,0.,0., 1./
       END

      BLOCK DATA NAZG
      include 'real8.inc'
      include 'pgroup.inc'
      INTEGER NGROP1(48,29),NGROP2(48,20),NGROP3(48,29),NGROP4(48,20)
      EQUIVALENCE(NGROUP,NGROP1),(NGROUP(1,30),NGROP2(1,1))
      EQUIVALENCE(NGROUP(1,50),NGROP3(1,1)),(NGROUP(1,79),NGROP4(1,1))
c........ point group elements are explicitly named here
      DATA NAZ/'UNIT',' C4Z',' C4Y',' C4X',' C2Z','-C4Z',
     , ' C2X','-C4X',' C2Y','-C4Y',
     ,' C3D',' C3C',' C3A',' C3B','-C3D','-C3C','-C3A','-C3B',
     ,' C22',' C21',' C26',' C25',' C23',' C24',
     ,' PXY',' PYZ',' PXZ',
     ,' S4Z',' S4X',' S4Y','S4Z3','S4X3','S4Y3',' S3A','S3A2',
     ,' S3B',' S3C',' S3D','S3B2','S3C2','S3D2','  P1','  P2',
     ,'  P3','  P4','  P5','  P6','   I',' C6z',' C3z','-C3z',
     ,'-C6z','Cxy-','Cyx-',' Cyx',' Cxy','-S3z','-S6z',' S6z',
     ,' S3z','Pxy-','Pyx-',' Pyx',' Pxy'/
c............... all group elements for the D6h family ..................
      DATA NGROU1 /1,23*0,  1,5,22*0,  1,7,22*0,  1,9,22*0,  1,53,22*0,
     * 1,54,22*0,  1,55,22*0,  1,56,22*0,  1,25,22*0,  1,26,22*0, 
     * 1,27,22*0,  1,61,22*0,  1,62,22*0,  1,63,22*0,  1,64,22*0,
     * 1,48,22*0,  1,50,51,21*0, 1,5,48,25,20*0,  1,7,48,26,20*0,
     * 1,9,48,27,20*0,  1,53,48,61,20*0,  1,54,48,62,20*0,  
     * 1,55,48,63,20*0, 1,56,48,64,20*0, 1,5,26,27,20*0, 1,5,61,63,20*0,
     * 1,5,62,64,20*0, 1,7,25,27,20*0, 1,9,25,26,20*0, 1,53,25,63,20*0,
     * 1,54,25,64,20*0, 1,55,25,61,20*0, 1,56,25,62,20*0,
     * 1,50,51,48,58,59,18*0, 1,50,51,26,61,64,18*0, 
     * 1,50,51,27,63,62,18*0, 1,50,51,57,25,60,18*0, 1,5,7,9,20*0,
     * 1,5,53,55,20*0, 1,5,54,56,20*0, 1,50,51,7,53,56,18*0,
     * 1,50,51,9,55,54,18*0, 1,7,9,5,48,26,27,25,16*0,
     * 1,5,53,55,48,25,61,63,16*0, 1,5,54,56,48,25,62,64,16*0,
     * 1,50,51,7,53,56,57,25,60,27,63,62,12*0, 1,50,51,9,55,54,57,25,60,
     * 26,61,64,12*0, 1,50,51,7,53,56,48,58,59,26,61,64,12*0, 1,50,51,9,
     * 54,55,48,58,59,27,62,63,12*0, 1,49,50,5,51,52,18*0, 1,49,50,5,51,
     *52,48,59,58,25,57,60,12*0, 1,49,50,5,51,52,26,61,64,27,63,62,12*0,
     * 1,49,50,5,51,52,9,55,54,7,53,56,12*0, 1,49,50,5,51,52,9,55,54,7,
     * 53,56,48,57,58,25,59,60,27,63,62,26,61,64/
c............... all group elements for the Oh family ....................
      DATA NGROP1 /1,47*0, 1,7,5,9,16,18,13,11,12,14,17,15,8,6,10,4,2,3,
     * 24,23,19,20,21,22,24*0, 1,7,5,9,16,18,13,11,12,14,17,15,8,6,10,4,
     * 2,3,24,23,19,20,21,22,48,26,25,27,40,39,34,38,37,36,35,41,32,31,
     * 33,29,28,30,45,44,43,42,47,46, 1,5,2,6,44*0, 1,7,9,5,2,6,19,20,
     * 40*0, 1,7,9,5,2,6,19,20,48,26,27,25,28,31,43,42,32*0, 1,5,2,6,48,
     * 25,28,31,40*0, 1,5,2,6,26,27,43,42,40*0, 1,7,5,9,3,10,23,24,40*0,
     * 1,5,7,9,3,10,24,23,48,25,26,27,30,33,45,44,32*0, 1,9,10,3,44*0,
     * 1,9,3,10,25,26,45,44,40*0, 1,9,3,10,48,27,30,33,40*0, 1,22,21,7,
     * 4,8,9,5,40*0, 1,5,9,7,4,8,22,21,48,25,27,26,29,32,46,47,32*0,
     * 1,7,4,8,44*0, 1,7,4,8,25,27,46,47,40*0, 1,7,4,8,48,26,29,32,40*0,
     * 1,5,46*0, 1,7,9,5,44*0, 1,7,5,9,16,18,13,11,12,14,17,15,36*0,
     * 1,7,5,9,16,18,13,11,12,14,17,15,48,26,25,27,40,39,34,38,37,36,35,
     * 41,24*0, 1,7,5,9,16,18,13,11,12,14,17,15,32,31,33,29,28,30,45,44,
     * 43,42,47,46,24*0, 1,7,9,5,48,26,27,25,40*0, 1,7,9,5,31,28,42,43,
     * 40*0, 1,5,9,7,32,29,47,46,40*0,1,7,5,9,33,30,45,44,40*0,1,
     * 19,20,5,44*0,1,5,20,19,48,25,42,43,40*0/
      DATA NGROP2
     & /1,19,20,5,31,28,26,27,40*0,1,5,48,25,44*0,1,
     * 5,26,27,44*0,1,
     * 5,31,28,44*0,1,5,42,43,44*0,1,7,46*0,1,21,22,7,44*0,1,
     * 21,22,7,32,29,27,25,40*0,1,7,22,21,48,26,46,47,40*0,1,
     * 7,25,27,44*0,1,7,48,26,44*0,1,7,32,29,44*0,1,7,46,47,44*0,1,
     * 9,46*0,1,23,24,9,44*0,1,23,24,9,33,30,26,25,40*0,1,
     * 9,23,24,48,27,44,45,40*0,1,9,25,26,44*0,1,9,48,27,44*0,1,
     * 9,33,30,44*0/
      DATA NGROP3
     * /1,9,44,45,44*0,1,11,15,45*0,1,
     * 11,15,19,24,22,42*0,1,11,15,24,22,19,48,38,41,45,46,43,36*0,1,
     * 11,15,48,38,41,42*0,1,11,15,43,45,46,42*0,1,12,16,45*0,1,
     * 12,16,20,22,23,42*0,1,12,16,22,23,20,48,37,40,46,44,42,36*0,1,
     * 12,16,48,37,40,42*0,1,12,16,42,46,44,42*0,1,13,17,45*0,1,
     * 13,17,20,24,21,42*0,1,13,17,24,21,20,48,34,35,45,47,42,36*0,1,
     * 13,17,48,34,35,42*0,1,13,17,42,45,47,42*0,1,14,18,45*0,1,
     * 14,18,19,21,23,42*0,1,14,18,23,19,21,48,36,39,44,43,47,36*0,1,
     * 14,18,48,36,39,42*0,1,14,18,43,47,44,42*0,1,19,46*0,1,
     * 19,25,42,44*0,1,19,48,43,44*0,1,20,46*0,1,20,25,43,44*0,1,
     * 20,48,42,44*0,1,21,46*0,1,21,26,46,44*0/
      DATA NGROP4  /1,21,48,47,44*0,1,22,46*0,1,
     * 22,26,47,44*0,1,22,48,46,44*0,1,23,46*0,1,
     * 23,27,45,44*0,1,23,48,44,44*0,1,24,46*0,1,24,27,44,44*0,1,
     * 24,48,45,44*0,1,25,46*0,1,26,46*0,1,27,46*0,1,42,46*0,1,
     * 43,46*0,1,44,46*0,1,45,46*0,1,46,46*0,1,47,46*0,1,48,46*0/
c.................. all groups names ...................................
      DATA GNAM /'C1 ','O  ','Oh ','C4 ','D4 ','D4h','C4h','C4v',
     *           'D4 ','D4h','C4 ','C4v','C4h','D4 ','D4h','C4 ',
     *           'C4v','C4h','C2 ','D2 ','T  ','Th ','Td ','D2h',
     *           'D2d','D2d','D2d','D2 ','D2h','D2d','C2h','C2v',
     *           'S4 ','C2v','C2 ','D2 ','D2d','D2h','C2v','C2h',
     *           'S4 ','C2v','C2 ','D2 ','D2d','D2h','C2v','C2h',
     *           'S4 ','C2v','C3 ','D3 ','D3d','C3i','C3v','C3 ',
     *           'D3 ','D3d','C3i','C3v','C3 ','D3 ','D3d','C3i',
     *           'C3v','C3 ','D3 ','D3d','C3i','C3v','C2 ','C2v',
     *           'C2h','C2 ','C2v','C2h','C2 ','C2v','C2h','C2 ',
     *           'C2v','C2h','C2 ','C2v','C2h','C2 ','C2v','C2h',
     *           9*'Cs ','Ci ',
     *            'C1 ','C2 ','C2 ','C2 ','C2 ','C2 ','C2 ','C2 ',
     *            'Cs ','Cs ','Cs ','Cs ','Cs ','Cs ','Cs ','Ci ',
     *            'C3 ','C2h','C2h','C2h','C2h','C2h','C2h','C2h',
     *            'C2v','C2v','C2v','C2v','C2v','C2v','C2v','C2v',
     *            'C2v','C3i','C3v','C3v','C3h','D2 ','D2 ','D2 ',
     *            'D3 ','D3 ','D2h','D2h','D2h','D3h','D3h','D3d',
     *            'D3d','C6 ','C6h','C6v','D6 ','D6h',44*'C1 '/
c.................. all group names ................................
      DATA GNAM0 /'C1 ','O  ','Oh ','T  ','Th ','Td ',
     *           'C6 ','C6h','C6v','D6 ','D6h',
     *           'C4 ','D4 ','D4h','C4h','C4v','S4 ',
     *           'C3 ','D3 ','D3d','C3i','C3v','C3h','D3h',
     *           'C2 ','D2 ','D2h','D2d','C2h','C2v'/
      END


      subroutine elem_numb()
c.................................................................
c    Fills in N_of_E(98,2) by numbers of elements for all groups
c.................................................................
      include 'real8.inc'
      include 'pgroup.inc'
c  Try one family after another: 1 (for Oh) or 2 (for D6h)
c
c......... Start from all Oh groups: all elements are in NGROUP(k,iG)
c
      do 150 iG=1,98
        N_of_E(iG,1)=48
        do k=2,48
           if(NGROUP(k,iG).eq.0) then
              N_of_E(iG,1)=k-1
              go to 150
           end if
        end do
 150  continue
c
c....... Now, all D6h groups: all elements are in NGROU1(k,iG)
c
      do 250 iG=1,54
        N_of_E(iG,2)=24
        do k=2,24
           if(NGROU1(k,iG).eq.0) then
              N_of_E(iG,2)=k-1
              go to 250
           end if
        end do
 250  continue
      return
      end
