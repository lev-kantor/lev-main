      subroutine Tag(NumLin,ITI,listat,list,len,N_lists,long_list)
c.......................................................................
c analyses the Line with NumLin words (by LinPos and LinEnd), each word
c may contain either a number or two numbers separated by a dash, and
c compiles a list for tagging, namely, it sets:
c
c    listat(atoms in the list)     = .true.
c    listat(atoms not in the list) = .false.
c    list(1:len)  - contains a nicely written list of atoms
c.......................................................................
      include 'real8.inc'
      integer LinEnd(LENG2),LinPos(LENG2)
      character (LEN=LENG1) Line
      logical listat(*)
      character(*) list

c........... initialise the listat first
      listat(1:ITI)=.false.

c............ now nicely ask

 44   write(*,*)
     &        'Specify atoms using space and/or comma to separate lists'
      write(*,*)'and a dash (without space) to indicate from/to'
      write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
      read(*,'(a)') line
      call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
      if(iErr.ne.0) go to 44
      if(NumLin.eq.0) then
         write(*,*)'WARNING! The tagging is disabled!' ; return
      end if

c............ produce the listat

      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=44) i1 ; i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=44) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=44) i2
         end if
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 44
         listat(i1:i2)=.true.
      end do

c__________ compose the nice list

      call do_nice_list(listat,ITI,list,len,N_lists,long_list)
      end

      subroutine TTag(TagYes,ITI,TI,Labels,listat,list,len,N_lists,
     ,     long_list)
c.......................................................................
c compiles a list for tagging, namely, it sets:
c
c    listat(atoms in the list)     = .true.
c    listat(atoms not in the list) = .false.
c    list(1:len)  - contains a nicely written list of atoms
c.......................................................................
c A number of options are offered in a little menu, including:
c   - by coordinates
c   - by numbers
c   - by species
c You can apply one option after another builging this way a complicated
c list.
c.......................................................................
c If asked by numbers, then it analyses the Line with NumLin words 
c (by LinPos and LinEnd), each word may contain either a number or two 
c numbers separated by a dash, and
c.......................................................................
c N_lists - the maximum allowed length of the character list (it is only 
c           used for printing in the routine calling this one)
c.......................................................................
      include 'real8.inc'
      character (LEN=LENG1) Line
      integer LinEnd(LENG2),LinPos(LENG2)
      logical listat(*),TagYes,long_list
      character(*) list
      character cha*10,chb*10,cha2*2,Labels(*)*2,ch,spec*2
      real*8 cp(3),TI(3,N0LT)
      data cp/3*0.0/,Rad/1.0/

c........... initialise the listat first
      listat(1:ITI)=.false.
      x1=-1.e10 ; x2=1.e10 ; y1=-1.e10 ; y2=1.e10 ; z1=-1.e10 
      z2= 1.e10 ; TagYes=.false.
c
c.......................................................................
c.............. menu starts here .......................................
c.......................................................................
c
 21   write(*,'(/a/)')'========= CHOOSE how to tag atoms'
      if(TagYes) then
         write(*,*) '     >> Current set of tagged atoms: '
         call do_nice_list(listat,ITI,list,len,N_lists,long_list)
         call print_long_char(list,len,long_list)
      end if
      write(*,*)
      write(*,'(2x,3a)') char(47),
     ,           '========================================',char(92)
      write(*,'(a)')' | You can execute each Produce option many |'
      write(*,'(a)')' |  times until the final list is obtained  |'
      write(*,'(2x,3a)') char(92),
     ,           '========================================',char(47)
      write(*,*)
      write(*,'(a)')'  N. Produce: by atomic numbers'
      write(*,'(a)')' Sp. Produce: by species'
      write(*,'(a)')' Si. Produce: inside the sphere'
      write(*,'(a)')' So. Produce: outside the sphere'
      write(*,'(a)')' Cr. Produce: by coordinates X,Y,Z intervals'
      write(*,'(a)')'  E. Empty the list; you can start again!'

c_____ show settings
      write(*,*) ' Co. Show atoms with current tagging'
      write(*,'(a)')
     &'-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,'(3(a,f10.5),a)')
     &        ' Cp. The central point: (',cp(1),',',cp(2),',',cp(3),')'
      write(*,'(a,f10.5)')'  R. The sphere radius: ',Rad
      call interval(x1,x2,cha,chb)
      write(*,'(a)')'  X. X-interval:         ('//cha//','//chb//')'
      call interval(y1,y2,cha,chb)
      write(*,'(a)')'  Y. Y-interval:         ('//cha//','//chb//')'
      call interval(z1,z2,cha,chb)
      write(*,'(a)')'  Z. Z-interval:         ('//cha//','//chb//')'
      write(*,'(a)')'  Q. Quit with the empty list'
      write(*,'(a)')'  P. Exit: quit with the current list'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[N]...... choose atoms by numbers

      IF(cha2(l0:).eq.'N') THEN

 44      write(*,*)
     &        'Specify atoms using space and/or comma to separate lists'
         write(*,*)'and a dash (without space) to indicate from/to'
         write(*,*)'within the same list, for example: 1-5,9, 7-8 15 25'
         read(*,'(a)') line
         call CutStrT(Line,NumLin,LinPos,LinEnd,LENG1,0,1,iErr)
         if(iErr.ne.0) go to 44
         if(NumLin.eq.0) go to 21

c________________ produce the listat
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 44
            do j=i1,i2
               listat(j)=.true.
            end do
         end do
         TagYes=.true.

c[Sp]...... choose atoms of the same species

      ELSE IF(cha2(l0:).eq.'Sp') THEN

         write(*,*) 'Choose the species [ALL atoms of this '//
     &        'species will be selected]:'
         read(*,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec=' '//cha2(l0:)
         else
            spec=cha2
         end if
         i=0
         do nat=1,ITI
            if(spec.eq.Labels(nat)) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.eq.0) then
            write(*,*)'ERROR: wrong species!'
         else
            write(*,*)'... Number of selected atoms = ',i
         end if
         if(i.gt.0) TagYes=.true.

c[Si]...... choose atoms inside the sphere

      ELSE IF(cha2(l0:).eq.'Si') THEN
         
         i=0
         do nat=1,ITI
            d=sqrt( (TI(1,nat)-Cp(1))**2 + (TI(2,nat)-Cp(2))**2 + 
     &           (TI(3,nat)-Cp(3))**2 )
            if(d.le.Rad) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

c[So]...... choose atoms outside the sphere

      ELSE IF(cha2(l0:).eq.'So') THEN
         
         i=0
         do nat=1,ITI
            d=sqrt( (TI(1,nat)-Cp(1))**2 + (TI(2,nat)-Cp(2))**2 + 
     &           (TI(3,nat)-Cp(3))**2 )
            if(d.gt.Rad) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

c[Cr]...... choose atoms by coordinates

      ELSE IF(cha2(l0:).eq.'Cr') THEN

         i=0
         do nat=1,ITI
            if((TI(1,nat).gt.x1 .and. TI(1,nat).lt.x2) .and.
     &           (TI(2,nat).gt.y1 .and. TI(2,nat).lt.y2) .and.
     &              (TI(3,nat).gt.z1 .and. TI(3,nat).lt.z2) ) then
               i=i+1
               listat(nat)=.true.
            end if
         end do
         if(i.gt.0) TagYes=.true.

c[E]...... empty the list

      ELSE IF(cha2(l0:).eq.'E') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         TagYes=.false.

c[Co]...... show atoms with tagging

      ELSE IF(cha2(l0:).eq.'Co') THEN

         write(*,*)' #  Species               Position            Tag'
         do i=1,ITI
            ch=' '
            if(listat(i)) ch='Y'
            write(*,'(i5,x,a,4x,3(f10.5,x),2x,a)') 
     &           i,Labels(i),(TI(j,i),j=1,3),ch 
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[X]...... choose X interval 

      ELSE IF(cha2(l0:).eq.'X') THEN
         
         write(*,*)
     &        'Specify the interval of atomic coordinates: A < X < B.'
 1       write(*,*)
     &  'Give the smallest (left) boundary of X (hit ENTER for -Infty):'
         call read_number_or_infty(x1,-1,iErr)
         if(iErr.ne.0) go to 1
 2       write(*,*)
     &  'Give the largest (right) boundary of X (hit ENTER for Infty):'
         call read_number_or_infty(x2,1,iErr)
         if(iErr.ne.0) go to 2

c[Y]...... choose Y interval 

      ELSE IF(cha2(l0:).eq.'Y') THEN

         write(*,*)
     &        'Specify the interval of atomic coordinates: A < Y < B.'
 3       write(*,*)
     &  'Give the smallest (left) boundary of Y (hit ENTER for -Infty):'
         call read_number_or_infty(y1,-1,iErr)
         if(iErr.ne.0) go to 3
 4       write(*,*)
     &  'Give the largest (right) boundary of Y (hit ENTER for Infty):'
         call read_number_or_infty(y2,1,iErr)
         if(iErr.ne.0) go to 4

c[Z]...... choose Z interval 

      ELSE IF(cha2(l0:).eq.'Z') THEN

         write(*,*)
     &        'Specify the interval of atomic coordinates: A < Z < B.'
 5       write(*,*)
     &  'Give the smallest (left) boundary of Z (hit ENTER for -Infty):'
         call read_number_or_infty(z1,-1,iErr)
         if(iErr.ne.0) go to 5
 6       write(*,*)
     &  'Give the largest (right) boundary of Z (hit ENTER for Infty):'
         call read_number_or_infty(z2,1,iErr)
         if(iErr.ne.0) go to 6

c[Cp]...... choose Central point

      ELSE IF(cha2(l0:).eq.'Cp') THEN

 7       write(*,*)'Specify the Central Point:'
         read(*,*,err=7) Cp
            
c[R]...... choose radius

      ELSE IF(cha2(l0:).eq.'R') THEN
         
 8       write(*,*)'Specify the radius of the sphere:'
            read(*,*,err=8) Rad

c[Q]...... quit and do nothing

      ELSE IF(cha2(l0:).eq.'Q') THEN

         do i=1,ITI
            listat(i)=.false.
         end do
         TagYes=.false.
         return

c[P]...... exit with the current list

      ELSE IF(cha2(l0:).eq.'P') THEN
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end
      
      subroutine interval(x1,x2,cha,chb)
c......................................................................
c creates interval (x1,x2) in the character form as: (cha,chb)
c......................................................................
      real*8 x1,x2
      character cha*10,chb*10
      if(x1.le.-1.0e10) then
         cha='-Infinity '
      else
         write(cha,'(f10.5)') x1
      end if
      if(x2.ge. 1.0e10) then
         chb='+Infinity '
      else
         write(chb,'(f10.5)') x2
      end if
      end

      subroutine read_number_or_infty(a,icase,iErr)
c......................................................................
c     reads a number or replaces it with:
c  icase=-1:  -infinity 
c  icase= 1:  +infinity 
c......................................................................
      include 'real8.inc'
      character Line*20

      iErr=0
      if(icase.eq.-1) then
         write(*,*) 'Enter number or I for -Infinity:'
      else if(icase.eq.1) then
         write(*,*) 'Enter number or I for Infinity:'
      end if
      read(*,'(a)') line
      i0=index(line,'I')
      if(i0.ne.0) then
         if(icase.eq.-1) a=-1.0e10
         if(icase.eq. 1) a= 1.0e10
      else
         read(line,*,err=1) a
      end if
      return
 1    iErr=1
      end

      subroutine Tag_Am(NumLin,ITI,Err,Ndim,mchange)
c.......................................................................
c choose atoms for specifying new masses
c.......................................................................
      include 'real8.inc'
      include 'atom_info.inc'
      integer LinEnd(LENG2),LinPos(LENG2)
      character (LEN=LENG1) Line
      logical Err,mchange(N0LT)

 2    write(*,'(a)')
     &     'Specify a range of atoms with a new mass. '
      write(*,'(a)')'Use dash (without space) to indicate from/to'
      write(*,'(a)')'within the same list, e.g.: 1-5,9 7-8,15 25.'
      write(*,'(a)')
     &     'Press ENTER with no atom numbers for the default values'
      read(*,'(a)') line
      call CutStrT(Line,NumLin,LinPos,LinEnd,0,1,iErr)
      if(iErr.ne.0) go to 2
      if(NumLin.eq.0) return
      Err=.false.
      do i=1,NumLin
         i0=index(line(LinPos(i):LinEnd(i)),'-')
         if(i0.eq.0) then
            read(line(LinPos(i):LinEnd(i)),*,err=2) i1
            i2=i1
         else
            read(line(LinPos(i):LinPos(i)+i0-2),*,err=2) i1
            read(line(LinPos(i)+i0:LinEnd(i)),*,err=2) i2
         end if
         if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 2
         do nt=i1,i2
            do j=1,Ndim,3
               if(atom_info(j).eq.nt) then
                  mchange(nt)=.true.
                  go to 11
               end if
            end do
            Err=.true.
            write(*,'(a,i5,a)') 'ERROR: atom ',nt,
     &           ' is fixed and thus cannot be chosen'
 11      end do
      end do
      return
      end
      
      
