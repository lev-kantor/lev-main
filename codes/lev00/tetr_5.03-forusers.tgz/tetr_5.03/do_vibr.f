      subroutine VANJA(RA,L1,I,IA,NREP,BJ)
C***********************************************************************
c  ONLY for p-like orbits I (L1=1) !!!       
c........ INPUT:
c  RA - position of the 1st atom in the orbit
c   I - orbit #
c  IA - irrep #
c........ OUTPUT:
c  NREP - # of repetiions
c  W(irrep dim,repetition,atom from the orbit,xyz-component) - 
c        - trasformation matrix for the given orbit and irrep (in common)
C***********************************************************************
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      dimension RA(3),GAMA1(15,15),BJ(3,3)
C*******************************************************************
c
c.......... get more information about the orbit RA: atomic generators,
c           local group, etc. and the # of repetitions NREP
      call repetit(RA,IA,NREP,BJ)
      if(NREP.eq.0) return
c
c........ if IA is 2- or 3-dim, find out its number in the list of all 2D and
c         3D irreps of this gfoup (to refer to irrep matrices)
c  NM2 - which 2-dim. IA is (if any)
c  NM2 - which 3-dim. IA is (if any)
      NALF=NALFA(IA)
      if(NALF.gt.1) then
        NM2=0
        NM3=0
        do IA1=1,IA
          if(NALFA(IA1).eq.2) NM2=NM2+1
          if(NALFA(IA1).eq.3) NM3=NM3+1
        end do
      end if
c
c............. compute:
c      - the GAMA matrix in GAMA1 in the left triangular form 
c        (stored temporarily);
c      - the TM matrix in W (stored in common);
      M1=2*L1+1
      NQQ=N_orb*M1
      call WORTOG(L1,I,IA,NM2,NM3,NREP,NALF,NQQ,GAMA1)
      return
      end

      subroutine repetit(RA,IA,NREP,BJ)
c.... compute # of repetitions NREP of the irrep IA in the orbit given by 
c the 1st atom at RA
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      dimension RA(3),BJ(3,3)
c
c.......... get more information about the orbit RA: atomic generators,
c           local group, etc.
      call orbita(RA,BJ)
c.......... compute the number of repertitions NREP of irrep IA in the
c           reducible one for:  p-like orbits only
      XREPR=0.
      do J=1,MGN
         KGJ=KG(KH(J))
         xg = C(1,1,KGJ)+C(2,2,KGJ)+C(3,3,KGJ)
         XREPR=XREPR+XX(IA,KH(J))*(C(1,1,KGJ)+C(2,2,KGJ)+C(3,3,KGJ))
         write(*,'(2i5,x,a,2(x,f10.5))') j,KGj, NAZ(kgj),xg,XX(IA,KH(J))
c         do i=1,3
c            write(*,'(3(f10.5,x))') (C(i,j1,kgj),j1=1,3)
c         end do
      end do
c_______ final calculation
      write(*,*) XREPR
      NREP=NINT(XREPR)
      if(NREP.eq.0) return
      NREP=NREP/MGN
      return
      end  

      subroutine WORTOG(L1,I,IA,NM2,NM3,NREP,NALF,NQQ,GAMA1)
C*******************************************************************
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      parameter (MG01=5*MG0)
      dimension Q(MG01),Q1(MG01),GAMA1(15,15),SC(14),G1(15,15)
      integer NGE(15)
      NNF=0
      do K=1,NALF
         do 23 M=1,M1
            call MATRW(L1,IA,1,K,M,NM2,NM3,Q,NALF)
            do NQ=1,NQQ
               if(ABS(Q(NQ)).gt.0.00001) go to 2
            end do
            go to 23
 2          NGE(NNF+1)=NQ 
            NE=NQ ; NQ=0
            do NA=1,N_orb
               do MJU=1,M1
                  NQ=NQ+1 ; W(1,NNF+1,NA,MJU)=Q(NQ)
               end do
            end do
            if(NNF.eq.0) go to 14
            do 13 NSTEP=1,NNF
               if(NGE(NSTEP).ne.NE) go to 13
               NQ=0
               do NA=1,N_orb
                  do MJU=1,M1
                     NQ=NQ+1 ; Q1(NQ)=W(2,NSTEP,NA,MJU)
                  end do
               end do
               A=Q1(NE) ; B=Q(NE)
               do J=NE,NQQ
                  Q(J)=Q1(J)-Q(J)*A/B
               end do
               do J=NE,NQQ
                  if(abs(Q(J)).gt.0.00001) go to 7
               end do
               go to 23
 7             NGE(NNF+1)=J
               NE=J
               if(NSTEP.eq.1) go to 13
               NSTEP1=NSTEP-1
               do 12 J=1,NSTEP1
                  if(NGE(J).ne.NE) go to 12
                  NQ=0
                  do NA=1,N_orb
                     do MJU=1,M1
                        NQ=NQ+1 ; Q1(NQ)=W(2,J,NA,MJU)
                     end do
                  end do
                  A=Q1(NE) ; B=Q(NE)
                  do J1=NE,NQQ
                     Q(J1)=Q1(J1)-Q(J1)*A/B
                  end do
                  do J1=NE,NQQ
                     if(abs(Q(J1)).gt.0.00001) go to 11
                  end do
                  go to 23
 11               NGE(NNF+1)=J1
                  NE=J1
 12            end do
 13         end do
 14         NNF=NNF+1
            PVTRKM(NNF,1,I,IA)=K
            PVTRKM(NNF,2,I,IA)=M
c     
            A1=SCALR(NNF,NNF)
            A2=0.0
            if(NNF.eq.1) go to 16
            NNF1=NNF-1
            do NNF2=1,NNF1
               SC(NNF2)=SCALR(NNF2,NNF)
               A2=A2+SC(NNF2)*SC(NNF2)
            end do
 16         GAMA1(NNF,NNF)=1./SQRT(A1-A2)
            GNFNF=GAMA1(NNF,NNF)
            if(NNF.eq.1) go to 18
C     
            do NNF2=1,NNF1
               GAMA1(NNF,NNF2)=-GNFNF*SC(NNF2)
            end do
C     
 18         do NA=1,N_orb
               do MJU=1,M1
                  W(1,NNF,NA,MJU)=GNFNF*W(1,NNF,NA,MJU)
               end do
            end do
            if(NNF.eq.1) go to 21
            do 200 NNF2=1,NNF1
               GNFNF2=GAMA1(NNF,NNF2)
               if(abs(GNFNF2).le.1.E-05) go to 200
               do  NA=1,N_orb
                  do MJU=1,M1
                     W(1,NNF,NA,MJU)=W(1,NNF,NA,MJU)+
     +                                        GNFNF2*W(1,NNF2,NA,MJU)
                  end do
               end do
 200        end do
 21         if(NNF.eq.NREP) go to 24
            NQ=0
            do NA=1,N_orb
               do MJU=1,M1
                  NQ=NQ+1
                  W(2,NNF,NA,MJU)=Q(NQ)
               end do
            end do
 23      end do
      end do
 24   if(NALF.eq.1) go to 28
c     
      do NNF=1,NREP
         GNFNF=GAMA1(NNF,NNF)
         NNF1=NNF-1
         do 27 J=2,NALF
            iii=PVTRKM(NNF,1,I,IA)
            jjj=PVTRKM(NNF,2,I,IA)
            call MATRW(L1,IA,J,iii,jjj,NM2,NM3,Q,NALF)
            NQ=0
            do NA=1,N_orb
               do MJU=1,M1
                  NQ=NQ+1
                  W(J,NNF,NA,MJU)=GNFNF*Q(NQ)
               end do
            end do
            if(NNF.eq.1) go to 27
            do 260 NNF2=1,NNF1
               GNFNF2=GAMA1(NNF,NNF2)
               if(abs(GNFNF2).le.1.E-05) go to 260
               do NA=1,N_orb
                  do MJU=1,M1
                     W(J,NNF,NA,MJU)=W(J,NNF,NA,MJU)+
     +                                        GNFNF2*W(J,NNF2,NA,MJU)
                  end do
               end do
 260        end do
 27      end do
      end do
C     
 28   do 30 NNF=1,NREP
         GAMA1(NNF,NNF)=1./GAMA1(NNF,NNF)
         if(NNF.eq.1) go to 30
         NNF1=NNF-1
         do NNF2=1,NNF1
            GAMA1(NNF,NNF2)=-GAMA1(NNF,NNF2)*GAMA1(NNF,NNF)
            GAMA1(NNF2,NNF)=0.0
         end do
 30   end do
      call MINV(GAMA1,NREP,G1,15)
      do INN=1,NREP
         do INN1=1,NREP
            GAMA1(INN,INN1)=G1(INN,INN1)
         end do
      end do
      return
      end
      
      function SCALR(NNF1,NNF2)
      include 'real8.inc'
      include 'symgenv.inc'
      SCALR=0.0
      do NA=1,N_orb
         do MJU=1,M1
            SCALR=SCALR+W(1,NNF1,NA,MJU)*W(1,NNF2,NA,MJU)
         end do
      end do
      return
      end

      subroutine MATRW(L1,I,J,K,M,NM2,NM3,Q,NALF)
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      parameter (MG01=5*MG0)
      dimension Q(MG01),NI(3)
      data NI/2,3,1/
      if(NALF-2) 12,16,20
   12 NQ=0
      do NA=1,N_orb
         KJNA=KJ(NA)
         do MJU=1,M1
            NQ=NQ+1
            Q(NQ)=0.0
            do J1=1,3
               S=0.0
               do NELG=1,MGN
                  S=S+XX(I,KH(NELG))*C(NI(J1),NI(M),KG(KH(NELG)))
               end do
               Q(NQ)=Q(NQ)+C(NI(MJU),NI(J1),KG(KJNA))*S
            end do
            Q(NQ)=Q(NQ)*XX(I,KJNA)
         end do
      end do
      return
 16   NQ=0
      do NA=1,N_orb
         KJNA=KJ(NA)
         do MJU=1,M1
            NQ=NQ+1
            Q(NQ)=0.0
            do I1=1,2
               S1=0.0
               do J1=1,3
                  S=0.0
                  do NELG=1,MGN
                     KGHN=KG(KH(NELG))
                     S=S+D2ALFA(I1,K,KH(NELG),NM2)*C(NI(J1),NI(M),KGHN)
                  end do
                  S1=S1+C(NI(MJU),NI(J1),KG(KJNA))*S
               end do
               Q(NQ)=Q(NQ)+D2ALFA(J,I1,KJNA,NM2)*S1
            end do
         end do
      end do
      return
   20 NQ=0
      do NA=1,N_orb
         KJNA=KJ(NA)
         do MJU=1,M1
            NQ=NQ+1
            Q(NQ)=0.0
            do I1=1,3
               S1=0.0
               do J1=1,3
                  S=0.0
                  do NELG=1,MGN
                     KGHN=KG(KH(NELG))
                     S=S+D3ALFA(I1,K,KH(NELG),NM3)*C(NI(J1),NI(M),KGHN)
                  end do
                  S1=S1+C(NI(MJU),NI(J1),KG(KJNA))*S
               end do
               Q(NQ)=Q(NQ)+D3ALFA(J,I1,KJNA,NM3)*S1
            end do
         end do
      end do
      end

      subroutine MINV(A,N,B,NMAX)
c..............................................................
c  Calculation of inverse of left triangular matrix A
c  B - the resulting inverse of matrix A (is left triangular)
c  N    - actual dimension of A
c  NMAX - max. dimension of A
c..............................................................
      include 'real8.inc'
      dimension A(NMAX,NMAX),B(NMAX,NMAX)
c........... Loop throught columns
      do J=1,N-1
         B(J,J)=1.0/A(J,J)
c........... Loop throught rows J+L
         do L=1,N-J
            S=0.0
            do K=J,J+L-1
               S=S+A(J+L,K)*B(K,J)
            end do
            B(J+L,J)=-S/A(J+L,J+L)
         end do
      end do
      B(N,N)=1.0/A(N,N)
      return
      end
