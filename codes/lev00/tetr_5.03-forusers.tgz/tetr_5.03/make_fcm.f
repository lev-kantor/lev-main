      subroutine make_fcm(Which_Code)
c...............................................................
c The force constant matrix is constructed out of all components
c due to every irrep. Then atomic masses can be changed and the
c new frequencies obtained (e.g. isotopic shifts). 
c
c    Similarly, one can estimate the vibrational frequencies if
c chemically similar species are used, e.g. Ge instead of Si, so 
c that the same FCM is used with different masses.
c...............................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'working.inc'
      include 'symgenv.inc'      
      include 'matrix.inc'      
      include 'systema.inc'      
      include 'atom_info.inc'
      include 'lists.inc'
      character (LEN=200) Line
      integer LinEnd(100),LinPos(100),IRA_left(N0IR)
      logical Add_Hs,Err,Yes_solved,Yes_fixed,Diff_Order_of_Atoms
      logical mchange(N0LT),yes_chosen,proj_at(N0LT)
      character I_of_w_aver*9
      logical ChargeS,listat(N0LT),Changed_Mass,IR_normalise
      character Yes_xyz*4,cha2*2,cha1,name*50
      character title_pl(9)*9,Title*50,cha5*5,cha4*4
      dimension Freq(K0DM0),Atom_Mass(N0LT),RR(MG0,3),RA(3)
      dimension Freq_ru(K0DM0),Freq_ll(K0DM0)
      dimension sigma(9),Direct(3),Pol_E(3)
      dimension Q(3,3,N0LT),chrg(3,3)
      integer Num_proj_atom(8),j_proj_atom(8)
      double precision :: I_of_w,Pref(K0DM0)
      common /buffer0/ A0(3,3),TI0(3,N0LT),B0(3,3),ITI0,
     ,     NspN0(N0KD),Nsp0,Species0(N0KD),relax_flag0(3,N0LT)
      character Species0*2,relax_flag0,cch*72,Which_Code*6
      double precision, parameter :: K_B=8.617343e-5       ! in eV/K
      double precision, parameter :: H_bar=4.13566733e-15  ! in eV*sec
      data tiny/0.00001/,Add_Hs/.false./,Yes_xyz/'Xmol'/
      data ampl/0.05/,Temp/300.0/
      data Direct/0.0,0.0,-1.0/,Pol_E/1.0,0.0,0.0/
      data I_of_w_aver/'  no_aver'/,zangle/0.0/
      data step/0.1/,Up_lim/0.0/,N_disp/1/,ibound/10/
      data sigma/10.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,90.0/
      
c
c........... keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
c
c............. read the info from mol_vibr()
c 
      open(23,file='vibr_info.dat',form='formatted',status='old',err=5)
      read(23,'(2(i5,x),a8)',err=5,end=5) NEPR,Nsp,system
      if(system.eq.' K-POINT') return
      read(23,'(a3,20(x,a3))',err=5,end=5) GroupN,(NAZVIR(IA),IA=1,NEPR)
      read(23,'(20(a2,x))',err=5,end=5)  (Species(is),is=1,Nsp)
      read(23,*,err=5,end=5) (IRA_left(IA),IA=1,NEPR)
      read(23,*,err=5,end=5) (NALFA(IA),IA=1,NEPR)
      read(23,*,err=5,end=5) NORB,MG,(KG(i),i=1,MG)
      read(23,*,err=5,end=5) (KAN(io),(R1(io,j),j=1,3),io=1,NORB)
      read(23,*,err=5,end=5) (ISORT1(io),io=1,NORB)
      read(23,*,err=5,end=5) 
     &     ((orb_to_old(io,nat),nat=1,KAN(io)),io=1,NORB)
      read(23,'(20(l1,x))',err=5,end=5) (Fix(io),io=1,NORB),Yes_Fixed
      read(23,'(5(f10.5,x))',err=5,end=5) ((TRAN(N,j),j=1,3),N=1,MG)
      if(system.eq.'LATT-TRA') then
         read(23,*,err=5,end=5) AI,BI,AJ,BJ,IJ
         read(23,*,err=5,end=5)  ITI,((TI(j,n),j=1,3),n=1,ITI)
         read(23,*,err=5,end=5)  (NspN(i),i=1,Nsp)
         read(23,*,err=5,end=5) ((Vkp(k,j),j=1,3),k=1,MG)
         read(23,*,err=5,end=5) ((Vk_rep(IA,j),j=1,3),IA=1,NEPR)
      end if
      close (23)
      go to 7
 5    write(*,*)'FATAL! File [vibr_info.dat] is bad or absent!'
      return

c
c............. check if atoms are in different order
c
 7    Diff_Order_of_Atoms=.false.
      nt=0
      do io=1,NORB
         do iN=1,KAN(io)
            nt=nt+1
            if(nt.ne.orb_to_old(io,iN)) Diff_Order_of_Atoms=.true.
         end do
      end do
c
c.............. collect necessary info
c               Ndim - total dimension  of the problem
c                  j - counts degrees of freedom
      j=0
      nat=0
      do io=1,NORB
         if( .not.Fix(io) ) then
            do iN=1,KAN(io)
               do k=1,3
                  j=j+1
                  atom_info(j)=iN+nat
                  xyz_info(j)=k
                  species_info(j)=ISORT1(io)
                  mchange(iN+nat)=.false.
                  old_atom_from_vibr(j)=orb_to_old(io,iN)
               end do
            end do
         end if
         nat=nat+KAN(io)
      end do
      Ndim=j
      write(*,*)'Total atomic dimension found = ',Ndim
c
c............... set default masses on atoms
c
      call mass_default(Atom_Mass)
c
c............... construct the Force Constant Matrix ...............
c............... in Cartesian representation  (G_mat)  .............
c     
      call do_F_mat_files(IRA_left,NEPR,N0IR,Err)
      if(Err) return
c
c.......... calculate force constant matrices using right-upper, left-lower 
c           and average method of symmetrisation of the FCM
c
      call build_fcm(Ndim,IRA_left,Err,'right-u',Which_Code)
      call calculate_freq(Ndim,Freq_ru,Atom_Mass,prod_freq_log)
      if(Err) then
         write(*,*)'ERROR when constructing force constant matrix (RU)'
         return
      end if
      call build_fcm(Ndim,IRA_left,Err,'left-lw',Which_Code)
      call calculate_freq(Ndim,Freq_ll,Atom_Mass,prod_freq_log)
      if(Err) then
         write(*,*)'ERROR when constructing force constant matrix (LL)'
         return
      end if
      call build_fcm(Ndim,IRA_left,Err,'average',Which_Code)
      call calculate_freq(Ndim,Freq,Atom_Mass,prod_freq_log)
      if(Err) then
         write(*,*)'ERROR when constructing force constant matrix (AV)'
         return
      end if
      Yes_solved=.true.
      E_L=0.0
      E_R=max(Freq(Ndim),Freq_ru(Ndim),Freq_ll(Ndim))+3*sigma(1)
c
c..................................................................
c..................... Main menu starts here ......................
c..................................................................
c
      Changed_Mass=.false. ; Yes_chosen=.false. ; ChargeS=.false.
      IR_normalise=.false. 
      Temp1=10.0; Temp2=500.0 ; Ntp=10 ; stepT=(Temp2-Temp1)/Ntp

 21   write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      if(Diff_Order_of_Atoms) 
     &   write(*,'(a)') ' ++++ IMPORTANT: order of atoms CHANGED! ++++'
      if(system.eq.'MOLECULE') then
         write(*,'(2a)')' MOLECULE: lattice translations IGNORED' 
      else      
         write(*,'(2a)')' SUPERCELL: lattice translations USED'
         write(*,*)'... CURRENT lattice vectors for the supercell:...'
         write(*,'(a,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      end if
      write(*,'(a)')
      write(*,*)'========= CHOOSE an OPTION:'
      write(*,'(a)')


      write(*,'(a)') ' Am. Change atomic masses for a range of atoms'


c________ action

      write(*,'(a)')
     &'------ A c t i o n s  w i t h  v i b r a t i o n s  ----------'
      if(Yes_solved) then
         write(*,'(a)') ' Ei. Solve the eigenvalue problem <= Done!'
         write(*,'(5x,a,e16.10)') 
     &     'Nat. logarithm of product of frequencies = ',prod_freq_log 
         write(*,'(a)') ' Sv. Show eigenvalues/vectors'
         write(*,'(a)') ' Sa. Show frequencies and normal modes'
         write(*,'(a)') ' Vs. Write xyz movie file for a mode'
      else
         write(*,'(a)') ' Ei. Solve the eigenvalue problem'
      end if
      
c_______ Free energy

      write(*,'(a)')
     &'----------------------- F r e e   e n e r g y ----------------'
      if(Yes_solved) 
     &     write(*,'(a)') ' Fr. Show the free energy (eV)'
      write(*,'(a,i10)')
     &     ' Np. [Free energy]: Number of temperature points: ',Ntp
      write(*,'(2(a,f10.5),a)')
     &' Tr. [Free energy]: Temperature range: [',Temp1,' - ',Temp2,']'
      stepT=(Temp2-Temp1)/Ntp
      write(*,'(a,f10.5,a)') 
     &     '                    Temperature step = ',stepT,' K'
      
c_______ DOS options

      write(*,'(a)')
     &'------------------------ p h o n o n   D O S -----------------'
      if(Yes_solved) then
         write(*,'(a)') 
     &        ' D1. Calculate the phonon DOS: different dispersions'
         if(Yes_chosen) write(*,'(a)') 
     &        ' D2. Calculate the phonon DOS: projected on atoms'
         write(*,*)'     Dispersion to be used = ',sigma(1)
      end if
      if(.not.Yes_chosen) then
         write(*,'(a)')' pD. Choose atoms for projected phonon DOS'
      else
         write(*,'(a)')
     &        ' pD. Choosen atoms for projected phonon DOS:'
         write(*,'(10x,9(i3,x))') (Num_proj_atom(k),k=1,Np_atoms)
c         write(*,'(10x,9(i3,a,i3,a,x))') 
c     &     (Num_proj_atom(k),'{=',j_proj_atom(k),'}',k=1,Np_atoms)
      end if

c________ IR intensity option

      write(*,'(a)')
     &'---------------------- IR  i n t e n s i t y -----------------'
      write(*,'(a,f10.5)')'  T. For I(w): Temperature (K): ',Temp
      if(I_of_w_aver.eq.'  no_aver') then
         write(*,'(a)')   
     &     ' Av. For I(w): particular polarisation direction'
         write(*,'(a)')   '  D. For I(w): direction of E in E/M wave:'
         write(*,'(15x,3(f10.5,x))') (Pol_E(i),i=1,3)
      else if(I_of_w_aver.eq.' pol_aver') then
         write(*,'(a)')   
     &' Av. For I(w): aver. polarisations: given propagation direction'
         write(*,'(a)')   '  D. For I(w): direction of the wave:'
         write(*,'(15x,3(f10.5,x))') (Direct(i),i=1,3)
      else if(I_of_w_aver.eq.'zpol_aver') then
         write(*,'(a)')   
     &' Av. For I(w): aver. polarisations: given angle with Z axis'
         write(*,'(a,f10.5)')
     &        '  D. For I(w): propagation direction angle: ',zangle
      else if(I_of_w_aver.eq.'full_aver') then
         write(*,'(a)')' Av. For I(w): full average over ALL directions'
      end if
      if(ChargeS) then
         write(*,'(a)') ' Bc. For I(w): Born charges on atoms: KNOWN'
         write(*,'(a)') 
     &        ' CM. For I(w): modify Born charges on a set of atoms'
         write(*,'(a)') ' Pf. For I(w): show prefactors'
         if(Yes_solved)
     &     write(*,'(a)')   ' Iw. Calculate the IR intensity curve I(w)'
      else
         write(*,'(a)')' Bc. For I(w): Born charges on atoms: NOT KNOWN'
      end if      
         
c_____ show if the FCM is good enough (error analysis)

      if(.not.Changed_Mass) then
         write(*,'(a)')
     &  '------ C h e c k i n g   p r e c i s i o n  o f  F C M -------'
         write(*,'(a)')' Pr. Compare DOS using three FCMs'
      end if

c_____ show info

      write(*,'(a)')
     &'-------------- G e n e r a l  I n f o r m a t i o n ----------'
      write(*,'(a)')' Co. Show information about atoms'
      if(ChargeS) write(*,'(a)')' SB. Show Born charges'
      write(*,'(a)')' Sy. Show the point symmetry group info'

c________ settings for graphics

      write(*,'(a)')
     &'------------- S e t t i n g s:  D O S  a n d  I(w) -----------'
      write(*,'(a,i1)')' Nd. Number of dispersions/broadenings: ',N_disp
      if(N_disp.eq.1) then
         write(*,'(a,f10.5)')
     &        ' Sg. Dispersion for DOS/I(w) (cm^-1): ',sigma(1)
      else
         write(*,'(a)') ' Sg. Dispersions for DOS/I(w) (cm^-1): '
         write(*,'(10x,9(f10.5,x))') (sigma(i),i=1,N_disp)
      end if
      sigmam=0.0
      do i=1,N_disp
         if(sigma(i).gt.sigmam) sigmam=sigma(i)
      end do

      write(*,'(a,f10.5)')' St. Step for DOS/I(w) (cm^-1): ',step
      if(IR_normalise) then
         write(*,'(a,f10.5)')' NI. Normalise the IR spectrum: YES'
      else
         write(*,'(a,f10.5)')' NI. Normalise the IR spectrum: NO'
      end if
      if(Up_lim.ne.0.0) then
         write(*,'(a,f10.5)')' Up. Upper limit for DOS/I(w): ',Up_lim
      else
         write(*,'(a,f10.5)')' Up. Upper limit for DOS/I(w): not set'
      end if
      write(*,'(2(a,f10.5),a)')
     &     ' EB. Energy interval for DOS:  [',E_L,',',E_R,']'
      write(*,'(2(a,f10.5),a)')
     &     '     Energy interval for I(w): [',E_L,',',2*E_R,']'

c___________ general settings

      write(*,'(a)')
     &'---------------- G e n e r a l  S e t t i n g s --------------'
c      write(*,'(a)')
c     &   ' XY. Format of <geom.xyz> file is for '//YES_xyz
      write(*,'(a)')
     &   '  W. Write <geom.xyz> file to preview the current geometry'
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,'(a)')
     &           ' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,'(a)')
     &           ' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      write(*,'(a,f10.5)')' Da. Distortion amplitude for movies: ',ampl 
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)
c
c[Am]............. atomic masses
c
      IF(cha2(l0:).eq.'Am') THEN
         
         call Tag_Am(NumLin,ITI,Err,Ndim,mchange)
         if(NumLin.eq.0) then
            call mass_default(Atom_Mass)
            write(*,*)'WARNING! Default masses are set!'
            Changed_Mass=.false.
            go to 14
         end if
         if(Err) go to 12

 3       write(*,*)'Give the new mass for these atoms (a.u.m.):'
         read(*,*,err=3) amass
         nat=0
         do io=1,NORB
            do iN=1,KAN(io)
               nat=nat+1
               if(mchange(nat)) Atom_Mass(nat)=amass
            end do
         end do
         Changed_Mass=.true.
 14      Yes_solved=.false.
         Yes_chosen=.false.
 12      do j=1,ITI
            mchange(j)=.false.
         end do

c[Ei]...... solve the eigenvalue problem

      ELSE IF(cha2(l0:).eq.'Ei') THEN

c____________ calculate the dynamical matrix with given masses at atoms
c              and diagonalise it; then calculate eigenvlues

         call calculate_freq(Ndim,Freq,Atom_Mass,prod_freq_log)
         Yes_solved=.true.

c[Sv]...... show eigenvalues/vectors prior to W_all multiplication
c           (i.e. mixing of generalised displacements)

      ELSE IF(cha2(l0:).eq.'Sv' .and. Yes_solved) THEN

         write(*,*)'>>>>>>>> RESULT of diagonalisation: <<<<<<<<<<<'
         call print_eigenproblem(EigR,EigV,Ndim,K0DM0,6)
         open(37,file='EIGEN_all.res',status='unknown')
         call print_eigenproblem(EigR,EigV,Ndim,K0DM0,37)
         close (37)
         write(*,'(/a)')
     &      '*******************************************************'
         write(*,'(a)')
     &     '   Full table can also be seen in the file EIGEN_all.res'
         write(*,'(a/)')
     &      '*******************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sa]...... show frequencies (in cm^-1) and normal modes; 
c       if a frequency is imaginary (EigR < 0), it is set to -1

      ELSE IF(cha2(l0:).eq.'Sa' .and. Yes_solved ) THEN

         call show_normal_coord(Ndim,Freq,Species,6)
         open(37,file='N_MODES_all.res',status='unknown')
         call show_normal_coord(Ndim,Freq,Species,37)
         close (37)
         write(*,'(/a)')
     &    '**********************************************************'
         write(*,'(a)')
     &    '   Full table can also be seen in the file N_MODES_all.res'
         write(*,'(a/)')
     &    '**********************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Fr]...... show the quasiharmonic free energy from all frequencies

      ELSE IF(cha2(l0:).eq.'Fr' .and. Yes_solved) THEN

         open(72,file='free.en', form='formatted')
         write(*,'(a)') '... Writing free energy into [free.en]'
         write(72,*)'#.... T(K) ... Zero en.(eV) ... Free en.(eV) ...'
         write(*,*) '#.... T(K) ... Zero en.(eV) ... Free en.(eV) ...'
         do k=1,Ndim
            if(EigR(k).ge.0.0d0) then
               omega=sqrt( EigR(k)*.9648667e+28 ) 
               freq1=omega*53.08837459E-13
               if(freq1.gt.0.01) then
                  write(*,*)'# freq = ',freq1,' cm^-1'
                  write(72,*)'# freq = ',freq1,' cm^-1'
               end if
            end if
         end do

         do i=1,Ntp+1
            Temp=Temp1+(i-1)*stepT ; fren=0.0d0 ; zero=0.0d0

            do k=1,Ndim
               if(EigR(k).ge.0.0d0) then
                  omega=sqrt(EigR(k)*.9648667e+28 ) ; en = H_bar*omega
                  freq1=omega*53.08837459E-13
                  if(freq1.gt.0.01) then
                     ex=exp(-en/(K_B*Temp))  ; zero=zero + en/2. 
                     fren=fren + K_B*Temp*log(1.0d0-ex)
                  end if
               end if
            end do

            write(72,'(5x,f10.5,2(5x,e16.10))') Temp, zero, fren + zero
            write(*,'(5x,f10.5,2(5x,e16.10))') Temp, zero, fren + zero
         
         end do
         close(72)
         write(*,'(a/)')
     &      '*******************************************************'
         write(*,'(a)')'   Free energy vs. T is written into [free.en]'
         write(*,'(a/)')
     &      '*******************************************************'
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Np]...... number of points of T for the free energy

      ELSE IF(cha2(l0:).eq.'Np') THEN

 34      write(*,*)'Specify the number of T points for the free energy:'
         read(*,*,err=34) Ntp
         if(Ntp.lt.1) go to 34

c[Tr]...... Temperature range for the free energy

      ELSE IF(cha2(l0:).eq.'Tr') THEN

 35      write(*,*)'Specify the min and max temperatures (in K):'
         read(*,*,err=35) Temp1, Temp2
         if(Temp1.lt.1.0 .or. Temp2. lt. 1.0 
     &                       .or. Temp1.gt.Temp2) go to 35

c[Vs]...... create a xyz-movie for a normal mode

      ELSE IF(cha2(l0:).eq.'Vs' .and. Yes_solved) THEN

         if(Ndim.gt.1) then
 16          write(*,'(a,i3)')
     &        'Specify a normal mode vector between 1 and ',Ndim
            read(*,*,err=16) iV
            if(iV.lt.1 .or. iV.gt.Ndim) go to 16
         else
            iV=1
         end if         
         open(37,file='geom.xyz',form='formatted')
         do iang=0,360,10
            amp=2*ampl*sin(iang*pi/180.0)
            call distorted_xyz_all(Ndim,iV,amp,Species,ITI,
     ,                                          37,YES_xyz,Add_Hs)
         end do
         close (37)

c[Pr]...... display the DOS using upper-right, left-lower and average FCMs

      ELSE IF(cha2(l0:).eq.'Pr' .and. (.not.Changed_Mass) ) THEN

         if(N_disp.gt.1) then
            write(*,*)'WARNING: the first dispersion will only be used'
            write(*,*)'       Disp = ',sigma(1)
            write(*,*)'Press ENTER when ready ...'
            read(*,*)
         end if
         open(31,file='dos_err.dat',form='formatted',status='unknown')
         ww=0.0
         do while (ww.lt.Freq(Ndim)+3*sigma(1)) 
            ww=ww+step
            write(31,'(10(f10.5,x))') ww,dos(ww,Ndim,Freq,sigma(1)),
     ,       dos(ww,Ndim,Freq_ru,sigma(1)),dos(ww,Ndim,Freq_ll,sigma(1))
         end do
         close (31)

         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title 
         title_pl(1)= ' average '
         title_pl(2)= 'right-upp'
         title_pl(3)= 'left-lowe'
         call Plot(3,'dos_err.dat ',11,
     ,            Title,title_pl,E_L,E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'DOS (arb.units)     ', 'Screen', 31,Up_lim)
         call Plot(3,'dos_err.dat ',11,
     ,            Title,title_pl,E_L,E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'DOS (arb.units)     ', 'Postsc', 31,Up_lim)


c[D1]...... calculate DOS for a set of dispersions

      ELSE IF(cha2(l0:).eq.'D1' .and. Yes_solved) THEN
         
         open(31,file='dos.dat',form='formatted',status='unknown')
         ww=0.0
         do while (ww.lt.Freq(Ndim)+3*sigmam) 
            ww=ww+step
            write(31,'(10(f10.5,x))') 
     &           ww,(dos(ww,Ndim,Freq,sigma(i)),i=1,N_disp)
         end do
         close (31)

         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title 
         do i=1,N_disp
            write(cha5,'(f5.1)') sigma(i)
            title_pl(i)= 's = '//cha5
         end do
         call Plot(N_disp,'dos.dat     ',7,
     ,            Title,title_pl,E_L,E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'DOS (arb.units)     ', 'Screen', 31,Up_lim)
         call Plot(N_disp,'dos.dat     ',7,
     ,            Title,title_pl,E_L,E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'DOS (arb.units)     ', 'Postsc', 31,Up_lim)

c[D2]...... calculate projected DOS for a set of atoms

      ELSE IF(cha2(l0:).eq.'D2' .and. Yes_solved .and. Yes_chosen) THEN
         
         open(31,file='dos_proj.dat',form='formatted',status='unknown')
         s=sigma(1)
         ww=0.0
         do while (ww.lt.Freq(Ndim)+3*s) 
            ww=ww+step
            st=dos(ww,Ndim,Freq,s)
            write(31,'(10(f10.5,x))') ww,st,
     ,         (pdos(ww,Ndim,Freq,s,j_proj_atom(k)),k=1,Np_atoms)
         end do
         close (31)

         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title 
         title_pl(1)='total DOS'
         do k=1,Np_atoms
            write(cha4,'(i4)') Num_proj_atom(k)
            title_pl(k+1)='atom '//cha4
         end do
         call Plot(Np_atoms+1,'dos_proj.dat',12,
     ,            Title,title_pl,E_L,E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'Proj-DOS (arb.units)', 'Screen', 31,Up_lim)
         call Plot(Np_atoms+1,'dos_proj.dat',12,
     ,            Title,title_pl,E_L,E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'Proj-DOS (arb.units)', 'Postsc', 31,Up_lim)

c[pD]...... choose atoms for projected DOS

      ELSE IF(cha2(l0:).eq.'pD') THEN
         
         do j=1,ITI
            proj_at(j)=.false.
         end do
 31      write(*,*)'Give atomic numbers for projected DOS on one line'
         write(*,*)
     &     'using dashes, commas and spaces (up to 8 atoms in total):' 
         read(*,'(a)') line
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 31
         nt=0
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*,err=31) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*,err=31) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*,err=31) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 31
            do j=i1,i2
               nt=nt+1
               if(nt.gt.8) then
                  write(*,*)
     &             'WARNING: The list is longer than 8 and will be cut'
               else
                  proj_at(j)=.true.
                  Num_proj_atom(nt)=j
               end if
            end do
         end do
         Np_atoms=nt
         if(nt.gt.8) Np_atoms=8
         Yes_chosen=.true.

c____________ determine degrees of freedom j corresponding to projected atoms

         Err=.false.
         do k=1,Np_atoms
            do j=1,Ndim,3
               if(atom_info(j).eq.Num_proj_atom(k)) then
                  j_proj_atom(k)=j
                  go to 51
               end if
            end do
            Err=.true.
            write(*,'(a,i5,a)') 'ERROR: atom ',Num_proj_atom(k),
     &                   ' is fixed and thus cannot be chosen'
 51      end do
         if(Err) Yes_chosen=.false.

c[Co]...... show information about orbits

      ELSE IF(cha2(l0:).eq.'Co') THEN
         
         write(*,'(a)') 'Tot--Orb-Species-Number-------'//
     &'--atom coordinates---------Radius--Fix-|----Mass----|-Old#-'
         nt=0
         do io=1,NORB
            is=ISORT1(io)
            if(Fix(io)) then
               cha1='Y'
            else
               cha1='N'
            end if
            RA(1)=R1(io,1)
            RA(2)=R1(io,2)
            RA(3)=R1(io,3)
            call pvrt0(RA,RR,Nnn)
            do iN=1,KAN(io)
               nt=nt+1
               rad=sqrt(RR(iN,1)**2+RR(iN,2)**2+RR(iN,3)**2)
               write(*,'(i4,x,2(i3,x),a2,x,i5,x,4(f10.5,x),x,a,x,
     ,                           f9.5,x,a,i4)') 
     &           nt,io,is,Species(is),iN,(RR(iN,j),j=1,3),rad,
     ,           cha1//' | ',Atom_mass(nt),'| ',orb_to_old(io,iN)
            end do
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[SB]...... show Born charges on atoms

      ELSE IF(cha2(l0:).eq.'SB' .and. ChargeS) THEN
         
         write(*,'(a)') 'Tot-Species-|--------Born--charge---'//
     &    '---------------------------------------------------|-Old#-'
         nt=0
         do io=1,NORB
            is=ISORT1(io)
            if(Fix(io)) then
               cha1='Y'
            else
               cha1='N'
            end if
            RA(1)=R1(io,1)
            RA(2)=R1(io,2)
            RA(3)=R1(io,3)
            call pvrt0(RA,RR,Nnn)
            do iN=1,KAN(io)
               nt=nt+1
               rad=sqrt(RR(iN,1)**2+RR(iN,2)**2+RR(iN,3)**2)
               if(ChargeS) then
                  nat=orb_to_old(io,iN)
                  write(cch,'(9(f7.3,x))') ((Q(i,j,nat),j=1,3),i=1,3)
               else
                  cch='                         --- Not available ---'
     &                 //'                          '
               end if  
               write(*,'(i4,x,i3,x,a2,a3,a72,a,i4)') 
     &           nt,is,Species(is),' | ',cch,' |',orb_to_old(io,iN)
            end do
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n','y')
         write(*,'(2a)') 'Point symmetry group:       ',GroupN
         if(MG.gt.12) then
            write(*,'(a,12(a4,1x))') 'Group operators:            ',
     ,           (NAZ(KG(i)),i=1,12)
            do i=13,MG,12
               l1=i
               l2=l1+12
               if(l2.gt.MG) l2=MG
               write(*,'(a,12(a4,1x))') (NAZ(KG(j)),j=l1,l2)
            end do
         else
            write(*,'(a,12(a4,1x))') 'Group operators:            ',
     ,           (NAZ(KG(i)),i=1,MG)
         end if
         write(*,'(a,12(i2,2x))')  'Irreducible represenations #: ',
     ,        (i,i=1,NEPR)
         write(*,'(a,12(x,a3))')'Their names:                  ',
     ,        (NAZVIR(i),i=1,NEPR)
         write(*,'(a,12(x,i2,x))')'Their dimensions:            ',
     ,        (NALFA(i),i=1,NEPR)
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Da]...... displacement amplitude

      ELSE IF(cha2(l0:).eq.'Da') THEN

 13      write(*,*)'Specify the amplitude of distortion (in A):'
         read(*,*,err=13) ampl

c[XY]...... ask the code for movie.xyz file 

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='Ymol'
c         end if

c[Hs]...... add Hydrogens to movie.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[Sg]...... sigma for the DOS

      ELSE IF(cha2(l0:).eq.'Sg') THEN

 15      write(*,'(a,i1,a)')'Specify ',N_disp,' dispersions (in cm^-1):'
         read(*,*,err=15) (sigma(i),i=1,N_disp)
         do i=1,N_disp
            if(sigma(i).lt.0.0) go to 15
         end do

c[Nd]...... number of dispersions

      ELSE IF(cha2(l0:).eq.'Nd') THEN

 17      write(*,*)'Specify the number of dispersions: '
         read(*,*,err=17) N_disp
         if(N_disp.lt.1 .or. N_disp.gt.9) go to 17

c[St]...... step for the DOS

      ELSE IF(cha2(l0:).eq.'St') THEN

 26      write(*,*)'Specify (in cm^-1) step for the DOS:'
         read(*,*,err=26) step

c[NI]...... whether to normalise the IR spectrum

      ELSE IF(cha2(l0:).eq.'NI') THEN

         if(IR_normalise) then
            IR_normalise=.false.
         else
            IR_normalise=.true.
         end if

c[Up]...... upper limit for the DOS

      ELSE IF(cha2(l0:).eq.'Up') THEN

 27      write(*,*)'Specify the upper limit for the DOS/I(w):'
         read(*,*,err=27) Up_lim

c[EB]...... left/right limits for the DOS

      ELSE IF(cha2(l0:).eq.'EB') THEN

 53      write(*,*) 'Specify the left and right limits for the DOS:'
         write(*,*)'Hit ENTER to change to the default value'
         read(*,'(a)') line
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(NumLin.eq.0) then
            write(*,*)'Restoring default value ...'
            E_L=0.0
            E_R=max(Freq(Ndim),Freq_ru(Ndim),Freq_ll(Ndim))+3*sigmam
         else
            read(Line(LinPos(1):LinEnd(1)),*,err=53) E_L
            read(Line(LinPos(2):LinEnd(2)),*,err=53) E_R
         end if
         if(E_L.ge.E_R) go to 53

c[T]...... temperature in K

      ELSE IF(cha2(l0:).eq.'T') THEN

 28      write(*,*)'Specify the temperature (in K) for I(w):'
         read(*,*,err=28) Temp

c[Av]...... if average over all directions of E or not

      ELSE IF(cha2(l0:).eq.'Av') THEN

         if(I_of_w_aver.eq.'  no_aver') then
            I_of_w_aver=' pol_aver'
         else if(I_of_w_aver.eq.' pol_aver') then
            I_of_w_aver='zpol_aver'
         else if(I_of_w_aver.eq.'zpol_aver') then
            I_of_w_aver='full_aver'
         else if(I_of_w_aver.eq.'full_aver') then
            I_of_w_aver='  no_aver'
         end if

c[D]...... direction of polarisation (E-direction) or direction of the wave

      ELSE IF(cha2(l0:).eq.'D' .and. I_of_w_aver.ne.'full_aver') THEN

 29      if(I_of_w_aver.eq.' pol_aver') then
            write(*,*)'Specify direction of the E/M wave:'
            read(*,*,err=29) Direct
            dd=sqrt(Direct(1)**2+Direct(2)**2+Direct(3)**2)
            if(dd.lt.tiny) go to 29
            Direct(1)=Direct(1)/dd
            Direct(2)=Direct(2)/dd
            Direct(3)=Direct(3)/dd
         else if(I_of_w_aver.eq.'zpol_aver') then
            write(*,*)'Specify propagation direction angle with the '//
     &           ' Z axis (in Degrees):'
            read(*,*,err=29) zangle
            Direct(1)=zangle
         else if(I_of_w_aver.eq.'  no_aver') then
            write(*,*)'Specify E direction in the E/M wave:'
            read(*,*,err=29) Pol_E
            dd=sqrt(Pol_E(1)**2+Pol_E(2)**2+Pol_E(3)**2)
            if(dd.lt.tiny) go to 29
            Pol_E(1)=Pol_E(1)/dd
            Pol_E(2)=Pol_E(2)/dd
            Pol_E(3)=Pol_E(3)/dd
         end if

c[Bc]...... Born charges on atoms

      ELSE IF(cha2(l0:).eq.'Bc') THEN

         write(*,*)
     &     '**    Specify the file name with Born charges on atoms:  **'
         write(*,*)
     &     '***** should be in the SAME ORDER as in GEOMETRY FILE  ****'
         read(*,'(a)') name
         call right(name,50,l1)
         open(79,file=name(l1:),form='formatted',status='old',err=71)

c_________ Important: atoms in the file are ordered in the original order!
c          We should assign charges corresponding to the new order by orbits
c TO DO: put the corresponding reading statements for each coed to read
c        from their outputs directly when available
 
         if(Which_Code.eq.'SIESTA') then
            read(79,*)
            do na=1,ITI
               read(79,*,err=71,end=71) ((Q(i,j,na),j=1,3),i=1,3)
            end do
         else if(Which_Code.eq.'  VASP') then
            read(79,*)
            do na=1,ITI
               read(79,*,err=71,end=71) ((Q(i,j,na),j=1,3),i=1,3)
            end do
         else if(Which_Code.eq.'VASP52') then
            read(79,*)
            do na=1,ITI
               read(79,*,err=71,end=71) ((Q(i,j,na),j=1,3),i=1,3)
            end do
         else
            write(*,*)'*** There is NO yet support for other codes ***'
            ChargeS=.false.
            go to 21
         end if            
         close (79)
         ChargeS=.true.
         go to 21
 71      write(*,'(a)') 'ERROR! The file '//
     &        name(l1:)//' with Born charges is absent or bad'
         write(*,'(a)') '       I(w) cannot be calculated'
         ChargeS=.false.

c[CM]...... modify charges on atoms

      ELSE IF(cha2(l0:).eq.'CM' .and. ChargeS) THEN

         write(*,*) 
     &        '-------------------------------------------------------'
         write(*,*) 
     &        'Specify atoms for which the SAME charges will be given:'
         write(*,*) '      [in the OLD order (as in the geometry file)]'
         write(*,*) 
     &        '-------------------------------------------------------'
         call Tag(NumLin,ITI,listat,lists,length,N_lists,long_lists)
         if(NumLin.eq.0) go to 21
 32      write(*,*)
     &        'Specify the Born charge tensor (3x3) for these atoms:'
         read(*,*,err=32) ((chrg(i,j),j=1,3),i=1,3)
         do na=1,ITI
            if(listat(na)) then
               do i=1,3
                  Q(i,1:3,na)=chrg(i,1:3)
               end do
            end if
         end do

c[Pf]...... Prefactors for IR intensity: for information only 

      ELSE IF(cha2(l0:).eq.'Pf' .and. ChargeS) THEN

         do j=1,Ndim
            if(Freq(j).gt.tiny) then
               Pref(j)=
     &     Pref_Iw(j,Ndim,Q,Atom_Mass,I_of_w_aver,Direct,Pol_E,.true.)
            else
               Pref(j)=0.0d0
            end if
         end do
         do irep=1,Ndim,ibound
            ir1=irep ; ir2=ir1+ibound-1
            if(ir2.gt.Ndim) ir2=Ndim
            write(*,'(a,10(x,f10.5))') '* Frequency (cm^-1): ',
     ,                                             (Freq(i),i=ir1,ir2)
            write(*,'(a,10(x,f10.5))') 'Prefactor (arb.un.): ',
     ,                                             (Pref(i),i=ir1,ir2)
            write(*,*)
     &           '---------------------------------------------------'
         end do
         write(*,*)'Press ENTER when ready ...'
         read(*,*)

c[Iw]...... IR intensity calculated here for a set of broadening parameters

      ELSE IF(cha2(l0:).eq.'Iw' .and. ChargeS .and. Yes_solved) THEN

         ww=1.0
         w2=2*Freq(Ndim)+3*sigmam

c______________ determine the normalisation factor
         if(IR_normalise) then
            ddm=0.0d0
            do while (ww.lt.w2) 
               ww=ww+step
               dd=I_of_w(ww,Ndim,Freq,sigma(1),Temp,Q,Atom_Mass,
     ,              I_of_w_aver,Direct,Pol_E)
               if(dd.gt.ddm) ddm=dd
            end do
            write(*,*)'Max value for normalisation = ',ddm
         end if
c_______________ actual calculation

         ww=1.0
         open(31,file='I_of_w.dat',form='formatted',status='unknown')
         do while (ww.lt.w2) 
            ww=ww+step
            if(IR_normalise) then
               write(31,'(10(f10.5,x))') ww,(I_of_w(ww,Ndim,Freq,
     ,              sigma(i),Temp,Q,Atom_Mass,I_of_w_aver,Direct,Pol_E)/
     /              ddm,i=1,N_disp)
            else
               write(31,'(10(e12.7,x))') ww,(I_of_w(ww,Ndim,Freq,
     ,         sigma(i),Temp,Q,Atom_Mass,I_of_w_aver,Direct,Pol_E),
     ,              i=1,N_disp)
            end if
         end do
         close (31)

c_______________ plot
         write(*,*)'Give the title to your plot (hit ENTER to ingnore):'
         read(*,'(a)') Title 
         do i=1,N_disp
            write(cha5,'(f5.1)') sigma(i)
            title_pl(i)= 's = '//cha5
         end do
         call Plot(N_disp,'I_of_w.dat  ',10,
     ,            Title,title_pl,E_L,2*E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'I(w) (arb.units)    ', 'Screen', 31,Up_lim)
         call Plot(N_disp,'I_of_w.dat  ',10,
     ,            Title,title_pl,E_L,2*E_R,
     ,           'Frequency (cm^-1)   ', 
     ,           'I(w) (arb.units)    ', 'Postsc', 31,Up_lim)

c[W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W') THEN

c___________ constract all lattice sites  and write geom.xyz      
         call dump_orb_xyz(YES_xyz,Add_Hs)

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21

      end

      subroutine build_fcm(Ndim,IRA_left,Err,WhichForce,Which_Code)
c..................................................................................
c Force constant matrix is constructed from all irreps in one go in G_mat.
c..................................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'working.inc'
      include 'symgenv.inc'      
      include 'matrix.inc'      
      include 'systema.inc'     
      include 'atom_info.inc'     
      integer IRA_left(N0IR),kk(3)
      character WhichForce*7,Which_Code*6
      logical Err1,W_files(N0IR),Yes_W_all,F_files(N0IR),Yes_F_mat
      logical Err
      data kk/3,1,2/
 
      do j=1,Ndim
         do j1=j,Ndim
            G_mat(j,j1)=0.0d0
            G_mat(j1,j)=G_mat(j,j1)
         end do
      end do
c            
      DO 10 IA=1,NEPR
         W_files(IA)=.true.
         F_files(IA)=.true.
         if(IRA_left(IA).eq.0) go to 10
         write(*,*)'irrep= ',IA,' # of vectors = ',IRA_left(IA)

c___________ read in the W_all matrix for this irrep
         call read_W_all_matrix(IA,IRA_left(IA),Err1)
         if(Err1) then
            write(*,*) 'FATAL! Cannot get W-matrix for irrep = ',IA
            W_files(IA)=.false.
         end if

c___________ read in the F matrix for this irrep
         call read_F_matrix(IA,F_mat,IRA_left(IA),ITI,Err1,
     ,        WhichForce,Which_Code)
         if(Err1) then
            write(*,*)'FATAL! Cannot get F-matrix for irrep = ',IA
            F_files(IA)=.false.
         end if

c___________ build up the force constant matrix in Cartesian 
c            coordinates

         do j=1,Ndim
            iN=atom_info(j)
            k=kk(xyz_info(j))

            do j1=j,Ndim
               iN1=atom_info(j1)
               k1=kk(xyz_info(j1))

               do iR=1,IRA_left(IA)
                  do iR1=1,IRA_left(IA)

                     s=0.0d0
                     do jj=1,NALFA(IA)
                        s=s+W_all(k,iN,iR,jj)*W_all(k1,iN1,iR1,jj)
                     end do
                     G_mat(j,j1)=G_mat(j,j1)+s*F_mat(iR,iR1)
                     
                  end do
               end do
               
            end do
         end do

 10   END DO

c___________ decide if to proceed
      
      Err=.false.
      Yes_W_all=.true.
      Yes_F_mat=.true.
      do IA=1,NEPR
         if(.not.W_files(IA)) Yes_W_all=.false.
         if(.not.F_files(IA)) Yes_F_mat=.false.
      end do
      if((.not.Yes_W_all) .or. (.not.Yes_F_mat)) then
         write(*,*)'FATAL! Some files are missing, cannot proceed!'
         Err=.true.
         return
      end if
      return
      end

      subroutine mass_default(Atom_Mass)
c.................................................................
c set Atom_Mass(atom) to AtMass(species)
c.................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'symgenv.inc'
      dimension Atom_Mass(N0LT)
      nat=0
      do io=1,NORB
         is=ISORT1(io)
         do iN=1,KAN(io)
            nat=nat+1
            Atom_Mass(nat)=AtMass(is)
         end do
      end do
      return
      end

      subroutine distorted_xyz_all(Ndim,iV,ampl,Species,ITI,
     ,                                       unit,YES_xyz,Add_Hs)
c..............................................................................
c     New atomic positions corresponding to the excitation of one diaplcement
c vector iV (with amplitude ampl) are calculated and then dumped into a unit.
c..............................................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      include 'matrix.inc'
      include 'atom_info.inc'
      dimension RR(MG0,3),RA(3),x(3)
      integer unit
      character YES_xyz*4,Species(N0KD)*2
      logical Err,Add_Hs
      
c................. write number of atoms
      nnn=ITI
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(unit,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(unit,'(a/i5)') '1',nnn
      end if

      j=-2
      do iOrb=1,NORB
         is=ISORT1(iOrb)
         call check_Mendel(Species(is),mendl,Err,.false.)
         RA(1)=R1(iOrb,1)
         RA(2)=R1(iOrb,2)
         RA(3)=R1(iOrb,3)
         call PVRT0(RA,RR,Nnn)
         do nat=1,Nnn
            if( .not.Fix(iOrb) ) then
               j=j+3
               x(1)=RR(nat,1) + EigV(j  ,iV)*ampl
               x(2)=RR(nat,2) + EigV(j+1,iV)*ampl
               x(3)=RR(nat,3) + EigV(j+2,iV)*ampl
            else
               x(1)=RR(nat,1)
               x(2)=RR(nat,2)
               x(3)=RR(nat,3)
            end if
            if(YES_xyz.eq.'Xmol') then
               write(unit,'(a2,5x,3(f16.10,1x),a)') 
     &              Species(is),(x(j1),j1=1,3)
c     &              Species(is),(x(j1),j1=1,3),' 0 0 0'
            else if(YES_xyz.eq.'Ymol') then
               write(unit,'(i2,5x,3(f16.10,1x))') 
     &              mendl,(x(j1),j1=1,3)
            end if
               
         end do
      end do

      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(unit,'(a)')'2     0.0 0.0 0.0  '
         write(unit,'(a)')'3     15.0 0.0 0.0 '
         write(unit,'(a)')'4     0.0 15.0 0.0 '
         write(unit,'(a)')'5     0.0 0.0 15.0 '
      end if
      return
      end

      subroutine show_normal_coord(Ndim,Freq,Species,unit)
c.............................................................
c nice print of the normal modes for all irreps
c Ndim - total number of normal modes for all irreps
c.............................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      include 'matrix.inc'
      include 'atom_info.inc'
      dimension RR(MG0,3),RA(3),Freq(Ndim)
      integer rep,unit
      character a(3),Species(N0KD)*2
      data a/'x','y','z'/,ibound/10/
c  
c........... write on the screen/file
c
      write(unit,'(a/)')
     &     '****************** normal displacements **************'

      do irep=1,Ndim,ibound
         ir1=irep
         ir2=ir1+ibound-1 ; if(ir2.gt.Ndim) ir2=Ndim
         write(unit,'(a,20(x,f10.5))') '    Frequency  (in cm^-1) ',
     ,           (Freq(rep),rep=ir1,ir2)
         write(unit,'(2x,a,20(2x,i5,4x))')
     &     'old#   atom#     x/y/z   ',(rep,rep=ir1,ir2)
         j=0
         do iOrb=1,NORB
            if((.not.Fix(iOrb))) then
               RA(1:3)=R1(iOrb,1:3) ; is=ISORT1(iOrb)
               call PVRT0(RA,RR,Nnn)
               do nat=1,Nnn
                  iold=orb_to_old(iOrb,nat)
                  do k=1,3
                     j=j+1 ; nt=atom_info(j)
                     write(unit,'(i3,x,a,x,i5,a,20(x,f10.5))') 
     &                    iold,Species(is),nt,a(k),RR(nat,k),
     ,                    (EigV(j,rep),rep=ir1,ir2)
                  end do
               end do
               write(unit,*)
     &           '---------------------------------------------------'
            end if
         end do

         if(ir2.eq.Ndim) return
         if(unit.eq.6) then
            write(*,'(a)')'... Hit ENTER to continue ...'
            read(*,*)
         end if
         
      end do
      end

      double precision function dos(w,Ndim,Freq,sigma)
c.................................................................
c  calculates DOS at w (units: cm^-1)
c.................................................................
      include 'real8.inc'
      dimension Freq(Ndim)

      sg2=sigma*sigma
      sq=1.0/sqrt(2*pi*sigma)
      dos=0.0d0
      do k=1,Ndim
         if(Freq(k).gt.0.0) then
            dw=w-Freq(k)
            dos=dos+exp(-dw*dw/(2*sg2))*sq
         end if
      end do
      return
      end

      double precision function pdos(w,Ndim,Freq,sigma,j)
c....................................................................
c  calculates DOS at w (units: cm^-1) projected on atom associated
c  with degrees of freedom (j,j+1,j+2)=(x,y,z)
c....................................................................
      include 'real8.inc'
      include 'matrix.inc'      
      dimension Freq(Ndim)

      sg2=sigma*sigma
      sq=1.0/sqrt(2*pi*sigma)
      pdos=0.0d0
      do k=1,Ndim
         if(Freq(k).gt.0.0) then
            dw=w-Freq(k)
            s=EigV(j,k)**2+EigV(j+1,k)**2+EigV(j+2,k)**2
            pdos=pdos+exp(-dw*dw/(2*sg2))*sq*s
         end if
      end do
      return
      end

      double precision function I_of_w(w,Ndim,Freq,sigma,Temp,
     ,                              Q,Atom_Mass,I_of_w_aver,Dir,Pol)
c....................................................................
c  calculates I(w) (arb units) at w (units: cm^-1) 
c....................................................................
      include 'real8.inc'
      include 'matrix.inc'      
      include 'atom_info.inc'
      double precision, intent(in):: Freq(Ndim),Atom_Mass(N0LT)
      double precision, intent(in):: Q(3,3,N0LT)
      double precision, parameter :: K_B=8.617343e-5       ! in eV/K
      double precision, parameter :: H_bar=4.13566733e-15  ! in eV*sec
      double precision, parameter :: tiny=0.001
      double precision :: Lorenz,Dir(3),Pol(3)
      character :: I_of_w_aver*9

      I_of_w=0.0d0
      do j=1,Ndim
         if(Freq(j).gt.tiny) then

c
c____________ prefactor depending on the method: the given direction of E (Pol) 
c             or, if averaged, the direction of propagation (Dir), or
c             yet different if for complete averaging

            xa=Pref_Iw(j,Ndim,Q,Atom_Mass,I_of_w_aver,Dir,Pol,.false.)
     ,                                                    

c____________ Bose-Einstein population for each phonon mode, frequencies 
c             are in sec^-1

            omega=sqrt( EigR(j)*.9648667e+28 )
            ex=H_bar*omega/ (K_B*Temp)
            Ph_popul=1.0d0/(exp(ex)-1.0)
c            write(*,'(i3,5(x,e12.6))') j,Ph_popul

c____________ lorenzians at w+w(Ph) and w-w(Ph), frequencies are in cm^-1;
c             in fact, the Lorenzian at w+w(Ph) is small, but I leave it in
c             anyway

            dwM= w-Freq(j)
            dwP= w+Freq(j)
            g1=Lorenz(dwM,sigma)
            g2=Lorenz(dwP,sigma)
            ss=( (1.0+Ph_popul)*g1+ Ph_popul*g2 )/Freq(j)
c            write(*,'(5(x,e12.6))') dwM,dwP,sig,ss,xa

c____________ summing up over modes

            I_of_w=I_of_w + xa*ss 

         end if
      end do
c      I_of_w=I_of_w/(4*pi)
      return
      end

      double precision function Lorenz(x,sigma)
c.......... lorenzian at x with the width sigma
      include 'real8.inc'
      lorenz=(sigma/pi)/(x*x+sigma*sigma)
      return
      end

      double precision function 
     &     Pref_Iw(j,Ndim,Q,Atom_Mass,I_of_w_aver,Dir,Pol,verb)
c................................................................
c prefactors for the I(w) due to the given eigenvalue j
c................................................................
      include 'real8.inc'
      include 'matrix.inc'      
      include 'atom_info.inc'
      double precision, intent(in):: Q(3,3,N0LT),Atom_Mass(N0LT)
      double precision :: x(3),Dir(3),Pol(3),xA(3),xA_perp(3)
      character :: I_of_w_aver*9
      logical verb

c________________ loop over atoms via degrees of freedom: k,k+1,k+2 correspond
c                 to x,y,z of the atom nat=atom_info(k)
      
      if(verb) then
         write(*,'(a)')'========== Calculating prefactors ==========='
         write(*,'(a,i3)')'Vibrational mode ',j
      end if
      x(1)=0.0
      x(2)=0.0
      x(3)=0.0
      do k=1,Ndim,3
         nat=old_atom_from_vibr(k)
         xA(1)=Q(1,1,nat)*EigV(k,j)+Q(1,2,nat)*EigV(k+1,j)+
     +                                   Q(1,3,nat)*EigV(k+2,j)
         xA(2)=Q(2,1,nat)*EigV(k,j)+Q(2,2,nat)*EigV(k+1,j)+
     +                                   Q(2,3,nat)*EigV(k+2,j)
         xA(3)=Q(3,1,nat)*EigV(k,j)+Q(3,2,nat)*EigV(k+1,j)+
     +                                   Q(3,3,nat)*EigV(k+2,j)
         if(verb) then
            write(*,'(a,i5,a,3(f10.5,x),a,f10.5)')
     &              'Atom ',nat,' tau = (',(xA(i1),i1=1,3),
     &                   '), m_pref= ', 1.0/sqrt(Atom_mass(nat))
         end if
         if(I_of_w_aver.eq.'  no_aver') then
            x(1)=x(1)+xA(1)/sqrt(Atom_mass(nat))
            x(2)=x(2)+xA(2)/sqrt(Atom_mass(nat))
            x(3)=x(3)+xA(3)/sqrt(Atom_mass(nat))
         else if(I_of_w_aver.eq.' pol_aver') then
            s=xA(1)*Dir(1)+xA(2)*Dir(2)+xA(3)*Dir(3)
            xA_perp(1)=xA(1)-s*Dir(1)
            xA_perp(2)=xA(2)-s*Dir(2)
            xA_perp(3)=xA(3)-s*Dir(3)
            x(1)=x(1)+xA_perp(1)/sqrt(Atom_mass(nat))
            x(2)=x(2)+xA_perp(2)/sqrt(Atom_mass(nat))
            x(3)=x(3)+xA_perp(3)/sqrt(Atom_mass(nat))
         else if(I_of_w_aver.eq.'zpol_aver') then
            x(1)=x(1)+xA(1)/sqrt(Atom_mass(nat))
            x(2)=x(2)+xA(2)/sqrt(Atom_mass(nat))
            x(3)=x(3)+xA(3)/sqrt(Atom_mass(nat))
         else if(I_of_w_aver.eq.'full_aver') then
            x(1)=x(1)+xA(1)/sqrt(Atom_mass(nat))
            x(2)=x(2)+xA(2)/sqrt(Atom_mass(nat))
            x(3)=x(3)+xA(3)/sqrt(Atom_mass(nat))
         end if
      end do
      if(I_of_w_aver.eq.'  no_aver') then
         s=x(1)*Pol(1)+x(2)*Pol(2)+x(3)*Pol(3)
         aa=s*s
      else if(I_of_w_aver.eq.' pol_aver') then
         aa=(x(1)*x(1)+x(2)*x(2)+x(3)*x(3))/2.0
      else if(I_of_w_aver.eq.'zpol_aver') then
         sin_teta=sin(Dir(1))
         sin2=sin_teta*sin_teta
         aa=(x(1)*x(1)+x(2)*x(2))*(1.0-0.5*sin2)+x(3)*x(3)*sin2
      else if(I_of_w_aver.eq.'full_aver') then
         aa=(x(1)*x(1)+x(2)*x(2)+x(3)*x(3))/3.0
      end if
      if(verb) then
         write(*,'(a,3(f10.5,x))')'Final vector = ',(x(i1),i1=1,3)
         write(*,'(a,f10.5)')'prefactor = ',aa
      end if
c
c...... final claculation of the prefactors
c
c      freq =sqrt( EigR(j)*.9648667e+28 )*53.08837459E-13
      freq =sqrt( EigR(j) )
      Pref_Iw=aa * freq**3
      return
      end

      subroutine dump_orb_xyz(YES_xyz,Add_Hs)
c................................................................
c write geom.xyz file for XMOL
c................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'symgenv.inc'      
      character YES_xyz*4
      dimension x(3),RR(MG0,3)
      logical Err,Add_Hs

c__________ open xyz file

      open(37,file='geom.xyz',form='formatted',status='unknown')
      nnn=ITI
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(37,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(37,'(a/i5)') '1',nnn
      end if

c___________ write all atoms

      nt=0
      do io=1,NORB
         is=ISORT1(io)
         call check_Mendel(Species(is),mendl,Err,.false.)
         x(1)=R1(io,1)
         x(2)=R1(io,2)
         x(3)=R1(io,3)
         call pvrt0(x,RR,Nnn)
         do iN=1,KAN(io)
            nt=nt+1
            if(YES_xyz.eq.'Xmol') then
               write(37,'(a2,5x,3(f16.10,1x),a)') 
     &              Species(is),(RR(iN,j),j=1,3)
c     &              Species(is),(RR(iN,j),j=1,3),' 0 0 0'
            else if(YES_xyz.eq.'Ymol') then
               write(37,'(i2,5x,3(f16.10,1x))') 
     &              mendl,(RR(iN,j),j=1,3)
            end if
         end do
      end do
      
      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(37,'(a)')'2     0.0 0.0 0.0  '
         write(37,'(a)')'3     15.0 0.0 0.0 '
         write(37,'(a)')'4     0.0 15.0 0.0 '
         write(37,'(a)')'5     0.0 0.0 15.0 '
      end if
      close (37)
      return
      end

      subroutine calculate_freq(Ndim,Freq,Atom_Mass,prod_freq_log)
c............................................................................
c calculate frequencies from the force-constant matrix G_mat
c............................................................................
      include 'real8.inc'
      include 'matrix.inc'
      include 'atom_info.inc'

      dimension Freq(K0DM0),Atom_Mass(N0LT)
      data tiny/0.00001/

      do j=1,Ndim
         nat=atom_info(j)
         do j1=j,Ndim
            nat1=atom_info(j1)
            am=Atom_Mass(nat)*Atom_Mass(nat1)
            F_mat(j,j1)=G_mat(j,j1)/sqrt(am)
            F_mat(j1,j)=F_mat(j,j1)
         end do
      end do
      
c_________  and diagonalise it
      call diag(F_mat,Work,EigR,EigV,K0DM0,Ndim)

c_________ eigenvalues EigR() are in [eV/(a.u.m.*A^2)]; 
c          change sqrt(EigR) into cm^-1, these will be frequencies (=Freq);
c          also, take product of frequencies (except for the imaginary ones,
c          if exist)

      prod_freq_log=0.0
      do k=1,Ndim
         if(EigR(k).ge.tiny) then
            Freq(k)=sqrt( EigR(k)*.9648667e+28 )*53.08837459E-13
            prod_freq_log=prod_freq_log + dlog(Freq(k))
         else
            Freq(k)=-1.0
         end if
      end do
      end
