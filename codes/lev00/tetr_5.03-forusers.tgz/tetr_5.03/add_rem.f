      subroutine add_rem()
c..................................................................
c     Adds/removes atoms to/from the cell. ---> now obsolete!
c     Just checking positions in the cell.
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension r(3),x(3),Nsp1(N0KD+1)
      character angstr*12,cha2*2
      logical ask_equiv
      data angstr/'<Angstroms> '/
c
c....... Nsp1(species) - gives the number of 1st atom of the current
c                        species in the list of all atoms in the cell
c
      Nsp1(1)=1
      if(Nsp.ge.2) then
        do j=2,Nsp+1
          Nsp1(j)=Nsp1(j-1)+NspN(j-1)
        end do
      end if

c
c....... setting intitial precision
      tiny=tiny_equiv

c
c................. menu
c
 5    write(*,*)
      write(*,*)'Choose an option:'
      write(*,*)
      write(*,*)'  1. Check position in the cell'
      write(*,*)
     &     ' Co. Show current atomic positions in fractional/Cartesian'

c_____ show settings

      write(*,*)
     &'----------------------- s e t t i n g --------------------------'
      write(*,*)' An. [For input] Position is specified in: '//angstr
      write(*,*)
     &' Pr. Precision while checking position on equivalence:',tiny
      write(*,*)'  Q. Leave'
      write(*,*)
      write(*,*)'----------> Choose the appropriate option:'
      read (*,'(a)',err=5) cha2
      call right(cha2,2,l0)

c
c....... choose the way how the coordinates are given
c
      IF(cha2(l0:).eq.'An') THEN
         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else
            angstr='<Fractional>'
         end if 

c
c...... precision
c
      ELSE IF(cha2(l0:).eq.'Pr') THEN

 11      write(*,*)
     &        'Specify precision while checking fractional coordinates:'
         read(*,*,err=11) tiny

c
c...... check lattice sites
c
      ELSE IF(cha2(l0:).eq.'1') THEN

         call givepoint(x(1),x(2),x(3),angstr)
         write(*,*)'The position to check: ',  (x(j),j=1,3) 

c______ check 
         do k=1,ITI
            r(1)=TI(1,k)-x(1)
            r(2)=TI(2,k)-x(2)
            r(3)=TI(3,k)-x(3)
            if(ask_equiv(r,BJ,3,tiny)) then
               do kk=1,Nsp
                  if(k.ge.Nsp1(kk).and.k.lt.Nsp1(kk+1)) go to 40
               end do
 40            write(*,*) 'ANSWER: position is equivalent to atom ',k,
     &              ' (it belongs to species ',kk,')'
               go to 5
            end if
         end do
         write(*,*)'ANSWER: position is unique!'
         
c[Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN
         call show_atoms_notag()

c[Q].... quit

      ELSE IF(cha2(l0:).eq.'Q') THEN
         return
      ELSE
         write(*,*)'ERROR! Try again!'
      END IF
      go to 5
      end

      subroutine write_animate_xyz(Which_Code)
c..................................................................
c     Reads file containing atomic coordinats during the course
c  of relaxation and writes this information as geom_film.xyz file.
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension TI1(3,N0LT)
      logical Add_Hs
      character Which_Code*6,YES_xyz*4,answer*1
      data YES_xyz/'Xmol'/
      data M1/0/,N1/0/,M2/0/,N2/0/,M3/0/,N3/0/
c
c........... ask breeding box
      call ask_breeding_box(M1,N1,M2,N2,M3,N3)

c
c........... ask visualisation package
      write(*,'(a)')'Visualisation package is set to: '//YES_xyz
      write(*,'(a)')'Keep it or change (k/c)?'
      read(*,'(a)') answer
      if(answer.eq.'c') then
         if(YES_xyz.eq.'Xmol') then
            YES_xyz='Ymol'
         else if(YES_xyz.eq.'Ymol') then
            YES_xyz='Xmol'
         end if
         write(*,'(a)')'OK! setting the package to: '//YES_xyz
      end if
      write(*,'(a)')'Add Hydrogen atoms to the xyz file (n/y)?'
      read(*,'(a)') answer
      if(answer.eq.'y') then
         Add_Hs=.true.
      else
         Add_Hs=.false.
      end if

c___________ open amination file
      open(14,file='geom.xyz',form='formatted',status='unknown')

c___________ read/write

      if(Which_Code.eq.'CASTEP') then
         open(13,file=seed(l0seed:)//'.coord',form='formatted',
     &        status='old',err=100)
         read(13,*)
 1       read(13,*,err=110,end=10) iter
         write(*,*)'reading in data from iteration = ',iter
         do k=1,ITI
            read(13,*) TI1(1,k),TI1(2,k),TI1(3,k)
         end do
         call create_film_xyz(TI1,ITI,Species,Nsp,NspN,AJ,
     ,        M1,N1,M2,N2,M3,N3,YES_xyz,Add_Hs)
         go to 1
c
c.............. VASP, SIESTA
c 
c      else if(Which_Code.eq.'  VASP') then
      else 
        write(*,*)'Sorry! Not yet implemented!'
      end if
 10   close(13)
      close(14)
      return
c
c... errors
 100  write(*,*)'FATAL! File '//seed(l0seed:)//'.coord does not exist!'
      return
 110  write(*,*)'ERROR while reading '//seed(l0seed:)//'.coord file!'
      return
      end

      subroutine create_film_xyz(TI1,ITI,Species,Nsp,NspN,AJ,
     ,     M1,N1,M2,N2,M3,N3,YES_xyz,Add_Hs)
c................................................................
c write geom.xyz file for Xmol/Ymol
c................................................................
      include 'real8.inc'
      dimension x(3),TI1(3,N0LT),NspN(Nsp),AJ(3,3)
      character Species(Nsp)*2,YES_xyz*4
      logical Err,Add_Hs

c__________ write number of atoms first
      L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
      nnn=ITI*L_ext
      if(YES_xyz.eq.'Xmol' .or. YES_xyz.eq.'None') then
         if(Add_Hs) nnn=nnn+3
         write(14,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(14,'(a/i5)') '1',nnn
      end if

c___________ write atoms next

      nat=0
      do i=1,Nsp
         call check_Mendel(Species(i),mendl,Err,.false.)

         do i1=M1,N1
            do i2=M2,N2
               do i3=M3,N3
                  
                  DO k=1,NspN(i)
                     x(1)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+
     +                    TI1(1,k+nat)
                     x(2)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+
     +                    TI1(2,k+nat)
                     x(3)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+
     +                    TI1(3,k+nat)
                     if(YES_xyz.eq.'Xmol' .or. YES_xyz.eq.'None') then
                        write(14,'(a2,5x,3(f16.10,1x),a)') 
     &                       Species(i),(x(j),j=1,3)
c     &                       Species(i),(x(j),j=1,3),' 0 0 0'
                     else if(YES_xyz.eq.'Ymol') then
                        write(14,'(i2,5x,3(f16.10,1x))') 
     &                                     mendl,(x(j),j=1,3)
                     end if
                  END DO
                  
               end do
            end do
         end do
         
         nat=nat+NspN(i)
         
      end do
      if(Add_Hs .and. (YES_xyz.eq.'Xmol' .or. YES_xyz.eq.'None')) then
         write(14,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(14,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(14,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and. Add_Hs) then
         write(14,'(a)')'2     0.0 0.0 0.0  '
         write(14,'(a)')'3     10.0 0.0 0.0 '
         write(14,'(a)')'4     0.0 10.0 0.0 '
         write(14,'(a)')'5     0.0 0.0 10.0 '
      end if
      return
      end

      subroutine write_in_box(Which_Code,YES_xyz)
c....................................................................
c   A box is chosen inside the cell which may run across several
c adjacent cells, and all atoms in the box are written in an
c appropriate XYZ file
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      parameter (N_z=200,N_at=1000)
      dimension R(3),x(3),R1(3),R2(3)
      dimension Center(3),Sides(3,3),Direct(3,3),Face(3),RecipS(3,3)
      dimension Pos(3,N_at),iType(N_at)
      character cha2*2,YES_xyz*4
      logical Yes_Do,Err,Add_Hs
      character Which_Code*6,angstr*12
      data tiny/0.0001/,Center/3*0.0/,Face/3*1.0/,angstr/'<Angstroms> '/
      data Add_Hs/.false./
c
c________ default for the directions of the box sides: 
c         along the Cartesian axes 
      do i=1,3
         do j=1,3
            Direct(i,j)=0.0
         end do
         Direct(i,i)=1.0
      end do
c
c................. start the main menu
c
      Yes_Do=.false.
1     iQuit=0
      write(*,*)'............MENU for XYZ-in-a-box writer .............'
      write(*,*)'......... Change these parameters if necessary:.......'
      write(*,*)

      write(*,'(a,3(f10.5,a))') '  Cp. The box center is at: (',
     &          Center(1),',',Center(2),',',Center(3),')'

      write(*,'(a)')'      Directions of the box sides are fixed along:'
      write(*,'(10x,a,3(f10.5,a))') 
     &    '1   <',Direct(1,1),',',Direct(1,2),',',Direct(1,3),'  >'
      write(*,'(10x,a,3(f10.5,a))') 
     &    '2   <',Direct(2,1),',',Direct(2,2),',',Direct(2,3),'  >'
      write(*,'(10x,a,3(f10.5,a))') 
     &    '3   <',Direct(3,1),',',Direct(3,2),',',Direct(3,3),'  >'

      write(*,'(a,3(1x,f10.5))')
     &    '   L. Lengths of the box sides (in A) are: ',(Face(i),i=1,3)

      do i=1,3
        do j=1,3
          Sides(i,j)=Direct(i,j)*Face(i)
        end do
      end do
      call INVER(Sides,RecipS)
      
      if(Yes_Do) then
         write(*,'(a)') '  Ca. Calculate atomic positions <-- DONE!'
         write(*,'(a,i5)') '    >>> atoms found in the box = ',nt
         write(*,'(a)') '  At. Show atoms in the box' 
      else
         write(*,'(a)') '  Ca. Calculate atomic positions'
      end if
      write(*,'(a)') '   W. Write atoms into <geom.xyz> file'

      write(*,'(a)')
     &              '-------  G e n e r a l  s e t t i n g s ---------'
      write(*,'(a)')'  An. Coordinates are specified in: '//angstr
      write(*,'(a)')
     &    '  Co. Show current atomic positions in fractional/Cartesian'
c      write(*,*)
c     &' XY. Use the following format for <geom.xyz> file: '//YES_xyz
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      write(*,'(a)')'  cT. Centre of a triangle of points/atoms'
      write(*,'(a)')'  mD. Middle distance between two points/atoms'

      write(*,'(a)')'------ L e a v e   t h e   m e n u -------------'
      write(*,'(a)')'   Q. Return to the previous menu'
      write(*,*)
      write(*,*)'------> Choose the item and press ENTER:'
      read (*,'(a)',err=1) cha2
      call right(cha2,2,l0)
c
c[An]__________ choose the way how the coordinates are given
c
      IF(cha2(l0:).eq.'An') THEN
         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if 
c
c[Cp]__________ give the central point 
c
      ELSE IF(cha2(l0:).eq.'Cp') THEN
         WRITE(*,*)'Give the center of your box'
         call givepoint(Center(1),Center(2),Center(3),angstr)
         Yes_Do=.false.
c
c[L]__________ choose lengths of the box sides
c
      ELSE IF(cha2(l0:).eq.'L') THEN
 12      WRITE(*,'(a)')'Give lengths of the box sides (in A)'
         read(*,*,err=12) (Face(j),j=1,3)
         do j=1,3
           Face(j)=abs(Face(j))
           if(Face(j).lt.tiny) go to 12
         end do
         Yes_Do=.false.
c
c[Ca]________ calculate atomic positions in the box
c
      ELSE IF(cha2(l0:).eq.'Ca') THEN
         call at_in_box(Center,Sides,RecipS,Pos,iType,N_at,nt,Err)
         if(Err) go to 1
         Yes_Do=.true.
c
c[At]_________ show atoms inside the box
c
      ELSE IF(cha2(l0:).eq.'At' .and. Yes_Do) THEN
         write(*,'(a)')' Tot#  Species  Spec#        '//
     &        '    |-------------  Cartesian ---------|'
        do i=1,nt
            write(*,'(i4,5x,a2,5x,i3,5x,3(f16.10,1x),a)') 
     &         i,Species(iType(i)),iType(i),(Pos(j,i),j=1,3)
         end do
         write(*,'(a)')'Press ENTER when done ...'
         read(*,*)
c
c[W]_________ write the XYZ file with atoms inside the box
c
      ELSE IF(cha2(l0:).eq.'W' .and. Yes_Do) THEN

c___________________ write an xyz file with atomic positions
         write(*,'(a)')
     &        'Opening the file <geom.xyz> with the coordinates ...'
         open(37,file='geom.xyz',form='formatted',status='unknown')
c         open(37,file='geom_box.xyz',form='formatted',status='unknown')
         nnn=nt
         if(YES_xyz.eq.'Xmol') then
            if(Add_Hs) nnn=nnn+3
            write(37,'(i5/)') nnn
         else if(YES_xyz.eq.'Ymol') then
            if(Add_Hs) nnn=nnn+4
            write(37,'(a/i5)') '1',nnn
         end if
         do i=1,nt
            if(YES_xyz.eq.'Xmol') then
               write(37,'(a2,5x,3(f16.10,1x),a)') 
     &              Species(iType(i)),(Pos(j,i),j=1,3)
c     &              Species(iType(i)),(Pos(j,i),j=1,3),' 0 0 0'
            else if(YES_xyz.eq.'Ymol') then
               call check_Mendel(Species(iType(i)),mendl,Err,.false.)
               write(37,'(i2,5x,3(f16.10,1x))') mendl,(Pos(j,i),j=1,3)
            end if
         end do
         if(YES_xyz.eq.'Xmol' .and. Add_Hs) then
            write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 10.0  0.0  0.0 '
            write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  10.0  0.0 '
            write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  10.0 '
         else if(YES_xyz.eq.'Ymol' .and. Add_Hs) then
            write(37,'(a)')'2     0.0 0.0 0.0  '
            write(37,'(a)')'3     10.0 0.0 0.0 '
            write(37,'(a)')'4     0.0 10.0 0.0 '
            write(37,'(a)')'5     0.0 0.0 10.0 '
         end if
         close(37)
         WRITE(*,*)'Done! The file <geom_box.xyz> created!'
c
c[Co].... display atomic positions
c
      ELSE IF(cha2(l0:).eq.'Co') THEN
         call show_atoms_notag()
c
c[cT]__________ centre of a triangle
c
      ELSE IF(cha2(l0:).eq.'cT') THEN
         WRITE(*,*)'Give the 1st point/atom:'
         call givepoint(R(1),R(2),R(3),angstr)
         WRITE(*,*)'Give the 2nd point/atom:'
         call givepoint(R1(1),R1(2),R1(3),angstr)
         WRITE(*,*)'Give the 3rd point/atom:'
         call givepoint(R2(1),R2(2),R2(3),angstr)
         do i=1,3
            x(i)=(R(i)+R1(i)+R2(i))/3.0
         end do
         write(*,*)'The centre of the triangle is at:',(x(i),i=1,3)

c
c[mD]__________ middle distance between two points
c
      ELSE IF(cha2(l0:).eq.'mD') THEN
         WRITE(*,*)'Give the 1st point/atom:'
         call givepoint(R(1),R(2),R(3),angstr)
         WRITE(*,*)'Give the 2nd point/atom:'
         call givepoint(R1(1),R1(2),R1(3),angstr)
         do i=1,3
            x(i)=0.5 * (R(i)+R1(i))
         end do
         write(*,*)'The middle distance between the points is at:',
     &        (x(i),i=1,3)

c[XY]...... format for the xyz file

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='Ymol'
c         end if

c[Hs]...... add Hydrongens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if
c
c[Q]__________ return to the previous menu
c
      ELSE IF(cha2(l0:).eq.'Q') THEN
         return  
      ELSE
         write(*,*)'ERROR! Try again!'
      END IF
      go to 1
      end

      subroutine at_in_box(Centr,Sides,Rec,Pos,iType,N_at,nt,Err)
c.................................................................
c Positions Pos() and species types iType() of all atoms fitted 
c into the box (with Centr, Sides, Rec) are calculated.
c.................................................................
c nt - number of atoms found in the box (should be =< N_at)
c.................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension Pos(3,N_at),iType(N_at)
      dimension Centr(3),Sides(3,3),Rec(3,3),x(3)
      character iask
      logical Err

      Err=.false.
      nat=0
      nt=0
      DO i1=1,Nsp
         DO j1=1,NspN(i1)
            nat=nat+1
            
            do i=-1,1
               do j=-1,1
                  do k=-1,1
                     x(1)=i*AJ(1,1)+j*AJ(2,1)+k*AJ(3,1)+TI(1,nat)
                     x(2)=i*AJ(1,2)+j*AJ(2,2)+k*AJ(3,2)+TI(2,nat)
                     x(3)=i*AJ(1,3)+j*AJ(2,3)+k*AJ(3,3)+TI(3,nat)
                     call ask_box2(x,Centr,Sides,Rec,iask)

                     if(iask.eq.'y') then
                        nt=nt+1
                        if(nt.eq.N_at) then
                           write(*,*)
     &                          'ERROR! # of atoms in the box > ',N_at
                           Err=.true.
                           return
                        end if
                        Pos(1,nt)=x(1)
                        Pos(2,nt)=x(2)
                        Pos(3,nt)=x(3)
                        iType(nt)=i1
                     end if

                  end do
               end do
            end do
            
         END DO
      END DO
      write(*,*)'Number of atoms in the box found = ',nt
      return
      end

      subroutine ask_box2(r,Center,SIDES,RECIP,iask)
c.........................................................................
c Replies with:
c  iask='y'  -  if the point r() is inside a parallelepiped
c               (the box) drawn around the Center with sides along the 
c               directions of the vectors SIDES
c  iask='n'  -  if not.
c.........................................................................
c  SIDES(#,xyz) - directions of the box sides
c  RECIP(#,xyz) - "reciprocal" vectors associated with SIDES, i.e.
c                    RECIP(#1)*SIDES(#2)=delta(#1,#2) (dot product)
c.........................................................................
      include 'real8.inc'
      character iask*1
      dimension Center(3),r(3),x(3),corner(3),SIDES(3,3)
      dimension RECIP(3,3)
      data tiny/0.0001D00/
c
c_______ the vector to the 1st corner of the box 
c
      corner(1)=Center(1)-0.5*(SIDES(1,1)+SIDES(2,1)+SIDES(3,1))      
      corner(2)=Center(2)-0.5*(SIDES(1,2)+SIDES(2,2)+SIDES(3,2))      
      corner(3)=Center(3)-0.5*(SIDES(1,3)+SIDES(2,3)+SIDES(3,3))      
c
c_______ part of r() inside the box
c       
      x(1)=r(1)-corner(1)
      x(2)=r(2)-corner(2)
      x(3)=r(3)-corner(3)
c
c_______ The vector x() is inside the box fixed by vectors SIDES if
c        in the expansion of x() wrt SIDES all 3 coefficients are
c        between 0.0  and 1.0

      d0=-tiny
      d1=1.0+tiny
      c1=x(1)*RECIP(1,1)+x(2)*RECIP(1,2)+x(3)*RECIP(1,3)
      if(c1.ge.d0 .and. c1.le.d1) then
         c2=x(1)*RECIP(2,1)+x(2)*RECIP(2,2)+x(3)*RECIP(2,3)
         if(c2.ge.d0 .and. c2.le.d1) then
            c3=x(1)*RECIP(3,1)+x(2)*RECIP(3,2)+x(3)*RECIP(3,3)
            if(c3.ge.d0 .and. c3.le.d1) then
               iask='y'
               return
            end if
         end if
      end if
      iask='n'
      return
      end 

