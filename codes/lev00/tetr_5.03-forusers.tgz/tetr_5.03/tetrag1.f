      program tetr
c.........................................................................
c..........[This is kept for historical reasons]..........................
c.........................................................................
c
c..................This program was written to simplify ................
c..................an input to CASTEP. At the moment it ................
c..................produces "fort.15" file contained:   ................
c..................................
c..................- direct lattice vectors;            ................
c..................- atomic coordinates in the cell;    ................
c..................- k-points and their weights.        ................
c..................................
c.........................................................................
c.................    L.N.Kantorovich        25.07.94     ................
c.........................................................................
c
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'siesta.inc'
      include 'pgroup_base.inc'
      include 'systema.inc'
      character Which_Code*6,YES_xyz*4,cha2*2,seed0*40,word*14
      logical read_c,okay,Err
      double precision kpoint(Nkpoint,3)
      data M1/0/,N1/0/,M2/0/,N2/0/,M3/0/,N3/0/ 
      data YES_xyz/'Xmol'/

c___________ log file
      open(8,file='tetr.log',STATUS='replace',form='formatted')
      
c______check if TETR is run under Chimera:
      i0=iargc()
      if(i0.eq.0) then
         CHIMERA=.false.
         write(8,*)'>>>> CHIMERA is OFF'
      else
         call getarg(1,word)
         i0=index(word,'CHIMERA=true') + index(word,'CHIMERA=T')
     &       + index(word,'CHIMERA=.true.')    
         if(i0.ne.0) CHIMERA=.true.
         write(8,*)'>>>> CHIMERA is ON'
      end if
c
c___ elements of all groups
c
      call elem_numb()
c
c___ read_c=.true. if ALL coordinates have been already read in by 
c                   read_coord(); otherwise, it is .false.
      call initialise(nkp,read_c)
c
c___ setting initial precision for checking atomic positions for 
c    equivalence
c
      tiny_equiv=0.0001d0 
c     
c....... the hat
      call hat()
c     
c....... ask about the code: which format?
 111  call which_PW_code(Which_Code)
      seed0=seed
      l0seed0=l0seed
c
c....... read geometry information from the file
      if(Which_Code.ne.'   NEW') then
         call initiate(Which_Code,seed0,l0seed0,Err)
         if(Err) then
            read_c=.false.
            go to 111
         else
            read_c=.true.
         end if
      end if
c
c........ initial setting: 
c             origin - if to move closer to the centre of the coord. system
c             donot_kp - if to leave the k-points unchanged
c
      origin=.false.
      donot_kp=.false.
c     
c......ask what to do in the MAIN MENU
c     
c_________ calculate reciprocal lattice vectors in 2*PI units
 1    if(read_c) call INVER(AJ,BJ)

      write(*,*)'/---------------------------------------------------\\'
      write(*,*)'|.................... MAIN MENU:.....................|'
      write(*,*)'\\---------------------------------------------------/'

      write(*,*)
      write(*,*)
     &     '>>>>>>>>>>>>>  Create unit cell from scratch <<<<<<<<'
      write(*,*)  '               [current geometry will be lost] '
      write(*,*)
     &'  B. Generate cell from scratch || Pc. Generate from space group'
      write(*,*)
      write(*,*)
     &        '>>>>>>>>>>>>>>>>>  Cluster construction  <<<<<<<<<<<<'
      write(*,*)'  Cl. Build up a cluster from the lattice'

      if(Which_Code.ne.'   NEW') then
         write(*,*)
         write(*,*)
     &        '>>>>>>>>>>>>> Geometry file already exists <<<<<<<<<<'
         write(*,*)
     &'  M. Complex cell modifications ||  KP. k-points generation '
c         write(*,*)'  La. Build up a layered cell (e.g. for SBC)'
         write(*,*)
         write(*,*)
     &        '>>>>>>>>>>>>>>>  PHONONS: preparation <<<<<<<<<<<<<'
         write(*,*)
     & ' Vm. Vibrations of molecules    || Vc. Crystals (point group)'
         write(*,*)
     & ' Vs. Crystals (space group)     || Vk. Crystals (k-points)'
         write(*,*)
         write(*,*)
     &        '>>>>>>>>>>>>>>>  PHONONS: calculation <<<<<<<<<<<<<'
         write(*,*)
     & ' V2. Vibrations [normal modes]  || V3. Vibrations application'
         write(*,*)
         write(*,*)
     &        '>>>>>>>>>>>>>>>>>  Miscellaneous  <<<<<<<<<<<<<<<'
         write(*,*)
     & ' Cm. Compare geometries         ||  D. Interatomic distances'
         write(*,*)
     & ' PE. Move atoms via symmetry    || Ch. Check a specified point'
         if(Which_Code.eq.'SIESTA' .or. Which_Code.eq.'  VASP'
     &          .or. Which_Code.eq.'VASP52') then
            write(*,*)
     &   ' AF. Script for AFM modelling   || Ew. Coulomb potential'
         else
            write(*,*)' Ew. Coulomb potential inside the unit cell'
         end if
         if(Which_Code.eq.'CASTEP') 
     &   write(*,*)' An. Animation XYZ file of the relaxation process'
         write(*,*)
     &     ' Sb. Save XYZ file in a box running across adjacent cells'
      end if   
 3    write(*,*)
      write(*,*)'---------- g e n e r a l  s e t t i n g s -----------'
c      write(*,*)' XY. Format of <geom.xyz> is set to '//YES_xyz
      if(Which_Code.eq.'SIESTA') then
        if(where_siesta.eq.'SIESTA') then
           write(*,*)' Ss. Save SIESTA settings with geometry'//
     &                                          ' from another XV file'
        else if(where_siesta.eq.'SIE-XV') then
           write(*,*)' Ss. Save geometry with SIESTA settings'//
     &                                         ' from another fdf file'
        end if
      else
         if(Which_Code.eq.'QUICKS') write(*,*)
     &       ' Ss. Update geometry from the QUICKSTEP output XYZ file'
      end if
      write(*,*) '  R. Read geometry from file    ||  S. Save'
      write(*,*) '  Q. Quit.'
      write(*,*)
      write(*,*)'Specify the character and press ENTER ------->'
      read (*,'(a)',err=1) cha2
      call right(cha2,2,l0)

c[B].......... generate primitive geometry from scratch

      IF(cha2(l0:).eq.'B') THEN
         Which_Code='   NEW'
         call initialise(nkp,read_c)
         write(8,*) 'The geometry  will be prepared!'
         call build_lat(okay)
         if(okay) then
            read_c=.true.
            Which_Code='  None'
         end if

c[Pc].......... primitive cell from space group

      ELSE IF(cha2(l0:).eq.'Pc') THEN
         Which_Code='   NEW'
         call initialise(nkp,read_c)
         write(8,*) 'The geometry  will be prepared!'
         call lattice_space(okay,nkp,kpoint,Which_Code)
         if(okay) then
            read_c=.true.
            Which_Code='  None'
         end if

c[R].......... read geometry from file

      ELSE IF(cha2(l0:).eq.'R') THEN
         Which_Code='   NEW'
         call initialise(nkp,read_c)
         write(*,*)'Read geometry from file!'
 11      call which_PW_code(Which_Code)
         seed0=seed
         l0seed0=l0seed
         if(Which_Code.ne.'   NEW') then
            call initiate(Which_Code,seed0,l0seed0,Err)
            read_c=.true.
            if(Err) go to 11
         end if

c[M].......... sophisticated modification of geometry file

      ELSE IF(cha2(l0:).eq.'M' .and. Which_Code.ne.'   NEW') THEN

         call change(nkp,kpoint,Which_Code)

c[KP].......... generating k-points

      ELSE IF(cha2(l0:).eq.'KP' .and. Which_Code.ne.'   NEW') THEN

         call problem(Which_Code,kpoint,nkp,YES_xyz)

c[Cl].......... Cluster

      ELSE IF(cha2(l0:).eq.'Cl') THEN

         if(Which_Code.ne.'   NEW') then
            okay=.true.
         else
            okay=.false.
         end if
         call cluster(okay)
         if(Which_Code.eq.'   NEW' .and. okay) then
            read_c=.true.
            Which_Code='  None'
         end if
         
c[La].......... build a layered system, e.g. for Stochastic Boundary Conditions
c               calculations

      ELSE IF(cha2(l0:).eq.'La') THEN

c         call onion_build(Which_Code)

c[Ew].......... Coulomb potential

      ELSE IF(cha2(l0:).eq.'Ew' .and. Which_Code.ne.'   NEW') THEN

         call Coulomb()

c[Vm]......... study vibrations of molecules: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vm' .and. Which_Code.ne.'   NEW') THEN

         system='MOLECULE'
         call mol_vibr(Which_Code,kpoint,nkp)

c[Vc]......... study vibrations of crystals: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vc' .and. Which_Code.ne.'   NEW') THEN

         system=' LATTICE'
         call mol_vibr(Which_Code,kpoint,nkp)

c[Vs]......... study vibrations of crystals: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vs' .and. Which_Code.ne.'   NEW') THEN

         system='LATT-TRA'
         call crystal_vibr(Which_Code,kpoint,nkp)

c[Vk]......... study vibrations of crystals: modify geometry file

      ELSE IF(cha2(l0:).eq.'Vk' .and. Which_Code.ne.'   NEW') THEN

         system=' K-POINT'
         call kpoint_vibr(Which_Code,kpoint,nkp)

c[V2]......... calculations of vibrational frequencies

      ELSE IF(cha2(l0:).eq.'V2' .and. Which_Code.ne.'   NEW') THEN

         call eig_vibr(Which_Code)

c[V3]......... application

      ELSE IF(cha2(l0:).eq.'V3' .and. Which_Code.ne.'   NEW') THEN

         call make_fcm(Which_Code)

c[AF]......... AFM imaging script

      ELSE IF(cha2(l0:).eq.'AF' .and. 
     &    (Which_Code.eq.'SIESTA' .or. Which_Code.eq.'  VASP'
     &                          .or. Which_Code.eq.'VASP52')) then

         call move_tip(Which_Code,nkp,kpoint)

c[Cm].......... compare geometry with the one in another file

      ELSE IF(cha2(l0:).eq.'Cm' .and. Which_Code.ne.'   NEW') THEN

         call compare()

c[Ge].......... dump Cartesian coordinates into XYZ file

      ELSE IF(cha2(l0:).eq.'Ge' .and. Which_Code.ne.'   NEW') THEN

c[D].......... study distances between atoms

      ELSE IF(cha2(l0:).eq.'D' .and. Which_Code.ne.'   NEW') THEN

         call distances()

c[Ch].......... check point in the cell

      ELSE IF(cha2(l0:).eq.'Ch' .and. Which_Code.ne.'   NEW') THEN

         call add_rem()

c[An]........... animation XYZ file after relaxation run

c      ELSE IF(cha2(l0:).eq.'An' .and. Which_Code.ne.'   NEW') THEN
      ELSE IF(cha2(l0:).eq.'An' .and. Which_Code.eq.'CASTEP') THEN

         call write_animate_xyz(Which_Code)

c[PE]........... moving atoms (for petential energy surfaces) keeping the
c                symmetry

      ELSE IF(cha2(l0:).eq.'PE' .and. Which_Code.ne.'   NEW') THEN

         call move_atoms(nkp,kpoint,Which_Code)

c[S]........... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S' .and. Which_Code.ne.'   NEW') THEN

         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

c[Ss]........... save final fdf file after relaxation (i.e. combine the latest
c                XV file with the initial fdf one)

      ELSE IF(cha2(l0:).eq.'Ss') THEN
         if(Which_Code.eq.'SIESTA') then
            call write_final_siesta()
         else if(Which_Code.eq.'QUICKS') then
            call write_final_cp2k()
         end if

c[Sb]........... create an XYZ file of a box running across adjacent cells

      ELSE IF(cha2(l0:).eq.'Sb' .and. Which_Code.ne.'   NEW') THEN

         call write_in_box(Which_Code,YES_xyz)

c[XY]...... ask which visualisation package

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='Ymol'
c         end if

c[Q]........... exit

      ELSE IF(cha2(l0:).eq.'Q') THEN
         close(8)
         stop "I owe you nothing!"
      ELSE
         write(*,*) 'Wrong! Try again!'
      END IF
      go to 1
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine initiate(Where_From,seed0,l0seed0,Err)
      include 'real8.inc'
      include 'tetrag1.inc'
      character Where_From*6,seed0*40
      logical Err
      Err=.false.
c
c_____________ read exisiting geometry file if entering for the first time
      relax_flag='T'
      Species='  '
      if(Where_From.eq.'CASTEP'.or.Where_From.eq.' CETEP'
     &     .or. Where_From.eq.'  VASP' .or. Where_From.eq.'VASP52') then
         call get_N_of_Atoms(Where_From,seed0,l0seed0,Err)
         if(Err) go to 19
         call get_geometry(Where_From,seed0,l0seed0,Err)
         if(Err) go to 19
c_____________ask species
         if(Where_From.ne.'VASP52') then
            call ask_species(Nsp,Species,0,Err)
            if(Err) go to 19
         end if
      else if(Where_From.eq.'SIESTA') then
         call get_all_from_SIESTA(seed0,l0seed0,Err)
         if(Err) go to 19
         where_siesta='SIESTA'
      else if(Where_From.eq.'SIE-XV') then
         call get_all_from_SIESTAXV(seed0,l0seed0,Err)
         if(Err) go to 19
         Where_From='SIESTA'
         where_siesta='SIE-XV'
      else if(Where_From.eq.'   XYZ') then
         call read_xyz(seed0,l0seed0,Err)
         if(Err) go to 19
         Where_From='  None'
      else if(Where_From.eq.'QUICKS') then
         call get_all_from_QUICKSTEP(Seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'    QE') then
         call get_all_from_QE(seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'CRYSTL') then
         call get_all_from_CRYSTAL(seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'LAMMPS') then
         call get_all_from_LAMMPS(seed0,l0seed0,Err)
         if(Err) go to 19
      else if(Where_From.eq.'    LM') then
c         call get_all_from_LM(seed0,l0seed0,Err)
         if(Err) go to 19

      end if

c_________ get atomic masses (in a.u.m.) for all species
      call get_masses()

c_________ calculate reciprocal lattice vectors in 2*PI units
      call INVER(AJ,BJ)
c
c_________ error
 19   if(Err) then
         write(*,*) '/---------------------------------------\\'
         write(*,*) '|  No file or Wrong format! Try again!  |'
         write(*,*)'\\---------------------------------------/'
      end if
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
   
      subroutine compare()
c..................................................................
c   Compare the current geometry with that in another file
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      character seed1*40,Which_Format*6,cha*2
      character Species1*2,relax_flag1,fl*4,fl1*4
      dimension r(3),fr(3)
      logical Err,Genrt1

      thresh=0.1
c
c............. read geometry from another file and keep in /buffer/

c___________ temporarily keep the current geometry in /buffer/
      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)

c___________ choose the read format and then read in the geometry
 11   call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
      if(Which_Format.eq.'  None') return
      call initiate(Which_Format,seed1,l0seed1,Err)
      if(Err) go to 11
c
c___________ check consistency first
      if(ITI.ne.ITI1 .or. Nsp.ne.Nsp1) go to 100
      do isp=1,Nsp
         if(NspN(isp).ne.NspN1(isp)) go to 100
         if(Species(isp).ne.Species1(isp)) go to 100
      end do
      ii=0
      do i=1,3
         do j=1,3
            if(abs(AX(i,j)-AJ(i,j)).gt.tiny_equiv) ii=ii+1
         end do
      end do
      if(ii.ne.0) then
         write(*,*)'MIND: Direct lattice vectors are different!'
      end if
c
c............. open the output file
c  current geometry     - in /buffer/ as ITI1, TI1, etc.
c  newly read geometry  - as ITI,TI, etc.
      
      write(*,*) 
     &     'File compare_to.dat is being created ...'
c     &     'File comp_to_'//seed1(l0seed1:)//'.dat is being created ...'
c      open(14,file='comp_to_'//seed1(l0seed1:)//'.dat',status='unknown')
      open(14,file='compare_to.dat',status='unknown')
      write(14,'(a,i5)')'# Number os species Nsp = ',Nsp
      write(14,'(a)')'# Number of atoms in every species:'
      write(14,'(10(i3,a,a,a))') (NspN(i),'[',Species(i),'] ',i=1,Nsp)

      write(14,'(a)')' #  '
      write(14,'(a)')' #  Lattice vectors'
      write(14,'(a)')' #  ^^^^^^^^^^^^^^^'
      write(14,'(a/)')
     & ' #                Current(=1st)                       Second' 
      write(*,'(a)')' #  '
      write(*,'(a)')' #  Lattice vectors'
      write(*,'(a)')' #  ^^^^^^^^^^^^^^^'
      write(*,'(a/)')
     & ' #                Current(=1st)                       Second' 

c___________ while comparing, take away the complete translations and
c            mark with * displacements larger than thresh

      do i=1,3
         write(14,'(a,i1,a,3(f10.5,x),5x,3(f10.5,x))') 
     &        '[',i,'] ',(AX(i,j),j=1,3),(AJ(i,j),j=1,3)
         write(*,'(a,i1,a,3(f10.5,x),5x,3(f10.5,x))') 
     &        '[',i,'] ',(AX(i,j),j=1,3),(AJ(i,j),j=1,3)
      end do

      write(14,'(/a)')' #  '
      write(14,'(a)')' #  In Cartesian coordinates'
      write(14,'(a)')' #  ^^^^^^^^^^^^^^^^^^^^^^^^'
      write(14,'(a)')
     &     ' #              Current (1st) position                  '//
     &     ' Additional (2nd) position              Displ (2nd - 1st)'
      write(*,'(/a)')' #  '
      write(*,'(a)')' #  In Cartesian coordinates'
      write(*,'(a)')' #  ^^^^^^^^^^^^^^^^^^^^^^^^'
      write(*,'(a)')
     &     ' #              Current (1st) position                  '//
     &     ' Additional (2nd) position              Displ (2nd - 1st)'

      nat=0
      do isp=1,Nsp
         write(14,*)
         write(14,'(a12,i2,a20)')
     &        '........ ',isp,' species '//Species(isp)//' ........'
         write(14,*)
         write(*,*)
         write(*,'(a12,i2,a20)')
     &        '........ ',isp,' species '//Species(isp)//' ........'
         write(*,*)

c_______________ take out the direct lattice part when comparing;
c                note that TI,TI1 are given in Cartesian coordinates!

         do i=1,NspN(isp)
            nat=nat+1
            r(1:3)=TI1(1:3,nat)-TI(1:3,nat) 
            do j=1,3
               frac=r(1)*BJ(j,1)+r(2)*BJ(j,2)+r(3)*BJ(j,3)
               frac=frac-int(frac)
               if(frac.gt.0.5) frac=frac-1.0
               if(frac.lt.-0.5) frac=frac+1.0
               fr(j)=frac
            end do
            r(1:3)=fr(1)*AJ(1,1:3)+fr(2)*AJ(2,1:3)+fr(3)*AJ(3,1:3)
            rr=sqrt(r(1)**2+r(2)**2+r(3)**2)
            if(rr.gt.thresh) then
               cha=' *'
            else
               cha='  '
            end if
            fl =' '//relax_flag(1,nat)//relax_flag(2,nat)//
     &                                               relax_flag(3,nat)
            fl1=' '//relax_flag1(1,nat)//relax_flag1(2,nat)//
     &                                              relax_flag1(3,nat)
            if(fl.ne.fl1) write(*,*) 
     &           ' <... WARNING: relaxation flags are different ...>'
            write(14,'(i4,3(1x,f12.6),a,3(1x,f12.6),a,3(1x,f12.6),a)')
     &        nat,(TI1(j,nat),j=1,3),fl1,(TI(j,nat),j=1,3),fl,
     ,                                                 (-r(j),j=1,3),cha
            write(*,'(i4,3(1x,f12.6),a,3(1x,f12.6),a,3(1x,f12.6),a)')
     &        nat,(TI1(j,nat),j=1,3),fl1,(TI(j,nat),j=1,3),fl,
     ,                                                 (-r(j),j=1,3),cha
         end do
      end do
      close (14)
      go to 200

c....... errors in comparability
 100  write(*,*)'The files are NOT compatible. ABORTING ...'

c___________ restore the original geometry from /buffer/
 200  call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,     Genrt)
      write(*,*)'Press ENTER when done ...'
      read(*,*)
      return
      end

      subroutine choose_dstn(K1,K2,i_Max,Method,iQuit)
c......................................................................
c      Choose two points K1 and K2 of interest and the maximal distance
c for images.
c.........................................................................
c Method='all_shortest ' - examination of ALL interatomic distances between
c                          ALL species (including images); only the shortest
c                          distance is chosen for each species; then, these 
c                          distances are ordered in increasing order;
c Method='pair_limiting' - for the given pair all the images in the right
c                          order will be given (up to desired number i_Max)
c.........................................................................
c iQuit = 0 - not quit, proceed with the procedure;
c         1 - quit, i.e. skip the procedure in the parent program.
c......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      logical numbers
      character Method*13
      data numbers/.false./
c
      Method='pair_limiting'
1     iQuit=0
      write(*,*)' '
      write(*,*)'..............MENU for exploring distances ...........'
      write(*,*)'......... Change these parameters if necessary: ......'
      write(*,*)
      write(*,*)'  0. Method for exploring distances: '//Method
      if(Method.ne.'all_shortest ') then
        if(.not.numbers) then 
          iQuit=1
          write(*,'(a)')
     ,   '   1. Pair of atoms to be studied: ....... undefined .......'
        else
          write(*,'(a34,i3,a5,i3)')
     ,   '   1. Pair of atoms to be studied: ',K1,' and ',K2
        end if
      end if
      if(Method.eq.'pair_limiting') write(*,'(a39,i3)')
     &           '   2. Number of spheres of images to be shown: ',i_Max
      write(*,'(a)')
     &         '   3. Calculate distances'
      write(*,'(a)')'   4. Quit: skip the step and do NOT proceed. '
      write(*,*)' '
      write(*,*)'------> Choose the item and press ENTER:'
      read(*,*,err=100) item
c
c__________ choose the method
c
      if(item.eq.0) then
         if(Method.eq.'pair_limiting') then
            Method='all_shortest '
         else 
            Method='pair_limiting'
         end if
c
c__________ choose two atoms
c
      else if(Method.eq.'pair_limiting' .and. item.eq.1) then
 10      write(*,*)'Specify atomic numbers K1 and K2:'
         read(*,*,err=10) K1,K2
         if(K1.lt.1.or.K2.lt.1) go to 10 
         if(K1.gt.ITI.or.K2.gt.ITI) go to 10 
         numbers=.true.
c
c__________  number of "spheres" of images
c
      else if(Method.eq.'pair_limiting' .and. item.eq.2) then
 11      write(*,*)'Give the number of spheres:'
         read(*,*,err=11) i_Max
         if(i_Max.le.0) go to 11
c
c__________ Quit or skip
c
      else if(item.eq.3) then
         if(iQuit.eq.0) return
         write(*,*)'ERROR! You still have undefined parameters!'
      else if(item.eq.4) then
         iQuit=1
         return  
      else
         write(*,*)'ERROR! Try again!'
      end if
      go to 1
c
c............. error
 100  write(*,*)'Incorrect item number! Try again!'
      go to 1
      end

      subroutine distances()
c..................................................................
c    Calculates interatomic distances for all pairs of specified 
c atoms including images from nearest 26 cells
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      parameter (N0LT0=N0LT*(1+N0LT)/2)
      dimension x(3),dist_short(N0LT0),distan(27),isort(N0LT0),
     ,          i1_all(N0LT0),i2_all(N0LT0)  
      character Method*13,line(27)*76
      data i_Max/1/, tiny/0.00001/
c
c_______ open coord.dat 
c
      OPEN(UNIT=7,FILE='distance.dat',form='formatted',
     ,                                  status='unknown',err=200)
      write(8,*)'The file distance.dat has been opened!'
c
c_____ menu
c
 10   call  choose_dstn(K1,K2,i_Max,Method,iQuit)
      if(iQuit.eq.1) then
        close (7)
        return
      end if
      write(7,*)'________ Method = ',Method,' _________'
      if(Method.eq.'pair_limiting') write(7,*)'K1=',K1,' and K2=',K2
c
c_____ scan all atoms in the cell
c
      i_all=0
      do 100 j=1,ITI
         jj=j ; jjj=ITI
         if(Method.eq.'pair_limiting' .and. K2.lt.K1) then
            jj=1 ; jjj=j
         end if
         if(Method.eq.'pair_limiting' .and. j.ne.K1) go to 100
         do 90 j1=jj,jjj
            if(Method.eq.'pair_limiting' .and. j1.ne.K2 ) go to 90
            i_all=i_all+1
c
c_____ distances between j and j1 for all images 
c
            short=100000.0
            i=0
            do i1=-1,1
               do i2=-1,1
                  do 3 i3=-1,1
                     if(j.eq.j1 .and. i1.eq.0 .and. i2.eq.0
     &                                        .and. i3.eq.0) go to 3 
                     i=i+1
                     x(1)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+TI(1,j1)
                     x(2)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+TI(2,j1)
                     x(3)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+TI(3,j1)
                     ar=sqrt( (x(1)-TI(1,j))**2 + (x(2)-TI(2,j))**2 + 
     +                    (x(3)-TI(3,j))**2 )
                     if(ar.le.short) short=ar  
                     write(line(i),1) 'ijk[',i1,',',i2,',',i3,']: {',
     ,                    TI(1,j),',',TI(2,j),',',TI(3,j),'} and {', 
     ,                    x(1),',',x(2),',',x(3),'} => ',ar,' A'
                     distan(i)=ar
 3                continue
               end do
            end do
            dist_short(i_all)=short
            i1_all(i_all)=j
            i2_all(i_all)=j1
 90      continue
 100  continue
 1    format(a4,2(i2,a1),i2,a4,2(f6.3,a1),f6.3,a7,
     &     2(f6.3,a1),f6.3,a5,f6.3,a2)
c
c_____ give the info due to the method chosen
c
      if(Method.eq.'pair_limiting') then
c
c_____ pair-limiting case: all the distances in the right order for the
c      given pair (only i_Max spheres; it is monitored by iM)
c     
         ii=26
         if(K1.ne.K2) ii=27 
         call sort(distan,ii,isort)
         iM=1 
         d=distan(isort(1))
         write(7,*)'_____ result _____'
         do i=1,ii
            if(abs(distan(isort(i))-d).gt.tiny) then
               iM=iM+1
               d=distan(isort(i))
            end if
            if(iM.le.i_Max) then
               write(*,'(a)') line(isort(i))
               write(7,'(a)') line(isort(i))
           end if
        end do
c
c_____ all-shortest case: we give all the shortest distances for all
c      pairs in the right order
c
      else 
         iT=ITI*(ITI+1)/2
         call sort(dist_short,iT,isort)
         write(7,*)'_____ result _____'
         do i=1,iT
            is=isort(i)
            write(*,'(a6,i3,a5,i3,a4,f10.5)') 
     &   'atoms ',i1_all(is),' and ',i2_all(is),' => ',dist_short(is)
            write(7,'(a6,i3,a5,i3,a4,f10.5)') 
     &   'atoms ',i1_all(is),' and ',i2_all(is),' => ',dist_short(is)
         end do
      end if
      go to 10
c
c.... errors
200   write(*,*)'FATAL! Cannot open distance.dat file'
      return
      end

      subroutine problem(Which_Code,kpoint,nkp,YES_xyz)
      include 'real8.inc'
      include 'tetrag1.inc'
      character Which_Code*6,YES_xyz*4,cha2*2
      double precision kpoint(Nkpoint,3)

c...................................................................
c............. Choose the problem: DOS or BAND structure ...........
c...................................................................
c
      kpmethod='  mp'
      z_supp =.false.
 2    write(*,*)
     &     '/-------------------------------------------------\\'
      write(*,*)
     &     '|................. K-point menu ..................|'
      write(*,*)
     &    '\\-------------------------------------------------/'

      if(.not.z_supp) then
         write(*,*)'     0. BULK calculation'
         call INVER(AJ,BJ0)
      else
         write(*,*)
     &   '     0. SLAB calculation: suppressed Z coord. in the k-space'
         call INVER2(AJ,BJ0)
      end if
      write(*,'(10x,a)')'NEW reciprocal lattice vectors (up to 2*PI):'
      write(*,'(10x,a,3(x,f10.5))') 'BJ0(1):   ',(BJ0(1,i),i=1,3)
      write(*,'(10x,a,3(x,f10.5))') 'BJ0(2):   ',(BJ0(2,i),i=1,3)
      write(*,'(10x,a,3(x,f10.5))') 'BJ0(3):   ',(BJ0(3,i),i=1,3)

      write(*,*)'     1. DOS '
      write(*,*)'     2. BAND: eigenvalues along a k-direction'
      write(*,*)'     3. Self-consistent (ordinary) calculation'
      if(nkp.ne.0) write(*,*)'     S. Save'
      write(*,*)'     Q. Return to the main menu'
      write(*,*)
      write(*,*)'Specify the character and press ENTER ------->'
      read (*,'(a)',err=2) cha2
      call right(cha2,2,l0)

c[0]........... slab/bulk

      IF(cha2(l0:).eq.'0') THEN

         if(z_supp) then
            z_supp=.false.
         else
            z_supp=.true.
         end if

c[1]........... DOS

      ELSE IF(cha2(l0:).eq.'1') THEN

         write(8,*)'...............................................'
         write(8,*)'... I am going to prepare an input for DOS ....'
         write(8,*)'...............................................'
         call DOS_kp(Which_Code,kpoint,nkp)

c[2]........... band

      ELSE IF(cha2(l0:).eq.'2') THEN

         write(8,*)'...............................................'
         write(8,*)'... I am going to prepare an input for BAND ...'
         write(8,*)'...............................................'
         call BAND_kp(Which_Code,kpoint,nkp)

c[3]........... scf

      ELSE IF(cha2(l0:).eq.'3') THEN

         write(8,*)'...............................................'
         write(8,*)'... I am going to prepare an input for SCF ....'
         write(8,*)'...............................................'
         call Manh_Pack(Which_Code,kpoint,nkp)

c[S]........... save

      ELSE IF(cha2(l0:).eq.'S' .and. nkp.ne.0) THEN

         write(8,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

c[Q]........... leave menu

      ELSE IF(cha2(l0:).eq.'Q') THEN

         write(8,*)'... Buy.'
         return
      else
         write(*,*)'Incorrect item number! Try again!'
      end if
      go to 2
      end

      subroutine get_masses()
      include 'real8.inc'
      include 'mendeleev.inc'
      include 'tetrag1.inc'
      logical Err
      do is=1,Nsp
         call check_Mendel(Species(is),k,Err,.true.)
         if(.not.Err) then
            AtMass(is)=At_Masses(k)
         else
            AtMass(is)=1000.0
         end if
         if(AtMass(is).eq.0.0) then
            write(*,*)
     &  'ERROR! Atomic mass for '//Species(is)//' is NOT available!'
            write(*,*)'Press ENTER when ready ...'
            read(*,*)
         end if
      end do
      return
      end

      subroutine initialise(nkp,read_c)
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'siesta.inc'
      logical read_c
      nkp=0
      nlines=0
      read_c=.false.
      do k=1,N0LT
         relax_flag(1,k)='T'
         relax_flag(2,k)='T'
         relax_flag(3,k)='T'
      end do
      do is=1,N0KD
         Species(is)='  '
      end do
      ITI=0
      return
      end

      subroutine ask_species(Nsp,Species,UNIT,Err)
c.......................................................................
c Two options: 
c    UNIT=0     -> ask to enter from keyboard 
c    otherwise  -> read all from a single Line from unit UNIT
c.......................................................................
      character Species(Nsp)*2,cha2*2,line*200
      integer LinEnd(100),LinPos(100), UNIT
      logical Err,found
c
 10   found=.false. ;  Err=.false. 
      if(UNIT.ne.0) then
         call CutStr(Line,NumLin,LinPos,LinEnd,UNIT,0,iErr)
         if(NumLin.eq.Nsp .and.iErr.eq.0) found=.true.
      end if
c
      do i=1,Nsp

 1       write(*,'(a25,i3,a8)')'___> Atoms in species ',i,' <____'
         if(.not.found) then
            write(*,'(a,i5,a)')
     &           'Chemical element (character*2) of species ',i,' ?'
            read(*,'(a)') cha2
            call right(cha2,2,l0)
            if(l0.eq.2) then
               Species(i)=' '//cha2(l0:)
            else
               Species(i)=cha2
            end if
         else
            i0=LinEnd(i)-LinPos(i)+1 ; if(i0.gt.2) go to 200
            if(i0.eq.1) then
               Species(i)=' '//line(LinPos(i):LinEnd(i))
            else if(i0.eq.2) then
               Species(i)=line(LinPos(i):LinEnd(i))
            end if
         end if

c___________ checking from NAZV
         call check_Mendel(Species(i),k,Err,.true.)
         if(Err) then
            if(UNIT.eq.0) then
               go to 1
            else
               go to 10
            end if
         end if

c___________ checking if = to that given previously
         if(i.gt.1) then
            do ii=1,i-1
               if(Species(i).eq.Species(ii)) then
                  write(*,'(2(a,i3),a)')
     &      'ERROR! Species ',i,' and ',ii,' are the same. Try again!'
                  if(UNIT.ne.0) go to 200
                  go to 1
               end if
            end do
         end if
            
      end do
      return
c............ errors
 200  write(*,*) 'ERROR in reading species'
      Err=.true.
      end

      subroutine write_final_cp2k()
c.............................................................................
c reads the CP2K output xyz file with the latest geometry (as geometries at
c all iterations are given in the file, only the latest is needed) and writes
c the final seed.inp file with the new geometry keeping all other stuff intack
c.............................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      integer LinEnd(100),LinPos(100)
      character seed1*40,cha2*2,spc*2,line*200
      double precision kpoint(Nkpoint,3)
c
c............ open the xyz file 
c
 1    write(*,*)'Specify the output XYZ file from your QUICKSTEP run:'
      write(*,'(/a)')'**** XYZ files in the current directory: ***'
      call system('ls *.xyz ')
      write(*,'(a)') '************************************************'
      write(*,'(a)') '*** Full name to be given including extention **'
      write(*,'(a/)')'************************************************'
      read(*,'(a)') seed1
      call right(seed1,40,l0seed1)
      open(13,file=seed1(l0seed1:),status='old',err=10)
      read(13,*,err=8) nn
      if(nn.ne.ITI) then
         write(*,*) 'ERROR: wrong number of atoms'
         write(*,*) 'ERROR: *.XYZ is inconsistent with *.INP file'
         close (13) ; go to 1
      end if
c
c............. read the new geometry
c      
c______________ find the number j of geometry blocks      

      j=0
      do
         read(13,'(a)',err=8,end=2) line
         if(index(line,'i =').ne.0) then
            j=j+1 ; write(*,*) 'geometry found = ',j
         end if
      end do
 2    write(*,*)'... ',j,' geometries found ...'

c______________ read geometry from the last block

      rewind (13) ; j0=0
      do 
         read(13,'(a)',err=8) line
         if(index(line,'i =').ne.0) j0=j0+1
         if(j.eq.j0) exit
      end do
      nat=0
      do isp=1,Nsp
         do n=1,NspN(isp)
            nat=nat+1
            call CutStr(Line,NumLin,LinPos,LinEnd,13,0,iErr)
            cha2=line(LinPos(1):LinEnd(1)) ; call right(cha2,2,l0)
            spc=cha2 ; if(l0.eq.2) spc=' '//cha2(l0:)
            if(spc.ne.Species(isp)) then
               write(*,*)'ERROR:  wrong order of species'
               write(*,*)'ERROR: *.XYZ is inconsistent with *.INP file'
               close (13) ; go to  1
            end if
            read(line(LinPos(2):),*,err=8,end=8) TI(1:3,nat)
         end do
      end do
      write(8,*)'... the geometry was read successfully! ...'
      close (13) ; go to 20
 8    write(*,*)'ERROR: cannot read atomic coordinates'
 10   write(*,*)'ERROR! File '//seed1(loseed1:)//' is bad.'
      close(13)
      go to 1
c
c............... write the new file
c
 20   write(8,*)'... writing geometry and k-points ...'
      call write_kp(0,kpoint,'QUICKS',YES_xyz,.false.)
      write(8,*)'Done!'
      return
      end

 
