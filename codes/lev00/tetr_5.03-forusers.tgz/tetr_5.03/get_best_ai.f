      subroutine get_best_AI(AJ,HH,KK,LL,IJ,xn,icase,iPrnt)
      include 'real8.inc'
c.....................................................................
c    A new set of unit cell (UC) direct lattice vectors AJ(#,xyz) of 
c minimal length is built here from incoming basic vectors AJ(#,xyz). 
c    The new set gives the same unit cell volume and the first two 
c vectors will lie in the plane specified either by:
c      icase=0 - three Miller's indices HH,KK,LL;
c      icase=1 - normal vector xn().
c....................................................................
c     The method works as follows: first, one shortest possible
c lattice vector lying in the plane is built. This is done by Evien's 
c type "shells". Then, starting from the same shell, we run the same 
c algorithm again for lattice vectors which are not parallel to the 
c first one chosen and again we choose the shortest possible in the plane. 
c Then, finally, the third vector is chosen which has a non-vanishing 
c component normal to the plane.
c....................................................................
c     During every search we always check two more "shells" to make
c sure that there are no more vectors shorter than the one already 
c found.
c....................................................................
      dimension Xs(3),AJ(3,3),AJ1(3,3),xn(3),IJ(3,3)
      logical found,current,answer
      integer HH,KK,LL,icase
      data tiny/0.000001/
c
c...... save AJ in AJ1
c
      call send(AJ,3,3,AJ1)
c
c...... UC volume
c
      DET1= AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(2,3)*AJ(3,2))
     *    -AJ(2,1)*(AJ(1,2)*AJ(3,3)-AJ(1,3)*AJ(3,2))
     *    +AJ(3,1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2))
c
c....... The both lattices are built by shells numbered using the.......
c   index N=0,1,2,... where N=0 belongs to the 0 site; inside every
c   shell the lattice vectors are computed as N1*a1+N2*a2+N3*a3,
c   where a1,a2,a3 are basic translations AJ.
c.... found =.true. -  if a successful vector is found at all
c    current=.true. -  if a successful vector is found in the current shell
c....... i_luc - is used to count new UC basic lattice vectors being built
c
      i_luc=1
 10   found=.false.
      xsl_min=1.0e+10 ; vol_min=1.0e+10

      N=0
 30   N=N+1
      current=.false.
      do N3=-N,N
         do N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
c     
c____________ summation over the direct lattice
               Xs(1)=N1*AJ1(1,1)+N2*AJ1(2,1)+N3*AJ1(3,1)
               Xs(2)=N1*AJ1(1,2)+N2*AJ1(2,2)+N3*AJ1(3,2)
               Xs(3)=N1*AJ1(1,3)+N2*AJ1(2,3)+N3*AJ1(3,3)
c     
c_________________ check for the first two lattice vectors if they lie
c                  in the plane perpendicular to the HH,KK,LL reciprocal
c                  lattice vector
c     
               if(iPrnt.ge.13) write(9,*) 'N=',N,'    ',N1,N2,N3
               if(i_luc.ne.3) then
                  if(icase.eq.0) then
                     if(HH*N1+KK*N2+LL*N3.ne.0) go to 250
                  else if(icase.eq.1) then
                     sp=abs(Xs(1)*xn(1)+Xs(2)*xn(2)+Xs(3)*xn(3))
                     if(sp.gt.tiny) go to 250
                  end if
               end if 
c
c_________________ check if the vector Xs is linearly dependent with
c                  the previously found AJ-vectors or not
               if(i_luc.ne.1) then
                  call ask_lin_dep(Xs,AJ,i_luc-1,answer)
                  if(answer) go to 250
               end if
c     
c_________________ check its lenght
               xsl= sqrt( Xs(1)*Xs(1) + Xs(2)*Xs(2) + Xs(3)*Xs(3) )
               if(iPrnt.ge.13) 
     &              write(9,'(a,3(1x,f10.5),3x,f10.5,2(x,l1))')
     &              ' xs => ',(Xs(i),i=1,3),xsl,found,current
               if(i_luc.lt.3) then
                  if(xsl.ge.xsl_min) go to 250
               else
                  vol= abs(AJ(1,1)*(AJ(2,2)*Xs(3)-AJ(2,3)*Xs(2))
     *                 -AJ(2,1)*(AJ(1,2)*Xs(3)-AJ(1,3)*Xs(2))
     *                 +Xs(1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2)))
                  if(vol.gt.vol_min) then
                     go to 250
                  else if(abs(vol-vol_min).lt.tiny) then
                     if(xsl.ge.xsl_min) go to 250
                  end if
               end if
c     
c_________________ okay, accept it!
 40            xsl_min=xsl 
               if(i_luc.eq.3) vol_min=vol
               AJ(i_luc,1:3)=Xs(1:3)
               IJ(i_luc,1)=N1 ; IJ(i_luc,2)=N2 ; IJ(i_luc,3)=N3
               found=.true. ; current=.true.
               if(iPrnt.ge.13)write(9,'(a,i1,3(1x,f10.5),5x,f10.5,2l1)')
     &              '__found so far__ ',i_luc,(AJ(i_luc,j),j=1,3),
     ,              xsl_min, found,current
c     
 250        end do
         end do
      end do
c
c........ if not found, go to the next shell
c
      if(.not.found) go to 30
c
c........ if found for the first time, go for another two shells
c
      if(found) then
         if(current) then
            ishell=1
         else
            if(iPrnt.ge.13) write(9,*) 'isehll=',ishell
            if(ishell.eq.2)  go to 50
            ishell=ishell+1
         end if
      end if
      go to 30
c
c........ build the next vector now starting from the very beginning again
c
 50   if(i_luc.lt.3) then
         i_luc=i_luc+1
         if(iPrnt.ge.13) 
     &        write(9,'(a,i1)') '========> going to i_luc=',i_luc
         go to 10
      end if
c
c...... check the new UC volume
c
      DET= AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(2,3)*AJ(3,2))
     *    -AJ(2,1)*(AJ(1,2)*AJ(3,3)-AJ(1,3)*AJ(3,2))
     *    +AJ(3,1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2))
      if(abs(abs(DET1/DET)-1.0).gt.tiny) then
         write(*,*)'BAD news! New UC has a different volume.'
         write(*,*)'UNDO this step, please, and report the problem'
      end if
c
c............ print
      if(iPrnt.ge.13) then
         write(9,'(a)')'..get_best_ai.. old UC vectors AJ1:'
         write(9,'(a,3(1x,f10.5))') 'AJ1(1, ) => ', (AJ1(1,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ1(2, ) => ', (AJ1(2,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ1(3, ) => ', (AJ1(3,j),j=1,3)
         write(9,'(a)')'..get_best_ai.. new UC vectors AJ:'
         write(9,'(a,3(1x,f10.5))') 'AJ(1, ) => ', (AJ(1,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ(2, ) => ', (AJ(2,j),j=1,3)
         write(9,'(a,3(1x,f10.5))') 'AJ(3, ) => ', (AJ(3,j),j=1,3)
      end if
      end

      subroutine send(X,n,m,Y)
      include 'real8.inc'
c................. matrix X(n,m) is copied into matrix Y
      dimension X(n,m),Y(n,m)
      Y=X
      end

      subroutine ask_lin_dep(Xs,AJ,i_chk,answer)
c...................................................................
c     Checks if vector Xs is linearly dependent on i_chk vectors
c AJ(#,xyz), #=1,...,i_chk  (i_chk is either 1 or 2).
c
c OUTPUT:  answer=.true. if vector Xs is linearly dependent.
c                                     ^^
c...................................................................
      include 'real8.inc'
      dimension Xs(3),AJ(3,3),Z(3)
      data tiny/0.0000001/
      logical answer

      answer=.false.

      if(i_chk.eq.1) then
c.......... If i_chk=1, then we simply check if they are collinear
         xsl= sqrt(Xs(1)*Xs(1) + Xs(2)*Xs(2) + Xs(3)*Xs(3))
         ajl= sqrt(AJ(1,1)*AJ(1,1) + AJ(1,2)*AJ(1,2) + AJ(1,3)*AJ(1,3))
         scalr=abs(AJ(1,1)*Xs(1) + AJ(1,2)*Xs(2) + AJ(1,3)*Xs(3))
         if(abs(scalr-xsl*ajl).lt.tiny) answer=.true.
      else
c.......... If i_chk=2, then we check if Xs is perpendicular to
c           the vector product of the two AJ's or not
         Z(1)=AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2)
         Z(2)=AJ(1,3)*AJ(2,1)-AJ(1,1)*AJ(2,3)
         Z(3)=AJ(1,1)*AJ(2,2)-AJ(1,2)*AJ(2,1)
         scalr=Z(1)*Xs(1) + Z(2)*Xs(2) + Z(3)*Xs(3)
         if(abs(scalr).lt.tiny) answer=.true.
      end if
      end
