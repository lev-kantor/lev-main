      program get_forces
c.........................................................................
c (1) finds atomic forces in VASP or SIESTA ouput files on the LAST ionic
c     relaxation step, and writes them into tmp.f file
c (2) if tip-atoms are specified, then forces on all tip atoms are read in 
c     explicitly and then summed up to get the tip force which is also 
c     printed into the tmp.f file as well as on the screen
c.........................................................................
c syntax:
c ^^^^^^^
c              get_forces verbose file [tip-atoms]
c where:
c       verbose = F or T for printing on the screen information messages 
c       file - name of the file containing forces
c       tip-atoms (optional) - atominc numbers belonging to the tip; it is
c                              also checked if VASP/SIESTA finished 
c                              relaxing the geometry; if NOT, then instead
c                              of forces an ERROR message is given 
c.........................................................................
      include 'tetr_param.inc'
      double precision fx,fy,fz
      character FilNam*80,line*200,code*6,string(5)*22,verbose
      character tip_ats*1000,fstring(3)*22,line1*200,vstring(2)*6
      double precision tip_force(3),f(3)
      integer LinEnd(100),LinPos(100)
      logical ver,listat(N0LT),Forces,Force_Fin
      data vstring/'vasp.4','vasp.5'/
      data string/ 'TOTAL-FORCE (eV/Angst)', 'sta: Atomic forces (eV',
     ,             'TOTAL-FORCE (eV/Angst)', 'ATOMIC FORCES in [a.u.',
     ,             'ITEM: ATOMS x y z fx f'/
      data fstring/'reached required accur','outcoor: Relaxed atomi',
     ,             'reached required accur'/
      do i=1,N0LT
         listat(i)=.false.
      end do

c........... get the OUTCAR file name
      i0=iargc()
      if(i0.lt.2) then
         write(6,*) 'Syntax ERROR:'
         write(6,*) 'Name of the OUTCAR file and verbose flag',
     &              ' must be given. Stop.'
         stop 'ERROR in command line'
      end if
      call getarg(1,verbose)
      if(verbose.eq.'F') then
          ver=.false.
      else 
          ver=.true.
      end if
      call getarg(2,FilNam)
      call right(FilNam,80,leng)

c........... check if the tip force is to be calculated
      Forces=.false.
      if(i0.eq.3) then
         if(ver) write(*,*)'Tip force will be calculated'
         call getarg(3,tip_ats)
         call right(tip_ats,100,lent)
         if(ver) write(*,*)'Tip atoms are: ',tip_ats(lent:)
         call CutStr(tip_ats,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.eq.1) go to 200
         do i=1,NumLin
            do j=LinPos(i),LinEnd(i)
               if(tip_ats(j:j).eq.'-') go to 2
            end do
            read(tip_ats(LinPos(i):LinEnd(i)),*,err=200) n1
            n2=n1
            go to 4
2           read(tip_ats(LinPos(i):j-1),*,err=200) n1
            read(tip_ats(j+1:LinEnd(i)),*,err=200) n2
4           do n=n1,n2
               listat(n)=.true.
            end do
         end do
         Forces=.true.
      end if

c........... open the file and determine the code (vasp/siesta/cp2k/lammps)

      open(1,file=FilNam(leng:),form='formatted',status='old',err=100)

c_______ try VASP

      call find_string(string(1),22,1,iErr)
      if(iErr.eq.0) then
         if(ver) write(*,*)'>>>>> Get_Forces: this IS vasp <<<<<'
         rewind(1)
         call find_string(vstring(2),6,1,iErr)
         if(iErr.eq.0) then
            code='vasp52' ; icode=3 ; go to 5
         else
            code=' vasp ' ; icode=1 ; go to 5
         end if
      else
         if(ver) then
            write(*,*)'>>>>> Get_Forces: this is NOT vasp <<<<<'
            write(*,*)'>>>>> trying SIESTA/CP2K/LAMMPS ...' 
         end if
      end if

c_______ try SIESTA

      rewind(1)
      call find_string(string(2),22,1,iErr)
      if(iErr.eq.0) then
         if(ver) write(*,*)'>>>>> Get_Forces: this IS siesta <<<<<'
         code='siesta' ; icode=2 ; go to 5
      else
         if(ver) then
            write(*,*)'>>>>> Get_Forces: this is NOT siesta <<<<<'
            write(*,*)'>>>>> trying CP2K/LAMMPS ...' 
         end if
      end if

c_______ try CP2K

      rewind(1)
      call find_string(string(4),22,1,iErr)
      if(iErr.eq.0) then
         if(ver) write(*,*)'>>>>> Get_Forces: this IS cp2k <<<<<'
         code='cp2k  ' ; icode=4 ; go to 5
      else
         if(ver) then
            write(*,*)'>>>>> Get_Forces: this is NOT cp2k <<<<<'
            write(*,*)'>>>>> trying LAMMPS ...' 
         end if
      end if

c_______ try LAMMPS

      rewind(1)
      call find_string(string(5),22,1,iErr)
      if(iErr.eq.0) then
         if(ver) write(*,*)'>>>>> Get_Forces: this IS LAMMPS <<<<<'
         code='lammps' ; icode=5
      else
         if(ver) then
            write(*,*)'>>>>> Get_Forces: this is NOT LAMMPS <<<<<'
            write(*,*)'ERROR! Unknown code - UNSUPPORTED!'
            stop
         end if
      end if

 5    if(ver) write(*,'(a)')'code='//code
c
c.................. determine if the relaxation finished
c
      if(Forces) then
         rewind (1)
         call find_string(fstring(icode),22,1,iErr)
         if(iErr.eq.1) then
            if(ver) write(*,*) 'ERROR: relaxation has NOT finished yet'
            Force_Fin=.false.
         else
            if(ver) write(*,*) 'Structural RELAXATION finished - Fine!'
            Force_Fin=.true.
         end if
      end if
c
c.................. determine the last printout of forces
c
      rewind (1)
      i=0
 3    call find_string(string(icode),22,1,iErr)
      if(iErr.eq.0) then
          i=i+1
          go to 3
      end if
      if(ver) write(*,*)
     &     'The string "',string(icode),'" was found ',i,' times'
      rewind (1)
c__________________ if for vibrations, then read the very first forces only
c (since in the case of siesta it writes 'siesta:' in the 2nd printout)
c      if(.not.Forces) i=1
      do j=1,i
        call find_string(string(icode),22,1,iErr)
      end do
c
c................... read the last forces and calculate the tip force
c                    if required
c
      tip_force(1:3)=0.0

      open(2,file='tmp.f',form='formatted',status='unknown')
      if(code.eq.' vasp ' .or. code.eq.'vasp52') then
         read(1,'(a)')
      else if(code.eq.'cp2k  ') then
         read(1,'(a)') ; read(1,'(a)') 
      end if
      i=0
 1    i=i+1
      read(1,'(a)',end=100,err=100) line
      if(icode.eq.4) then
         if(index(line,'SUM OF ATOMIC FORCES').ne.0) go to 10
      else
         if(index(line,'-----').ne.0) go to 10
      end if
c
c____________ in the case of siesta we need to analyse the lines
c             since sometimes some stupid nessages come across
c             which we have to get rid off
c
      call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
      if(code.eq.'siesta') then
         if(Line(LinPos(1):LinEnd(1)).ne.'siesta:') go to 1
         read(line(LinPos(2):),*,err=11) natom,fx,fy,fz
         go to 21
 11      write(*,*)'WARNING: problem for atom ',i,' in SIESTA output'
         write(*,*)'         Trying to resolve ...'
         do k=1,LinEnd(NumLin)
            if(Line(k:k).eq.'*') then
               k_star=k
               go to 12
            end if
         end do
         go to 300
 12      read(1,'(a)',end=100,err=100) line1
         call CutStr(Line1,NumLin,LinPos,LinEnd,0,0,iErr)
         line=Line(1:k_star-1)//line1(1:LinEnd(NumLin))
      end if

 21   if(listat(i)) then
         call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
         if(code.eq.' vasp ' .or. code.eq.'vasp52' ) then
            read(Line(LinPos(4):LinEnd(6)),*,err=100) f
         else
            if(Line(LinPos(1):LinEnd(1)).eq.'siesta:') then
               read(Line(LinPos(3):LinEnd(5)),*,err=100) f
            else
               read(Line(LinPos(2):LinEnd(4)),*,err=100) f
            end if
         end if
         if(ver) write(*,'(i5,a,3(e16.10,x))') i,' atom force is ',f
         tip_force(1)=tip_force(1)+f(1)
         tip_force(2)=tip_force(2)+f(2)
         tip_force(3)=tip_force(3)+f(3)
      end if    
c      if(index(line,'-----').ne.0) go to 10
      write(2,'(a)') trim(line)
      go to 1

 10   if(ver) write(*,*)'Found ',i-1,' forces in this file'
      write(2,*)'Tip force is (in eV/A):'
      write(2,'(3(e16.10,x))') tip_force
      close (1)
      close (2)
      if(Forces) then
         if(Force_Fin) then
            if(ver) write(*,*)'Tip force is (in eV/A):'
            write(*,'(3(e16.10,x))') tip_force
         else
            write(*,'(a)') 'ERROR: relaxation NOT finished!'
         end if
      end if
      stop
c
c....... errors
c
 100  write(*,*)'ERROR! File '//FilNam(leng:)//' is bad or absent'
      stop 'ERROR in openning/reading DFT output file' 
 200  write(*,*)'ERROR in reading the list of tip atoms'
      stop 'ERROR in the list of atoms'
 300  write(*,*)'ERROR in reading forces: check SIESTA output file'
      stop 'ERROR in reading SIESTA forces'
      end

      subroutine right(char,len,leng)
      character*(*)  char
      do i=len,1,-1
         j=i
         if(char(i:i).ne.' ') go to 1
      end do
 1    jj=len-j
      do i=j,1,-1
         char(jj+i:jj+i) = char(i:i)
      end do
      do i=1,jj
         char(i:i)=' '
      end do
      leng=jj+1
      return
      end

      subroutine find_string(string,l,NFIL,iErr)
      character*(*) string
      character line*200
c
      iErr=0
10    read (NFIL,'(a)',END=40,ERR=40) Line
      i0=index(Line,string(1:l))
      if(i0.eq.0) go to 10
c      write(*,'(/a)')
c     & '.........O.K.! String '//string(1:l)//' is found !!! .........'
      return
 40   iErr=1
      end

       subroutine CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iCom,iErr)
c.................................................................
c....It reads the line from the file UNIT=NFIL as a string   .....
c.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
c.... substrings. Their number is NumLin, while starting and .....
c.... ending positions are LinPos and LinEnd.                .....
c.................................................................
c Up to 100 substrings is implied to be in the initial string Line.
c.................................................................
c  If NFIL=0 it is assumed that the string Line*80 exists and
c  must not be read from the external source, but must be taken
c  as an input from the parent program
c.................................................................
c  iErr=1 in the case of error input; oterwise iErr=0
c.................................................................
c  Commas are also interpreted as string division symbols 
c  alongside spaces if iCom=1; not, if iCom=/=1.
c.................................................................
c
      character Line*100,cha
      integer LinEnd(100),LinPos(100)
      iErr=0
      NumLin=0
      icase=0
c............ replace commas, if present, by spaces
      if(iCom.eq.1) then
         do i=1,100
            if(Line(i:i).eq.',') Line(i:i)=' '
         end do
      end if
c............ Loop over all characters in the Line(1:80)............
      do 5 i=1,100
         i0=i
         cha=Line(i:i)
c________ if the 1st not blank character is found
         if(cha.ne.' '.and.cha.ne.'	'.and.icase.eq.0) then
            NumLin=NumLin+1
            if(NumLin.gt.100) go to 10
            LinPos(NumLin)=i
            icase=1
         end if
c_________ if the 1st blank character is found after the substring
         if(cha.eq.' '.and.icase.eq.1) then
            LinEnd(NumLin)=i-1
            icase=0
         end if
 5    end do
      if(icase.eq.1) LinEnd(NumLin)=100
      return
 10   iErr=1
      return
      end
