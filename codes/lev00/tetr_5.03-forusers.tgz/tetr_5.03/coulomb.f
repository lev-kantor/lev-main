      subroutine Coulomb()
c.........................................................................
c  Calculates the Coulomb potential from point-ion lattice in an arbitrary
c point inside the UC (interactively).
c.........................................................................
c Charge(species) - ionic charge on each species;
c Q(ion) - ionic charge on each ion in the cell.
c.........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      logical verbose,Yes_Pot
      dimension Charge(N0KD),Q(N0LT),Point(3),a(3),verb(N0LT)
      data Point/3*0.0/,EPSew/1.0E-10/,factor/1.0/
c
c....... open the file for the output
c
      write(*,*)
     &     'The file <madel.dat> for the output is being opened ...'
      open(UNIT=19,FILE='madel.dat',form='formatted',status='unknown',
     ,                                       err=200) 
c
c.......... unit cell volume Vc
c
      Vc= abs( AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(2,3)*AJ(3,2))
     *        -AJ(2,1)*(AJ(1,2)*AJ(3,3)-AJ(1,3)*AJ(3,2))
     *        +AJ(3,1)*(AJ(1,2)*AJ(2,3)-AJ(1,3)*AJ(2,2)))
c
c.......................................................................
c       The "best" Ewald constant gEwald is estimated as:
c
c              gEwald**2 = BJ_min/(2*AJ_min)
c
c  where BJ_min and AJ_min are the minimal inverse and direct lattice
c  vectors, respectively.
c.......................................................................
      AJ_min=100000.0
      BJ_min=100000.0
      do n1=-1,1
         do n2=-1,1
            do 10 n3=-1,1
               if(n1.eq.0 .and. n2.eq.0 .and. n3.eq.0) go to 10
c_______ find AJ_min
               a(1)=n1*AJ(1,1)+n2*AJ(2,1)+n3*AJ(3,1)
               a(2)=n1*AJ(1,2)+n2*AJ(2,2)+n3*AJ(3,2)
               a(3)=n1*AJ(1,3)+n2*AJ(2,3)+n3*AJ(3,3)
               aa=sqrt(a(1)*a(1)+a(2)*a(2)+a(3)*a(3))
               if(aa.le.AJ_min) AJ_min=aa
c_______find BJ_min
               a(1)=n1*BJ(1,1)+n2*BJ(2,1)+n3*BJ(3,1)
               a(2)=n1*BJ(1,2)+n2*BJ(2,2)+n3*BJ(3,2)
               a(3)=n1*BJ(1,3)+n2*BJ(2,3)+n3*BJ(3,3)
               aa=sqrt(a(1)*a(1)+a(2)*a(2)+a(3)*a(3))*2*PI
               if(aa.le.BJ_min) BJ_min=aa
 10         continue
         end do
      end do
      gEwald=sqrt( 0.5*BJ_min/AJ_min )
      write(*,*)'... The "best" gEwald = ',gEwald,'...'
      write(19,*)'... The "best" gEwald = ',gEwald,'...'
c
c....... set up charges, precision, the point of interest (Point)
c        and a multiplication factor
c
      verbose=.false.
      Yes_Pot=.false.
 1    call choose(Charge,Q,Point,EPSew,factor,gEwald,verbose,iQuit,
     ,     Yes_Pot,vMad)
      EPSx=-log(EPSew)
      if(iQuit.eq.1) then
         close (19)
         return
      end if
      write(19,*)'... current gEwald = ',gEwald,'...'
      write(19,*)'Point: ',(Point(i),i=1,3)
c
c....... run the Ewald method for the Point to calculate vMad
c
      write(*,*)
      vMad=0.0
      do ion=1,ITI
         a(1)=TI(1,ion)-Point(1) 
         a(2)=TI(2,ion)-Point(2) 
         a(3)=TI(3,ion)-Point(3) 
         call Madelung(AJ,BJ,Vc,a,gEwald,EPSx,Ew,verbose)
         verb(ion)=Ew
c     write(19,*) ion,a,Ew
         vMad=vMad+Q(ion)*Ew  
      end do
      write(*,'(a26,e12.6)')'____> Madelung potential: ',vMad*factor
      write(19,'(a26,e12.6)')'____> Madelung potential: ',vMad*factor
      write(*,*)
      if(verbose) then
         write(*,'(a/6(e12.6,x))')'Contributions:',(verb(i),i=1,ITI)
         write(19,'(a/6(e12.6,x))')'Contributions:',(verb(i),i=1,ITI)
      end if
      Yes_Pot=.true.
      go to 1
c
c..... errors
 200  write(*,*)'FATAL! Error while opening madel.dat file!'
      return
      end

      subroutine Madelung(AJ,BJ,Vc,X,gEwald,EPSx,Ew,verbose)
c.......................................................................
c The Coulomb potential (vMad) at the point X from point-ion lattice.
c The Ewald's method is used here.
c Besides, the Evien's idea of organizing the summations over the
c direct and the reciprocal lattices ("by shells") is implemented.
c.......................................................................
c EPSx - the precision of the lattice Ewald's summation for x2:
c       EPSx=-ln(EPSew)
c.......................................................................
      include 'real8.inc'
      DIMENSION AJ(3,3),BJ(3,3),X(3),Xc(3)
      logical FlagD,FlagI,verbose
      data tiny/0.00001/
      gE2=gEwald*gEwald
c.......... put summands to zero:
      Em0D=0.0
      Em0I=0.0
      Em=0.0
c
c....... The both lattices are built by shells numbered using the.......
c   index N=0,1,2,... where N=0 belongs to the 0 site; inside every
c   shell the lattice vectors are computed as N1*a1+N2*a2+N3*a3,
c   where a1,a2,a3 are basic translations (AI for the direct and BI for
c   the invers lattices, respectively), and N1,N2,N3 - indices for the
c   shell, at least one of them is +N or -N.
c.......................................................................
c  count number of "active" sites in direct and reciprocal summations
c  for statistics
      iTotD=0
      iTotR=0
c
c....... The contributions from all shells N. Construction of the shells
c        N by means of the Evien's method.
      FlagD=.True.
      FlagI=.True.
c....... FlagD and FlagI are logical variables for interrupting of the
c   summations over the direct and inverse lattices, respectively. At the
c   beginning they are .true. and the summations are allowed. But, if for
c   every term in the shell the corresponding contribution is small
c   enough, then the variable becomes .false. and suppresses the corresp.
c   summation for all sequential shells. If both are .false., the both
c   summations are stopped. The property is obtained by checking the
c   variables iDir and iInv for 0 values at the end of every shell.
c   iDir and iInv are the numbers of sites in the shell which give a
c   nonzero contribution).
c
      N=-1
30    N=N+1
      iDir=0
      iInv=0
      do N3=-N,N
         do  N2=-N,N
            do 250 N1=-N,N
               if(N3.ne.N.and.N3.ne.-N) then
                  if(N2.ne.N.and.N2.ne.-N) then
                     if(N1.ne.N.and.N1.ne.-N) go to 250
                  end if
               end if
c
c____________ summation over the direct lattice
               if( .not.FlagD ) go to 100
               Xc(1)=gEwald*(N1*AJ(1,1)+N2*AJ(2,1)+N3*AJ(3,1)+X(1))
               Xc(2)=gEwald*(N1*AJ(1,2)+N2*AJ(2,2)+N3*AJ(3,2)+X(2))
               Xc(3)=gEwald*(N1*AJ(1,3)+N2*AJ(2,3)+N3*AJ(3,3)+X(3))
               x2= Xc(1)*Xc(1) + Xc(2)*Xc(2) + Xc(3)*Xc(3)
               if( x2.le.EPSx ) then
                  iDir=iDir + 1
                  if( x2.lt.tiny) then
                     Em=-gEwald*1.128379167
                  else
                     x1= sqrt(x2)
                     Em0D=Em0D+urfc9(x1)*exp(-x2)
                  end if 
               end if
c
c____________ summation over the reciprocal lattice
 100           if(N.eq.0) go to 30
               if( .not.FlagI ) go to 250
               Xc(1) = (N1*BJ(1,1) + N2*BJ(2,1) + N3*BJ(3,1))*2*PI
               Xc(2) = (N1*BJ(1,2) + N2*BJ(2,2) + N3*BJ(3,2))*2*PI
               Xc(3) = (N1*BJ(1,3) + N2*BJ(2,3) + N3*BJ(3,3))*2*PI
               g2= Xc(1)*Xc(1) + Xc(2)*Xc(2) + Xc(3)*Xc(3)
               x2= g2/(4.0*gE2)
               if( x2.le.EPSx ) then
                  iInv=iInv + 1
                  qu = exp(-x2)/g2
                  Xg = Xc(1)*X(1) + Xc(2)*X(2) + Xc(3)*X(3)
                  cosXg = cos(Xg)
                  Em0I=Em0I+qu*cosXg
               end if
 250        end do
         end do
      end do
      if(verbose) then 
         iTotD=iTotD+iDir
         iTotR=iTotR+iInv
         write(*,'(3(a,i5))')
     &        '...> sphere N=',N,' with iDir=',iDir,' iInv=',iInv
         write(19,'(3(a,i5))')
     &        '...> sphere N=',N,' with iDir=',iDir,' iInv=',iInv
      end if
      if(iDir.eq.0 .and. N.gt.0) FlagD = .False.
      if(iInv.eq.0) FlagI = .False.
      if(FlagD.or.FlagI) go to 30
      if(verbose) then
         write(*,'(2(a,i6))') 
     &'Final number of sites: Dir=',iTotD,' Recipr=',iTotR
         write(19,'(2(a,i6))') 
     &'Final number of sites: Dir=',iTotD,' Recipr=',iTotR
         write(19,'(a1,f8.3,2(a1,f8.3),a9,i2,3(1x,e12.6))')
     &     '(',X(1),',',X(2),',',X(3),'), Evjen=',N,Em0I,Em0D,Em
      end if
      write(*,'(3(a,i5))')'...> N=',N,' spheres were needed'
c
c.......... compile the whole thing from Dir. and INv. contributions
c
      Ew=4*PI/Vc*Em0I+gEwald*Em0D+Em
      return
      end

      FUNCTION URFC9(Y)
c......................................................................
c                 urfc9(y)=erfc(y)*exp(y**2)/y ,
c  where erfc(y) is the usual error function, erf(y)=1-erfc(y).
c......................................................................
c  We use here the interpolation given in the Abramovitz and Steagan
c  book for the erfc(y).
c......................................................................
      include 'real8.inc'
      T=1./(1.+0.3275911*Y)
      URFC9 = T*(0.2548296+T*(-0.2844967+T*(1.4214137+T*(-1.45315203+
     +T*1.0614054))))/Y
      RETURN
      END

      subroutine choose(Charge,Q,Point,EPSew,factor,gEwald,
     ,                                 verbose,iQuit,Yes_Pot,vMad)
c......................................................................
c      Choose the point of interest (Point), precision (EPSx)
c and charges on ions in the cell.
c      Ewald's constant gEwald can be chosen as well.
c.........................................................................
c Charge(species) - ionic charge on each species;
c Q(ion) - ionic charge on each ion in the cell.
c......................................................................
c iQuit = 0 - not quit, proceed with the procedure;
c         1 - quit, i.e. skip the procedure in the parent program.
c......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      character angstr*12,cha2*2
      logical verbose,Yes_Pot
      dimension Charge(N0KD),Q(N0LT),Point(3),fPoint(3)
      data angstr/'<AtomNumber>'/,iCharge/0/,iChargeS/0/,mCharge/0/
      data iCoord/0/,tiny/0.000001/
c
 21   iQuit=0
      write(*,*)'..............MENU for Madelung potential ...........'
      write(*,*)'......... Change these parameters if necessary: .....'
      write(*,*)
      if(iCoord.eq.0) then 
         iQuit=1
         write(*,'(a)')
     ,   '   1. Point of interest: ....... undefined .......'
      else
         write(*,'(a,f10.5,2(a1,f10.5),a1)')
     ,   '   1. Point of interest (Angstroms): (',
     ,                       Point(1),',',Point(2),',',Point(3),')'
         fPoint(1)=BJ(1,1)*Point(1)+BJ(1,2)*Point(2)+BJ(1,3)*Point(3)
         fPoint(2)=BJ(2,1)*Point(1)+BJ(2,2)*Point(2)+BJ(2,3)*Point(3)
         fPoint(3)=BJ(3,1)*Point(1)+BJ(3,2)*Point(2)+BJ(3,3)*Point(3)
         write(*,'(x,a,f10.5,2(a1,f10.5),a1)')
     ,   '     Point of interest (fractionl): (',
     ,                     fPoint(1),',',fPoint(2),',',fPoint(3),')'
      end if
      if(iChargeS.eq.0) then
         if(mCharge.eq.0) then
            write(*,'(a)')
     &        '   3. Charges on species: ....... undefined .......'
         else
            write(*,'(a)')
     &          '   3. Charges on species (not used): UNKNOWN'
         end if
      else
         write(*,'(a)')
     &          '   3. Charges on species:   KNOWN'
      end if  
      if(iCharge.eq.0) then
         iQuit=1
         write(*,'(a)')
     &          '   4. Charges on ions: ....... undefined .......'
      else
         write(*,'(a)')
     &          '   4. Charges on ions:   KNOWN'
      end if  

      if(Yes_Pot) then
         write(*,'(a)')
     &'  Ok. Adopt present setting and calculate the potential <- Done!'
         write(*,'(6x,a,e12.6)')'>>>> Madelung potential: ',vMad*factor
      else
         write(*,'(a)')
     &         '  Ok. Adopt present setting and calculate the potential'
      end if

c_____ show settings
      write(*,*)
     &'-------------- g e n e r a l  s e t t i n g s ----------------'
      if(mCharge.eq.0) then
         write(*,'(a)')
     &          '   2. Charges on all species are the same: YES'
      else
         write(*,'(a)')
     &          '   2. Charges on all species are the same: NO'
      end if  
      write(*,*)
     &     ' An. [For input] Coordinates are specified in: '//angstr
      write(*,*)
     &     ' Co. Show current atomic positions in fractional/Cartesian'
      write(*,*)' Sy. Show the point symmetry'
      write(*,'(a,e12.6)')  '  Ew. Ewald constant: ',gEwald
      write(*,'(a35,e12.6)')'   5. Precision of the summations: ',EPSew
      write(*,'(a29,e12.6)')'   6. Multiplication factor: ',factor
      if(verbose) then
         write(*,'(a)')     '  Vb. Verbose: YES'
      else
         write(*,'(a)')     '  Vb. Verbose: NO'
      end if
      write(*,'(a)')'   Q. Quit: skip the step and do NOT proceed. '
      write(*,*)
      write(*,*)'------> Choose the item and press ENTER:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)
c
c[An]__________ choose the way how the coordinates are given
c
      IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if 
c
c[1]__________ give the point 
c
      ELSE IF(cha2(l0:).eq.'1') THEN

         call givepoint(Point(1),Point(2),Point(3),angstr)
         iCoord=1
c
c[2]__________ choose the method: individually for all ions or through
c           the species 
c
      ELSE IF(cha2(l0:).eq.'2') THEN

         if(mCharge.eq.0) then
            mCharge=1
         else
            mCharge=0
         end if
c
c[3]__________ specify charges on species and assign these charges to
c           all ions in Q(ion):
c
      ELSE IF(cha2(l0:).eq.'3') THEN

 20      if(mCharge.eq.0) then
           write(*,'(a22,i2,a9/20(a2,x))')
     &          'Give charges for each ',Nsp,' species: ',
     ,           (Species(i),i=1,Nsp)
           read(*,*,err=20) (Charge(i),i=1,Nsp)
           iChargeS=1
           write(*,*)'______ charges on ions: ________'
           ion=0
           tot=0.0
           do i=1,Nsp
             do j=1,NspN(i)
               ion = ion +1
               Q(ion)=Charge(i)
               tot=tot+Q(ion)
               write(*,'(a4,i2,a3,i2,a3,i3,a2,f10.5)')
     &                           ' sp=',i,' #=',j,' Q(',ion,')=',Q(ion)
             end do
           end do 
           write(*,*)'________________________________'
           if(abs(tot).gt.tiny)
     &        write(*,*)'WARNING! Your unit cell is not neutral!'
           iCharge=1
         else
           write(*,*)
     &      'WANRNING! You do NOT need them unless the option 2 is YES!'
         end if 
c
c[4]__________ specify charges for all ions in the cell individually
c
      ELSE IF(cha2(l0:).eq.'4') THEN

 29      if(mCharge.eq.1) then
           write(*,*)
     &     'Give ionic charges individually:'
           ion=1
           do i=1,Nsp
 30          write(*,'(a17,i2,a2,i2,a6)') 
     &                 '____ The species ',i,': ',NspN(i),' ions:' 
             read(*,*,err=30) (Q(k),k=ion,ion+NspN(i)-1)
             ion=ion+NspN(i)
           end do 
           iCharge=1
           write(*,*)'______ charges on ions: ________'
           ion=0
           tot=0.0
           do i=1,Nsp
             do j=1,NspN(i)
               ion = ion +1
               write(*,'(a4,i2,a3,i2,a3,i3,a2,f10.5)')
     &                           ' sp=',i,' #=',j,' Q(',ion,')=',Q(ion)
               tot=tot+Q(ion)
             end do
           end do 
           write(*,*)'________________________________'
           if(abs(tot).gt.tiny) then
             write(*,*)'ERROR! Your unit cell is not neutral!'
             go to 29
           end if
         else
           write(*,*)
     &      'WANRNING! You do NOT need them unless the option 2 is NO!'
         end if 
c
c[5]__________ specify the precision of the summations in the Ewald method 
c
      ELSE IF(cha2(l0:).eq.'5') THEN

 40      write(*,*)'Give the precision:'
         read(*,*,err=40) EPSew
c
c[6]__________ specify the multiplication factor
c
      ELSE IF(cha2(l0:).eq.'6') THEN

 45      write(*,*)'Give the multiplication factor:'
         read(*,*,err=45) factor
c
c[Ew]__________ change Ewald's constant
c
      ELSE IF(cha2(l0:).eq.'Ew') THEN

 50      write(*,*)'Specify the Ewald constant:'
         read(*,*,err=50) gEwald
c
c[Vb]__________ verbose or not
c
      ELSE IF(cha2(l0:).eq.'Vb') THEN

         if(verbose) then
            verbose=.false.
         else
            verbose=.true.
         end if

c[Co].... display lattice atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN
         k=0
         do i=1,Nsp
            write(*,'(3a,i5)')
     &           '.... Species <',Species(i),'> ......> ',i
            write(*,'(a)')' Tot   # |----------  Fractional ---------|'
     &        //'-------------  Cartesian ---------| Relax | Charges'
            do j=1,NspN(i)
               k=k+1
               a1=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
               a2=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
               a3=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
               write(*,'(2(x,i3),x,3(x,f10.5),2x,3(x,f10.5),3x,a,
     ,              f10.5)') k,j,a1,a2,a3,(TI(j1,k),j1=1,3),
     ,            relax_flag(1,k)//relax_flag(2,k)//relax_flag(3,k),
     ,            Q(k)
            end do
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n','y')
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c
c[Ok]__________ fo to calculate the potential
c
      ELSE IF(cha2(l0:).eq.'Ok') THEN

         if(iQuit.eq.0) return
         write(*,*)'ERROR! You still have undefined parameters!'

c
c[Q]__________ fo to calculate the potential
c
      ELSE IF(cha2(l0:).eq.'Q') THEN

         iQuit=1
         return  
      else
         write(*,*)'ERROR! Try again!'
      end if
      go to 21
      end

      subroutine givepoint(aCENTX,aCENTY,aCENTZ,angstr)
c...............................................................
c   Choose a point for the plot
c...............................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension x(3)
      character angstr*12
c
c__________ give coordinates in Angstroms
      if(angstr.eq.'<Angstroms> ') then
 5       write(*,*)'Give Cartesian coordinates as X,Y,Z in Angstroms:'
         READ(*,*,err=10) aCENTX,aCENTY,aCENTZ
         return
 10      write(*,*)'Error! Try again!'
         go to 5
c
c__________ give position via atomic number
      else if(angstr.eq.'<AtomNumber>') then
 30      write(*,*)'Give atomic number:'
         read(*,*,err=30) number
         if(number.lt.1.or.number.gt.ITI) go to 30
         aCENTX=TI(1,number)
         aCENTY=TI(2,number)
         aCENTZ=TI(3,number)
c
c__________ give through fractional coordinates
      else 
 6       write(*,*)'Give fractional coordinates along A1,A2,A3:'
         READ(*,*,err=6) x(1),x(2),x(3)
c_________ transform to Cartesian coordinates
         aCENTX=x(1)*AJ(1,1)+x(2)*AJ(2,1)+x(3)*AJ(3,1)
         aCENTY=x(1)*AJ(1,2)+x(2)*AJ(2,2)+x(3)*AJ(3,2)
         aCENTZ=x(1)*AJ(1,3)+x(2)*AJ(2,3)+x(3)*AJ(3,3)
         return
      end if
      end




