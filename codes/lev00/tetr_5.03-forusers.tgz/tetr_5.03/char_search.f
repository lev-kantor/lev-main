ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c find the correct character
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      character cha
 1    write(*,*) 'Specify the character:'
      read(*,'(a1)') cha
      i=0
 10   i=i+1
c      write(*,*) i,cha,char(i)
      if(char(i).eq.cha) then
         if(i.lt.10) then
            write(*,'(2a,i1,a)') cha,' corresponds to char(',i,')'
         else if(i.lt.100) then
            write(*,'(2a,i2,a)') cha,' corresponds to char(',i,')'
         else if(i.lt.1000) then
            write(*,'(2a,i3,a)') cha,' corresponds to char(',i,')'
         end if
         go to 1
      else
         if(i.gt.999) stop
         go to 10
      end if
      stop
      end
