      subroutine CutStrT(Line,NumLin,LinPos,LinEnd,LEN,
     &                                      NFIL,iCom,iErr)
c.................................................................
c....It reads the line from the file UNIT=NFIL as a string   .....
c.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
c.... substrings. Their number is NumLin, while starting and .....
c.... ending positions are LinPos and LinEnd.                .....
c.................................................................
c  LEN - the length of the string
c  Up to LEN/2 substrings is implied to be in the string Line.
c.................................................................
c  If NFIL=0 it is assumed that the string Line*80 exists and
c  must not be read from the external source, but must be taken
c  as an input from the parent program
c.................................................................
c  iErr=1 in the case of error input; oterwise iErr=0
c.................................................................
c  Commas are also interpreted as string division symbols 
c  alongside spaces if iCom=1; not, if iCom=/=1.
c.................................................................
c  Equal signs are also interpreted as string division symbols 
c  alongside spaces if iCom=2; not, if iCom=/=2.
c.................................................................
c
      character (LEN=LEN) Line
      character cha
      integer LinEnd(*),LinPos(*)
      iErr=0
      if(NFIL.ne.0)  then
         call SkipL(NFIL,iErr)
         if(iErr.ne.0) go to 10
         read (NFIL,'(a)',err=10,end=10) Line
      end if
      NumLin=0 ; icase=0
c............ replace commas, if present, by spaces
      if(iCom.eq.1) then
         do i=1,LEN
            if(Line(i:i).eq.',') Line(i:i)=' '
         end do
      end if
c............ replace equal sign, if present, by spaces
      if(iCom.eq.2) then
         do i=1,LEN
            if(Line(i:i).eq.'=') Line(i:i)=' '
         end do
      end if
c............ Loop over all characters in the Line(1:LEN)..........
      do 5 i=1,LEN
         i0=i
         cha=Line(i:i)
c________ if the 1st not blank character is found
         if(cha.ne.' '.and.cha.ne.'	'.and.icase.eq.0) then
            NumLin=NumLin+1
            if(NumLin.gt.LEN/2) go to 10
            LinPos(NumLin)=i
            icase=1
         end if
c_________ if the 1st blank character is found after the substring
         if(cha.eq.' '.and.icase.eq.1) then
            LinEnd(NumLin)=i-1
            icase=0
         end if
 5    end do
      if(icase.eq.1) LinEnd(NumLin)=LEN
      return
 10   iErr=1
      return
      end

      subroutine CutStr(Line,NumLin,LinPos,LinEnd,NFIL,iCom,iErr)
c.................................................................
c....It reads the line from the file UNIT=NFIL as a string   .....
c.... Line*80 (if NFIL.ne.0) and replies with a set of       .....
c.... substrings. Their number is NumLin, while starting and .....
c.... ending positions are LinPos and LinEnd.                .....
c.................................................................
c Up to 100 substrings is implied to be in the initial string Line.
c.................................................................
c  If NFIL=0 it is assumed that the string Line*80 exists and
c  must not be read from the external source, but must be taken
c  as an input from the parent program
c.................................................................
c  iErr=1 in the case of error input; oterwise iErr=0
c.................................................................
c  Commas are also interpreted as string division symbols 
c  alongside spaces if iCom=1; not, if iCom=/=1.
c.................................................................
c  Equal signs are also interpreted as string division symbols 
c  alongside spaces if iCom=2; not, if iCom=/=2.
c.................................................................
c
      character Line*200
      character cha
      integer LinEnd(100),LinPos(100)
      iErr=0
      if(NFIL.ne.0)  then
         call SkipL(NFIL,iErr)
         if(iErr.ne.0) go to 10
         read (NFIL,'(a)',err=10,end=10) Line
      end if
      NumLin=0 ; icase=0
c............ replace commas, if present, by spaces
      if(iCom.eq.1) then
         do i=1,200
            if(Line(i:i).eq.',') Line(i:i)=' '
         end do
      end if
c............ replace equal sign, if present, by spaces
      if(iCom.eq.2) then
         do i=1,200
            if(Line(i:i).eq.'=') Line(i:i)=' '
         end do
      end if
c............ Loop over all characters in the Line(1:200)............
      do 5 i=1,200
         i0=i
         cha=Line(i:i)
c________ if the 1st not blank character is found
         if(cha.ne.' '.and.cha.ne.'	'.and.icase.eq.0) then
            NumLin=NumLin+1
            if(NumLin.gt.100) go to 10
            LinPos(NumLin)=i
            icase=1
         end if
c_________ if the 1st blank character is found after the substring
         if(cha.eq.' '.and.icase.eq.1) then
            LinEnd(NumLin)=i-1
            icase=0
         end if
 5    end do
      if(icase.eq.1) LinEnd(NumLin)=200
      return
 10   iErr=1
      return
      end

      subroutine SkipL(NFIL,iErr)
c.......................................................................x
c...... Program skips all "empty" string containing comments, etc.......
c...... All lines, containing **,--,==,*-, ## annd -* symbols are.......
c...... recognized as the comments lines and are skipped. The    .......
c...... driver is set up at the beginning of the first "nonempty".......
c...... record                                                   .......
c.......................................................................
c  iErr=1 in the case of error input; oterwise iErr=0
c.................................................................
c
      parameter (nComm=6)
      character Line*200,Comm(nComm)*2
      data Comm/'*-','-*','--','==','**','##'/
c.......... read the current line from the driver NFIL
1     read (NFIL,'(a)',err=10,end=10) Line
c_________ analyze Line if it is empty
      if(Line(1:1).eq.CHAR(0)) go to 1
c_________ analyze Line if it is filled by simple blanks
      do i=1,200
         if(Line(i:i).ne.CHAR(0).and.Line(i:i).ne.' ') go to 2
      end do
      go to 1
c_________ analyze Line for the comment symbols; in the case if any
c          one from the list Comm() was found at the beginning of the Line, 
c          it reads the next line
 2    do j=1,200
         if(Line(j:j).ne.' ') then
            do i=1,nComm
               if(INDEX(Line(j:j+1),Comm(i)).ne.0) go to 1
            end do
            iErr=0 ; go to 5
         end if
      end do
c_________ return to the beginning of the "nonempty" line (record)
 5    backspace NFIL
      return
c......... in the case of an error
10    iErr=1
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine right(char,len,len00)
      character*(*)  char
      do i=len,1,-1
         j=i
         if(char(i:i).ne.' ') go to 1
      end do
 1    jj=len-j
      do i=j,1,-1
         char(jj+i:jj+i) = char(i:i)
      end do
      do i=1,jj
         char(i:i)=' '
      end do
      len00=jj+1
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine posit(char,len,len00)
      character*(*)  char
      do i=len,1,-1
         j=i
         if(char(i:i).eq.' ') then
            len00=j+1
            return
         end if
      end do
      len00=1
      return
      end

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine find_string(string,l,NFIL,Line,iErr)
      character*(*) string,line
c
      iErr=0
 10   read (NFIL,'(a)',END=40,ERR=40) Line
      i0=index(Line,string(1:l))
      if(i0.eq.0) go to 10
c     write(9,'(/a)')
c     & '.........O.K.! String '//string(1:l)//' is found !!! .........'
      return
 40   iErr=1
      end


cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine find_symbol(string,l,symbol,ipos)
      character*(*) string
      character  symbol
c
      ipos=0
      do i=1,l
         if(string(i:i).eq.symbol) then
            ipos=i
            return
         end if
      end do
      return
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      logical function file_exist(name,l0)
      include 'whereis.inc'
      character name*20

      inquire(file=tetr_dir(tetr_l0:)//'/'//name(:l0),
     &     EXIST=file_exist)
      if(file_exist) then
         write(*,'(a)')
     &     'OK! File '//tetr_dir(tetr_l0:)//'/'//name(:l0)//' exists!'
      else
         write(*,'(a)')
     &     'ERROR! Cannot find '//tetr_dir(tetr_l0:)//'/'//name(:l0)
      end if
      return
      end

ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

     
      logical function if_cha_is_number(cha,l0,number)
      character*(*) cha
      logical log,is_cha_number1,is_cha_number2
      if_cha_is_number=.false.
      if(l0.eq.1) then
         log=is_cha_number2(cha(l0:))
      else if(l0.eq.2) then
         log=is_cha_number1(cha(l0:))
      end if
      if(.not.log) return
      read(cha(l0:),*,err=27) number
      if(number.eq.0) go to 27
      if_cha_is_number=.true.
 27   return
      end

      logical function is_cha_number1(cha)
      character cha,numb(10)
      data numb/'0','1','2','3','4','5','6','7','8','9'/
      is_cha_number1=.false.
      write(*,'(a)')' character = '//cha

      do j=1,10
         if(cha.eq.numb(j))  then
c            write(*,'(a)')'character '//cha//' is number '//numb(j)
            go to 10
         end if
      end do
c      write(*,'(a,i1,a)') 'character '//cha//' is NOT number'
      return

 10   is_cha_number1=.true.
      return
      end

      logical function is_cha_number2(cha)
      character cha*2,numb(10)
      data numb/'0','1','2','3','4','5','6','7','8','9'/
      l=2
      is_cha_number2=.false.
c      write(*,'(a)')' character = '//cha

      do i=1,l

         do j=1,10
            if(cha(i:i).eq.numb(j))  then
c               write(*,'(a,i1,a)')
c     &          'character '//cha(i:i)//'(i=',i,') is number '//numb(j)
               go to 10
            end if
         end do
c         write(*,'(a,i1,a)')
c     &        'character '//cha(i:i)//'(i=',i,') is NOT number'
         return

 10   end do
      is_cha_number2=.true.
      return
      end

      subroutine name_from_number(nat,cha,l1,err)
c..............................................................
c  generates character cha(l1:) from the number 'nat' 
c  which should be < 9999; otherwise, err=.true.
c..............................................................
      character cha*4
      logical err
      err=.false.
      if(nat.le.9) then
         l1=4
         write(cha(l1:),'(i1)') nat
      else if(nat.le.99) then
         l1=3
         write(cha(l1:),'(i2)') nat
      else if(nat.le.999) then
         l1=2
         write(cha(l1:),'(i3)') nat
      else if(nat.le.9999) then
         l1=1
         write(cha(l1:),'(i4)') nat
      else
         err=.true.
      end if
      return
      end

      subroutine find_left_space(cha,l0,l)
c...............................................................
c finds the last space position l from the left in cha(:l0) 
c before the actual word inside.
c l=0 - means that there are no spaces before the word
c...............................................................
      character*(*)  cha
      l=0
 1    l=l+1
      if(l.gt.l0) return
      if(cha(l:l).eq.' ') go to 1
      l=l-1
      return
      end

      subroutine find_word(string,l0,l1,l2,err)
c...............................................................
c finds the first word in the string string(:l0) of length i0.
c Input: string(:i0)
c Output: i1,i2, word=string(l1:l2)
c...............................................................
c err=.true. - means that there are no words inside string(:i0)
c...............................................................
      character*(*) string
      logical err,beg
      err=.false. ; beg=.false.
      l=0
 1    l=l+1
      if(l.gt.l0) then
         err=.true. ; return
      end if
      if(string(l:l).eq. ' ' .or. string(l:l).eq.'') then
         if(beg) then
            l2=l-1 ; return
         end if
      else if(.not.beg) then
         l1=l ; beg=.true.
      end if
      go to 1
      end
