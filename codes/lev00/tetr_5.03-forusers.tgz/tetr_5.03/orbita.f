      subroutine ORBITA(RA,BJ)
C*******************************************************************
c Works out the orbit built from the 1st atom RA(xyz).
c*******************************************************************
c
c=====  Local group of the 1st atom:
c^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 
c       MGN - number of elements in the local group (final)
c    KH(I2) - gives local group elements (in the list of elements of 
c             the whole group)
c
c=====  Generators of the orbit:
c^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  
c R(I1,xyz) - positions of atoms in the orbit
c    KJ(I1) - gives generators (in the list of elements of 
c             the whole group) 
c     N_orb - number of atoms in the orbit (final)
C*******************************************************************
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'systema.inc'
      include 'space.inc'
      dimension R(MG0,3),RA(3),RR1(3),RL(3),BJ(3,3)
      logical ask_equiv
      data tiny/0.0001/
      I1=1 ; I2=1 ; KJ(1)=1 ; KH(1)=1
      R(1,1:3)=RA(1:3)
      if(MG.EQ.1) go to 4
c
c......... loop over all group elements........................
c        I1 - counts generators (or atoms in the orbit)
c        I2 - counts elements 
c
      do 3 I=2,MG
         KGI=KG(I)
         RR1(1)=C(1,1,KGI)*RA(1)+C(1,2,KGI)*RA(2)+C(1,3,KGI)*RA(3)+
     +        TRAN(I,1)
         RR1(2)=C(2,1,KGI)*RA(1)+C(2,2,KGI)*RA(2)+C(2,3,KGI)*RA(3)+
     +        TRAN(I,2)
         RR1(3)=C(3,1,KGI)*RA(1)+C(3,2,KGI)*RA(2)+C(3,3,KGI)*RA(3)+
     +        TRAN(I,3)
C____ Test the element I, whether it belongs to the local group
         RL=RR1-RA
         if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA') then
            if(ask_equiv(RL,BJ,3,tiny)) go to 2
         else
            AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
            if(AR.lt.tiny) go to 2
         end if
c______ if it does not belong to the local group, then
C       check whether it coincides with any already found atoms in the orbit;
c       if not, try another group element => 3;
c       if does, fill KJ with the generator number
         do J=1,I1
            RL(1:3)=RR1(1:3)-R(J,1:3)
            if(system.eq.' LATTICE' .or. system.eq.'LATT-TRA') then
               if(ask_equiv(RL,BJ,3,tiny)) go to 3
            else
               AR=RL(1)*RL(1)+RL(2)*RL(2)+RL(3)*RL(3)
               if(AR.lt.tiny) go to 3
            end if
         end do
c______ fill KJ with the generator number I
         I1=I1+1 ; R(I1,1:3)=RR1(1:3) ; KJ(I1)= I
         go to 3
c______ if it does belong to the local group
 2       I2=I2+1
         KH(I2)=I
    3 end do
    4 N_orb=I1
      MGN=MG/N_orb
      end
