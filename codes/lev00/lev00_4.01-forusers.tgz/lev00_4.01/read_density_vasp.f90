subroutine vasp_dens(grid,charge,name,spin,iErr)
!..............................................................
!    read density from name=CHGCAR/LOCPOT/... file of VASP
!
!    ncol=5  in the case of CHGCAR (density)
!    ncol=5  in the case of LOCPOT (potential)
!    ncol=10 in the case of PARCHG (partial density)
!..............................................................
!    spin =.false. - total charge \____ for all files
!         = .true. - spin density /
!..............................................................
use param
use atoms
implicit none
integer, parameter :: NCol0=10
real*8, parameter  :: tiny=0.0001
integer, dimension(:), allocatable :: NatSpec 
real*8 GRID(NGX,NGY,NGZ),DIR(3,3),charge,factor,x,y,z,dens(NCol0)
integer ix5(NCol0),iy5(NCol0),iz5(NCol0),iErr,ncol,i,j
!integer icase
integer NGX1,NGY1,NGZ1,ijk,ijk5,iz,iy,ix,last,jj,i0,j0
character name*6,title*10,line*100
logical spin
!
!......... which case
!
      allocate(NatSpec(NSPEC))
      iErr=0
      if(name.eq.'CHGCAR' .or. name.eq.'LOCPOT') then
!         icase=1
         ncol=5
      else if(name.eq.'PARCHG') then
!         icase=2
         ncol=10
      else
         write(*,*)'Not yet implemented!'
         iErr=1 ; go to 300
      end if
      open(19,file=name,status='old',form='formatted',err=100)
!
!.......... skipping stuff and checking
!
      read(19,'(a)',err=100,end=100) title
      read(19,*,err=100,end=100) factor
      read(19,*,err=100,end=100) DIR(1,1), DIR(1,2), DIR(1,3)
      read(19,*,err=100,end=100) DIR(2,1), DIR(2,2), DIR(2,3)
      read(19,*,err=100,end=100) DIR(3,1), DIR(3,2), DIR(3,3)
      write(*,*) DIR(1,1), DIR(1,2), DIR(1,3)
      write(*,*) DIR(2,1), DIR(2,2), DIR(2,3)
      write(*,*) DIR(3,1), DIR(3,2), DIR(3,3)
      do i=1,3
         do j=1,3
            if(abs(DIRC(i,j)-factor*DIR(i,j)).gt.tiny) then
               write(*,*)'FATAL! Found different lattice vectors!'
               go to 100
            end if
         end do
      end do
!______________ attempt to read other lines; in version 5.2 we have a new line
!               with atomic species; read it if possible, otherwise skip for
!               older versions (29.05.2010, LK)
      read(19,*,err=10) (NatSpec(i),i=1,NSPEC)
      go to 15
10    read(19,*,err=100,end=100) (NatSpec(i),i=1,NSPEC)
15    write(*,*) (NatSpec(i),i=1,NSPEC)
      do i=1,NSPEC
         if(NatSpec(i).ne.NspN(i)) then
            write(*,*)'FATAL! Found different species numbers!'
            go to 100
         end if
      end do
!      write(*,*) (NatSpec(i),i=1,NSPEC)
      read(19,'(a)',err=100,end=100) title
      write(*,'(a)') title
!_____________Skipping coordinates: not checking. It could be worth doing
!             though...
      do i=1,NSPEC
         do j=1,NspN(i)
            read(19,*,err=100,end=100) x,y,z
         end do
      end do
!_____________checking grid
      read(19,*,err=100,end=100) NGX1,NGY1,NGZ1
      write(*,*)  NGX1,NGY1,NGZ1
      if(NGX.ne.NGX1 .or.NGY.ne.NGY1 .or.NGZ.ne.NGZ1) then
         write(*,*)'FATAL! Found different grid dimensions!'
         go to 100
      end if
!
!..........reading the charge density
!     It was written in NCol=5 or 10 columns using something like:
!
!     WRITE(..,..) (((DENS(I,J,K),I=1,NGX), J=1,NGY), K=1,NGZ)
!
      if(spin) then
         write(*,*)'Skipping the charge density, please wait ...'
      else
         if(name.eq.'CHGCAR') then
            write(*,*)'Reading in charge density, please wait ...'
         else if(name.eq.'PARCHG') then
            write(*,*)'Reading in partial density, please wait ...'
         else if(name.eq.'LOCPOT') then
            write(*,*)'Reading in potential, please wait ...'
         end if
      end if
!
      ijk5=0 ; ijk=0 ; j0=NPLWV/10 ; charge=0.0
      do iz=1,NGZ
         do iy=1,NGY
            do ix=1,NGX
               ijk=ijk+1 ; ijk5=ijk5+1 ; last=NCol
               if(ijk.eq.NPLWV) last=ijk5
               if(ijk5.le.last) then
                  ix5(ijk5)=ix ; iy5(ijk5)=iy ; iz5(ijk5)=iz
               end if
               if(ijk5.eq.last) then
                  read(19,*,err=100,end=100) (dens(jj),jj=1,last)
                  do jj=1,last
!                    if(dens(jj).lt.0.0) dens(jj)=0.0
                    if(.not.spin) grid(ix5(jj),iy5(jj),iz5(jj))=dens(jj)
                    charge=charge+dens(jj)
                  end do
                  ijk5=0
               end if
               if(ijk/j0*j0.eq.ijk) &
                    write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
            end do
         end do
      end do
      write(*,*)'Done!'
      write(*,'(a,e12.6)')'The charge is = ',charge/NPLWV
      if(.not.spin) go to 70
!
!.......... reading the spin density if spin=.true.
!     It was written in 5 columns using something like:
!
!  WRITE(..,..) (((DENS(I,J,K),I=1,NGX), J=1,NGY), K=1,NGZ)
!
      write(*,*)'... jumping to spin density'
 51   read(19,'(a)',end=200) line
!      write(*,'(a)') line
      i0=index(line,'.')
      if(i0.ne.0) go to 51
      read(line,*,err=51,end=51) NGX1,NGY1,NGZ1
      write(*,*) NGX1,NGY1,NGZ1
      if(NGX.ne.NGX1 .or.NGY.ne.NGY1 .or.NGZ.ne.NGZ1) go to 51
      write(*,*)'Reading in spin density, please wait ...'
!
      ijk5=0
      ijk=0
      j0=NPLWV/10
      charge=0.0
      do iz=1,NGZ
         do iy=1,NGY
            do ix=1,NGX
               ijk=ijk+1 ; ijk5=ijk5+1 ; last=NCol
               if(ijk.eq.NPLWV) last=ijk5
               if(ijk5.le.last) then
                  ix5(ijk5)=ix ; iy5(ijk5)=iy ; iz5(ijk5)=iz
               end if
               if(ijk5.eq.last) then
                  read(19,*,err=200,end=200) (dens(jj),jj=1,last)
                  do jj=1,last
                    grid(ix5(jj),iy5(jj),iz5(jj))=dens(jj)
                    charge=charge+dens(jj)
                  end do
                  ijk5=0
               end if
               if(ijk/j0*j0.eq.ijk) &
                    write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
            end do
         end do
      end do
      write(*,*)'Done!'
      write(*,'(a,e12.6)')'The spin charge is = ',charge/NPLWV
 70   close (19)
      go to 300
!
!.......errors
 100  write(*,*)'FATAL! File '//name//' does not exist, bad or wrong!'
      iErr=1
      go to 300
 200  write(*,*)'WARNING! There is no spin density found!'
      iErr=1

!......... finish
300   deallocate(NatSpec)
      return
end subroutine vasp_dens

subroutine vasp_dens_manip(unit1,unit2,unit3,c1,c2, &
                           totdensA,totdensB,totdens,NPLWV,iErr)
!.................................................................
!    reading density from unit1, unit2 of VASP and manipulaiting
!    into:
!                density=c1*den1+c2*den2
!.................................................................
!use param
use atoms
implicit none
real*8, parameter  :: pi=3.1415927d0,tiny=0.0001
integer, parameter ::  NCol0=10
integer unit1,unit2,unit3,ncol,iErr,i,j,j0,NPLWV
real*8 DIR1(3,3),DIR2(3,3),dens(NCol0),dens1(NCol0),dens2(NCol0),factor
real*8 x,y,z,totdensA,totdensB,totdens,c1,c2
integer, dimension(:), allocatable :: NatSpec1, NatSpec2
integer ix5(NCol0),iy5(NCol0),iz5(NCol0),NGX1,NGY1,NGZ1,NGX2,NGY2,NGZ2
integer ijk5,ijk,iz,iy,ix,last,jj
character title*10,line*200
logical check
integer LinEnd(100),LinPos(100),NSPEC1,NSPEC2

      iErr=0 ; ncol=5
!
!.......... going through the heading
!
!..... A-file

      write(*,*) '_______> (A) density file: <________'

      read(unit1,'(a)',err=100,end=100) title
      read(unit1,*,err=100,end=100) factor
      do i=1,3
         read(unit1,*,err=100,end=100) (DIR1(i,j), j=1,3)
      end do
      write(*,'(a)')'(A) ... found lattice vectors:'
      write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR1(1,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR1(2,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR1(3,j),j=1,3)
      call CutStr(Line,NSPEC1,LinPos,LinEnd,unit1,0,iErr)
      allocate(NatSpec1(NSPEC1))
!
!........... to accommodate the new vasp v. > 5.2 format which has the species
!            symbol line preceding the line of the numbers of atoms in species
!
      read(Line,*,err=1) (NatSpec1(i),i=1,NSPEC1) ; go to 2
1     read(unit1,*,err=100) (NatSpec1(i),i=1,NSPEC1)
2     write(*,*) '(A) ...  found number of species = ',NSPEC1, ' with species numbers: '
      write(*,'(20(i4,x))') (NatSpec1(i),i=1,NSPEC1)
      j=0
      do i=1,NSPEC1
         j=j+NatSpec1(i)
      end do
      write(*,*) '(A) ...  found total number of atoms = ',j

!..... B-file

      write(*,*) '_______> (B) density file: <________'
      read(unit2,'(a)',err=101,end=101) title
      read(unit2,*,err=101,end=101) factor
      do i=1,3
         read(unit2,*,err=101,end=101) (DIR2(i,j), j=1,3)
      end do
      write(*,'(a)')'(B) ... found lattice vectors:'
      write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR2(1,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR2(2,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR2(3,j),j=1,3)
      call CutStr(Line,NSPEC2,LinPos,LinEnd,unit2,0,iErr)
      allocate(NatSpec2(NSPEC2))
!
!........... to accommodate the new vasp v. > 5.2 format which has the species
!            symbol line preceding the line of the numbers of atoms in species
!
      read(Line,*,err=3) (NatSpec2(i),i=1,NSPEC2) ; go to 4
3     read(unit2,*,err=100) (NatSpec2(i),i=1,NSPEC2)
4     write(*,*) '(B) ...  found number of species = ',NSPEC2, ' with species numbers: '
      write(*,'(20(i4,x))') (NatSpec2(i),i=1,NSPEC2)
      j=0
      do i=1,NSPEC2
         j=j+NatSpec2(i)
      end do
      write(*,*) '(B) ...  found total number of atoms = ',j

!.... checks

      check=.true.
      if(NSPEC1.ne.NSPEC2) then
         check=.false.
      else
         do i=1,NSPEC1
            if(NatSpec1(i).ne.NatSpec2(i)) check=.false.
         end do
      end if

      if(.not.check) then
         write(*,*)'WARNING! Species are different in the two densities!'
         write(*,*)'WARNING! The file to be created will have information from file A'
         write(*,*)'         Please, EDIT BEFORE USE! '
         write(*,*)'         Press ENTER when ready ...'
         read(*,*)
      end if

!.......... check consistency of the two files: lattice vectors
      do i=1,3
         do j=1,3
            if(abs(DIR1(i,j)-DIR2(i,j)).gt.tiny) then
               iErr=2
               go to 200
            end if
         end do
      end do
      write(*,*)'... Lattice vectors: check passed!'
!
!.......... writing this to unit3
      write(unit3,'(a)') title
      write(unit3,*) factor
      write(unit3,'(x,3(2x,f10.6))') DIR1(1,1), DIR1(1,2), DIR1(1,3)
      write(unit3,'(x,3(2x,f10.6))') DIR1(2,1), DIR1(2,2), DIR1(2,3)
      write(unit3,'(x,3(2x,f10.6))') DIR1(3,1), DIR1(3,2), DIR1(3,3)
      write(unit3,*) (NatSpec1(i),i=1,NSPEC1)
!
      read(unit1,'(a)',err=100,end=100) title
      read(unit2,'(a)',err=101,end=101) title
      write(unit3,'(a)') title
!
!_____________Skipping coordinates: not checking; writing coordinates to unit3

      do i=1,NSPEC1
         do j=1,NatSpec1(i)
            read(unit1,*,err=100,end=100) x,y,z
            write(unit3,'(3(x,f9.6))') x,y,z
         end do
      end do
      do i=1,NSPEC2
         do j=1,NatSpec2(i)
            read(unit2,*,err=101,end=101) x,y,z
         end do
      end do

!.......... check consistency of the two files: grid
      read(unit1,*,err=100,end=100) NGX1,NGY1,NGZ1
      read(unit2,*,err=101,end=101) NGX2,NGY2,NGZ2
      if(NGX2.ne.NGX1 .or.NGY2.ne.NGY1 .or.NGZ2.ne.NGZ1) then
         iErr=2
         go to 200
      else
         write(*,*)'... Grid: check passed!'
         NPLWV=NGX1*NGY1*NGZ1
      end if
      write(unit3,'(/3(i5,x))') NGX1,NGY1,NGZ1
!
!..........reading the charge density
!     It was written in NCol=5 columns using something like:
!
!     WRITE(..,..) (((DENS(I,J,K),I=1,NGX), J=1,NGY), K=1,NGZ)
!
      write(*,*)'Reading in charge densities, please wait ...'
!
      ijk5=0
      ijk=0
      j0=NPLWV/10

      totdensA = 0.0 ; totdensB = 0.0 ; totdens  = 0.0
      do iz=1,NGZ1
         do iy=1,NGY1
            do ix=1,NGX1
               ijk=ijk+1 ; ijk5=ijk5+1 ; last=NCol
               if(ijk.eq.NPLWV) last=ijk5
               if(ijk5.le.last) then
                  ix5(ijk5)=ix ; iy5(ijk5)=iy ; iz5(ijk5)=iz
               end if
               if(ijk5.eq.last) then
                  read(unit1,*,err=100,end=100) (dens(jj),jj=1,last)
                  read(unit2,*,err=101,end=101) (dens1(jj),jj=1,last)
                  do jj=1,last
                    dens2(jj)=c1*dens(jj)+c2*dens1(jj)
                    totdensA=totdensA+dens(jj)
                    totdensB=totdensB+dens1(jj)
                    totdens=totdens+dens2(jj)
                  end do
                  write(unit3,'(5(e18.11,x))') (dens2(jj),jj=1,last)
                  ijk5=0
               end if
               if(ijk/j0*j0.eq.ijk) &
                    write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
            end do
         end do
      end do
      write(*,*)'Done!'
      go to 200
!
!........... error messages
 100  write(*,*)'FATAL! The A-density file is bad!'
      iErr=1
      go to 200
 101  write(*,*)'FATAL! The B-density file is bad!'
      iErr=1

!............ finish

200   deallocate(NatSpec1) ; deallocate(NatSpec2)
      return
end subroutine vasp_dens_manip

subroutine check_dens_vasp(unit1,filen,NGX1,NGY1,NGZ1,Tot,iErr)
implicit none
integer, parameter ::  NCol0=10
integer iErr,NGX1,NGY1,NGZ1,unit1,i,j,ijk5,ijk,j0,ix,iy,iz,last,Ncol,jj
real*8 Tot,DIR1(3,3),factor,x,y,z,dens(NCol0)
character filen*100,line*200,title*10
integer LinEnd(100),LinPos(100),NSPEC1,NPLWV
integer ix5(NCol0),iy5(NCol0),iz5(NCol0)
integer, dimension(:), allocatable :: NatSpec1

  iErr=0
  ncol=5
  open(unit1,file=trim(filen),status='old',form='formatted',err=10)
!
!.......... going through the heading
!
  write(*,*) '_______> (A) density file: <________'
  
  read(unit1,'(a)',err=10,end=10) title
  read(unit1,*,err=10,end=10) factor
  do i=1,3
     read(unit1,*,err=10,end=10) (DIR1(i,j), j=1,3)
  end do
  write(*,'(a)')'(A) ... found lattice vectors:'
  write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR1(1,j),j=1,3)
  write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR1(2,j),j=1,3)
  write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR1(3,j),j=1,3)
  call CutStr(Line,NSPEC1,LinPos,LinEnd,unit1,0,iErr)
  allocate(NatSpec1(NSPEC1))
!
!........... to accommodate the new vasp v. > 5.2 format which has the species
!            symbol line preceding the line of the numbers of atoms in species
!
  read(Line,*,err=1) (NatSpec1(i),i=1,NSPEC1) ; go to 2
1 read(unit1,*,err=10) (NatSpec1(i),i=1,NSPEC1)
2 write(*,*) '...  found number of species = ',NSPEC1, ' with species numbers: '
  write(*,'(20(i4,x))') (NatSpec1(i),i=1,NSPEC1)
  j=0
  do i=1,NSPEC1
     j=j+NatSpec1(i)
  end do
  write(*,*) '...  found total number of atoms = ',j
!
  read(unit1,'(a)',err=10,end=10) title
!
!_____________Skipping coordinates

  do i=1,NSPEC1
     do j=1,NatSpec1(i)
        read(unit1,*,err=10,end=10) x,y,z
      end do
  end do
 
!.......... grid
  read(unit1,*,err=10,end=10) NGX1,NGY1,NGZ1
  NPLWV=NGX1*NGY1*NGZ1

!.......... reading density and calculating the total charge Tot

  ijk5=0 ; ijk=0 ; j0=NPLWV/10 ; Tot=0.0
  do iz=1,NGZ1
     do iy=1,NGY1
        do ix=1,NGX1
           ijk=ijk+1 ; ijk5=ijk5+1 ; last=NCol
           if(ijk.eq.NPLWV) last=ijk5
           if(ijk5.le.last) then
              ix5(ijk5)=ix ; iy5(ijk5)=iy ; iz5(ijk5)=iz
           end if
           if(ijk5.eq.last) then
              read(unit1,*,err=10,end=10) (dens(jj),jj=1,last)
              do jj=1,last
                 Tot=Tot+dens(jj)
              end do
              ijk5=0
           end if
           if(ijk/j0*j0.eq.ijk) &
                write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
        end do
     end do
  end do
  write(*,*)'Done!'
  go to 20


!........... error messages
10 write(*,*)'FATAL! The density file is bad!'
  iErr=1
  go to 20

!............ finish

20 deallocate(NatSpec1)
   close (unit1)
end subroutine check_dens_vasp
