subroutine EA_model_mesh(Which_Code)
!.............................................................................
! Using the current surface geometry, it will position tip atoms 
! on a mesh of points above the surface and saves the input files
! (CP2K only currently) in a directory structure.
!.............................................................................
  use real8
  use tetrag1
  use mlists
  implicit none
  integer :: NGX_,NGY_,NGZ_,NGX1,NGY1,NGZ1
  integer :: i,ix,iy,iz,lx,ly,lz,j,ll,l0,anum,anum1,anum2,ln
  character :: Labels(N0LT)*2
  integer :: length,iAt,ii,ref_at,iA,k,is
  character :: chx*4,chy*4,chz*4,dir*17,cha2*2
  real*8 :: zup,zdw,slab,zupdw,middle,vec1(2),vec2(2),Cp(3),Zupper,vec3(3)
  real(8) :: v1,v2,v12,delta(3),TI1(3,N0LT)
  real*8,parameter :: tiny=0.0001
  logical :: err,YES_Lv,periodic,listat(N0LT),tagYES,ref_Tip_At,Yes_All,Yes_Mv
  character :: Which_Code*6,YES_xyz*4,Type*2
  character*12 :: angstr='<AtomNumber>',name*100

!..... check if this is the slab geonmetry
  
  slab=abs(AJ(3,1)) + abs(AJ(3,2)) + abs(AJ(1,3)) + abs(AJ(2,3))
  if(slab.ne.0.0) then
     write(*,*)'CANNOT PROCEED: this is NOT a slab geometry!'
     write(*,*)'>>>>>>>>>>>>> Make sure: <<<<<<<<<<<<<<'
     write(*,*)'  (i) the 3rd lattice vector is along Z'
     write(*,*)' (ii) the 1st and 2nd lattice vectors are within XY plane'
     write(*,*)'Press ENTER when ready'
     read(*,*)
     return
  end if
  
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'WARNING: slab atoms go conitnuously along the Z axis.'
  write(*,*)'         Correct in the M menu if this is not the case first.'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  
!______ bracket the atoms of the slab on the Z axis

  zup=-1.0e10  ; zdw=1.0e10
  do i=1,ITI
     if(TI(3,i).gt.zup) zup=TI(3,i)
     if(TI(3,i).lt.zdw) zdw=TI(3,i)
  end do
  zupdw=zdw+AJ(3,3)
  middle = zup+0.5*(zupdw-zup)
!
!========================================================================
!===================== MENU starts here =================================
!========================================================================
!
  iAt=0
  do i=1,Nsp
     do ii=1,NspN(i)
        iAt=iAt+1 ; Labels(iAt)=Species(i)
     end do
  end do
  periodic=.false.
  vec1(1)=AJ(1,1) ; vec1(2)=AJ(1,2)
  vec2(1)=AJ(2,1) ; vec2(2)=AJ(2,2)
  vec3(1)=0.0; vec3(2)=0.0 ; vec3(3)=middle-zup
  Cp(1)=0.0 ; Cp(2)=0.0 ; Cp(3)=Zup
  Zupper=middle ; YES_xyz='Xmol' ; YES_Lv=.true. ; tagYES=.false. ; Yes_All=.true.
  listat=.false. ; ref_Tip_At=.false. ; Type='3D' ; Yes_Mv=.true.
  NGX_=3 ; NGY_=3; NGZ_=3

21 write(*,*)'/---------------------------------------------------\\'
  write(*,*)'|......................  MENU .......................|'
  write(*,*)'\\---------------------------------------------------/'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,'(a)') '......... CURRENT lattice vectors ...'
  do i=1,3
     write(*,'(a,i1,a,3(f10.5,x))') '[',i,'] ',(AJ(i,j),j=1,3)
  end do
  write(*,'(a,5x,20(a2,x))') '>>> Species: ',(Species(i),i=1,Nsp)
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'>>>> The slab is found between ',zdw,' and ',zup,' (in A)'
  write(*,*)'>>>> The middle of the vacuum gap = ',middle
  write(*,*)'>>>> The allowed range of Z values = [ ',zup,',',middle,' ]'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)
  write(*,'(a,3(f10.5,a,x),a)') &
       ' Cp. The corner point of the box: [',Cp(1),',',Cp(2),',',Cp(3),' ]'
  write(*,'(a,f10.5)') ' Up. Upper Z point of the box: ',Zupper

  write(*,'(a,f10.5)') ' Dm. Dimensionality of the grid: '//Type
  if(Type.eq.'1D') then
     NGX_=0 ; NGY_=0
     write(*,'(a,i5))') ' Gr. Grid along the 3rd vector: ',NGZ_
     write(*,'(a)') '     >>> Vertical grid ONLY - spectroscopy <<<'
  else if(Type.eq.'2D') then
     NGZ_=0
     write(*,'(a)') '     >>> Horizontal in-plane grid ONLY - constant height <<<'
     write(*,'(a,2(i5,a))')  &
              ' Gr. Grid along the 1st and 2nd vectors: ',NGX_,',',NGY_
  else
     write(*,'(a,3(i5,a))')  &
              ' Gr. Grid along the 1st, 2nd and 3rd vectors: ',NGX_,',',NGY_,',',NGZ_
     write(*,'(a)') '     >>> Full spatial grid - appropriate for constant current <<<'
  end if

  if(NGX_.eq.0 .or. NGY_.eq.0) then
     vec1=0.0 ; vec2=0.0
     write(*,'(2(a,f10.5),a)') &
          '     The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
     write(*,'(2(a,f10.5),a)') &
          '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
  else
     write(*,'(2(a,f10.5),a)') &
          ' Vp. The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
     write(*,'(2(a,f10.5),a)') &
          '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
  end if
  vec3(3)=Zupper-Cp(3) ; if(NGZ_.eq.0) vec3=0.0
  write(*,'(3(a,f10.5),a)') &
       '     The 3rd vector (perpendicular to XY) is   (',vec3(1),',',vec3(2),',',vec3(3),')'

  if(NGX_.eq.0 .or. NGY_.eq.0) then
     periodic=.false.
     write(*,'(a)')  '     The STM box CANNOT be periodically extended within the XY plane'
  else
     if(periodic) then
        write(*,'(a)')  '  P. The STM box CAN be periodically extended within the XY plane'
     else
        write(*,'(a)')  '  P. The STM box CANNOT be periodically extended within the XY plane'
     end if
  end if
  
  write(*,'(a)')  ' Tp. Tag tip atoms'
  if(tagYES) then
     call print_long_char(lists,length,long_lists)
     if(ref_Tip_At) then
        write(*,'(a,i5)')  ' Ta. Reference tip atom: ',ref_at
        write(*,'(5x,a,3(f10.5,x))') 'delta = ',delta(1:3)
     else
        write(*,'(a)')  ' Ta. Specify reference tip atom'
     end if
  end if
  if(tagYES .and. ref_Tip_At) then
     write(*,'(a)') '  S. Save the directory structure with all tip positions'
  end if
  if(Yes_Mv) then
     write(*,'(a)') ' Si. [For save] Place CP2K input with [@include coordinates.inc]: YES'
  else
     write(*,'(a)') ' Si. [For save] Place CP2K input with [@include coordinates.inc]: NO'
  end if

  write(*,'(a)')  ' ======================== S E T T I N G S =============================='
  if(CHIMERA) then
     if(YES_Lv) then
        write(*,'(a)') ' Vs. Show lattice vectors and vectors defining the box'
        write(*,'(a)') ' Lv. Show lattice vectors - YES'
     else
        write(*,'(a)') ' Vs. Show only vectors defining the box'
        write(*,'(a)') ' Lv. Show lattice vectors - NO'
     end if
  end if
  if(Yes_All) then
     write(*,'(a)') ' AL. [For save] ALL atomic positions are saved in [coordinates.inc]'
  else
     write(*,'(a)') ' AL. [For save] ONLY TIP coordinates are saved in [coordinates.inc]'
  end if
  write(*,'(a)') ' An. [For input] Coordinates are specified in: '//angstr
  write(*,'(a)')  ' Co. Show atomic positions '
  write(*,'(a)') '  Q. Quit.'
  write(*,*)
  write(*,*)'Specify the character and press ENTER ------->'
  read(*,'(a)',err=21) cha2  ; write(8,'(a)') cha2
  call right(cha2,2,l0)

![Vp].......... two in-plane vectors along the 1st & 2nd directions to define the box

  IF(cha2(l0:).eq.'Vp' .and. (NGX_.ne.0 .and. NGY_.ne.0) ) THEN

8    write(*,*)'>>>>>>>>>> Two IN-PLANE VECTORS of the box <<<<<<<<<<<<<<'

     if(angstr.eq.'<AtomNumber>') then
5       write(*,*)'Give the atom at the beginning of both vectors:'
        read(*,*,err=5) anum ; write(8,*) anum
6       write(*,*)'Give the atom at the end of the 1st vector:'
        read(*,*,err=6) anum1 ; write(8,*) anum1
        if(anum.eq.anum1) go to 5
        vec1(1)=TI(1,anum1)-TI(1,anum) ; vec1(2)=TI(2,anum1)-TI(2,anum)
7       write(*,*)'Give the atom at the end of the 2nd vector:'
        read(*,*,err=7) anum2 ; write(8,*) anum2
        if(anum.eq.anum2 .or. anum1.eq.anum2) go to 7
        vec2(1)=TI(1,anum2)-TI(1,anum) ; vec2(2)=TI(2,anum2)-TI(2,anum)
     else
11      write(*,*)'Give 2 Cartesian compoenents (X,Y) of the 1st vector to define the box:'
        read(*,*,err=11) vec1(1),vec1(2) ; write(8,*) vec1(1),vec1(2)
        v1=sqrt(vec1(1)*vec1(1)+vec1(2)*vec1(2))
        if(v1.lt.tiny) go to 11
12      write(*,*)'Give 2 Cartesian compoenents (X,Y) of the 2nd vector to define the box:'
        read(*,*,err=12) vec2(1),vec2(2) ; write(8,*) vec2(1),vec2(2)
        v2=sqrt(vec2(1)*vec2(1)+vec2(2)*vec2(2))
        if(v2.lt.tiny) go to 12
!______________ check if the 2 vectors are colllinear        
        v12=vec1(1)*vec2(1)+vec1(2)*vec2(2)
        if(1.0-v12/(v1*v2) .lt. tiny) then
           write(*,*) 'ERROR! The two vectors are (nearly) collinear!'
           go to 8
        end if
     end if

![Dm].......... dimensinality of the grid

  ELSE IF(cha2(l0:).eq.'Dm') THEN

     if(Type.eq.'3D') then
        Type='2D'
     else if(Type.eq.'2D') then
        Type='1D'
     else 
        Type='3D'
     end if
     
![Cp].......... specify the corner point for the box

  ELSE IF(cha2(l0:).eq.'Cp') THEN

     write(*,*)'>>>>> Specify the corner point of the box. <<<<<'
     if(angstr.eq.'<AtomNumber>') then
9       write(*,*) &
             'Firstly, specify the X,Y cordinates of the corner point using atom number:'
        read(*,*) anum ; write(8,*) anum
        if(anum.lt.1 .or. anum.gt.ITI) go to 9
        Cp(1)=TI(1,anum) ; Cp(2)=TI(2,anum)
     else
10      write(*,*) &
             'Firstly, specify the X,Y cordinates of the corner point in Cartesian:'
        read(*,*) Cp(1),Cp(2) ; write(8,*) Cp(1),Cp(2)
     end if
13   write(*,'(2(a,f10.5),a)') 'Secondly, specify the Z. It must be within [',zup,',',middle,']'
     read(*,*,err=13) Cp(3) ; write(8,*) Cp(3)
     if(Cp(3).lt.zup .or. Cp(3).gt.middle) then
        write(*,*)'WARNING! the Z-compoenent is outside the Z-window!'
     end if
        
![Up].......... specify the z-upper point for the box

  ELSE IF(cha2(l0:).eq.'Up') THEN
     
14   write(*,*)'Specify Z of the upper point of the box within  [',zup,',',middle,']:'
     read(*,*,err=14) Zupper ; write(8,*) Zupper
     if(Zupper.lt.Cp(3) .or. Zupper.gt.middle) then
        write(*,*)'ERROR! Choose within the correct Z windows'
        go to 14
     end if

![P].......... whether the system can be periodically extended within the surface plane or not
!              This is the case if the vectors vec1, vec2 correspond to the primitive surface unit cell,
!              while the current vectors AJ(1,) and AJ(2,) are vectors extended fro them.     
     
  ELSE IF(cha2(l0:).eq.'P' .and. (NGX_.ne.0 .and. NGY_.ne.0) ) THEN

     if(periodic) then
        periodic=.false.
     else
        periodic=.true.
     end if
     
![Gr].......... specify the grid

  ELSE IF(cha2(l0:).eq.'Gr') THEN

     NGX1=NGX_ ; NGY1=NGY_ ; NGZ1=NGZ_
     if(Type.eq.'3D') then
        write(*,*)'Specify the grid along 3 vectors of the box:'
        read(*,*,err=21) NGX1,NGY1,NGZ1 ; write(8,*) NGX1,NGY1,NGZ1
        if(NGX1 * NGY1 * NGZ1 .eq. 0)  then
           write(*,*) 'ERROR: the grid is wrong: cannot be 0'
           go to 21
        end if
     else if(Type.eq.'2D') then
        write(*,*)'Specify the grid along 2 vectors of the box within the XY plane:'
        read(*,*,err=21) NGX1,NGY1 ; write(8,*) NGX1,NGY1
        if(NGX1 * NGY1 .eq. 0)  then
           write(*,*) 'ERROR: the grid is wrong: cannot be 0'
           go to 21
        end if
     else if(Type.eq.'1D') then
        write(*,*)'Specify the grid along the 3rd vector only'
        read(*,*,err=21) NGZ1 ; write(8,*) NGZ1
     end if
     if(NGX1.lt.0 .or. NGY1.lt.0 .or. NGZ1.lt.0) then
        write(*,*) 'ERROR: the grid is wrong: must be non-negative'
        go to 21
     else if(NGX1.gt.9999 .or. NGY1.gt.9999 .or. NGZ1.gt.9999) then
        write(*,*) 'ERROR: the grid is too large, must be =< 9999'
        go to 21
     end if
     NGX_=NGX1 ; NGY_=NGY1 ; NGZ_=NGZ1
     
![Tp].......... tag tip atoms

  ELSE IF(cha2(l0:).eq.'Tp') THEN

     listat=.false. ; tagYES=.false.
     
     call TTag(tagYES,ITI,TI,Labels,listat,lists,length, &
          N_lists,long_lists)
     do i=1,ITI
        if(listat(i)) then
           tagYES=.true. ;  exit
        end if
     end do

![Ta].......... ref tip atom: its position defines the positions of all atoms of the tip

  ELSE IF(cha2(l0:).eq.'Ta' .and. tagYES) THEN

     write(*,*)'Give the atomic number of a tip atom that will define the tip position:'
     read(*,*,err=21) ref_at ; write(8,*) ref_at
     if(ref_at.lt.0 .or. ref_at.gt.ITI .or. .not.listat(ref_at))  go to 21
     do i=1,3
        delta(i)=Cp(i)-TI(i,ref_at)
     end do
     ref_Tip_At=.true.

![Vs]...... show lattice vectors & box vectors
     
  ELSE IF(cha2(l0:).eq.'Vs' .and. CHIMERA) THEN
        
     open(35,file='vectors.vct',form='formatted',status='unknown')
     if(YES_Lv) then 
        write(35,*) '6'
        do i=1,3
           write(35,*) (AJ(i,j),j=1,3)
        end do
     else
        write(35,*) '3'
     end if
     write(35,*) vec1(1),vec1(2),' 0.0'
     write(35,*) vec2(1),vec2(2),' 0.0'
     write(35,*) vec3(1),vec3(2),vec3(3)
     close(35)

![An]...... choose the way how the coordinates are given

  ELSE IF(cha2(l0:).eq.'An') THEN

     if(angstr.eq.'<Angstroms> ') then
        angstr='<AtomNumber>'
     else if(angstr.eq.'<AtomNumber>') then
        angstr='<Angstroms> '
     end if

![Lv]...... show lattice vectors in CHINERA or not

  ELSE IF(cha2(l0:).eq.'Lv') THEN

     if(YES_Lv) then
        YES_Lv=.false.
     else 
        YES_Lv=.true.
     end if

![S].......... Save 
        
  ELSE IF(cha2(l0:).eq.'S' .and. tagYES .and. ref_Tip_At) THEN

!______ determine positions of the tip atom(s), create the correct directory
!       structure and write the input file in each directory.
!       Tip atom(s) is(are) assumed the last in the list.

     if(Yes_Mv) then
        write(*,*)'*** Enter the name of the input file containing ***'
        write(*,*)'*** the [@include coordinates.inc] statememnt   ***'
        read(*,'(a)') name ; write(*,'(a)') name
        call right(name,100,ln)
     end if
     TI1=TI
     do ix=0,NGX_
        call name_from_number(ix,chx,lx,err)
        do iy=0,NGY_
           call name_from_number(iy,chy,ly,err)
           do iz=0,NGZ_
              call name_from_number(iz,chz,lz,err)
              
              dir=chx(lx:)//'.'//chy(ly:)//'.'//chz(lz:)
              ll=2+(5-lx)+(5-ly)+(5-lz)
              write(*,*) '... creating directory '//dir(1:ll)
              call system('mkdir '//dir(1:ll))

              do iA=1,ITI
                 if(listat(iA)) then
                    if(NGX_.ne.0 .and. NGY_.ne.0) then
                       TI1(1,iA)= TI(1,iA) + delta(1) + ix*vec1(1)/NGX_ + iy*vec2(1)/NGY_
                       TI1(2,iA)= TI(2,iA) + delta(2) + ix*vec1(2)/NGX_ + iy*vec2(2)/NGY_
                    else if(NGX_.eq.0 .and. NGY_.ne.0) then
                       TI1(1,iA)= TI(1,iA) + delta(1) + iy*vec2(1)/NGY_
                       TI1(2,iA)= TI(2,iA) + delta(2) + iy*vec2(2)/NGY_
                    else if(NGX_.ne.0 .and. NGY_.eq.0) then
                       TI1(1,iA)= TI(1,iA) + delta(1) + ix*vec1(1)/NGX_
                       TI1(2,iA)= TI(2,iA) + delta(2) + ix*vec1(2)/NGX_
                    else if(NGX_.eq.0 .and. NGY_.eq.0) then
                       TI1(1,iA)= TI(1,iA) + delta(1) 
                       TI1(2,iA)= TI(2,iA) + delta(2) 
                    end if
                    if(NGZ_.eq.0) then
                       TI1(3,iA)= TI(3,iA) + delta(3)  
                    else
                       TI1(3,iA)= TI(3,iA) + delta(3) + iz*vec3(3)/NGZ_
                    end if
                 end if
              end do
              
!______________ create file [coordinates.inc] with atomic positions in each directory
              
              open(19,file='coordinates.inc')
              iA=0
              do k=1,Nsp
                 do is=1,NspN(k)
                    iA=iA+1
                    if(Yes_All .or. listat(iA)) &
                       write(19,'(a,3(x,f10.5))') Species(k),TI1(1:3,iA)
                 end do
              end do
              close(19)
              write(*,'(a)') 'mv coordinates.inc '//dir(1:ll)//'/.'
              call system('mv coordinates.inc '//dir(1:ll)//'/.')
              if(Yes_Mv) then
                 write(*,'(a)') 'cp '//name(ln:)//' '//dir(1:ll)//'/input.inp'
                 call system('cp '//name(ln:)//' '//dir(1:ll)//'/input.inp')
           end if
           end do
        end do
     end do
        
!______________ save the file for lev00      

     open(18,file='for_lev00.dat')
     write(18,*) Cp ; write(18,*) vec1 ; write(18,*) vec2
     write(18,*) vec3 ; write(18,*) NGX_,NGY_,NGZ_
     if(periodic) then
        write(18,*) '1 periodic'
     else 
        write(18,*) '0 non-periodic'
     end if
     write(18,'(2a)') Type(1:1),'  - '//Type//'-system'
     write(18,'(10(l1,x))') (listat(iA),iA=1,ITI)
     close(18)
      
![Co].... display atomic positions

  ELSE IF(cha2(l0:).eq.'Co') THEN

     call show_atoms(listat)

![AL].... which atoms to save in [coordinates.inc] file: only tip (.false.) or all (.true.)?

  ELSE IF(cha2(l0:).eq.'AL') THEN

     if(Yes_All) then
        Yes_All=.false.
     else
        Yes_All=.true.
     end if

![Si].... move the input file with @include statement into each directory or not

  ELSE IF(cha2(l0:).eq.'Si') THEN

     if(Yes_Mv) then
        Yes_Mv=.false.
     else
        Yes_Mv=.true.
     end if

![Q]...... quit

  ELSE IF(cha2(l0:).eq.'Q') THEN
      
!.......... return the original settings

     return
  ELSE
     write(*,*) 'Wrong! Try again!'
  END IF
  go to 21
     
!..................................................................................      
!............................. MENY ENDS ..........................................
!..................................................................................      
end subroutine EA_model_mesh






