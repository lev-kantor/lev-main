      subroutine change(nkp,kpoint,Which_Code)
!..........................................................................
! A number of tasks is performed:
!
! (1) a different choice of primitive lattice vectors giving equivalent
!     representation of the given lattice;
! (2) a rotation of the coordinate system; in this case a rotation of
!     the given set of lattice vectors is performed (fractional coordinates
!     of atoms will not change);
! (3) a new Cartesian origin is taken, i.e. the system is shifted by
!     a given vector, e.g. to the centre of mass;
! (4) SLAB calculation: change  the 3rd lattice vector to increase/decrease
!     the vacuum gap.
! (5) a different choice of primitive lattice vectors, e.g. with respect to
!     a plane specified by Miller indices.
! (6) large unit cell (supercell) construction ("breeding")
!
!  + a lot lot more (see the menu below!)
!...........................................................................
!     After the new coord. system or set of lattice vectors is choisen,
! then:
! (a) Cartesian coordinates of all atoms in the cell are recalculated;
! (b) a new crystal class symmetry group and the largest symmorphic point
!     group of the system is provided;
! (c) user can go to the k-points generator;
!....................................................................
      use real8
      use tetrag1
      use pgroup
      use mlists
      use buffer_index
      use buffer
      use buffer0
      use buffer1
      use reference
      use bb
      implicit none

      real(8) :: x(3),r(3),TI2(3,N0LT),dir(3)
      integer :: NspN2(N0KD)
      character :: spec*2,typ
      character :: line*200
      character(len=FLEN) :: seed1
      character :: Labels(N0LT)*2
      integer :: LinEnd(100),LinPos(100),NumLin
      integer :: iSort(N0LT),iorbit(N0LT),local(MG0)
      real(8) :: Shift(3),v(3),vmod(3),Fr(3,N0LT),cntp(3)
      real(8) :: xn(3,neighb0),C_rot(3,3),Add_Vects(5,3)
      character :: answer,cha2*2
      logical :: errr,listat(N0LT),TagYES,FinPos,Err,back,ts_list(N0LT)
      logical,dimension(:), allocatable :: listb
      logical :: ask_equiv,listt(N0LT),BSSE_tag,Frozen_at
      logical :: list_fr(N0LT),thesame,list1(N0LT),Yes_div
      character :: Which_Format*6,Which_Code*6,cha4*4,ch4*4,hh4*4,cc*100
      real(8) :: kpoint(Nkpoint,3)
      character*12 :: angstr='<AtomNumber>'
      character*4 :: YES_xyz='Xmol'
      real(8) :: tiny=0.000001,toler=0.1d0,H_at_dist=1.0,wdth_nn=0.1
      integer :: M1=0,N1=0,M2=0,N2=0,M3=0,N3=0
      logical :: Add_Hs=.false.
      character*2,dimension(3),parameter :: fst_nd_rd=(/'st','nd','rd'/)
!
      integer :: i_luc,ig,iErr,iAt,ii,in,i1,i2,k,i,nkp,i0,i3,jsp,iRot,ll
      integer :: Num_Vects,ion,ior,iorb,ir,is,is1,isp,jj,j2,j1,j,iv,ITI2,N_v,stat
      integer :: jsp3,k1,kjsp,l,l0,l0seed1,l1,L_ext,L_ext1,nat1,nat2
      integer :: lenfr,length,kk,lr,MG_luc,mlg,n_of_neighb,n_tagged,nat
      integer :: jsp_species
      real(8) :: prod123,r_luc,scalef,cos12,sin12,fr1,fr3,TotMass
      real(8) :: rMG_luc,vdot13,vdot23,vdot12,a1,a2,a3,acofm,dd,dmove

!........... MENU ...........................................
!
!___________ keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)

!___________ keep the old geometry for undo

      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)
!
!___________ initialise tags
      tagYES=.false. ; listat=.false.
      call initial_mol_index(iMol,Mol_index,BSSE_tag)
!
!___________ initialise the reference geometry
      ITIz=ITI ; TIz=TI ; AZ=AJ ; NspNz=NspN ; Nspz=Nsp
      Speciesz=Species ; Num_Vects=0
!
!========================================================================
!===================== MENU starts here =================================
!========================================================================

      ts_list=.false.

!___________ initialise the list of frozen atoms
 21   Frozen_at=.false.
      do i=1,ITI
         list_fr(i)=.false.
         if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' .or. &
               relax_flag(3,i).eq.'F') then
            list_fr(i)=.true. ; Frozen_at=.true.
         end if
      end do
      if(Frozen_at) call do_nice_list(list_fr,ITI,listfr,lenfr, &
                                                 N_lists,long_listfr)
!
      write(*,*)
      write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,'(a,4x,a)') '......... CURRENT lattice vectors ...', &
                             '.... REFERENCE lattice vectors ........'
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x),5x,3(f10.5,x))') &
              '[',i,'] ',(AJ(i,j),j=1,3),(AZ(i,j),j=1,3)
      end do
      write(*,'(a,5x,20(a2,x))') '>>> Species: ',(Species(i),i=1,Nsp)
      iAt=0
      do i=1,Nsp
         do ii=1,NspN(i)
            iAt=iAt+1 ; Labels(iAt)=Species(i)
         end do
      end do
      L_ext1=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)
      write(*,'(a,3(i2,a,i2,a),i3,a,i5)') &
           '>>> Box: [',M11,'...',N11,'] x [', M22,'...',N22,'] x [', &
         M33,'...',N33,'], ext = ',L_ext1,', # of atoms= ',ITI*L_ext1
      write(*,'(a)')'>>>>>>>>>>>>>>>>>> MENU <<<<<<<<<<<<<<<<<<<<'

!      write(*,*)'========= CHOOSE AN OPTION:'
!      write(*,*)
!      write(*,*)
!     &     '/==================================================\\'
!      write(*,*)'||  HELP: a complex transformation is obtained by  ||'
!      write(*,*)'|| applying elementary operations one after another||'
!      write(*,*)'\\==================================================/'
!      write(*,*)

      write(*,*) &
      '  1. Shift (new origin)       ||   2. Shift (center of mass)'
      write(*,*) &
      '  3. Rotate                   ||  Sc. Rescale up/down'
      write(*,*) &
      '------------ o p e r a t i o n s   w i t h   c e l l s -------'
      write(*,*) &
      ' Ex. Diagonal "breeding"      ||  Su. General "breeding"'
      write(*,*) &
      ' C1. Change 1 translation     ||  C3. Change 3 translations'
      write(*,*) &
      ' Sr. Build surface            ||  44. Cluster atoms'
      write(*,*) &
      ' Rf. Adjust to ref. file      ||  Rd. Reduction to primitive'
      write(*,*) &
       '  5. Set all atoms inside the cell box (0 < fract.coord. < 1 )'
      write(*,*) &
      '-------------- o t h e r   o p e r a t i o n s----------------'

!___________ BSSE calculation (with SIESTA and CP2K)
      BSSE_tag=.false.
      do i=1,ITI
         if(Mol_index(i).eq.0) go to 19
      end do
      BSSE_tag=.true.
 19   if(BSSE_tag) then
         write(*,*)' B1. DIVISIONS: redo divisions from scratch'
         write(*,*) &
          '     DIVISIONS: their current number = ',iMol,' <- complete'
         if(Which_Code.eq.'SIESTA') then
            write(*,*)' B2. SIESTA: BSSE + density difference script'
         else if(Which_Code.eq.'QUICKS') then
            write(*,*) &
                 ' B2. QUICKSTEP: Input file for the BSSE calculation'
         end if
         write(*,*)' B3. Generate script for density difference'
      else
         write(*,*) &
               ' B1. DIVISIONS: divide up the system into molecules'
         write(*,*) &
               '     DIVISIONS: current number of divisions = ',iMol
      end if

!___________ add operations + operations with multiple lists
      write(*,*) &
      ' Aa. Add an atom              ||  Ad. Add atoms from file'
      if(tagYES) then
         write(*,*) &
      '-------------- m u l t i p l e   l i s t s   -----------------'
         if(CHIMERA) then
            write(*,*) &
      '  T. Tagged atoms [ON]        ||  Td. Display tagged atoms'
         else
            write(*,*)'  T. Tagged atoms [ON]: '
         end if
         call print_long_char(lists,length,long_lists)
         write(*,*) &
      ' Rm. Remove tagged atoms      ||  Ru. Remove untagged'
         write(*,*) &
      ' Rn. Rename atoms             ||  Mv. Move atoms'
         write(*,*) &
      ' Rt. Rotate atoms             ||   H. Terminate with H atoms'
         write(*,*)' Re. Redefine atoms to an equivalent position'
      else
         length=0
         write(*,*) &
      ' Rm. Remove tagged atoms      ||  Ru. Remove untagged'
         write(*,*) &
      ' Rn. Rename atoms             ||  Mv. Move atoms'
         write(*,*) &
      ' Rt. Rotate atoms             ||   H. Terminate with H atoms'
         write(*,*)' Re. Redefine atoms to an equivalent position'
         write(*,*) &
      '-------------- m u l t i p l e   l i s t s   -----------------'
         write(*,*) &
      '  T. Tag atoms (simple) [OFF] ||  TT. Tag atoms (complex)'
      end if
      if(Frozen_at) then
         if(CHIMERA) then
            write(*,*) &
      ' Fa. Frozen atoms:            ||  Fd. Display frozen atoms'
         else
            write(*,*)' Fa. Frozen atoms:'
         end if
         call print_long_char(listfr,lenfr,long_listfr)
      else
         write(*,*)' Fa. Frozen atoms:     <-- not set'
      end if

!_____ show settings

      write(*,*) &
      '---------- v i s u a l i a s i o n   s e t t i n g s ---------'
!___________ set YES_xyz to the visualisation code:
!            make geom.xyz file automatically after every change
      write(*,*) &
      ' Bb. Breeding box size        ||  B0. Nullify the breeding box'
      write(*,*) '  W. Write <geom.xyz> file    ||  Vs. Show ', &
                      Num_Vects,' (lattice+) vectors (up to 5)'
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,*)' Hs. Show axes when viewing the system: YES'
         else
            write(*,*)' Hs. Show axes when viewing the system: NO'
         end if
      else
!         write(*,*)' Tb. Remove (Return) tagged atoms from (to) visualisation'
         if(L_ext1.eq.1) write(*,*)' Ts. System atoms not to be shown in visualisation'
      end if
!      if(YES_xyz.ne.'None') then
!         write(*,*)
!     &   ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
!      else
!         write(*,*)
!     &   ' XY. Do NOT produce <geom.xyz> file after every change'
!      end if

      write(*,*) &
      '-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,*) &
      ' UU. RESTORE original cell    ||   U. UNDO the last step'
      write(*,*) &
           ' Sy. Show point symmetry      || '// &
       ' Sf. Save symmetrised forces (SIESTA)'
      write(*,*) &
      ' Co. Show atomic positions    ||  ST. Save Tagged atoms in XYZ'
      write(*,'(a)') &
      '  SR. Set current geometry as REFERENCE (for option H)'
      write(*,'(a,f10.5)') &
              '  Tl. Tolerance when reducing the cell is: ',toler
      write(*,'(a,f10.5)') &
              '  Hd. Distance between an atom and H is: ',H_at_dist
      write(*,'(a,f10.5)') &
              '  Nd. Spherical belt width when finding nn is: ',wdth_nn

      write(*,*) &
           ' An. [For input] Coordinates are specified in: '//angstr
      write(*,*) &
      '  S. Save the input file      ||   Q. Proceed/Quit'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

![XY]...... ask whether to produce geom.xyz file automatically

!      IF(cha2(l0:).eq.'XY') THEN

!         if(YES_xyz.eq.'None') then
!            YES_xyz='Ymol'
!         else if(YES_xyz.eq.'Ymol') then
!            YES_xyz='Xmol'
!         else if(YES_xyz.eq.'Xmol') then
!            YES_xyz='None'
!         end if

![Hs]...... add Hydrongens to geom.xyz or not

      IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN
!      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else
            Add_Hs=.true.
         end if

![Vs]...... add more Hydrongens to geom.xyz for showing vectors including lattice vectors

      ELSE IF(cha2(l0:).eq.'Vs') THEN
         
59       Num_Vects=0
         write(*,*) 'Show the 1st lattice translation (Yy/Nn)?'
         read(*,'(a)') answer
         if(answer.eq.'y' .or. answer.eq.'Y') then
            Num_Vects=Num_Vects+1
            Add_Vects(Num_Vects,1:3)=AJ(1,1:3)
         end if
         write(*,*) 'Show the 2nd lattice translation (Yy/Nn)?'
         read(*,'(a)') answer
         if(answer.eq.'y' .or. answer.eq.'Y') then
            Num_Vects=Num_Vects+1
            Add_Vects(Num_Vects,1:3)=AJ(2,1:3)
         end if
         write(*,*) 'Show the 3rd lattice translation (Yy/Nn)?'
         read(*,'(a)') answer
         if(answer.eq.'y' .or. answer.eq.'Y') then
            Num_Vects=Num_Vects+1
            Add_Vects(Num_Vects,1:3)=AJ(3,1:3)
         end if
         write(*,*)'Enter the number of additional vectors (up to ',5-Num_Vects,') or 0:'
         read(*,*,err=21) N_v ; write(8,*) N_v
         if(N_v.lt.0 .or. N_v.gt.2) go to 52
         if(N_v.ne.0) then
            do i=1,N_v
               write(*,'(a,i1,a)') 'Give vector  [',i,'] :'
               read(*,*,err=59) Add_Vects(Num_Vects+i,1:3)
               write(8,*) Add_Vects(Num_Vects+i,1:3)
            end do
            Num_Vects=Num_Vects+N_v
         end if
52       if(Num_Vects.gt.0 .and. CHIMERA) then
            open(35,file='vectors.vct',form='formatted',status='unknown')
            write(35,*) Num_Vects
            do i=1,Num_Vects
               write(35,*) Add_Vects(i,1:3)
            end do
            close(35)
!         else if(Num_Vects.eq.0 .and. CHIMERA) then
!            open(35,file='vectors.vct',iostat=stat,status='old')
!            close(35,status='delete')
         end if

![Fa]...... choose/modify the list of frozen atoms

      ELSE IF(cha2(l0:).eq.'Fa') THEN

         if(Frozen_at) then
            do i=1,ITI
               if(list_fr(i)) then
                  relax_flag(1:3,i)='T' ; list_fr(i)=.false.
               end if
            end do
            write(*,*)'WARNING! The frozen atoms unselected!'
            Frozen_at=.false.  ; go to 21
         end if

!__________ specify wanted atoms
         call TTag(Frozen_at,ITI,TI,Labels,list_fr,listfr,lenfr, &
                                            N_lists,long_listfr)
         if(.not.Frozen_at) go to 21

!__________ set relaxation flags
         do i=1,ITI
            if(list_fr(i)) relax_flag(1:3,i)='F'
         end do
!         Frozen_at=.true.

![SR]...... set the current geometry as the reference one (needed for H)

      ELSE IF(cha2(l0:).eq.'SR') THEN

         ITIz=ITI ; TIz=TI ; AZ=AJ ; NspNz=NspN ; Nspz=Nsp
         Speciesz=Species

![Tl].... tolerance when reducing the cell size (in A)

      ELSE IF(cha2(l0:).eq.'Tl') THEN

 58      write(*,*)'Specify the tolerance:'
         read(*,*,err=58) toler ; write(8,*) toler
         if(toler.le.0.0) go to 58

![Hd].... distance between atom and the terminating H (link atom)

      ELSE IF(cha2(l0:).eq.'Hd') THEN

 54      write(*,*)'Specify the distance to the terminating H atoms:'
         read(*,*,err=54) H_at_dist ; write(8,*) H_at_dist
         if(H_at_dist.le.0.0) go to 54

![Nd].... when seraching for nn, a sperical belt of width wdth_nn is
!         allowed

      ELSE IF(cha2(l0:).eq.'Nd') THEN

 53      write(*,*) 'Specify the allowed width of a spherical belt'
         write(*,*) 'when searching for nearest neighbours:'
         read(*,*,err=53) wdth_nn ; write(8,*) wdth_nn
         if(wdth_nn.lt.0.0) go to 53

![An]...... choose the way how the coordinates are given

      ELSE IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if
![Sc].... scale ll atomic positions by a factor

      ELSE IF(cha2(l0:).eq.'Sc') THEN
 57      write(*,*) 'Specify the scaling factor (to be multiplied with)'
         read(*,*,err=57) scalef ; write(8,*) scalef
         if(scalef.lt.tiny) go to 57

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ scale the current system
         AJ=AJ*scalef
         j=0
         do k=1,Nsp
            do is=1,NspN(k)
               j=j+1 ; TI(1:3,j)=TI(1:3,j)*scalef
            end do
         end do

!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

!___________ construct all lattice sites and write geom.xyz
         if(YES_xyz.ne.'None') &
       call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![1]...... ask about a shift of the system

      ELSE IF(cha2(l0:).eq.'1') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         write(*,*)'Specify in Cartesian (C,c) or via an atom (ENTER)?'
         read(*,'(a)') answer ; write(8,'(a)') answer
         if(answer.eq.'C' .or. answer.eq.'c') then
 13         write(*,*) &
                 'Give a new origin of the coordinate system as x,y,z:'
            read(*,*,err=13) (Shift(i),i=1,3)
            write(8,*) (Shift(i),i=1,3)
         else
 14         write(*,*) 'Give atomic number:'
            read(*,*,err=14) Nat ; write(8,*) Nat
            if(Nat.lt.1 .or. Nat.gt. ITI) go to 14
            Shift(1:3)=TI(1:3,Nat)
         end if
!
!___________ recalculate Cartesian atomic positions in TI(comp,number)
!             (BJ are still OLD reciprocal vectors corresponding to
!             old AJ=>AX):
!
         do k=1,ITI
            TI(1:3,k)=TI(1:3,k)-Shift(1:3)
         end do

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
              call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![2]...... shift the system to the center of mass

      ELSE IF(cha2(l0:).eq.'2') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!__________ ask about atomic masses
!
! 31      write(*,*)'Specify atomic masses in a.u.m. for all species:'
!         read(*,*,err=31) (AtMass(i),i=1,Nsp)
!         write(*,*)'Atomic masses are:'
!         write(*,*) (AtMass(i),i=1,Nsp)
!         write(*,*)'Do you want to correct masses (Y,y/other char)?'
!         read(*,'(a)') answer
!         if(answer.eq.'y'.or.answer.eq.'Y') go to 31
         do is=1,Nsp
            if(AtMass(is).eq.0.0) then
               write(*,*) 'ERROR! Atomic mass for '//Species(is)// &
                    ' is NOT available!'
               write(*,*)'Cannot proceeed! Press ENTER when ready ...'
               read(*,*) ; write(8,'(a)') 'PressEnter'
               go to 21
            end if
         end do
         Shift(1:3)=0.0 ; TotMass=0.0
         iAt=0
         do i=1,Nsp
            do ii=1,NspN(i)
               iAt=iAt+1
               Shift(1:3)=Shift(1:3)+TI(1:3,iAt)*AtMass(i)
               TotMass=TotMass+AtMass(i)
            end do
         end do
         Shift(1:3)=Shift(1:3)/TotMass
!
!_____ shift the system (if necessary) to the center of mass
!
         acofm=sqrt(Shift(1)**2+Shift(2)**2+Shift(3)**2)
         if(acofm.gt.tiny) then
            write(*,*)'WARNING! Center of mass is NOT in the origin!'
            write(*,'(a11,1x,3(f10.5,1x),a2)') &
                 'It is at: (', (Shift(j),j=1,3),' )'
            write(*,*)'New atomic positions are:'
            do i=1,ITI
               TI(1,i)=TI(1,i)-Shift(1)
               TI(2,i)=TI(2,i)-Shift(2)
               TI(3,i)=TI(3,i)-Shift(3)
               write(6,'(i3,5x,3(f10.5,1x))') i,(TI(jj,i),jj=1,3)
            end do
         else
            write(*,*)'GOOD! Center of mass IS in the origin!'
         end if

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![3]...... rotate

      ELSE IF(cha2(l0:).eq.'3') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

 1       call rotate_system(AJ,AX)
!
!________ ask about vectors
         write(*,*)'... NEW lattice vectors for the supercell ...'
         write(*,'(a,3(x,f10.5))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(3):   ',(AJ(3,i),i=1,3)
         write(*,*) &
              'Did you wish just these to generate (Y,y/other char)?'
         read(*,'(a)') answer ; write(8,'(a)') answer
         if(answer.ne.'y'.and.answer.ne.'Y') go to 1

!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)
!
!________ change Cartesian positions of atoms
!
         do k=1,ITI
            a1=TI1(1,k)*BX(1,1)+TI1(2,k)*BX(1,2)+TI1(3,k)*BX(1,3)
            a2=TI1(1,k)*BX(2,1)+TI1(2,k)*BX(2,2)+TI1(3,k)*BX(2,3)
            a3=TI1(1,k)*BX(3,1)+TI1(2,k)*BX(3,2)+TI1(3,k)*BX(3,3)
            TI(1,k)=a1*AJ(1,1)+a2*AJ(2,1)+a3*AJ(3,1)
            TI(2,k)=a1*AJ(1,2)+a2*AJ(2,2)+a3*AJ(3,2)
            TI(3,k)=a1*AJ(1,3)+a2*AJ(2,3)+a3*AJ(3,3)
         end do

!___________ construct all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Re]......  move atoms around. This is e.g. useful while preparing a SLAB
!           calculation.

      ELSE IF(cha2(l0:).eq.'Re') THEN

         write(*,*) &
              '>>>>>>>>>>>>>>>>>>>> IMPORTANT! <<<<<<<<<<<<<<<<<<<<<<<<'
         write(*,*) &
             '........................................................'
         write(*,*) &
             'Picked atoms will be shifted by a lattice vector to an'
         write(*,*) 'equivalent position.'
         write(*,*) &
             '........................................................'

         if(.not.tagYES) then
 61         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=61) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 61
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ ask for the integer coefficients i1,i2,i3 of the shift

 62      write(*,'(a,i3,a)') &
              'Atoms will be moved by i1*AJ(1)+i2*AJ(2)+i3*AJ(3).'
         write(*,*)'Specify integers i1,i2,i3 for the shift:'
         read(*,*,err=62) i1,i2,i3 ; write(8,*) i1,i2,i3

!___________ shift atom nat
         do nat=1,ITI
            if(listat(nat)) then
               TI(1,nat)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+TI(1,nat)
               TI(2,nat)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+TI(2,nat)
               TI(3,nat)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+TI(3,nat)
            end if
         end do

!___________ constract all lattice sites and write geom.xyz
         if(YES_xyz.ne.'None') &
               call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![5]...... set all atoms inside the cell box, i.e. with the fractional coordinates
!          between 0 and 1

      ELSE IF(cha2(l0:).eq.'5') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ go through all atoms and "redefine" if necessary
         do nat=1,ITI
            do j=1,3
               fr1=TI(1,nat)*BJ(j,1)+TI(2,nat)*BJ(j,2)+TI(3,nat)*BJ(j,3)
               x(j)=fr1-int(fr1)
               if(fr1.lt.0.0) x(j)=x(j)+1.0
            end do
            TI(1,nat)=x(1)*AJ(1,1)+x(2)*AJ(2,1)+x(3)*AJ(3,1)
            TI(2,nat)=x(1)*AJ(1,2)+x(2)*AJ(2,2)+x(3)*AJ(3,2)
            TI(3,nat)=x(1)*AJ(1,3)+x(2)*AJ(2,3)+x(3)*AJ(3,3)
         end do

!___________ constract all lattice sites and write geom.xyz
         if(YES_xyz.ne.'None') &
               call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Rf]...... correct fractional coordinates of atoms in order for them
!           to be closer to those in a reference input file

      ELSE IF(cha2(l0:).eq.'Rf') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ choose the read format and then read in the geometry
 112     call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
         if(Which_Format.eq.'  None') go to 21
         call initiate(Which_Format,seed1,l0seed1,Err)
         if(Err) go to 112

!___________ keep the newly read geometry in /buffer1/
         call keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
!
!___________ restore the original geometry from /buffer/
         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ check consistency

         do i=1,3
            do j=1,3
               if(abs(AJ(i,j)-AY(i,j)).gt.tiny) go to 300
            end do
         end do
         if(Nsp.ne.Nsp3) go to 300
         do is=1,Nsp
            if(NspN(is).ne.NspN3(is)) go to 300
            if(Species(is).ne.Species3(is)) go to 300
         end do

!___________ correct coordinates

         do nat=1,ITI
            do j=1,3
               fr1=TI(1,nat)*BJ(j,1)+TI(2,nat)*BJ(j,2)+TI(3,nat)*BJ(j,3)
               fr3=TI3(1,nat)*BJ(j,1)+ &
                                TI3(2,nat)*BJ(j,2)+TI3(3,nat)*BJ(j,3)
               x(j)=fr1-nint(fr1-fr3)
            end do
            TI(1,nat)=x(1)*AJ(1,1)+x(2)*AJ(2,1)+x(3)*AJ(3,1)
            TI(2,nat)=x(1)*AJ(1,2)+x(2)*AJ(2,2)+x(3)*AJ(3,2)
            TI(3,nat)=x(1)*AJ(1,3)+x(2)*AJ(2,3)+x(3)*AJ(3,3)
         end do

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)
         go to 21
 300     write(*,'(a)')'ERROR! The two geometries are NOT consistent!'
         write(*,'(a)')'========= > Operation ABORTED! <============='
         write(*,'(8x,a)') 'Press ENTER when ready ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![44]...... new positions of atoms in the cell are found which
!           correspond to fractional coordinates between -0.5 and 0.5
!           around the origin at the specified point

      ELSE IF(cha2(l0:).eq.'44') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ specify the point

         call givepoint(x(1),x(2),x(3),angstr)

!___________ shift atoms to new positions

         do i=1,ITI
            r(1)=TI(1,i)-x(1)
            r(2)=TI(2,i)-x(2)
            r(3)=TI(3,i)-x(3)
            call reducn1(r,AJ,BJ)
            TI(1,i)=r(1)+x(1)
            TI(2,i)=r(2)+x(2)
            TI(3,i)=r(3)+x(3)
            write(6,'(i3,5x,3(f10.5,1x))') i,(TI(jj,i),jj=1,3)
         end do

!___________ constract all lattice sites and write geom.xyz
         if(YES_xyz.ne.'None') &
               call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Sr].... choose a new set of latttice vectors which are in the surface plane
!         specified by Miller indices or directly by the normal

      ELSE IF(cha2(l0:).eq.'Sr') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!(1)________ choose new basic lattice vectors so that the first two lie in the
!            specified plane.

         call normal_to_plane(AJ)
!
!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)
!
!________ work out fractional coordinates in new vectors
         do k=1,ITI
            Fr(1,k)=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
            Fr(2,k)=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
            Fr(3,k)=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
         end do

!(2)________ rotate the vectors so that the 1st is along X axis, the 2nd in the
!            XY plane, the 3rd as required to keep the same relative orientation
         do i=1,3
           vmod(i)=sqrt(AJ(i,1)*AJ(i,1)+AJ(i,2)*AJ(i,2)+AJ(i,3)*AJ(i,3))
         end do
         vdot12=AJ(1,1)*AJ(2,1)+AJ(1,2)*AJ(2,2)+AJ(1,3)*AJ(2,3)
         vdot13=AJ(1,1)*AJ(3,1)+AJ(1,2)*AJ(3,2)+AJ(1,3)*AJ(3,3)
         vdot23=AJ(2,1)*AJ(3,1)+AJ(2,2)*AJ(3,2)+AJ(2,3)*AJ(3,3)
         prod123=AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(3,2)*AJ(2,3))- &
                 AJ(1,2)*(AJ(2,1)*AJ(3,3)-AJ(3,1)*AJ(2,3))+ &
                 AJ(1,3)*(AJ(2,1)*AJ(3,2)-AJ(3,1)*AJ(2,2))
         cos12=vdot12/(vmod(1)*vmod(2))  ; sin12=sqrt(1.0-cos12*cos12)
!________ new vectors
         AJ(1,1)=vmod(1) ; AJ(1,2:3)=0.0
         AJ(2,1)=vmod(2)*cos12 ; AJ(2,2)=vmod(2)*sin12 ; AJ(2,3)=0.0
         AJ(3,1)=vdot13/vmod(1)
         AJ(3,2)=( vdot23/vmod(2)-vdot13/vmod(1)*cos12 )/sin12
         AJ(3,3)=prod123/(vmod(1)*vmod(2)*sin12)

!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)
!
!(3)________ change Cartesian positions of atoms
!
         do k=1,ITI
           TI(1,k)=Fr(1,k)*AJ(1,1)+Fr(2,k)*AJ(2,1)+Fr(3,k)*AJ(3,1)
           TI(2,k)=Fr(1,k)*AJ(1,2)+Fr(2,k)*AJ(2,2)+Fr(3,k)*AJ(3,2)
           TI(3,k)=Fr(1,k)*AJ(1,3)+Fr(2,k)*AJ(2,3)+Fr(3,k)*AJ(3,3)
         end do

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
              call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Ex].... LUC construction: simple (diaginal) "breeding" of atoms

      ELSE IF(cha2(l0:).eq.'Ex') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ ask extensions along the existing lattice vectors for the
!            breeding box
         call ask_breeding_box(M1,N1,M2,N2,M3,N3)

!___________ check first

         L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
         if(ITI*L_ext.gt.N0LT) then
            write(*,*) &
              'ERROR! The breeding box is too big, see tetr_param.inc'
            go to 21
         end if

!___________ construct all lattice sites
         jj=0
         nat=0
         DO i=1,Nsp
            write(*,'(a25,i3,a8)')'___> Atoms in species ',i,' <____'
            NspN2(i)=0
            do i1=M1,N1
               do i2=M2,N2
                  do i3=M3,N3

                     DO k=1,NspN(i)
                        jj=jj+1
                        TI(1,jj)=i1*AJ(1,1)+i2*AJ(2,1)+i3*AJ(3,1)+ &
                             TI1(1,k+nat)
                        TI(2,jj)=i1*AJ(1,2)+i2*AJ(2,2)+i3*AJ(3,2)+ &
                             TI1(2,k+nat)
                        TI(3,jj)=i1*AJ(1,3)+i2*AJ(2,3)+i3*AJ(3,3)+ &
                             TI1(3,k+nat)
                        NspN2(i)=NspN2(i)+1
                        relax_flag(1,jj)=relax_flag1(1,k+nat)
                        relax_flag(2,jj)=relax_flag1(2,k+nat)
                        relax_flag(3,jj)=relax_flag1(3,k+nat)
                     END DO

                  end do
               end do
            end do
            nat=nat+NspN(i)
            NspN(i)=NspN2(i)
            write(*,*)'................ found ',NspN(i),' atoms'
         END DO
         ITI2=jj
         write(*,'(i5,a)') ITI2,' sites have been identified'
         L_ext=ITI2/ITI
         write(*,'(a,i3)')'INFO(2): found UC->LUC extension L=',L_ext
         ITI=ITI2

!___________ modify the lattice vectors
         do i=1,3
            AJ(1,i)=AJ(1,i)*(N1-M1+1)
            AJ(2,i)=AJ(2,i)*(N2-M2+1)
            AJ(3,i)=AJ(3,i)*(N3-M3+1)
         end do

!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

!_________ initialise division index
         call initial_mol_index(iMol,Mol_index,BSSE_tag)

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Su].... LUC construction: complex "breeding" of atoms

      ELSE IF(cha2(l0:).eq.'Su') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ specify extention matrix

 34      write(*,*)'Choose 3x3 integer extention matrix UC => LUC.'
 3       write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=3) (IJ(1,j),j=1,3)
         write(8,*) (IJ(1,j),j=1,3)
 4       write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=4) (IJ(2,j),j=1,3)
         write(8,*) (IJ(2,j),j=1,3)
 5       write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=5) (IJ(3,j),j=1,3)
         write(8,*) (IJ(3,j),j=1,3)
         MG_luc=abs(IJ(1,1)*(IJ(2,2)*IJ(3,3)-IJ(3,2)*IJ(2,3)) - &
              IJ(2,1)*(IJ(1,2)*IJ(3,3)-IJ(3,2)*IJ(1,3)) + &
              IJ(3,1)*(IJ(1,2)*IJ(2,3)-IJ(1,3)*IJ(2,2)))
         write(*,*) 'cell ==> supercell extention = ',MG_luc
         if(abs(MG_luc).lt.tiny) then
            write(*,*) 'ERROR! Zero extention!'
            write(*,*) 'Press ENTER ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
            go to 21
         end if
         if(ITI*MG_luc.gt.N0LT) then
            write(*,*) &
              'ERROR! The breeding box is too big, see tetr_param.inc'
            write(*,*)'Press ENTER ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
            go to 21
         end if
         ITI=ITI*MG_luc
         do k=1,3
            do k1=1,3
               AI(k,k1)=AJ(k,k1)
               BI(k,k1)=BJ(k,k1)
            end do
         end do
         do k=1,3
            AJ(1,k)=IJ(1,1)*AI(1,k)+IJ(1,2)*AI(2,k)+IJ(1,3)*AI(3,k)
            AJ(2,k)=IJ(2,1)*AI(1,k)+IJ(2,2)*AI(2,k)+IJ(2,3)*AI(3,k)
            AJ(3,k)=IJ(3,1)*AI(1,k)+IJ(3,2)*AI(2,k)+IJ(3,3)*AI(3,k)
         end do
         call INVER(AJ,BJ)

!____________ generate internal translations
         call LACE(MG_luc,iErr)
         if(iErr.eq.1) stop 'ERROR in LACE! STOP'

!____________ generate positions of all atoms in the supercell
         j=0 ; j1=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN(k)
               j1=j1+1
               do k1=1,MG_luc
                  j=j+1
                  TI(1:3,j)=TRAN(k1,1:3)+TI1(1:3,j1)
                  relax_flag(1:3,j)=relax_flag1(1:3,j1)
               end do
            end do
            NspN(k)=NspN(k)*MG_luc
         end do

!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

!_________ initialise division index
         call initial_mol_index(iMol,Mol_index,BSSE_tag)

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Rd].... UC construction from LUC: complex cell "reduction"

      ELSE IF(cha2(l0:).eq.'Rd') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ specify extention matrix

         write(*,*) &
         'Choose 3x3 (real) extention matrix CURRENT => REDUCED cell:'
 83      write(*,*)' Give elements 11,12,13 of it:'
         read(*,*,err=83) (rIJ(1,j),j=1,3)
         write(8,*)  (rIJ(1,j),j=1,3)
 84      write(*,*)' Give elements 21,22,23 of it:'
         read(*,*,err=84) (rIJ(2,j),j=1,3)
         write(8,*)  (rIJ(2,j),j=1,3)
 85      write(*,*)' Give elements 31,32,33 of it:'
         read(*,*,err=85) (rIJ(3,j),j=1,3)
         write(8,*) (rIJ(3,j),j=1,3)
         rMG_luc=abs(rIJ(1,1)*(rIJ(2,2)*rIJ(3,3)-rIJ(3,2)*rIJ(2,3)) - &
              rIJ(2,1)*(rIJ(1,2)*rIJ(3,3)-rIJ(3,2)*rIJ(1,3)) + &
              rIJ(3,1)*(rIJ(1,2)*rIJ(2,3)-rIJ(1,3)*rIJ(2,2)))
         write(*,'(a,f10.5)') 'cell ==> factor rMG_luc      = ',rMG_luc
         r_luc=1./rMG_luc ;  i_luc=nint(1./rMG_luc)
         write(*,'(a,i4,a)') &
              'cell ==> supercell reduction = ',i_luc,' times'
         if(abs(rMG_luc).lt.tiny) then
            write(*,*)'ERROR! Zero reduction!'
            write(*,*)'Press ENTER ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
            go to 21
         end if
         if(rMG_luc.gt.1.0) then
            write(*,*) 'ERROR! This is NOT a reduction! '
            write(*,*)'Press ENTER ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
            go to 21
         end if
         do k=1,Nsp
            kk=NspN(k)/i_luc
            if(nint(NspN(k)/r_luc).ne.kk) then
               write(*,*) k,nint(NspN(k)/r_luc),kk
               write(*,*) &
                 'ERROR! The reduced cell CANNOT be the primitive one!'
               write(*,*)'Press ENTER ...'
               read(*,*) ; write(8,'(a)') 'PressEnter'
               go to 21
            end if
         end do
         ITI=ITI/i_luc
         write(*,*)'NEW expected number of atoms = ', ITI
         AI=AJ ; BI=BJ
         do k=1,3
            AJ(1:3,k)=rIJ(1:3,1)*AI(1,k)+rIJ(1:3,2)*AI(2,k)+ &
                                               rIJ(1:3,3)*AI(3,k)
         end do
         call INVER(AJ,BJ)

!____________ generate positions of all atoms in the reduced cell and check
!             consistency
         j1=0 ; list1=.true. ; j=0
         do k=1,Nsp
            write(*,*)'....... Atoms of species ',k,' ........'
            do is=1,NspN(k)
               j1=j1+1

               if(list1(j1)) then
                  j=j+1 ; list1(j1)=.false. ; TI(1:3,j)=TI1(1:3,j1)
                  relax_flag(1:3,j)=relax_flag1(1:3,j1)
                  r(1:3)=TI1(1:3,j1) ; j2=1
                  do nat=1,ITI1
                     if(list1(nat)) then
                        x(1:3)=r(1:3)-TI1(1:3,nat)
                        if(ask_equiv(x,BJ,3,toler)) then
                           write(*,'(2(a,i5),a)') &
                        '... Atom ',j1,' is equiv. to atom ',nat,' ...'
                           j2=j2+1 ; list1(nat)=.false.
                        end if
                     end if
                  end do
                  if(j2.ne.i_luc) then
                     write(*,*)'ERROR! The reduced cell CANNOT'// &
                                               ' be the primitive one!'
                     write(*,'(a,f10.5)') &
                          '*** Your current tolerance = ',toler
                     write(*,'(a)') &
                     '*** Consider reducing the tolerance -> option Tl'
                     write(*,*)'Press ENTER ...'
                     read(*,*) ; write(8,'(a)') 'PressEnter'
                     call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp, &
                          Species,relax_flag,Genrt)
                     call restore_mol_index(iMol,Mol_index,ITI)
                     go to 21
                  end if
               end if

            end do
            NspN(k)=NspN(k)/i_luc
            write(*,*)'NEW number of atoms in species ',k,' is ',NspN(k)
         end do

!_________ initialise division index
         call initial_mol_index(iMol,Mol_index,BSSE_tag)

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![C1]...... ask about ONE new lattice vector (e.g. for SLAB calculation)

      ELSE IF(cha2(l0:).eq.'C1') THEN

         write(*,*)'>>>>>>>>>>>>>>>>>> IMPORTANT! <<<<<<<<<<<<<<<<<<<<<'
         write(*,*) &
              'This step is to be the LAST ONE for creating vacuum gap.'
         write(*,*) &
              'You will NOT be able to move atoms around after that.'
         write(*,*)'Make sure that atoms in the unit cell are in place.'

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

 79      write(*,*) 'Which vector to change (1, 2 or 3)?'
         read(*,*,err=79) iv ; write(8,*) iv
         if(iv.lt.1 .or. iv.gt.3) go to 79
 11      write(*,'(a,i1,a)') &
            'Give a new ',iv,'-'//fst_nd_rd(iv)//' lattice vector:'
         read(*,*,err=11) (AJ(iv,i),i=1,3)
         write(8,*) (AJ(iv,i),i=1,3)
         write(*,*) '... NEW lattice vectors for the supercell ...'
         write(*,'(a,3(x,f10.5))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(3):   ',(AJ(3,i),i=1,3)
         write(*,*) &
              'Did you wish just these to generate (Y,y/other char)?'
         read(*,'(a)') answer ; write(8,'(a)') answer
         if(answer.ne.'y'.and.answer.ne.'Y') go to 11
!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![C3].... choose a new set of latttice vectors keeping atoms in
!        the same Cartesian positions (e.g. for molecules)

      ELSE IF(cha2(l0:).eq.'C3') THEN

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

 71      write(*,*) 'Give  new 1st lattice vector:'
         read(*,*,err=71) (AJ(1,i),i=1,3)
         write(8,*) (AJ(1,i),i=1,3)
 72      write(*,*) 'Give  new 2nd lattice vector:'
         read(*,*,err=72) (AJ(2,i),i=1,3)
         write(8,*) (AJ(2,i),i=1,3)
 73      write(*,*) 'Give  new 3rd lattice vector:'
         read(*,*,err=73) (AJ(3,i),i=1,3)
         write(8,*) (AJ(3,i),i=1,3)
         write(*,*) '... NEW lattice vectors for the supercell ...'
         write(*,'(a,3(x,f10.5))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(x,f10.5))') 'AJ(3):   ',(AJ(3,i),i=1,3)
         write(*,*) &
              'Did you wish just these to generate (Y,y/other char)?'
         read(*,'(a)') answer ; write(8,'(a)') answer
         if(answer.ne.'y'.and.answer.ne.'Y') go to 71
!_________ update reciprocal vectors BJ
         call INVER(AJ,BJ)

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Aa].... manually add an atom to the cell

      ELSE IF(cha2(l0:).eq.'Aa') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if
         if(angstr.eq.'<AtomNumber>') then
            write(*,*) &
              'ERROR! Option <AtomNumber> is meaningless in this case'
            write(*,*) &
                 '       Change it in the menu to Angstrem/Fractional'
            write(*,*)'       Press ENTER when done ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
            go to 21
         end if

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ now add atom

 98      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2 ; write(8,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if
!___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!'
            go to 98
         end if
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii
               go to 97
            end if
         end do
         jsp=Nsp+1
         NspN(jsp)=0
         Species(jsp)=spec

 97      call givepoint(x(1),x(2),x(3),angstr)
         call add_atom(x,jsp,errr,.true.,'T','T','T',ion,listat)
         if(errr) go to 97

!___________ construct all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![B1].... divide the system into molecules (for BSSE with SIESTA)

      ELSE IF(cha2(l0:).eq.'B1') THEN

!__________ keep the current indeces for undo

         call keep_mol_index(iMol,Mol_index,ITI)

!__________ specify atoms for molecule iMol
         if(BSSE_tag) call initial_mol_index(Imol,Mol_index,BSSE_tag)
         write(*,*) &
               '<|........ Identify system part ',iMol+1,' ..........|>'
 45      write(*,*) &
              'List atom numbers belonging to this part using spaces'
         write(*,*) &
             'and/or comma, and a dash (without space) to indicate'
         write(*,*)'from/to within the same list, e.g.: 1-5,9 7-8,15 25'
         write(*,*)'..................................................'
         write(*,*)'Press ENTER to clear the whole existing partition'
         read(*,'(a)') line ; write(8,'(a)') trim(Line)
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 45
         if(NumLin.eq.0) then
            call initial_mol_index(iMol,Mol_index,BSSE_tag)
            go to 21
         end if
!
         Yes_div=.false.
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*,err=45) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*,err=45) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*,err=45) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.ITI) go to 45
            do j=i1,i2
               if(Mol_index(j).eq.0) then
                  Mol_index(j)=iMol+1 ; Yes_div=.true.
               else
                  write(*,'(2(a,i3),a)') 'OVERLAP: atom ',j, &
          ' is already in part ',Mol_index(j),' -> Skipping change ...'
               end if
            end do
         end do
         if(Yes_div) iMol=iMol+1

![B2].... generate BSSE or density difference script (SIESTA, QUICKSTEP)
!         or input file (QUICKSTEP)

      ELSE IF(cha2(l0:).eq.'B2' .and. BSSE_tag .and. &
           (Which_Code.eq.'SIESTA' .or. Which_Code.eq.'QUICKS')) then

         if(Which_Code.eq.'SIESTA') THEN
            call BSSE_script(Which_Code)
         else if(Which_Code.eq.'QUICKS') THEN
            write(*,*)'Standard CP2K calculation (y) or TETR-way (n)?'
            read(*,'(a)') answer ; write(8,'(a)') answer
            if(answer.eq.'y' .or. answer.eq.'Y') then
               write(*,*)'WARNING: standard BSSE implementation in CP2K'
               call BSSE_input_QUICKS()
            else
               write(*,*) &
             'WARNING: bypassing standard BSSE implementation in CP2K'
               call BSSE_script(Which_Code)
            end if
         end if

![B3].... generate BSSE or density difference script

      ELSE IF(cha2(l0:).eq.'B3' .and. BSSE_tag ) THEN

         call Dens_Diff_script(Which_Code)

![Ad].... add atoms from another file of accepted formats

      ELSE IF(cha2(l0:).eq.'Ad') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in [tetr_param.inc] file!'
            go to 21
         end if

!___________ keep the old geometry in /buffer/

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ choose the read format and then read in the geometry
 111     call ask_which_format('  None',Which_Format,seed1,l0seed1,'R')
         if(Which_Format.eq.'  None') go to 21
         call initiate(Which_Format,seed1,l0seed1,Err)
         if(Err) go to 111

!___________ keep the newly read geometry in /buffer1/
         call keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)

!___________ restore the original geometry from /buffer/
         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ add atoms from /buffer1/ one by one to the old set
         nat=0
         do jsp3=1,Nsp3
            jsp=jsp_species(Species3(jsp3),Species,Nsp)
            if(jsp.eq.0) then
               jsp=Nsp+1 ; Species(jsp)=Species3(jsp3) ; NspN(jsp)=0
            end if
            do k=1,NspN3(jsp3)
               nat=nat+1 ; x(1:3)=TI3(1:3,nat)
               call add_atom(x,jsp,errr,.true.,relax_flag3(1,nat), &
                       relax_flag3(2,nat),relax_flag3(3,nat),ion,listat)
               if(errr) then
                  write(*,*)'WARNING! Atom #',nat,' cannot be accepted.'
               else
                  listat(ion)=.true.
               end if
            end do
         end do
         if(errr) then
            write(*,*)'<=========================================>'
            write(*,*)'WARNING! Some atoms (see above) were ignored'
            write(*,*)'Hit ENTER when ready ...'
            write(*,*)'<=========================================>'
            read(*,*)  ; write(8,'(a)') 'PressEnter'
         end if
         if(Nsp.ne.Nsp1) then
            write(*,*)'WARNING! Number of species changed!'
            write(*,*)'         New number of species = ',Nsp
         end if

         call do_nice_list(listat,ITI,lists,length,N_lists,long_lists)
         tagYES=.true.

!___________ construct all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![T].... tag atoms using a multiple lists method

      ELSE IF(cha2(l0:).eq.'T') THEN

         listat(1:ITI)=.false.
         if(tagYES) then
            write(*,*)'WARNING! The tagging is disabled!'
            tagYES=.false. ; go to 21
         end if

!__________ specify wanted atoms
         call Tag(NumLin,ITI,listat,lists,length,N_lists,long_lists)
         if(NumLin.eq.0) then
            tagYES=.false. ; go to 21
         end if
         tagYES=.true.

![TT].... tag atoms using more complex options

      ELSE IF(cha2(l0:).eq.'TT' .and. (.not.TagYes)) THEN

         call TTag(tagYES,ITI,TI,Labels,listat,lists,length, &
                    N_lists,long_lists)

![Td]... display selected atoms in the CHIMEERA window

      ELSE IF(cha2(l0:).eq.'Td' .and. TagYes .and. CHIMERA) THEN

         call write_list(listat)

![Fd]... display frozen atoms in the CHIMEERA window

      ELSE IF(cha2(l0:).eq.'Fd' .and. Frozen_at .and. CHIMERA) THEN

         call write_list(list_fr)

![Rm].... remove atoms from the cell - many lists

      ELSE IF(cha2(l0:).eq.'Rm') THEN

         if(.not.tagYES) then
 37         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=37) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 37
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ remove tagged atoms
         do i=ITI1,1,-1
            if(listat(i)) call remove_atoms(i,i,.true.,.true.)
            listat(i)=.false.
         end do
         tagYES=.false.

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
            call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Ru].... remove atoms from the cell by specifying atoms
!         which are to stay

      ELSE IF(cha2(l0:).eq.'Ru') THEN

         if(.not.tagYES) then
 38         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=38) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 38
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ remove untagged atoms
         do i=ITI1,1,-1
            if(.not.listat(i)) call remove_atoms(i,i,.true.,.true.)
            listat(i)=.false.
         end do
         tagYES=.false.

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Rn].... change species (i.e. rename atoms)

      ELSE IF(cha2(l0:).eq.'Rn') THEN

         if(.not.tagYES) then
 39         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=39) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 39
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

!___________ keep the old geometry for undo

         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!___________ (a) remove tagged atoms
!            (b) initialise listt to listat to keep the old list of tagged atoms

         do i=ITI1,1,-1
            listt(i)=listat(i)
            if(listat(i)) then
               call remove_atoms(i,i,.true.,.true.)
               listat(i)=.false.
            end if
         end do

!__________ ask the target species number
 42      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2 ; write(8,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if
!___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!'
            go to 42
         end if
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii ; go to 43
            end if
         end do
         jsp=Nsp+1 ; NspN(jsp)=0 ; Species(jsp)=spec

!__________ and add removed atoms as species jsp
 43      do k=1,ITI1
            if(listt(k)) then
               x(1:3)=TI1(1:3,k)
               call add_atom(x,jsp,errr,.false.,relax_flag1(1,k), &
                          relax_flag1(2,k),relax_flag1(3,k),ion,listat)
            end if
            listat(k)=.false.
         end do
         tagYES=.false.

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Mv]... Move atoms to another (general) position

      ELSE IF(cha2(l0:).eq.'Mv') THEN

         FinPos=.false.
         if(.not.tagYES) then
 36         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=36) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 36
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
            if(nat1.eq.nat2) FinPos=.true.
         end if

!___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ ask about the target.

 94      call ask_displacement(angstr,dir,dmove,dd,FinPos,nat1,back)
         if(back) then
            do i=1,ITI
               if(.not.tagYES) listat(i)=.false.
            end do
            go to 21
         end if

!___________ move all atoms
         do i=1,ITI
            if(listat(i) .and. dd.gt.tiny) then
               TI2(1:3,i)=TI(1:3,i)+dmove/dd * dir(1:3)
            else
               TI2(1:3,i)=TI(1:3,i)
            end if
         end do

!______ check new positions
         do k=1,ITI
            if(listat(k) .and. dd.gt.tiny) then
               do k1=1,ITI
                  if(k.ne.k1) then
                     r(1:3)=TI2(1:3,k1)-TI2(1:3,k)
                     if(ask_equiv(r,BJ,3,tiny_equiv)) then
                        write(*,*) 'ERROR! Found equivalences!'
                        go to 94
                     end if
                  end if
               end do
            end if
         end do
         write(*,*)'O.K.! New positions are fine!'
         do i=1,ITI
            if(listat(i)) then
               TI(1:3,i)=TI2(1:3,i)
            end if
            if(.not.tagYES) listat(i)=.false.
         end do

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Rt]... Rotate atoms about a general axis

      ELSE IF(cha2(l0:).eq.'Rt') THEN

         if(.not.tagYES) then
 32         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=32) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.ge.nat2 .or. nat1.lt.1 .or. nat2.gt.ITI) go to 32
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1 .and. i.le.nat2) listat(i)=.true.
            end do
         end if

!___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)

!___________ specify angles and the central point
 33      call specify_angle(cntp,C_rot)

!___________ rotate atoms
         do i=1,ITI
            if(listat(i)) then
               call rotate_atom(TI(1,i),TI(2,i),TI(3,i), &
                      TI2(1,i),TI2(2,i),TI2(3,i),cntp,C_rot)
            else
               TI2(1:3,i)=TI(1:3,i)
            end if
         end do

!______ check new positions
         do k=1,ITI
            if(listat(k)) then
               do k1=1,ITI
                  if(k.ne.k1) then
                     r(1:3)=TI2(1:3,k1)-TI2(1:3,k)
                     if(ask_equiv(r,BJ,3,tiny_equiv)) then
                        write(*,*) 'ERROR! Found equivalences!'
                        go to 33
                     end if
                  end if
               end do
            end if
         end do
         write(*,*)'O.K.! New positions are fine!'
         do i=1,ITI
            if(listat(i)) TI(1:3,i)=TI2(1:3,i)
            if(.not.tagYES) listat(i)=.false.
         end do

!___________ constract all lattice sites  and write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![H].... terminate specified atoms with hydrogens:
!        predefined geometry (reference) is used to generate nearest neighbours

      ELSE IF(cha2(l0:).eq.'H') THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if

         if(.not.tagYES) then
 56         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=56) nat1,nat2 ; write(8,*) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 56
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1 .and. i.le.nat2) listat(i)=.true.
            end do
         end if

!___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call keep_mol_index(iMol,Mol_index,ITI)

!__________ add H species first if not in the system already
         spec=' H'
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii ; go to 55
            end if
         end do
         jsp=Nsp+1 ; Species(jsp)=spec ; NspN(jsp)=0

!___________ now add terminating hydrogens
 55      do i=1,ITI1
            if(listat(i)) then
               call find_neighbours_for_M(i,xn,n_of_neighb,isp,wdth_nn)
               do in=1,n_of_neighb
                  x(1:3)=xn(1:3,in)+TI1(1:3,i)
                  if(.not.thesame(x,ITI1,TI1)) then
                     if(ITI+1.gt.N0LT) then
                        write(*,*) &
                          'ERROR! Increase N0LT in tetr_param.inc file!'
                        call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp, &
                                              Species,relax_flag,Genrt)
                        call restore_mol_index(iMol,Mol_index,ITI)
                        if(YES_xyz.ne.'None') call create_xyz1(M11,N11, &
                                         M22,N22,M33,N33,YES_xyz,Add_Hs, &
                                         Num_Vects,Add_Vects,ts_list)
                        go to 21
                     end if
                     call shift_pos(x,TI1(1,i),H_at_dist,dir)
                     call add_atom(x,jsp,errr,.true., &
                                                 'T','T','T',ion,listat)
                     if(errr) then
                        write(*,*) 'ERROR! Change distance to H in Hd!'
                        call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp, &
                             Species,relax_flag,Genrt)
                        call restore_mol_index(iMol,Mol_index,ITI)
                        if(YES_xyz.ne.'None') call create_xyz1(M11,N11, &
                             M22,N22,M33,N33,YES_xyz,Add_Hs, &
                             Num_Vects,Add_Vects,ts_list)
                        go to 21
                     end if
                  end if
               end do
            end if
            listat(i)=.false.
         end do
         write(*,*)'Number of atoms in the cluster = ',ITI
         tagYES=.false.

!___________ write geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![U].... undo the last step: restore AJ, BJ and TI from the previous step

      ELSE IF(cha2(l0:).eq.'U') THEN

         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag, &
              Genrt)
         call restore_mol_index(iMol,Mol_index,ITI)
         listat=.false. ; tagYES=.false.

!___________ restore geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![UU].... restore the default

      ELSE IF(cha2(l0:).eq.'UU') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         call initial_mol_index(iMol,Mol_index,BSSE_tag)
         listat=.false.

!___________ restore geom.xyz
         if(YES_xyz.ne.'None') &
                call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN
         call show_atoms(listat)

![Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n','y')
         write(*,*)'Hit ENTER when done ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'

![Bb].... ask extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'Bb') THEN

!___________ ask extensions along the existing lattice vectors for the
!            breeding box and update geom.xyz

         call ask_breeding_box(M11,N11,M22,N22,M33,N33)
         call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![Ts].... choose atoms of the system not to be shown in visualisation (CHIMERA only)

      ELSE IF(cha2(l0:).eq.'Ts' .and. L_ext1.eq.1 .and. CHIMERA) THEN

         ts_list=.false.
         call TagS(NumLin,ITI,ts_list)
         call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)
         
![Tb].... remove tagged atoms from the visualisaiton (CHIMERA only)

!      ELSE IF(cha2(l0:).eq.'Tb' .and. CHIMERA) THEN

!         L_ext=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)*ITI
!         allocate(listb(L_ext))
        

!__________ specify wanted atoms to be removed
!         call TagB(NumLin,ITI,listb,L_ext)
!         if(NumLin.ne.0) then
!            call create_xyz_b(M11,N11,M22,N22,M33,N33,YES_xyz,listb)
!         else
!            call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
!              Num_Vects,Add_Vects,ts_list)
!         end if
!         deallocate(listb)

![B0].... nullify the extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'B0') THEN

         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W') THEN

!___________ constract all lattice sites  and write geom.xyz
         call create_xyz1(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs, &
                       Num_Vects,Add_Vects,ts_list)

![S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S') THEN
         if(Frozen_at) sel_dyn=.true.
         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

![ST].... save tagged atoms as a xyz file

      ELSE IF(cha2(l0:).eq.'ST' .and. TagYES) THEN
         write(*,*)'... writing geometry ...'
         open(74,file='geom_tagged.xyz')
         n_tagged=0
         do nat=1,ITI
            if(listat(nat)) n_tagged = n_tagged + 1
         end do
         write(*,*)'... there are ',n_tagged,' tagged atoms'
         write(74,'(i10/)') n_tagged
         nat=0
         do is=1,Nsp
            do j=1,NspN(is)
               nat=nat+1
               if(listat(nat)) write(74,'(a13,3(x,f10.5))') &
                                     Species(is),(TI(k,nat),k=1,3)
            end do
         end do
         close(74)
         write(*,*)'... file geom_tagged.xyz created successfully ...'

![Sf].... generate SIESTA code (routine constr.f) to symmetrise forces
!         during atomic relaxation - according to the present symmetry
!         [it can be useful even if the current code is not SIESTA!]

      ELSE IF(cha2(l0:).eq.'Sf') THEN

         if(ITI.gt.9999) then
            write(*,*)'WARNING: option NOT supported - too many atoms'
            write(*,*)'Press ENTER when ready ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
            go to 21
         end if

!............ check symmetry
         call check_symmetry('n','y')
         if(MGp.eq.1) go to 21

!............ open the file
         write(*,*)'... generating for SIESTA constr.f file ...'
         open(93,file='for_SIESTA_constr.file',form='formatted')
         do j=1,MGp,24
            j1=j+23
            if(j1.gt.MGp) j1=MGp
            write(93,'(a,48(x,i2,2x))')'c..operations: ',(KGp(i),i=j,j1)
            write(93,'(a,14x,48(a,x))')  'c', (NAZ(KGp(i)),i=j,j1)
         end do

!_________________ working out first atoms of all orbits
         nat=0
         do is=1,Nsp
            do ii=1,NspN(is)
               nat=nat+1
               listt(nat)=.false.
               iSort(nat)=is
            end do
         end do
         iorb=0
         do nat=1,ITI
            r(1:3)=TI(1:3,nat)
            if(.not.listt(nat)) then
               iorb=iorb+1
               iorbit(iorb)=nat
               listt(nat)=.true.
               do Irot=1,MGp
                  call which_atom_after_rot(r,Irot,nat1,Err)
                  if(.not.listt(nat1)) listt(nat1)=.true.
               end do
            end if
         end do

!_________________ working out relations between forces on 1st atoms of orbits

         do ior=1,iorb
            nat=iorbit(ior)
            r(1:3)=TI(1:3,nat)
            write(93,'(2(a,i3),a)') &
                 'c=======> orbit= ',ior,', 1st atom = ',nat,' <======='

!______________________ local group
            ig=0
            do Irot=2,MGp
               call which_atom_after_rot(r,Irot,nat1,Err)
               if(nat1.eq.nat) then
                  ig=ig+1
                  local(ig)=Irot
!                  write(93,'(a,3(i2,x),a)')
!     &                  'c_loc_ ',ig,local(ig),KGp(Irot),NAZ(KGp(Irot))
               end if
            end do
            mlg=ig
            if(mlg.eq.0) then
               typ='E'
            else
               call analyse_loc_grp(typ,v,local,mlg,KGp,93,err,.false.)
!               call analyse_loc_grp(typ,v,local,mlg,KGp,93,err,.true.)
               if(err) then
                  close(93,status='delete')
                  go to 21
               end if
            end if

!______________________ print the local group and work out the force code
            do i=1,mlg,10
               i1=i+9
               if(i1.gt.mlg) i1=mlg
               write(93,'(a,10(a,x))') &
                            'c...local: ',(NAZ(KGp(local(j))),j=i,i1)
            end do
            call code_same_atom(nat,v,typ,93)
         end do

!............ do the calculation
         do nat=1,ITI
            listt(nat)=.false.
         end do
         do nat=1,ITI
            r(1:3)=TI(1:3,nat)
            call name_from_number(nat,ch4,l,err)
!
            if(.not.listt(nat)) then
               listt(nat)=.true.

               do Irot=1,MGp
                  call which_atom_after_rot(r,Irot,nat1,Err)
                  if(Err) stop 'ERROR in change option Sf'
                  Ir=KGp(Irot)

                  is1=iSort(nat1)
                  call name_from_number(Ir,hh4,lr,err)
                  if(.not.listt(nat1)) then
                     call name_from_number(nat1,cha4,l1,err)
                     write(93,'(3a,i5,a,i5,2a)') &
                       'c....... force on ',Species(is1),' atom ',nat1, &
                      ' via atom ',nat,' and operation ',NAZ(Ir)
!                     write(93,*) (C(1,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)') 'c','fa(1,',cha4(l1:),')=' &
                          //'C(1,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'// &
                            'C(1,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// &
                            'C(1,3,',hh4(lr:),')*fa(3,',ch4(l:),')'
!                     write(93,*) (C(2,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)')'c','fa(2,',cha4(l1:),')=' &
                          //'C(2,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'// &
                            'C(2,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// &
                            'C(2,3,',hh4(lr:),')*fa(3,',ch4(l:),')'
!                     write(93,*) (C(3,j,Ir),j=1,3)
                 write(93,'(a,5x,7(a,a),a)')'c','fa(3,',cha4(l1:),')=' &
                          //'C(3,1,',hh4(lr:),')*fa(1,',ch4(l:),')+'// &
                            'C(3,2,',hh4(lr:),')*fa(2,',ch4(l:),')+'// &
                            'C(3,3,',hh4(lr:),')*fa(3,',ch4(l:),')'

                     call cha_name(C(1,1,Ir),C(1,2,Ir), &
                                               C(1,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a)') 'fa(1,',cha4(l1:),')=',cc(:ll)
                     call cha_name(C(2,1,Ir),C(2,2,Ir), &
                                               C(2,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a)')  'fa(2,',cha4(l1:),')=',cc(:ll)
                     call cha_name(C(3,1,Ir),C(3,2,Ir), &
                                               C(3,3,Ir),ch4,l,cc,ll)
                     write(93,'(6x,4a/a)') &
                                      'fa(3,',cha4(l1:),')=',cc(:ll),'c'

                     listt(nat1)=.true.
                  end if
               end do

            end if
!
         end do
         close(93)

![Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call check_symmetry('y','y')
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end subroutine change

