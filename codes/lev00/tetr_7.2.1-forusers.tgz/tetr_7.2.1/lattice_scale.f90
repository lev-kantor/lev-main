module lattice_match
  implicit none

  integer :: M1,M2,N1,N2,K
  real*8 :: scl,ang,maxang
  logical :: fixed1
  integer,dimension(:,:,:),allocatable :: U1,V1
  integer,dimension(:),allocatable :: thebest
  integer :: i11,i12,i21,i22,j11,j12,j21,j22,detU,detV
  integer :: U(2,2),V(2,2)
  real*8 ::ang1,ang2

  CONTAINS

    subroutine det_size_for_lattice(a,b,list)
!==============================================================  
!  1st lattice is given a(1,:),a(2,:)
!     This lattice is transformed by U(2,2)
!  2nd lattice is given b(1,:),b(2,:)
!     This lattice is transformed by V(2,2) and additionally
!     rotated by angle phi

      real*8 :: a(2,2),b(2,2),a1(2,2),b1(2,2)
      integer :: list
  
!................................................................................  
!................... run loops to determine the required memory ................
!................................................................................  

      maxang=180.0-ang ; list=0
      do i11=-N1,N1
         do i12=-N1,N1
            do i21=-N1,N1
               do i22=-N1,N1
                  U(1,1)=i11 ; U(1,2)=i12 ; U(2,1)=i21; U(2,2) = i22
                  detU=abs(U(1,1)*U(2,2)-U(2,1)*U(1,2))
                  if(detU.gt.M1 .or. detU.eq.0) go to 1
                  if(fixed1 .and. (U(1,1).ne.1 .or. U(1,2).ne.0 .or. U(2,1).ne.0 .or. U(2,2).ne.1)) go to 1
                  
                  call transform_lattice(a,U,a1)
                  ang1=angle_2vectors(a1(1,1),a1(1,2),a1(2,1),a1(2,2))
                  if(abs(ang1).lt.ang .or. abs(ang1).gt.maxang) go to 1
              
                  do j11=-N2,N2
                     do j12=-N2,N2
                        do j21=-N2,N2
                           do j22=-N2,N2
                              V(1,1)=j11 ; V(1,2)=j12 ; V(2,1)=j21; V(2,2) = j22
                              detV=abs(V(1,1)*V(2,2)-V(2,1)*V(1,2))
                              if(detV.gt.M2 .or. detV.eq.0) go to 2

                              call transform_lattice(b,V,b1)
                              ang2=angle_2vectors(b1(1,1),b1(1,2),b1(2,1),b1(2,2))
                              if(abs(ang2).lt.ang .or. abs(ang2).gt.maxang) go to 2
                              
                              list=list+1
                              
2                          end do
                        end do
                     end do
                  end do
                  
1              end do
            end do
         end do
      end do
      
      write(*,*) '... there are ',list,' possiblities'
    end subroutine det_size_for_lattice

    subroutine lattice(a,b,list)
!==============================================================  
!  1st lattice is given a(1,:),a(2,:)
!     This lattice is transformed by U(2,2)
!  2nd lattice is given b(1,:),b(2,:)
!     This lattice is transformed by V(2,2) and additionally
!     rotated by angle phi

      real*8 :: phi,a(2,2),b(2,2),b1(2,2),a1(2,2),b2(2,2),delta,x,y,z,max,min
      integer :: list,l,list10, i,l1
      real*8,dimension(:),allocatable :: angle,error,err,errb,angle1,angle2,scaling
      real*8 :: scale
      logical,dimension(:),allocatable :: yes
      
      write(*,*) '... there are ',list,' possiblities'

!................................................................................  
!................... work out the favourable lattices ...........................
!................................................................................  

      maxang=180.0-ang
      allocate(angle(list),scaling(list),error(list),angle1(list),angle2(list),yes(list))
  
      list10=list/10
      write(*,*) list10
      
      l=0 ; max=0.0d0  ; min=10.0d10 ; yes=.true.
      do i11=-N1,N1
         do i22=-N1,N1
            do i21=-N1,N1
               do i12=-N1,N1
                  U(1,1)=i11 ; U(1,2)=i12 ; U(2,1)=i21; U(2,2) = i22
                  detU=abs(U(1,1)*U(2,2)-U(2,1)*U(1,2))
                  if(detU.gt.M1 .or. detU.eq.0) go to 3
                  if(fixed1 .and. (U(1,1).ne.1 .or. U(1,2).ne.0 .or. U(2,1).ne.0 .or. U(2,2).ne.1)) go to 3

                  call transform_lattice(a,U,a1)
                  ang1=angle_2vectors(a1(1,1),a1(1,2),a1(2,1),a1(2,2))
                  if(abs(ang1).lt.ang .or. abs(ang1).gt.maxang) go to 3
                  
                  do j11=-N2,N2
                     do j22=-N2,N2
                        do j21=-N2,N2
                           do j12=-N2,N2
                              V(1,1)=j11 ; V(1,2)=j12 ; V(2,1)=j21; V(2,2) = j22
                              detV=abs(V(1,1)*V(2,2)-V(2,1)*V(1,2))
                              if(detV.gt.M2 .or. detV.eq.0) go to 4
                          
                              call transform_lattice(b,V,b1)
                              ang2=angle_2vectors(b1(1,1),b1(1,2),b1(2,1),b1(2,2))
                              if(abs(ang2).le.ang .or. abs(ang2).gt.maxang) go to 4
                              
                              l=l+1
                              if(l/list10*list10.eq.l) write(*,*) 'done ',l/list10*10,' %'
                              
                              angle1(l)=ang1 ; angle2(l)=ang2

                          
!______________ determine the rotational angle

                              x=-a1(1,1)*b1(1,2)+a1(1,2)*b1(1,1)-a1(2,1)*b1(2,2)+a1(2,2)*b1(2,1)
                              y= a1(1,1)*b1(1,1)+a1(1,2)*b1(1,2)+a1(2,1)*b1(2,1)+a1(2,2)*b1(2,2)
                              if(abs(y).lt.0.0001) then
                                 phi=1.5707963268d0
                              else
                                 phi=-atan(x/y)
                              end if
                              angle(l)=phi

!_______________ determine the scaling factor                          

                              z= b1(1,1)*b1(1,1)+b1(1,2)*b1(1,2)+b1(2,1)*b1(2,1)+b1(2,2)*b1(2,2)
                              if(abs(y).lt.0.0001) then
                                 scale = -x/z
                              else
                                 scale = y/(z*cos(phi))
                              end if
                              scaling(l)=scale
                          
!_______________ construct rotated b1-lattcie ==> b2

                              call rotate_second_lattice(b1,phi,b2)
                              b2(:,:) = scale * b2(:,:)
                          
!________________ save the two extensions of the lattices                          

                              U1(:,:,l)=U(:,:)
                              V1(:,:,l)=V(:,:)
                          
!_______________ calculate the error function

                              if(scale.lt.1.0-scl .or. scale.gt.1.0+scl) then
                                 delta=1.0d5 ; yes(l)=.false.
                              else
                                 delta = difference(a1,b2)
                              end if
                              error(l)=delta
                              
                              if(delta.gt.max) max=delta
                              if(delta.lt.min) min=delta

4                          end do
                        end do
                     end do
                  end do
                  
3              end do
            end do
         end do
      end do
      
      write(*,*)'... finished loops'
      write(*,*)'... the interval of delta from ',min,' to ',max
  
!................................................................................  
!....... show only the best few variants.........................................
!................................................................................

      allocate(err(K),errb(K))
      i=0
      do l=1,list
         if(yes(l)) i=i+1
      end do
      if(i.lt.K) then
         K=i ; write(*,*)'... only ',K,' results are at all available ...'
      end if
      do i=1,K
         min=1.0d10
         do l=1,list
            if(yes(l) .and. error(l).le.min) then
               min=error(l) ; l1=l
            end if
         end do
         thebest(i)=l1 ; errb(i)=error(l1)
         write(*,'(/2(a,i10),a,f10.5)')' The best ',i,' is l= ',l1,' with error = ',errb(i)
         call transform_lattice(a,U1(1,1,l1),a1)
         detU=abs(U1(1,1,l1)*U1(2,2,l1)-U1(2,1,l1)*U1(1,2,l1))
         
         write(*,*)'... the first lattice ... [extension = ',detU,'] angle between them = ',angle1(l1),' deg'
         write(*,'(a,2(x,f10.5),2(a,i3),a)') ' a1 = ',a1(1,:),'     |',U1(1,1,l1),' ',U1(1,2,l1),'|'
         write(*,'(a,2(x,f10.5),2(a,i3),a)') ' a2 = ',a1(2,:),'     |',U1(2,1,l1),' ',U1(2,2,l1),'|'
         call transform_lattice(b,V1(1,1,l1),b1)
         call rotate_second_lattice(b1,angle(l1),b2)
         b2(:,:)=scaling(l1)*b2(:,:)
         detV=abs(V1(1,1,l1)*V1(2,2,l1)-V1(2,1,l1)*V1(1,2,l1))
         write(*,*)'... the second lattice ... [extension = ',detV,'] angle between them = ',angle2(l1),' deg'
         write(*,*)'    rotation angle = ',angle(l1)*180.0/3.1415926,' deg'
         write(*,*)'    scaling factor = ',scaling(l1)
         write(*,'(a,2(x,f10.5),2(a,i3),a)') ' b1 = ',b2(1,:),'     |',V1(1,1,l1),' ',V1(1,2,l1),'|'
         write(*,'(a,2(x,f10.5),2(a,i3),a)') ' b2 = ',b2(2,:),'     |',V1(2,1,l1),' ',V1(2,2,l1),'|'
         write(*,*)'..... check error = ',difference(a1,b2)
         yes(l1)=.false.
         
      end do
!      deallocate(err,thebest,errb,U1,V1,angle,scaling,error,angle1,angle2,yes)
      deallocate(err,errb,angle,scaling,error,angle1,angle2,yes)
      return
    end subroutine lattice

    subroutine transform_lattice(a,U,a1)
      !..... the first lattice transformed
      implicit none
      integer :: U(2,2)
      real*8  :: a(2,2),a1(2,2)
      
      a1(1,1)=U(1,1)*a(1,1)+U(1,2)*a(2,1)
      a1(1,2)=U(1,1)*a(1,2)+U(1,2)*a(2,2)
      a1(2,1)=U(2,1)*a(1,1)+U(2,2)*a(2,1)
      a1(2,2)=U(2,1)*a(1,2)+U(2,2)*a(2,2)
    end subroutine transform_lattice
    
    subroutine rotate_second_lattice(b1,phi,b2)
      implicit none
      real*8  :: b1(2,2),b2(2,2),phi
      
      b2(1,1)= cos(phi)*b1(1,1)+sin(phi)*b1(1,2)
      b2(1,2)=-sin(phi)*b1(1,1)+cos(phi)*b1(1,2)
      b2(2,1)= cos(phi)*b1(2,1)+sin(phi)*b1(2,2)
      b2(2,2)=-sin(phi)*b1(2,1)+cos(phi)*b1(2,2)
    end subroutine rotate_second_lattice
    
    real*8 function difference(a1,b2)
      implicit none
      real*8  :: b2(2,2),a1(2,2),delta
      integer :: i,j
      delta=0.0d0
      do i=1,2
         do j=1,2
            delta = delta + (a1(i,j)-b2(i,j)) * (a1(i,j)-b2(i,j))
         end do
      end do
      difference=delta
    end function difference

    real*8 function angle_2vectors(ax,ay,bx,by)
      !.... angle in degrees  
      implicit none
      real*8 :: ax,ay,bx,by,aa,bb,ab
      aa=sqrt(ax*ax + ay*ay)
      bb=sqrt(bx*bx + by*by)
      ab=ax*bx + ay*by
      angle_2vectors=acos(ab/(aa*bb))*180.0/3.1415926536
    end function angle_2vectors

end module lattice_match
  
