      subroutine mol_vibr(Which_Code,kpoint,nkp)
c....................................................................
c         It calculates vibrations of either a molecule (located in a 
c large enough cell) or a supercell. In both cases only the point group
c symmetry is considered.
c 
c (1) in the molecule case: the center of coordinate system should be 
c     in the centre of mass (use M from the main menu for this)
c (2) the point group of the system is obtained
c (3) all atoms are broken down into orbits
c (4) some orbits can be fixed (e.g. a cluster) or not (a molecule):
c     (i) if fixed, this may e.g. correspond to a cluster embedded in 
c         the environment when outer orbits (at the cluster boundary) 
c         are fixed; local vibrations associated with the inner 
c         orbits can then be obtained;
c    (ii) if none are fixed, all orbits are free and this corresponds
c         to e.g. an isolated molecule
c (5) masses of atoms for every species (a.e.m.) are taken from default
c (6) the matrix of masses is calculated and written into a file 
c (7) the group-theoretical analysis is performed for every irrep
c (8) then it is possible either to construct geometries that correspond 
c     to activated mode one by one, or, preferably, all in one go using
c     option Au (automatic).
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      include 'systema.inc'      
      dimension TI1(3,N0LT),x1(3),iFix(N0RB),x2(3)
      character cha2*2,Yes_xyz*4
      character Which_Code*6,cha1,cha17*17,numb(12)*2,Line*200
      character cha3*13
      character b1,b2,b3,ch*16,chh*18,chg*17
      integer IRA_left(N0IR)
      integer LinEnd(100),LinPos(100)
      double precision kpoint(Nkpoint,3),C_cond(3,N0LT,6)
      double precision ampl(2)
      logical Yes_masses,Add_Hs,Yes_Fixed,Yes_irrep_info,active
      logical Yes_ampl,Show_fixed,Err
      data Add_Hs/.false./,Yes_xyz/'Xmol'/
      data numb/' 1',' 2',' 3',' 4',' 5',' 6',' 7',' 8',' 9',
     &                                           '10','11','12'/
      data ampl/0.01,0.015/,Show_fixed/.false./,Ndispl/2/,ampl1/0.05/
c
c........... save TI in TI1
c
      do i=1,ITI
        TI1(1:3,i)=TI(1:3,i)
      end do
c
c.......... initial setting; checking consistency
      call get_orbits(KodErr,Linear,N_cond1,C_cond,Err,'y')
c------ [If TESTING, comment out the above line and uncomment the one below]
c      call get_orbits(KodErr,Linear,N_cond1,C_cond,Err,'n')
      

      if(KodErr.eq.1) go to 100
      if(Err) then
         write(*,'(a)')
     &        'ERROR: system '//system//' is inconsistent with geometry'
         return
      end if
c
c..................................................................
c..................... Main menu starts here ......................
c..................................................................
c
      Yes_masses=.true.
      do is=1,Nsp
         if(AtMass(is).lt.tiny_equiv) Yes_masses=.false.
      end do
            
      Yes_Fixed=.false. ; Fix=.false.
      Yes_irrep_info=.false. ; active=.false. ; Yes_ampl=.false.

 21   write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      if(system.eq.'MOLECULE') then
         write(*,'(2a)')' MOLECULE: lattice translations IGNORED' 
      else      
         write(*,'(2a)')' SUPERCELL: lattice translations USED'
         write(*,*)'... CURRENT lattice vectors for the supercell:...'
         write(*,'(a,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
         write(*,'(a,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      end if
      write(*,'(a)')
      write(*,*)'========= CHOOSE an OPTION:'
      write(*,'(a)')

      if(.not.Yes_masses) write(*,'(a)')
     &      ' Am. Specify atomic masses for every species <- undefined'

      if(Yes_Fixed) then
         write(*,'(a)') ' Fx. Some orbits are fixed.'
         write(*,'(a)')'     Transl/rot constrains will NOT be applied!'
      else
         write(*,'(a)') ' Fx. Specify which orbits to fix'
         if(system.eq.'MOLECULE') write(*,'(a)') 
     &        '     Currently transl/rot constrains ARE applied!'   
      end if

      if(Yes_Fixed) then
         ifx=0
         do io=1,NORB
            if(Fix(io)) then
               ifx=ifx+1 ; iFix(ifx)=io
            end if
         end do
         write(cha2,'(i2)') ifx
         do kk=1,ifx,20
            cha3='             ' ; if(kk.eq.1) cha3='Fixed orbits:'
            ik=kk+19 ; if(ik.gt.ifx) ik=ifx
            write(*,'(5x,a,20(i3,x))') cha3, (iFix(j),j=kk,ik)
            n1=n1+20
         end do
      end if

      if(Yes_masses) then
         if(Yes_irrep_info) then
            write(*,'(a)')
     &       ' Ir. Collect info about symmetry adapted vectors <- Done'
         else
            write(*,'(a)')
     &   ' Ir. Collect info about symmetry adapted vectors <- undefined'
         end if
      end if
   
c_____ actions with active irrep

      if(Yes_irrep_info) then
         write(*,'(a)')
     &'------ A c t i o n s  w i t h  A c t i v e  I r r e p ----------'
         do IA=1,NEPR
            if(IRA_left(IA).ne.0) then
               if(active .and. IA.eq.IA_active) then
                  cha17='  <=== now active'
               else
                  cha17='                 '
               end if
               if(IA.lt.10) then
                  write(cha1,'(i1)') IA
                  write(*,'(a,i1,a,i5,a)')' '//cha1//'. irrep ('//
     &              NAZVIR(IA)//') is ',NALFA(IA),
     &                 'D; # of vectors = ',IRA_left(IA),cha17
               else
                  write(cha2,'(i2)') IA
                  write(*,'(a,i1,a,i5,a)') cha2//'. irrep ('//
     &              NAZVIR(IA)//') is ',NALFA(IA),
     &              'D; # of vectors = ',IRA_left(IA),cha17
               end if
            end if
         end do
      end if
      
      if(active) then
         if(Yes_ampl) then
            write(*,'(2(a,i3))')
     &           ' Vn. Pair of vectors to be activated: ',iV1,' and ',iV2
         else
            write(*,'(2(a,i3))')
     &           ' Vn. Pair of vectors to be activated: <= undefined'
         end if
         write(*,'(a)')
     &        ' Go. Show symmetry adapted coordinates (before constr.)'
         write(*,'(a)')
     &        ' Sa. Show final symmetry adapted displacements'
         if(IA_active.lt.10) then
            write(cha1,'(i1)') IA_active
            write(*,'(a)') 
     &           ' Sw. Write final symmetry adapted '//
     &                     'displacements to W_'//cha1//'.mat'
            write(*,'(a)') ' Gw. Write G-matrix for eigenvalue'//
     &           ' problem to G_'//cha1//'.mat'
         else
            write(cha2,'(i2)') IA_active
            write(*,'(a)') 
     &           ' Sw. Write final symmetry adapted '//
     &                     'displacements to W_'//cha2//'.mat'
            write(*,'(a)') ' Gw. Write G-matrix for eigenvalue'//
     &           ' problem to G_'//cha2//'.mat'
         end if
         write(*,'(a)')
     &       ' Vs. Write <geom.xyz> geom file for each displacement'
      end if

c_____ automatic

      if(active) then
         write(*,'(a)')
     &'------------------- A u t o m a t i c   o p t i o n ------------'
         write(*,'(a)')
     &    ' Au. Generate: input_for.tetr + directories + scripts'
      else if(Yes_irrep_info) then
         write(*,'(a)')
     &'------------------- A u t o m a t i c   o p t i o n ------------'
         write(*,'(a)')
     &    ' Au. FULLY AUTOMATIC: input_for.tetr + directories + scripts'
      end if

c_____ show info

      write(*,'(a)')
     &'-------------- G e n e r a l  I n f o r m a t i o n ------------'
      write(*,'(a)')
     &     ' Co. Show general geometry information about orbits'
      write(*,'(a)')' Or. Show detailed information about given orbit'
      write(*,'(a)')' Sy. Show the point symmetry group info'
      if(Yes_masses .and. (.not.Yes_Fixed) 
     &                              .and. system.eq.'MOLECULE') then 
         write(*,'(a)')
     &        ' Cn. Show translational-rotational constraints:'
      end if
      if(Yes_masses) then
         N_Cond=N_Cond1
         if(Yes_Fixed .or. system.eq.' LATTICE') N_Cond=0
         write(*,'(5x,a,i1)')'Current number of conditions = ',N_Cond
      end if

c_____ show settings

      write(*,'(a)')
     &'---------------- G e n e r a l  S e t t i n g s ----------------'
      if(Yes_masses) then
         write(*,'(a)')
     &       ' Am. Atomic masses for every species:'
         write(*,'(5x,6(f10.5,x,3a,2x))') 
     &        (AtMass(is),'[',Species(is),']',is=1,Nsp)
      end if
c      write(*,'(a)')
c     &   ' XY. Format of <geom.xyz> file is for '//YES_xyz
      if(Ndispl.lt.4) then
         write(*,'(a,2(f10.5,x))')
     &        ' Da. Distortion amplitude: ',ampl(1)
      else
         write(*,'(a,2(f10.5,x))')
     &        ' Da. Distortion amplitude: ',ampl(1),ampl(2)
      end if
      write(*,'(a,i1)')
     &     ' Nd. Number of displacements (for [Au] only): ',Ndispl
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,'(a)')
     &        ' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,'(a)')
     &        ' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      if(Yes_Fixed) then
         if(.not.Show_fixed) then
            write(*,'(a)')' Sx. Show fixed atoms in tables: NO'
         else
            write(*,'(a)')' Sx. Show fixed atoms in tables: YES'
         end if
      end if
      if(active .and. Yes_ampl) write(*,'(a)')'  S. Save geometry file'
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)
      if(cha2.eq.'  ') go to 21

c[IA]..... first of all, check if active irrep is chosen; if it was,
c          then construct W_all,IRA

      IF(Yes_irrep_info) THEN

         read(cha2(l0:),'(i2)',err=27) n_IA

c__________________ deactivate the irrep if chosen 2nd time
         if(active.and.n_IA.eq.IA_active) then
            active=.false.
            go to 21
         end if

c___________________ activate the irrep if the 1st time
         do IA=1,NEPR
            if(n_IA.eq.IA) then
               if(IRA_left(IA).eq.0) then
                  write(*,*)'Error! Try again!'
                  go to 21
               end if
               IA_active=IA
               call do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
               if(IRA-N_Cond.ne.IRA_left(IA)) stop 'IRA error'
               active=.true.
               Yes_ampl=.false.
               go to 21
            end if
         end do

      END IF

c[Am]...... specify atomic masses

 27   IF(cha2(l0:).eq.'Am') THEN

         call choose_masses(Species,AtMass,Nsp,Yes_masses)

c______________ apply conditions and orthogonormalise them
         N_cond1=6
         call do_cond(N_Cond1,C_cond,AtMass)
         if(Linear) N_cond1=5

c______________ reset logical flags since masses changed
         active=.false.
         Yes_irrep_info=.false.
         Yes_ampl=.false.

c[Fx]...... which orbits to fix

      ELSE IF(cha2(l0:).eq.'Fx') THEN

         j=0
         do i=1,NORB
            if(Fix(i)) j=j+1
         end do
 2       write(*,'(a)')
     &        'Specify a range of orbits to fix, nothing to disable:'
         write(*,'(a)')'use dash (without space) to indicate from/to'
         write(*,'(a)')'within the same list, e.g.: 1-5,9 7-8,15 25'
         read(*,'(a)') line
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 2
         if(NumLin.eq.0) then
            Yes_Fixed=.false.
            do i=1,NORB
               Fix(i)=.false.
            end do
            write(*,*)'WARNING! The Fixing of orbits is disabled!'
            go to 19
         else
            if((NORB-j).lt.2) then
               write(*,*)'WARNING! No orbits left to fix anymore!'
               go to 21
            end if
            Yes_Fixed=.true.
         end if
         do i=1,NumLin
            i0=index(line(LinPos(i):LinEnd(i)),'-')
            if(i0.eq.0) then
               read(line(LinPos(i):LinEnd(i)),*) i1
               i2=i1
            else
               read(line(LinPos(i):LinPos(i)+i0-2),*) i1
               read(line(LinPos(i)+i0:LinEnd(i)),*) i2
            end if
            if(i1.gt.i2 .or. i1.lt.1 .or. i2.gt.NORB) go to 2
            do j=i1,i2
               Fix(j)=.true.
            end do
         end do
         j=0
         do i=1,NORB
            if(Fix(i)) j=j+1
         end do
c         if(j.gt.99) then
c            write(*,*)'Too many fixed orbits! Redefine!'
c            go to 2
c         end if

c______________ reset logical flags 
 19      active=.false.
         Yes_irrep_info=.false.
         Yes_ampl=.false.
         
c[Cn]...... show constrains 

      ELSE IF(cha2(l0:).eq.'Cn' .and. Yes_masses .and. 
     &        (.not.Yes_Fixed).and.system.eq.'MOLECULE') THEN

         write(*,*)'********** conditions after orthogonalisation:'
         call show_C(C_cond,N_cond,Species)
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Ir]...... collect info about symmetry-adapted vectors; constraints will also
c           be applied if set:
c           IRA_left(IA) - number of linearly independent symmetry-adapted
c                          coordinates left after getting rid of constrains
c                          (for irrep IA)

      ELSE IF(cha2(l0:).eq.'Ir' .and. Yes_masses) THEN

         IR=0
         do IA=1,NEPR
            call do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
            IRA_left(IA) = IRA-N_cond
         end do
         Yes_irrep_info=.true.

c______________ write all the info for later use (eigenvalues)
         open(23,file='vibr_info.dat',form='formatted')
         write(23,'(2(i5,x),a8)') NEPR,Nsp,system
         write(23,'(a3,20(x,a3))') GroupN,(NAZVIR(IA),IA=1,NEPR)
         write(23,'(20(a2,x))')  (Species(is),is=1,Nsp)
         write(23,*) (IRA_left(IA),IA=1,NEPR)
         write(23,*) (NALFA(IA),IA=1,NEPR)
         write(23,*) NORB,MG,(KG(i),i=1,MG)
         write(23,*) (KAN(io),(R1(io,j),j=1,3),io=1,NORB)
         write(23,*) (ISORT1(io),io=1,NORB)
         write(23,*) ((orb_to_old(io,nat),nat=1,KAN(io)),io=1,NORB)
         write(23,'(20(l1,x))') (Fix(io),io=1,NORB),Yes_Fixed
         write(23,'(5(f10.5,x))') ((TRAN(N,j),j=1,3),N=1,MG)
         write(23,*) (ICMPL(IA),IA=1,NEPR)
         close (23)
         write(*,*)'WARNING: general info written to [vibr_info.dat]'

c[Go].... show symmetry adapted coordinates for each orbit
c         (prior to applying constraints)

      ELSE IF(cha2(l0:).eq.'Go' .and. active) THEN

 4       if(NORB.gt.1) then
            write(*,'(a,i3,a)')
     &         'Specify the orbit number between 1 and ',NORB,':'
            read(*,*,err=4) iOrb
            if(iOrb.lt.1 .or. iOrb.gt.NORB) go to 4
         else
            iOrb=1
         end if
         if(Fix(iOrb)) then
            write(*,*)'ERROR! This orbit is fixed! Choose another one!'
            go to 4
         end if
         x1(1:3)=R1(iOrb,1:3)
         IA=IA_active
         call VANJA(x1,1,iOrb,IA,NREP,BJ)
         if(NREP.gt.0) then 
            write(*,'(a,i2,a)')
     &           '*************** irrep = ',IA,' *****************'
            call show_W_matrix(iOrb,x1,IA,NREP)
         else
            write(*,'(2(a,i3))')
     &           'Orbit ',iOrb, 'does NOT contain Irrep = ',IA
         end if

c[Sa]...... show symmetry-adapted vectors for given irrep
c         (after applying constraints)

      ELSE IF(cha2(l0:).eq.'Sa' .and. active) THEN

         IA=IA_active
         call show_W_all_matrix(IA,IRA,Species,N_Cond,Show_fixed)
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sw]...... write symmetry-adapted vectors for given irrep
c         (after applying constraints)

      ELSE IF(cha2(l0:).eq.'Sw' .and. active) THEN

         IA=IA_active
         call write_W_all_matrix(IA,IRA,N_Cond)

c[Gw]...... write G-matrix for the eigenvalue problem (option V2
c           of the main menu)

      ELSE IF(cha2(l0:).eq.'Gw' .and. active) THEN

         IA=IA_active
         call write_G_matrix(IA,IRA,N_Cond,AtMass)

c[Vn]...... give pair of vectors

      ELSE IF(cha2(l0:).eq.'Vn' .and. active) THEN

         if(IRA_left(IA_active).ge.1) then
            IA=IA_active
 8          write(*,'(a,i3,a)')
     &           'Specify a pair of vectors from 1 to ',IRA-N_Cond, 
     &           ' to distort the system:'
            read(*,*,err=8) iV1,iV2
            if(iV1.lt.1 .or. iV1.gt.iV2 .or. iV2.gt.IRA-N_Cond) go to 8
            Yes_ampl=.true.
         end if

c[Vs]...... write xyz geom files for a displacement vector

      ELSE IF(cha2(l0:).eq.'Vs' .and. active) THEN

         if(IRA-N_Cond.gt.1) then
 7          write(*,'(a,i3)')
     &        'Specify a displacement vector between 1 and ',IRA-N_Cond
            read(*,*,err=7) iV
            if(iV.lt.1 .or. iV.gt.IRA-N_Cond) go to 7
         else
            iV=1
         end if
         open(37,file='geom.xyz',form='formatted')
         do iang=0,360,10
            amp=2*ampl1*sin(iang*pi/180.0)
            call distorted_xyz(IRA,N_Cond,iV,1,amp,Species,ITI,
     ,                                             37,YES_xyz,Add_Hs)
         end do
         close (37)

c[Au]...... an input file for tetr will be saved that can generate all geometries
c           of the active irrep automatically

      ELSE IF(cha2(l0:).eq.'Au' .and. Yes_irrep_info) THEN

         call automatic(iFix,N_Cond,Ndispl,Yes_Fixed,ifx,ampl,active,
     ,                   IRA_left,C_Cond,IA_active,system)
         write(*,'(4(/a))') 
     &  '.........................................................',
     &  '=================> Now, do the following: <==============',
     &  '     1. check script run_DFT_script and edit if necessary',
     &  '     2. run the script to calculate DFT forces'
         write(*,'(3(a/))') 
     &  '     3. run option V2 and/or V3 of tetr to '//
     &        'get eigenvectors/values'
         if(Which_Code.eq.'QUICKS') then
            write(*,'(6(/a))') 
     &  '     4. Include into FORCE_EVAL box the following lines:',
     &  '           &PRINT',
     &  '             &FORCES',
     &  '               NDIGITS 12',
     &  '             &END FORCES',
     &  '           &END PRINT'
         end if
         write(*,'(3(a/))') 
     &  '........................................................' ,
     &  'press ENTER when ready ...'
         read(*,*)

c[XY]...... ask the code for geom.xyz file 

c      ELSE IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='Ymol'
c         end if

c[Hs]...... add Hydrogens to geom.xyz or not

      ELSE IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[Sx]...... if to show fixed atoms in tables

      ELSE IF(cha2(l0:).eq.'Sx' .and. Yes_Fixed) THEN

         if(Show_fixed) then
            Show_fixed=.false.
         else
            Show_fixed=.true.
         end if

c[Da]...... displacement amplitude

      ELSE IF(cha2(l0:).eq.'Da') THEN

 13      if(Ndispl.lt.3) then
            write(*,*)'Specify the amplitude of distortion (in A):'
            read(*,*,err=13) ampl(1)
         else
            write(*,*)'Specify 2 amplitudes of distortion (in A):'
            read(*,*,err=13) ampl(1),ampl(2)
         end if

c[Nd]...... displacements number: for [Au] option only

      ELSE IF(cha2(l0:).eq.'Nd') THEN

         if(Ndispl.eq.1) then
            Ndispl=2
         else  if(Ndispl.eq.2) then
            Ndispl=4
         else 
            Ndispl=1
         end if

c[Co]...... show information about orbits

      ELSE IF(cha2(l0:).eq.'Co') THEN
         
         write(*,'(a)')
     &    '-No--Species-Number-----1st atom coordinates-'//
     &        '-------Radius----Fix-|-------Old#-------->'
         do io=1,NORB
            is=ISORT1(io)
            rad=sqrt(R1(io,1)**2+R1(io,2)**2+R1(io,3)**2)
            if(Fix(io)) then
               cha1='Y'
            else
               cha1='N'
            end if
            write(*,'(2(i3,x),a2,i5,x,4(f10.5,x),2x,a,2x,a,48(i3,x))') 
     &        io,is,Species(is),KAN(io),(R1(io,j),j=1,3),rad,cha1,
     ,        '| ',(orb_to_old(io,nat),nat=1,KAN(io))
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Or].... show the orbit's local group

      ELSE IF(cha2(l0:).eq.'Or') THEN

 33      if(NORB.gt.1) then
            write(*,'(a,i3,a)')
     &        'Specify the orbit number between 1 and ',NORB,':'
            read(*,*,err=33) iOrb
            if(iOrb.lt.1 .or. iOrb.gt.NORB) go to 33
         else
            iOrb=1
         end if
         if(Fix(iOrb)) then
            write(*,*)'ERROR! This orbit is fixed! Choose another one!'
            go to 33
         end if
         x1(1:3)=R1(iOrb,1:3)
         call orbita(x1,BJ)
         write(*,'(2a)') 'Atomic species:  ',Species(ISORT1(iOrb))
         write(*,'(a,f10.5,a)')
     &        'Atomic mass:     ',AtMass(ISORT1(iOrb)),' a.u.m.'
         write(*,'(a,i4)')'Number of atoms: ',KAN(iOrb)
         if(Fix(iOrb)) then
            write(*,'(a)')'Is orbit fixed:  YES'
         else
            write(*,'(a)')'Is orbit fixed:   NO'
         end if
         write(*,'(a,20(a4,x))')
     &        'The local group: ',(NAZ(KG(KH(i))),i=1,MGN)
         write(*,'(/a)')
     &     'Old#-Atom#--Generator-----------Atom position----------'
         do i=1,KAN(iOrb)
            k=KG(KJ(i))
            x2(1)=C(1,1,k)*x1(1)+C(1,2,k)*x1(2)+C(1,3,k)*x1(3)
            x2(2)=C(2,1,k)*x1(1)+C(2,2,k)*x1(2)+C(2,3,k)*x1(3)
            x2(3)=C(3,1,k)*x1(1)+C(3,2,k)*x1(2)+C(3,3,k)*x1(3)
            iold=orb_to_old(iOrb,i)
            write(*,'(i3,3x,i3,5x,a4,5x,3(x,f10.5))') 
     &                      iold,i,NAZ(KG(KJ(i))),(x2(j),j=1,3)
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Sy].... show the symmetry

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n','y')
         write(*,'(2a)') 'Point symmetry group:       ',GroupN
         if(MG.gt.12) then
            write(*,'(a,12(a4,1x))') 'Group operators:            ',
     ,           (NAZ(KG(i)),i=1,12)
            do i=13,MG,12
               l1=i ; l2=l1+12
               if(l2.gt.MG) l2=MG
               write(*,'(a,12(a4,1x))') (NAZ(KG(j)),j=l1,l2)
            end do
         else
            write(*,'(a,12(a4,1x))') 'Group operators:            ',
     ,           (NAZ(KG(i)),i=1,MG)
         end if
         write(*,'(a,12(i2,2x))')  'Irreducible represenations #: ',
     ,        (i,i=1,NEPR)
         write(*,'(a,12(x,a3))')'Their names:                  ',
     ,        (NAZVIR(i),i=1,NEPR)
         write(*,'(a,12(x,i2,x))')'Their dimensions:            ',
     ,        (NALFA(i),i=1,NEPR)
c
         K1=0 ; K2=0 ; K3=0 ; b1=char(47) ; b2=char(92) ; b3='|'
         do ir=1,NEPR
            if(NALFA(ir).eq.1) K1=K1+1 
            if(NALFA(ir).eq.2) K2=K2+1 
            if(NALFA(ir).eq.3) K3=K3+1 
         end do
c
         write(*,'(/a)')
     ,        '....>>>>>>  All irreps characters info <<<<<<.....'
         write(cha2,'(i2)') NEPR
         chg='(4x,'//cha2//'(3x,a3,3x))' 
         write(*,chg) (NAZVIR(ir),ir=1,NEPR)
         do ig=1,MG
            kgi=KG(ig)
            write(*,'(a4,'//cha2//'(1x,F8.5))') 
     ,           NAZ(kgi),(XX(ir,ig),ir=1,NEPR)
         end do
c
         if(K2.gt.0) then
            write(*,'(/a)')'....>>>>>>  2D irreps info <<<<<<.....'
            write(cha1,'(i1)') K2
            ch='(4x,'//cha1//'(9x,a3,9x))' 
            write(*,ch) (NAZVIR(ir),ir=K1+1,K1+K2)
            do ig=1,MG
               kgi=KG(ig) ; 
               write(*,'(a4,'//cha1//'(1x,a,F8.5,1x,f8.5,a))') NAZ(kgi),
     ,          (b1,D2ALFA(1,1,ig,ir),D2ALFA(1,2,ig,ir),b2,ir=1,K2)
               write(*,'(4x,'//cha1//'(1x,a,F8.5,1x,f8.5,a )/)') 
     ,         (b2,D2ALFA(2,1,ig,ir),D2ALFA(2,2,ig,ir),b1,ir=1,K2)
            end do
         end if
c
         if(K3.gt.0) then
            write(*,'(/a)')'....>>>>>>  3D irreps info <<<<<<.....'
            write(cha1,'(i1)') K3
            chh='(4x,'//cha1//'(13x,a3,13x))' 
            write(*,chh) (NAZVIR(ir),ir=K1+K2+1,NEPR)
            do ig=1,MG
               kgi=KG(ig) ; 
               write(*,'(a4,'//cha1//'(1x,a,F8.5,1x,f8.5,1x,f8.5,a))') 
     ,            NAZ(kgi),(b1,D3ALFA(1,1,ig,ir),D3ALFA(1,2,ig,ir),
     ,                                   D3ALFA(1,3,ig,ir),b2,ir=1,K3)
               write(*,'(4x,'//cha1//'(1x,a,F8.5,1x,f8.5,1x,f8.5,a))') 
     ,                     (b3,D3ALFA(2,1,ig,ir),D3ALFA(2,2,ig,ir),
     ,                                   D3ALFA(2,3,ig,ir),b3,ir=1,K3)
               write(*,'(4x,'//cha1//'(1x,a,F8.5,1x,f8.5,1x,f8.5,a)/)') 
     ,                     (b2,D3ALFA(3,1,ig,ir),D3ALFA(3,2,ig,ir),
     ,                                   D3ALFA(3,3,ig,ir),b1,ir=1,K3)
            end do
         end if
c
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S' .and. active .and. Yes_ampl) THEN

         call get_new_TI(N_Cond,iV1,iV2,ampl(1),TI,ITI)
         write(*,*)'... writing geometry and k-points ...'
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.true.)

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN
         TI=TI1
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
c
c............. errors
 100  write(*,*)'.<mol_vibr>.Execution interrupted due to FATAL'//
     &                                              ' errors ...'
      stop 
      end

      subroutine show_W_matrix(iOrb,RA,IA,NREP)
c.....................................................................
c A nice print of the transformation matrix for the current
c orbitiOrb,, irrep IA, which enters NREP times (directly after 
c VANJA)
c.....................................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      dimension kk(3),RR(MG0,3),RA(3)
      integer rep
      character a(3)
      data a/'y','z','x'/,kk/2,3,1/
      write(*,'(a/)')'********** transformation matrix ***********'
      write(*,'(24x,a)') '<---(repetition,row)--->'
      write(*,'(2x,a,20(3x,a,i2,a,i1,a,2x))') 'old# atom#   x/y/z   ',
     ,         (('(',rep,',',i,')',i=1,NALFA(IA)),rep=1,NREP)
      call PVRT0(RA,RR,Nnn)
      do nat=1,Nnn
         iold=orb_to_old(iOrb,nat)
         do j=1,3
            k=kk(j)
            write(*,'(i3,x,i5,a,20(x,f10.5))') iold,nat,a(j),RR(nat,k),
     ,             ((W(i,rep,nat,j),i=1,NALFA(IA)),rep=1,NREP)
         end do
      end do
      write(*,*)'--------------------------------------------------- '
      return
      end

      subroutine show_W_all_matrix(IA,IRA,Species,N_Cond,Show_fixed)
c.............................................................
c nice print of the symmetry-adapted displacements 
c IA     - given irrep
c IRA    - total number of linearly independent vectors
c N_Cond - number of conditions
c.............................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension kk(3),RR(MG0,3),RA(3)
      integer rep,unit
      character a(3),Species(N0KD)*2
      logical Show_fixed
      data a/'y','z','x'/,kk/2,3,1/
c  
c........... write on the scree/file
c
      unit=6
      write(unit,'(a/)')
     &     '********** symmetry-adapted displacements ***********'
      write(unit,'(24x,a)') '   <---(repetition,row)--->'
      write(unit,'(2x,a,20(3x,a,i2,a,i1,a,2x))')
     &     'old#     atom#   x/y/z   ',
     &     (('(',rep-N_Cond,',',i,')',i=1,NALFA(IA)),rep=N_Cond+1,IRA)
      iN0=0
      do iOrb=1,NORB
         if((.not.Fix(iOrb)) .or. Show_fixed) then
            RA(1:3)=R1(iOrb,1:3)
            is=ISORT1(iOrb)
            call PVRT0(RA,RR,Nnn)
            do nat=1,Nnn
c            do nat=1,KAN(iOrb)
               iN=iN0+nat
               iold=orb_to_old(iOrb,nat)
               do i=1,3
                  k=kk(i)
                  write(unit,'(i3,x,a,x,i5,a,20(x,f10.5))') 
     &                 iold,Species(is),iN,a(i),RR(nat,k),
     ,            ((W_all(i,iN,rep,j),j=1,NALFA(IA)),rep=N_Cond+1,IRA)
               end do
            end do
            write(unit,*)
     &        '---------------------------------------------------'
         end if
         iN0=iN0+KAN(iOrb)
      end do
      return
      end

      subroutine write_W_all_matrix(IA,IRA,N_Cond)
c.............................................................
c writes the symmetry-adapted displacements to a file W_IA.mat
c IA     - given irrep
c IRA    - the number of liunearly independent vectors
c N_Cond - number of conditions
c.............................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension RR(MG0,3),RA(3)
      integer rep
      character cha1,cha2*2
c
c........... write the vectors into a file Vector_{irrep number}.dat
c
      if(IA.lt.10) then
         write(cha1,'(i1)') IA
         open (23,file='W_'//cha1//'.mat',form='formatted')
      else 
         write(cha2,'(i2)') IA
         open (23,file='W_'//cha2//'.mat',form='formatted')
      end if
c  
c........... write on the screen/file
c
      iN=0
      do iOrb=1,NORB
         RA(1:3)=R1(iOrb,1:3) ; is=ISORT1(iOrb)
         call PVRT0(RA,RR,Nnn)
         do nat=1,Nnn
            iN=iN+1
            do i=1,3
               write(23,*) 
     &              ((W_all(i,iN,rep,j),j=1,NALFA(IA)),rep=N_Cond+1,IRA)
            end do
         end do
      end do
      close (23)
      return
c
c..[TEST].. check orthogonality of W matrix within each orbit for the given irrep IA
c           [this may not work for molecules if constraints are applied]
c           {comment out the return statement above to activate}
c
      write(*,'(/a/)')'.... checking orthogonality of the W matirx ....'
      do iF1=N_Cond+1,IRA
         do iF2=iF1,IRA
            do j1=1,NALFA(IA) 
               do j2=J1,NALFA(IA)

                  iN=0
                  do 10 iOrb=1,NORB
                     if(Fix(iOrb)) go to 10
                     RA(1:3)=R1(iOrb,1:3) ; is=ISORT1(iOrb)
                     call PVRT0(RA,RR,Nnn)
                     s=0.0
                     write(*,'(a,i5,a)')'______> Orbit ',iOrb,' <______'
                     do nat=1,Nnn
                        iN=iN+1
                        s=s+W_all(1,iN,iF1,j1)*W_all(1,iN,iF2,j2)+
     +                      W_all(2,iN,iF1,j1)*W_all(2,iN,iF2,j2)+
     +                      W_all(3,iN,iF1,j1)*W_all(3,iN,iF2,j2)
                     end do
                     write(*,'(4(a,i2),a,e12.6)') 
     &                    '(',iF1,',',j1,') (',iF2,',',j2,') ',s
 10               end do

               end do
            end do
         end do
      end do
      end

      subroutine distorted_xyz(IRA,N_Cond,iV,j,ampl,Species,ITI,
     ,                                             unit,YES_xyz,Add_Hs)
c..............................................................................
c     New atomic positions corresponding to the excitation of one diaplcement
c vector iV,j (with amplitude ampl) are calculated and then dumped into a unit.
c   Here iV corespond to the vector number for row=1. If row index j
c is different from 1 (for 2D and 3D irreps), then the vector corresponding to
c the rowj is used.
c..............................................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension RR(MG0,3),RA(3),x(3)
      integer unit
      character YES_xyz*4,Species(N0KD)*2
      logical Err,Add_Hs
      
c................. write number of atoms
      nnn=ITI
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(unit,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(unit,'(a/i5)') '1',nnn
      end if

      iN=0
      do iOrb=1,NORB
         RA(1:3)=R1(iOrb,1:3)
         is=ISORT1(iOrb)
         call PVRT0(RA,RR,Nnn)
         call check_Mendel(Species(is),mendl,Err,.false.)

         do nat=1,Nnn
            iN=iN+1
            x(1)=RR(nat,1)+W_all(3,iN,N_Cond+iV,j)*ampl
            x(2)=RR(nat,2)+W_all(1,iN,N_Cond+iV,j)*ampl
            x(3)=RR(nat,3)+W_all(2,iN,N_Cond+iV,j)*ampl

            if(YES_xyz.eq.'Xmol') then
               write(unit,'(a2,5x,3(f16.10,1x),a)') 
     &              Species(is),(x(j1),j1=1,3)
c     &              Species(is),(x(j1),j1=1,3),' 0 0 0'
            else if(YES_xyz.eq.'Ymol') then
               write(unit,'(i2,5x,3(f16.10,1x))') 
     &              mendl,(x(j1),j1=1,3)
            end if

         end do
      end do

      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(unit,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol' .and.Add_Hs) then
         write(unit,'(a)')'2     0.0 0.0 0.0  '
         write(unit,'(a)')'3     15.0 0.0 0.0 '
         write(unit,'(a)')'4     0.0 15.0 0.0 '
         write(unit,'(a)')'5     0.0 0.0 15.0 '
      end if
      return
      end

      subroutine get_new_TI(N_Cond,iV1,iV2,ampl,TI,ITI)
c..............................................................................
c     New atomic positions corresponding to the excitation of one diaplcement
c vector iV,j (with amplitude ampl) are calculated and then dumped into a unit.
c   Here iV corespond to the vector number for row=1. If row index j
c is different from 1 (for 2D and 3D irreps), then the vector corresponding to
c the row j is used.
c..............................................................................
      include 'real8.inc'
      include 'symgenv.inc'
      include 'working.inc'
      dimension RR(MG0,3),RA(3),TI(3,N0LT)
      
      iN=0
      do iOrb=1,NORB
         RA(1:3)=R1(iOrb,1:3)
         is=ISORT1(iOrb)
         call PVRT0(RA,RR,Nnn)

         do nat=1,Nnn
            iN=iN+1
            if(iV1.eq.iV2) then
               TI(1,iN)=RR(nat,1) + W_all(3,iN,N_Cond+iV1,1)*ampl
               TI(2,iN)=RR(nat,2) + W_all(1,iN,N_Cond+iV1,1)*ampl
               TI(3,iN)=RR(nat,3) + W_all(2,iN,N_Cond+iV1,1)*ampl
            else
               TI(1,iN)=RR(nat,1) + ampl*(W_all(3,iN,N_Cond+iV1,1) +
     +                                W_all(3,iN,N_Cond+iV2,1))
               TI(2,iN)=RR(nat,2) + ampl*(W_all(1,iN,N_Cond+iV1,1) +
     +                                W_all(1,iN,N_Cond+iV2,1))
               TI(3,iN)=RR(nat,3) + ampl*(W_all(2,iN,N_Cond+iV1,1) +
     +                                W_all(2,iN,N_Cond+iV2,1))
            end if
c            write(*,'(a,2(i3,x),5x,3(f12.8,x))') 
c     &           'new: ',iOrb,iN,(TI(j,iN),j=1,3)
         end do
      end do
      end

      subroutine automatic(iFix,N_Cond,Ndispl,Yes_Fixed,ifx,ampl,active,
     ,     IRA_left,C_Cond,IA_active,syst)
c.........................................................................
c Ndispl - number of displacements to be used
c.........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'whereis.inc'
      include 'mendeleev.inc'
      character answer_code,answer,cha2*2,syst*8
      logical Yes_Fixed,active,Err
      dimension Displ(4),iFix(N0RB),IRA_left(N0IR)
      dimension C_cond(3,N0LT,6),ampl(2)
      character Which_Code*6,Which_Format*6,seed1*40

c................. set up all displacements amplitudes
      
      if(Ndispl.eq.1) then
         Displ(1)= ampl(1)
      else if(Ndispl.eq.2) then
         Displ(1)= ampl(1) ; Displ(2)=-ampl(1)
      else if(Ndispl.eq.4) then
         Displ(1)= ampl(1) ; Displ(2)=-ampl(1)
         Displ(3)= ampl(2) ; Displ(4)=-ampl(2)
      end if

c................ interactive part

c
c........ choose the write/output format
c
 1    call ask_which_format(Which_Code,Which_Format,seed1,l0seed1,
     ,                             'S')
      if(Which_Format.eq.'  VASP') then
         answer_code='v'
      else if(Which_Format.eq.'VASP52') then
         answer_code='w'
      else if(Which_Format.eq.'    MM') then
         answer_code='m'
      else if(Which_Format.eq.'SIESTA') then
         answer_code='s'
      else if(Which_Format.eq.'QUICKS') then
         answer_code='q'
      else if(Which_Format.eq.'LAMMPS') then 
         answer_code='l'                     
      else if(Which_Format.eq.'    LM') then
         answer_code='t'
      else if(Which_Format.eq.'  None') then
         write(*,'(a/a)')'Exiting ... Hit ENTER when ready ...'
         read(*,*)
         return
      else
         write(*,*)'ERROR! Not yet implemented! Try again!'
         go to 1
      end if
c      write(*,'(a)')'Which option: Energy or Force (e/f)?'
c      read(*,*) answer
      answer='f'

c................ write to the file: general part

      open(37,file='input_for.tetr',form='formatted')
      if(answer_code.eq.'s') then
         write(37,'(a)') '4' ; cha2='4 '
         write(37,'(a)') seed1(l0seed1:)
      else if(answer_code.eq.'v') then
         write(37,'(a)') '3' ; cha2='3 '
         write(37,'(a)') seed1(l0seed1:)
         do is=1,Nsp
            write(37,'(a)') Species(is)
         end do
      else if(answer_code.eq.'w') then
         write(37,'(a)') '8' ; cha2='8 '
         write(37,'(a)') seed1(l0seed1:)
      else if(answer_code.eq.'q') then
         write(37,'(a)') '2' ; cha2='2 '
         write(37,'(a)') seed1(l0seed1:)
      else if(answer_code.eq.'l') then 
         write(37,'(a)') 'L' ; cha2='L '
         write(37,'(a)') seed1(l0seed1:) 
         do is=1,Nsp
            call check_Mendel(Species(is),mendl,Err,.true.)
            write(37,'(i2)') mendl
         end do
      else if(answer_code.eq.'t') then
         write(37,'(a)') 'LM' ; cha2='LM'
         write(37,'(a)') seed1(l0seed1:)
      end if
      if(syst.eq.' LATTICE') then
         write(37,'(a)') 'Vc'
      else if(syst.eq.'MOLECULE') then
         write(37,'(a)') 'Vm'
      else if(syst.eq.'LATT-TRA') then
         write(37,'(a)') 'Vs'
      else if(syst.eq.' K-POINT') then
         write(37,'(a)') 'Vk'
      end if
c................. if system='LATT-TRA' or ' K-POINT', then choose the supercell first

      if(syst.eq.'LATT-TRA' .or. syst.eq.' K-POINT') then
         write(37,'(a)') 'Su'
         do i=1,3
            write(37,'(3(i5,x))') (IJ(i,j),j=1,3)
         end do
      end if
c.................. fixed atoms

      if(Yes_Fixed) then
         do nt=1,ifx,10
            ntm=nt+9
            if(ntm.gt.ifx) ntm=ifx
            write(37,'(a)') 'Fx'
            write(37,'(10(i3,x))') (iFix(j),j=nt,ntm)
         end do
      end if

c.................. save the script

      open(38,file='run_DFT_script',form='formatted')
      write(38,'(a)') '#!/bin/csh '
      write(38,'(a)')'#################################################'
      write(38,'(a)')'# is used to run DFT to get 2nd derivative matrix'
      write(38,'(a)')'#################################################'
      if(answer_code.eq.'s') then
         write(38,'(a)') " set siesta='mpirun -np NN [executable]'"
      else if(answer_code.eq.'v' .or. answer_code.eq.'w') then
         write(38,'(a)') " set vasp='mpirun -np NN [executable]'"
      else if(answer_code.eq.'q') then
         write(38,'(a)') " set cp2k='mpirun -np NN [executable]'"
      else if(answer_code.eq.'l') then
         write(38,'(a)') " set lmp='mpirun -np NN [executable]'"
      else if(answer_code.eq.'t') then
         write(38,'(a)') " set lmf='mpirun -np NN [executable]'"
      end if

c................ write to the file: irrep-dependent part

      if(active) then
         if(syst.ne.' K-POINT') then
            IRA=IRA_left(IA_active) + N_cond
            call write_G_matrix(IA_active,IRA,N_Cond,AtMass)
            call write_W_all_matrix(IA_active,IRA,N_Cond)
         end if
         call do_input_scripts(IA_active,iFix,IRA,N_Cond,Ndispl,
     &           Yes_Fixed,ifx,Displ,answer,answer_code,cha2,syst)
      else
         do IA=1,NEPR
            if(IRA_left(IA).ne.0) then
               IA_active=IA
               if(syst.ne.' K-POINT') then
                  call do_irrep(IA,ITI,IRA,N_Cond,C_cond,Species,BJ)
                  if(IRA-N_Cond.ne.IRA_left(IA)) stop 'IRA error'
                  call write_G_matrix(IA_active,IRA,N_Cond,AtMass)
                  call write_W_all_matrix(IA_active,IRA,N_Cond)
               else
                  IRA=IRA_left(IA)
               end if
               call do_input_scripts(IA_active,iFix,IRA,N_Cond,Ndispl,
     &              Yes_Fixed,ifx,Displ,answer,answer_code,cha2,syst)
            end if
         end do
      end if

c............... finish off the file

      write(37,'(a/a)') 'Q','Q'
      close (37)
      write(*,*)'>>>>>>>>>> FILE input_for.tetr CREATED <<<<<<<<<<'

c............... finish off the script
      close(38)
      call system('chmod u+x run_DFT_script')

c............... create all input files by running tetr from inside

      call system(tetr_dir(tetr_l0:)//'/tetr < input_for.tetr >& out')
      end

      subroutine do_input_scripts(IA_active,iFix,IRA,N_Cond,Ndispl,
     &             Yes_Fixed,ifx,Displ,answer,answer_code,ch2,syst)
c.........................................................................
c do everything for the given irrep IA_active
c.........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      character answer_code,answer,cha2*2,cha10(4)*10,cha5*5,ch2*2
      character cht(K0DM0)*5, al_string*9,syst*8
      integer l_cht(K0DM0)
      logical Yes_Fixed
      dimension Displ(4),lb(4),iFix(N0RB)

c.................. create directories [will complain if directories exist]

      write(cha2,'(i2)') IA_active
      call posit(cha2,2,la)
      call system('mkdir irrep_'//cha2(la:))
      write(*,'(a)')'Directory irrep_'//cha2(la:)//' created'
      do id=1,Ndispl
         write(cha10(id),'(f10.5)') Displ(id)
         call posit(cha10(id),10,lb(id))
         call system('mkdir 
     &             irrep_'//cha2(la:)//'/d='//cha10(id)(lb(id):))
         write(*,'(a)')
     &    'Directory irrep_'//cha2(la:)//'/d='//cha10(id)(lb(id):)//
     &                                  ' created'
      end do
      
c.................. write input file

      write(37,'(a/i2)') 'Ir',IA_active

c__________________________ loop over displacements
      DO id=1,Ndispl
         write(37,'(a/f10.5)') 'Da',Displ(id)
         do iV1=1,IRA-N_Cond
            write(37,'(a)') 'Vn'
            if(syst.eq.' K-POINT') then
c________________ loops over atoms of the primitive cell first,
c                 then x,y,z
               iat=int(iV1/3) ; if(iat*3.ne.iV1) iat=iat+1 
               ixyz=iV1-3*(iat-1)
               write(37,'(i5,x,i5)') iat,ixyz
            else
               write(37,'(i5,x,i5)') iV1, iV1
            end if
            write(37,'(a/a)') 'S',ch2
            write(cha5,'(i5)') iV1 ; call posit(cha5,5,lc)
            write(37,'(a)') 
     &   'irrep_'//cha2(la:)//'/d='//cha10(id)(lb(id):)//'/'//cha5(lc:)
            if(iV1.gt.K0DM0) then
               write(*,*) 
     &   'WARNING! list of files in run_DFT_script will be incomplete!'
               write(*,*)'Increase K0DM0 in sym_par.inc'
            else
               cht(iV1)=cha5 ; l_cht(iV1)=lc 
            end if
            if(answer_code.eq.'v'.or.answer_code.eq.'w') 
     &                                              write(37,'(a)') 'c'
         end do 
      END DO

c.................. save script [The loop over different repetitions
c         (if IRA-N_Cond > 50) will be split into several with 50 in each]

      write(38,'(/a,i5/)') '#...... irrep = ',IA_active
      do id=1,Ndispl

         write(38,'(a)') 
     &        'set dir=irrep_'//cha2(la:)//'/d='//cha10(id)(lb(id):)

         do k=1,IRA-N_Cond,50
            kmin=k ; kmax=k+49; if(kmax.gt.IRA-N_Cond) kmax=IRA-N_Cond
            write(38,'(52a)') 
     &       'foreach file ( ',(cht(i)(l_cht(i):)//' ',i=kmin,kmax),' )' 
            if(answer_code.eq.'v' .or. answer_code.eq.'w' 
     &                                     .or. answer_code.eq.'m') then
               write(38,'(3a)') '   /bin/cp $dir/$file POSCAR'
               if(answer_code.eq.'v' .or. answer_code.eq.'w') then
                  write(38,'(3a)') '   $vasp'
               else if(answer_code.eq.'m') then
                  write(38,'(3a)') '   mm'
               end if
               write(38,'(a)')'   /bin/mv OUTCAR $dir'//'/OUTCAR_$file'
               write(38,'(a)')'end'
            else if(answer_code.eq.'s') then
               write(38,'(3a)')'  /bin/cp $dir/$file.fdf INPUT_FILE.fdf'
               write(38,'(3a)')'  $siesta |tee OUTCAR'
               write(38,'(a)')  ' /bin/mv OUTCAR $dir'//'/OUTCAR_$file'
               write(38,'(a)') 'end'
            else if(answer_code.eq.'q') then
               write(38,'(3a)')'  /bin/cp $dir/$file input.inp'
               write(38,'(3a)')'  $cp2k -o OUTCAR input.inp '
               write(38,'(a)')  ' /bin/mv OUTCAR $dir'//'/OUTCAR_$file'
               write(38,'(a)') 'end'
            else if(answer_code.eq.'l') then 
               write(38,'(a)') '  /bin/cp $dir/$file INPUT_STR.pos' 
               write(38,'(a)') '  $lmp <INPUT_SCRIPT >OUTPUT' 
               write(38,'(a)')'  echo "-----" >>OUTCAR'
               write(38,'(a)') '  /bin/mv OUTPUT $dir'//'/OUTPUT_$file'
               write(38,'(a)') '  /bin/mv OUTCAR $dir'//'/OUTCAR_$file'
               write(38,'(a)') 'end' 
            else if(answer_code.eq.'t') then
               write(al_string,"(f9.6)") alat
               write(38,'(a)') '  echo "Preparing $dir/$file"'
               write(38,'(a)') '  cp $dir/$file site.$file'
               write(38,'(a)') '  mv ctrl.* ctrl.$file'
               write(38,'(a)') '  mv atm.* atm.$file'
               write(38,'(a)') '  mv basp.* basp.$file'
               write(38,'(a)') '  $lmf ctrl.$file --wforce=force' //
     &           ' --wpos=pos'
               write(38,'(a)') '  rm mixm.$file site.$file rst.$file' 
               write(38,'(a)') '  mv force.$file $dir/force.$file'
               write(38,'(a)') '  mv pos.$file $dir/pos.$file'
               write(38,'(a)') '  mv save.$file $dir/save.$file'
               write(38,'(a)') "  awk '/%/ {x=NR; next}(NR>x) {" //
     &           "con=38.89379629307789; val1=$1*con;" // 
     &           " val2=$2*con; val3=$3*con; print val1, val2, val3}'"//
     &           " $dir/force.$file > $dir/fnew.$file"
               write(38,'(a)') "  awk '/%/ {x=NR; next}(NR>x) {" //
     &           "con=0.529177249; val1=$1*con;" // 
     &           " val2=$2*con; val3=$3*con; print val1, val2, val3}'"//
     &           " $dir/pos.$file > $dir/pnew.$file"
               write(38,'(a)') '  echo "POSITION                    ' //
     &           '                  TOTAL-FORCE (eV/Angst)" > ' //
     &           '$dir/OUTCAR_$file'
               write(38,'(a)') '  echo "------------------------' //
     &           '---------------------------------------------------'//
     &           '--------------" >> $dir/OUTCAR_$file'
               write(38,'(a)') "  pr -m -t -s  $dir/pnew.$file " //
     &           "$dir/fnew.$file | awk '{print $0}' >> " //
     &           "$dir/OUTCAR_$file"
               write(38,'(a)') '  rm $dir/pnew.$file $dir/fnew.$file'
               write(38,'(a)') '  echo "------------------------'//
     &           '---------------------------------------------------'//
     &           '--------------" >> $dir/OUTCAR_$file'
               write(38,'(a)') 'end'
            end if
         end do

      end do
      end

      subroutine get_orbits(KodErr,Linear,N_cond1,C_cond,Err,yes_symm)
c...................................................................
c (1) obtain the system symmetry;
c (2) split the system into orbits;
c (3) if MOLECULE (default): check if it is linear
c (4) if MOLECULE (default): calculate conditions
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      include 'systema.inc'
      dimension C_cond(3,N0LT,6)
      logical Linear,Err
      character Gfam*3,yes_symm

c________ get the symmetry group
c         [for testing purposes yes_symm='n']

      call check_symmetry('n',yes_symm)
c
c_________ order elements KG in the correct order as they should
c          appear in the table of characters and in matrices of irreps;

      call permut(Gfam,GroupN,MGp,KGp,iErr)
      MG=MGp
      do i=1,MG
         KG(i)=KGp(i)
c_______________ Internal translations are set to zero.
         TRAN(i,1:3)=0.0
      end do
c
c_________ read all the info of the group including irreps 
c
      call readgr(KodErr,3)
      if(KodErr.eq.1) return
c
c......... break down system into orbits:
c            R1(i,xyz) - 1st atom of orbit i
c            NORB       - number of orbits
c
      call irina(TI,Nsp,NspN,BJ,Err)
      if(Err) return
c
c....... check if the molecule is linear along Z and then obtain
c        the 6 (or 5) vectors of conditions
c
      if(system.eq.'MOLECULE') then
         a=0.0
         do nat=1,ITI
            a=a+sqrt(TI(1,nat)**2+TI(2,nat)**2)
         end do
         if(abs(a).gt.tiny_equiv) then
            Linear=.false.
            write(*,*)'Molecule is NOT linear!'
         else
            Linear=.true.
            write(*,*)'Molecule IS linear!'
         end if

c______________ apply conditions and orthogonormalise them for the
c               default case of MOLECULE
         N_cond1=6
         call do_cond(N_Cond1,C_cond,AtMass)
         if(Linear) N_cond1=5
      else
         N_Cond1=0
      end if
      return
      end

      subroutine choose_masses(Species,AtMass,Nsp,Yes_masses)
c...............................................................
c choose masses for species
c...............................................................
      include 'real8.inc'
      character Species(Nsp)*2,cha2*2,cha,chaa2*2
      dimension AtMass(Nsp)
      logical Yes_masses
      data tiny/0.001/

 21   write(*,*)'>>>>>>>>>>>>> choose atomic masses <<<<<<<<<<<<'
      ii=0
      do is=1,Nsp
         if(is.lt.10) then
            write(cha,'(i1)') is
            chaa2=' '//cha
         else if(is.lt.100) then
            write(chaa2,'(i2)') is
         else
            write(*,*)'FATAL! is > 99 - not yet implemented!'
         end if
         if(AtMass(is).lt.tiny) then
            write(*,'(x,a)') 
     &         chaa2//' Mass of '//Species(is)//' <= undefined'
         else
            ii=ii+1
            write(*,'(x,a,f10.5,a)') 
     &    chaa2//' Mass of '//Species(is)//' = ',AtMass(is),' a.m.u.'
         end if
      end do
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[IS]..... choose species IS

c[Q].... finish

      IF(cha2(l0:).eq.'Q') THEN
         if(ii.eq.Nsp) then
            Yes_masses=.true.
         else
            Yes_masses=.false.
         end if
         return
      ELSE
         read(cha2,*,err=10) is1
         if(is1.ge.1 .and. is1.le.Nsp) then
 1          write(*,'(3a)')'Specify atomic mass (a.u.m.) for ',
     ,                                      Species(is1) ,':'
            read(*,*,err=1) AtMass(is1)
            go to 21
         end if
 10      write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

      
         
