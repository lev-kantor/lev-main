      subroutine move_atoms(nkp,kpoint,Which_Code)
c....................................................................
c     Atoms in the cell can be freely moved around preserving the
c cell symmetry
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension x(3),dspl(3),r(3),dir(3)
      dimension iSym(N0LT),iNum(N0LT),iSort(N0LT)
      common /buffer0/ A0(3,3),TI0(3,N0LT),B0(3,3),ITI0,
     ,     NspN0(N0KD),Nsp0,Species0(N0KD),relax_flag0(3,N0LT)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,relax_flag1
      character Species0*2,relax_flag0
      character cha2*2,angstr*12,YES_xyz*4,Which_Code*6
      double precision kpoint(Nkpoint,3)
      logical Yes_Move,Yes_Done,Add_Hs,ask_equiv,Genrt1
      data tiny/0.000001/,nm/0/,dspl/3*0.0/
      data angstr/'<AtomNumber>'/,YES_xyz/'Xmol'/
      data M11/0/,N11/0/,M22/0/,N22/0/,M33/0/,N33/0/,Add_Hs/.false./
c
c................................................................
c....... check the symmetry of the currect system ...............
c................................................................
c
      write(*,*)'....................................................'
      write(*,*)'... Asking about your LARGE lattice point group ....'
      write(*,*)'....................................................'
      write(*,*)
      call point_gr()
      write(*,*)'______ So, your system point group is '//GroupN
      write(*,*)'       with elements:'
      write(*,'(12(a4,1x))') (NAZ(KGp(i)),i=1,MGp)
      write(*,*)
c
c
c...... save old positions of atoms in TI1(comp,number). 
c
c___________ keep the current geometry as default in /buffer0/

      call keep_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)

c___________ keep the old geometry for undo

      call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,Genrt)

c
c...... fill in iSort(sublattice) by atomic sorts
c
      k=0
      do i=1,Nsp
        do j=1,NspN(i)
          k=k+1
          iSort(k)=i
        end do
      end do
c
c........... MENU ...........................................
c
      Yes_Move=.false.
      Yes_Done=.false.
      dmove=0.0
 13   write(*,'(a)')'Choose an option:'
      write(*,*)
      write(*,'(a)')'>>>>>> atoms are numbered across species <<<<<<<'
      write(*,*)

      if(nm.eq.0) then
         write(*,'(a)')
     &     '  1. Specify atom to be moved and show all equivalent'
      else
         write(*,'(a,i5)')'  1. Atom to be moved is number = ',nm
         if(js.eq.0) then
            write(*,'(a)')'... No symmetry equivalent atoms found!'
         else
            write(*,'(5x,a,i3)')
     &     'Number of atoms found in the star: ' ,js+1
            write(*,'(5x,a)')'>>> these are atoms/symmetries:'
            write(*,'((5x,10(i4,x)))') (iNum(is),is=1,js)
            write(*,'((5x,10(a4,x)))') (NAZ(KGp(iSym(is))),is=1,js)
         end if
         Yes_Move=.true.
      end if

c_____ arrange displacement

      write(*,'(a)')'  2. Choose the method of displacing atoms'
      if(abs(dmove).gt.tiny) then
         write(*,'(5x,a,3(x,f10.5))')
     &        '>>> (1st atom) displacement direction: ',
     &        (dspl(j)/dmove,j=1,3)
         write(*,'(5x,a,3(x,f10.5))')
     &        '>>> (1st atom) displacement: ', dmove
      end if

      if(Yes_Done) then
         write(*,'(a)')'  M. Move! <== Done!'
      else
         write(*,'(a)')'  M. Move it!'
      end if

c_____ show settings

      write(*,*)
     &'---------- v i s u a l i a s i o n   s e t t i n g s ---------'
c___________ set YES_xyz to the visualisation code: 
c            make geom.xyz file automatically after every change
      write(*,'(8x,a)')
     &     '>>>>> Current setting for the breeding box: <<<<<'
      write(*,'(13x,a,3(i2,a,i2,a))') '[',M11,'...',N11,'] x [', M22,
     &                           '...',N22,'] x [', M33,'...',N33,']'
      L_ext1=(N11-M11+1)*(N22-M22+1)*(N33-M33+1)
      write(*,'(8x,2(a,i5))')
     &     '>>>>> extension = ',L_ext1,', # of atoms= ',ITI*L_ext1

      write(*,*)
     &        ' Bb. Set the size of the breeding box for visualisation'
      write(*,*) 
     &        ' B0. Nullify the breeding box (make the UNIT extension)'

c      if(YES_xyz.ne.'None') then
c         write(*,*)
c     &   ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
c      else
c         write(*,*)
c     &   ' XY. Do NOT produce <geom.xyz> file after every change'
c      end if
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: YES'
         else 
            write(*,*)' Hs. H atoms to be added to <geom.xyz> file: NO'
         end if
      end if
      write(*,*)
     &   '  W. Write <geom.xyz> file for preview using current breeding'

      write(*,'(a)')
     &'-------------- g e n e r a l  s e t t i n g s ----------------'
      write(*,*)' UU. ******  RESTORE the original serting ******'
      write(*,'(a)')'  U. ********** UNDO *********** the last step'
      write(*,'(a)')
     &     ' An. [For input] Coordinates are specified in: '//angstr
      write(*,'(a)')' Sy. Check the symmetry after distortion'
      write(*,'(a)')
     &     ' Co. Show current atomic positions in fractional/Cartesian'
      write(*,'(a)')'  S. Save.'
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,*)
      write(*,'(a)')'----------> Choose the appropriate option:'
      read (*,'(a)',err=13) cha2
      call right(cha2,2,l0)

c
c[XY]...... ask whether to produce geom.xyz file automatically

c      IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'None') then
c            YES_xyz='Ymol'
c         else if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='None'
c         end if

c[Hs]...... add Hydrongens to geom.xyz or not

      IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN
c      ELSE IF(cha2(l0:).eq.'Hs') THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[An]...... choose the way how the coordinates are given

      ELSE IF(cha2(l0:).eq.'An') THEN

         if(angstr.eq.'<Fractional>') then
            angstr='<Angstroms> '
         else if(angstr.eq.'<Angstroms> ') then
            angstr='<AtomNumber>'
         else if(angstr.eq.'<AtomNumber>') then
            angstr='<Fractional>'
         end if 
c
c[1]___________ find all atoms of the star
c
      ELSE IF(cha2(l0:).eq.'1') THEN

 21      write(*,*)'Specify the atom by its number:'
         read(*,*,err=21) nm
         if(nm.gt.ITI .or. nm.lt.1) go to 21
         write(*,*)'Checking other atoms on equivalence ...'
         js=0
         do 30 k=1,ITI
            if(k.eq.nm) go to 30
            do jGb=1,MGp
               jG=KGp(jGb)
               r(1)=C(1,1,jG)*TI(1,k)+C(2,1,jG)*TI(2,k)+
     +              C(3,1,jG)*TI(3,k)-TI(1,nm)
               r(2)=C(1,2,jG)*TI(1,k)+C(2,2,jG)*TI(2,k)+
     +              C(3,2,jG)*TI(3,k)-TI(2,nm)
               r(3)=C(1,3,jG)*TI(1,k)+C(2,3,jG)*TI(2,k)+
     +              C(3,3,jG)*TI(3,k)-TI(3,nm)
               if(ask_equiv(r,BJ,3,tiny_equiv)) then
                  if(iSort(nm).ne.iSort(k)) stop 'ERROR in move_atoms!'
                  js=js+1
                  write(*,'(a,i5,a,3(f10.5,x),a,i3)')'... atom = ',k,
     &                 ' at ( ',(TI(j,k),j=1,3),
     &                      ') is equivalent to atom ',nm
                  write(*,'(a,a4)')'..symmetry operation ',NAZ(jG)
                  iSym(js)=jGb
                  iNum(js)=k
                  go to 30
               end if
            end do
 30      continue

c
c[2]___________ specify ther displacement vector
c
      ELSE IF(cha2(l0:).eq.'2') THEN

c___________ ask about the target
 94      write(*,*)'Specify direction of the displacement by:'
         write(*,*)
     &    '  1. two points (e.g. two atoms): primary and target'
         write(*,*)'  2. or a vector'
         read(*,*,err=94) methd
         if(methd.ne.1.and.methd.ne.2) go to 94
         if(methd.eq.1) then
            write(*,*)'Specify the primary point:'
            call givepoint(x(1),x(2),x(3),angstr)
            write(*,*)'Specify the target point:'
            call givepoint(r(1),r(2),r(3),angstr)
            dir(1)=r(1)-x(1)
            dir(2)=r(2)-x(2)
            dir(3)=r(3)-x(3)
         else
 92         write(*,*)'Specify the direction vector:'
            read(*,*,err=92) dir
         end if
         dd=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
         if(dd.lt.tiny) then
            write(*,*)'ERROR! Zero direction!'
            go to 94
         end if
         write(*,'(a,3(x,f10.5))')
     &        'Displacement direction: ',(dir(i)/dd,i=1,3)

c___________ ask how to move if by two points
         if(methd.eq.1) then
 95         write(*,*)
     &        'Specify how to move towards the target (in Agstrems):'
            write(*,*)' 1. By some distance'
            write(*,*)
     &      ' 2. Primary point to be some distance away from the target'
            read(*,*,err=95) meth
            if(meth.ne.1.and.meth.ne.2) go to 95
         end if

c___________ ask the distance
 96      write(*,*)'Specify the distance (in Angstrems):'
         read(*,*,err=96) dists
         if(methd.eq.2 .or. meth.eq.1) then
            dmove=dists
         else
            dmove=dd-dists
         end if
         write(*,'(a,f10.5,a)')
     &        'Atoms in the list will be moved by ',dmove,' A'
         dspl(1)= dmove/dd * dir(1)
         dspl(2)= dmove/dd * dir(2)
         dspl(3)= dmove/dd * dir(3)

c
c[M]___________ move all atoms belonging to the star
c
      ELSE IF(cha2(l0:).eq.'M' .and. Yes_Move) THEN

c___________ keep the old geometry for undo
         call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)

c___________ displace the first atom of the star

         TI(1,nm)=TI1(1,nm)+dspl(1)
         TI(2,nm)=TI1(2,nm)+dspl(2)
         TI(3,nm)=TI1(3,nm)+dspl(3)
         write(*,'(a,i4,a,3(f10.5,x),a,3(f10.5,x),a)')
     &           'atom ',nm,' (',(TI1(j,nm),j=1,3),') ==> (', 
     &           (TI(j,nm),j=1,3),')'

c___________ displace other atoms of the star

         if(js.ne.0) then
            do is=1,js
               jG=KGp(iSym(is))
               k=iNum(is)
               do i=1,3
                  d=C(i,1,jG)*dspl(1)+C(i,2,jG)*dspl(2)+
     +                 C(i,3,jG)*dspl(3)
                  TI(i,k)=TI1(i,k)+d
               end do
               write(*,'(a,i4,a,3(f10.5,x),a,3(f10.5,x),a)')
     &           'atom ',k,' (',(TI1(j,k),j=1,3),') ==> (', 
     &              (TI(j,k),j=1,3),')'
            end do
         end if
         Yes_Done=.true.

c___________ constract all lattice sites  and write geom.xyz      
         if(YES_xyz.ne.'None') 
     &         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c
c[Sy]___________ checking the symmetry for the new geometry
c

      ELSE IF(cha2(l0:).eq.'Sy') THEN

         call check_symmetry('n','y')

         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[UU].... restore the default

      ELSE IF(cha2(l0:).eq.'UU') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         Yes_Done=.false.
c
c[U]___________ undo the last step
c
      ELSE IF(cha2(l0:).eq.'U') THEN

         call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag,
     ,        Genrt)
         Yes_Done=.false.

c[Co].... display atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN
         call show_atoms_notag()

c[Bb].... ask extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'Bb') THEN

c___________ ask extensions along the existing lattice vectors for the 
c            breeding box
         call ask_breeding_box(M11,N11,M22,N22,M33,N33)
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[B0].... nullify the extensions for the breeding box

      ELSE IF(cha2(l0:).eq.'B0') THEN

         M11=0 ; N11=0 ; M22=0 ; N22=0 ; M33=0 ; N33=0
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[W].... write geom.xyz file for the current breeding box: visualisation only

      ELSE IF(cha2(l0:).eq.'W') THEN

c___________ constract all lattice sites  and write geom.xyz      
         call create_xyz(M11,N11,M22,N22,M33,N33,YES_xyz,Add_Hs)

c[S].... create geometry/k-points file

      ELSE IF(cha2(l0:).eq.'S') THEN
         call write_kp(nkp,kpoint,Which_Code,YES_xyz,.false.)

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN

         call restore_default(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         call check_symmetry('y','y')
         return

      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 13

      end



