        subroutine permut(GfamX,PgrX,MGx,KGx,iErr)
c....................................................................
c..... From the input:
c   GfamX - the group family (Oh or D6h);
c   PgrX  - the group label  (Oh,Td,C2. etc.);
c   MGx   - the order of the group (might be incorrect - ignored);
c   KGx   - the list of elements (from the whole list in C() ):
c           might be incomplete (but the number must be equal to or
c           smaller than MGx).
c.....................................................................
c...... The routine considers the group label and the elements  ......
c...... specified in the input and using this information:      ......
c......  - chooses the whole group PgrX matching this elements; ......
c......  - takes all the group elements KGx in the correct order......
c......  - takes the correct order of the group MGx             ......
c.....................................................................
c   The number of elements in the input needn't be equal to the
c   actual number of them in the group; it is sufficient to specify
c   only the group generators, indicating (by an axis) the direction
c   of the group, etc.
c....................................................................
c   iErr = 1 in the case of FATAL errors; otherwise, iErr=0
c....................................................................
      include 'real8.inc'
      include 'pgroup.inc'
      include 'symgenv.inc'
      character GfamX*3,PgrX*3
      integer KGx(*)
c
c................ Choose the family first: 1 (for Oh) or 2 (for D6h)
c.......... Try to check all Oh groups: all elements are in NGROUP(k,iG)
c              and all names are in GNAM(iG,1)
      do 150 iG=1,98
         if(GNAM(iG,1).ne.PgrX) go to 150
c___________________ determine the number of elements NofE
         NofE=48
         do k=2,48
            if(NGROUP(k,iG).eq.0) then
               NofE=k-1
               go to 60
            end if
         end do
c________________check the elements: loop over all elements specified
c                    in the input (group generators, at least)
 60      do 70 k=1,MGx
            do k0=1,NofE
               if(NGROUP(k0,iG).eq.KGx(k)) go to 70
            end do
            go to 150
 70      end do
c_______________o.k., the first found group is iG:
         GfamX='Oh '
         PgrX=GNAM(iG,1)
         MGx=NofE
         do k=1,MGx
            KGx(k)=NGROUP(k,iG)
         end do
         go to 160
 150  end do
c
c_______ Try to check all D6h groups: all elements are in NGROU1(k,iG)
c     and all names are in GNAM(iG,2)
      do 100 iG=1,54
         if(GNAM(iG,2).ne.PgrX) go to 100
c___________________determine the number of elements NofE
         NofE=24
         do k=2,24
            if(NGROU1(k,iG).eq.0) then
               NofE=k-1
               go to 40
            end if
         end do
c________________check the elements: loop over all elements specified
c     in the input
 40      do 50 k=1,MGx
            do k0=1,NofE
               if(NGROU1(k0,iG).eq.KGx(k)) go to 50
            end do
            go to 100
 50      end do
c_______________o.k., the first found group is iG:
         GfamX='D6h'
         PgrX=GNAM(iG,2)
         MGx=NofE
         do k=1,MGx
            KGx(k)=NGROU1(k,iG)
         end do
         go to 160
 100  end do
      go to 200
c.............. print the group and all its elements
 160  write(*,*)'....... The group family is '//GfamX//' ...'
c      write(*,*)'....... The group is recognized and it is found'//
c     ,                                      ' to be '//PgrX//' ...'
c      write(*,*)'....... The group elements are:'
c      write(*,1)(KGx(k),NAZ(KGx(k)),k=1,MGx)
c 1    format(8(i2,'[',a4,'] '))
c      write(*,*)'..O.K.!.Identification of the group processed '//
c     &                                                  'correctly! ...'
      iErr=0
      return
c.............. error messages .........................................
 200  write(*,*)'.FATAL!.<Permut>.The group contradicts with the '//
     &                                                     'elements!'
       iErr=1
       return
       end

