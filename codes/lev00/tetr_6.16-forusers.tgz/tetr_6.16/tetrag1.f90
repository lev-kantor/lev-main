module tetrag1
use space
use tetr_param  
implicit none
!
!........................................................................
!........... Common statements ..........................................
!........................................................................

!....  AI(number,component) - direct lattice vectors of the primitive UC;
!      BI(number,component) - its reciprocal basic vectors (in 2*PI);
!      TI(component,number) - vectors of sublattices in LUC or UC;
!      ITI - number of sublattices in LUC or UC;
!      Genrt(number) = T if the atom is the 1st atom of the star (in Pc)
!                    = F otherwise
!      how_geometry = 'carte' or 'fract' ==> the way CONTCAR from VASP
!                   stores the coordinates
!      Species(species) - chemical symbol of species
!      seed(l0seed:) - seed (CASTEP/SIESTA/QUICKSTEP), file (VASP) name for input
!      Natom_in_cell(cluster_atom) = number of the cell atom from which
!                                    the given cluster atom is derived
!      Mol_index(atoms) - which division (part) the atoms belongs to (for BSSE)
!      iMol - number of divisions (for BSSE)
!
!    FLEN  - max number of characters in file names
      integer,parameter :: FLEN=100

      real(8) :: AI(3,3),BI(3,3),TI(3,N0LT),vscale
      integer :: ITI,l0seed,Natom_in_cell(N0LT),Mol_index(N0LT),iMol
      character :: how_geometry*5,relax_flag(3,N0LT),vtitle*80,Species(N0KD)*2
      character(len=FLEN) :: seed
      character :: where_siesta*6
      logical :: sel_dyn,donot_kp,Genrt(N0LT)

!... qMP1,qMP2,qMP3 - MP parameters
!    kpmethod  - method of the k-points generation (= 'band','  mp','tetr')
!
      integer :: qMP1,qMP2,qMP3
      character :: kpmethod*4

!
!........................................................................
!.... AtMass(species)  - atomic mass (in a.u.m.)
!     Nsp              - total number of species in fort.5 file
!     NspN(species)    - number of atoms in every species
!
      real(8) :: AtMass(N0KD)
      integer :: NspN(N0KD),Nsp
!
!....  AJ(number,component) - direct lattice vectors of the LUC;
!      BJ(number,component) - its reciprocal basic vectors (in 2*PI);
!     BJ0(number,component) = BJ, but they are different in the case
!                             of z-compression compression;
!      IJ  - this is the UC -> LUC extention matrix;
!      iRotat - number of irred. parts in the whole BZ for LUC lattice
!      z_supp - is used to suppress z-components of BJ-vectors which
!               might be useful for slab calculations
!
      real(8) :: AJ(3,3),BJ(3,3),BJ0(3,3),rIJ(3,3)
      integer :: IJ(3,3),iRotat
      logical :: z_supp,origin
!
!............ precision for checking lattice sites
! 
      real(8) :: tiny_equiv
!
!........... lammps block
! 
      character lkeyword*5
!
!........... LM block
!
      real(8) :: alat,vel(3,N0LT),eula(3,N0LT),vshift(N0LT)
      integer :: PL(N0LT),rlax(N0LT),Nspec(N0LT),Ospec(N0LT)
      character :: lmLine1*137, lmLine2*137
!
!.......... CHIMERA
!
      logical :: CHIMERA

!........... cp2k related stuff

      logical :: cp2k_ghost(N0KD),cp2k_sp_all(N0KD)
      logical :: if_call_which_format
      character :: cp2k_basis_set(N0KD)*30,cp2k_potential(N0KD)*30, &
                    cp2k_element(N0KD)*3
      character(len=FLEN) :: seed2,Which_Format2*6
      integer :: l0seed2

end module tetrag1
