subroutine EA_model_mesh(Which_Code)
!.............................................................................
! Using the current surface geometry, it will position He atom (representing     
! the tip) on a mesh of points above the surface and saves the input files
! (CP2K only currently) in a directory structure.
!.............................................................................
  use real8
  use tetrag1
  implicit none
  integer :: i,NGX_,NGY_,NGZ_,ix,iy,iz,lx,ly,lz,nkp,l0seed1,j,ll,l0,anum,anum1,anum2
  character :: answer*1,chx*4,chy*4,chz*4,dir*17,cha2*2
  real*8 :: zup,zdw,slab,zupdw,middle,r_He(3),vec1(2),vec2(2),Cp(3),Zupper,vec3(3)
  real(8) :: kpoint(Nkpoint,3),v1,v2,v12
  real*8,parameter :: tiny=0.0001
  logical :: err,listat(N0LT),YES_Lv,periodic
  character(len=FLEN) :: seed1
  character :: Which_Code*6,YES_xyz*4,xxx*10,yyy*10,zzz*10
  character*12 :: angstr='<AtomNumber>'

!..... check if this is the slab geonmetry
  
  slab=abs(AJ(3,1)) + abs(AJ(3,2)) + abs(AJ(1,3)) + abs(AJ(2,3))
  if(slab.ne.0.0) then
     write(*,*)'CANNOT PROCEED: this is NOT a slab geometry!'
     write(*,*)'>>>>>>>>>>>>> Make sure: <<<<<<<<<<<<<<'
     write(*,*)'  (i) the 3rd lattice vector is along Z'
     write(*,*)' (ii) the 1st and 2nd lattice vectors are within XY plane'
     write(*,*)'Press ENTER when ready'
     read(*,*)
     return
  end if
  
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'WARNING: slab atoms are conitnuously given along the Z axis.'
  write(*,*)'         Correct in the M menu if this is not the case first.'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
  
!______ bracket the atoms of the slab on the Z axis

  zup=-1.0e10  ; zdw=1.0e10
  do i=1,ITI
     if(TI(3,i).gt.zup) zup=TI(3,i)
     if(TI(3,i).lt.zdw) zdw=TI(3,i)
  end do
  zupdw=zdw+AJ(3,3)
  middle = zup+0.5*(zupdw-zup)
!
!========================================================================
!===================== MENU starts here =================================
!========================================================================
!
  periodic=.false.
  vec1(1)=AJ(1,1) ; vec1(2)=AJ(1,2)
  vec2(1)=AJ(2,1) ; vec2(2)=AJ(2,2)
  vec3(1)=0.0; vec3(2)=0.0 ; vec3(3)=middle-zup
  Cp(1)=0.0 ; Cp(2)=0.0 ; Cp(3)=Zup
  NGX_=3 ; NGY_=3; NGZ_=3
  Zupper=middle ; YES_xyz='Xmol' ; nkp=0 ; YES_Lv=.true.
  r_He=TI(1:3,ITI)
  
21 write(*,*)'/---------------------------------------------------\\'
  write(*,*)'|......................  MENU .......................|'
  write(*,*)'\\---------------------------------------------------/'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,'(a)') '......... CURRENT lattice vectors ...'
  do i=1,3
     write(*,'(a,i1,a,3(f10.5,x))') '[',i,'] ',(AJ(i,j),j=1,3)
  end do
  write(*,'(a,5x,20(a2,x))') '>>> Species: ',(Species(i),i=1,Nsp)
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)'>>>> The slab is found between ',zdw,' and ',zup,' (in A)'
  write(*,*)'>>>> The middle of the vacuum gap = ',middle
  write(*,*)'>>>> The allowed range of Z values = [ ',zup,',',middle,' ]'
  write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
  write(*,*)
  write(*,'(a,3(f10.5,a,x),a)') &
       ' Cp. The corner point of the box: [',Cp(1),',',Cp(2),',',Cp(3),' ]'
  write(*,'(a,f10.5)') ' Up. Upper Z point of the box: ',Zupper
  write(*,'(2(a,f10.5),a,)') &
       ' Vp. The 1st vector along the box (within XY): (',vec1(1),',',vec1(2),')'
  write(*,'(2(a,f10.5),a,)') &
       '     The 2nd vector along the box (within XY): (',vec2(1),',',vec2(2),')'
  vec3(3)=Zupper-Cp(3)
  write(*,'(3(a,f10.5),a)') &
       '     The 3rd vector (perpendicular to XY) is   (',vec3(1),',',vec3(2),',',vec3(3),')'
  write(*,'(a,3(i5,a))')  &
              ' Gr. Grid along the 1st, 2nd and 3rd vectors: ',NGX_,',',NGY_,',',NGZ_
  if(periodic) then
     write(*,'(a)')  '  P. The STM box CAN be periodically extended within the plane'
  else
     write(*,'(a)')  '  P. The STM box CANNOT be periodically extended within the plane'
  end if
  write(*,'(a)')  ' Co. Show atomic positions '
  write(*,'(a)') '  S. Save the directory structure with all tip positions'
  if(CHIMERA) then
     if(YES_Lv) then
        write(*,'(a)')  ' Vs. Show lattice vectors and vectors defining the box'
     else
        write(*,'(a)')  ' Vs. Show only vectors defining the box'
     end if
  end if
  write(*,'(a)') ' An. [For input] Coordinates are specified in: '//angstr
  if(YES_Lv) then
     write(*,'(a)') ' Lv. Show lattice vectors - YES'
  else
     write(*,'(a)') ' Lv. Show lattice vectors - NO'
  end if 
  write(*,'(a)') '  Q. Quit.'
  write(*,*)
  write(*,*)'Specify the character and press ENTER ------->'
  read(*,'(a)',err=21) cha2  ; write(8,'(a)') cha2
  call right(cha2,2,l0)

![Vp].......... two in-plane vectors along the 1st & 2nd directions to define the box

  IF(cha2(l0:).eq.'Vp') THEN

8    write(*,*)'>>>>>>>>>> Two IN-PLANE VECTORS of the box <<<<<<<<<<<<<<'

     if(angstr.eq.'<AtomNumber>') then
5       write(*,*)'Give the atom at the beginning of both vectors:'
        read(*,*,err=5) anum
6       write(*,*)'Give the atom at the end of the 1st vector:'
        read(*,*,err=6) anum1
        if(anum.eq.anum1) go to 5
        vec1(1)=TI(1,anum1)-TI(1,anum) ; vec1(2)=TI(2,anum1)-TI(2,anum)
7       write(*,*)'Give the atom at the end of the 2nd vector:'
        read(*,*,err=7) anum2
        if(anum.eq.anum2 .or. anum1.eq.anum2) go to 7
        vec2(1)=TI(1,anum2)-TI(1,anum) ; vec2(2)=TI(2,anum2)-TI(2,anum)
     else
11      write(*,*)'Give 2 Cartesian compoenents (X,Y) of the 1st vector to define the box:'
        read(*,*,err=11) vec1(1),vec1(2)
        v1=sqrt(vec1(1)*vec1(1)+vec1(2)*vec1(2))
        if(v1.lt.tiny) go to 11
12      write(*,*)'Give 2 Cartesian compoenents (X,Y) of the 2nd vector to define the box:'
        read(*,*,err=12) vec2(1),vec2(2)
        v2=sqrt(vec2(1)*vec2(1)+vec2(2)*vec2(2))
        if(v2.lt.tiny) go to 12
!______________ check if the 2 vectors are colllinear        
        v12=vec1(1)*vec2(1)+vec1(2)*vec2(2)
        if(1.0-v12/(v1*v2) .lt. tiny) then
           write(*,*) 'ERROR! The two vectors are (nearly) collinear!'
           go to 8
        end if
     end if

![Cp].......... specify the corner point for the box

  ELSE IF(cha2(l0:).eq.'Cp') THEN

     write(*,*)'>>>>> Specify the corner point of the box. <<<<<'
     if(angstr.eq.'<AtomNumber>') then
9       write(*,*) &
             'Firstly, specify the X,Y cordinates of the corner point using atom number:'
        read(*,*) anum
        if(anum.lt.1 .or. anum.gt.ITI) go to 9
        Cp(1)=TI(1,anum) ; Cp(2)=TI(2,anum)
     else
10      write(*,*) &
             'Firstly, specify the X,Y cordinates of the corner point in Cartesian:'
        read(*,*) Cp(1),Cp(2)
     end if
13   write(*,'(2(a,f10.5),a)') 'Secondly, specify the Z. It must be within [',zup,',',middle,']'
     read(*,*,err=13) Cp(3)
     if(Cp(3).lt.zup .or. Cp(3).gt.middle) then
        write(*,*)'WARNING! the Z-compoenent is outside the Z-window!'
     end if
        
![Up].......... specify the z-upper point for the box

  ELSE IF(cha2(l0:).eq.'Up') THEN
14   write(*,*)'Specify Z of the upper point of the box within  [',zup,',',middle,']:'
     read(*,*,err=14) Zupper
     if(Zupper.lt.Cp(3) .or. Zupper.gt.middle) then
        write(*,*)'ERROR! Choose within the correct Z windows'
        go to 14
     end if

![P].......... whether the system can be periodically extended within the surface plane or not
!              This is the case if the vectors vec1, vec2 correspond to the primitive surface unit cell,
!              while the current vectors AJ(1,) and AJ(2,) are vectors extended fro them.     
     
  ELSE IF(cha2(l0:).eq.'P') THEN

     if(periodic) then
        periodic=.false.
     else
        periodic=.true.
     end if
     
![Gr].......... specify the grid

  ELSE IF(cha2(l0:).eq.'Gr') THEN
15   write(*,*)'Specify the grid along each vector of the box:'
     read(*,*,err=15) NGX_,NGY_,NGZ_
     if(NGX_.lt.2 .or. NGY_.lt.2 .or. NGZ_.lt.2) then
        write(*,*) 'The grid is not dense enough'
        go to 15
     else if(NGX_.gt.9999 .or. NGY_.gt.9999 .or. NGZ_.gt.9999) then
        write(*,*) 'The grid is too large, must be =< 9999'
        go to 15
     end if
     
![Vs]...... show lattice vectors & box vectors
     
  ELSE IF(cha2(l0:).eq.'Vs' .and. CHIMERA) THEN
        
     open(35,file='vectors.vct',form='formatted',status='unknown')
     if(YES_Lv) then 
        write(35,*) '6'
        do i=1,3
           write(35,*) (AJ(i,j),j=1,3)
        end do
     else
        write(35,*) '3'
     end if
     write(35,*) vec1(1),vec1(2),' 0.0'
     write(35,*) vec2(1),vec2(2),' 0.0'
     write(35,*) vec3(1),vec3(2),vec3(3)
     close(35)

![An]...... choose the way how the coordinates are given

  ELSE IF(cha2(l0:).eq.'An') THEN

     if(angstr.eq.'<Angstroms> ') then
        angstr='<AtomNumber>'
     else if(angstr.eq.'<AtomNumber>') then
        angstr='<Angstroms> '
     end if

![Lv]...... show lattice vectors in CHINERA or not

  ELSE IF(cha2(l0:).eq.'Lv') THEN

     if(YES_Lv) then
        YES_Lv=.false.
     else 
        YES_Lv=.true.
     end if

![S].......... Save 
        
  ELSE IF(cha2(l0:).eq.'S') THEN

!______________ choose the write/output format
        
     call ask_which_format(Which_Code,Which_Format2,seed2,l0seed2,'S')
     write(*,*)'>> The names of the input files in each directory = '//seed2(l0seed2:)
     if_call_which_format=.false.


!______ determine positions of the He atom, create the correct directory
!       structure and write the input file in each directory.
!       He atom is assumed the last in the list.

     do ix=0,NGX_
        call name_from_number(ix,chx,lx,err)
        do iy=0,NGY_
           call name_from_number(iy,chy,ly,err)
           do iz=0,NGZ_
              call name_from_number(iz,chz,lz,err)
              
              dir=chx(lx:)//'.'//chy(ly:)//'.'//chz(lz:)
              ll=2+(5-lx)+(5-ly)+(5-lz)
              write(*,*) '... creating directory '//dir(1:ll)
              call system('mkdir '//dir(1:ll))
              
              TI(1,ITI)= Cp(1) + ix*vec1(1)/NGX_ + iy*vec2(1)/NGY_
              TI(2,ITI)= Cp(2) + ix*vec1(2)/NGX_ + iy*vec2(2)/NGY_
              TI(3,ITI)= Cp(3) + iz*vec3(3)/NGZ_
                 
!_______________ create a new input file and put it into the correct directory
!                (can be used if the ionput file is read in without problems) 

              call write_kp(nkp,kpoint,'QUICKS',YES_xyz,.false.)
              
              write(*,'(a)') 'mv '//seed2(l0seed2:)//' '//dir(1:ll)//'/input.inp'
              call system('mv '//seed2(l0seed2:)//' '//dir(1:ll)//'/input.inp')
            
!______________ just write X,Y,Z of the He atom into the directory as well (will be
!               used to change the position of the He atom by the running script)
!               (must be used if the ionput file is read in with problems) 

              write(xxx,'(f10.5)') TI(1,ITI)
              write(yyy,'(f10.5)') TI(2,ITI)
              write(zzz,'(f10.5)') TI(3,ITI)
              write(*,'(a)') 'echo '//xxx//' '//yyy//' '//zzz//' > '//dir(1:ll)//'/xyz'
              call system('echo '//xxx//' '//yyy//' '//zzz//' > '//dir(1:ll)//'/xyz')
                 
           end do
        end do
     end do
        
!______________ save the file for lev00      

     open(18,file='for_lev00.dat')
     write(18,*) Cp ; write(18,*) vec1 ; write(18,*) vec2
     write(18,*) vec3 ; write(18,*) NGX_,NGY_,NGZ_
     if(periodic) then
        write(35,*) '1 periodic'
     else 
        write(35,*) '0 non-periodic'
     end if
     close(18)
      
![Co].... display atomic positions

  ELSE IF(cha2(l0:).eq.'Co') THEN
     listat=.false.
     call show_atoms(listat)

![Q]...... quit

  ELSE IF(cha2(l0:).eq.'Q') THEN
      
!.......... return the original settings

     TI(1:3,ITI)=r_He
     if_call_which_format=.true.
     return
  ELSE
     write(*,*) 'Wrong! Try again!'
  END IF
  go to 21
     
!..................................................................................      
!............................. MENY ENDS ..........................................
!..................................................................................      
end subroutine EA_model_mesh






