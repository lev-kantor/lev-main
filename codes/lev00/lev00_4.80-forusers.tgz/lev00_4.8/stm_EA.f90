subroutine stm_EA(grid)
!.........................................................................
!   NOTE:  gnuplot is NOT working with CHIMERA !!!
!.........................................................................
!  This is a version of stm_TH() adapted for EA model (using another grid)  
!.........................................................................
use param ; use atoms ; use menu ; use breeding ; use eff_at
implicit none
real*8,parameter :: tiny=0.0001
real*8 :: grid(0:NGX_,0:NGY_,0:NGZ_),Zwn1,Zwn2,vv,s
real*8,dimension(3) :: Center=(/0.0,0.0,0.0/),Face=(/1.0,1.0,1.0/)
integer,dimension(3) :: ngrid=(/20,20,20/)
real*8,dimension(:) :: zgrid(0:NGZ_),fgrid(0:NGZ_)
real*8 :: Direct(3,3),da(3),vect(3,3),Bot,Top,corner(3),LDOS,Zmin,Zmax,Zdw,Zup,a,b,cc,c1,c2
real*8 :: y(3),dirv(3,3),recv(3,3),Recip(3,3),Direc(3,3),ZLD,ILD,x1(3)
integer nChrg,j,i,i1,i2,i3,nat,j1,Nltrp,k,i10,i20
logical :: Yes_Do,Yes_Curr,Yes_XY,Yes_Spctr,Yes_Empty_lines,Yes_exp,Yes_Fz,Yes_Const_Curr
logical :: Yes_square_ext
character cha2*2,Title*50,title_pl(8)*7,cha1
character Line*200
integer LinEnd(100),LinPos(100),NumLin,iErr,idw,iup
integer L_ext
real*8,allocatable,dimension(:) :: dos,zz
data Title/'                                                  '/
real*8,allocatable,dimension(:,:) :: LatPos
real*8,allocatable,dimension(:)   :: Zldos
real*8 Imax,x(3),denval,z1,z2,zz1,R(3),R1(3),R2(3),spctr(8)

!.........(1) Analyse the current profiles along Z for every X,Y to determine 
!             the bottom value of Z so that the current would only decay to 0
!             from that value for ALL (X,Y).
!.........(2) Also, we find the minimum of all maximum values of the current
!             to set the current window between 0 and that value (Imax)

     do i3=0,NGZ_
        zgrid(i3)=Cp(3) + i3 * vec3(3)/NGZ_
        if(dim_type.eq.1) fgrid(i3)=grid(0,0,i3)
     end do
     Top=Cp(3)+vec3(3)
     Bot=Cp(3)
     Imax=1.0e10
     do i1=0,NGX_  
        do i2=0,NGY_
           cc=0.0 ; zmin=Cp(3)
           do i3=NGZ_,0,-1
              if(grid(i1,i2,i3).gt.cc) then
                 cc=grid(i1,i2,i3)
              else
                 zmin=zgrid(i3+1)
                 if(cc.lt.Imax) Imax=cc
                 exit
              end if
           end do
           if(zmin.eq.Cp(3)) Imax=cc
           write(*,'(2(a,i3),2(a,f10.5))') '(i1,i2)=(',i1,',',i2,') => max Current = ',cc,' at z = ',zmin
           if(zmin.gt.Bot) Bot=zmin
        end do
     end do

!....................................................................................
!    The box within which the STM image is calculated (viewed) MUST be the same as 
!    the STM box from the EA model (where the current is available) if the system 
!    is NOT periodic. Then the viewing box is set identical to the STM box.
!....................................................................................
!    If the system IS periodic (2D or 3D only), then the box for viewing can be
!    modified.
!....................................................................................
!    reciprocal vectors to Direct(No,xyz) are Recip(No,xyz)
     Direct(1,1:3)=vec1 ;  Direct(2,1:3)=vec2 ; Direct(3,1:3)=vec3 
     Direc=Direct
     call bastr_any_dim(Direc,Recip,vv,0,dim_type)
     Direct(3,3)=Top-Bot
     
!............ small vectors due to each current cell on the grid     
!             reciprocal vectors to dirv(No,xyz) are recv(No,xyz)

     if(dim_type.eq.1) then
        dirv(3,1:3)=vec3/NGZ_ ; ngrid(1)=0 ; ngrid(2)=0
     else if(dim_type.eq.2) then
        dirv(1,1:3)=vec1/NGX_ ; dirv(2,1:3)=vec2/NGY_  ; ngrid(3)=0
     else if(dim_type.eq.3) then
        dirv(1,1:3)=vec1/NGX_ ; dirv(2,1:3)=vec2/NGY_ ; dirv(3,1:3)=vec3/NGZ_
     end if
     call bastr_any_dim(dirv,recv,vv,0,dim_type)
!
     Corner(1:2)=Cp(1:2) ; Corner(3)=Bot
     Center(1:3)=Corner(1:3)+0.5*(Direct(1,1:3)+Direct(2,1:3))
        
!....................................................................................

!................. initial setting for the Z-window for atoms to be shown in [Sh]
     Zmax=0.0 ; Zmin=-2.0 
     Zwn1=0.0 ; Zwn2=10.0

!................. initialisation for spectrosopy
     Nltrp=1 ; allocate(LatPos(3,Nltrp))
     
     if(dim_type.eq.1) then
        LatPos(1:3,1)=Cp(1:3) ; title_pl(1)='point 1'
     end if
!................. start the main menu
!
     Yes_Do=.false.
     Yes_Curr=.false. ; if(dim_type.eq.2) Yes_Curr=.true.
     Yes_XY=.false.  ; if(dim_type.eq.1) Yes_XY=.true.
     Yes_Spctr=.false. ; Yes_Empty_lines=.true. ; Yes_exp=.false. ; Yes_Fz=.true.
     Yes_Const_Curr=.true. ; if(dim_type.eq.2) Yes_Const_Curr=.false.
     Yes_square_ext=.false.
      
1     write(*,*) 
      write(*,*)'............MENU for STM/EA ...........................'
      write(*,*)'======================================================='
      write(*,*)'***| Surface MUST be perpendicular to the Z axis ! |***'
      write(*,*)'***|  Change appropriate parameters if necessary   |***'
      write(*,*)'======================================================='
      if(dim_type.eq.1) then
         write(*,*)'======  This is 1D (vertical spectroscopy) case ======='
      else if(dim_type.eq.2) then
         write(*,*)'======      This is 2D (constant height) case   ======='
      else 
         write(*,*)'======  This is 3D (all options available) case ======='
      end if
      write(*,*)'======================================================='

      write(*,'(a)') '---------- E A - S T M   i m a g e  -------------'
      write(*,*)'>>>> The bottom of the preview region = ',Bot,' (in A) <<<<'
      write(*,*)'>>>> The top of the preview region    = ',Top,' (in A) <<<<'
      write(*,*)'>>>> The window of currents across all (X,Y) is: [0.0,',Imax,'] <<<<'
      if(iperiodic.eq.1) then
         write(*,'(a,2(f10.5,a))') '  1. Surface area center is at: (', &
              Center(1),',',Center(2),')'
         write(*,'(a)') '  D. Directions 1 & 2 of the surface preview area:'
         write(*,'(10x,a,2(f10.5,a))') '[1]   <',Direct(1,1),',',Direct(1,2),'  >'
         write(*,'(10x,a,2(f10.5,a))') '[2]   <',Direct(2,1),',',Direct(2,2),'  >'
         corner(1:2)=Center(1:2)-0.5*(Direct(1,1:2)+Direct(2,1:2))
      else
         write(*,'(a,2(f10.5,a))') '      Surface area center is at: (', &
                Center(1),',',Center(2),')'
         write(*,'(a)')'      Directions of the surface area are fixed along:'
         write(*,'(10x,a,2(f10.5,a))') '[1]   <',Direct(1,1),',',Direct(1,2),'  >'
         write(*,'(10x,a,2(f10.5,a))') '[2]   <',Direct(2,1),',',Direct(2,2),'  >'
      end if

      da=0.0
      do i=1,3
         face(i)=sqrt( Direct(i,1)**2+Direct(i,2)**2+Direct(i,3)**2 )
      end do
      if(dim_type.eq.1) then
         write(*,'(a,3(1x,i3))') '   4. The grid along the vertical line: ',ngrid(3)
         nChrg=ngrid(3)
         da(3)=face(3)/ngrid(3) ; vect(3,1:3)=Direct(3,1:3)/ngrid(3)
      else if(dim_type.eq.2) then
         write(*,'(a,3(1x,i3))') &
           '   4. The grid in the box in 2 XY directions: ',(ngrid(i),i=1,2)
         nChrg=ngrid(1)*ngrid(2)
         da(1)=face(1)/ngrid(1) ; vect(1,1:3)=Direct(1,1:3)/ngrid(1)
         da(2)=face(2)/ngrid(2) ; vect(2,1:3)=Direct(2,1:3)/ngrid(2)
      else
         write(*,'(a,3(1x,i3))') &
           '   4. The grid in the box in 3 directions: ',(ngrid(i),i=1,3)
         nChrg=ngrid(1)*ngrid(2)*ngrid(3)
         da(1)=face(1)/ngrid(1) ; vect(1,1:3)=Direct(1,1:3)/ngrid(1)
         da(2)=face(2)/ngrid(2) ; vect(2,1:3)=Direct(2,1:3)/ngrid(2)
         da(3)=face(3)/ngrid(3) ; vect(3,1:3)=Direct(3,1:3)/ngrid(3)
      end if
      
      write(*,'(5x,a,i10)')'>>>> total number of grid points = ',nChrg

      write(*,'(5x,a,3(1x,f10.5))') &
           '>>>> the starting point (corner) of the box is at ',(corner(i),i=1,3)

      write(*,'(5x,a,3(x,f10.5))')'>>>> steps along 3 directions are ', &
           (da(i),i=1,3)
      if(dim_type.ne.1) then
         if(Yes_Const_Curr) then
            write(*,'(a,f12.7)') '  Md. Image mode = CONSTANT CURRENT'
            if(Yes_Curr) then
               write(*,'(a,f12.7)') '   I. Value of CURRENT within the window = ',LDOS
               if(.not.Yes_Do) then
                  write(*,'(a)') '  Ci. Calculate IMAGE of constant CURRENT topography'
               else
                  write(*,'(a)') '  Ci. Calculate constant CURRENT topography - DONE!'
               end if
            else
               write(*,'(a)') '   I. Value of LDOS within the window = UNDERFINED'
            end if
         else
            if(dim_type.eq.2) then
               write(*,'(a,f12.7)') '      Image mode = CONSTANT HEIGHT'
               ZLD=Cp(3)
               write(*,'(a,f12.7)') '      Value of Z within the window = ',ZLD
            else
               write(*,'(a,f12.7)') '  Md. Image mode = CONSTANT HEIGHT'
            end if
            if(Yes_Curr) then
               write(*,'(a,f10.5)') '   I. Value of Z within the window = ',ZLD
               if(.not.Yes_Do) then
                  write(*,'(a)') '  Ci. Calculate IMAGE of constant Z topography'
               else
                  write(*,'(a)') '  Ci. Calculate constant Z topography - DONE!'
               end if
            else
               write(*,'(a)') '   I. Value of Z within the window = UNDERFINED'
            end if
         end if
         if(Yes_Do) then
            write(*,'(a)') '  Vi. PREVIEW the image' 
            write(*,'(a)') '  Ps. Create the Postscript of the image' 
         end if
         write(*,'(a)') '  Sh. SHOW (X,Y)-coordinates of surface atoms within the PLOT'
      end if
      
      write(*,'(a)') '------------ S p e c t r o s c o p y ------------'
      write(*,'(a,i3)') '      Number of points along Z axis = ',ngrid(3)

      if(dim_type.ne.2) then
         if(Yes_XY) then
            if(dim_type.eq.1) then
               write(*,'(a)') '      Lateral points - KNOWN'
            else
               write(*,'(a)') '  XY. Lateral points - KNOWN'
            end if
            write(*,'(a)') '  Sl. Show Lateral points'
            if(Yes_Spctr) then
               write(*,'(a)') '  Cs. Calculate spectroscopy curves - DONE!'
               write(*,'(a)') '  Vs. PREVIEW all spectroscopy curves' 
            else
               write(*,'(a)') '  Cs. Calculate spectroscopy curves'
            end if
         else
            write(*,'(a,i3)') '  Nl. Number of lateral points for 1D spectoscopy plots = ',Nltrp
            write(*,'(a,i3)') '  XY. Specify lateral points - yet UNDEFINED'
         end if
      end if
      
      if(CHIMERA) then
         write(*,*)    '---------- v i s u a l i a s i o n   s e t t i n g s ---------'
         L_ext=(N1-M1+1)*(N2-M2+1)*(N3-M3+1)
         write(*,'(a,3(i2,a,i2,a),i3,a,i5)') &
          '>>> Box: [',M1,'...',N1,'] x [', M2,'...',N2,'] x [', &
                M3,'...',N3,'], ext = ',L_ext,', # of atoms= ',NIONS*L_ext
         write(*,*)    '  Bb. Breeding box size'
         write(*,*)    '  B0. Nullify the breeding box'
      end if

      write(*,'(a)') '-------  G e n e r a l  s e t t i n g s ---------'

      if(dim_type.ne.2) then
         if(Yes_exp) then
            write(*,'(a)') '  Ex. Exponential fit  for ALL Z values'
         else
            write(*,'(a)') '  Ex. Exponential fit ONLY for large Z values'
         end if
      end if
      
      write(*,'(a)') '  An. Coordinates are specified in: '//angstr
      write(*,'(a)') '  Co. Show current atomic positions in fractional/Cartesian'
      write(*,'(2(a,f10.5),a)') &
           '  zW. Z-window to SHOW (X,Y)-positions of atoms: [ ',Zmin,',',Zmax,' ]'

      if(.not.Yes_Fz) then
         write(*,'(a)')'  Zf. Z-boundaried for the 3D plot CAN be changed'
         write(*,'(2(a,f10.5),a)') &
              '  Fz. Z-window in 3D plot [ ',Zwn1,',',Zwn2,' ]'
      else
         write(*,'(a)')'  Zf. Z-boundaried for the 3D plot are AUTOMATIC'
      end if
         
      if(Yes_Empty_lines) then
         write(*,'(a)')'  El. Add empty lines in the constant LDOS file <--- YES'
      else
         write(*,'(a)')'  El. Add empty lines in the constant LDOS file <--- NO'
      end if
      if(type_prv.eq.'2d-old-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 2D + contours'
         write(*,*) ' cl. PREVIEW/Ps: number of contour levels = ',nclasses
      else if(type_prv.eq.'2d-col-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 2D + colours'
      else if(type_prv.eq.'2d-gray') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 2D + gray palette'
      else if(type_prv.eq.'3d-old-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D + grid lines'
      else if(type_prv.eq.'3d-c-2d') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D + 2D underneath; in colour'
      else if(type_prv.eq.'3d-g-2d') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D + 2D underneath; in gray'
      else if(type_prv.eq.'3d-col-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D; in colour'
      else if(type_prv.eq.'3d-col-') then
         write(*,'(a,a7)') '  3D. PREVIEW/Ps type: 3D; in colour'
     end if
     if(Yes_square_ext) then
        write(*,'(a)') '  IE. Extend the image to the full square: YES'
     else
        write(*,'(a)') '  IE. Extend the image to the full square: NO'
     end if
     
     write(*,'(a)') '------------ C a l c u l a t o r ----------------'
     write(*,'(a)') '  cT. Centre of a triangle of points/atoms'
     write(*,'(a)') '  mD. Middle distance between two points/atoms'
     write(*,'(a)') '------- L e a v e   t h e   m e n u -------------'
     write(*,'(a)')'   Q. Return to the previous menu'
     write(*,*)
     write(*,*)'------> Choose the item and press ENTER:'
     read (*,'(a)',err=1) cha2
!
![1]__________ give the central point
!
     IF(trim(cha2).eq.'1' .and. iperiodic.eq.1) THEN
        write(*,*)'Give the center of your surface area :'
        write(*,*)'*** Z coordinate will be ignored ***'
        call givepoint(Center(1),Center(2),Center(3),angstr)
        Yes_Do=.false.
!
![D]__________ choose directions of the preview area
!
     ELSE IF(trim(cha2).eq.'D' .and. iperiodic.eq.1) THEN
12      WRITE(*,'(a)')'Give two directions (via X,Y each) of the surface area (in A)'
        read(*,*,err=12) Direct(1,1:2)
        c1=Direct(1,1)*Direct(1,1)+Direct(1,2)*Direct(1,2)
        if(c1.lt.tiny) go to 12
        read(*,*,err=12) Direct(2,1:2)
        c2=Direct(2,1)*Direct(2,1)+Direct(2,2)*Direct(2,2)
        if(c2.lt.tiny) go to 12
        cc=Direct(1,1)*Direct(2,1)+Direct(1,2)*Direct(2,2)
        if(1.0-cc/(c1*c2) .lt. tiny) go to 12
        Yes_Do=.false.
!
![4]__________ choose the grid in the box
!
     ELSE IF(trim(cha2).eq.'4') THEN

        ngrid=0
        if(dim_type.eq.1) then
11         write(*,'(a)') 'Specify the number of grid points along the Z direction:'
           read(*,*,err=11) ngrid(3)
           if(ngrid(3).lt.1) go to 11
        else if(dim_type.eq.2) then
14         write(*,'(a)') 'Specify the number of grid points within XY along 2 directions:'
           read(*,*,err=14) (ngrid(i),i=1,2)
           if(ngrid(1).lt.1 .or. ngrid(2).lt.1) go to 14
        else
13         write(*,'(a)') 'Specify the number of grid points in all 3 directions:'
           read(*,*,err=13) (ngrid(i),i=1,3)
           if(ngrid(1).lt.1 .or. ngrid(2).lt.1 .or.ngrid(3).lt.1) go to 13
        end if
        Yes_Do=.false. ; Yes_exp=.false.
!
![Md]__________ choose the image mode
!
     ELSE IF(trim(cha2).eq.'Md' .and. dim_type.eq.3) THEN

        if(Yes_Const_Curr) then
           Yes_Const_Curr=.false.
        else
           Yes_Const_Curr=.true.
        end if
        Yes_Do=.false. ; Yes_Curr=.false.
!
![I]__________ choose LDOS / ZLD value within the window
!
     ELSE IF(trim(cha2).eq.'I' .and. dim_type.eq.3) THEN

21      if(Yes_Const_Curr) then
           write(*,'(2(a,f10.5),a)') 'Specify the LDOS value within [ 0.0 ',Imax,' ]'
           read(*,*,err=21) LDOS
           if(LDOS.lt.0.0 .or. LDOS.gt.Imax) then
              write(*,*)'ERROR! The current should be within the specified range!'
              write(*,*)'Hit ENTER when done ...' ; read(*,*)
              Yes_Curr=.false.
           else
              Yes_Curr=.true. ; Yes_Do=.false.
           end if
        else
           write(*,'(2(a,f10.5),a)') 'Specify the Z value within [ ',Bot,',',Top,' ] A'
           read(*,*,err=21) ZLD
           if(ZLD.lt.Bot .or. ZLD.gt.Top) then
              write(*,*)'ERROR! The Z should be within the specified range!'
              write(*,*)'Hit ENTER when done ...' ; read(*,*)
              Yes_Curr=.false.
           else
              Yes_Curr=.true. ; Yes_Do=.false.
           end if
        end if
!
![Ci]__________ calculate the current or Z topography
!
     ELSE IF(trim(cha2).eq.'Ci' .and. Yes_Curr .and. dim_type.ne.1) THEN

        allocate(Zldos(0:ngrid(3))) ; allocate(zz(0:ngrid(3))) 
        write(*,'(a)') 'Opening the file for the constant LDOS ....'
        open(31,file='ldos.dat',form='formatted',status='unknown')

        if(Yes_Fz) then
           Zwn1=1.0d10 ; Zwn2=-1.0d10
        end if

!_____________ if Yes_square_ext=.true., extend the image

        i10=0 ; i20=0
        if(Yes_square_ext) then
           i10=-ngrid(1) ; i20=-ngrid(2)
        end if
        
        DO i1=i10,ngrid(1)
           DO i2=i20,ngrid(2)

!__________________ get all current values (Zldos) along the z for these i1,i2;

              do i3=0,ngrid(3)

!_________________________ Cartesian position of the grid point in the box
                 x(1)= abs(i1)*vect(1,1)+abs(i2)*vect(2,1)+i3*vect(3,1)+corner(1)
                 x(2)= abs(i1)*vect(1,2)+abs(i2)*vect(2,2)+i3*vect(3,2)+corner(2)
                 x(3)= abs(i1)*vect(1,3)+abs(i2)*vect(2,3)+i3*vect(3,3)+corner(3)
                 
!_________________________ position within the original STM box where the current is available
                 y=x-Cp

!_________________________ reduce into the STM box and interpolate                    

                 if(iperiodic.eq.1) call reducn_2d(y,Direc,Recip)
                 call interpolate_EA(y,recv,denval,grid)

                 Zldos(i3)=denval ; zz(i3)=x(3)
              end do

              x(1)= i1*vect(1,1)+i2*vect(2,1)+corner(1)-Center(1)
              x(2)= i1*vect(1,2)+i2*vect(2,2)+corner(2)-Center(2)

              if(Yes_Const_Curr) then
!_________________________ determine the height zz1 corresponding to the given value of the 
!                          current LDOS
!_________________________ do the exponential fit for only large z values

                 if(.not. Yes_Exp) then
                    if(LDOS.gt.Zldos(ngrid(3))) then
                       do i3=0,ngrid(3)-1
                          z1=i1*vect(1,3)+i2*vect(2,3)+i3*vect(3,3)+corner(3)
                          if( LDOS.ge.Zldos(i3+1) .and. LDOS.lt.Zldos(i3) ) then
                             z2=i1*vect(1,3)+i2*vect(2,3)+(i3+1)*vect(3,3)+corner(3)
                             zz1=z1+(LDOS-Zldos(i3))*(z2-z1)/(Zldos(i3+1)-Zldos(i3))
                             exit
                          end if
                       end do
                    else  
                       call exp_interpolate(Zldos,zz,ngrid(3),a,b)
                       zz1=-log(LDOS/a)/b                  
                    end if
                 else
                    call exp_interpolate(Zldos,zz,ngrid(3),a,b)
                    zz1=-log(LDOS/a)/b                  
                 end if
                 write(31,'(3(e20.8,x))') x(1),x(2),zz1
                 if(Yes_Fz) then
                    if(zz1.lt.Zwn1) Zwn1=zz1
                    if(zz1.gt.Zwn2) Zwn2=zz1
                 end if

              else
!_________________________ determine the current ILD corresponding to the given value of Z 
!_________________________ do the exponential fit for only large z values

                 if(dim_type.eq.3) then
                    if(.not. Yes_Exp) then
                       if(ZLD.lt.zz(ngrid(3))) then
                          do i3=0,ngrid(3)-1
                             z1=i1*vect(1,3)+i2*vect(2,3)+i3*vect(3,3)+corner(3)
                             if( ZLD.le.zz(i3+1) .and. ZLD.gt.zz(i3) ) then
                                z2=i1*vect(1,3)+i2*vect(2,3)+(i3+1)*vect(3,3)+corner(3)
                                ILD=ZLdos(i3)+(Zldos(i3+1)-Zldos(i3))/(z2-z1)*(ZLD-z1)
                                exit
                             end if
                          end do
                       else  
                          call exp_interpolate(Zldos,zz,ngrid(3),a,b)
                          ILD=a*exp(-b*ZLD)
                       end if
                    else
                       call exp_interpolate(Zldos,zz,ngrid(3),a,b)
                       ILD=a*exp(-b*ZLD)
                    end if
                 else
                    ILD=Zldos(0)
                 end if
                 write(31,'(3(e20.8,x))') x(1),x(2),ILD
                 if(Yes_Fz) then
                    if(ILD.lt.Zwn1) Zwn1=ILD
                    if(ILD.gt.Zwn2) Zwn2=ILD
                 end if
              end if
           END DO
           if(Yes_Empty_lines) write(31,*)
        END DO

        close (31)
        write(*,*)'Done! The file <ldos.dat> created!'
        write(*,'(2(a,f10.5),a)')'... Z boundaries are: [ ',Zwn1,',',Zwn2,' ]'
        deallocate(Zldos) ; deallocate(zz)
        Yes_Do=.true.
!
![Vi]__________ preview LDOS image
!
     ELSE IF(trim(cha2).eq.'Vi' .and. Yes_Do) THEN
        if(Yes_Const_Curr) then
           call Plot3dz('ldos.dat',8,Title, &
              'X-coordinate (A)    ','Y-coordinate (A)    ', &
              'Z-coordinate        ','Screen', 33,nclasses,type_prv,Zwn1,Zwn2)
        else
           call Plot3dz('ldos.dat',8,Title, &
              'X-coordinate (A)    ','Y-coordinate (A)    ', &
              'Current             ','Screen', 33,nclasses,type_prv,Zwn1,Zwn2)
        end if
!
![Ps]__________ create a Postscript file for the LDOS
!
     ELSE IF(trim(cha2).eq.'Ps' .and. Yes_Do) THEN
        if(Yes_Const_Curr) then
           call Plot3d('ldos.dat',8,Title, &
                'X-coordinate (A)    ','Y-coordinate (A)    ', &
                'Z-coordinate        ','Postsc', 33,nclasses,type_prv)
        else
           call Plot3d('ldos.dat',8,Title, &
                'X-coordinate (A)    ','Y-coordinate (A)    ', &
                'Current             ','Postsc', 33,nclasses,type_prv)
        end if
        write(*,*)'... Postscript file <ldos.dat.ps> has been created'
!
![Sh]__________ show atomic positions via their X,Y coordinates on the PLOT [V];
!               only atoms within the specified Z-window [Zmin,Zmax] are given 
!
     ELSE IF(trim(cha2).eq.'Sh') THEN
        write(*,'(a)')'*****************************************************'
        write(*,'(a)')'*** Only atoms within the Z-window are shown.     ***'
        write(*,'(a)')'*** Only atoms within the surface area are shown. ***'
        write(*,'(2(a,f10.5),a)') &
             '*** Z-window = [',Zmin,',',Zmax,']            ***'
        write(*,*)    '*****************************************************'
        nat=0

        do i=1,NSPEC
           write(*,'(3a,i5)')'.... Species <',Species(i),'> ......> ',i
           write(*,'(a)')' Tot   Sp#      |-X-in-PLOT-| |-Y-in-PLOT-| [--actual-Z-]'
           do j=1,NspN(i)
              nat=nat+1
              if(TI(3,nat).ge.Zmin .and. TI(3,nat).le.Zmax) then
                 x(1:2)=TI(1:2,nat)-Center(1:2)
!                 write(*,*) nat,x(1:2),TI(1:3,nat)
                 if(abs(x(1)).le.0.6*Face(1) .and. abs(x(2)).le.0.6*Face(2)) then 
                    write(*,'(2(x,i5),2(4x,f10.5),2x,a,f10.5,a)') &
                         nat,j,(x(j1),j1=1,2),'  [',TI(3,nat),' ]'
                 end if
              end if
           end do
        end do
        write(*,*)'Hit ENTER when done ...' ; read(*,*)
!
![Nl]__________ number of lateral points for spectroscopy
!
     ELSE IF(trim(cha2).eq.'Nl' .and. dim_type.eq.3) THEN
        deallocate(LatPos)
69      write(*,*)'Specify number of lateral points for 1D plots (<10):'
        read(*,*,err=69) Nltrp
        if(Nltrp.lt.1 .or. Nltrp.gt.8) go to 69
        allocate(LatPos(3,Nltrp)) 
        Yes_Spctr=.false. ; Yes_XY=.false.
!
![XY]__________ specify lateral points for spectroscopy
!
     ELSE IF(trim(cha2).eq.'XY' .and. dim_type.eq.3) THEN
        do i=1,Nltrp
           if(iperiodic.eq.0) then
              write(*,'(a)')      ' Specify  *** within the STM box *** X, Y, X'
              write(*,'(a,i2,a)') ' the lateral point [',i,'] (only X,Y are kept):'
           else
              write(*,'(a,i2,a)') &
                   ' Specify X, Y, X the lateral point [',i,'] (only X,Y are kept):'
           end if
           call givepoint(LatPos(1,i),LatPos(2,i),LatPos(3,i),angstr)
           if(iperiodic.eq.0) then
              do j=1,3
                 x(j)=LatPos(1,i)*Recip(j,1)+LatPos(2,i)*Recip(j,2)+LatPos(3,i)*Recip(j,3)
                 if(x(j).lt.0.0 .or. x(j).gt.1.0) then
                    write(*,*)'ERROR: the point must be within the STM box!'
                    go to 1
                 end if
              end do
           end if
           write(cha1,'(i1)') i
           title_pl(i)='point '//cha1
        end do
        Yes_XY=.true. ;  Yes_Spctr=.false.
        
!
![Sl]__________ show the lateral points for spectroscopy
!
     ELSE IF(trim(cha2).eq.'Sl' .and. Yes_XY .and. dim_type.ne.2) THEN
        write(*,'(a)')' #  --actual-X- --actual-Y- |  X-in-2D-PLOT Y-in-2D-PLOT'
        do i=1,Nltrp
           write(*,'(i2,2(x,f10.5),3x,a,2(x,f10.5))') &
                i,LatPos(1,i),LatPos(2,i),' | ',LatPos(1,i)-Center(1),LatPos(2,i)-Center(2)
        end do
        write(*,*)'Hit ENTER when done ...' ; read(*,*)
!
![Cs]__________ calculate spectroscopy curves
!
     ELSE IF(trim(cha2).eq.'Cs' .and. Yes_XY .and. dim_type.ne.2) THEN
        
        open(31,file='spectr.dat',form='formatted',status='unknown')

!____ because of the current algorithm based on "reciprocal vectors", the last point        
!     i3=ngrid(3) has to be excluded as it is equivalent to the 0 point (error)

        j=-1
        do i3=0,ngrid(3)
           x(3)=i3*vect(3,3)+corner(3)
           if(x(3).ge.Bot .and. x(3).le.Top) then
              j=j+1
              do i=1,Nltrp

!_________________________ interpolate
                 
                 if(dim_type.eq.1) then
                    call interplotate_1D(x(3),NGZ_,zgrid,fgrid,spctr(i))
                 else if(dim_type.eq.3) then
                    x(1)=LatPos(1,i) ; x(2)=LatPos(2,i)  
                    y=x-Cp
                    if(iperiodic.eq.1) call reducn_2d(y,Direc,Recip)
                    call interpolate_EA(y,recv,spctr(i),grid)
                 end if
              end do
              write(31,'(f10.5,9(x,e12.6))') x(3),(spctr(i),i=1,Nltrp)
              
           end if
        end do
        Yes_Spctr=.true.
!__________________________ check the exponential fit
        rewind(31)
        if(Yes_Exp) then
           open(32,file='spectr_exp.dat',form='formatted',status='unknown')
           allocate(dos(ngrid(3))) ; allocate(zz(ngrid(3))) 
           do i=1,Nltrp
              write(*,*)'===============> lateral point ',i,' <================='
              do i3=0,j
                 read(31,'(a)') line
                 call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
                 read(line(LinPos(1):LinEnd(1)),*) zz(i3+1)
                 read(line(LinPos(i+1):LinEnd(i+1)),*) dos(i3+1)
              end do
              call critical_points(dos,zz,ngrid(3)+1,Bot,Top,Zdw,Zup,idw,iup,a,b)
              write(*,'(2(a,f10.5),2(a,e20.8),a)')'[Zdw,Zup] = [',Zdw,',',Zup,'], fit=',a,'*exp(-',b,'*z)'
              write(32,*) a,b
              rewind(31)
           end do
           deallocate(dos) ; deallocate(zz)
           close(32)
        end if
        close(31) 
!
![Vs]__________ preview spectroscopy curves
!
     ELSE IF(trim(cha2).eq.'Vs' .and. Yes_Spctr .and. dim_type.ne.2) THEN
        if(.not.Yes_Exp) then
           call Plot_bunch(Nltrp,'spectr.dat',10,Title,title_pl, &
                'Z (A)               ',&
                'LDOS (arb. units)   ', 'Screen', 33)
        else
           call Plot_bunch_exp(Nltrp,'spectr.dat',10,Title,title_pl, &
                'Z (A)               ',&
                'LDOS (arb. units)   ', 'Screen', 33,32)
        end if
         
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
![Bb].... ask extensions for the breeding box

     ELSE IF(trim(cha2).eq.'Bb' .and. CHIMERA) THEN

!___________ ask extensions along the existing lattice vectors for the 
!            breeding box and update geom.xyz

        call ask_breeding_box(M1,N1,M2,N2,M3,N3)
        call create_xyz(M1,N1,M2,N2,M3,N3)

![B0].... nullify the extensions for the breeding box

     ELSE IF(trim(cha2).eq.'B0' .and. CHIMERA) THEN
        
        M1=0 ; N1=0 ; M2=0 ; N2=0 ; M3=0 ; N3=0
        call create_xyz(M1,N1,M2,N2,M3,N3)
         
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
![Ex]__________ set the exponential fit
!
     ELSE IF(trim(cha2).eq.'Ex' .and. dim_type.ne.2) THEN
         
        if(Yes_exp) then
           Yes_exp=.false.
        else
           Yes_exp=.true.
        end if
!
![An]__________ choose the way how the coordinates are given
!
     ELSE IF(trim(cha2).eq.'An') THEN
        if(angstr.eq.'<Fractional>') then
           angstr='<Angstroms> '
        else if(angstr.eq.'<Angstroms> ') then
           angstr='<AtomNumber>'
        else if(angstr.eq.'<AtomNumber>') then
           angstr='<Fractional>'
        end if
!
![Co].... display atomic positions
!
     ELSE IF(trim(cha2).eq.'Co') THEN
        call show_atoms()
!
![zW].... Z-window: z-values of atoms to be shown in option 'Sh'
!
     ELSE IF(trim(cha2).eq.'zW') THEN
76      write(*,*)'Specify the Z window of coordinates for atoms to be shown in [Sh].'
        write(*,*)'Give the low and high Z coordinates (A):'
        read(*,*,err=76) Zmin,Zmax
        if(Zmax-Zmin.lt.tiny) go to 76
!
![Fz].... Z-window for Vi plots
!
     ELSE IF(trim(cha2).eq.'Fz' .and. .not.Yes_Fz) THEN
77      write(*,*)'Specify the Z window for plotting with Vi:'
        write(*,*)'Give the low and high Z coordinates (A):'
        read(*,*,err=77) Zwn1,Zwn2
        if(Zwn2-Zwn1.lt.tiny) go to 77
!
![Zf].... Z-window for Vi plots is estanlished automatically or not
!
     ELSE IF(trim(cha2).eq.'Zf') THEN
        if(Yes_Fz) then
           Yes_Fz=.false.
        else
           yes_Fz=.true.
        end if
!
![El].... whether add or not empty lines when saving the constant LDOS plot 
!
     ELSE IF(trim(cha2).eq.'El') THEN
        if(Yes_Empty_lines) then
           Yes_Empty_lines=.false.
        else
           Yes_Empty_lines=.true.
        end if
!
![IE].... image extension: if the lattice is square, treat the current image as
!         as a quarter of the rectangular and extend to the whole of it        
!
     ELSE IF(trim(cha2).eq.'IE') THEN
        if(Yes_square_ext) then
           Yes_square_ext=.false.
        else
           Yes_square_ext=.true.
        end if
!
![cl].... number of contour levels for preview
!
     ELSE IF(trim(cha2).eq.'cl' .and. type_prv.eq.'2d-old-') THEN
75      write(*,*)'Specify the number of contour levels (2D only; must be > 2):'
        read(*,*,err=75) nclasses
        if(nclasses.lt.2) go to 75
!
![3D].... contour or 3-dimensional for preview
!
     ELSE IF(trim(cha2).eq.'3D') THEN
        if(type_prv.eq.'2d-old-') then
           type_prv='2d-col-'
        else if(type_prv.eq.'2d-col-') then
           type_prv='2d-gray'
        else if(type_prv.eq.'2d-gray') then
           type_prv='3d-old-'
        else if(type_prv.eq.'3d-old-') then
           type_prv='3d-c-2d'
        else if(type_prv.eq.'3d-c-2d') then
           type_prv='3d-g-2d-'
        else if(type_prv.eq.'3d-g-2d') then
           type_prv='3d-col-'
        else if(type_prv.eq.'3d-col-') then
           type_prv='2d-old-'
        end if
!
![cT]__________ centre of a triangle
!
     ELSE IF(trim(cha2).eq.'cT') THEN
        write(*,*)'Give the 1st point/atom:'
        call givepoint(R(1),R(2),R(3),angstr)
        write(*,*)'Give the 2nd point/atom:'
        call givepoint(R1(1),R1(2),R1(3),angstr)
        write(*,*)'Give the 3rd point/atom:'
        call givepoint(R2(1),R2(2),R2(3),angstr)
        x=(R+R1+R2)/3.0
        write(*,*)'The centre of the triangle is at:',(x(i),i=1,3)

!
![mD]__________ middle distance between two points
!
     ELSE IF(trim(cha2).eq.'mD') THEN
        write(*,*)'Give the 1st point/atom:'
        call givepoint(R(1),R(2),R(3),angstr)
        write(*,*)'Give the 2nd point/atom:'
        call givepoint(R1(1),R1(2),R1(3),angstr)
        x=(R+R1)/2.0
        write(*,*)'The middle distance between the points is at:', &
             (x(i),i=1,3)
!
![Q]__________ return to the previous menu
!
     ELSE IF(trim(cha2).eq.'Q') THEN
        deallocate(LatPos) 
        return
     ELSE
        write(*,*)'ERROR! Try again!'
     END IF
     go to 1
end subroutine stm_EA

subroutine exp_interpolate(dos,z,n,a,b)
!.................................................................
! exponential interpolation dos(z)=a*exp(-b*z) 
!.................................................................
  implicit none
  real*8 :: dos(0:n),z(0:n),a,b,x,y,x2,xy,w1
  integer :: n,j
  
!.......... least square fit

   x=0.0 ; y=0.0 ; x2=0.0 ; xy=0.0 ; w1=0
   do j=0,n
      w1=w1+1
      x=x+z(j) ; y=y+log(dos(j)) ; x2=x2+z(j)*z(j) ; xy=xy+z(j)*log(dos(j))
   end do
   a=exp( (y*x2-x*xy) / (w1*x2-x*x )  )
   b= -(w1*xy-x*y) / (w1*x2-x*x )  
  
end subroutine exp_interpolate
