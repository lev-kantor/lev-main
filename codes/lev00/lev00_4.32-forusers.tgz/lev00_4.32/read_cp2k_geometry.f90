subroutine read_cp2k_geom(Err)
!.................................................................
!  reading QUICKSTEP input file (a little bit simplified) 
!.................................................................
use param
use code
use atoms
use kpoints
use mendeleev
implicit none
character Line*200,cell_type*7,cha2*2,spec*2
integer LinEnd(100),LinPos(100),fix_type,is,nat,NumLin,i,k,i0,ni,iErr,j,i1,i2
logical good,Err
real*8 alpha,beta,gama,a0,b0,c0
logical,dimension(:,:),allocatable ::  fix_crd
real*8,dimension(:,:),allocatable ::  TI1
real*8,parameter :: pi=3.1415927
integer,dimension(:),allocatable  ::  isp

!........... some useful defaults
     alpha= 90.0 ; beta = 90.0 ; gama = 90.0 ;  cell_type='       ' 
     nat=0 ; fix_type=0 
     allocate(fix_crd(NIONS,3)) ; fix_crd=.false.
     allocate(isp(NIONS))

!........... open 'tmp.inp' file and read all data

     write(*,*) 'Reading from "tmp.inp" ...'
     open(14,file='tmp.inp',form='formatted',status='old',err=19)
1    read(14,'(a)',err=19,end=50) line

!_________ reading unit cell lattice vectors

     if(index(line,'&CELL').ne.0 .and. index(line,'&CELL_OPT').eq.0) then
5       call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
        if(iErr.ne.0) go to 19
        if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) then
           if(cell_type.eq.'abc_abg') then
              DIRC(1,1)=a0
              DIRC(2,1)=b0*cos(gama*pi/180.0)
              DIRC(2,2)=b0*sin(gama*pi/180.0)
              DIRC(3,1)=c0*cos(beta)
              DIRC(3,2)=c0*(cos(alpha)-cos(gama)*cos(beta))/sin(gama)
              DIRC(3,3)=sqrt(c0*c0-DIRC(3,1)**2-DIRC(3,2)**2)
           end if
           write(*,*)'========> Found lattice vectors: <=========='
           do i=1,3
              write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (DIRC(i,j),j=1,3)
           end do
           call bastr(DIRC,RECC,VOLC,1)
           call bastr(DIRC,BCELL,VOLC,0)
           go to 1
        else
           if(index(line(LinPos(1):LinEnd(1)),'A').ne.0) then
              read(line(LinPos(2):LinEnd(4)),*,err=19) (DIRC(1,j),j=1,3)
              if(cell_type.eq.'abc_abg') then
                 write(*,*)'ERROR: inconsistency in &CELL block' 
                 go to 19
              end if
              cell_type='vectors'
           else if(index(line(LinPos(1):LinEnd(1)),'B').ne.0) then
              read(line(LinPos(2):LinEnd(4)),*,err=19) (DIRC(2,j),j=1,3)
              if(cell_type.eq.'abc_abg') then
                 write(*,*)'ERROR: inconsistency in &CELL block'
                 go to 19
              end if
              cell_type='vectors'
           else if(index(line(LinPos(1):LinEnd(1)),'C').ne.0) then
              read(line(LinPos(2):LinEnd(4)),*,err=19) (DIRC(3,j),j=1,3)
              if(cell_type.eq.'abc_abg') then
                 write(*,*)'ERROR: inconsistency in &CELL block'
                 go to 19
              end if
              cell_type='vectors'
           else if(index(line(LinPos(1):LinEnd(1)),'ABC').ne.0) then
              read(line(LinPos(2):LinEnd(4)),*,err=19) a0,b0,c0
              if(cell_type.eq.'vectors') then
                 write(*,*)'ERROR: inconsistency in &CELL block'
                 go to 19
              end if
              cell_type='abc_abg'
           else if(index(line,'ALPHA_').ne.0) then
              read(line(LinPos(2):LinEnd(4)),*,err=19) alpha,beta,gama
              if(cell_type.eq.'vectors') then
                 write(*,*)'ERROR: inconsistency in &CELL block'
                 go to 19
              end if
              cell_type='abc_abg'
           end if
        end if
        go to 5

!_________ reading atomic positions and species: 
!         [ we assume UNITS=A and no SCALING at the moment ]
!         nat - counts atoms         
!         isp - counts different species

     else if(index(line,'&COORD').ne.0) then  
        do nat=1,NIONS
           call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
           if(iErr.ne.0) go to 19
           read(line(LinPos(2):LinEnd(4)),*)  (TI(j,nat),j=1,3)            
           read(line(LinPos(1):LinEnd(1)),*) spec
           if(LinEnd(1)-LinPos(1).eq.0) then
              cha2=' '//spec
           else
              cha2=spec
           end if
           do is=1,NSPEC
              if(cha2.eq.Species(is)) then
                 isp(nat)=is ; exit
              end if
           end do
        end do
 
!__________ reading contsraints (type 7 is the default)
!    fix_type = 0, 1, 2, 3, 4, 5,  6,   7  corresponds to the following fixed:
!              no  X  Y  Z  XY XZ  YZ  XYZ

     else if(index(line,'&FIXED_ATOMS').ne.0) then  
        if(NIONS.eq.0) then
           write(*,*)'FATAL! Wrong input file!'
           write(*,*)'FATAL! Put box &FORCE_EVAL before &MOTION'
           go to 19
        end if
        fix_type=0
15      call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
        if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) then
           go to 1
        else if(index(line(LinPos(1):LinEnd(1)),'COMPONENT').ne.0) then
           if(line(LinPos(2):LinEnd(2)).eq.'X') then
              fix_type=1
           else if(line(LinPos(2):LinEnd(2)).eq.'Y') then
              fix_type=2
           else if(line(LinPos(2):LinEnd(2)).eq.'Z') then
              fix_type=3
           else if(index(line(LinPos(2):LinEnd(2)),'X').ne.0 .and. &
                index(line(LinPos(2):LinEnd(2)),'Y').ne.0 .and.  &
                index(line(LinPos(2):LinEnd(2)),'Z').eq.0) then
              fix_type=4
           else if(index(line(LinPos(2):LinEnd(2)),'X').ne.0 .and. &
                index(line(LinPos(2):LinEnd(2)),'Y').eq.0 .and.  &
                index(line(LinPos(2):LinEnd(2)),'Z').ne.0) then
              fix_type=5
           else if(index(line(LinPos(2):LinEnd(2)),'X').eq.0 .and. &
                index(line(LinPos(2):LinEnd(2)),'Y').ne.0 .and.  &
                index(line(LinPos(2):LinEnd(2)),'Z').ne.0) then
              fix_type=6
           else if(index(line(LinPos(2):LinEnd(2)),'X').ne.0 .and. &
                index(line(LinPos(2):LinEnd(2)),'Y').ne.0 .and.  &
                index(line(LinPos(2):LinEnd(2)),'Z').ne.0) then
              fix_type=7
           else
              write(*,*)'Wrong contsraint command' ; go to 19
           end if
        else if(index(line(LinPos(1):LinEnd(1)),'LIST').ne.0) then
           if(fix_type.eq.0) fix_type=7
           do k=2,NumLin
              i0=index(line(LinPos(k):LinEnd(k)),'..')
              if(i0.eq.0) then
                 read(line(LinPos(k):LinEnd(k)),*,err=19) i1 ; i2=i1
              else
                 read(line(LinPos(k):LinPos(k)+i0-2),*,err=19) i1
                 read(line(LinPos(k)+i0+1:LinEnd(k)),*,err=19) i2
              end if
              write(*,'(3(a,i5))')  'QUICKSTEP: found atoms from ',i1, &
                   ' to ',i2,' of fix type = ',fix_type
              if(min(i1,i2).lt.1 .or. max(i1,i2).gt.NIONS) then
                 write(*,*) 'ERROR! Wrong atomic numbers in the LIST command:'
                 write(*,*) line ; go to 19
              end if
              do i=i1,i2
                 if(fix_type.ge.1 .and. fix_type.le.3) then
                    fix_crd(i,fix_type)=.true.
                 else if(fix_type.eq.4) then
                    fix_crd(i,1:2)=.true. 
                 else if(fix_type.eq.5) then
                    fix_crd(i,1)=.true. ; fix_crd(i,3)=.true.
                 else if(fix_type.eq.6) then
                    fix_crd(i,2:3)=.true. 
                 else if(fix_type.eq.7) then
                    fix_crd(i,1:3)=.true.
                 end if
              end do
           end do
        else
           write(*,*)'WARNING! Unrecognised command in &FROZEN_ATOMS!'
           write(*,*)'WARNING! ====> to be IGNORED!'
           write(*,*)'Press ENTER when ready ...'
           read(*,*)
        end if
        go to 15
     end if
     go to 1
      
!................ work out properly the species and order atoms
50   close(14)
     call system('/bin/rm -rf tmp.inp')

     write(*,*) '....1....'

!_________ sorting atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
     allocate(TI1(3,NIONS)) 
     good=.true. ; k=0
     do i=1,NSPEC
        ni=0
        do nat=1,NIONS
           if(isp(nat).eq.i) then
              ni=ni+1 ; k=k+1 ; TI1(1:3,k)=TI(1:3,nat)
              old_to_new(nat)=k
           end if
        end do
        NspN(i)=ni
     end do
     if(k.ne.NIONS) good=.false.
     TI=TI1
     write(*,'(a)')'WARNING: atoms have been ordered by species!'
     write(*,'(a,10(i5,x))') 'QUICKSTEP: found NspN = ',(NspN(i),i=1,NSPEC)
     write(*,*)'Done geometry!'

     write(*,*) '....2....'
     
!........... set up relaxation flags

     do i=1,NIONS
        i1=old_to_new(i) 
        do j=1,3
           relax_flag(j,i1)='T' ; if(fix_crd(i,j)) relax_flag(j,i1)='F'
        end do
     end do
     
!............ finishing
     
     if(good) then
        write(*,*) 'O.K.! This [tmp.inp] is fine! Let us proceed!' 
        write(*,*)'........> Total number of atoms in the cell is ',NIONS
     else
        write(*,*)'FATAL! Problems with sorting atoms!' 
        Err=.true. ; return
     end if
!
!___________ show atoms 
!
     nat=0
     do i=1,NSPEC
        write(*,'(a25,i3,a8)')'______> Atoms in species ',i,' <______'
        do k=1,NspN(i)
           nat=nat+1
           write(*,'(i5,5x,3(f10.5,1x),3x,3(a,x))')  &
                nat,(TI(j,nat),j=1,3),(relax_flag(j,nat),j=1,3)
        end do
     end do
     do i=1,3
        write(*,'(a,i1,a,3(f10.5,x))') '[',i,']  ',(DIRC(i,j),j=1,3)
     end do
     Err=.false.
     return

!......... errors
19   write(*,*)'FATAL! Bad or absent QUICKSTEP input file!'
     Err=.true.
end Subroutine read_cp2k_geom
