subroutine siesta_dens(grid,charge,spin,iErr)
!..............................................................
!    read density from name=seed.RHO... file of siesta
!..............................................................
!    spin = .false. - total charge
!         = .true.  - spin density
!..............................................................
use param
use atoms
use code
implicit none
real*8,parameter :: A_au=1.889725989,au_A=1.0/A_au
real*8,parameter :: tiny=0.001
real*8 GRID(NGX,NGY,NGZ),DIR(3,3)
real*8 charge,factor
logical spin,form
integer iErr,i,j,NGX1,NGY1,NGZ1,nspins,ijk,j0,iz,iy,ix
!.......... should be real, not real*8, otherwise it gives an error
!           when reading an unformatted density file
real,dimension(:),allocatable :: dens

      allocate(dens(NGX))
      iErr=0
      write(*,'(a)') &
              'Trying '//trim(seed)//'.RHO as FORMATTED ...'
      open(19,file=trim(seed)//'.RHO',status='old',form='formatted', &
                                    err=10)
      write(*,'(a)') 'Opened '//trim(seed)//'.RHO as FORMATTED'
      do i=1,3
         read(19,*,err=10,end=10) (DIR(i,j),j=1,3)
      end do
      write(*,'(a)')'Reading lattice vectors done'
      form=.true.
      go to 20

 10   close (19)
      write(*,'(a)') 'Trying '//trim(seed)//'.RHO as UNFORMATTED ...'
      open(19,file=trim(seed)//'.RHO',status='old', &
                                           form='unformatted',err=100)
      write(*,'(a)')'Opened '//trim(seed)//'.RHO as UNFORMATTED'
      read(19,err=100,end=100) ((DIR(i,j),j=1,3),i=1,3)
      write(*,'(a)')'Reading lattice vectors done'
      form=.false.
!
!.......... skipping stuff and checking
!
 20   factor=VOLC*A_au**3
      write(*,'(a)')'..........in the density .........|........from input...............'
      do j=1,3
         write(*,'(3(f10.5,x),a,3(f10.5,x))') (DIR(j,i)*au_A, i=1,3),' | ',(DIRC(j,i), i=1,3)
      end do
      do i=1,3
         do j=1,3
            if(abs(DIRC(i,j)-au_A*DIR(i,j)).gt.tiny) then
               write(*,*) 'ERROR! Mismatch of lattice vectors!'
               write(*,'(2i2,3(x,e12.6))') i,j,DIRC(i,j),au_A*DIR(i,j),abs(DIRC(i,j)-au_A*DIR(i,j))
               go to 100
            end if
         end do
      end do

!_____________checking grid and spin

      if(form) then
         read(19,*,err=100,end=100) NGX1,NGY1,NGZ1,nspins
      else
         read(19,err=100,end=100) NGX1,NGY1,NGZ1,nspins
      end if
      write(*,*)  NGX1,NGY1,NGZ1,nspins
      if(NGX.ne.NGX1 .or.NGY.ne.NGY1 .or.NGZ.ne.NGZ1) go to 100
      if(spin .and. nspins.eq.1) go to 200

!
!..........reading the charge density
!
!     WRITE(..,..) (((DENS(I,J,K),I=1,NGX), J=1,NGY), K=1,NGZ)
!
      if(spin) then
         write(*,*)'Skipping the charge density, please wait ...'
      else
         write(*,*)'Reading in charge density, please wait ...'
      end if
!
      charge=0.0 ; ijk=0 ; j0=NPLWV/10
      do iz=1,NGZ
         do iy=1,NGY
            ijk=ijk+NGX
            if(form) then
               read(19,*,err=100,end=100) (dens(ix),ix=1,NGX)
            else
               read(19,err=100,end=100) (dens(ix),ix=1,NGX)
               write(111,'(a,x,2(i5,x),5(f10.5,x))') '19 ',iz,iy,dens(1:5)
            end if
            do ix=1,NGX
               if(.not.spin) then
                  grid(ix,iy,iz)=dens(ix)*factor
                  charge=charge+grid(ix,iy,iz)
               else
                  charge=charge+dens(ix)*factor
               end if
            end do
            if(ijk/j0*j0.eq.ijk) &
                 write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
         end do
      end do
      write(*,*)'Done!'
      write(*,'(a,e12.6)')'The charge is = ',charge/NPLWV
      if(.not.spin) go to 70
!
!.......... reading the spin density if spin=.true.
!
!  WRITE(..,..) (((DENS(I,J,K),I=1,NGX), J=1,NGY), K=1,NGZ)
!
      write(*,*)'... jumping to spin density'
      write(*,*)'Reading in spin density, please wait ...'
!
      charge=0.0 ; ijk=0 ; j0=NPLWV/10
      do iz=1,NGZ
         do iy=1,NGY
            ijk=ijk+NGX
            if(form) then
               read(19,*,err=100,end=100) (dens(ix),ix=1,NGX)
            else
               read(19,err=100,end=100) (dens(ix),ix=1,NGX)
            end if
            do ix=1,NGX
               grid(ix,iy,iz)=dens(ix)*factor
               charge=charge+grid(ix,iy,iz)
            end do
            if(ijk/j0*j0.eq.ijk) &
                 write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
         end do
      end do
      write(*,*)'Done!'
      write(*,'(a,e12.6)')'The spin charge is = ',charge/NPLWV
 70   close (19)
      go to 300
!
!.......errors
 100  write(*,*)'FATAL! File '//trim(seed)//'.RHO not found or bad!'
      iErr=1
      go to 300
 200  write(*,*)'WARNING! There is no spin density found!'
      iErr=1
300   deallocate(dens)
end subroutine siesta_dens

subroutine siesta_dens_manip(unit1,unit2,unit3,c1,c2, &
                      filenA,filenB,filen,totdensA,totdensB,totdens,NPLWV,iErr)
!..............................................................
!    reading density from unit1, unit2 of SIESTA and
!    manipulaiting into:
!                         density=c1*den1+c2*den2
!..............................................................
!use param
use atoms
use code
implicit none
real*8,parameter :: tiny=0.001
real*8,parameter :: A_au=1.889725989,au_A=1.0/A_au
integer unit1,unit2,unit3,iErr,i,j,NGX1,NGY1,NGZ1,nspins,NGX2,NGY2,NGZ2
integer j0,ijk,iz,iy,ix,NPLWV
real*8 DIR1(3,3),DIR2(3,3),c1,c2
real*8,dimension(:),allocatable :: dens
real  ,dimension(:),allocatable :: dens1,dens2
real*8 totdensA,totdensB,totdens,factor
character filenA*100,filenB*100,filen*101
logical formA, formB, alloc

      Ierr=0
      alloc=.false.

!................. open A-density file

      write(*,*) 'Trying reading A-density as FORMATTED ...'
      open(unit1,file=trim(filenA),status='old',form='formatted',err=1)
      do i=1,3
         read(unit1,*,err=1,end=1) (DIR1(i,j),j=1,3)
      end do
      formA=.true.
      write(*,'(a)')'Opened '//trim(filenA)//' as FORMATTED'
      go to 5

 1    close (unit1)
      write(*,*) 'Trying reading A-density as UNFORMATTED ...'
      open(unit1,file=trim(filenA),status='old',form='unformatted',err=100)
      read(unit1,err=100,end=100) ((DIR1(i,j),j=1,3),i=1,3)
      formA=.false.
      write(*,'(a)') 'Opened '//trim(filenA)//' as UNFORMATTED'

5     write(*,'(a)')'(A) ... found lattice vectors:'
      write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR1(1,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR1(2,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR1(3,j),j=1,3)

!................. open B-density file

      write(*,*) 'Trying reading B-density as FORMATTED ...'
      open(unit2,file=trim(filenB),status='old',form='formatted',err=2)
      do i=1,3
         read(unit2,*,err=2,end=2) (DIR2(i,j),j=1,3)
      end do
      formB=.true.
      write(*,'(a)')'Opened '//trim(filenB)//' as FORMATTED'
      go to 6

 2    close (unit2)
      write(*,*) 'Trying reading B-density as UNFORMATTED ...'
      open(unit2,file=trim(filenB),status='old',form='unformatted',err=101)
      read(unit2,err=101,end=101) ((DIR2(i,j),j=1,3),i=1,3)
      formB=.false.
      write(*,'(a)') 'Opened '//trim(filenB)//' as UNFORMATTED'

6     write(*,'(a)')'(B) ... found lattice vectors:'
      write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR2(1,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR2(2,j),j=1,3)
      write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR2(3,j),j=1,3)

!................. open the final file as formatted

      write(*,*)'Writing density to '//trim(filen)//' as FORMATTED ...'
      open(unit3,file=trim(filen),status='unknown',form='formatted',err=102)

!................. checking lattice vectors and the grid

!__________ checking lattice vectors

      do i=1,3
         do j=1,3
            if(abs(DIR2(i,j)-DIR1(i,j)).gt.tiny) then
               iErr=2 ; return
            end if
         end do
      end do
      write(*,*)'... Lattice vectors: check passed!'

!_____________checking grid

      if(formA) then
         read(unit1,*,err=100,end=100) NGX1,NGY1,NGZ1,nspins
      else
         read(unit1,err=100,end=100) NGX1,NGY1,NGZ1,nspins
      end if
      write(*,'(a,3(i5,x))')  '(A) ... found grid: ',NGX1,NGY1,NGZ1
      write(*,'(a,i2)')  '(A) ... found spin: ',nspins
      if(formB) then
         read(unit2,*,err=101,end=101) NGX2,NGY2,NGZ2,nspins
      else
         read(unit2,err=101,end=101) NGX2,NGY2,NGZ2,nspins
      end if
      write(*,'(a,3(i5,x))')  '(B) ... found grid: ',NGX2,NGY2,NGZ2
      write(*,'(a,i2)')  '(B) ... found spin: ',nspins
      if(NGX2.ne.NGX1 .or.NGY2.ne.NGY1 .or.NGZ2.ne.NGZ1) then
         iErr=2 ; return
      else
         write(*,*)'... Grid: check passed!'
         NPLWV=NGX1*NGY1*NGZ1
      end if

!................. start READING/WRITING

      do i=1,3
         write(unit3,*) (DIR1(i,j),j=1,3)
         do j=1,3
            DIR1(i,j)=DIR1(i,j)*au_A
         end do
      end do
      write(unit3,*) NGX1,NGY1,NGZ1,' 1'

      call bastr(DIR1,RECC,VOLC,1)
      factor=VOLC*A_au**3
!
!..........reading the charge density
!
!     WRITE(..,..) (((DENS(I,J,K),I=1,NGX), J=1,NGY), K=1,NGZ)
!
      allocate(dens(NGX1)) ; allocate(dens1(NGX1)) ; allocate(dens2(NGX1))
      alloc=.true.

      Totdensa = 0.0 ; totdensB = 0.0 ; totdens  = 0.0
      ijk=0 ; j0=NGX1*NGY1*NGZ1/10

      do iz=1,NGZ1
         do iy=1,NGY1
            ijk=ijk+NGX1
            
            if(formA) then
               read(unit1,*,err=100,end=100) (dens1(ix),ix=1,NGX1)
            else
               read(unit1,err=100,end=100) (dens1(ix),ix=1,NGX1)
            end if
            if(formB) then
               read(unit2,*,err=101,end=101) (dens2(ix),ix=1,NGX1)
            else
               read(unit2,err=101,end=101) (dens2(ix),ix=1,NGX1)
            end if

            do ix=1,NGX1
               dens(ix)=c1*dens1(ix)+c2*dens2(ix)
               totdensA=totdensA+dens1(ix)*factor
               totdensB=totdensB+dens2(ix)*factor
               totdens =totdens + dens(ix)*factor
            end do
            write(unit3,*) (dens(ix),ix=1,NGX1)

            if(ijk/j0*j0.eq.ijk) &
                 write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
         end do
      end do
      write(*,*)'Done!'
      go to 200
!
!.......errors
 100  write(*,*)'FATAL! File '//trim(filenA)//' not found or bad!'
      iErr=1
      go to 200
 101  write(*,*)'FATAL! File '//trim(filenB)//' not found or bad!'
      iErr=1
      go to 200
 102  write(*,*)'FATAL! File '//trim(filen)//' cannlot be opened!'
      iErr=1

!............ finish

200   if(alloc) then
         deallocate(dens)
         deallocate(dens1)
         deallocate(dens2)
      end if
end subroutine siesta_dens_manip

subroutine check_dens_siesta(unit1,filen,NGX1,NGY1,NGZ1,Tot,iErr)
implicit none
real*8,parameter :: A_au=1.889725989,au_A=1.0/A_au
integer unit1,iErr,i,j,NGX1,NGY1,NGZ1,nspins
integer j0,ijk,iz,iy,ix
real*8 DIR1(3,3),RECC(3,3),VOLC,Tot,factor
real  ,dimension(:),allocatable :: dens1
character filen*100
logical formA, alloc

   iErr=0 ; alloc=.false.

!................. open density file

   write(*,*) 'Trying reading density as FORMATTED ...'
   open(unit1,file=trim(filen),status='old',form='formatted',err=1)
   do i=1,3
      read(unit1,*,err=1,end=1) (DIR1(i,j),j=1,3)
   end do
   formA=.true.
   write(*,'(a)')'Opened '//trim(filen)//' as FORMATTED'
   go to 5
   
1  close (unit1)
   write(*,*) 'Trying reading density as UNFORMATTED ...'
   open(unit1,file=trim(filen),status='old',form='unformatted',err=10)
   read(unit1,err=10,end=10) ((DIR1(i,j),j=1,3),i=1,3)
   formA=.false.
   write(*,'(a)') 'Opened '//trim(filen)//' as UNFORMATTED'
   
5  write(*,'(a)')'... found lattice vectors:'
   write(*,'(a,3(f10.5,x))')'   DIR(1) ',(DIR1(1,j)*au_A,j=1,3)
   write(*,'(a,3(f10.5,x))')'   DIR(2) ',(DIR1(2,j)*au_A,j=1,3)
   write(*,'(a,3(f10.5,x))')'   DIR(3) ',(DIR1(3,j)*au_A,j=1,3)
!
   if(formA) then
      read(unit1,*,err=10,end=10) NGX1,NGY1,NGZ1,nspins
   else
      read(unit1,err=10,end=10) NGX1,NGY1,NGZ1,nspins
   end if
   write(*,'(a,3(i5,x))')  '... found grid: ',NGX1,NGY1,NGZ1
   write(*,'(a,i2)')       '... found spin: ',nspins
!
   allocate(dens1(NGX1))
   alloc=.true.
   
   DIR1=DIR1*au_A
   call bastr(DIR1,RECC,VOLC,1)
   factor=VOLC*A_au**3 ; Tot = 0.0 ; ijk=0 ; j0=NGX1*NGY1*NGZ1/10

   do iz=1,NGZ1
      do iy=1,NGY1
         ijk=ijk+NGX1
         
         if(formA) then
            read(unit1,*,err=10,end=10) (dens1(ix),ix=1,NGX1)
         else
            read(unit1,err=10,end=10) (dens1(ix),ix=1,NGX1)
         end if
         
         do ix=1,NGX1
            Tot=Tot+dens1(ix)*factor
         end do
         
         if(ijk/j0*j0.eq.ijk) &
              write(*,'(a,i3,a)') '... done ',ijk/j0*10,' %'
      end do
   end do
   write(*,*)'Done!'
   go to 20
!
!.......errors
10 write(*,*)'FATAL! File '//trim(filen)//' not found or bad!'
   iErr=1
   go to 20
   
!............ finish
   
20 if(alloc) deallocate(dens1)
   close (unit1)
end subroutine check_dens_siesta
