
program main
implicit none
real*8,allocatable,dimension(:) :: dos,z
real*8 a,b,Zup,Zdw
integer j,n

    open(1,file='spectr.dat')
    n=0
    do
       read(1,*,err=10,end=10) a,b 
       n=n+1
    end do
10  write(*,*)'found ',n,' lines of data in the file' 
    allocate(dos(n)) ; allocate(z(n))
    rewind(1)
    do j=1,n
       read(1,*) z(j),dos(j)
       write(*,*) j,z(j),dos(j)
    end do
    close(1)
    call critical_points(dos,z,n,Zdw,Zup,a,b)
    write(*,*) 'Zup= ',Zup,' and Zdw= ',Zdw
  end program main

subroutine critical_points(dos,z,n,Zdw,Zup,a,b)
!..........................................................................
!  dos(z) curve is analysed to choose (i=1,..,n):
!
!       Zdw - point on the curve where the intensity is at a min (large z)
!       Zup - point on the curve where the intensity is at a max (small z)
! 
! At least 5 consequitive points are to be on the slope between Zup and Zdw
!..........................................................................
! From the interval [Zdw,Zup] an exponential fit a*exp(-b*z) is built
! by square-least fit of log(dos(i))=log(a)-b*z(i), =idw,..,iup
!..........................................................................
implicit none
real*8 dos(n),z(n),Zup,Zdw,a,b,x,y,x2,xy,w,w1
!real* a1,b1
integer j,i3,n,iup,idw
logical first,yes_found

   Zup=z(n) ; Zdw=z(1)
   first=.true. ; yes_found=.false.

!........... find the lowest point at large z
   do i3=n,2,-1
      if(dos(i3-1).ge.dos(i3)) then
         if(first) then
            Zup=z(i3) ; j=1 ; first=.false. ; iup=i3
         else
            j=j+1
            if(j.ge.5) then
               yes_found=.true. ; exit
            end if
         end if
      else
         first=.true. ; Zup=z(i3) ; j=1 ; iup=i3
      end if
   end do
   write(*,*) 'found Zup= ',Zup,' at iup=',iup

!........... find the highest point at small z

   idw=1
   do i3=iup-1,1,-1
      if(dos(i3-1).lt.dos(i3)) then
         idw=i3 ; Zdw=z(idw)  ; exit
      end if
   end do
   write(*,*) 'found Zdw= ',Zdw,' at idw=',idw

!.......... use weight
!   b1=-log(dos(idw)/dos(iup)) / (z(idw)-z(iup))
!   a1=exp(log(dos(idw))+b1*z(idw))
!   write(*,*) a1,b1
   w1=0.0 ; x=0.0 ; y=0.0 ; x2=0.0 ; xy=0.0
   do j=idw,iup
!      w=exp(-b1*(z(j)-z(idw))) 
      w=1.0
      w1=w1+w
      x=x+w*z(j) ; y=y+w*log(dos(j)) ; x2=x2+w*z(j)*z(j) ; xy=xy+w*z(j)*log(dos(j))
   end do
   a=exp( (y*x2-x*xy) / (w1*x2-x*x )  )
   b= -(w1*xy-x*y) / (w1*x2-x*x )  
   write(*,*) w1,x,y,x2,xy
   write(*,*) a,b


end subroutine critical_points
