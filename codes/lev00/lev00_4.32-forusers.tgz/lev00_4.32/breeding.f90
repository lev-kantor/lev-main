module breeding
  integer M1,N1,M2,N2,M3,N3
end module breeding
