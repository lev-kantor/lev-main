subroutine mainmenu()
use atoms
use code
use param
use kpoints
use dos
use siesta_EIG
implicit none
character problem*3,item*2
logical Err

!................ ask about the problem to solve
!
10 write(*,*)'.....................................................'
   write(*,*)'Choose the problem to solve:'
   write(*,*)
   write(*,*)'============== DOS options ======================='
   if(yeskp .and. yesen) then
      write(*,*)'=====> 1. Method of Tetrahedra (Blochl) <=========='
      write(*,*)' { You must have [band.out, brill.dat] from TETR }'   
      write(*,*)' Cd. Choose dispersion for the DOS smearing'
      write(*,*)' TD. Total DOS'   
      if(Which_Code.eq.'  VASP') write(*,*)' PD. Projected DOS calculation'
   end if
   if(Which_Code.eq.'SIESTA') then
      write(*,*)'============> 2. Sum of Gaussians <================'
      write(*,*)' DO. Total DOS: you need [seed].EIG'   
      write(*,*)' PD. Projected DOS: you need [seed].PDOS file'   
   end if
   write(*,*)
   write(*,*)'============== DENSITY options ==================='
   if(Which_Code.eq.'  VASP') then
      write(*,*) ' D. total/partial electron density, electrostatic potential'
   else if(Which_Code.eq.'SIESTA') then
      write(*,*) ' D. total or partial electron density; electrostatic potential'
   else if(Which_Code.eq.'QUICKS') then
      write(*,*) ' D. total electron density'
   end if
   if((Which_Code.eq.'  VASP' .and. ispin.eq.2) .or. Which_Code.eq.'SIESTA') then
      write(*,*) 'SD. total or partial spin density; electrostatic potential'
   else if(Which_Code.eq.'QUICKS') then
      write(*,*) 'SD. spin density'
   end if
   write(*,*)
   write(*,*)'============== ELECTR. potential options ========='
   write(*,*)'CP. Coulomb potential (point,line,plane)'
   if(Which_Code.eq.'SIESTA') then
      write(*,*)'============== OTHER ============================='
      if(yesrlx) write(*,*)'Ck  Check if SIESTA relaxation finished properly'
   end if
   write(*,*)
   if(Which_Code.eq.'  VASP') then
      write(*,*)'============== MOVIE options ==================='
      write(*,*)'Ge. Analyse (relaxed/MD) geometries'
   end if
   write(*,*)
   write(*,*)' Q. Quit'
   write(*,*)
   write(*,*)'------------>'
   read(*,'(a)',err=11) item

![DSm]_____ total DOS for various smearing parameters
   if(trim(item).eq.'Cd' .and. yeskp .and. yesen) then
      problem='DSm'
      call ask_spin(jspin)
      call prep_disp()

![PRO]_____ projected DOS 
   else if(trim(item).eq.'PD') then
      if(yeskp .and. yesen .and. Which_Code.eq.'  VASP') then
         problem='PRO'
         call ask_spin(jspin)
         call get_psi2_from_vasp(Err)
         if(Err) then
            write(*,*)'************************************************************'
            write(*,*)'** PDOS is not available as the PROCAR file was not found **'
            write(*,*)'** Press ENTER when ready ...                             **'
            write(*,*)'************************************************************'
            read(*,*)
         else
            call prep_dos(1)
         end if
      else if(Which_Code.eq.'SIESTA') then
         call ask_spin(jspin)
         call read_siesta_pdos(jspin)
      end if
      
![tDS]_____ total DOS: run an interactive 
!  program to sum contributions from every tetrahedra (those were built 
!  earlier by the 1st part of the code.

   else if(trim(item).eq.'TD' .and. yeskp .and. yesen) then
      problem='tDS'
      call ask_spin(jspin)
      call prep_dos(0)

   else if(Which_Code.eq.'SIESTA' .and. trim(item).eq.'DO') then
      problem='tDS'
      call ask_spin(jspin)
      call dos_from_EIG(jspin)
      
![MAP]_____ Prepare output files for the densities in the format 
!  understandable by plotters (i.e. when the coordinates are in 
!  Angstroms (instead of being through the grid numbers) and the 
!  density is along a line or in a plane: run an interactive program

![D]_________ plot the charge density in the case of DNS and quit
   else if(trim(item).eq.'D') then
      problem='DNS'
      call density(.false.)

![SD]_________ plot the spin density in the case of DNS and quit
   else if(trim(item).eq.'SD' .and. ispin.eq.2 ) then
      problem='DNS'
      call density(.true.)
      
![CP]__________ calculate Coulomb potential for point charges 
!
   else if(trim(item).eq.'CP') then
      problem='Mad'
      call lev_coulmb()

![Ck]__________ check siesta forces and if the relaxation finished
!
   else if(trim(item).eq.'Ck' .and. Which_Code.eq.'SIESTA' .and. yesrlx) then
      problem='Chk'
      call check_siesta_forces()
      
![Ge]__________ collect all geometries into a single XYZ file
!
   else if(trim(item).eq.'Ge' .and. Which_Code.eq.'  VASP') then
      problem='Mov'
      call collect_xyz()

   else if(trim(item).eq.'Q') then
      return
   end if
   go to 10
11 write(*,*) "Incorrect item number! Try again!"
   go to 10
end subroutine mainmenu
 
subroutine ask_spin(jspin)
!.................................................................
!  in the case of spin-polarised calculation (ispin=2)
!                ask for which spin: 1 or 2
!.................................................................
! jspin = 1  - non spin-polarised calculation
!         1  - spin polarised, spin UP
!         2  - spin polarised, spin DOWN
!.................................................................
use param
implicit none
integer jspin
1 if(ispin.eq.1) then
     jspin=1
  else if(ispin.eq.2) then
     write(*,*)'Specify which spin: up (1) or down (2)?'
     read(*,*,err=1) jspin
     if(jspin.eq.1) then
        write(*,*) 'DOS will be calculated for spin UP'
     else if(jspin.eq.2) then
        write(*,*) 'DOS will be calculated for spin DOWN'
     else
        go to 1
     end if
  end if
end subroutine ask_spin

subroutine check_siesta_forces()
use param
use atoms
use code
implicit none
character line*200
integer LinEnd(100),LinPos(100),NumLin,iErr,nat,i,at,i1
real*8 f(3),ff,ftol

   write(*,'(a)')'... Reading forces from the main SIESTA output '//trim(nameout)//'...'
   open(19,file=trim(nameout),status='old',form='formatted',err=10)

!___________ check if relaxation was successful   

   call find_string('outcoor: Relaxed atomic coordinates',35,line,19,.true.,iErr)
   if(iErr.eq.0) then
      write(*,*)'GOOD: this calculation HAS FINISHED!'
   else
      write(*,*)'WARNING: this calculation has NOT finished!'
   end if

!..................... check individual forces

20 write(*,*)'Specify force tolerance for checking:'
   read(*,*,err=20) ftol ; if(ftol.lt.0.0) ftol=abs(ftol)
   
!___________ find the last forces
   rewind(19) ; i=0
1  call find_string('siesta: Atomic forces (eV/Ang):',31,line,19,.true.,iErr)
   if(iErr.eq.0) then
      i=i+1 ; go to 1
   end if
   write(*,*)'... Found the forces ',i,' times ...'
   rewind(19) ; i1=0
2  call find_string('siesta: Atomic forces (eV/Ang):',31,line,19,.true.,iErr)
   i1=i1+1 ; if(i1.lt.i) go to 2

!___________ read and check the last forces

   do at=1,NIONS
      call CutStr(Line,NumLin,LinPos,LinEnd,19,0,iErr)
      if(NumLin.eq.5) then
         read(line(LinPos(2):LinEnd(5)),*,err=40) nat,(f(i),i=1,3)
      else if(NumLin.eq.4) then
         read(line(LinPos(1):LinEnd(4)),*,err=40) nat,(f(i),i=1,3)
      end if
      write(*,*) nat,(f(i),i=1,3)
      if(at.ne.nat) go to 40
      ff=sqrt(f(1)*f(1)+f(2)*f(2)+f(3)*f(3))
!      write(*,'(i5,5x,3a)') at,(relax_flag(j,nat),j=1,3)
      if( (relax_flag(1,nat).eq.'T' .and. abs(f(1)).gt.ftol) .or. &
            (relax_flag(2,nat).eq.'T' .and. abs(f(2)).gt.ftol) .or. &
              (relax_flag(3,nat).eq.'T' .and. abs(f(3)).gt.ftol) ) &
          write(*,'(a,3(x,f10.5),a,i5,a,f10.5)') &
              'WARNING: large force ( ',f,' ) on atom =',nat,' abs= ',ff
   end do
   write(*,*)'Finished checking individual atomic forces ...'
   write(*,*)'Found ',nat,' atoms in the system'
   call CutStr(Line,NumLin,LinPos,LinEnd,19,0,iErr)
   if(NumLin.eq.5) then
      read(line(LinPos(3):LinEnd(5)),*,err=40) (f(i),i=1,3)
   else if(NumLin.eq.4) then
      read(line(LinPos(2):LinEnd(4)),*,err=40) (f(i),i=1,3)
   end if
   ff=sqrt(f(1)*f(1)+f(2)*f(2)+f(3)*f(3))
   write(*,'(a,3(f10.5,x),a,f10.5)') '... Checking the net force => ',f,' abs= ',ff
   close(19)  ; return
10 write(*,*)'FATAL! Cannot open SIESTA on-screen output file'
   close(19) ; return
40 write(*,*)'ERROR reading SIESTA forces from on-screen output file'
   close(19)
end subroutine check_siesta_forces

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine collect_xyz()
use param
use atoms
use code
implicit none
character line*200,item*2,list*200
integer LinEnd(100),LinPos(100),NumLin,iErr,i,k,count,i1,k1,nat,len
integer kTag,icount,lngth,pos,tcount,jcount,kcount,count1,count2
real*8 x,y,z,energy,fx,fy,fz,force_max,fm,Force_min,r(3),X1,X2,fxx,fyy,fzz
character cha
logical TagYes,AtomsYes,Yes_Mo,AaYes
character(len=2),dimension(:),allocatable :: Labels
character(len=7),dimension(:),allocatable :: title_pl,title_pl1
logical,dimension(:),allocatable :: listat
real*8,dimension(:),allocatable :: Xc,Yc,Zc
real*8,dimension(:,:),allocatable :: TIi
character title*50,xaxis*20,yaxis*20,where*6,cha4*4,cha5*4,cha10*10

!........... species by atom number
   allocate(Labels(NIONS)) ; allocate(listat(NIONS))
   nat=0
   do i=1,NSPEC
      do k=1,NspN(i)
         nat=nat+1 ; Labels(nat)=Species(i)
      end do
   end do

   write(*,*)'======================================================'
   write(*,*)'===== VASP output file to be used        =============' 
   write(*,*)'======================================================'
!   call system('ls *OUTCAR*')
   write(*,'(a)') nameout
   write(*,*)'======================================================'

!   write(*,*)' Give the name of the VASP output file:'
!   read(*,'(a)') nameout

   write(*,'(a)')'... Reading the OUTCAR file '//trim(nameout)//'...'
   open(19,file=trim(nameout),status='old',form='formatted',err=10)

!.......... choose initially All atoms
   
   TagYes=.true. ; listat=.true.
   write(cha10,'(i10)') NIONS ; list='1-'//trim(cha10) ; len=0
   kTag=NIONS
   allocate(Xc(kTag),Yc(kTag),Zc(kTag)) ; allocate(title_pl(kTag))
   do k=1,NIONS
      write(cha4,'(i4)') i ; title_pl(k)='at='//cha4
   end do
   
!............ start the menu

   AtomsYes=.false. ; Yes_Mo=.false. ; Force_min=0.01 ; AaYes=.true.
21 write(*,*)'..................................................'
   write(*,*) 
   write(*,'(a)')' Mo. Put all geometries in a single geometries.xyz file'
   write(*,'(a)')'     and save all their energies'
   if(Yes_Mo) then
      write(*,'(a)')' PE. PLot energies'
      write(*,'(a)')' PF. PLot maximum force'
      write(*,'(a)')'  S. Particular geometry: save as a VASP input file'
      write(*,'(a)')' Cf. Particular geometry: check atomic forces'
      write(*,'(a)')' Cm. Particular geometries: compare geometries'
   end if
   write(*,'(a)')   '  T. Tag atoms of interest'
   if(TagYes) then
      write(*,'(a)')'     Chosen atom(s):'
      if(len.eq.0) then
         write(*,'(a)')'         '//trim(list)
      else
         write(*,'(a)')'         '//list(1:len)
      end if
         write(*,'(a)')' At. Position history for selected atoms'
      if(AtomsYes) write(*,'(a)')' Pt. Plot atomic trajectories'
   end if
   write(*,'(/a)')'================= General help ==================='
   write(*,'(a)')' Co. Show current atomic positions in fractional/Cartesian'
   write(*,'(a,f10.5)')' Tl. Minimum force on atoms = ',Force_min
   if(Yes_Mo) write(*,'(a,i5,a,i5)')  &
        ' GN. For pLotting: between geometries ',count1,' and ',count2
   if(AaYes) then
      write(*,'(a)')' Aa. In opption Cf show all atoms'
   else
      write(*,'(a,f10.5)')' Aa. In option Cf show only atoms with forces >',Force_min 
   end if
   write(*,'(a)')'  Q. Quit'
   write(*,*)
   write(*,*)'------------>'
   read(*,*) item

![T]___________ select atoms

   if(trim(item)=='T') then

      if(TagYes) then
         deallocate(title_pl) ; deallocate(Xc,Yc,Zc) 
         TagYes=.false. ; listat=.false. ; go to 21
      end if
      call TTag(TagYes,NIONS,TI,Labels,listat,list,len)
      k=0
      do i=1,NIONS
         if(listat(i)) k=k+1
      end do
      if(k.eq.0) then
         TagYes=.false. ; go to 21
      end if
      kTag=k
      allocate(Xc(kTag),Yc(kTag),Zc(kTag)) ; allocate(title_pl(kTag))
      k=0
      do i=1,NIONS
         if(listat(i)) then
            k=k+1 ; write(cha4,'(i4)') i ; title_pl(k)='at='//cha4
         end if
      end do
      TagYes=.true.

![Co]___________ show all atoms with tags if present

   else if(trim(item)=='Co') then

      call show_atoms_tagged1(listat)
      
![Tl]___________ enter the minimum force on atoms to display them

   else if(trim(item)=='Tl') then

6     write(*,*)'Enter minimum force to display atomic numbers'
      write(*,*)'with forces larger than this value:'
      read(*,*,err=6) Force_min 

![At]___________ go through all geometries consecutively

   else if(trim(item)=='At' .and. TagYes) then

      open(20,file='one_atom.X',form='formatted')
      open(21,file='one_atom.Y',form='formatted')
      open(22,file='one_atom.Z',form='formatted')
      count=0
      do
         call find_string(' POSITION ',10,line,19,.true.,iErr)
         if(iErr.ne.0) go to 2
         read(19,'(a)') cha
         k1=0 ; nat=0
         do i=1,NSPEC
            do k=1,NspN(i)
               nat=nat+1
               read(19,*) x,y,z
               if(listat(nat)) then
                  k1=k1+1 ; Xc(k1)=x ; Yc(k1)=y ; Zc(k1)=z
               end if
            end do
         end do
         count=count+1
         write(*,*)'... positions read, count =',count
         write(20,*) count,(Xc(k1),k1=1,kTag)
         write(21,*) count,(Yc(k1),k1=1,kTag)
         write(22,*) count,(Zc(k1),k1=1,kTag)
      end do
2     close (20) ; close(21) ; close(22)
      rewind (19)
      AtomsYes=.true.
      
![Pt]___________ plot atomic trajectorries
      
   else if(trim(item)=='Pt' .and. AtomsYes .and. TagYes) then

      title='X-coordinate' ; X1=count1 ; X2=count2
      call Plot_bunch_with_lim(kTag,'one_atom.X',10,title,title_pl, &
                'geometry number     ',&
                'X coordinate  (A)   ', 'Screen', 33,X1,X2)
      call Plot_bunch_with_lim(kTag,'one_atom.X',10,title,title_pl, &
                'geometry number     ',&
                'Y coordinate  (A)   ', 'Screen', 34,X1,X2)
      call Plot_bunch_with_lim(kTag,'one_atom.X',10,title,title_pl, &
                'geometry number     ',&
                'Z coordinate  (A)   ', 'Screen', 35,X1,X2)

![Mo]___________ go through all geometries consecutively
      
   else if(trim(item)=='Mo') then
      
      open(20,file='geometries.xyz',form='formatted',err=11)
      open(23,file='energies.d',form='formatted',err=12)
      open(24,file='forces.dat',form='formatted',err=12)
      count=0 
      do
         call find_string(' POSITION ',10,line,19,.true.,iErr)
         if(iErr.eq.0) then
            write(*,*)'... POSITION found'
         else
            go to 3
         end if
         read(19,'(a)') cha
         write(20,'(i10/)') NIONS
         nat=0 ; force_max=-1.0
         do i=1,NSPEC
            do k=1,NspN(i)
               nat=nat+1
               read(19,*) x,y,z,fx,fy,fz
               if(relax_flag(1,nat).eq.'F') fx=0.0 
               if(relax_flag(2,nat).eq.'F') fy=0.0 
               if(relax_flag(3,nat).eq.'F') fz=0.0 
               fx=abs(fx) ; fy=abs(fy) ; fz=abs(fz) ; fm=max(fx,fy,fz)
               if(fm.gt.force_max) force_max=fm
               write(20,'(a2,5x,3(f10.5,x))') Species(i),x,y,z
            end do
         end do
         count=count+1
         write(*,*)'... positions read, count =',count
         call find_string('energy(s',8,line,19,.true.,iErr)
         call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
         read(Line(LinPos(7):),*) energy
         write(23,*) count,energy
         write(24,*) count,force_max
      end do
3     close (20) ; close(23) ; close(24)
      tcount=count ; count1=1 ; count2=tcount
      rewind (19)
      Yes_Mo=.true.

![Aa]___________ how to show forces on atoms

   else if(trim(item)=='Aa') then

      if(AaYes) then
         AaYes=.false.
      else
         AaYes=.true.
      end if
      
![GN]___________ boundary geometries for PE and PF
      
   else if(trim(item)=='GN' .and. Yes_Mo) then

13    write(*,*)'Indicate two geometries between 1 and ',tcount,' :'
      read(*,*) count1,count2
      if(count1.gt.count2 .or. count1.lt.1 .or. count2.gt.tcount) go to 13

![PE]___________ plot energies
      
   else if(trim(item)=='PE' .and. Yes_Mo) then
      
      title='Energies    ' ; X1=count1 ; X2=count2
      allocate(title_pl1(1)) ; title_pl1(1)='       '  
      call Plot_bunch_with_lim(1,'energies.d',10,title,title_pl1, &
                'geometry number     ',&
                'Energy (eV)         ', 'Screen', 33,X1,X2)
      deallocate(title_pl1)

![PF]___________ plot maximum force
      
   else if(trim(item)=='PF' .and. Yes_Mo) then
      
      title='Max force   ' ; X1=count1 ; X2=count2
      allocate(title_pl1(1)) ; title_pl1(1)='       '  
      call Plot_bunch_with_lim(1,'forces.dat',10,title,title_pl1, &
                'geometry number     ',&
                'Max force (eV/A)    ', 'Screen', 33,X1,X2)
      deallocate(title_pl1)

![S]___________ save a particular geometry
      
   else if(trim(item)=='S' .and. Yes_Mo) then

4     write(*,*) 'Choose geometry between 1 and ',tcount
      read(*,*,err=4) icount
      if(icount.lt.1 .or. icount.gt.tcount) go to 4
      write(cha4,'(i4)') icount ; call char_pos(cha4,4,pos)
      write(*,'(a)') '...'//cha4(pos:)//'...'
      open(20,file='CONTCAR_iter='//cha4(pos:),form='formatted')
      count=0
      do
         call find_string(' POSITION ',10,line,19,.true.,iErr)
         count=count+1
         if(count.eq.icount) exit
      end do
      read(19,'(a)') 
      write(20,*) '... Saved geometry '//trim(cha4)
      write(20,*) '1.0'
      write(20,*) DIRC(1,1),DIRC(1,2),DIRC(1,3)
      write(20,*) DIRC(2,1),DIRC(2,2),DIRC(2,3)
      write(20,*) DIRC(3,1),DIRC(3,2),DIRC(3,3)
      write(cha4,'(i4)') NSPEC ; call char_pos(cha4,4,pos)
      write(20,'('//cha4(pos:)//'(a,x))') (Species(i),i=1,NSPEC)
      write(20,'('//cha4(pos:)//'(i5,x))') (NspN(i),i=1,NSPEC)
      write(20,'(a/a)') 'Selective dynamics','Cartesian'
      do i=1,NSPEC
         do k=1,NspN(i)
            read(19,*) x,y,z
            write(20,'(3(f10.5,x),a)') x,y,z,'   F F F'
         end do
      end do
      write(*,*)'... positions read, count =',count
      close (20) 
      rewind (19)

![Cf]___________ print atoms with forces > tolerance 
      
   else if(trim(item)=='Cf' .and. Yes_Mo) then

7     write(*,*) 'Choose geometry between 1 and ',tcount
      read(*,*,err=7) icount
      if(icount.lt.1 .or. icount.gt.tcount) go to 7
      write(cha4,'(i4)') icount ; call char_pos(cha4,4,pos)
      write(*,'(a)') '...'//cha4(pos:)//'...'
      count=0
      do
         call find_string(' POSITION ',10,line,19,.true.,iErr)
         count=count+1
         if(count.eq.icount) exit
      end do
      read(19,'(a)') 
      nat=0
      write(*,'(/a)') &
       '...ATOM..|............ POSITION .............|............. FORCES ............|RLX'
      do i=1,NSPEC
         do k=1,NspN(i)
            nat=nat+1
            read(19,*) x,y,z,fxx,fyy,fzz
            fx=fxx ; fy=fyy; fz=fzz
            if(relax_flag(1,nat).eq.'F') fx=0.0 
            if(relax_flag(2,nat).eq.'F') fy=0.0 
            if(relax_flag(3,nat).eq.'F') fz=0.0 
            fx=abs(fx) ; fy=abs(fy) ; fz=abs(fz) ; fm=max(fx,fy,fz)
            if(AaYes) then
               write(*,'(i5,x,a2,6(x,f10.5,x),3a,x,f10.5)') &
                    nat,Species(i),x,y,z,fxx,fyy,fzz,relax_flag(1,nat), &
                    relax_flag(2,nat),relax_flag(3,nat)
            else 
               if(fm.gt.Force_min) then
                  write(*,'(i5,x,a2,6(x,f10.5,x),3a,x,f10.5)') &
                       nat,Species(i),x,y,z,fx,fy,fz,relax_flag(1,nat), &
                       relax_flag(2,nat),relax_flag(3,nat),fm
               end if
            end if
         end do
      end do
      write(*,'(a/)') &
      '...................................................................................'
      write(*,*)'... positions read, count =',count
      write(*,*)'Press ENTER to proceed...'
      read(*,*)
      rewind (19)


![Cm]___________ compare particular geometries
      
   else if(trim(item)=='Cm' .and. Yes_Mo) then

8     write(*,*) 'Choose TWO geometries between 1 and ',tcount
      read(*,*,err=8) icount,jcount
      if(icount.lt.1 .or. icount.gt.tcount) go to 8
      if(jcount.lt.1 .or. jcount.gt.tcount .or. icount.eq.jcount) go to 8
      if(icount.gt.jcount) then
         kcount=jcount; jcount=icount ; icount=kcount
         write(*,*) icount,jcount
      end if
      write(cha4,'(i4)') icount ; call char_pos(cha4,4,pos)
      write(cha5,'(i4)') jcount ; call char_pos(cha5,4,pos)
      allocate(TIi(3,NIONS))
      count=0
      do
         call find_string(' POSITION ',10,line,19,.true.,iErr)
         count=count+1
         if(count.eq.icount) then
            read(19,'(a)') 
            nat=0 
            do i=1,NSPEC
               do k=1,NspN(i)
                  nat=nat+1
                  read(19,*) TIi(1,nat),TIi(2,nat),TIi(3,nat)
               end do
            end do
         else if(count.eq.jcount) then
            write(*,'(6x,3(14x,a,12x))') &
                 'geometry = '//cha4,'geometry = '//cha5,' >= DIFFERENCE =<'
            read(19,'(a)') 
            nat=0 
            do i=1,NSPEC
               do k1=1,NspN(i)
                  nat=nat+1
                  read(19,*) r(1),r(2),r(3)
                  write(*,'(i5,x,a,3(1x,f12.6),2x,3(1x,f12.6),2x,3(1x,f12.6),a)') &
                    nat,Species(i),(TI(k,nat),k=1,3),(r(k),k=1,3),(r(k)-TI(k,nat),k=1,3)
               end do
            end do
            exit
         end if
      end do
      write(*,*)'... positions read, count =',count
      deallocate(TIi)
      rewind (19)

   else if(trim(item)=='Q') then
      go to 5
   else
      write(*,*) "Incorrect! Please, try again!"
   end if
   go to 21
!......... finish

10 write(*,*)'ERROR: cannot open OUTCAR file '//trim(nameout)
   go to 5
12 write(*,*)'ERROR: cannot open energy file energies.dat'
   go to 5
11 write(*,*)'ERROR: cannot open XYZ file geometries.xyz'
5  close(19) 
   deallocate(Labels) ; deallocate(listat)
   return
 end subroutine collect_xyz
 
