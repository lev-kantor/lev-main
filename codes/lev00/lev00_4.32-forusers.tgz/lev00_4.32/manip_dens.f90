subroutine manipulate()
!...............................................................
!   Read charge two densities and manipulate them using the 
!   following recipe:
!
!       final(grid) = c1*A(grid) + c2*B(grid)
!
!   Write result to another density file.
!...............................................................
!use param
use code
implicit none
character filenA*100,filenB*100,filen*101,answer
character file*24,item*2
real*8 :: c1=1.0,c2=-1.0,totdens,totdensA,totdensB
integer  iErr,NPLWV,NGXa,NGYa,NGZa,NGXb,NGYb,NGZb,NPLWVa,NPLWVb,ncol
real*8  TotA,TotB
logical Yes_Do,goodA,goodB,Yes_merge
!
!......... defaults for file names
!
      if(Which_Code.eq.'  VASP') then
         file='CHGCAR'
         write(*,*) 'Total (CHGCAR) or partial (PARCHG) densities (t/p)?'
         read(*,'(a)') answer
         if(answer.eq.'t') then
            ncol=5
         else
            ncol=10
         end if
         write(*,'(a)') '******************************************'
         write(*,'(a,i2,a)') '*** ',ncol,' columns of data will be read in ***'
         write(*,'(a)') '******************************************'
      else if(Which_Code.eq.'SIESTA') then
         file='siesta.RHO'
      else if(Which_Code.eq.'QUICKS') then
         file='density.cube'
      end if
      filenA=trim(file)//'_a' ; filenB=trim(file)//'_b' ; filen =trim(file)//'_ab'
!
!......... ask what to do:
!
      Yes_Do=.false. ; goodA=.false. ; goodB=.false. ; Yes_merge=.false.

 10   write(*,*)' ....... DENSITIES MANIPULATION MENU .................'
      write(*,*)' ... CALCULATE the density from A,B-densities as: ....'
      if(Yes_merge) then
         c1=1.0 ; c2=1.0
      end if
      if(c2.lt.0.0) then
         write(*,'(/a,f8.3,a,f9.3,a)') &
           '    final(grid) = ',c1,' * A(grid) ',c2,' * B(grid)'
      else
         write(*,'(/a,f8.3,a,f9.3,a)') &
           '    final(grid) = ',c1,' * A(grid) + ',c2,' * B(grid)'
      end if
      write(*,*)
      write(*,*)'   <<< active code = '//Which_Code//' >>>'
      if(Yes_merge) then
         write(*,*)' M. MERGE the densities? - YES'
      else
         write(*,*)' M. MANIPULATE the densities? - YES'
      end if
      write(*,*)' A. file name of the A-density = ',trim(filenA)
      write(*,*)'rA. read the file [',trim(filenA),'] <= only CHECK'
      if(goodA) then
         write(*,'(6x,3(a,i5))')'Grid => ',NGXa,' x ',NGYa,' x ',NGZa
         NPLWVa=NGXa*NGYa*NGZa
         write(*,'(6x,a,f12.6,a)') '...> Total charge in ['//trim(filenA)// &
              '] = ',TotA/NPLWVa,' <...'
      end if
      write(*,*)' B. file name of the B-density = ',trim(filenB)
      write(*,*)'rB. read the file [',trim(filenB),'] <= only CHECK'
      if(goodB) then
         write(*,'(6x,3(a,i5))')'Grid => ',NGXb,' x ',NGYb,' x ',NGZb
         NPLWVb=NGXb*NGYb*NGZb
         write(*,'(6x,a,f12.6,a)') '...> Total charge in ['//trim(filenB)// &
              '] = ',TotB/NPLWVb,' <...'
      end if
      write(*,*)'AB. file name of the final density = ',trim(filen)
      if(.not.Yes_merge) then
         write(*,*)'C1. coefficient c1= ',c1
         write(*,*)'C2. coefficient c2= ',c2
      end if
      if(Yes_Do) then
         write(*,*)' F. calculate and write the final density <= DONE'
         write(*,'(a,f12.6,a)') '...> Total charge in ['//trim(filenA)// &
              '] = ',totdensA/NPLWV,' <...'
         write(*,'(a,f12.6,a)') '...> Total charge in ['//trim(filenB)// &
              '] = ',totdensB/NPLWV,' <...'
         write(*,'(a,f12.6,a)') '...> Final charge in ['//trim(filen)// &
              '] = ',totdens/NPLWV,' <...'
      else
         write(*,*)' F. calculate and write the final density'
      end if
      write(*,*)' Q. quit'
      write(*,*)
      write(*,*)'------------>'
      read(*,'(a)',ERR=11) item

![M]..... Manipulate or Merge the densities
      if(trim(item).eq.'M') then
         if(Yes_merge) then
            Yes_merge=.false.
         else
            Yes_merge=.true.
         end if

![A]..... A-density filename
      else if(trim(item).eq.'A') then
 13      write(*,*)'Give the file name for the A-density:'
         read(*,'(a)',err=13) filenA

![rA]..... read A-density to check the file
      else if(trim(item).eq.'rA') then
         if(Which_Code.eq.'  VASP') then
            call check_dens_vasp(19,filenA,NGXa,NGYa,NGZa,TotA,ncol,iErr)
         else if(Which_Code.eq.'SIESTA') then
            call check_dens_siesta(19,filenA,NGXa,NGYa,NGZa,TotA,iErr)
         else if(Which_Code.eq.'QUICKS') then
            call check_dens_cp2k(19,filenA,NGXa,NGYa,NGZa,TotA,iErr)
         end if
         if(iErr.eq.0) goodA=.true.

![B]..... B-density filename
      else if(trim(item).eq.'B') then
 14      write(*,*)'Give the file name for the B-density:'
         read(*,'(a)',err=14) filenB

![rB]..... read B-density to check the file
      else if(trim(item).eq.'rB') then
         if(Which_Code.eq.'  VASP') then
            call check_dens_vasp(19,filenB,NGXb,NGYb,NGZb,TotB,ncol,iErr)
         else if(Which_Code.eq.'SIESTA') then
            call check_dens_siesta(19,filenB,NGXb,NGYb,NGZb,TotB,iErr)
         else if(Which_Code.eq.'QUICKS') then
            call check_dens_cp2k(19,filenB,NGXb,NGYb,NGZb,TotB,iErr)
         end if
         if(iErr.eq.0) goodB=.true.

![AB]..... final density filename
      else if(trim(item).eq.'AB') then
 15      write(*,*)'Give the file name for the final density:'
         read(*,'(a)',err=15) filen

![C1]..... c1
      else if(trim(item).eq.'C1' .and. (.not.Yes_merge)) then
 16      write(*,*)'Give c1:' ; read(*,*,err=16) c1

![C2]..... c2
      else if(trim(item).eq.'C2' .and. (.not.Yes_merge)) then
 17      write(*,*)'Give c2:' ; read(*,*,err=17) c2

![F]..... calculate + write the final density
!  The total density 'totdens' is calculated in each case to
!  take care of the calculation
!
      else if(trim(item).eq.'F') then

!===================== open files for VASP

         if(Which_Code.eq.'  VASP') then

            write(*,*)'Reading in density from '//trim(filenA)//' ...'
            open(1,file=trim(filenA),status='old',form='formatted', &
                 err=150)
            write(*,*)'Reading in density from '//trim(filenB)//' ...'
            open(2,file=trim(filenB),status='old',form='formatted', &
                 err=151)
            write(*,*)'Writing density to '//trim(filen)//' ...'
            open(3,file=trim(filen),status='unknown',form='formatted')

            call vasp_dens_manip(1,2,3,c1,c2,totdensA,totdensB,totdens,NPLWV,ncol,iErr)
            close (1) ; close (2)
            if(iErr.eq.2) go to 153
            if(iErr.eq.1) go to 172
            close (3)

!===================== open files for SIESTA

         else if(Which_Code.eq.'SIESTA') then
            call siesta_dens_manip(1,2,3,c1,c2,filenA, &
                 filenB,filen,totdensA,totdensB,totdens,NPLWV,iErr)
            close (1) ; close (2)
            if(iErr.eq.2) go to 153
            if(iErr.eq.1) go to 172
            close (3)

!===================== open files for CP2K

         else if(Which_Code.eq.'QUICKS') then
            call cp2k_dens_manip(1,2,3,c1,c2,filenA, &
                 filenB,filen,totdensA,totdensB,totdens,NPLWV,Yes_merge,iErr)
            close (1) ; close (2)
            if(iErr.eq.2) go to 153
            if(iErr.eq.1) go to 172
            close (3)
         end if
         Yes_Do=.true.

![7]..... quit
      else if(trim(item).eq.'Q') then
         return
      else
         go to 11
      end if
      go to 10
 11   write(*,*) "Incorrect menu option! Try again!" ; go to 10

!..... errors

 150  write(*,*)'FATAL! Error while opening '//trim(filenA)//' file!'
      go to 10
 151  write(*,*)'FATAL! Error while opening '//trim(filenB)//' file!'
      close (1)
      go to 10
 153  write(*,*) 'FATAL! Files '//trim(filenA)//' and '// &
           trim(filenB)//' are inconsistent'
      go to 172
 172  close (3,status='delete')
      go to 10
end subroutine manipulate


