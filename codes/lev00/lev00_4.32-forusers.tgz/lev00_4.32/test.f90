program test
  implicit none
  real*8 dos(300),z(300)
  real*8 Zup,Zdw,a,b,eps
  integer :: i,j,k,idw,iup,n

  open(1,file='spectr.dat')
  do i=1,300
     read(1,*) z(i),dos(i)
  end do
  close(1)
  n=300 ; eps=1.0
  call critical_points(dos,z,n,Zdw,Zup,idw,iup,a,b,eps)
  write(*,*) a,b
  do i=iup,idw
     write(2,*) z(i),dos(i),a*exp(-b*z(i))
  end do
end program test

subroutine critical_points(dos,z,n,Zdw,Zup,idw,iup,a,b,eps)
!..........................................................................
!  dos(z) curve is analysed to choose (i=1,..,n):
!
!       Zdw - point on the curve where the intensity is at a min (large z)
!       Zup - point on the curve where the intensity is at a max (small z)
! 
!..........................................................................
! eps - the tolerance: the max point must be larger than eps
!..........................................................................
! From the interval [Zdw,Zup] an exponential fit a*exp(-b*z) is built
! by square-least fit method of log(dos(i))=log(a)-b*z(i), =idw,..,iup
!..........................................................................
implicit none
real*8 dos(n),z(n),Zup,Zdw,a,b,x,y,x2,xy,w,w1
real*8 am,eps
integer j,i3,n,iup,idw,imin,imax,n1
logical first,yes_found

!....... find the maximum point inside the given set of points starting form the end

   am=eps ; j=0 ; yes_found=.false.
   do i3=n,1,-1
      if(dos(i3).gt.eps) then
         am=dos(i3) ; n1=i3 ; exit
      end if
   end do
   write(*,*) n1,z(n1),am
   do i3=n1,1,-1
      if( dos(i3).ge.dos(i3+1) ) then
         am=dos(i3) ; iup=i3 ; j=j+1
      else
         exit
      end if
   end do
   Zup=z(iup)
!   write(*,*) 'Max: z = ',Zup,' dos = ',dos(iup),' iup = ',iup

!....... find the minimum dos inside the given set of points after the maximum point

   am=1.0e10 
   do i3=iup,n
      if(dos(i3).le.am) then
         am=dos(i3) ; idw=i3
      end if
   end do
   Zdw=z(idw)
!   write(*,*) 'Min: z = ',Zdw,' dos = ',dos(idw),' idw = ',idw

   
!.......... least square fit

   x=0.0 ; y=0.0 ; x2=0.0 ; xy=0.0 ; w1=0
   do j=iup,idw
      w1=w1+1
      x=x+z(j) ; y=y+log(dos(j)) ; x2=x2+z(j)*z(j) ; xy=xy+z(j)*log(dos(j))
   end do
   write(*,*) x,y,x2,xy
   a=exp( (y*x2-x*xy) / (w1*x2-x*x )  )
   b= -(w1*xy-x*y) / (w1*x2-x*x )  
!   write(*,*) a,b

end subroutine critical_points
