program tes
  implicit none
  character cha*5
  integer l,pos,i2,i1

1 read(*,'(a)') cha

  call char_pos(cha,5,pos)
  write(*,*) pos, '...'//cha//'...'
  go to 1
  
end program tes

subroutine char_pos(cha,l,pos)
! eliminates blank characters of the content of cha (of length l)
! on the right by moving the content to the right, and gives position pos  
! for the first non-blank character on the left
  implicit none
  character(*) cha
  integer l,pos,i2,i1,ii,i

  if(l.eq.1) then
     pos=1 ; return
  end if
  do i2=l,1,-1
     if(cha(i2:i2).ne.' ') exit
  end do
  if(i2.lt.l) then
     do i=i2,1,-1
        ii=i+l-i2
        cha(ii:ii)=cha(i:i) ; cha(i:i)=' '
     end do
  end if
  do i1=1,l
     if(cha(i1:i1).ne.' ') then
        pos=i1 ; exit
     end if
  end do
end subroutine char_pos
