program lev00
!.........................................................................
!..................  This is a post-processing routine    ................
!..................      for DFT codes, such as           ................
!..................           VASP, SIESTA               ................
!.........................................................................
!..................  What it can do:                      ................
!..................  ^^^^^^^^^^^^^^^                      ................
!..................  - total and projected DOS;           ................
!..................  - total or partial charge density    ................
!..................    along lines or in planes           ................
!..................  - integration of charge density      ................
!..................  - manipulation with charge densities ................
!..................  - and a lot, lot more                ................
!.........................................................................
!.................    Started around:         19.08.94    ................
!.................    F90 version started:    30.07.07    ................
!.........................................................................
!.................    Lev.Kantorovitch@kcl.ac.uk          ................
!.........................................................................
!
! the code (SIESTA, VASP, ...) is chosen by user and the dimensions
! for arrays are determined from the corresponding DFT output files 
use param
use atoms
use code
use kpoints
use dos
implicit none
logical Err
character word*14
integer i0,iargc
!
!______check if LEV00 is run under Chimera:
i0=iargc()
if(i0.eq.0) then
   CHIMERA=.false.
   write(*,*)'>>>> CHIMERA is OFF'
else
   call getarg(1,word)
   i0=index(word,'CHIMERA=true') + index(word,'CHIMERA=T') &
                                  + index(word,'CHIMERA=TRUE')    
   if(i0.ne.0) CHIMERA=.true.
   write(*,*)'>>>> CHIMERA is ON'
end if
!
call hat()
!
!............... ask about the code
!
Err=.true. ; yeskp=.false.  ; yesen=.false. ; yesrlx=.false.
do while(Err) 
   call which_PW_code()
   write(*,*) 'The code is '//Which_Code
!
!................read parameters from output files of the DFT codes
!                and do eigenvalues
!
   if(Which_Code=='  VASP') then
      call do_param(Err)
   else if(Which_Code=='SIESTA') then
      call get_param_siesta(Err)
   else if(Which_Code=='QUICKS') then
      call get_param_cp2k(Err)
   end if
end do
NPLWV=NGX*NGY*NGZ

write(*,'(/a)')'=========> Parameters found <=========='
write(*,*) 'Grid               = ',NGX,'x',NGY,'x',NGZ
write(*,*) 'Number of atoms    = ',NIONS
write(*,*) 'Number of species  = ',NSPEC
write(*,*) 'Number of K-points = ',NKPTS
write(*,*) 'Number of bands    = ',NBANDS
if(ispin == 1) then
   write(*,*)'This is NOT spin-polarised calculation'
else if(ispin == 2) then
   write(*,*)'This IS spin-polarised calculation'
else
   write(*,*)'WARNING: spin is NOT recognised; set to no-spin'
   ispin=0
end if
NPLWV=NGX*NGY*NGZ
!
!............. allocate necessary intital memory
!
allocate(TI(3,NIONS))
allocate(QradI(NIONS))
allocate(atom_species(NIONS))
allocate(NspN(NSPEC))
allocate(relax_flag(3,NIONS))
if(Which_Code=='  VASP') allocate(RWIGS(NSPEC))
allocate(VKPT(3,NKPTS)) ; allocate(WTKPT(NKPTS))
allocate(old_to_new(NIONS))
if(Which_Code=='QUICKS') then
   VKPT=0.0 ; WTKPT=1.0
end if
!
!.............. read geometry
!
Err=.true.
do while(Err) 
   if(Which_Code=='  VASP') then
      call read_vasp_geom(Err)
      call get_rwigs(RWIGS)
   else if(Which_Code=='SIESTA') then
      call read_siesta_geom(Err)
   else if(Which_Code=='QUICKS') then
      call read_cp2k_geom(Err)
   end if
end do
deallocate(old_to_new)
!
!.............. if CHIMERA=T, save geom.xyz
!
if(CHIMERA) then
   call create_xyz(0,0,0,0,0,0)
end if
!
!.............. main menu 
!
call mainmenu()
stop "I owe you nothing!"
end program lev00


