      subroutine which_PW_code(Which_Code)
      use real8
      use tetrag1
      implicit none
      character :: Which_Code*6,cha2*2
!
      integer :: l0
!
!................ ask about the code
!

 21   write(*,*)'..................................................'
      write(*,*)'Choose the input format:'
      write(*,*)

      write(*,*)'       1. open input as CASTEP   [ *.geom]'
      write(*,*)'       2. open input as QUICKSTEP (cp2k)'
      write(*,*)'       3. open input as VASP'
      write(*,*)'       4. open input as SIESTA   [ *.fdf ]'
      write(*,*)'       5. open output as SIESTA  [ *.XV  ]'
      write(*,*)'       6. open as XYZ-type file  [ *.xyz ]'
      write(*,*)'       N. NEW or go directly to the main menu'
      write(*,*)'       8. open input as VASP v. 5.2'
      write(*,*)'       9. open input as Quantum Espresso'
      write(*,*)'      10. open input as CRYSTAL'
      write(*,*)'       L. open input as LAMMPS'
      write(*,*)'      LM. open input as LM'
      write(*,*)'       Q. QUIT'
      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

      if(cha2(l0:).eq.'1') then
        Which_Code='CASTEP'
        write(*,*)'Specify seed name (char*',FLEN,') for your CASTEP run:'
        write(*,'(/a)')'**** Input files in the current directory: ***'
        call system('ls *.geom')
        write(*,'(a)')'**********************************************'
        write(*,'(a)')'*  Extention .geom should NOT be specified!  *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'2') then
        Which_Code='QUICKS'
        write(*,*)'Specify LABEL (char*,',FLEN,') for your QUICKSTEP run:'
        write(*,'(/a)')'**** Input files in the current directory: ***'
        call system('ls *.inp ')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '* Extention .inp (if exists) must be given!  *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'3') then
        Which_Code='  VASP'
        write(*,*)'Specify the input filename (char*,',FLEN,') [CONTCAR]:'
        write(*,'(/a)') &
             '**** My guess: input files in the current directory: ***'
        call system('ls *CONTCAR* *POSCAR*')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*        Give the complete file name!        *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        if(seed.eq.'') seed='CONTCAR'
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'8') then
        Which_Code='VASP52'
        write(*,*)'Specify the input filename (char*,',FLEN,') [CONTCAR]:'
        write(*,'(/a)') &
             '**** My guess: input files in the current directory: ***'
        call system('ls *CONTCAR* *POSCAR*')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*        Give the complete file name!        *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        if(seed.eq.'') seed='CONTCAR'
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'4') then
        Which_Code='SIESTA'
        write(*,*)'Specify SYSTEM LABEL (char*,',FLEN,') for your SIESTA run:'
        write(*,'(/a)')'**** Input files in the current directory: ***'
        call system('ls *.fdf ')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*  Extention .fdf should NOT be specified!   *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'5') then
        Which_Code='SIE-XV'
        write(*,*)'Specify SYSTEM LABEL (char*,',FLEN,') for your SIESTA run:'
        write(*,'(/a)')'**** Output files in the current directory: ***'
        call system('ls *.XV')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*   Extention .XV should NOT be specified!   *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'6') then
        Which_Code='   XYZ'
        write(*,*)'Specify file name (char*,',FLEN,') without .xyz:'
        write(*,'(/a)') &
             '**** XYZ-like files in the current directory: ***'
        call system('ls *.xyz')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*  Extention .xyz should NOT be specified!   *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'N') then
        Which_Code='   NEW'
        vscale=1.0
        vtitle='created by tetr'
        how_geometry='fract'
        sel_dyn=.false.
        return

      else if(cha2(l0:).eq.'9') then
        Which_Code='    QE'
        write(*,*)'Specify file name (char*,',FLEN,')'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls .')
        write(*,'(a)') '**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'10') then
        Which_Code='CRYSTL'
        write(*,*)'Specify file name (char*,',FLEN,')'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls .')
        write(*,'(a)') '**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'L') then
        Which_Code='LAMMPS'
        write(*,*)'Specify file name (char*,',FLEN,') '
        write(*,'(a)') '**********************************************'
        write(*,'(/a)') 'Info about LAMMPS input at: http://lammps.sandia.gov/doc/read_data.html'
        write(*,'(/a)') 'IMPORTANT: This code reads only atom_style atomic'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls *.pos')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*        Give the complete file name!        *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'LM') then
        Which_Code='    LM'
        write(*,*)'Specify file name (char*,',FLEN,') '
        write(*,'(a)') '**********************************************'
        write(*,'(/a)') 'Info about LM input at: http://www.lmsuite.org'
        write(*,'(/a)') 'IMPORTANT: This code reads site files ONLY.'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls .')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*        Give the complete file name!        *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed ; write(8,'(a)') trim(seed)
        call right(seed,FLEN,l0seed)
        return

      else if(cha2(l0:).eq.'Q') then
        stop
      else
         write(*,*) "Incorrect item number! Try again!"
      end if
      go to 21
      end subroutine which_PW_code

!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      subroutine ask_which_format(Which_Code,Which_Format,seed1,l0seed1, &
                                                  Mode)
      use real8
      use tetrag1
      implicit none
      character :: Which_Code*6,Which_Format*6,Mode,cha2*2
      character(len=FLEN) :: seed1
!
      integer :: l0,l0seed1
!
!................ ask about the code
!
      Which_Format=Which_Code

 21   write(*,*)'..................................................'
      if(Mode.eq.'R') then
         write(*,*)'READ geometry from one of the following formats:'
      else
         write(*,*) &
        'SAVE/WRITE geometry/k-points in one of the following formats:'
      end if

      write(*,*)

      if(Which_Format.eq.'    MM') then
         write(*,*)'       0. MM input <=== active'
      else
         write(*,*)'       0. MM input'
      end if
      if(Which_Format.eq.'CASTEP') then
         write(*,*)'       1. CASTEP input [*.geom]  <=== active'
      else
         write(*,*)'       1. CASTEP input'
      end if
      if(Which_Format.eq.'QUICKS') then
         write(*,*)'       2. QUICKSTEP input [e.g. *.inp]  <=== active'
      else
         write(*,*)'       2. QUICKSTEP input'
      end if
      if(Which_Format.eq.'  VASP') then
         write(*,*)'       3. VASP input  <=== active'
      else
         write(*,*)'       3. VASP input'
      end if
      if(Which_Format.eq.'SIESTA') then
         write(*,*)'       4. SIESTA input  [*.fdf]   <=== active'
         if(Mode.eq.'R') &
             write(*,*)'       5. SIESTA output [*.XV ]   <=== active'
      else
         write(*,*)'       4. SIESTA input  [*.fdf]'
         if(Mode.eq.'R') write(*,*)'       5. SIESTA output [*.XV ]'
      end if
      write(*,*)'       6. XYZ-type file  [ *.xyz ]'
      if(Which_Format.eq.'VASP52') then
         write(*,*)'       8. VASP v. 5.2 input  <=== active'
      else
         write(*,*)'       8. VASP v. 5.2 input'
      end if
      if(Which_Format.eq.'    QE') then
         write(*,*)'       9. Quantum Espresso input  <=== active'
      else
         write(*,*)'       9. Quantum Espresso input'
      end if
      if(Which_Format.eq.'CRYSTL') then
         write(*,*)'      10. CRYSTAL input  <=== active'
      else
         write(*,*)'      10. CRYSTAL input'
      end if
      if(Which_Format.eq.'LAMMPS') then
         write(*,*)'       L. LAMMPS input  <=== active'
      else
         write(*,*)'       L. LAMMPS input'
      end if
      if(Which_Format.eq.'    LM') then
         write(*,*)'      LM. LM input  <=== active'
      else
         write(*,*)'      LM. LM input'
      end if
!
      if(Which_Code.eq.'CASTEP') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//'.geom [CASTEP]'
         write(*,*)'          Existing file will move to '// &
                                           seed(l0seed:)//'.geom..bak'
      else if(Which_Code.eq.'QUICKS') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [CP2K]'
         write(*,*)'          Existing file will move to '// &
                                           seed(l0seed:)//'.bak'
      else if(Which_Format.eq.'  VASP') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [VASP]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.bak'
      else if(Which_Format.eq.'VASP52') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [VASP_5.2]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.bak'
      else if(Which_Format.eq.'SIESTA') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//'.fdf [SIESTA]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.fdf.bak'
      else if(Which_Format.eq.'   XYZ') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//'.xyz [XYZ]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.xyz.bak'
      else if(Which_Format.eq.'    QE') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [QE]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.bak'
      else if(Which_Format.eq.'CRYSTL') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [CRYSTAL]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.bak'
      else if(Which_Format.eq.'LAMMPS') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [LAMMPS]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.bak'
      else if(Which_Format.eq.'    LM') then
         write(*,*) &
           '       D. Default: file '//seed(l0seed:)//' [LM]'
         write(*,*) &
      '          Existing file will move to '//seed(l0seed:)//'.bak'
      end if

      if(Mode.eq.'R') then
         write(*,*)'       Q. Quit: do NOT read'
      else
         write(*,*)'       Q. Quit: do NOT save'
      end if

      write(*,*)
      write(*,*)'----------> Choose an appropriate option:'
      read(*,'(a)',err=21) cha2 ; write(8,'(a)') cha2
      call right(cha2,2,l0)

      if(cha2(l0:).eq.'1') then
         Which_Format='CASTEP'
 10      write(*,*)'Specify new seed name (char*,',FLEN,'):'
         write(*,*)'**** Input files in the current directory: ***'
         call system('ls *.geom')
         write(*,*)'**********************************************'
         read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
         if(seed1.eq.'') go to 10
         call right(seed1,FLEN,l0seed1)
         return

      else if(cha2(l0:).eq.'2') then
         Which_Format='QUICKS'
 20      write(*,*)'Specify new file name (char*,',FLEN,'):'
         write(*,'(/a)')'**** Input files in the current directory: ***'
         call system('ls *.inp ')
         write(*,'(a)') '**********************************************'
         write(*,'(a)') '*        Give the complete file name!        *'
         write(*,'(a/)')'**********************************************'
         read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
         if(seed1.eq.'') go to 20
         call right(seed1,FLEN,l0seed1)
         return

      else if(cha2(l0:).eq.'3' .or. cha2(l0:).eq.'0' &
                                        .or. cha2(l0:).eq.'8') then
         if(cha2(l0:).eq.'3') then
            Which_Format='  VASP'
         else if(cha2(l0:).eq.'8') then
            Which_Format='VASP52'
         else
            Which_Format='    MM'
         end if
         write(*,*)'Specify new CONTCAR-type file (char*,',FLEN,') [CONTCAR]:'
         write(*,'(/a)') &
             '**** My guess: input files in the current directory: ***'
         call system('ls *CONTCAR* *POSCAR*')
         write(*,'(a)') '**********************************************'
         write(*,'(a)') '*        Give the complete file name!        *'
         write(*,'(a/)')'**********************************************'
         read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
         if(seed1.eq.'') seed1='CONTCAR'
         call right(seed1,FLEN,l0seed1)
         return

      else if(cha2(l0:).eq.'4') then
         Which_Format='SIESTA'
 30      write(*,*)'Specify new SYSTEM LABEL (char*,',FLEN,'):'
         write(*,*)'**** Input files in the current directory: ***'
         call system('ls *.fdf')
         write(*,*)'**********************************************'
         read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
         if(seed1.eq.'') go to 30
         call right(seed1,FLEN,l0seed1)
         return

      else if(cha2(l0:).eq.'5' .and. Mode.eq.'R') then
        Which_Format='SIE-XV'
        write(*,*)'Specify new SYSTEM LABEL (char*,',FLEN,'):'
        write(*,'(/a)')'**** Output files in the current directory: ***'
        call system('ls *.XV')
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
        call right(seed1,FLEN,l0seed1)
        return

      else if(cha2(l0:).eq.'6') then
        Which_Format='   XYZ'
        write(*,*)'Specify file name (char*,',FLEN,') without .xyz:'
        write(*,'(/a)') &
             '**** XYZ-like files in the current directory: ***'
        call system('ls *.xyz')
        write(*,'(a/)') &
             '*************************************************'
        read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
        call right(seed1,FLEN,l0seed1)
        return

      else if(cha2(l0:).eq.'9') then
        Which_Format='    QE'
        write(*,*)'Specify file name (char*,',FLEN,')'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls .')
        write(*,'(a)') '**********************************************'
        read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
        call right(seed1,FLEN,l0seed1)
        return

      else if(cha2(l0:).eq.'10') then
        Which_Format='CRYSTL'
        write(*,*)'Specify file name (char*,',FLEN,')'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls .')
        write(*,'(a)') '**********************************************'
        read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
        call right(seed1,FLEN,l0seed1)
        return

      else if(cha2(l0:).eq.'L') then
        Which_Format='LAMMPS'
        write(*,*)'Specify file name (char*,',FLEN,')'
        write(*,'(/a)') '****  files in the current directory: ***'
        call system('ls *.pos')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*        Give the complete file name!        *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
        print*, 'Your file is: ', seed1
        call right(seed1,FLEN,l0seed1)
        return

      else if(cha2(l0:).eq.'LM') then
        Which_Format='    LM'
        write(*,*)'Specify file name (char*,',FLEN,')'
        write(*,'(/a)') '**** files in the current directory: ***'
        call system('ls .')
        write(*,'(a)') '**********************************************'
        write(*,'(a)') '*        Give the complete file name!        *'
        write(*,'(a/)')'**********************************************'
        read(*,'(a)') seed1 ; write(8,'(a)') trim(seed1)
        print*, 'Your file is: ', seed1
        call right(seed1,FLEN,l0seed1)
        return

      else if(cha2(l0:).eq.'D' .and. Which_Code.ne.'  None') then
        Which_Format=Which_Code
        seed1=seed
        l0seed1=l0seed
        return

      else if(cha2(l0:).eq.'Q') then
         Which_Format='  None'
         return
      else
         write(*,*) "Incorrect item number! Try again!"
      end if
      go to 21
      end subroutine ask_which_format

      subroutine get_N_of_Atoms(Which_Code,seed0,l0seed0,Err)
!..................................................................
!  It asks for:
!     Nsp - number of species in the system;
!     NspN(i) - number of atoms of the given species, i (=1,..,Nsp)
!..................................................................
      use real8
      use tetrag1
      implicit none
      character :: Which_Code*6,answer,Line*200
      character(len=FLEN) :: seed0
      integer :: LinEnd(100),LinPos(100),NumLin
      logical :: Err
!
      integer :: i,l0seed0,iErr
!
!.............. CASTEP/CETEP
!
      if(Which_Code.eq.'CASTEP' .or. Which_Code.eq.' CETEP') then
 1       write(*,*)'Give number of species:'
         read(*,*,err=1) Nsp ; write(8,*) Nsp
         if(Nsp.gt.N0KD.or.Nsp.lt.1) then
            write(*,'(a,i5)')'ERROR! Must be between 1 and ',N0KD
            write(*,*)'Quit (Q,q) or try again (other char)?'
            read(*,'(a)') answer ; write(8,'(a)') answer
            if(answer.eq.'q'.or.answer.eq.'Q') go to 19
         end if
 2       write(*,*)'Give number of atoms in every species:'
         read(*,*,err=2) (NspN(i),i=1,Nsp)
         write(8,*) (NspN(i),i=1,Nsp)
!
!.............. VASP
!
      else if(Which_Code.eq.'  VASP') then
        write(*,*)'Reading from '//seed0(l0seed0:)// &
                                       ' number of atoms in species ...'
        open(14,file=seed0(l0seed0:),status='old',err=19)
        do i=1,5
          read(14,'(a)',err=19) line
        end do
        call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
        Nsp=NumLin
        if(Nsp.gt.N0KD.or.Nsp.lt.1) go to 19
        read(line,*,err=19) (NspN(i),i=1,Nsp)
        write(*,*) (NspN(i),i=1,Nsp)
        close(14)
!
!.............. VASP v. 5.2. Care should be taken here as a line with
!  species symbols may precede the line with NspN for this version of VASP
!
      else if(Which_Code.eq.'VASP52') then
        write(*,*)'Reading from '//seed0(l0seed0:)// &
                                       ' number of atoms in species ...'
        open(14,file=seed0(l0seed0:),status='old',err=19)
        do i=1,5
!          read(14,*,err=19) line ; write(*,*) line
          read(14,*,err=19)
        end do
        call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
        Nsp=NumLin ; write(*,*) 'Nsp = ', Nsp
        if(Nsp.gt.N0KD .or. Nsp.lt.1) go to 19
!        write(*,*) line
        read(line,*,err=10) (NspN(i),i=1,Nsp) ; go to 20
 10     read(14,*,err=19) (NspN(i),i=1,Nsp)
        write(*,*) (NspN(i),i=1,Nsp)
        close(14)
      end if
!
!.............. checking and out
!
 20   ITI=0
      do i=1,Nsp
         ITI=ITI+NspN(i)
      end do
      if(ITI.gt.N0LT) then
         write(*,'(a,i5)')'ERROR! Total # of atoms is > than N0LT=',N0LT
         write(*,'(a)')'Increase N0LT in tetr_param.inc file'
         write(*,'(a)')'                 ^^^^^^^^^^^^^^     '
         go to 19
      end if
      write(*,*)'O.K.! Total number of atoms = ',ITI
      write(*,'(a,10(i3,x))') &
              '      Numbers of atoms in species: ',(NspN(i),i=1,Nsp)
      write(*,*)'Proceeding further ...'
      return
!
!.......... errors
 19   write(*,*)'FATAL! Absent, wrong or inconsistent file'
      Err=.true.
      if(Which_Code.eq.'VASP52'.or. Which_Code.eq.'  VASP') close(14)
      return
      end subroutine get_N_of_Atoms

      subroutine check_atoms(nat,good)
!.............................................................
! checks if atom nat is equivalent to any of k=1,...,nat-1
!.............................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: r(3)
      logical ::good,ask_equiv
!
      integer :: nat,k

      good=.true.
      if(nat.gt.1) then
         do k=1,nat-1
            r(1:3)=TI(1:3,k)-TI(1:3,nat)
            if(ask_equiv(r,BJ,3,tiny_equiv)) then
               write(*,'(a)') 'WARNING! Equivalent atom found!'
               good=.false.
            end if
         end do
      end if
      end subroutine check_atoms

      subroutine get_geometry(Which_Code,seed0,l0seed0,Err)
!..................................................................
!  Reads the geometry file of CASTEP/CETEP/VASP to get:
!  AJ  - direct lattice vectors;
!  TI  - sublattices: they are stored in one array for all species,
!        one after another;
!  ITI - number of sublattices, i.e. total number of atoms in your
!        cell.
!..................................................................
      use real8
      use tetrag1
      implicit none
      real(8) :: r(3)
      character :: Which_Code*6,Line*200
      character(len=FLEN) :: seed0
      integer :: LinEnd(100),LinPos(100),NumLin
      logical :: good,Err
!
      integer :: i,k,nat,iErr,j,nt,i0,i2,j1,i1,j0,j2,NspN1,ITI1,Nsp1
      integer :: l0seed0,is,is1
      real(8) ::  r1,r2,r3
!
!.............. CASTEP / old CASTEP / CETEP
!
      IF(Which_Code.eq.'CASTEP'.or. Which_Code.eq.' CETEP') THEN
         if(Which_Code.eq.'CASTEP') then
            write(*,*) &
                 'Reading from '//seed0(l0seed0:)//'.geom geometry ...'
            open(15,file=seed0(l0seed0:)//'.geom',form='formatted', &
                 status='old',err=100)
         else
            write(*,*)'Reading from fort.15 geometry  ...'
            open(15,file='fort.15',status='old',form='formatted', &
                 err=100)
         end if
         read (15,*,err=100,end=100) AJ(1,1), AJ(2,1), AJ(3,1)
         read (15,*,err=100,end=100) AJ(1,2), AJ(2,2), AJ(3,2)
         read (15,*,err=100,end=100) AJ(1,3), AJ(2,3), AJ(3,3)
         read (15,*,err=100,end=100)  r1,r2,r3
         read (15,*,err=100,end=100)  r1,r2,r3
         read (15,*,err=100,end=100)  r1,r2,r3
         call INVER(AJ,BJ)
         nat=0
         do i=1,Nsp
            do k=1,NspN(i)
               nat=nat+1
               call CutStr(Line,NumLin,LinPos,LinEnd,15,0,iErr)
               if(iErr.eq.1.or.NumLin.lt.3) then
                  go to 100
               else if(NumLin.eq.3) then
                  read(Line(LinPos(1):LinEnd(3)),*,err=100) (r(j),j=1,3)
                  relax_flag(1,nat)='F'
               else
                  read(Line(LinPos(1):LinEnd(4)),*,err=100) &
                                                         (r(j),j=1,3),r1
                  if(r1.eq.0) then
                     relax_flag(1,nat)='F'
                     relax_flag(2,nat)='F'
                     relax_flag(3,nat)='F'
                  else
                     relax_flag(1,nat)='T'
                     relax_flag(2,nat)='T'
                     relax_flag(3,nat)='T'
                  end if
               end if
               TI(1,nat)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
               TI(2,nat)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
               TI(3,nat)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
               call check_atoms(nat,good)
            end do
            do k=1,NspN(i)
               call CutStr(Line,NumLin,LinPos,LinEnd,15,0,iErr)
               if(iErr.eq.1.or.NumLin.lt.3) then
                  go to 100
               else
                  read (Line,*,err=100,end=100) r1,r2,r3
               end if
            end do
         end do
!
!.............. VASP and VASP52
!
      ELSE IF(Which_Code.eq.'  VASP' .or. Which_Code.eq.'VASP52') THEN
!__________________________ reading geometry
         write(*,*)'Reading geometry from '//seed0(l0seed0:)//' ...'
         open (15,file=seed0(l0seed0:),status='old',FORM='FORMATTED', &
                                                              err=200)
         read(15,'(a)',err=200,end=200) vtitle
         write(*,*) vtitle
         read(15,*) vscale
         read (15,*,err=200,end=200) AJ(1,1), AJ(1,2), AJ(1,3)
         read (15,*,err=200,end=200) AJ(2,1), AJ(2,2), AJ(2,3)
         read (15,*,err=200,end=200) AJ(3,1), AJ(3,2), AJ(3,3)
         AJ=AJ*vscale ;  nat=0 ; nt=0
         call INVER(AJ,BJ)
         if(Which_Code.eq.'VASP52') then
            call ask_species(Nsp,Species,15,Err)
            if(Err) go to 200
         end if
         ITI=0
         do i=1,Nsp
            ITI=ITI+NspN(i)
         end do
 10      read(15,'(a)',err=200,end=200) line
         i0=index(line,'Cart')   ; i1=index(line,'cart') ;
         i2=index(line,'CART')   ; j0=index(line,'direct')
         j1=index(line,'Direct') ; j2=index(line,'DIRECT')
         if(i0.ne.0 .or. i1.ne.0 .or. i2.ne.0 ) then
            how_geometry='carte'
            write(*,'(a)') &
            '... implying Cartesian format, reading in ...'
            do i=1,Nsp
               NspN1=NspN(i)
               do k=1,NspN1
                  nat=nat+1 ; nt=nt+1
                  call CutStr(Line,NumLin,LinPos,LinEnd,15,0,iErr)
                  if(iErr.eq.1.or.NumLin.lt.3) go to 200
                  read(Line(LinPos(1):LinEnd(3)),*,err=200) &
                                           (TI(j,nat),j=1,3)
                  TI(1:3,nat)=vscale*TI(1:3,nat)
!__________ check the atomic position; reject if equaivalent
                  call check_atoms(nat,good)
                  if(.not.good) then
                     write(*,'(a,i3,a)')'... skipping atom ',nt,' ...'
                     nat=nat-1 ; NspN(i)=NspN(i)-1 ; go to 11
                  end if
!__________ proceed if accepted
                  if(NumLin.eq.6) then
                     sel_dyn=.true.
                     read(Line(LinPos(4):LinEnd(4)),'(a)',err=200) &
                          relax_flag(1,nat)
                     read(Line(LinPos(5):LinEnd(5)),'(a)',err=200) &
                          relax_flag(2,nat)
                     read(Line(LinPos(6):LinEnd(6)),'(a)',err=200) &
                          relax_flag(3,nat)
                  else
                     sel_dyn=.false. ; relax_flag(1:3,nat)='F'
                  end if
 11            end do
            end do
         else if(j0.ne.0 .or. j1.ne.0 .or. j2.ne.0 ) then
            how_geometry='fract'
            write(*,'(a)') &
                 '... implying fractional format, reading in ...'
            do i=1,Nsp
               NspN1=NspN(i)
               do k=1,NspN1
                  nat=nat+1; nt=nt+1
                  call CutStr(Line,NumLin,LinPos,LinEnd,15,0,iErr)
                  if(iErr.eq.1.or.NumLin.lt.3) go to 200
                  read(Line(LinPos(1):LinEnd(3)),*,err=200) (r(j),j=1,3)
                  TI(1,nat)=r(1)*AJ(1,1)+r(2)*AJ(2,1)+r(3)*AJ(3,1)
                  TI(2,nat)=r(1)*AJ(1,2)+r(2)*AJ(2,2)+r(3)*AJ(3,2)
                  TI(3,nat)=r(1)*AJ(1,3)+r(2)*AJ(2,3)+r(3)*AJ(3,3)
!__________ check the atomic position; reject if equaivalent
                  call check_atoms(nat,good)
                  if(.not.good) then
                     write(*,'(a,i3,a)')'... skipping atom ',nt,' ...'
                     nat=nat-1 ; NspN(i)=NspN(i)-1 ; go to 13
                  end if
!__________ proceed if accepted
                  if(NumLin.eq.6) then
                     sel_dyn=.true.
                     read(Line(LinPos(4):LinEnd(4)),'(a)',err=200) &
                          relax_flag(1,nat)
                     read(Line(LinPos(5):LinEnd(5)),'(a)',err=200) &
                          relax_flag(2,nat)
                     read(Line(LinPos(6):LinEnd(6)),'(a)',err=200) &
                          relax_flag(3,nat)
                  else
                     sel_dyn=.false. ; relax_flag(1:3,nat)='F'
                  end if
 13            end do
            end do
         else
            go to 10
         end if
!
!____________ dealing with the case if due to equivalence of atoms
!             the whole species has gone
         ITI1=0
         do i=1,Nsp
            ITI1=ITI1+NspN(i)
         end do
         if(ITI1.ne.ITI) then
            ITI=ITI1 ; Nsp1=Nsp
            write(*,*) &
               'WARNING: Equivalent atoms were found: new total = ',ITI
            is=0
 15         is=is+1
            if(NspN(is).eq.0) then
               if(Which_Code.eq.'VASP52') then
                  write(*,*) &
                       'WARNING: species '//Species(is)//' has gone!'
               else
                  write(*,*) 'WARNING: species # ',is,' has gone!'
               end if
               if(Nsp1.gt.is) then
                  do is1=is+1,Nsp
                     NspN(is1-1)=NspN(is1) ; Species(is1-1)=Species(is1)
                  end do
               end if
               Nsp1=Nsp1-1
            end if
            if(is.lt.Nsp1) go to 15
            Nsp=Nsp1
         end if
         if(Which_Code.eq.'VASP52') then
            write(*,'(a,10(2a,i5,a,x))') &
        'VASP: found species = ',(Species(i),' [',NspN(i),']  ',i=1,Nsp)
         else
            write(*,'(a,10(i3,x,a,i5,a,x))') &
                 'VASP: found species = ',(i,' [',NspN(i),']  ',i=1,Nsp)
         end if
!
!........ other codes???
!
      END IF
      write(*,*)'Done geometry!'
!
!............. finishing
!
      close (15)
      write(*,*) &
        'O.K.! This seed.geom/fort.15/CONTCAR is fine! Let us proceed!'
      write(*,*) &
              '........> Total number of atoms in the cell is ',ITI
!
!___________ show atoms
!
      nat=0
      do i=1,Nsp
         write(*,'(a25,i3,a8)')'______> Atoms in species ',i,' <______'
         do k=1,NspN(i)
            nat=nat+1
            write(*,'(i5,5x,3(f10.5,1x),3x,3(a,x))') &
                 nat,(TI(j,nat),j=1,3),(relax_flag(j,nat),j=1,3)
         end do
      end do
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']  ',(AJ(i,j),j=1,3)
      end do
      return
!
!......... errors
 100  write(*,*)'FATAL! The seed.geom/fort.15 file is bad or absent!'
      Err=.true. ; close(15) ; return
 200  write(*,*)'FATAL! File '//seed0(l0seed0:)//' is bad or absent!'
      Err=.true. ; close(15) ; return
      end subroutine get_geometry

      subroutine get_all_from_CRYSTAL(seed0,l0seed0,Err)
!.................................................................
!  reading CRYSTAL input file (simplified): no account of symmetry
!  [only a single trivial symetry operation assumed]
!.................................................................
      use real8
      use tetrag1
      use mendeleev
      implicit none
      character(len=FLEN) :: seed0
      character :: spec(N0LT)*2
      logical :: Err,Errr
      real(8) :: TI1(3,N0LT)
      integer :: isp(N0LT),mendl(N0LT)
!
      integer :: i,j,iRot,nat,ni,k,l0seed0

      write(*,*) 'Reading from '//seed0(l0seed0:)//' ...'
      open(14,file=seed0(l0seed0:),form='formatted', &
                 status='old',err=19)
      read(14,*)

!.......... lattice vectors
      read (14,*,err=19,end=19) AJ(1,1), AJ(1,2), AJ(1,3)
      read (14,*,err=19,end=19) AJ(2,1), AJ(2,2), AJ(2,3)
      read (14,*,err=19,end=19) AJ(3,1), AJ(3,2), AJ(3,3)
      write(*,*)'CRYSTAL: found lattice vectors:'
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
      end do
      call INVER(AJ,BJ)
      vscale=1.0

!........... skip rotational elements
      read(14,*) iRot
      do i=1,iRot
         do j=1,4
            read(14,*)
         end do
      end do

!........... read atomic positions
      read(14,*) ITI
      Nsp=1 ; Errr=.false.
      do nat=1,ITI
         read(14,*,err=20,end=20) mendl(nat),(TI(j,nat),j=1,3)
         if(mendl(nat).le.112.and.mendl(nat).ge.1) then
            spec(nat)=NAZV(mendl(nat))
            if(spec(nat).eq.'  ') Errr=.true.
         else
            Errr=.true.
         end if
         if(nat.eq.1) then
            isp(1)=1 ; Species(Nsp)=spec(1)
         else
            do i=1,nat-1
               if(spec(i).eq.spec(nat)) then
                  isp(nat)=isp(i)
                  go to 10
               end if
            end do
            Nsp=Nsp+1
            isp(nat)=Nsp ; Species(Nsp)=spec(nat)
         end if
 10   end do

      if(Errr) go to 20
      write(*,*)'CRYSTAL: found Nsp = ',Nsp
      write(*,*)'CRYSTAL: found species:'
      write(*,'(10(a,a2,a,3x))') ('(',Species(i),')',i=1,Nsp)

!__________ sorting atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
      k=0
      do i=1,Nsp
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.i) then
               ni=ni+1 ; k=k+1
               TI1(1:3,k)=TI(1:3,nat)
            end if
         end do
         NspN(i)=ni
      end do
      TI=TI1
      write(*,'(a,10(i5,x))')'XYZ: found NspN = ',(NspN(i),i=1,Nsp)
      write(*,*)'Done atomic positions!'
      close (14)
      return
!
!......... errors
 19   write(*,*)'FATAL! Absent input file!'
      Err=.true.
      return
 20   write(*,*)'FATAL! Cannot recognize the format!'
 21   Err=.true.
      end subroutine get_all_from_CRYSTAL

      subroutine get_all_from_LAMMPS(seed0,l0seed0,Err)
!.................................................................
!  reading LAMMPS input file (simplified): no account of symmetry
!  [only a single trivial symetry operation assumed]
!.................................................................
      use real8
      use tetrag1
      use mendeleev
      implicit none
      character(len=FLEN) :: seed0
      logical :: Err
!
      integer :: l0seed0,i,j,nat,is,iErr,kk,mendl,ii
      real(8) :: xlo,ylo,zlo,xhi,yhi,zhi,xy,xz,yz

      write(*,*) 'Reading from '//seed0(l0seed0:)//' ...'
      open(14,file=seed0(l0seed0:),form='formatted', &
                 status='old',err=19)
      read(14,*,err=19,end=19)
      read(14,*,err=20,end=20) ITI
      print*, 'Total number of atoms = ',ITI
      read(14,*,err=20,end=20) Nsp
      print*, 'Total number of species = ',Nsp

      call SkipL(14,iErr)

!.......... lattice vectors
 13   read (14,*,err=20,end=20) xlo, xhi
 14   read (14,*,err=20,end=20) ylo, yhi
      read (14,*,err=20,end=20) zlo, zhi
      read (14,*,err=20,end=20) xy, xz, yz
      AJ(1,1)= xhi-xlo  ; AJ(1,2)= 0.000000  ; AJ(1,3)= 0.000000
      AJ(2,1)= xy ; AJ(2,2)= yhi-ylo ; AJ(2,3)= 0.000000
      AJ(3,1)= xz ; AJ(3,2)= yz ; AJ(3,3)= zhi-zlo

      write(*,*)'LAMMPS: found lattice vectors:'
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
      end do
      call INVER(AJ,BJ)

!........... read atomic positions
      call SkipL(14,iErr)
      read(14,*,err=20,end=20) lkeyword
      if (lkeyword.eq.'Atoms') then
         go to 12
      else
         go to 20
      end if
 12   read(14,*,err=20,end=20)

      nat=1 ; NspN(1)=0 ; is=1
 131  read(14,*,err=20,end=20) ii,kk,(TI(j,nat),j=1,3)
      if(kk.eq.is) then
         NspN(is)=NspN(is)+1
      else
         is=is+1 ; NspN(is)=1
      end if
      nat=nat+1
      if(nat.le.ITI) go to 131

!......... manually read atomic species

      write(*,*) "Give atomic number"
      do is=1,Nsp
 23      write(*,'(a12,1x,I0,1x,a1)') 'Species no. ',is, ':'
         read(*,*,err=23) mendl ; write(8,*) mendl
         if(mendl.le.112.and.mendl.ge.1) then
            Species(is)=NAZV(mendl)
         else
            go to 23
         end if
      end do

      write(*,*)'LAMMPS: Found Nsp = ',Nsp
      write(*,'(a,10(i5,x))')'LAMMPS: Found NspN = ',(NspN(i),i=1,Nsp)
      write(*,*)'LAMMPS: Found species:'
      write(*,'(10(a,a2,a,3x))') ('(',Species(i),')',i=1,Nsp)
      write(*,*)'Done atomic positions!'

 15   close (14)
      return
!
!......... errors
 19   write(*,*)'FATAL! Absent input file!'
      Err=.true.
      return
 20   write(*,*)'FATAL! Cannot recognize the format!'
 21   Err=.true.
      end subroutine get_all_from_LAMMPS

       subroutine get_all_from_SIESTA(seed0,l0seed0,Err)
!.................................................................
!  reading SIESTA input file (a little bit simplified)
!.................................................................
      use real8
      use tetrag1
      use mendeleev
      use siesta
      implicit none
      character :: Line*200
      character(len=FLEN) :: seed0
      integer :: LinEnd(100),LinPos(100),NumLin
      integer :: old_to_new(N0LT)
      logical :: good,Err
      real(8) :: TI1(3,N0LT),r(3)
      integer :: isp(N0LT)
!
      integer :: iErr,iLi,ITI1,i,i1,m1,j,i2,i0,nat,nt,k
      integer :: ni,is,l0seed0,is1,Nsp1

      write(*,*) 'Reading from '//seed0(l0seed0:)//'.fdf  ...'
      open(14,file=seed0(l0seed0:)//'.fdf',form='formatted', &
                 status='old',err=19)

!_________ reading SystemLabel
      call find_string('SystemLabel',11,14,Line,iErr)
      if(iErr.eq.1) then
         write(*,*)'ERROR: system label not found'
         go to 1
      end if
      call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
      if(iErr.eq.1.or.NumLin.lt.2) go to 19
      iLi=LinEnd(2)-LinPos(2)+1
      if(iLi.gt.50) then
         write(*,*)'ERROR: system label is too long (> 50)!'
         go to 1
      end if
      isysl0=50-iLi+1
      SystemLabel(isysl0:)=Line(LinPos(2):LinEnd(2))
      go to 5
 1    write(*,*)'WARNING: SystemLabel is set to TEMP'
      isysl0=47 ; SystemLabel(isysl0:)='TEMP'

!_________ reading the number of species
 5    rewind (14)
      call find_string('NumberOfSpecies',15,14,Line,iErr)
      if(iErr.eq.1) then
         write(*,*)'ERROR: number of species'
         go to 19
      end if
      call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
      if(iErr.eq.1.or.NumLin.lt.2) go to 19
      read(Line(LinPos(2):LinEnd(2)),*,err=19) Nsp1
      if(Nsp1.lt.1 .or. Nsp1.gt.N0KD) then
         write(*,*) &
            'ERROR! Number of species > N0KD=',N0KD,' in tetr_param.inc'
         go to 19
      end if
      write(*,*)'SIESTA: found Nsp = ',Nsp1

!_________ reading the number of atoms
      rewind (14)
      call find_string('NumberOfAtoms',13,14,Line,iErr)
      if(iErr.eq.1) then
         write(*,*)'ERROR: number of atoms'
         go to 19
      end if
      call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
      if(iErr.eq.1.or.NumLin.lt.2) go to 19
      read(Line(LinPos(2):LinEnd(2)),*,err=19) ITI1
      write(*,*)'SIESTA: found ITI = ',ITI1
      if(ITI1.gt.N0LT) then
         write(*,*) &
            'ERROR! Number of atoms > N0LT=',N0LT,' in tetr_param.inc'
         go to 19
      end if

!_________ reading chemical species
      rewind (14)
      call find_string('%block ChemicalSpeciesLabel',27,14,Line,iErr)
      if(iErr.eq.1) go to 19
      do i=1,Nsp1
         read(14,*,err=19,end=19) i1,m1
         if(i1.eq.i) then
            if(m1.le.112) then
               Species(i)=NAZV(m1)
            else
               Species(i)='XX'
            end if
         else
            write(*,*)'ERROR(chem.spec.) in '//seed0(l0seed0:)//'.fdf'
            go to 19
         end if
      end do
      write(*,*)'SIESTA: found species:'
      write(*,'(10(a,a2,a,3x))') ('(',Species(i),')',i=1,Nsp1)

!_________ reading lattice constant
      rewind (14)
      write(*,*) &
           'Reading from '//seed0(l0seed0:)//'.fdf lattice constant ...'
      call find_string('LatticeConstant',15,14,Line,iErr)
      call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
      if(iErr.eq.1) then
         vscale=1.0
      else
         read (Line(LinPos(2):LinEnd(2)),*,err=19,end=19) vscale
      end if

!_________ reading lattice vectors
      rewind (14)
      write(*,*) 'Reading from '//seed0(l0seed0:)//'.fdf geometry ...'
      call find_string('%block LatticeVectors',21,14,Line,iErr)
      if(iErr.eq.1) go to 19
      read (14,*,err=19,end=19) AJ(1,1), AJ(1,2), AJ(1,3)
      read (14,*,err=19,end=19) AJ(2,1), AJ(2,2), AJ(2,3)
      read (14,*,err=19,end=19) AJ(3,1), AJ(3,2), AJ(3,3)
      write(*,*)'SIESTA: found lattice vectors:'
      do i=1,3
         AJ(i,1:3)=AJ(i,1:3)*vscale
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
      end do
      call INVER(AJ,BJ)

!_________ reading format
      rewind (14)
      call find_string('AtomicCoordinatesFormat',22,14,Line,iErr)
      if(iErr.eq.1) then
         write(*,*)'SIESTA: have not found format, implying Ang'
         i1=1
      else
         call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
         if(iErr.eq.1.or.NumLin.lt.2) go to 19
         i0=index(Line(LinPos(2):LinEnd(2)),'Cartesian')
         i1=index(Line(LinPos(2):LinEnd(2)),'Ang')
         i2=index(Line(LinPos(2):LinEnd(2)),'Bohr')
      end if
      if(i0.ne.0 .or. i1.ne.0 .or. i2.ne.0) then
         write(*,'(a)') &
              'SIESTA: implying Cartesian format, reading in ...'
      else
         write(*,'(a)') &
          'SIESTA: implying fractionional format, reading in ...'
      end if

!_________ reading geometry as it is in the input
      rewind (14)
      call find_string('%block AtomicCoordinatesAndAtomicSpecies', &
           40,14,Line,iErr)
      if(iErr.eq.1) then
         write(*,*)'ERROR: no atomic coordinates'
         go to 19
      end if
      nat=0 ; ITI=ITI1
      do nt=1,ITI1
         nat=nat+1
         if(i0.ne.0 .or. i1.ne.0 .or. i2.ne.0) then
            read(14,*,err=19,end=19) (TI(j,nat),j=1,3),isp(nat)
            TI(1:3,nat)=TI(1:3,nat)*vscale
         else
            read(14,*,err=19,end=19) (r(j),j=1,3),isp(nat)
            TI(1:3,nat)=r(1)*AJ(1,1:3)+r(2)*AJ(2,1:3)+r(3)*AJ(3,1:3)
         end if
!__________ check the atomic position; reject if equaivalent
         call check_atoms(nat,good)
         if(.not.good) then
            write(*,'(a,i3,a)')'... skipping atom ',nt,' ...'
            nat=nat-1 ; ITI=ITI-1
         end if
!__________ proceed if accepted
      end do
      if(ITI.ne.ITI1) then
         write(*,*) 'WARNING: found equivalent atoms; new total = ',ITI
         write(*,*) 'WARNING: Constrains (if exist) may be WRONG'
         write(*,*) 'Press ENTER when ready ...'
         read(*,*) ; write(8,'(a)') 'PressEnter'
      end if
!__________ sorting atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
      k=0
      do is=1,Nsp1
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.is) then
               ni=ni+1 ; k=k+1 ; TI1(1:3,k)=TI(1:3,nat)
               old_to_new(nat)=k
            end if
         end do
         NspN(is)=ni
      end do
      good=.true. ; if(k.ne.ITI) good=.false.
      TI(1:3,1:ITI)=TI1(1:3,1:ITI)
      write(*,'(a,10(i5,x))')'SIESTA: found NspN = ',(NspN(i),i=1,Nsp1)

!__________ renumber species if some are missing (after eliminating
!           equivalent atoms)
      is=0
 10   is=is+1
      if(NspN(is).eq.0) then
         write(*,*)'WARNING: species '//Species(is)//' has gone!'
         if(Nsp1.gt.is) then
            do is1=is+1,Nsp1
               NspN(is1-1)=NspN(is1) ; Species(is1-1)=Species(is1)
            end do
         end if
         Nsp1=Nsp1-1
      end if
      if(is.lt.Nsp1) go to 10
      Nsp=Nsp1
!__________ print at this stage

      write(*,'(a)')'WARNING: atoms have been ordered by species!'
      write(*,'(a,10(i5,x))')'SIESTA: found NspN = ',(NspN(i),i=1,Nsp)
      write(*,*)'Done geometry!'
!
!___________ reading geometry constraints
!
      call get_relax_flags_SIESTA(14,ITI,relax_flag,old_to_new)
!
!............. reading irrelevant stuff  and finishing
!
 20   if(nlines.eq.0) call get_rest_from_SIESTA(ITI1,Nsp1,14)
      close (14)

      if(good) then
         write(*,*) 'O.K.! This '//seed0(l0seed0:) &
                                //'.fdf is fine! Let us proceed!'
         write(*,*) &
              '........> Total number of atoms in the cell is ',ITI
      else
         write(*,*)'FATAL! Problems with sorting atoms'
         Err=.true. ; return
      end if
!
!___________ show atoms
!
      nat=0
      do i=1,Nsp
        write(*,'(a25,i3,a8)')'______> Atoms in species ',i,' <______'
        do k=1,NspN(i)
          nat=nat+1
          write(*,'(i5,5x,3(f10.5,1x),3x,3(a,x))') &
               nat,(TI(j,nat),j=1,3),(relax_flag(j,nat),j=1,3)
        end do
      end do
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']  ',(AJ(i,j),j=1,3)
      end do
      return
!
!......... errors
 19   write(*,*)'FATAL! Bad or absent SIESTA input file!'
      Err=.true.
      return
      end subroutine get_all_from_SIESTA

      subroutine get_rest_from_SIESTA(ITI1,Nsp1,nunit)
!.................................................................
! read and store all irrelevant information from SIESTA input
! Nsp1, ITI1 - corresond to the values in the original file
!              which may contain equivalent atoms (and hence the
!              actual Nsp and ITI will be smaller)
!.................................................................
!     implicit none
      use siesta
      implicit none
      character :: line*200
!
      integer nunit,ITI1,Nsp1,i,nat,iErr

      rewind (nunit)
 1    read(nunit,'(a)',end=100) line
      if(index(line,'SystemLabel').ne.0) then
         go to 1
      else if(index(line,'NumberOfSpecies').ne.0) then
         go to 1
      else if(index(line,'NumberOfAtoms').ne.0) then
         go to 1
      else if(index(line,'%block ChemicalSpeciesLabel').ne.0) then
         do i=1,Nsp1+1
            read(nunit,'(a)') line
         end do
         go to 1
      else if(index(line,'LatticeConstant').ne.0) then
         go to 1
      else if(index(line,'%block LatticeVectors').ne.0) then
         do i=1,4
            read(nunit,'(a)') line
         end do
         go to 1
      else if(index(line,'AtomicCoordinatesFormat').ne.0) then
         go to 1
      else if(index(line, &
            '%block AtomicCoordinatesAndAtomicSpecies').ne.0) then
         do nat=1,ITI1+1
            read(nunit,'(a)') line
         end do
         go to 1
      else if(index(line,'%block GeometryConstraints').ne.0) then
 10      read(nunit,'(a)') line
         if(index(Line(1:9),'%endblock').ne.0) go to 1
         go to 10
      else
         call add_to_lines(line,iErr) ; if(iErr.eq.1) go to 100
         go to 1
      end if
 100  write(*,*) 'found ',nlines,' extra lines in the SIESTA input'

      return
      end subroutine get_rest_from_SIESTA

      subroutine get_all_from_SIESTAXV(seed0,l0seed0,Err)
!.................................................................
!  reading SIESTA output geometry file seed.XV
!.................................................................
!     It is assumed that coordinates are given in SIESTA in a.u.,
! so that we convert them back to A.
!.................................................................
      use real8
      use tetrag1
      use mendeleev
      implicit none
      character(len=FLEN) :: seed0
      logical :: good,Err
      real(8) :: TI1(3,N0LT),r(3)
      integer :: isp(N0LT),mendl(N0LT)
      real(8),parameter :: au_A=1.889725989
!
      integer :: l0seed0,i,j,nat,nt,k,ni

      write(*,*) 'Reading from '//seed0(l0seed0:)//'.XV  ...'
      open(14,file=seed0(l0seed0:)//'.XV',form='formatted', &
                 status='old',err=19)

!_________ reading lattice vectors
      write(*,*) 'Reading from '//seed0(l0seed0:)//'.XV geometry ...'
      read (14,*,err=19,end=19) AJ(1,1), AJ(1,2), AJ(1,3)
      read (14,*,err=19,end=19) AJ(2,1), AJ(2,2), AJ(2,3)
      read (14,*,err=19,end=19) AJ(3,1), AJ(3,2), AJ(3,3)
      AJ=AJ/au_A
      write(*,*)'SIESTA: found lattice vectors:'
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
      end do
      call INVER(AJ,BJ)

!_________ reading the number of atoms
      read(14,*) ITI
      write(*,*)'SIESTA: found ITI = ',ITI
      if(ITI.gt.N0LT) then
         write(*,*) &
            'ERROR! Number of atoms > N0LT=',N0LT,' in tetr_param.inc'
         go to 19
      end if

!_________ reading geometry as it is in the input
      Nsp=1 ; nat=0 ; nt=0
 10   nat=nat+1 ; nt=nt+1
      if(nat.gt.ITI) go to 11
      read(14,*,err=19) isp(nat),mendl(nat),(r(j),j=1,3)
      TI(1:3,nat)=r(1:3)/au_A
!__________ check the atomic position; reject if equaivalent
      call check_atoms(nat,good)
      if(.not.good) then
         write(*,'(a,i3,a)')'... skipping atom ',nt,' ...'
         nat=nat-1 ; go to 10
      end if
!__________ proceed if accepted
      if(isp(nat).gt.Nsp) Nsp=isp(nat)
      if(mendl(nat).gt.112) then
         Species(isp(nat))='XX'
      else
         Species(isp(nat))=NAZV(mendl(nat))
      end if
      go to 10
 11   write(*,*)'SIESTA: found Nsp = ',Nsp
      write(*,*)'SIESTA: found species:'
      write(*,'(10(a,a2,a,3x))') ('(',Species(i),')',i=1,Nsp)

!__________ sorting atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
      k=0 ; good=.true.
      do i=1,Nsp
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.i) then
               ni=ni+1 ; k=k+1 ; TI1(1:3,k)=TI(1:3,nat)
            end if
         end do
         NspN(i)=ni
      end do
      if(k.ne.ITI) good=.false.
      TI(1:3,1:ITI)=TI1(1:3,1:ITI)
      write(*,'(a,10(i5,x))')'SIESTA: found NspN = ',(NspN(i),i=1,Nsp)
      write(*,*)'Done geometry!'
!
!............. finishing
!
      close (14)
      if(good) then
         vscale=1.0
         write(*,*) 'O.K.! This '//seed0(l0seed0:) &
                                //'.XV is fine! Let us proceed!'
         write(*,*) &
              '........> Total number of atoms in the cell is ',ITI
      else
         write(*,*)'FATAL! Bad input or error in sorting atoms!'
         Err=.true. ; return
      end if
!
!___________ show atoms
!
      nat=0
      do i=1,Nsp
        write(*,'(a25,i3,a8)')'______> Atoms in species ',i,' <______'
        do k=1,NspN(i)
          nat=nat+1
          write(*,'(i5,5x,3(f10.5,1x),3x,3(a,x))') &
               nat,(TI(j,nat),j=1,3),(relax_flag(j,nat),j=1,3)
        end do
      end do
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']  ',(AJ(i,j),j=1,3)
      end do
      return
!
!......... errors
 19   write(*,*)'FATAL! Bad or absent SIESTA output file!'
      Err=.true.
      end subroutine get_all_from_SIESTAXV

      subroutine read_xyz(seed0,l0seed0,Err)
!................................................................
! write geom.xyz file for XMOL
!................................................................
      use real8
      use tetrag1
      use mendeleev
      implicit none
      character(len=FLEN) :: seed0
      character :: YES_xyz*4,spec(N0LT)*2,line*200
      integer :: mendl(N0LT),isp(N0LT)
      real(8) :: TI1(3,N0LT),rmin(3),rmax(3)
      real(8) :: dim(3)
      integer :: LinEnd(100),LinPos(100),NumLin
      logical :: Err,Errr
      real(8),parameter :: tiny=0.0001
!
      integer :: l0seed0,nat,lin,j,i,k,ni,iErr

!__________ open xyz file

      write(*,*) 'Reading from '//seed0(l0seed0:)//'.xyz  ...'
      open(14,file=seed0(l0seed0:)//'.xyz',form='formatted', &
                 status='old',err=19)

      YES_xyz='Xmol'
 1    write(*,*)'...trying '//YES_xyz//' format ....'

!___________ read number of atoms
      if(YES_xyz.eq.'Xmol') then
         read(14,*,err=100,end=100) ITI
      else if(YES_xyz.eq.'Ymol') then
         read(14,*,err=20,end=20) ITI
      end if
      if(ITI.gt.N0LT) then
         write(*,*) &
            'ERROR! Number of atoms > N0LT=',N0LT,' in tetr_param.inc'
         go to 21
      end if
      if(ITI.lt.1) go to 100
      write(*,*)'XYZ: found ITI = ',ITI

!________ read the title
      read(14,'(a)') Line
      write(*,*) Line

!_________ reading geometry as it is in the input
      Nsp=1
      do nat=1,ITI

         if(YES_xyz.eq.'Xmol') then
            call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
            if(iErr.ne.0 .and. NumLin.lt.4) go to 100
            lin=LinEnd(1)-LinPos(1)+1
            if(lin.eq.1) then
               spec(nat)=' '//Line(LinPos(1):LinEnd(1))
            else if(lin.eq.2) then
               spec(nat)=Line(LinPos(1):LinEnd(1))
            else
               go to 100
            end if
            call check_Mendel(spec(nat),mendl(nat),Errr,.true.)
            read(Line(LinPos(2):),*,err=100,end=100) (TI(j,nat),j=1,3)
         else if(YES_xyz.eq.'Ymol') then
            read(14,*,err=20,end=20) mendl(nat),(TI(j,nat),j=1,3)
            if(mendl(nat).le.112.and.mendl(nat).ge.1) then
               spec(nat)=NAZV(mendl(nat))
               if(spec(nat).eq.'  ') Errr=.true.
            else
               Errr=.true.
            end if
         end if

         if(nat.eq.1) then
            isp(1)=1 ; Species(Nsp)=spec(1)
         else
            do i=1,nat-1
               if(spec(i).eq.spec(nat)) then
                  isp(nat)=isp(i)
                  go to 10
               end if
            end do
            Nsp=Nsp+1
            isp(nat)=Nsp ; Species(Nsp)=spec(nat)
         end if

 10   end do

      if(Errr) go to 20

      write(*,*)'XYZ: found Nsp = ',Nsp
      write(*,*)'XYZ: found species:'
      write(*,'(10(a,a2,a,3x))') ('(',Species(i),')',i=1,Nsp)

!__________ sorting atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
      k=0
      do i=1,Nsp
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.i) then
               ni=ni+1 ; k=k+1
               TI1(1:3,k)=TI(1:3,nat)
            end if
         end do
         NspN(i)=ni
      end do
      do nat=1,ITI
         TI(1:3,nat)=TI1(1:3,nat)
      end do
      write(*,'(a,10(i5,x))')'XYZ: found NspN = ',(NspN(i),i=1,Nsp)
      write(*,*)'Done atomic positions!'
      close (14)
!
!............. finishing: setting up lattice vectors
!
      do i=1,3
         rmin(i)= 1.0e20 ; rmax(i)=-1.0e20
         do nat=1,ITI
            if(TI(i,nat).lt.rmin(i)) rmin(i)=TI(i,nat)
            if(TI(i,nat).gt.rmax(i)) rmax(i)=TI(i,nat)
         end do
         dim(i)=rmax(i)-rmin(i)
         if(dim(i).lt.tiny) then
            write(*,*) '=============================================='
            write(*,*) 'WARNING: ZERO dimension along axis ',i,' found'
            write(*,*) '------> Making it artificially large <--------'
            write(*,*) '=============================================='
            dim(i)=50.0
         end if
      end do
      do i=1,3
         AJ(i,1:3)=0.0
         AJ(i,i)=dim(i)*1.2
      end do
      write(*,*)'XYZ: generated lattice vectors (Max-Min)*1.2:'
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
      end do
      call INVER(AJ,BJ)
      vscale=1.0
      return
!
!........ change format Xmol -> Ymol
 100  YES_xyz='Ymol'
      rewind 14
      go to 1
!
!......... errors
 19   write(*,*)'FATAL! Absent input file!'
      Err=.true.
      return
 20   write(*,*)'FATAL! Cannot recognize the format!'
 21   Err=.true.
      end subroutine read_xyz

      subroutine get_relax_flags_SIESTA(un,ITI,relax_flag,old_to_new)
!...........................................................................
! read geometry constraints from SIESTA fdf input file;
! the input file at unit = un  should be opened  already.
!...........................................................................
      use real8
      implicit none
      character :: Line*200,relax_flag(3,N0LT),cha(3)
      integer :: LinEnd(100),LinPos(100),NumLin
      integer :: un, old_to_new(N0LT)
      real(8) :: x(3)
!
      integer :: ITI,iErr,n1,n2,m,i,i1,m1

      rewind (un)
      call find_string('%block GeometryConstraints',26,un,Line,iErr)
      if(iErr.eq.1) return
      write(*,*)'FOUND block Geometry Constraints ...'
 15   call CutStr(Line,NumLin,LinPos,LinEnd,un,0,iErr)
      write(*,'(a)') Line
      if(index(Line(1:9),'%endblock').ne.0) go to 17
      if(index(Line,'position').eq.0) go to 18
      if(index(Line(LinPos(2):LinEnd(2)),'from').ne.0) then
         cha(1:3)='F'
         if(Numlin.eq.8) then
            read(Line(LinPos(6):LinEnd(8)),*,err=18) x
            if(x(1).eq.0.0) cha(1)='T'
            if(x(2).eq.0.0) cha(2)='T'
            if(x(3).eq.0.0) cha(3)='T'
         else if(Numlin.ne.5) then
            go to 18
         end if
         read(Line(LinPos(3):LinEnd(3)),*,err=18) n1
         read(Line(LinPos(5):LinEnd(5)),*,err=18) n2
         if(n1.lt.0 .and. n2.lt.0) then
            m=ITI+n1+1 ; n1=ITI+n2+1 ; n2=m
         end if
         if(n1.gt.n2 .or. n1.lt.1.or.n2.gt.ITI) go to 18
         do i=n1,n2
            i1=old_to_new(i) ; relax_flag(1:3,i1)=cha(1:3)
         end do
      else
         if(Numlin.lt.2) go to 18
         read(Line(LinPos(2):LinEnd(2)),*,err=18) m
         if(m.lt.1 .or. m.gt.ITI) go to 18
         m1=old_to_new(m) ; relax_flag(1:3,m1)='F'
         if(Numlin.eq.5) then
            read(Line(LinPos(3):LinEnd(5)),*,err=18) x
            if(x(1).eq.0.0) relax_flag(1,m1)='T'
            if(x(2).eq.0.0) relax_flag(2,m1)='T'
            if(x(3).eq.0.0) relax_flag(3,m1)='T'
         end if
      end if
      go to 15
 17   write(*,*)'FINE: block Geometry Constraints read successfully!'
      return
 18   write(*,*)'ERROR: constraints not recognised! Ignored!'
      relax_flag(1:3,1:ITI)='T'
      end subroutine get_relax_flags_SIESTA

      subroutine get_all_from_QUICKSTEP(seed0,l0seed0,Err)
!.................................................................
!  reading QUICKSTEP input file (a little bit simplified)
!.................................................................
      use real8
      use tetrag1
      use mendeleev
      use siesta
      implicit none
      character(len=FLEN) :: seed0
      character :: Line*200,cell_type*7,spec(N0LT)*2,cha2*2
      integer :: LinEnd(100),LinPos(100),NumLin
      integer :: old_to_new(N0LT),fix_type
      logical :: good,Err,fix_crd(N0LT,3),skip
      real(8) :: TI1(3,N0LT)
      integer :: isp(N0LT)
      character :: filename*100
!
      integer :: nat,nt,jsp,iErr,i0,j,i,i1,i2,ksp,k,ni,l0seed0
      real(8) :: alpha,beta,gama,a0,b0,c0

!........... some useful defaults
      alpha= 90.0 ; beta = 90.0 ; gama = 90.0 ;  cell_type='       '
      nat=0 ; nt=0 ; jsp=0 ; nlines=0 ; fix_type=0 ; ITI=0
      AJ=0.0 ; fix_crd(1:N0LT,1:3)=.false. ; skip=.false.
      vscale=1.0


      write(*,*) 'Reading from '//seed0(l0seed0:)//' ...'
      open(14,file=seed0(l0seed0:),form='formatted', &
                 status='old',err=19)
      open(16,file='tmp.inp')
      do
         call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
         if(iErr.ne.0) exit
         if(index(line,'@include').ne.0 &
                     .or. index(line,'@INCLUDE').ne.0) then
            filename=line(LinPos(2)+1:LinEnd(2)-1)
            i0=0
            open(15,file=trim(filename))
            do
               read(15,'(a)',end=2) line ; i0=i0+1
               write(16,'(a)') trim(line)
            end do
 2          write(*,*)'... found ',i0,' lines in "'//trim(filename)//'"'
            close(15)
         else
            write(16,'(a)') trim(line)
         end if
      end do
 3    close(16) ; close(14)

!........... open 'tmp.inp' file and read all data (now complete)

      write(*,*) 'Reading from "tmp.inp" ...'
      open(14,file='tmp.inp',form='formatted',status='old',err=19)
 1    read(14,'(a)',err=19,end=50) line

!_________ reading unit cell lattice vectors

      if(index(line,'&CELL').ne.0 &
                          .and. index(line,'&CELL_OPT').eq.0) then
         write(*,*)'>... reading lattice vectors ...<'
 5       call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
         if(iErr.ne.0) go to 19
         if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) then
            if(cell_type.eq.'abc_abg') then
               AJ(1,1)=a0
               AJ(2,1)=b0*cos(gama*pi/180.0)
               AJ(2,2)=b0*sin(gama*pi/180.0)
               AJ(3,1)=c0*cos(beta)
               AJ(3,2)=c0*(cos(alpha)-cos(gama)*cos(beta))/sin(gama)
               AJ(3,3)=sqrt(c0*c0-AJ(3,1)**2-AJ(3,2)**2)
            end if
            write(*,*)'========> Found lattice vectors: <=========='
            do i=1,3
               write(*,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
            end do
            call INVER(AJ,BJ)
            go to 1
         else
            if(index(line(LinPos(1):LinEnd(1)),'A').ne.0) then
               read(line(LinPos(2):LinEnd(4)),*,err=19) (AJ(1,j),j=1,3)
               if(cell_type.eq.'abc_abg') then
                  write(*,*)'ERROR: inconsistency in &CELL block'
                  go to 19
               end if
               cell_type='vectors'
            else if(index(line(LinPos(1):LinEnd(1)),'B').ne.0) then
               read(line(LinPos(2):LinEnd(4)),*,err=19) (AJ(2,j),j=1,3)
               if(cell_type.eq.'abc_abg') then
                  write(*,*)'ERROR: inconsistency in &CELL block'
                  go to 19
               end if
               cell_type='vectors'
            else if(index(line(LinPos(1):LinEnd(1)),'C').ne.0) then
               read(line(LinPos(2):LinEnd(4)),*,err=19) (AJ(3,j),j=1,3)
               if(cell_type.eq.'abc_abg') then
                  write(*,*)'ERROR: inconsistency in &CELL block'
                  go to 19
               end if
               cell_type='vectors'
            else if(index(line(LinPos(1):LinEnd(1)),'ABC').ne.0) then
               read(line(LinPos(2):LinEnd(4)),*,err=19) a0,b0,c0
               if(cell_type.eq.'vectors') then
                  write(*,*)'ERROR: inconsistency in &CELL block'
                  go to 19
               end if
               cell_type='abc_abg'
            else if(index(line,'ALPHA_').ne.0) then
               read(line(LinPos(2):LinEnd(4)),*,err=19) alpha,beta,gama
               if(cell_type.eq.'vectors') then
                  write(*,*)'ERROR: inconsistency in &CELL block'
                  go to 19
               end if
               cell_type='abc_abg'
            end if
         end if
         go to 5

!__________ skipping atomic species information
!
      else if(index(line,'&KIND').ne.0) then
         do
            read(14,'(a)',err=19,end=50) line
            if(index(line,'&END').ne.0) go to 1
         end do

!_________ reading atomic positions and species:
!         [ we assume UNITS=A and no SCALING at the moment ]
!         nat - counts atoms
!         isp - counts different species

      else if(index(line,'&COORD').ne.0) then
         write(*,*)'>... reading atomic positions ...<'
 10      call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
         if(iErr.ne.0) go to 19
         if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) then
            Nsp=jsp ; ITI=nat
            write(*,'(a,i5)') &
                 'QUICKSTEP: number of species found Nsp = ',Nsp
            write(*,'(a,i5)') &
                 'QUICKSTEP: number of atoms found ITI = ',ITI
            if(Nsp.le.0 .or. ITI.le.0) go to 19
            if(skip) then
               write(*,*) 'WARNING: found equivalent atoms'
               write(*,*) 'WARNING: Constrains (if exist) may be WRONG'
               write(*,*) 'Press ENTER when ready ...'
               read(*,*) ; write(8,'(a)') 'PressEnter'
            end if
            go to 1
         end if
         nat=nat+1 ; nt=nt+1
         if(nat.gt.N0LT) then
            write(*,*) &
              'ERROR! Number of atoms > N0LT=',N0LT,' in tetr_param.inc'
            go to 19
         end if
         read(line(LinPos(2):LinEnd(4)),*,err=19,end=50) &
                                                 (TI(j,nat),j=1,3)
!__________ check the atomic position; reject if equaivalent
         call check_atoms(nat,good)
         if(.not.good) then
            write(*,'(a,i3,a)')'... skipping atom ',nt,' ...'
            nat=nat-1 ; skip=.true. ; go to 10
         end if
!__________ proceed if accepted
         read(line(LinPos(1):LinEnd(1)),*,err=19,end=50) spec(nat)
         if(LinEnd(1)-LinPos(1).eq.0) then
            cha2=' '//spec(nat)
         else
            cha2=spec(nat)
         end if
         if(nat.eq.1) then
            jsp=1
         else
            do i=1,jsp
               if(cha2.eq.Species(i)) then
                  isp(nat)=i ; go to 11
               end if
            end do
            jsp=jsp+1
         end if
         Species(jsp)=cha2 ; isp(nat)=jsp
! 11      write(*,'(2(i5,x),a,3(x,f10.5))')
!     &        nat,isp(nat),Species(isp(nat)),(TI(j,nat),j=1,3)
 11      go to 10

!__________ reading contsraints (type 7 is the default)
!    fix_type = 0, 1, 2, 3, 4, 5,  6,   7  corresponds to the following fixed:
!              no  X  Y  Z  XY XZ  YZ  XYZ

      else if(index(line,'&FIXED_ATOMS').ne.0) then
         write(*,*)'>... reading fixed atoms ...<'
         if(ITI.eq.0) then
            write(*,*)'FATAL! Wrong input file!'
            write(*,*)'FATAL! Put box &FORCE_EVAL before &MOTION'
            write(*,*)'PLEASE place this box after &COORD box'
            write(*,*)'                      ^^^^^^          '
            go to 19
         end if
         fix_type=0
 15      call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
         if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) then
            go to 1
         else if(index(line(LinPos(1):LinEnd(1)),'COMPONENT').ne.0) then
            if(line(LinPos(2):LinEnd(2)).eq.'X') then
               fix_type=1
            else if(line(LinPos(2):LinEnd(2)).eq.'Y') then
               fix_type=2
            else if(line(LinPos(2):LinEnd(2)).eq.'Z') then
               fix_type=3
            else if(index(line(LinPos(2):LinEnd(2)),'X').ne.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Y').ne.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Z').eq.0) then
               fix_type=4
            else if(index(line(LinPos(2):LinEnd(2)),'X').ne.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Y').eq.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Z').ne.0) then
               fix_type=5
            else if(index(line(LinPos(2):LinEnd(2)),'X').eq.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Y').ne.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Z').ne.0) then
               fix_type=6
            else if(index(line(LinPos(2):LinEnd(2)),'X').ne.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Y').ne.0 .and. &
                    index(line(LinPos(2):LinEnd(2)),'Z').ne.0) then
               fix_type=7
            else
               write(*,*)'Wrong contsraint command' ; go to 19
            end if
         else if(index(line(LinPos(1):LinEnd(1)),'LIST').ne.0) then
            if(fix_type.eq.0) fix_type=7
            do k=2,NumLin
               i0=index(line(LinPos(k):LinEnd(k)),'..')
               if(i0.eq.0) then
                  read(line(LinPos(k):LinEnd(k)),*,err=19) i1 ; i2=i1
               else
                  read(line(LinPos(k):LinPos(k)+i0-2),*,err=19) i1
                  read(line(LinPos(k)+i0+1:LinEnd(k)),*,err=19) i2
               end if
               write(*,'(3(a,i5))')  'QUICKSTEP: found atoms from ',i1, &
                                  ' to ',i2,' of fix type = ',fix_type
               if(min(i1,i2).lt.1 .or. max(i1,i2).gt.ITI) then
                  write(*,*) &
                   'ERROR! Wrong atomic numbers in the LIST command:'
                  go to 19
               end if
               do i=i1,i2
                  if(fix_type.ge.1 .and. fix_type.le.3) then
                     fix_crd(i,fix_type)=.true.
                  else if(fix_type.eq.4) then
                     fix_crd(i,1)=.true. ; fix_crd(i,2)=.true.
                  else if(fix_type.eq.5) then
                     fix_crd(i,1)=.true. ; fix_crd(i,3)=.true.
                 else if(fix_type.eq.6) then
                     fix_crd(i,2)=.true. ; fix_crd(i,3)=.true.
                  else if(fix_type.eq.7) then
                     fix_crd(i,1:3)=.true.
                  end if
               end do
            end do
         else
            write(*,*)'WARNING! Unrecognised command in &FIXED_ATOMS!'
            write(*,*)'WARNING! ====> to be IGNORED!'
            write(*,*)'Press ENTER when ready ...'
            read(*,*) ; write(8,'(a)') 'PressEnter'
         end if
         go to 15

!_________ reading unit cell lattice optimisation commands (dump them)

      else if(index(line,'&CELL_OPT').ne.0) then
         call add_to_lines(line,iErr) ; if(iErr.ne.0) go to 19
 25      call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
         call add_to_lines(line,iErr) ; if(iErr.ne.0) go to 19
         if(index(line(LinPos(1):LinEnd(1)),'&END').ne.0) go to 1
         go to 25

!_________ dump all the rest as well

      else
         call add_to_lines(line,iErr) ; if(iErr.ne.0) go to 19
      end if
      go to 1

!................ work out properly the species
 50   rewind(14)
      cp2k_sp_all=.false.
 111  read(14,'(a)',err=19,end=52) line
      if(index(Line,'#').ne.0) go to 111
      if(index(line,'&KIND').ne.0) then
         call CutStr(Line,NumLin,LinPos,LinEnd,0,0,iErr)
         if(LinEnd(2)-LinPos(2).eq.0) then
            cha2=' '//Line(LinPos(2):LinEnd(2))
         else
            cha2=Line(LinPos(2):LinEnd(2))
         end if
         do ksp=1,Nsp
            if(Species(ksp).eq.cha2) go to 112
         end do
         go to 111
 112     cp2k_sp_all(ksp)=.true.
         write(*,'(a,i3,a)') &
              '>... found species ',ksp,' named '//Species(ksp)
         cp2k_potential(ksp)= '==> MISSING <=='
         cp2k_basis_set(ksp)= '==> MISSING <=='
         cp2k_element(ksp)= '==> MISSING <=='
         do
            call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
            if(index(line(:LinEnd(1)),'ELEMENT').ne.0) then
               cp2k_element(ksp)=Line(LinPos(2):LinEnd(2))
            else if(index(line(:LinEnd(1)),'BASIS_SET').ne.0) then
               cp2k_basis_set(ksp)=Line(LinPos(2):LinEnd(2))
            else if(index(line(:LinEnd(1)),'POTENTIAL').ne.0) then
               cp2k_potential(ksp)=Line(LinPos(2):LinEnd(2))
            else if(index(line(:LinEnd(1)),'GHOST').ne.0) then
               cp2k_ghost(ksp)=.true.
            else if(index(line(:LinEnd(1)),'&END').ne.0) then
               write(*,*)'=< Found information for '//Species(ksp)//' :'
               write(*,*)'Potential '//trim(cp2k_potential(ksp))
               write(*,*)'Basis Set '//trim(cp2k_basis_set(ksp))
               write(*,*)'Element '//trim(cp2k_element(ksp))
               exit
            end if
         end do
      end if
      go to 111
 52   do i=1,Nsp
         if(.not.cp2k_sp_all(i)) then
            write(*,*)'ERROR: info for '//Species(i)//' is missing'
            go to 19
         end if
      end do

!.................close the input file
      close(14)
      call system('/bin/rm -r tmp.inp')

!................order atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
      good=.true. ; k=0
      do i=1,Nsp
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.i) then
               ni=ni+1 ; k=k+1 ; TI1(1:3,k)=TI(1:3,nat)
               old_to_new(nat)=k
            end if
         end do
         NspN(i)=ni
      end do
      if(k.ne.ITI) good=.false.
      TI(1:3,1:ITI)=TI1(1:3,1:ITI)
      write(*,'(a)')'WARNING: atoms have been ordered by species!'
      write(*,'(a,10(i5,x))') &
                 'QUICKSTEP: found NspN = ',(NspN(i),i=1,Nsp)
      write(*,*)'Done geometry!'

!........... set up relaxation flags

      do i=1,ITI
         i1=old_to_new(i)
         do j=1,3
            relax_flag(j,i1)='T' ; if(fix_crd(i,j)) relax_flag(j,i1)='F'
         end do
      end do

!............ finishing

      if(good) then
         write(*,*) 'O.K.! This '//seed0(l0seed0:) &
                                //' is fine! Let us proceed!'
         write(*,*) &
              '........> Total number of atoms in the cell is ',ITI
      else
         write(*,*)'FATAL! Problems with sorting atoms!'
         Err=.true. ; return
      end if
!
!___________ show atoms
!
      nat=0
      do i=1,Nsp
         write(*,'(a25,i3,a8)')'______> Atoms in species ',i,' <______'
         do k=1,NspN(i)
            nat=nat+1
            write(*,'(i5,5x,3(f10.5,1x),3x,3(a,x))') &
                 nat,(TI(j,nat),j=1,3),(relax_flag(j,nat),j=1,3)
         end do
      end do
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']  ',(AJ(i,j),j=1,3)
      end do
      return
!
!......... errors
 19   write(*,*)'FATAL! Bad or absent QUICKSTEP input file!'
      Err=.true.
      end subroutine get_all_from_QUICKSTEP

      subroutine add_to_lines(line,iErr)
      use real8
      use siesta
      implicit none
      character :: line*200
      integer :: iErr
      iErr=0
      if(nlines.gt.1000-1) then
         write(*,*)'PROBLEM: rest of input is too big!'
         write(*,*)'Check your input file after SAVE!'
         iErr=1 ; return
      end if
      nlines=nlines+1
      lines(nlines)=line
      end subroutine add_to_lines

      subroutine get_all_from_QE(seed0,l0seed0,Err)
!.................................................................
!  reading QE input file (a little bit simplified)
!.................................................................
      use real8
      use tetrag1
      use mendeleev
      use siesta
      use qe
      implicit none
      character(len=FLEN) :: seed0
      character :: Line*200,cha2*2
      character :: spec*2
      integer :: LinEnd(100),LinPos(100),NumLin
      integer :: old_to_new(N0LT)
      logical :: good,Err,fx_crd(N0LT,3)
      real(8) :: TI1(3,N0LT),rf(3)
      integer :: isp(N0LT)
!
      integer :: nat,iErr,Nsp1,j,is,ITI1,nt,kp,k,ni,is1,i1,l0seed0,i

      good=.true.

!........... some useful defaults
      nat=0 ; nlines=0 ; vscale=1.0
      AJ=0.0 ; fx_crd(1:N0LT,1:3)=.false.

!........... open the file

      write(*,*) 'Reading from '//seed0(l0seed0:)//' ...'
      open(14,file=seed0(l0seed0:),form='formatted', &
                 status='old',err=19)

 1    read(14,'(a)',err=19,end=50) line
!      write(*,*) line

!_________ reading the scaling factor

      if(index(line,'celldm(1)').ne.0) then
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 19
         read(line(LinPos(3):LinEnd(3)),*,err=19) vscale
         write(*,*)'... found scalling factor =',vscale

!_________ reading the number of atoms

      else if(index(line,'nat').ne.0) then
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 19
         read(line(LinPos(3):LinEnd(3)),*,err=19) ITI1
         write(*,*)'... found total number of atoms =',ITI1

!_________ reading the number of species

      else if(index(line,'ntyp').ne.0) then
         call CutStr(Line,NumLin,LinPos,LinEnd,0,1,iErr)
         if(iErr.ne.0) go to 19
         read(line(LinPos(3):LinEnd(3)),*,err=19) Nsp1
         write(*,*)'... found total number of species =',Nsp1
         Nsp_QE=Nsp1

!_________ reading unit cell lattice vectors

      else if(index(line,'CELL_PARAMETERS').ne.0) then
         write(*,*)'========> Found lattice vectors: <=========='
         read(14,*,err=19) (AJ(1,j),j=1,3)
         write(*,'(a,3(f10.5,x))') '[1]', (AJ(1,j),j=1,3)
         read(14,*,err=19) (AJ(2,j),j=1,3)
         write(*,'(a,3(f10.5,x))') '[2]', (AJ(2,j),j=1,3)
         read(14,*,err=19) (AJ(3,j),j=1,3)
         write(*,'(a,3(f10.5,x))') '[3]', (AJ(3,j),j=1,3)
         AJ=AJ*vscale
         call INVER(AJ,BJ)

!_________ reading species box: MUST come before
!           WARNING: only 2 characters for the species at the moment

      else if(index(line,'ATOMIC_SPECIES').ne.0) then
         write(*,*)'========> Found Species: <=========='
         do is=1,Nsp1
            call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
            if(iErr.ne.0) go to 19
            read(line(LinPos(1):LinEnd(1)),*,err=19) spec
            if(LinEnd(1)-LinPos(1).eq.0) then
               cha2=' '//spec
            else
               cha2=spec
            end if
            Species(is)=cha2
            read(line(LinPos(2):LinEnd(2)),*,err=19) QE_masses(is)
            read(line(LinPos(3):LinEnd(3)),*,err=19) psp_names(is)
            call right(psp_names(is),50,psp_l0(is))
            write(*,'(a,i3,a,f10.5,x,a)') '... ',is, &
        ' ['//Species(is)//'] ',QE_masses(is),psp_names(is)(psp_l0(is):)
         end do

!_________ reading atomic positions and relaxation flags in the same order
!          as in the input file
!      nt - counts atoms
!      isp(nt) - atomic species

      else if(index(line,'ATOMIC_POSITIONS').ne.0) then
         write(*,*)'========> Found atoms: <=========='
         nat=0 ; ITI=ITI1
         do nt=1,ITI1
            nat=nat+1
            call CutStr(Line,NumLin,LinPos,LinEnd,14,0,iErr)
            if(iErr.ne.0) go to 19
            read(line(LinPos(2):LinEnd(4)),*,err=19) (TI(j,nat),j=1,3)
            TI(1:3,nat)=TI(1:3,nat)*vscale
!__________ check the atomic position; reject if equaivalent
            call check_atoms(nat,good)
            if(.not.good) then
               write(*,'(a,i3,a)')'... skipping atom ',nt,' ...'
               nat=nat-1 ; ITI=ITI-1 ; go to 11
            end if
!__________ proceed if accepted
            read(line(LinPos(1):LinEnd(1)),*,err=19) spec
            if(LinEnd(1)-LinPos(1).eq.0) then
               cha2=' '//spec
            else
               cha2=spec
            end if
            spec=cha2
            do is=1,Nsp1
               if(spec.eq.Species(is)) then
                  isp(nat)=is ; go to 10
               end if
            end do
            write(*,'(a,i5)') &
                 'ERROR: unknown species '//spec//' for atom ',nt
            write(*,*) line
            go to 19
 10         if(NumLin.eq.7) then
               read(line(LinPos(5):LinEnd(7)),*,err=19) (rf(j),j=1,3)
            else
               rf(1:3)=1.0
            end if
            do j=1,3
               fx_crd(nat,j)=.true.
               if(rf(j).eq.1.0) fx_crd(nat,j)=.false.
            end do
            write(*,'(i3,x,a,3(x,f10.5),3(x,l1))') nt,Species(isp(nat)), &
                             (TI(j,nat),j=1,3),(fx_crd(nat,j),j=1,3)
 11      end do

!_________ reading k-points (gamma or assuming they are given explicitly)
      else if(index(line,'K_POINTS').ne.0) then
         write(*,*)'========> Found k-points: <=========='
         if(index(line,'gamma').ne.0) then
            QE_nkp=1 ; QE_kpoint(1,1:3)=0.0
         else
            read(14,*,err=19) QE_nkp
            if(QE_nkp.gt.Nkpoint) then
               write(*,*)'WARNING: too many k-points, will be CUT!'
               QE_nkp=Nkpoint
            end if
            do kp=1,QE_nkp
               read(14,*) (QE_kpoint(kp,j),j=1,3),QE_weight(kp)
            end do
         end if
         QE_kpoint=QE_kpoint*2*pi/vscale

!__________ read the rest of it
      else
         call add_to_lines(line,iErr) ; if(iErr.eq.1) go to 19
      end if
      go to 1

!................ work out properly the species and order atoms
 50   close(14)

!__________ sorting atoms by species
!           ni - counts atoms in the current species i
!            k - counts all atoms
      k=0
      do is=1,Nsp1
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.is) then
               ni=ni+1 ; k=k+1 ; TI1(1:3,k)=TI(1:3,nat)
               old_to_new(nat)=k
            end if
         end do
         NspN(is)=ni
      end do
      if(k.ne.ITI) good=.false.
      TI(1:3,1:ITI)=TI1(1:3,1:ITI)
      write(*,'(a,10(i5,x))') 'QE: found NspN = ',(NspN(i),i=1,Nsp1)

!__________ renumber species if some are missing (after eliminating
!           equivalent atoms)
      is=0
 51   is=is+1
      if(NspN(is).eq.0) then
         write(*,*)'WARNING: species '//Species(is)//' has gone!'
         if(Nsp1.gt.is) then
            do is1=is+1,Nsp
               NspN(is1-1)=NspN(is1) ; Species(is1-1)=Species(is1)
               QE_masses(is1-1)=QE_masses(is1)
               psp_names(is1-1)= psp_names(is1)
               psp_l0(is1-1)=psp_l0(is1)
            end do
         end if
         Nsp1=Nsp1-1
      end if
      if(is.lt.Nsp1) go to 51
      Nsp=Nsp1

!__________ print at this stage

      write(*,'(a)')'WARNING: atoms have been ordered by species!'
      write(*,'(a,10(i5,x))')'SIESTA: found NspN = ',(NspN(i),i=1,Nsp)

!........... set up relaxation flags

      do i=1,ITI
         i1=old_to_new(i)
         do j=1,3
            relax_flag(j,i1)='T' ; if(fx_crd(i,j)) relax_flag(j,i1)='F'
         end do
      end do
      write(*,*)'Done geometry!'

!............ finishing

      write(*,*) 'O.K.! This '//seed0(l0seed0:) &
                                //' is fine! Let us proceed!'
      write(*,*) &
              '........> Total number of atoms in the cell is ',ITI
!
!___________ show atoms
!
      nat=0
      do i=1,Nsp
         write(*,'(a25,i3,a8)')'______> Atoms in species ',i,' <______'
         do k=1,NspN(i)
            nat=nat+1
            write(*,'(i5,5x,3(f10.5,1x),3x,3(a,x))') &
                 nat,(TI(j,nat),j=1,3),(relax_flag(j,nat),j=1,3)
         end do
      end do
      do i=1,3
         write(*,'(a,i1,a,3(f10.5,x))') '[',i,']  ',(AJ(i,j),j=1,3)
      end do
      return
!
!......... errors
 19   write(*,*)'FATAL! Bad or absent QE input file!'
      Err=.true.
      end subroutine get_all_from_QE

