      subroutine cluster(exist)
c..........................................................................
c   A cluster of atoms is constructed. Unsaturated bonds can be fixed 
c with H atoms.
c
c  exist = .true. if the lattice info is available
c....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'lists.inc'

      dimension x(3),TI2(3,N0LT),dir(3)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      common /buffer_c/ TIc(3,N0LT),ITIc,First_atom_c,isortc(N0LT),
     ,                  Natom_in_cellc(N0LT)   
      common /buffer1/ AY(3,3),TI3(3,N0LT),BY(3,3),ITI3,
     ,     NspN3(N0KD),Nsp3,Species3(N0KD),relax_flag3(3,N0LT)
      character Species1*2,relax_flag1
      character spec*2,Species3*2,relax_flag3
      character Labels(N0LT)*2
      integer First_atom,First_atom_c
      dimension Shift(3),H_Direct(3,N0LT)
      dimension cntp(3),isort(N0LT),C_rot(3,3)
      dimension xn(3,neighb0),incell(N0LT)
      character cha2*2,cha,angstr*12,YES_xyz*4
      data angstr/'<AtomNumber>'/,YES_xyz/'Xmol'/
      logical listat(N0LT),TagYES,FinPos,Err,First,Final,Genrt1
      logical back,thesame1,thesame,undo,H_index(N0LT),exist,Add_Hs
      logical Hd_auto
      data tiny/0.000001/,H_at_dist/1.0/,wdth_nn/0.1/,Add_Hs/.false./
      
c
c........... MENU ...........................................
c
c___________ keep the current lattice in /buffer/

      if(exist) call keep_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,
     ,     relax_flag,Genrt)
c
c___________ initialise tags
      tagYES=.false.
      do i=1,N0LT
         listat(i)=.false.
      end do

c___________ initialise cluster
      ITI=0 
      First=.false. ; Final=.false. ; undo=.false. ; Hd_auto=.false.
      
c========================================================================
c===================== MENY starts here =================================
c========================================================================

 21   write(*,*)
      write(*,*)'>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<'
      write(*,*)'... CURRENT lattice vectors for the supercell ARE...'
      write(*,'(a,3(f10.5,x))') 'AJ(1):   ',(AJ(1,i),i=1,3)
      write(*,'(a,3(f10.5,x))') 'AJ(2):   ',(AJ(2,i),i=1,3)
      write(*,'(a,3(f10.5,x))') 'AJ(3):   ',(AJ(3,i),i=1,3)
      write(*,'(a)')
     &     '>>>>>>>>>>>>>>>> Current species are: <<<<<<<<<<<<<<'
      write(*,'(4x,20(a2,x))') (Species(i),i=1,Nsp)
      if(ITI.gt.0) then
         do i=1,ITI
            Labels(i)=Species(isort(i))
         end do
      end if

      write(*,'(a)')
     & '>>>>>>>>>>>>>>>>>>>>>> MENU <<<<<<<<<<<<<<<<<<<<<<<<'
c      write(*,*)
c      write(*,*)'========= CHOOSE AN OPTION:'
c      write(*,*)
c      write(*,'(a)')
c     &              '/==============================================\'
      write(*,'(a)')'>>>  HELP for options N, H: ignore internal atoms'
c      write(*,'(a)')'\==============================================/'
      write(*,*)
      write(*,*)' R. Read existing cluster geometry'
      if(.not.First .and. exist) then
         write(*,'(a)')'  1. START HERE: choose the first cluster atom'
      else if(First .and. exist) then
         write(*,'(a,i5)')
     &       '  1. Cluster has been started from atom = ',First_atom
         write(*,'(a,a)')'      Species = ',Species(isort(1))
         write(*,'(6x,a,3(f10.5,a))')
     &      'Position = (',TI(1,1),',',TI(2,1),',',TI(3,1),')'
c         write(*,*)

c___________ operations with multiple lists
         if(tagYES) then
            write(*,'(a)')
     & '--------- operations with multiple lists of atoms ------------'
            write(*,'(a)')
     &       '  T. Untag atoms (multiple lists): currently ON'
            write(*,'(a)') '     >> Current set of tagged atoms: '
            call print_long_char(lists,length,long_lists)
            if(.not.Final) then
               write(*,'(a)')
     &'  N. Add NN around tagged atoms   ||  H. Terminate with H atoms'
               write(*,'(a)') ' mH. Move tagged H atoms along bonds'
            end if
            if(ITI.gt.1) then
               write(*,'(a)')
     &  ' Rm. Remove tagged atoms          || Ru. remove untagged '
            end if
            write(*,'(a)')' Rn. Rename tagged atoms: change species'
         else
            if(.not.Final) then
               write(*,'(a)')
     &'  N. Add NN around tagged atoms   ||  H. Terminate with H atoms'
               write(*,'(a)')' mH. Move a range of H atoms along bonds'
            end if
            if(ITI.gt.1) then
               write(*,'(a)')
     &  ' Rm. Remove tagged atoms          || Ru. remove untagged '
            end if
            write(*,'(a)')
     &           ' Rn. Rename a range of atoms: change species'
            write(*,'(a)')
     &  '--------- operations with multiple lists of atoms ------------'
            write(*,'(a)')
     &  '  T. Tag atoms (simple) [OFF]     || TT. Tag atoms (complex)'
         end if
         write(*,'(a)')
     &  '---------------------- shift ---------------------------------'
         write(*,'(a)')
     &'  O. General shift (new origin)   || Cm. Shift to centre of mass'
         write(*,'(a)')
     &  '------------------------- final options ----------------------'
         write(*,'(a)')
     &' Rt. Rotate the WHOLE cluster     || Mv. Move atom(s)' 
      end if

c_____ show settings
      write(*,*)
     &'---------- v i s u a l i a s i o n   s e t t i n g s --------'
c___________ set YES_xyz to the visualisation code: 
c     make geom.xyz file automatically after every change
      
c      if(YES_xyz.ne.'None') then
c         write(*,'(a)')
c     &  ' XY. Produce <geom.xyz> file after every change for '//YES_xyz
c      else
c         write(*,'(a)')
c     &  ' XY. Do NOT produce <geom.xyz> file after every change'
c      end if
      if(.not.CHIMERA) then
         if(Add_Hs) then
            write(*,'(a)')' Hs. Add H atoms to <geom.xyz> file: YES'
         else 
            write(*,'(a)')' Hs. Add H atoms to <geom.xyz> file: NO'
         end if
      end if
      write(*,'(a)')'  W. Write <geom.xyz> file for the current cluster'

      write(*,'(a)')
     &'-------------- g e n e r a l  s e t t i n g s ----------------'
      if(undo) write(*,'(a)')
     & '  U. ********** UNDO the last step *************'
      if(Hd_auto) then
         write(*,'(a,f10.5)')
     & ' Hd. Link atom, H, replaces the atom at its actual position'
      else
         write(*,'(a,f10.5)')
     &        ' Hd. Distance between an atom and H is: ',H_at_dist
      end if
      write(*,'(a,f10.5)')
     &   ' Nd. Spherical belt width when finding nn is: ',wdth_nn

      write(*,'(a)')' Co. Show lattice atomic positions'
      if(First) then
         write(*,'(a)')
     &' Cc. Show atoms of cluster        ||  S. Save geometry'
      end if
      write(*,'(a)')'  Q. Proceed/Quit'
      write(*,'(a)')
      write(*,'(a)')'----------> Choose an appropriate option:'
      read (*,'(a)',err=21) cha2
      call right(cha2,2,l0)

c[XY]...... ask whether to produce geom.xyz file automatically

c      IF(cha2(l0:).eq.'XY') THEN

c         if(YES_xyz.eq.'None') then
c            YES_xyz='Ymol'
c         else if(YES_xyz.eq.'Ymol') then
c            YES_xyz='Xmol'
c         else if(YES_xyz.eq.'Xmol') then
c            YES_xyz='None'
c         end if

c[Hs]...... add Hydrongens to geom.xyz or not

      IF(cha2(l0:).eq.'Hs' .and. (.not.CHIMERA)) THEN
c      ELSE IF(cha2(l0:).eq.'Hs') THEN

         if(Add_Hs) then
            Add_Hs=.false.
         else 
            Add_Hs=.true.
         end if

c[1]...... ask about the first atom

      ELSE IF(cha2(l0:).eq.'1' .and. exist) THEN

 12      write(*,*)
     &  'Specify atom in the supercell which will start the cluster:'
         read(*,*,err=12) First_atom
         if(First_atom.lt.1.or.First_atom.gt.ITI1) go to 12
         ITI=1
         TI(1:3,1)=TI1(1:3,First_atom)
         Natom_in_cell(1)=First_atom
         call find_species(First_atom,ispec)
         H_index(1)=.false.
         isort(1)=ispec
         First=.true. ; Final=.false. ; tagYES=.false.

c[O]...... ask about shift of the system

      ELSE IF(cha2(l0:).eq.'O' .and. First) THEN

c___________ keep the old geometry for undo
         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

 13      write(*,*)
     &        'Give a new origin of the coordinate system as x,y,z:'
         read(*,*,err=13) (Shift(i),i=1,3)
c
c___________ recalculate Cartesian atomic positions in TI(comp,number) 
c
         do k=1,ITI
            TI(1:3,k)=TI(1:3,k)-Shift(1:3)
         end do

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Cm]...... shift the system to the center of mass

      ELSE IF(cha2(l0:).eq.'Cm' .and. First) THEN

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c__________ ask about atomic masses
c
c 31      write(*,*)'Specify atomic masses in a.u.m. for all species:'
c         read(*,*,err=31) (AtMass(i),i=1,Nsp)
c         write(*,*)'Atomic masses are:'  
c         write(*,*) (AtMass(i),i=1,Nsp)  
c         write(*,*)'Do you want to correct masses (Y,y/other char)?'
c         read(*,'(a)') answer
c         if(answer.eq.'y'.or.answer.eq.'Y') go to 31
         Shift(1:3)=0.0 ; TotMass=0.0
         iAt=0
         do iAt=1,ITI
            i=isort(iAt)
            Shift(1:3)=Shift(1:3)+TI(1:3,iAt)*AtMass(i)
            TotMass=TotMass+AtMass(i)
         end do
         Shift(1:3)=Shift(1:3)/TotMass
c
c_____ shift the system (if necessary) to the center of mass
c
         acofm=sqrt(Shift(1)**2+Shift(2)**2+Shift(3)**2)
         if(acofm.gt.tiny) then
            write(*,*)'WARNING! Center of mass is NOT in the origin!'
            write(*,'(a11,1x,3(f10.5,1x),a2)')
     &           'It is at: (', (Shift(j),j=1,3),' )'
            write(*,*)'New atomic positions are:'
            do i=1,ITI
               TI(1:3,i)=TI(1:3,i)-Shift(1:3)
               write(6,'(i3,5x,3(f10.5,1x))') i,(TI(jj,i),jj=1,3)
            end do
         else
            write(*,*)'GOOD! Center of mass IS in the origin!'
         end if

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[N].... add all neighbours around specified atoms

      ELSE IF(cha2(l0:).eq.'N' .and. First .and. (.not.Final)) THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ specify atoms

         if(ITI.eq.1) then
            listat(1)=.true.
         else if(.not.tagYES) then
 38         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=38) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 38
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ now add atoms

         do i=1,ITIc
            if(listat(i).and.Natom_in_cell(i).ne.0) then
               call find_neighbours(i,xn,n_of_neighb,isp,incell,wdth_nn)
               do in=1,n_of_neighb
                  write(*,'(i2,x,a2,x,3(x,f10.5))') 
     &                       in,Species(isp),(xn(j,in),j=1,3)

                  x(1:3)=xn(1:3,in)+TI(1:3,i)
                  if(.not.thesame(x,ITI,TI)) then
                     ITI=ITI+1
                     if(ITI.gt.N0LT) then
                        write(*,*)
     &                   'ERROR! Increase N0LT in tetr_param.inc file!'
                        call restore_cluster(TI,ITI,isort,First_atom,
     ,                              Natom_in_cell)
                        if(ITI.ge.1) First=.true.
                        if(YES_xyz.ne.'None')
     &                     call dump_xyz(isort,YES_xyz,.true.,Add_Hs)
                        go to 21
                     end if
                     TI(1:3,ITI)=x(1:3) ; isort(ITI)=isp
                     Natom_in_cell(ITI)=incell(in)
                     H_index(ITI)=.false.
                  end if
               end do
            end if
            listat(i)=.false.
         end do
         write(*,*)'Number of atoms in the cluster = ',ITI
         tagYES=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Hd].... distance atom-H

      ELSE IF(cha2(l0:).eq.'Hd') THEN

 52      write(*,*)'Specify the distance to the terminating H atoms or'
         write(*,*)'use 0 if it to be set to the actual NN distance:'
         read(*,*,err=52) H_dist
         if(H_dist.eq.0.0) then
            Hd_auto=.true.
         else if(H_dist.ge.tiny) then
            H_at_dist=H_dist ; Hd_auto=.false.
         else if(H_dist.lt.tiny) then
            go to 52
         end if

c[Nd].... when seraching for nn, a sperical belt of width wdth_nn is
c         allowed

      ELSE IF(cha2(l0:).eq.'Nd') THEN

 53      write(*,*) 'Specify the allowed width of a spherical belt'
         write(*,*) 'when searching for nearest neighbours:'
         read(*,*,err=53) wdth_nn
         if(wdth_nn.lt.0.0) go to 53

c[H].... terminate specified atoms with hydrogens

      ELSE IF(cha2(l0:).eq.'H' .and. First .and. (.not.Final)) THEN

         if(ITI.eq.N0LT) then
            write(*,*)'ERROR! Increase N0LT in tetr_param.inc file!'
            go to 21
         end if

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ specify atoms

         if(ITI.eq.1) then
            listat(1)=.true.
         else if(.not.tagYES) then
 41         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=41) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 41
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c__________ add H species first, if not already present
         spec=' H'
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii ; go to 51
            end if
         end do
         jsp=Nsp+1 ; Species(jsp)=spec ; Nsp=jsp

c___________ now add terminating hydrogens
 51      do i=1,ITIc
            if(listat(i).and.Natom_in_cell(i).ne.0) then
               call find_neighbours(i,xn,n_of_neighb,isp,incell,wdth_nn)
               isp=jsp
               do in=1,n_of_neighb
                  write(*,'(i2,x,a2,x,3(x,f10.5))') 
     &                          in,Species(jsp),(xn(j,in),j=1,3)
                  x(1:3)=xn(1:3,in)+TI(1:3,i)
                  if(.not.thesame(x,ITI,TI)) then
                     ITI=ITI+1
                     if(ITI.gt.N0LT) then
                        write(*,*)
     &                    'ERROR! Increase N0LT in tetr_param.inc file!'
                        call restore_cluster(TI,ITI,isort,First_atom,
     ,                       Natom_in_cell)
                        if(ITI.ge.1) First=.true.
                        if(YES_xyz.ne.'None')
     &                       call dump_xyz(isort,YES_xyz,.true.,Add_Hs)
                        go to 21
                     end if
                     if(.not.Hd_auto) 
     &                          call shift_pos(x,TI(1,i),H_at_dist,dir)
                     TI(1:3,ITI)=x(1:3) 
                     H_index(ITI)=.true. ; isort(ITI)=isp  
                     Natom_in_cell(ITI)=0 ; H_Direct(1:3,ITI)=dir(1:3)
                  end if
               end do
            end if
            listat(i)=.false.
         end do
         write(*,*)'Number of atoms in the cluster = ',ITI
         tagYES=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[mH].... move specified H atoms along bonds

      ELSE IF(cha2(l0:).eq.'mH' .and. First .and. (.not.Final)) THEN

c___________ first, check if there are any H-terminations at all

         j=0
         do i=1,ITI
            if(H_index(i)) j=j+1
         end do
         if(j.eq.0) go to 21

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ specify H atoms
         if(.not.tagYES) then
 81         write(*,*) 
     &      '********* Specify range of atoms by two integers: *******'
            write(*,*) 
     &      '[only terminating H atoms within the range will be moved]'
            read(*,*, err=81) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 81
            do i=1,ITI
               if(i.ge.nat1.and.i.le.nat2.and.H_index(i)) then
                  listat(i)=.true.
               else
                  listat(i)=.false.
               end if
            end do
         end if
         
c___________ ask about new distance
 82      write(*,*) 'Specify displacement along the bond for H atoms:'
         read(*,*,err=82) H_displ

c___________ now move terminating H atoms
         do i=1,ITI
            if(listat(i)) TI(1:3,i)=TI(1:3,i)+H_displ*H_Direct(1:3,i)
            if(.not.tagYES) listat(i)=.false.
         end do
c         tagYES=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[T].... tag/untag atoms using a multiple lists method

      ELSE IF(cha2(l0:).eq.'T') THEN

         listat(1:ITI)=.false.
         if(tagYES) then
            write(*,*)'WARNING! The tagging is disabled!'
            tagYES=.false. ; go to 21
         end if

c__________ specify wanted atoms
         call Tag(NumLin,ITI,listat,lists,length,N_lists,long_lists)
         if(NumLin.eq.0) then
            tagYES=.false. ; go to 21
         end if
         tagYES=.true.

c[TT].... tag atoms using more complex options

      ELSE IF(cha2(l0:).eq.'TT' .and. (.not.tagYES)) THEN

         call TTag(tagYES,ITI,TI,Labels,listat,lists,length,
     ,              N_lists,long_lists)

c[Rm].... remove atoms from the cluster

      ELSE IF(cha2(l0:).eq.'Rm'.and.ITI.gt.1) THEN

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ choose atoms

         if(.not.tagYES) then
 36         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=36) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 36
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ remove tagged atoms
         do i=ITIc,1,-1
            if(listat(i)) call delete_atoms(i,i,isort)
            listat(i)=.false.
         end do
         tagYES=.false.
         if(ITI.eq.0) First=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None'.and.ITI.ge.1) 
     &                      call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Ru].... remove atoms from the cluster by specifying atoms
c         which are to stay

      ELSE IF(cha2(l0:).eq.'Ru'.and.ITI.gt.1) THEN

         if(.not.tagYES) then
 37         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=37) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 37
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ remove untagged atoms
         do i=ITIc,1,-1
            if(.not.listat(i)) call delete_atoms(i,i,isort)
            listat(i)=.false.
         end do
         tagYES=.false.
         if(ITI.eq.0) First=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Rn]...... change species (i.e. rename atoms)

      ELSE IF(cha2(l0:).eq.'Rn' .and. ITI.gt.1) THEN

         if(.not.tagYES) then
 39         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=39) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 39
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c__________ ask the target species number
 42      write(*,'(a,i5,a)')'Chemical element (character*2)?'
         read(*,'(a)') cha2
         call right(cha2,2,l0)
         if(l0.eq.2) then
            spec =' '//cha2(l0:)
         else
            spec = cha2
         end if
c___________checking from NAZV
         call check_Mendel(spec,kjsp,Err,.true.)
         if(Err) then
            write(*,*)'ERROR! Wrong species! Repeat!' ; go to 42
         end if
         do ii=1,Nsp
            if(spec.eq.Species(ii)) then
               jsp=ii ; go to 43
            end if
         end do
         jsp=Nsp+1 ; Species(jsp)=spec ; Nsp=jsp

c__________ change species
 43      do k=1,ITI
            if(listat(k)) isort(k)=jsp
            listat(k)=.false.
         end do
         tagYES=.false.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Rt]... Rotate all atoms about an axis

      ELSE IF(cha2(l0:).eq.'Rt'.and. ITI.gt.1) THEN

c___________ keep the old geometry for undo
         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ specify angles and the central point
         call specify_angle(cntp,C_rot)

c___________ rotate atoms
         do i=1,ITI
            call rotate_atom(TI(1,i),TI(2,i),TI(3,i),
     ,               TI2(1,i),TI2(2,i),TI2(3,i),cntp,C_rot)
         end do

         do i=1,ITI
            TI(1:3,i)=TI2(1:3,i)
         end do

c__________ after rotation no more construction is possible
         Final=.true.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Mv]... Move atom(s)

      ELSE IF(cha2(l0:).eq.'Mv' .and. ITI.gt.1) THEN

         if(.not.tagYES) then
 59         write(*,*) 'Specify range of atoms by two integers:'
            read(*,*, err=59) nat1,nat2
            if(nat1.gt.nat2.or.nat1.lt.1.or.nat2.gt.ITI) go to 59
            do i=1,ITI
               listat(i)=.false.
               if(i.ge.nat1.and.i.le.nat2) listat(i)=.true.
            end do
         end if

c___________ keep the old geometry for undo

         call keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         undo=.true.

c___________ ask about the target.

 94      call ask_displacement(angstr,dir,dmove,dd,FinPos,nat1,back)
         if(back) then
            do i=1,ITI
               if(.not.tagYES) listat(i)=.false.
            end do
            go to 21
         end if

c___________ move all atoms
         do i=1,ITI
            if(listat(i)) then
               TI2(1:3,i)=TI(1:3,i)+dmove/dd * dir(1:3)
            else
               TI2(1:3,i)=TI(1:3,i)
            end if
         end do

c____________ check equivalencies
         do i=1,ITI
            if(thesame1(i,ITI,TI2)) then
               write(*,*)'ERROR: New position for atom ',i,
     &                                       ' is inappropriate'
               go to 94
            end if
         end do
         do i=1,ITI
            TI(1:3,i)=TI2(1:3,i)
            if(.not.tagYES) listat(i)=.false.
         end do

c__________ after displacement no more construction is possible
         Final=.true.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[U].... undo the last step: restore TI, ITI, etc. from the previous step

      ELSE IF(cha2(l0:).eq.'U' .and. undo) THEN

         call restore_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
         if(ITI.ge.1) First=.true.

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[Co].... display lattice atomic positions

      ELSE IF(cha2(l0:).eq.'Co') THEN
         k=0
         do i=1,Nsp1
            write(*,'(3a,i5)')
     &           '.... Species <',Species1(i),'> ......> ',i
            write(*,'(a)')' Tot   # |----------  Fractional ---------|'
     &           //'-------------  Cartesian ---------| Relax'
            do j=1,NspN1(i)
               k=k+1
               a1=TI1(1,k)*BX(1,1)+TI1(2,k)*BX(1,2)+TI1(3,k)*BX(1,3)
               a2=TI1(1,k)*BX(2,1)+TI1(2,k)*BX(2,2)+TI1(3,k)*BX(2,3)
               a3=TI1(1,k)*BX(3,1)+TI1(2,k)*BX(3,2)+TI1(3,k)*BX(3,3)
               write(*,'(2(x,i3),x,3(x,f10.5),2x,3(x,f10.5),3x,a)') 
     &             k,j,a1,a2,a3,(TI1(j1,k),j1=1,3),
     ,            relax_flag1(1,k)//relax_flag1(2,k)//relax_flag1(3,k)
            end do
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[Cc].... display cluster atomic positions

      ELSE IF(cha2(l0:).eq.'Cc' .and. First) THEN

         write(*,'(a)')' Tot  Species-No In-Cell Species'//
     &   ' |-----------Cartesian -----------| Term-H Tag Dist_from_1st'
         do i=1,ITI
            if(listat(i)) then
               cha='Y'
            else
               cha=' '
            end if
            dist=sqrt((TI(1,i)-TI(1,1))**2+(TI(2,i)-TI(2,1))**2+
     +                                   (TI(3,i)-TI(3,1))**2)
            write(*,'(i4,6x,i2,8x,i3,5x,a2,3x,3(x,f10.5),
     ,                                            5x,l1,5x,a,x,f10.5)') 
     &           i,isort(i),
     ,           Natom_in_cell(i),Species(isort(i)),(TI(j1,i),j1=1,3),
     ,           H_index(i),cha,dist
         end do
         write(*,*)'Hit ENTER when done ...'
         read(*,*)

c[R].... read in the current info to <name.mol>

      ELSE IF(cha2(l0:).eq.'R') THEN

         call read_mol(isort,First_atom,First,Final,H_at_dist,
     ,        tagYES,YES_xyz,angstr,listat,H_index,H_Direct,Err)
         if(.not.Err) then
            undo=.false. ; exist=.true.
         end if
         
c[W].... write geom.xyz file for the current situation

      ELSE IF(cha2(l0:).eq.'W') THEN

c___________ write geom.xyz      
         if(YES_xyz.ne.'None')call dump_xyz(isort,YES_xyz,.true.,Add_Hs)

c[S].... write geom.xyz file for the cluster

      ELSE IF(cha2(l0:).eq.'S' .and. exist .and. First) THEN

 111     write(*,*) '========= Choose how to save:'
         write(*,*) 
         write(*,*) '  1. XYZ-format in <name.xyz> file'
         write(*,*) '  2. MOL-format in <name.mol> file'
         write(*,*) '  3. VASP, VASP_v5.2, SIESTA, etc. formats'
         write(*,*) '  R. Return'
         read (*,'(a)',err=111) cha2
         call right(cha2,2,l0)

c___________ write geom.xyz      
         if(cha2(l0:).eq.'1') then
            call dump_xyz(isort,YES_xyz,.false.,Add_Hs)
         else if(cha2(l0:).eq.'2') then
            call dump_mol(isort,First_atom,First,Final,H_at_dist,
     ,           tagYES,YES_xyz,angstr,listat,H_index,H_Direct)
         else if(cha2(l0:).eq.'3') then
            vscale=1.0
            call keep_geometr1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
            call rearrange(AJ,TI,ITI,isort,NspN,Nsp,Species,YES_xyz)
            call INVER(AJ,BJ)
            call write_kp(0,kpoint,Which_Code,YES_xyz,.false.)
            call restore_geom1(AJ,BJ,TI,ITI,NspN,Nsp,Species,relax_flag)
         else if(cha2(l0:).eq.'R') then
            go to 21
         end if
         go to 111

c[Q].... finish

      ELSE IF(cha2(l0:).eq.'Q') THEN
         if(exist) call restore_geometry(AJ,BJ,TI,ITI,NspN,Nsp,Species,
     ,        relax_flag,Genrt)
         return
      ELSE
         write(*,*)'Error! Try again!'
      END IF
      go to 21
      end

      subroutine dump_mol(isort,First_atom,First,Final,H_at_dist,
     ,     tagYES,YES_xyz,angstr,listat,H_index,H_Direct)
c...................................................................
c writes all the current info into a file (name.mol) which can be 
c read in by the routine at any time.
c We keep all the variables, including tagging - for convenience!
c UNDO info is NOT kept though!
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension isort(N0LT),H_Direct(3,N0LT)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      integer First_atom
      logical First,Final,tagYES,listat(N0LT),H_index(N0LT),Genrt1
      character YES_xyz*4,angstr*12,Species1*2,relax_flag1,name*20

c......... open file
      write(*,*)'Give the name (char*20) of the mol file [geom.mol]:'
      read(*,'(a)') name
      if(name.eq.'') name='geom'
      call right(name,20,l0)

      open(37,file=name(l0:)//'.mol',form='formatted',status='unknown')

c_______ general: species
      write(37,*)'# species'
      write(37,*) Nsp
      write(37,'(20(a2))') (Species(i),i=1,Nsp)

c_______ write the lattice information from /buffer/
      write(37,*)'# lattice information'
      write(37,*) Nsp1,ITI1
      write(37,*) (NspN1(i),i=1,Nsp1)
      write(37,*) ((AX(i,j),j=1,3),i=1,3)
      write(37,*) ((BX(i,j),j=1,3),i=1,3)
      do i=1,ITI1
         write(37,*) (TI1(j,i),j=1,3),(' ',relax_flag1(j,i),j=1,3)
      end do
      
c_______ write info variables
      write(37,*)'# info variables'
      write(37,*) First,Final,tagYES,First_atom,ITI,H_at_dist
      write(37,'(a12,x,a4)') angstr,YES_xyz
      write(37,*) (listat(i),i=1,ITI)

c_______ atomic coordinates + info
      write(37,*)'# atomic info'
      do i=1,ITI
         write(37,*) H_index(i)
         write(37,*) (TI(j,i),j=1,3),isort(i),Natom_in_cell(i),
     ,        AtMass(isort(i))
         if(H_index(i)) write(37,*) (H_Direct(j,i),j=1,3)
      end do
      close (37)
      write(*,*)'Done!... saved in <'//name(l0:)//'.mol> file'
      return
      end

      subroutine read_mol(isort,First_atom,First,Final,H_at_dist,
     ,     tagYES,YES_xyz,angstr,listat,H_index,H_Direct,Err)
c...................................................................
c reads in all info from a file (name.mol).
c We keep all the variables, including tagging - for convenience!
c UNDO info is NOT kept though!
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension isort(N0LT),H_Direct(3,N0LT)
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      integer First_atom
      logical First,Final,tagYES,listat(N0LT),Err,H_index(N0LT),Genrt1
      character YES_xyz*4,angstr*12,Species1*2,relax_flag1,name*20

c......... open file
      write(*,*)'Give the name (char*20) of the xyz file [geom.mol]:'
      write(*,*)'[the current lattice/cluster info will be destroyed]'
      write(*,*)'[           Press ENTER to quit                    ]'
      write(*,'(/a)')
     &       '**** MOL-like files in the current directory: ***'
      call system('ls *.mol')
      write(*,'(a/)')
     &       '*************************************************'
      read(*,'(a)') name
      call right(name,20,l0)

      open(37,file=name(l0:)//'.mol',form='formatted',status='old',
     ,     err=100)

c_______ general: species
      read(37,*,err=100,end=100)
      read(37,*,err=100,end=100) Nsp
      read(37,'(20(a2))',err=100,end=100) (Species(i),i=1,Nsp)

c_______ the lattice information to /buffer/
      read(37,*)
      read(37,*,err=100,end=100) Nsp1,ITI1
      read(37,*,err=100,end=100) (NspN1(i),i=1,Nsp1)
      read(37,*,err=100,end=100) ((AX(i,j),j=1,3),i=1,3)
      read(37,*,err=100,end=100) ((BX(i,j),j=1,3),i=1,3)
      do i=1,ITI1
         read(37,*,err=100,end=100) 
     &        (TI1(j,i),j=1,3),(relax_flag1(j,i),j=1,3)
      end do
      
c_______ write info variables
      read(37,*)
      read(37,*,err=100,end=100) 
     &     First,Final,tagYES,First_atom,ITI,H_at_dist
      read(37,'(a12,x,a4)',err=100,end=100) angstr,YES_xyz
      read(37,*,err=100,end=100) (listat(i),i=1,ITI)

c_______ atomic coordinates + info
      read(37,*)
      do i=1,ITI
         read(37,*,err=100,end=100) H_index(i)
         read(37,*,err=100,end=100) 
     &        (TI(j,i),j=1,3),isort(i),Natom_in_cell(i),AtMass(isort(i))
         if(H_index(i)) read(37,*,err=100,end=100) (H_Direct(j,i),j=1,3)
      end do
      close (37)
      Err=.false.
      return
c
c........... error
 100  write(*,*)'ERROR! File '//name(l0:)//
     &                       '.mol is bad or does NOT exist!'
      Err=.true.
      return
      end

      subroutine keep_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
c.................................................................
c  Save cluster atoms in /buffer_c/
c.................................................................
      include 'real8.inc'
      dimension TI(3,N0LT),isort(N0LT)
      common /buffer_c/ TIc(3,N0LT),ITIc,First_atom_c,isortc(N0LT),
     ,                  Natom_in_cellc(N0LT)   
      integer First_atom_c,First_atom,Natom_in_cell(N0LT)
      First_atom_c=First_atom
      ITIc=ITI
      do k=1,ITI
         TIc(1:3,k)=TI(1:3,k)
         isortc(k)=isort(k)
         Natom_in_cellc(k)=Natom_in_cell(k)
      end do
      return
      end

      subroutine restore_cluster(TI,ITI,isort,First_atom,Natom_in_cell)
c.................................................................
c  Restore cluster atoms from /buffer_c/
c.................................................................
      include 'real8.inc'
      dimension TI(3,N0LT),isort(N0LT)
      common /buffer_c/ TIc(3,N0LT),ITIc,First_atom_c,isortc(N0LT),
     ,                  Natom_in_cellc(N0LT)   
      integer First_atom_c,First_atom,Natom_in_cell(N0LT)
      First_atom=First_atom_c
      ITI=ITIc
      do k=1,ITI
         TI(1:3,k)=TIc(1:3,k)
         isort(k)=isortc(k)
         Natom_in_cell(k)=Natom_in_cellc(k)
      end do
      return
      end

      subroutine dump_xyz(isort,YES_xyz,Auto,Add_Hs)
c................................................................
c write geom.xyz file for XMOL
c................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      character YES_xyz*4,name*20
      dimension isort(N0LT)
      logical Err,Auto,Add_Hs

c__________ open xyz file
      if(Auto) then
         name='geom'
      else
         write(*,*)'Give the name (char*20) of the xyz file [geom.xyz]:'
         read(*,'(a)') name
      end if
      call right(name,20,l0)

      open(37,file=name(l0:)//'.xyz',form='formatted',status='unknown')
      nnn=ITI
      if(YES_xyz.eq.'Xmol') then
         if(Add_Hs) nnn=nnn+3
         write(37,'(i5/)') nnn
      else if(YES_xyz.eq.'Ymol') then
         if(Add_Hs) nnn=nnn+4
         write(37,'(a/i5)') '1',nnn
      end if

      DO i=1,ITI
         call check_Mendel(Species(isort(i)),mendl,Err,.false.)

         if(YES_xyz.eq.'Xmol') then
            write(37,'(a2,5x,3(f16.10,1x),a)') 
     &           Species(isort(i)),(TI(j,i),j=1,3)
c     &           Species(isort(i)),(TI(j,i),j=1,3),' 0 0 0'
         else if(YES_xyz.eq.'Ymol') then
            write(37,'(i2,5x,3(f16.10,1x))') mendl,(TI(j,i),j=1,3)
         end if
      END DO
      
      if(YES_xyz.eq.'Xmol' .and.Add_Hs) then
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 7.0  0.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  7.0  0.0 '
         write(37,'(a)')'H 0.0 0.0 0.0 atom_vector 0.0  0.0  7.0 '
      else if(YES_xyz.eq.'Ymol .and.Add_Hs') then
         write(37,'(a)')'2     0.0 0.0 0.0  '
         write(37,'(a)')'3     15.0 0.0 0.0 '
         write(37,'(a)')'4     0.0 15.0 0.0 '
         write(37,'(a)')'5     0.0 0.0 15.0 '
      end if
      close (37)
      write(*,*)'Done!... saved in <'//name(l0:)//'.xyz> file'
      return
      end
 
      subroutine find_species(nat,ispec)
c................................................................
c determines species number ispec from the atomic number nat
c................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      character Species1*2,relax_flag1
      logical Genrt1
      n=0
      do i=1,Nsp1
         do k=1,NspN1(i)
            n=n+1
            if(n.eq.nat) then
               ispec=i
               return
            end if
         end do
      end do
      write(*,*)'FATAL problem in find_species:'
      write(*,*) 'nat = ',nat
      stop
      end

      subroutine find_neighbours(n_at,xn,n_of_neighb,isp,incell,wdth_nn)
c..................................................................
c  finds n_of_neighb neighbours for atom n_at in the cluster which
c  are:
c
c    (1) may be in the cluster already (it is not checked here!)
c    (2) are closest to the atom n_at (within a belt of width wdth_nn)
c    (3) are all of the same species (but not necessarily the
c        same as atom n_at)
c
c  isp       - the species of the newly found atoms
c  xn(xyz,i) - RELATIVE positions of all nn atoms i=1,n_of_neighb
c              surrounding the given atom n_at
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      common /buffer/ AX(3,3),TI1(3,N0LT),BX(3,3),ITI1,
     , NspN1(N0KD),Nsp1,Genrt1(N0LT),Species1(N0KD),relax_flag1(3,N0LT)
      dimension xn(3,neighb0),r(3),incell(N0LT)
      character Species1*2,relax_flag1
      logical Genrt1
      data tiny/0.000001/

      m_at=Natom_in_cell(n_at)
      xmin=1.e10
      n=0

      nat=0
      do i=1,Nsp1
         do j=1,NspN1(i)
            nat=nat+1

            do i1=-2,2
               do i2=-2,2
                  do i3=-2,2
                     r(1)=i1*AX(1,1)+i2*AX(2,1)+i3*AX(3,1)+
     +                    TI1(1,nat)-TI1(1,m_at)
                     r(2)=i1*AX(1,2)+i2*AX(2,2)+i3*AX(3,2)+
     +                    TI1(2,nat)-TI1(2,m_at)
                     r(3)=i1*AX(1,3)+i2*AX(2,3)+i3*AX(3,3)+
     +                    TI1(3,nat)-TI1(3,m_at)

                     ar=sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3))

                     if(ar.lt.xmin-wdth_nn .and. ar.gt.tiny) then
                        xmin=ar
                        isp=i
                        n=1
                        xn(1:3,1)=r(1:3)
                        incell(1)=nat
                     else if(abs(ar-xmin).lt.wdth_nn 
     &                                         .and. i.eq.isp) then
                        n=n+1
                        xn(1:3,n)=r(1:3)
                        incell(n)=nat
                     end if
                  end do
               end do
            end do

         end do
      end do               
      n_of_neighb=n

      write(*,*)'_________> atoms found:'
      do n=1,n_of_neighb
         write(*,'(i2,x,a2,x,3(x,f10.5))') 
     &                               n,Species1(isp),(xn(j,n),j=1,3)
      end do
      return
      end

      subroutine delete_atoms(NumRem1,NumRem2,isort)
c...................................................................
c  removes atoms numbers from NumRem1 to NumRem2 from the cluster
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      dimension isort(N0LT)

      Nsp1=Nsp
      Nrem=NumRem2-NumRem1+1

c___________remove atoms from the TI/ITI list
      if(NumRem2.lt.ITI) then
         do k=NumRem2+1,ITI
            k1=k-Nrem
            TI(1:3,k1)=TI(1:3,k)
            Natom_in_cell(k1)=Natom_in_cell(k)
            isort(k1)=isort(k)
         end do
      end if
      ITI=ITI-Nrem

      return
      end

      subroutine shift_pos(x,y,dist,dir)
c...................................................................
c  it shifts atom at x() towards the target point y() keeping the 
c  distance dist between the two.
c
c      x() - the final position of the first atom.
c    dir() - calculated unit vector of direction from x() to y()
c...................................................................
      include 'real8.inc'
      dimension x(3),y(3),dir(3)
      data tiny/0.0001/
      dir=x-y
      dd=sqrt(dir(1)*dir(1)+dir(2)*dir(2)+dir(3)*dir(3))
      if(dd.gt.tiny) then
         dir=dir/dd ;  x=y+dist * dir
      else
         write(*,*)'ERROR! Source and target atoms are too close!'
         stop
      end if
      end

      subroutine rearrange(AJ,TI,ITI,isort,NspN,Nsp,Species,YES_xyz)
c..................................................................
c Reorder atoms in to conform to the TETR internal use: by species
c..................................................................
      include 'real8.inc'
      real*8 TI(3,N0LT),TI1(3,N0LT)
      real*8 AJ(3,3),rmin(3),rmax(3)
      integer isort(N0LT),isp(N0LT),NspN(N0KD)
      character Species(N0KD)*2,spec(N0LT)*2,YES_xyz*4
      real*8 dim(3)

      do nat=1,ITI
         spec(nat)=Species(isort(nat))
      end do

c_______________ find the number of species in the cluster            
      Nsp=1
      do nat=1,ITI
         if(nat.eq.1) then
            isp(1)=1
            Species(1)=spec(1)
         else
            do i=1,nat-1
               if(spec(i).eq.spec(nat)) then
                  isp(nat)=isp(i)
                  go to 10
               end if
            end do
            Nsp=Nsp+1
            isp(nat)=Nsp
            Species(Nsp)=spec(nat)
         end if
 10   end do
      write(8,*)'REARRANGE: found Nsp = ',Nsp
      write(8,*)'REARRANGE: found species:'
      write(8,'(10(a,a2,a,3x))') ('(',Species(i),')',i=1,Nsp)

c__________ sorting atoms by species
c           ni - counts atoms in the current species i
c            k - counts all atoms
      k=0
      do i=1,Nsp
         ni=0
         do nat=1,ITI
            if(isp(nat).eq.i) then
               ni=ni+1
               k=k+1
               TI1(1:3,k)=TI(1:3,nat)
            end if
         end do
         NspN(i)=ni
      end do
      do nat=1,ITI
         TI(1:3,nat)=TI1(1:3,nat)
      end do
      write(8,'(a,10(i5,x))')
     &            'REARRANGE: found NspN = ',(NspN(i),i=1,Nsp)
c
c............. finishing: setting up lattice vectors
c
      do i=1,3
         rmin(i)= 1.0e20 ; rmax(i)=-1.0e20
         do nat=1,ITI
            if(TI(i,nat).lt.rmin(i)) rmin(i)=TI(i,nat)
            if(TI(i,nat).gt.rmax(i)) rmax(i)=TI(i,nat)
         end do
         dim(i)=rmax(i)-rmin(i)
      end do
      do i=1,3
         do j=1,3
            AJ(i,j)=0.0
         end do
         AJ(i,i)=dim(i)*1.5
      end do
      write(8,*)'REARRANGE: generated lattice vectors (Max-Min)*1.5:'
      do i=1,3
         write(8,'(a,i1,a,3(f10.5,x))') '[',i,']', (AJ(i,j),j=1,3)
      end do
      return
      end

