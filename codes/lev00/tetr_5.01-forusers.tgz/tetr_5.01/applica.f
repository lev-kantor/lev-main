      subroutine BAND_kp(Which_Code,kpoint,nkp)
c.......................................................................
c  It prepares a set of k-points along a chosen direction in the BZ.
c......................................................................
c
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      character Which_Code*6
      character iGp
      dimension pKinit(3),pKfinl(3)
      double precision kpoint(Nkpoint,3)
      integer inpntn(3),inpntd(3),fipntn(3),fipntd(3)
      data tiny/0.0001/
c
c.......... Specify the point group (Ci - at the moment): we need it
c just to have something for this case as well. The group is used
c in write_kp for the calculation of weights.
c
      MGp=2
      KGp(1)=1
      KGp(2)=48
      write(*,*)
      write(*,*)'______ So, your system point group is Ci'
      write(*,*)'       with elements [C1 and I].'
      write(*,*)
c
c_________ ask first (pKinit) and last (pKfinl) K-points
c
      if(z_supp) 
     &    write(*,*)'NOTICE: You have NO z-direction in the BZ!'
      write(*,*)

      write(*,'(a)')'Specify the initial and the final k-points using'
      write(*,'(a/)')'fractional coordinates f1, f2 and f3: ' 
      write(*,'(a/)')'    K-point = f1 *B1  + f2 *B2  + f3 *B3 ,' 
      write(*,'(a)')'where B1, B2, B3 are reciprocal lattice vectors.'
      write(*,'(a)')'Each fractional coordinate is given as a ratio'
      write(*,'(a)')'of two integers, e.g. 5/6 or 1/2, etc.' 

      write(*,'(/a)')'Specify the INITIAL k-point:'
 11   write(*,'(a)')'give 2 integers for the 1st coefficient f1:'
      read(*,*,err=11) inpntn(1),inpntd(1)
 12   write(*,'(a)')'give 2 integers for the 2nd coefficient f2:'
      read(*,*,err=12) inpntn(2),inpntd(2)
 13   write(*,'(a)')'give 2 integers for the 3rd coefficient f3:'
      read(*,*,err=13) inpntn(3),inpntd(3)
      write(*,*)
      write(*,'(/a)')'Specify the FINAL k-point:'
 14   write(*,'(a)')'give 2 integers for the 1st coefficient f1:'
      read(*,*,err=14) fipntn(1),fipntd(1)
 15   write(*,'(a)')'give 2 integers for the 2nd coefficient f2:'
      read(*,*,err=15) fipntn(2),fipntd(2)
 16   write(*,'(a)')'give 2 integers for the 3rd coefficient f3:'
      read(*,*,err=16) fipntn(3),fipntd(3)
      write(*,*)
      do i=1,3
         if(inpntd(i).eq.0) inpntd(i)=1
         if(fipntd(i).eq.0) fipntd(i)=1
      end do
      do j=1,3
         pKinit(j)=inpntn(1)*BJ(1,j)/inpntd(1)+
     +        inpntn(2)*BJ(2,j)/inpntd(2)+
     +        inpntn(3)*BJ(3,j)/inpntd(3)
         pKfinl(j)=fipntn(1)*BJ(1,j)/fipntd(1)+
     +        fipntn(2)*BJ(2,j)/fipntd(2)+
     +        fipntn(3)*BJ(3,j)/fipntd(3)
      end do
      if(z_supp) then
         call suppr(pKinit(1),pKinit(2),pKinit(3))
         call suppr(pKfinl(1),pKfinl(2),pKfinl(3))
      end if
c
c________ print points
c
      write(*,'(a17,3(f10.5,1x))') 'Initial K-point: ',pKinit
      write(*,'(a17,3(f10.5,1x))') 'Final k-point:   ',pKfinl
c
c________ ask the grid dence NmKpnt - total number of K-points
c
      NmKpnt=0
      if(inpntn(1).eq.fipntn(1).and.inpntn(2).eq.fipntn(2).and.
     &     inpntn(3).eq.fipntn(3))  then
         if(inpntd(1).eq.fipntd(1).and.inpntd(2).eq.fipntd(2).and.
     &               inpntd(3).eq.fipntd(3))  NmKpnt=1
      end if
      if(NmKpnt.ne.1) then
 1       write(*,*)'Specify the number of points along the direction:'
         read(*,*,err=2) NmKpnt
         if(NmKpnt.gt.Nkpoint) then
            write(*,*)'WARNING! Cannot be > than ',Nkpoint
           write(*,*)' Increase Nkpoint in the file ~/TOOLS/tetrag1.inc'
            write(*,*)' and recompile the code there: make -f make.tetr'
            go to 2
         else if(NmKpnt.le.1) then
            go to 2
         else
            go to 3
         end if
 2       write(*,*)'ERROR! Try again!'
         go to 1
      end if
 3    write(*,*) ' Number of points will be ',NmKpnt
c
c........ check if the Gamma-point lies on the direction
c        iGp = 'Y' if the direction chosen crosses the Gamma point,
c        iGp = 'N' if not.
c
      iGp='Y'
      sModI=sqrt(pKinit(1)**2+pKinit(2)**2+pKinit(3)**2)
      sModF=sqrt(pKfinl(1)**2+pKfinl(2)**2+pKfinl(3)**2)
      if(sModF.gt.0.0001.and.sModI.gt.0.0001) then
        scal=pKfinl(1)*pKinit(1)+pKfinl(2)*pKinit(2)+pKfinl(3)*pKinit(3)
         cosIF=scal/(sModI*sModF)
         if(abs(1.0-abs(cosIF)).gt.tiny) iGp='N'
      end if
      if(iGp.eq.'Y')
     &     write(*,*)'WARNING! Gamma-point lies on the direction!'
c
c...... Construction of k-points (in the Cartesion coordinates up to
c 2*pi) lying on the chosen k-direction in the BZ;
c nkp -  is used to count k-points
c
      nkp=0
      do ik=1,NmKpnt
         nkp=nkp+1
         if(ik.eq.1) then
            kpoint(nkp,1)=pKinit(1)
            kpoint(nkp,2)=pKinit(2)
            kpoint(nkp,3)=pKinit(3)
         else
            kpoint(nkp,1)=(pKfinl(1)-pKinit(1))/(NmKpnt-1)*(ik-1) + 
     +           pKinit(1)
            kpoint(nkp,2)=(pKfinl(2)-pKinit(2))/(NmKpnt-1)*(ik-1) + 
     +           pKinit(2)
            kpoint(nkp,3)=(pKfinl(3)-pKinit(3))/(NmKpnt-1)*(ik-1) + 
     +           pKinit(3)
         end if
      end do
c     
c........ store k-points from the set kpoint(number,component) in the
c file fort.15 via coefficients with respect to the reciprocal lattice
c vectors BJ.
      kpmethod='band'
      return
      end

      subroutine Manh_Pack(Which_Code,kpoint,nkp)
c...................................................................
c Special points inside the BZ are computed using M.-P. method.
c...................................................................
c  qMP   - the MP parameter;
C  Nstar - the number of stars (because of the BZ symmetry)
c  NW(N) - the number of vectors in the N-th star (within the
c          M.-P. set).
c  C(component,component,operation) - matrices of all possible 3-dim.
c     operations of groups Oh and D6h ordered in some way; they
c     are defined in BLOCK DATA GROUP;
c  MGp - dimension of the "crystal" class point group (of the cell);
c  KGp(i) - reference vector from the group element i to the set C
c           of point operations.
c...................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension NW(Nkpoint),Qprs(3),qS(3)
      double precision one,two
      character Which_Code*6
      character answer
      double precision kpoint(Nkpoint,3)
      data one/1.0/,two/2.0/,tiny/0.0001/
c
c.......... Specify the Manchorst-Pack parameter
c
 1    if(z_supp) then
         write(*,*)'NOTICE: You have NO z-direction in the BZ!'
         write(*,*)'Specify 2 Manchorst-Pack (MP) parameters:'
         read(*,*,err=1) qMP1,qMP2
         qMP3=1
      else
         write(*,*)'Specify 3 Manchorst-Pack (MP) parameters:'
         read(*,*,err=1) qMP1,qMP2,qMP3
      end if
      if(min(qMP1,qMP2,qMP3).le.0) go to 1
      go to 3
 2    write(*,*)' WARNING! Cannot be > than ',Nkpoint
      write(*,*)' Increase Nkpoint in tetr_param.inc'
      write(*,*)' and recompile the code: make '
      write(*,*)' OR -----> try again!'
      go to 1
c
c.......... Specify the point group (Ci - at the moment)
 3    MGp=2
      KGp(1)=1
      KGp(2)=48
      write(*,*)
      write(*,*)'______ So, your system point group is Ci'
      write(*,*)'       with elements [C1 and I].'
      write(*,*)
c
c.......... generate the M.-P. set of k-points
      Nstar=0
      DO 90 Mp=1,qMP1
         a1=one/qMP1
         b1=-(qMP1+one)/(two*qMP1)
         Up=a1*Mp+b1
         DO 80 Mr=1,qMP2
            a2=one/qMP2
            b2=-(qMP2+one)/(two*qMP2)
            Ur=a2*Mr+b2
            DO 70 Ms=1,qMP3
               a3=one/qMP3
               b3=-(qMP3+one)/(two*qMP3)
               Us=a3*Ms+b3

               Qprs(1)=Up*BJ(1,1)+Ur*BJ(2,1)+Us*BJ(3,1)
               Qprs(2)=Up*BJ(1,2)+Ur*BJ(2,2)+Us*BJ(3,2)
               Qprs(3)=Up*BJ(1,3)+Ur*BJ(2,3)+Us*BJ(3,3)

               if(z_supp) call suppr(Qprs(1),Qprs(2),Qprs(3))
               if(Nstar.EQ.0) GO TO 51
               Do 50 n=1,Nstar
                  M0=n
                  DO 40 i=1,MGp
                     KGI=KGp(i)
                     qS(1)=C(1,1,KGI)*Qprs(1)+C(2,1,KGI)*Qprs(2)+
     +                    C(3,1,KGI)*Qprs(3)-kpoint(n,1)
                     qS(2)=C(1,2,KGI)*Qprs(1)+C(2,2,KGI)*Qprs(2)+
     +                    C(3,2,KGI)*Qprs(3)-kpoint(n,2)
                     qS(3)=C(1,3,KGI)*Qprs(1)+C(2,3,KGI)*Qprs(2)+
     +                    C(3,3,KGI)*Qprs(3)-kpoint(n,3)
                     DELTA=qS(1)*qS(1)+qS(2)*qS(2)+qS(3)*qS(3)
                     IF (DELTA.LE.tiny) GO TO 55
 40               CONTINUE
 50            CONTINUE
 51            Nstar=Nstar+1
               if(Nstar.gt.Nkpoint) go to 2
               kpoint(Nstar,1)=Qprs(1)
               kpoint(Nstar,2)=Qprs(2)
               kpoint(Nstar,3)=Qprs(3)
               NW(Nstar)=1
               GO TO 70
 55            NW(M0)=NW(M0)+1
 70         CONTINUE
 80      CONTINUE
 90   CONTINUE
c
c........... Weights belonging to the stars
c      nKP=Nstar
c      q3=1./(Nq*Nq*Nq)
c      WRITE (*,97)
c      DO 95 N=1,nKP
c      Weight(N)=NW(N)*q3
c   95 WRITE (2,99) N,Weight(N),QuBZ(N,1),QuBZ(N,2),QuBZ(N,3),NW(n)
c   97 FORMAT (3X,'Nstar',5X,'Weight',2X,'Qprs(X)',2X,'Qprs(Y)',2X,
c     ,       'Qprs(Z)',2x,'NW')
c   99 FORMAT (3X,I4,2X,F10.5,2X,F10.5,2X,F10.5,2X,F10.5,5x,i5)
c
c........ store the set kpoint(number,component) in the file fort.15
c via coefficients with respect to the reciprocal lattice vectors BJ
      write(*,*)
      write(*,*)'_____ Total number of k-points generated: ', Nstar
      write(*,*)
      write(*,*)'Choose another MP parameters (y,Y/any other char)?'
      read(*,'(a)') answer
      if(answer.eq.'y' .or. answer.eq.'Y') go to 1
c
      kpmethod='  mp'
      nkp=Nstar
      RETURN
      END

      subroutine DOS_kp(Which_Code,kpoint,nkp)
c.....................................................................
c    Generates tetrahedra inside the irreducible portion of the BZ and
c writes them into the file 'brill.dat';  it is used on the sequential
c steps of the DOS-constuction procedure
c.....................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension  unitc(8,3)
      double precision kpoint(Nkpoint,3)
      character Which_Code*6, answer*1
c
      if(z_supp) 
     &    write(*,*)'NOTICE: You have NO z-direction in the BZ!'
c
c_________ Choose interactively your point group: element by element
c
      write(*,*)'....................................................'
      write(*,*)'... Asking about your LARGE lattice point group ....'
      write(*,*)'....................................................'
      write(*,*)
      call point_gr()
      write(*,*)
      write(*,*)'______ So, your system point group is '//GroupN
      write(*,*)'       with elements:'
      write(*,'(12(a4,1x))') (NAZ(KGp(i)),i=1,MGp)
      write(*,*)
c
c.............. Specify the number of devisions .....................
 5    write(*,*)'Give number of divisions in one dimension:'
      read(*,*,err=5) ndiv
      if (ndiv.le.1) then
         write(*,*)'Number of divisions should be more than 1'
         go to 5
      end if
c     
c........................................................................
c.................... Generation of tetrahedra ..........................
c........................................................................
c
c_______ open 'brill.dat' to store an information for every tetrahedra
c
      open(unit=44,file='brill.dat',status='unknown')
c
c__________ write to 44 whether z-direction was supressed or not
c
      if(z_supp) then
         write(44,'(a)')'yes z-suppressed'
      else
         write(44,'(a)')'no  z-suppressed'
      end if
c
c_______ notetra - the current number of tetrahedra built at the moment
c        nkp - the number of different k-points generated so far in
c              the aray kpoint(k-point,component) from every tetrahedra
c
      notetra=0
      nkp=0
c_____________ 3 main loops over small cubes defined above. 
c
      ndiv1=ndiv-1
      do kx=0,ndiv1
         do ky=0,ndiv
            do kz=0,ndiv1
c
c_________  generate all 8 corners of the cube as follows (with respect
c to the 1st corner which has kkx=kky=kkz=0):
c 1  - ( 0,0,0);  2 - ( 0,0,dk);  3 - ( 0,dk,0);  4 - ( 0,dk,dk);
c 5  - (dk,0,0);  6 - (dk,0,dk);  7 - (dk,dk,0);  8 - (dk,dk,dk)
c They are stored in unitc(icorner,component).
c
               icorner=0
               do kkx=0,1
                  do kky=0,1
                     do kkz=0,1
                        icorner=icorner+1
                        unitc(icorner,1)=( (kx+kkx)*BJ(1,1) + 
     +                       (ky+kky)*BJ(2,1)+(kz+kkz)*BJ(3,1))/ndiv
                        unitc(icorner,2)=( (kx+kkx)*BJ(1,2) + 
     +                       (ky+kky)*BJ(2,2)+(kz+kkz)*BJ(3,2))/ndiv
                        unitc(icorner,3)=( (kx+kkx)*BJ(1,3) + 
     +                       (ky+kky)*BJ(2,3)+(kz+kkz)*BJ(3,3))/ndiv
                     end do
                  end do
               end do
c     
c........... check all 6 possibilities picking up every 4 different
c  corners. Store tetrahedra in unit=44, increase the counter (notetra)
c  by 1 and generate different k-point in kpoint(,); nkp - the k-point
c  counter
               call get_tetrah(kpoint,nkp,notetra,unitc,1,2,3,8,ierr)
               if(ierr.eq.1) go to 7 
               call get_tetrah(kpoint,nkp,notetra,unitc,1,2,6,8,ierr)
               if(ierr.eq.1) go to 7 
               call get_tetrah(kpoint,nkp,notetra,unitc,1,3,7,8,ierr)
               if(ierr.eq.1) go to 7 
               call get_tetrah(kpoint,nkp,notetra,unitc,1,5,6,7,ierr)
               if(ierr.eq.1) go to 7 
               call get_tetrah(kpoint,nkp,notetra,unitc,1,6,7,8,ierr)
               if(ierr.eq.1) go to 7 
               call get_tetrah(kpoint,nkp,notetra,unitc,8,2,4,3,ierr)
               if(ierr.eq.1) go to 7 
            end do
         end do
      end do
c
c_________ a short stop to take a deep breath
c
      write(*,*)'The number of divisions is ',ndiv
      write(*,*)'Total number of tetrahedra generated: ',notetra
      write(*,*)'Total number of k-points generated: ',nkp
 7    close (44)
      write(*,*)'Choose another division (y,Y/any other char)?'
      read(*,'(a)',err=10) answer
      if(answer.eq.'y' .or. answer.eq.'Y') go to 5
c
c........ store the set kpoint(number,component) of different k-points
c in the file fort.15 via coefficients with respect to the reciprocal
c lattice vectors BJ.
c
      kpmethod='tetr'
      return
c.............. errors
10    write(*,*)'Error! Try again!'
      go to 7
      end

      subroutine write_kp(nkp,kpoint,Which_Code,YES_xyz,YES_vibr)
c.......................................................................
c  It creates a geometry file and a file with k-points built before. 
c.......................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'siesta.inc'
      include 'qe.inc'
      include 'mendeleev.inc'
      parameter (tiny=0.00001)
      character Which_Code*6,Which_Format*6,seed1*40,YES_xyz*4
      character cha2*2,cha1,list_q(100)*29,types(7)*4,answer
      dimension X(3),t(3),weight(Nkpoint)
      integer set_beg(SETS),set_end(SETS),rf1,rf2,rf3
      logical  cp2k_motion,cp2k_constr,cp2k_subsys,cp2k
      double precision kpoint(Nkpoint,3),vmod(3),Fr(3,N0LT)
      logical Err,list_at(N0LT),frozen,YES_vibr,constr(N0LT)
      logical written_constr

      data types/' X  ','  Y ','   Z',' XY ',' XZ ',' YZ ',' XYZ'/
c
c..............................................................
c....................... write geometry .......................
c..............................................................
c
c........ choose the write/output format
c
      call ask_which_format(Which_Code,Which_Format,seed1,l0seed1,
     ,                             'S')
c     
c............... CETEP/CASTEP
c
      IF(Which_Format.eq.'CASTEP' .or. Which_Format.eq.' CETEP') THEN

c____________lattice vectors

         if(Which_Format.eq.'CASTEP') then
            if(seed.eq.seed1) call system('/bin/mv '//
     &         seed(l0seed:)//'.geom '//seed(l0seed:)//'.geom.bak')
            open(88,file=seed1(l0seed1:)//'.geom',status='unknown')
         else 
            if(Which_Code.eq.Which_Format) call system('/bin/mv '//
     &         'fort.15 fort.15.bak')
            open(88,file='fort.15',status='unknown')
         end if

         write(88,'(3(f16.12,1x))') (AJ(i,1),i=1,3)
         write(88,'(3(f16.12,1x))') (AJ(i,2),i=1,3)
         write(88,'(3(f16.12,1x))') (AJ(i,3),i=1,3)
         write(88,'(3(f16.12,1x))') (AJ(i,1),i=1,3)
         write(88,'(3(f16.12,1x))') (AJ(i,2),i=1,3)
         write(88,'(3(f16.12,1x))') (AJ(i,3),i=1,3)
         write(88,*)
c____________atomic coordinates in fractional 
         k0=0
         do ii=1,Nsp
            do jj=1,2
               k=0
               do j=1,NspN(ii)
                  k=k+1
                  k1=k0+k
                  do i=1,3
                     t(i)=TI(1,k1)*BJ(i,1)+TI(2,k1)*BJ(i,2)+
     +                                         TI(3,k1)*BJ(i,3)
                     if(abs(t(i)).lt.tiny) t(i)=0.0
                  end do
                  s0=0.0
                  if(relax_flag(1,k1).eq.'T') s0=1.0
                  write(88,'(4(f16.12,1x))') t(1),t(2),t(3),s0
               end do
               write(88,*) 
            end do
            k0=k0+k
         end do
         write(88,*)
         if(Which_Format.eq.'CASTEP') then
            write(*,*)'Written geometry to '//seed1(l0seed1:)//'.geom'
         else 
            write(*,*)'Written geometry to fort.15'
         end if
c
c............... VASP and VASP v.5.2
c
      ELSE IF(Which_Format.eq.'  VASP' .or. 
     &                                  Which_Format.eq.'VASP52') THEN

         if(seed.eq.seed1) call system('/bin/mv '//
     &         seed(l0seed:)//' '//seed(l0seed:)//'.bak')
         open(88,file=seed1(l0seed1:),status='unknown')
         if(Nsp.lt.10) then
            write(cha1,'(i1)') Nsp
            cha2=' '//cha1
         else
            write(cha2,'(i2)') Nsp
         end if
         if(Which_Code.eq.Which_Format) then
            call right(vtitle,80,lvt)
            write(88,'(2a,'//cha2//'(a,x))') 
     &           vtitle(lvt:),' -> Species: ',(Species(i),i=1,Nsp)
            write(88,*) vscale
         else
            write(88,'(2a,'//cha2//'(a,x))') 
     &           'made by tetr; --> species: ',(Species(i),i=1,Nsp)
            write(88,'(a)') '1.0'
            vscale=1.0
            how_geometry='carte'
            sel_dyn=.true.
         end if
         write(88,*) AJ(1,1)/vscale, AJ(1,2)/vscale, AJ(1,3)/vscale
         write(88,*) AJ(2,1)/vscale, AJ(2,2)/vscale, AJ(2,3)/vscale
         write(88,*) AJ(3,1)/vscale, AJ(3,2)/vscale, AJ(3,3)/vscale
         if(Which_Format.eq.'VASP52') then
            write(88,'('//cha2//'(a,x))') (Species(i),i=1,Nsp)
         end if
         write(88,*) (NspN(i),i=1,Nsp)
         if(sel_dyn) write(88,'(a)')'Selective dynamics'
         write(*,*)
     &    'Output geometry in Cartesian (C,c) or Fractional (F,f)?'
         read(*,'(a)') answer
         if(answer.eq.'C' .or. answer.eq.'c') then
            how_geometry='carte'
            write(*,*)'... geometry => Cartesian ...'
         else if(answer.eq.'F' .or. answer.eq.'f') then
            how_geometry='fract'
            write(*,*)'... geometry => Fractional/Direct ...'
         else
            write(*,*)'... geometry => as in the input ...'
         end if
         if(how_geometry.eq.'carte') then
            write(88,'(a)')'Cartesian'
            nat=0
            do i=1,Nsp
               do k=1,NspN(i)
                  nat=nat+1
                  if(sel_dyn) then
                     write(88,'(3(f16.12,x),2x,3(a,x))') 
     &                (TI(j,nat)/vscale,j=1,3),(relax_flag(j,nat),j=1,3)
                  else
                     write(88,'(3(f16.12,x))') (TI(j,nat)/vscale,j=1,3)
                  end if
               end do
               write(88,*)
            end do
         else
            write(88,'(a)')'Direct'
            nat=0
            do i=1,Nsp
               do k=1,NspN(i)
                  nat=nat+1
                  do j=1,3
                     t(j)=TI(1,nat)*BJ(j,1)+TI(2,nat)*BJ(j,2)+
     +                    TI(3,nat)*BJ(j,3)
                     if(abs(t(j)).lt.tiny) t(j)=0.0
                  end do
                  if(sel_dyn) then
                     write(88,'(3(f16.12,x),2x,3(a,x))') 
     &                    (t(j),j=1,3),(relax_flag(j,nat),j=1,3)
                  else
                     write(88,'(3(f16.12,x))') (t(j),j=1,3)
                  end if
               end do
               write(88,*)
            end do
         end if
         close (88)
         write(*,*)'Written geometry to '//seed1(l0seed1:)
c
c............... CRYSTAL
c
      ELSE IF(Which_Format.eq.'CRYSTL') THEN
         if(seed.eq.seed1) call system('/bin/mv '//
     &        seed(l0seed:)//' '//seed(l0seed:)//'.bak')
         open(88,file=seed1(l0seed1:),status='unknown')
         write(88,*)'# dimensionality, centring and crystal type here'
         write(88,*) AJ(1,1), AJ(1,2), AJ(1,3)
         write(88,*) AJ(2,1), AJ(2,2), AJ(2,3)
         write(88,*) AJ(3,1), AJ(3,2), AJ(3,3)
         write(88,*) '1'
         write(88,*) '1.0 0.0 0.0'
         write(88,*) '0.0 1.0 0.0'
         write(88,*) '0.0 0.0 1.0'
         write(88,*) '0.0 0.0 0.0'
         write(88,*) ITI
         nat=0
         do i=1,Nsp
            call check_Mendel(Species(i),mendl,Err,.false.)
            if(Err) write(*,'(a)') 'WARNING: wrong species '//
     &                         Species(i)//' in CRYSTAL input'
            do k=1,NspN(i)
               nat=nat+1
               write(88,'(i5,3(x,e12.6))') mendl, (TI(j,nat),j=1,3)
            end do     
         end do
         close (88)
         write(*,*)'Written geometry to '//seed1(l0seed1:)
c
c............... LAMMPS
c
      ELSE IF(Which_Format.eq.'LAMMPS') THEN
         if(seed.eq.seed1) call system('/bin/mv '//
     &        seed(l0seed:)//' '//seed(l0seed:)//'.bak')
         open(88,file=seed1(l0seed1:),status='unknown')

c________ work out fractional coordinates with old vectors
         do k=1,ITI
            Fr(1,k)=TI(1,k)*BJ(1,1)+TI(2,k)*BJ(1,2)+TI(3,k)*BJ(1,3)
            Fr(2,k)=TI(1,k)*BJ(2,1)+TI(2,k)*BJ(2,2)+TI(3,k)*BJ(2,3)
            Fr(3,k)=TI(1,k)*BJ(3,1)+TI(2,k)*BJ(3,2)+TI(3,k)*BJ(3,3)
         end do

c_________ rotate the vectors so that the 1st is along X axis, the 2nd in the
c            XY plane, the 3rd as required to keep the same relative orientation
         do i=1,3
           vmod(i)=sqrt(AJ(i,1)*AJ(i,1)+AJ(i,2)*AJ(i,2)+AJ(i,3)*AJ(i,3))
         end do
         vdot12=AJ(1,1)*AJ(2,1)+AJ(1,2)*AJ(2,2)+AJ(1,3)*AJ(2,3)
         vdot13=AJ(1,1)*AJ(3,1)+AJ(1,2)*AJ(3,2)+AJ(1,3)*AJ(3,3)
         vdot23=AJ(2,1)*AJ(3,1)+AJ(2,2)*AJ(3,2)+AJ(2,3)*AJ(3,3)
         prod123=AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(3,2)*AJ(2,3))-
     -           AJ(1,2)*(AJ(2,1)*AJ(3,3)-AJ(3,1)*AJ(2,3))+
     +           AJ(1,3)*(AJ(2,1)*AJ(3,2)-AJ(3,1)*AJ(2,2))
         cos12=vdot12/(vmod(1)*vmod(2))  ; sin12=sqrt(1.0-cos12*cos12)

c________ lower triangular matrix
         AJ(1,1)=vmod(1) ; AJ(1,2:3)=0.0
         AJ(2,1)=vmod(2)*cos12 ; AJ(2,2)=vmod(2)*sin12 ; AJ(2,3)=0.0
         AJ(3,1)=vdot13/vmod(1)
         AJ(3,2)=( vdot23/vmod(2)-vdot13/vmod(1)*cos12 )/sin12
         AJ(3,3)=prod123/(vmod(1)*vmod(2)*sin12)

c________ change Cartesian positions of atoms
         do k=1,ITI
           TI(1,k)=Fr(1,k)*AJ(1,1)+Fr(2,k)*AJ(2,1)+Fr(3,k)*AJ(3,1)
           TI(2,k)=Fr(1,k)*AJ(1,2)+Fr(2,k)*AJ(2,2)+Fr(3,k)*AJ(3,2)
           TI(3,k)=Fr(1,k)*AJ(1,3)+Fr(2,k)*AJ(2,3)+Fr(3,k)*AJ(3,3)
         end do

c_______ write file
         write(88,*)'# LAMMPS structure atom_style atomic'
         write(88,*) ITI, ' atoms'
         write(88,*) Nsp, ' atom types'
         write(88,*) ''
         write(88,'(1x,a3,1x,F25.14,1x,a7)') '0.0',AJ(1,1),'xlo xhi' 
         write(88,'(1x,a3,1x,F25.14,1x,a7)') '0.0',AJ(2,2),'ylo yhi' 
         write(88,'(1x,a3,1x,F25.14,1x,a7)') '0.0',AJ(3,3),'zlo zhi' 
         write(88,'(3(1x,F25.14),1x,a8)') AJ(2,1),AJ(3,1),
     &                                    AJ(3,2), 'xy xz yz' 
         write(88,*) ''
         write(88,*) lkeyword
         write(88,*) ''
         nat=0
         do is=1,Nsp
            do nn=1,NspN(is) 
                nat=nat+1
                write(88,'(1x,I0,1x,I0,3(1x,F25.14))') nn,is,
     &               (TI(j,nat),j=1,3)
            end do
         end do
         close (88)
         write(*,*)'Written geometry to '//seed1(l0seed1:)
c
c............... LM
c
c      ELSE IF(Which_Format.eq.'    LM') THEN
c         if(seed.eq.seed1) call system('/bin/mv '//
c     &        seed(l0seed:)//' '//seed(l0seed:)//'.bak')
c         open(88,file=seed1(l0seed1:),status='unknown')

c         write(lm_string1,"(i3)") ITI 
c         write(lm_string2,"(f9.6)") alat/alat ! Fudge

c         write(88,"(a,9(f10.7,x))") "% site-data vn=3.0 fast io=62 " //
c     &     "nbas=" //  trim(adjustl(lm_string1)) // " alat=" // 
c     &     trim(adjustl(lm_string2)) //  " plat=",
c     &     ((AJ(i,j)/0.529177249, j=1,3), i=1,3) 
c         write(88,"(a)") lmLine2
         
c         do j = 1, Nsp
c           Nspec(j) = NspN(j) + Nspec(j-1)
c         end do

c         i = 1;
c         do j = 1, Nsp
c           do while (i <= Nspec(j))
c             NAZV1(i) = adjustl(Species(j)) ! sList
c             i = i + 1
c           end do
c         end do
 
c         rlax(:) = 111 ! Change when relaxations are needed        
 
c         do nat=1,ITI
c           write(88,'(x,a2,5x,(3(2x,f10.7)),(3(3x,f10.7)),
c     &       (3(3x,f10.7)),f9.6,(2(i3,x)))') NAZV1(nat), 
c     &       (TI(j,nat)/0.529177249, j=1,3), (vel(j,nat),j=1,3), 
c     &       (eula(j,nat),j=1,3), vshift(nat), PL(nat), rlax(nat)        
c         end do
c
c............... SIESTA
c
      ELSE IF(Which_Format.eq.'SIESTA') THEN
         if(seed.eq.seed1) call system('/bin/mv '//
     &        seed(l0seed:)//'.fdf '//seed(l0seed:)//'.fdf.bak')
         open(88,file=seed1(l0seed1:)//'.fdf',status='unknown')
         
c__________________ take care of diagonal parameters for non-scf calculations

         i0=0 ; i1=0 ; i2=0 ; i3=0 ; i4=0 ; i5=0 ; i6=0
         write(*,*) 'nlines = ',nlines
         
         do nl=1,nlines
            if(index(lines(nl),'SystemLabel').ne.0) then
               write(88,'(a)') 'SystemLabel '//seed1(l0seed1:)
               i2=1
            else if(index(lines(nl),'SolutionMethod').ne.0)  then
               write(88,'(a)') 'SolutionMethod diagon'
               i0=1
            else if(index(lines(nl),'BandLineScale').ne.0) then
               i1=1
            else  if(YES_vibr .and. 
     &                index(lines(nl),'MD.NumCGSteps').ne.0) then
               write(88,'(a)') 'MD.NumCGSteps 0'
               i3=1
            else if(YES_vibr .and. 
     &                index(lines(nl),'UseSaveData').ne.0) then
               write(88,'(a)') 'UseSaveData false'
               i4=1
            else if(YES_vibr .and.
     &                index(lines(nl),'DM.UseSaveDM').ne.0) then
               write(88,'(a)') 'DM.UseSaveDM false'
               i5=1
            else if(YES_vibr .and.
     &                index(lines(nl),'MD.TypeOfRun').ne.0) then
               write(88,'(a)') 'MD.TypeOfRun CG'
               i6=1
            else    
               do i=1,100
                  if(lines(nl)(i:i).ne.' ') then
                     if(lines(nl)(1:1).eq.'#') then
                        write(88,'(/a)') trim(lines(nl))
                     else
                        write(88,'(a)') trim(lines(nl))
                     end if
                     go to 10
                  end if
               end do
            end if
 10      end do
         if(i0.eq.0) write(88,'(a)') 'SolutionMethod diagon'
         if(i2.eq.0) write(88,'(a)') 'SystemLabel '//seed1(l0seed1:)
         if(YES_vibr .and. i3.eq.0) write(88,'(a)') 'MD.NumCGSteps 0'
         if(YES_vibr .and. i4.eq.0) write(88,'(a)') 'UseSaveData false'
         if(YES_vibr .and. i5.eq.0) write(88,'(a)') 'DM.UseSaveDM false'
         if(YES_vibr .and. i6.eq.0) write(88,'(a)') 'MD.TypeOfRun CG'

c__________________ geometry constraints if any
         frozen=.false.
         do i=1,ITI
            if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' 
     &                             .or. relax_flag(3,i).eq.'F') then
               frozen=.true.
               write(88,'(/a)') '%block GeometryConstraints'
               go to 5
            end if
         end do
         if(.not.frozen) go to 15
c__________firstly, for all atoms which are completely frozen
 5       do i=1,ITI
            if(relax_flag(1,i).eq.'F' .and. relax_flag(2,i).eq.'F' 
     &                             .and. relax_flag(3,i).eq.'F') then
               list_at(i)=.true.
            else
               list_at(i)=.false.
            end if
         end do
         call do_sets_from_list(list_at,ITI,n,set_beg,set_end,SETS)
         do i=1,n
            if(set_beg(i).eq.set_end(i)) then
               write(88,'(a,i10)') 'position ',set_beg(i)
            else
               write(88,'(a,i10,a,i10)') 'position from ',
     &              set_beg(i),' to ',set_end(i)
            end if
         end do
c__________secondly, for all atoms which are frozen in some directions only
         do i=1,ITI
            if(.not.list_at(i)) then
               if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' 
     &                             .or. relax_flag(3,i).eq.'F') then
                  do j=1,3
                     x(j)=0.0
                     if(relax_flag(j,i).eq.'F') x(j)=1.0
                  end do
                  write(88,'(a,i5,3(x,f4.1))') 'position ',i, x
               end if
            end if
         end do
         write(88,'(a/)') '%endblock GeometryConstraints'

c__________________ geometry part now

 15      write(88,'(/a,i5)') 'NumberOfSpecies ',Nsp
         write(88,'(a,i5/)') 'NumberOfAtoms   ',ITI
         write(88,'(a)') '%block ChemicalSpeciesLabel'
         do i=1,Nsp
            call check_Mendel(Species(i),mendl,Err,.false.)
            if(Err) write(*,'(a)') 'WARNING: wrong species '//
     &                         Species(i)//' in SIESTA input'
            write(88,'(i5,x,i2,x,a)') i,mendl,Species(i)
         end do
         write(88,'(a/)') '%endblock ChemicalSpeciesLabel'
         write(88,'(a,f10.5,a)') 'LatticeConstant ',vscale,' Ang'
         write(88,'(a)') '%block LatticeVectors'
         do i=1,3
            write(88,*) (AJ(i,j)/vscale,j=1,3)
         end do
         write(88,'(a/)') '%endblock LatticeVectors'
         write(88,'(a)') 'AtomicCoordinatesFormat Ang'
         write(88,'(a)')'%block AtomicCoordinatesAndAtomicSpecies'
         nat=0
         do i=1,Nsp
            do k=1,NspN(i)
               nat=nat+1
               write(88,'(3(f16.12,x),i5,a,a,i5)') 
     &              (TI(j,nat)/vscale,j=1,3),i,' # ',Species(i),nat
            end do
         end do
         write(88,'(a)')'%endblock AtomicCoordinatesAndAtomicSpecies'
         write(*,*)'Written geometry to '//seed1(l0seed1:)//'.fdf'
c
c............... QUICKSTEP
c
      ELSE IF(Which_Format.eq.'QUICKS') THEN
         written_constr=.false.
         if(seed.eq.seed1) call system('/bin/mv '//
     &           seed(l0seed:)//' '//seed(l0seed:)//'.bak')
         
         open(88,file=seed1(l0seed1:),status='unknown')

c.............. analysing the existing input and checking blocks

         cp2k_motion=.false. ; cp2k_constr=.false. ; cp2k_subsys=.false.
         if(nlines.gt.1) then
            do nl=1,nlines
               if(index(lines(nl),'&SUBSYS').ne.0) cp2k_subsys=.true.
               if(index(lines(nl),'&MOTION').ne.0) cp2k_motion=.true.
               if(index(lines(nl),'&CONSTR').ne.0) cp2k_constr=.true.
            end do
         end if
         cp2k=.false. ; i=0
         do is=1,Nsp
            do n=1,NspN(is)
               i=i+1
               if(relax_flag(1,i).eq.'F' .or. relax_flag(2,i).eq.'F' 
     &                  .or. relax_flag(3,i).eq.'F') then
                  cp2k=.true. ; exit
               end if
            end do
         end do

c................ writing the existing portion of the input file if the
c        one is new or the old one was imcomplete
         
c         if(.not.cp2k_subsys .or. .not.cp2k_motion 
c     &        .or. nlines.eq.0)  then
         if(.not.cp2k_subsys .or. nlines.eq.0)  then

            write(88,'(a)') '  &SUBSYS'
            write(88,'(a)') '    &CELL'
            write(88,'(a,3(x,f14.9))')'A ',(AJ(1,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'B ',(AJ(2,j),j=1,3)
            write(88,'(a,3(x,f14.9))')'C ',(AJ(3,j),j=1,3)
            write(88,'(a)') '    &END CELL'
            write(88,'(a)') '    &COORD'
            nat=0
            do is=1,Nsp
               do n=1,NspN(is)
                  nat=nat+1
                  write(88,'(a,3(x,f14.9))') 
     &                 Species(is),(TI(j,nat),j=1,3)
               end do
            end do
            write(88,'(a)') '    &END COORD'
            write(88,'(a)') '  &END SUBSYS'

            write(88,'(a)') '  &MOTION'
            if(cp2k) then
               write(88,'(a)') '    &CONSTRAINT'
               do it=1,7
                  call relax_list_QUICKSTEP(constr,it,list_q,nn)
                  if(nn.ne.0) then
                     write(88,'(a)') '      &FIXED_ATOMS'
                     write(88,'(9x,a)') 'COMPONENTS_TO_FIX '//types(it)
                     do is=1,nn
                        write(88,'(9x,a)') list_q(is)
                     end do
                     write(88,'(a)') '      &END FIXED_ATOMS'
                  end if
               end do
               write(88,'(a)') '    &END CONSTRAINT'
            end if
            write(88,'(a/)') '  &END MOTION'

c____________ write whatever remains of the old file

            write(88,'(a/)')'########### REMAINS of the OLD file ######'
            if(nlines.ne.0) then
               do nl=1,nlines
                  write(88,'(a)') trim(lines(nl))
               end do
            end if
            write(*,*) 'WARNING! The input file will need EDITING!'
            write(*,*)'Press ENTER when done ...'
            read(*,*)

c................ writing changes to the old file: geometry & constraints

         else

            do nl=1,nlines
               
               if(index(lines(nl),'&END').ne.0 .and. 
     &                      index(lines(nl),'SUBSYS').ne.0) then
                  
c___________ cell
                  write(88,'(a)') '  &CELL'
                  write(88,'(a,3(x,f14.9))')'A ',(AJ(1,j),j=1,3)
                  write(88,'(a,3(x,f14.9))')'B ',(AJ(2,j),j=1,3)
                  write(88,'(a,3(x,f14.9))')'C ',(AJ(3,j),j=1,3)
                  write(88,'(a)') '  &END CELL'

c___________ coordinates
                  write(88,'(a)') '  &COORD'
                  nat=0
                  do is=1,Nsp
                     do n=1,NspN(is)
                        nat=nat+1
                        write(88,'(a,3(x,f14.9))') 
     &                       Species(is),(TI(j,nat),j=1,3)
                     end do
                  end do
                  write(88,'(a)') '  &END COORD'
                  write(88,'(a)') trim(lines(nl))

c___________ constraints (if any)

               else if(index(lines(nl),'&MOTION').ne.0) then

                  i0=index(lines(nl),'&') 
                  write(88,'(a)') trim(lines(nl))
                  if(cp2k) then
                     write(88,'(a)') '    &CONSTRAINT'
                     do it=1,7
                        call relax_list_QUICKSTEP(constr,it,list_q,nn)
                        if(nn.ne.0) then
                           write(88,'(a)') '      &FIXED_ATOMS'
                           write(88,'(6x,a)') 
     &                                 'COMPONENTS_TO_FIX '//types(it)
                           do is=1,nn
                              write(88,'(9x,a)') list_q(is)
                           end do
                           write(88,'(a)') '      &END FIXED_ATOMS'
                        end if
                     end do
                     write(88,'(a)') '    &END CONSTRAINT'
                  end if

c_____________ the rest of the old file
                  
               else if(index(lines(nl),'RUN_TYPE').ne.0 .and.
     &                             index(lines(nl),'#').eq.0) then
                  
                  if(Yes_vibr) then
                     write(88,'(a)') '     RUN_TYPE ENERGY_FORCE'
                  else
                     write(88,'(a)') trim(lines(nl))
                  end if

c_____________ the rest of the old file
                  
               else

                  if(index(lines(nl),'CONSTRAINT').eq.0)
     &                 write(88,'(a)') trim(lines(nl))
               end if
            end do

         end if
c
c............... Quantum Espresso
c
      ELSE IF(Which_Format.eq.'    QE') THEN

         if(seed.eq.seed1) call system('/bin/mv '//
     &           seed(l0seed:)//' '//seed(l0seed:)//'.bak')
         
         open(88,file=seed1(l0seed1:),status='unknown')

         do nl=1,nlines
            if(index(lines(nl),'ibrav').ne.0) then
               write(88,'(5x,a)')         'ibrav      = 0,'
               write(88,'(5x,a,f10.5,a)') 'celldm(1)  = ',vscale,','
               write(88,'(5x,a,i5,a)')    'nat        = ',ITI,','
               write(88,'(5x,a,i5,a)')    'ntyp       = ',Nsp,','
            else
               write(88,'(a)') trim(lines(nl))
            end if
         end do
         write(88,'(a)') 'CELL_PARAMETERS'
         write(88,'(3(x,f14.9))') (AJ(1,j)/vscale,j=1,3)
         write(88,'(3(x,f14.9))') (AJ(2,j)/vscale,j=1,3)
         write(88,'(3(x,f14.9))') (AJ(3,j)/vscale,j=1,3)
         write(88,'(a)') 'ATOMIC_SPECIES'
         do is=1,Nsp
            if(is.le.Nsp_QE) then
               write(88,'(a2,x,f10.5,x,a)') Species(is),QE_masses(is),
     ,              psp_names(is)(psp_l0(is):)
            else
               call check_Mendel(Species(is),mendl,Err,.false.)
               if(Err) write(*,'(a)') 'WARNING: wrong species '//
     &              Species(is)//' in QE input'
               write(88,'(a2,x,f10.5,a)') Species(is),At_Masses(mendl),
     ,              '      XXXXXXXXXXXXXX.UPF'
            end if
         end do
         write(88,'(a)') 'ATOMIC_POSITIONS'
         nat=0
         do is=1,Nsp
            do n=1,NspN(is)
               nat=nat+1
               rf1=0 ; if(relax_flag(1,nat).eq.'T') rf1=1
               rf2=0 ; if(relax_flag(2,nat).eq.'T') rf2=1
               rf3=0 ; if(relax_flag(3,nat).eq.'T') rf3=1
               write(88,'(a2,3(x,f10.5),3i2)') 
     &                 Species(is),(TI(j,nat)/vscale,j=1,3),rf1,rf2,rf3
            end do
         end do
c     
c............... XYZ
c
      ELSE IF(Which_Format.eq.'   XYZ') THEN
         if(seed.eq.seed1) call system('/bin/mv '//
     &         seed(l0seed:)//'.xyz '//seed(l0seed:)//'.xyz.bak')
         open(14,file=seed1(l0seed1:)//'.xyz',status='unknown')
         call create_film_xyz(TI,ITI,Species,Nsp,NspN,AJ,
     ,        0,0,0,0,0,0,YES_xyz,.false.)
         close (14)
         write(*,*)'Written geometry to '//seed1(l0seed1:)//'.xyz'
         return
c
c............... None: do not save at all!
c
      ELSE IF(Which_Format.eq.'  None') THEN
         return
      END IF
c
c..................................................................
c....................... write K-points ...........................
c..................................................................
c a loop with respect to different k-points from the set kpoint():
c store them in the file fort.15 (unit 88) via coefficients wrt
c the reciprocal lattice vectors BJ.
c       nkp - counts different k-points
c       weight - corresponding weights
c..................................................................
c     
c_______calculate weights with respect to the symmetry
c     
      if(nkp.eq.0) then
         if(Which_Format.eq.'    QE') then
            vv=vscale/(2*pi)
            nkp=QE_nkp ; kpoint=QE_kpoint*vv ; weight=QE_weight
            do i=1,nkp
               write(*,*) (kpoint(i,j),j=1,3),weight(i)
            end do
         else
            go to 100
         end if
      else
         nn=0
         do i=1,nkp
            x(1:3)=kpoint(i,1:3)
            call k_star(x,n_dim)
            weight(i)=n_dim
            nn=nn+n_dim
         end do
         weight=weight/nn
      end if
c
c............... VASP, CASTEP, SETEP, SIESTA
c
      if(Which_Format.eq.'  VASP' .or.
     &                                  Which_Format.eq.'VASP52') then
         call system('/bin/mv KPOINTS KPOINTS.bak')
         open (88,file='KPOINTS',status='unknown')
         write(88,'(a)')'created by tetr'
         write(88,'(i10)') nkp
         write(88,'(a)')'Reciprocal'
      else if(Which_Format.eq.'SIESTA') then
         if(kpmethod.eq.'  mp') then
            write(88,'(/a)')'%block kgrid_MonkhorstPack'
            write(88,'(i5,a)') qMP1,' 0 0 0.0'
            write(88,'(a,i5,a)') '0 ', qMP2,' 0 0.0'
            write(88,'(a,i5,a)') '0 0 ',qMP3,'  0.0'
            write(88,'(a)') '%endblock kgrid_MonkhorstPack'
         else if(kpmethod.eq.'tetr' .or. kpmethod.eq.'band') then
            write(88,'(/a)') 'BandLineScale ReciprocalLatticeVectors'
            write(88,'(a)') '%block BandPoints'
         end if
      else if(Which_Format.eq.'    QE') then
         write(88,'(a)') 'K_POINTS'
         write(88,'(i5)') nkp
         do kp=1,nkp
            write(88,'(4(f10.5,x))') (kpoint(kp,j),j=1,3),weight(kp)
         end do
      end if
c     
c_______transform kpoint() to fractional coordinates and write to unit=88:
c     
      do i=1,nkp
         a1=kpoint(i,1)*AJ(1,1)+kpoint(i,2)*AJ(1,2)+
     +        kpoint(i,3)*AJ(1,3)
         a2=kpoint(i,1)*AJ(2,1)+kpoint(i,2)*AJ(2,2)+
     +        kpoint(i,3)*AJ(2,3)
         if(z_supp) then
            a3=0.0
         else
            a3=kpoint(i,1)*AJ(3,1)+kpoint(i,2)*AJ(3,2)+
     +           kpoint(i,3)*AJ(3,3)
         end if
         if(Which_Format.eq.' CETEP' .or. Which_Format.eq.'  VASP' .or.
     &                                    Which_Format.eq.'VASP52') then
            write(88,'(4(f16.12,x))') a1,a2,a3, weight(i)
         else if(Which_Format.eq.'CASTEP') then
            write(88,'(3(f16.12,x))') a1,a2,a3
         else if(Which_Format.eq.'SIESTA') then
            if(kpmethod.eq.'tetr' .or. kpmethod.eq.'band') 
     &                     write(88,'(4(f16.12,x))') a1,a2,a3, weight(i)
         end if
      end do

c..... finish

      if(Which_Format.eq.'CASTEP') then
         do i=1,nkp
            write(88,'(4(f16.12,x))') weight(i)
         end do
         write(*,*)'Written k-points to '//seed1(l0seed1:)//'.geom'
      else if(Which_Format.eq.'    QE') then
         write(*,*)'Written k-points to '//seed1(l0seed1:)
         write(*,*)' Check '//seed1(l0seed1:)//'file before QE run!'
      else if(Which_Format.eq.'SIESTA') then
         if(kpmethod.eq.'tetr' .or. kpmethod.eq.'band') 
     &                        write(88,'(a)') '%endblock BandPoints'
         write(*,*)'Written k-points to '//seed1(l0seed1:)//'.fdf'
         write(*,*)'----------------------IMPORTANT------------------'
         write(*,*)' Check '//seed1(l0seed1:)//
     &           '.fdf file before SIESTA run'
         write(*,*)'as the k-point info may be contained more than once' 
         write(*,*)'----------------------IMPORTANT--------------------'
         write(*,*)
         write(*,*)'Hit ENTER when done  ...'
         read(*,*)
      else if(Which_Format.eq.'  VASP' .or.
     &                                  Which_Format.eq.'VASP52') then
         write(*,*)'Written k-points to KPOINTS file'
      end if
 100  close(unit=88)

      return
      end

      subroutine relax_list_QUICKSTEP(constr,fix_type,list_q,n)
c........................................................................
c works out the lists of atoms for QUICKSTEP input file which correspond
c to a particular fix_type = 1, ...,7 of constraints
c........................................................................
c fix_type = 0, 1, 2, 3, 4, 5, 6,  7  corresponds to the following fixed:
c           no  X  Y  Z  XY XZ YZ XYZ
c........................................................................
c OUTPUT: 
c      n       - number of continuous lists of atoms
c   list_q(i)  - character string for each list i=1,..,n in the format 
c                of QUICKSTEP
c........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'siesta.inc'
      integer fix_type, len1,len2
      logical constr(N0LT)
      integer set_beg(SETS),set_end(SETS)
      character cha1*10,cha2*10,list_q(100)*29

      do i=1,ITI
         constr(i)=.false.
      end do

c_____________________ go over all types

      do i=1,ITI
         if(fix_type.eq.1 .and. relax_flag(1,i).eq.'F' .and. 
     &        relax_flag(2,i).eq.'T' .and. relax_flag(3,i).eq.'T') then
            constr(i)=.true.
         else if(fix_type.eq.2 .and. relax_flag(1,i).eq.'T' .and. 
     &        relax_flag(2,i).eq.'F' .and. relax_flag(3,i).eq.'T') then
            constr(i)=.true.
         else if(fix_type.eq.3 .and. relax_flag(1,i).eq.'T' .and. 
     &        relax_flag(2,i).eq.'T' .and. relax_flag(3,i).eq.'F') then
            constr(i)=.true.
         else if(fix_type.eq.4 .and. relax_flag(1,i).eq.'F' .and. 
     &        relax_flag(2,i).eq.'F' .and. relax_flag(3,i).eq.'T') then
            constr(i)=.true.
         else if(fix_type.eq.5 .and. relax_flag(1,i).eq.'F' .and. 
     &        relax_flag(2,i).eq.'T' .and. relax_flag(3,i).eq.'F') then
            constr(i)=.true.
         else if(fix_type.eq.6 .and. relax_flag(1,i).eq.'T' .and. 
     &        relax_flag(2,i).eq.'F' .and. relax_flag(3,i).eq.'F') then
            constr(i)=.true.
         else if(fix_type.eq.7 .and. relax_flag(1,i).eq.'F' .and. 
     &        relax_flag(2,i).eq.'F' .and. relax_flag(3,i).eq.'F') then
            constr(i)=.true.
         end if
      end do

c............. create lists corresponding to the given fix_type      
c      n      - number of coninuous atomic numbers (up to 100 allowed)
c  set_beg(i) - first number of the list i 
c  set_end(i) - last number of the list i 

      call do_sets_from_list(constr,ITI,n,set_beg,set_end,SETS)
      if(n.eq.0) return

c............. create friendly lists in the QUICKSTEP format
      do i=1,n
         call number_to_char(set_beg(i),cha1,len1)
         call number_to_char(set_end(i),cha2,len2)
         list_q(i)=' LIST  '//cha1(1:len1)//'..'//cha2(1:len2)
      end do
      return
      end
      
      subroutine get_tetrah(point,nkp,notetra,unitc,i1,i2,i3,i4,ierr)
c........................................................................
c   It takes 4 corners i1,i2,i3,i4 of the cube from unitc(corner,compon.)
c and builds the tetrahedron:
c
c -  the corners are stored in the file 44;
c -  the number of tetrahedra ( notetra) is increased by 1;
c -  4 edges of the tetrahedra are verified if they give some new
c    k-points with respect to all nkp points previously picked up and
c    stored in the aray point(k-point,component);
c -  new points are written to point(,) and nkp is increased appropriately;
c -  for every 4 k-points staying at the edges of the tetrahedra a
c    reference aray k_pnt_ref(edge) is formed which gives the k-point
c    number in the list of different k-points (as in point(,) ); it is
c    also stored together with the tetrahedra in the file 44;
c........................................................................
c    Since all the tetrahedra are generated along BJ-vectors (inside the
c reciprocal unit cell instead of the Wigner-Zeighz BZ), there is no more
c need to check if all the edges are inside the BZ: by the construction,
c all the edges are always inside.
c........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension unitc(8,3),tetra(4,3),x(3),k_pnt_ref(4),t(3),r(3)
      dimension point(Nkpoint,3)
      logical ask_equiv
      ierr=0
c
c.........  build a tetrahedron from corners i1,i2,i3,i4 in tetra:
c
      do j=1,3
         tetra(1,j)=unitc(i1,j)
         tetra(2,j)=unitc(i2,j)
         tetra(3,j)=unitc(i3,j)
         tetra(4,j)=unitc(i4,j)
      end do
c     
c.......... write tetrahedra to unit=44 and increase the counter by 1;
c
      notetra=notetra+1
      write(44,*) notetra
      if(notetra.eq.1) then
         point(1,1)=tetra(1,1)
         point(1,2)=tetra(1,2)
         point(1,3)=tetra(1,3)
         if(z_supp) call suppr(point(1,1),point(1,2),point(1,3))
         nkp=1
      end if
c
c........................................................................
c   If it is not the 1st tetrahedron, check its edges with all nkp points
c defined previously and stored in point(k-point,component).
c   All points are checked together with all their rays in their stars.
c........................................................................
c
      do 50 k=1,4
         t(1)=tetra(k,1)
         t(2)=tetra(k,2)
         t(3)=tetra(k,3)
         do m=1,MGp
            j=KGp(m)
            x(1) = C(1,1,j)*t(1) + C(1,2,j)*t(2) + C(1,3,j)*t(3)
            x(2) = C(2,1,j)*t(1) + C(2,2,j)*t(2) + C(2,3,j)*t(3)
            x(3) = C(3,1,j)*t(1) + C(3,2,j)*t(2) + C(3,3,j)*t(3)
            if(z_supp) call suppr(x(1),x(2),x(3))
            do i=1,nkp
               r(1)=point(i,1)-x(1)
               r(2)=point(i,2)-x(2)
               r(3)=point(i,3)-x(3)
               if(z_supp) then
                  isp=2
               else
                  isp=3
               end if
               if(ask_equiv(r,AJ,isp,tiny_equiv)) then
                  k_pnt_ref(k)=i
                  go to 50
               end if
            end do
         end do
         nkp=nkp+1
         if(nkp.gt.Nkpoint) then
            write(*,*)'FATAL! Number of divisions is too large!'
            write(*,*)'Increase Nkpoint in ~/TOOLS/tetrag1.inc'
            write(*,*)' and recompile tetr there: make -f make.tetr'
            ierr=1
            return
         end if
         point(nkp,1)=tetra(k,1)
         point(nkp,2)=tetra(k,2)
         point(nkp,3)=tetra(k,3)
         if(z_supp) 
     &        call suppr(point(nkp,1),point(nkp,2),point(nkp,3))
         k_pnt_ref(k)=nkp
 50   continue
c     
c.......write the info about the tetrahedra to 44
c     
      write(44,*) (k_pnt_ref(k),k=1,4)
      write(44,*)
      return
      end

      subroutine suppr(x,y,z)
c........................................................................
c    In the case of the z-compresion (when this routine is only invoked)
c it removes the BJ(3) component of the vector (x,y,z)
c........................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
c_______ find coefficients a1,a2,a3 with respect to all BJ,
c        put a3=0 and recalculate the vector again:
c
      a1=x*AJ(1,1)+y*AJ(1,2)+z*AJ(1,3)
      a2=x*AJ(2,1)+y*AJ(2,2)+z*AJ(2,3)
      a3=0.0
      x=a1*BJ(1,1)+a2*BJ(2,1)
      y=a1*BJ(1,2)+a2*BJ(2,2)
      z=a1*BJ(1,3)+a2*BJ(2,3)
      return
      end

      subroutine k_star(r,n_dim)
c..................................................................
c    For the k-point r() (in reciprocal space up to 2*pi) it
c replies with the dimension, n_dim, of the star.
c..................................................................
      include 'real8.inc'
      include 'tetrag1.inc'
      include 'pgroup.inc'
      dimension r(3),star(48,3),x(3),d(3)
      logical ask_equiv
c     
c........ initial step
      if(z_supp) call suppr(r(1),r(2),r(3))
      star(1,1:3)=r(1:3)
      if(MGp.eq.1) then
         n_dim=1 ; return
      end if
c
c.......... construction of the star
      i1=1
      do 10 m=2,MGp
         j=KGp(m)
         x(1) = C(1,1,j)*r(1) + C(1,2,j)*r(2) + C(1,3,j)*r(3)
         x(2) = C(2,1,j)*r(1) + C(2,2,j)*r(2) + C(2,3,j)*r(3)
         x(3) = C(3,1,j)*r(1) + C(3,2,j)*r(2) + C(3,3,j)*r(3)
         if(z_supp) call suppr(x(1),x(2),x(3))
         do i=1,i1
            d(1:3)=star(i,1:3)-x(1:3)
            if(z_supp) then
               isp=2
            else
               isp=3
            end if
            if(ask_equiv(d,AJ,isp,tiny_equiv)) go to 10
         end do
         i1=i1+1
         star(i1,1:3)=x(1:3)
 10   continue
      n_dim=i1
      end

